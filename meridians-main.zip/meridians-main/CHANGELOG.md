# Changelog

What changed in Meridian, in plain language. Newest first. Numbered releases (`vX.Y.Z`) are the version shown in the app sidebar.

## Unreleased

### Charts that fit the question, separate charts, and a faster Ask (2026-10-20, v1.3.65)

- **A few totals show as a row of big numbers** (e.g. charges, visits, collections and denials for one doctor), whole dollars from $1,000, labels without "Sum of"
- **Rankings are sorted biggest first** ("Sorted by … ↓"); weeks, fiscal periods and quarters keep their time order
- **Long lists show the top 10 and one grey "All others" bar** (added up for counts and money; averages just say "Showing top 10 of n"); the full list stays in the table and downloads
- **Many or long names get sideways bars**, with the full name on hover; **bars always start at zero**; money per visit shows in $
- **Separate charts**: 3 or more measures become stacked charts sharing one time axis; more than 4 lines (e.g. visits by week for each clinic) become up to 12 small charts on the same scale, largest first. A "Separate charts / One chart" switch under the result, kept when you save; saved report cards keep their look
- **Ask is faster and cheaper**: it no longer waits for the list of doctor and clinic names, reuses its instructions between questions, answers more briefly, and answers a repeated question (same day and period) instantly at no cost
- **Ask knows our words**: billings = charges, collections = money collected, and visits from the billing data are clinic visits only (the answer says so)
- Negative money reads "-$35K"; narrow report tiles no longer break titles mid-word
- New: `docs/bi/ask-charts-knowledge-base.md`, the rulebook these charts follow

### Ask understands fiscal years, quarters, periods and weeks (2026-10-20, v1.3.64)

- **Ask now answers in fiscal terms**: "Bescos period 8 denials", "collections by quarter this fiscal year", "charges last period", "FY25 vs FY26". Claims, claim lines, payments, appointments and the visits-and-money table carry the fiscal year (Y26 = Dec 29 2025 – Dec 27 2026), quarter (Q1 = P1–3 … Q4 = P10–12, as in the Executive Report), period (P1–P12) and week
- **Payments count by the day the money came in**; claims, denials and visits by the service or visit date
- **"By period / by quarter" answers come out in time order** (P08, P09, P10 — never P10 before P2), each labelled with its year
- **Ask knows today's fiscal position** (for example "fiscal year Y26, quarter Q4, period P10"), so "this period", "last quarter" and "this fiscal year" mean the right weeks; calendar words like "last 30 days" or "October" still use calendar dates
- The fiscal calendar comes from the eCW data mart and refreshes with every data load

### Ask a question is clearer and keeps what you asked (2026-10-20, v1.3.63)

- **Your question stays put**: it stays in the box, shows above the answer as "You asked: …" with Meridian's note in a visible box, and is kept in the page link, so a reload brings back the question, note, title and chart without asking the AI again
- **Recent questions** under the box list your own last questions; one click asks it again. Only you see your own questions (Meridian staff still see the full Ask log)
- **The page scrolls to the answer** once it has run, and the builder's Visualize button stays hidden until you open "Show how this was built"
- **Save** fills in your question as the description
- **Digging deeper is easier to find**: a hint under every result says to click a bar, point or cell; a click with nothing under it says so; "See these rows" is no longer offered on summary-only tables (it used to fail there); the "Break out by" list scrolls instead of running off the screen
- **A list answer explains why it shows as a table** and points to the chart picker; a single row of totals no longer claims to be a list or invites a click that does nothing
- **Table headers read as words**: a total the AI named `total_visits` shows as "Total visits"

### Executive Report deck tables like the finance P&L, PDF deck (2026-10-19, v1.3.62)

- **Deck table headers are one solid navy block**: no lines between header cells, and the second header row ("Amount / % of rev.") is navy too, in the PowerPoint and its preview
- **Deck table rows read like the finance P&L**: totals bold navy on a pale-blue band, detail rows white with a black label and blue figures, no grid between rows. The report's own tabs stay as they were
- **Export → PDF deck works**: it opens a PDF preview of every slide; Save as PDF opens the print window with one slide per page and the deck's file name

### Executive Report notes shared, empty notes left out, one title style (2026-10-19, v1.3.61)

- **Notes are saved to AWS, not the browser**: the "Notes to ..." boxes now save by themselves, one shared copy per quarter or period (Alembic 0051), and show "Saved · name · time". Notes typed earlier in this browser are carried over once into an empty shared note.
- **Empty notes are left out of the PowerPoint and the preview**: a slide with blank notes gets no Notes heading or empty box, and its table uses the full width.
- **Every slide title looks the same** in the PowerPoint and the preview: one font, one size, one place; a long title wraps instead of shrinking. Summary and Next Steps slides now share the table slides' header.
### Ask finds doctors by name and answers money-with-visits questions (2026-10-19, v1.3.60)

- **Claims now carry the doctor's name**: the claims data had no provider name, so asking about a doctor's billings found nothing. The name now comes from the provider list
- **Ask knows the real doctor names**: they are in the list it matches against (names are stored LAST, FIRST), so "becos" finds "BESCOS, PILAR M". If a typed name still matches nobody, the answer says so and suggests the closest name
- **The first Ask after a restart waits up to 1.5 s** for that list instead of going without it
- **Money and visits in one answer**: a new "Visits and money by provider and day" table lets Ask show charges, collections, denials and visits side by side, and work out collections per visit
- **A busy AI model no longer fails the question**: Ask moves on to the next model, and the second model gets the plain question
- **A wrong-looking "Did you mean" can't break a question**, and it only shows for a likely typo of a real doctor's name
- **A slow AI model no longer makes you wait over a minute**: only an outage moves on to the next model, not a timeout
- **Missing data is said plainly**: asking for something the data doesn't have (like payer on claims) says so instead of answering with another column
- **"Highest" lists put empty rows last**: descending sorts now place blank values at the bottom

### Related questions keep their text (2026-10-19, v1.3.59)

- **Clicking a related question** keeps it in the Ask box so you can see what was asked, and a second click while it's answering is ignored instead of sending it twice

### Past Report day gets more time (2026-10-19, v1.3.58)

- **A past Report day no longer times out on a small database**: those cards recompute from the raw tables (only today's numbers are stored), so they now get up to 45 seconds instead of 10. Today's report is unchanged

### Daily Report loads fast (2026-10-19, v1.3.57)

- **Daily Report cards no longer time out on staging**: the heavy numbers behind every card on "Daily Report - Clinic" and "Daily Report - All Clinics" (day, week and weekday totals, performance rows, provider tables, visits detail, open notes, line of service) are now worked out once after each data load and stored, instead of re-reading about 1 GB of tables for every card. On the local copy every card went from 40-1,700 ms to under 15 ms. Choosing a past Report day still computes live
- **The data load refreshes them**: the mart load (and `apply_analytics_views.py --refresh`) rebuilds the stored numbers and updates the database's query statistics after every table, so a load always leaves the report current
- **Finished card runs are remembered for an hour**: a card that was just opened for the same person, filters and Report day comes back at once. Members and admins never share a remembered result, and a failed run is never remembered
- **A timed-out card is no longer run twice**: the page used to retry a 504 once, doubling the load on a slow database; it now shows the error with its Retry button straight away
- **The Clinic filter says "Loading choices"** (or that it could not load) instead of showing a list with only the default clinic, which looked like the whole list
- **Database setting (migration 0050)**: the BI reader role runs with JIT off, which stops the database spending seconds compiling these queries

### Chart readability (2026-10-19, v1.3.56)

- **Readable names**: legends, tooltips and axis titles show the column's display name ("Claims", "Total billed"); a raw `total_billed` is spelled out instead of shown as-is
- **Money looks like money**: dollar columns show compact ticks ($70K, $1.2M) on the axis and the full amount ($69,840) in tooltips and labels; counts stay plain numbers with thousands separators
- **Colors you can tell apart**: the chart palette is now color-blind safe (blue, orange, purple, green, red, light blue, pink, teal); no near-black or brown series. Colors you picked yourself are kept
- **Better default for money next to a count**: one dimension with a dollar measure and a count now opens as a combo chart: dollars as bars on the left axis, the count as a line on the right axis. A display you chose yourself is never changed
- **Clear dates**: week charts read "Week of Sep 28" and day charts "Sep 28" (the year is added when the data spans more than one year); months stay "Sep 2026"
### Executive Report tables shared (2026-10-19, v1.3.55)

- **Highlights and Initiatives are now the same for every admin**: the two typed tables save to the shared report in AWS, one copy per quarter or period, instead of staying in one browser. Open the same quarter on another computer and you see the same rows
- **Add and remove rows**: "Add row" under each table adds a topic (Highlights) or an initiative; rows you added can be removed (with a confirmation). The built-in rows stay
- **Click Hit, Miss or Challenge**: one status per row, click it again to clear it. The computed rows (Clinic Contribution, EBITDA, Visits) keep following the numbers and can carry an optional note
- **Saved by itself, and you can see who last edited**: a line under each table shows "Saved · name · time", or that it could not save and offers Retry. Text you typed is kept on the page until it is saved
- **Two admins no longer overwrite each other**: if someone saved the same table first, the changes are merged row by row; only if you both changed the same text do you get to pick which to keep
- **Old text in this browser can be imported once**: a banner offers "Review and import" for text typed here before the tables were shared. Nothing is imported until you click, and nothing is deleted unless it is already in the shared report (or you choose to discard it)
- **The deck uses the saved rows**: the PowerPoint contains exactly the rows saved for that period, and refuses to export if someone changed them while you were exporting. A final version freezes its rows. The three Notes boxes on the slides still save on this device only

### BI split y-axis (2026-10-19, v1.3.53)

- **Charts with very different sizes get two y-axes**: when one series is under a tenth the size of the biggest (say 10 claims next to $70,000 billed), it moves to a right-hand axis so it no longer shows as flat bars. Each axis is formatted and titled for its own series. Works on bar, line, area and combo charts; stacked, 100% stacked, row, pie, number and table are unchanged
- **Turn it off or pick a side**: Axes section of the chart settings has "Split axis when sizes differ a lot" plus Automatic / Left / Right for each series (combo charts now default each series to Automatic)
### v1.3.54 (2026-10-19)

- **Operations pages load much faster**: the heavy eCW claim, claim-line and appointment tables are now worked out once per Cobalt data load (a materialized view behind `analytics.fct_claim`, `fct_claim_line`, `fct_appointment`) instead of on every page view. On the local copy KPIs went from about 4.0 s to 0.7 s, Ultrasound 4.2 s to 0.7 s, Billing 1.6 s to 0.2 s, Portfolio 6.0 s to 1.2 s, with identical numbers. `copy_cobalt_to_aws.sh` refreshes them after each copy; `apply_analytics_views.py --refresh` does it on demand.

### BI on AWS (2026-10-16)

- **Reports & dashboards now store in the AWS database**: saved questions, dashboards, collections, models, metrics, saved filters and the download/row audit log live in RDS with the same per-organization rules. Queries on AWS wait for the eCW data to be connected (T:251), so they say "eCW data isn't connected" until then. Ask Meridian and PDF stay off on AWS for now.
### Every run input is kept (2026-10-16)

- **Every input of every process run is saved for good** — the exchange rate you type, the rate the Mexico payroll file actually used (or the 17.38 default when the file had none), the period and days read from the file, the file's fingerprint, and the US payroll "just this run" roster changes. Nothing in this history can be edited or deleted
- **Exchange-rate history** — one place lists the rate each Mexico payroll run booked with. At cutover, past runs are copied in and older rates are worked out from the payroll totals

### Sign-in code once every 30 days (2026-10-15)

- **The authenticator code is asked once per browser every 30 days**, not at every sign-in. Your password is still always needed. A different browser, a private window or cleared cookies ask once more. Needs the auth and compute stacks deployed (ADR 0052).

### Processes page redesign (2026-10-12)

- **One grid of equal tiles** instead of a section per category: no more half-empty rows. Pinned processes come first; each tile carries its category tag and colour.
- **"Sidebar pins 2 / 3"** shows how many pins are used; pinned stars are brand blue, and the rest grey out when every slot is taken.
- **The whole tile opens the process**, and a booked last run is quiet text, so a run waiting on you stands out.
### main v1.3.6–v1.3.8 on the AWS port (2026-10-12)

- **Operations (beta) is served by FastAPI** (`/api/v2/operations/kpis`, `/claims`, `/portfolio`) with the same one-org gate, validation and aggregate-only answers; the sidebar shows it in the top section to whoever may open the P&L.
- **On the new database Operations says "eCW data isn't connected on this server yet"** instead of reading the eClinicalWorks snapshot. That snapshot holds patient-level rows and lives outside RDS, so it waits for an audited read and a home on AWS (T:251).
- The Recharts chart kit from main sits beside the dashboard's own charts; the MX named-JE fix (v1.3.8) was already here.

### main v1.1.0–v1.3.5 on the AWS port (2026-10-12)

- **Everything main shipped through v1.3.5 now works on both databases.** US payroll people, MX payroll accounts and Payroll DB (beta) are served by the FastAPI routers and read and write RDS as well as Supabase; a run's ADP codes are stored on either.
- **Payroll DB (beta) on the new database shows Mexico only for now.** USA lines are read back from review workbooks that sit in the PHI bucket, and there is no audited server-side read of those yet; the screen says so.
- **The sidebar's Payroll DB link** sits in the top section, for whoever sees MX payroll results.

### Dashboards by role (2026-10-02)

- **A starter board for each kind of person.** Someone who never customised gets the board for what they can do: admins (and anyone who runs revenue and a payroll) get the controller board; otherwise each process they run adds its own; someone who can only see results gets a read-only board. Every board reads top to bottom: act now, is this normal, where is it coming from, look back.
- **Preview before you add.** Customise → Add a widget shows the library on the left and the chosen widget drawn with your own data on the right, with Square / Wide, then **Add to my board**.
- **Like with like.** Revenue and payroll are no longer stacked together: Money in, Money out, and Payroll as a % of revenue. Payer mix counts only Medicaid, Medicare, private insurance and self pay (Unposted has its own widget). USA gates show each gate's miss as a % of what it expected. Processes are compared with their own past, never with each other.
- **New widgets:** close progress, days to close (with the on-time streak), a close heatmap, re-runs, headline numbers with last period and last year (revenue, billing rows, $ per row, self-pay share, payroll, MX, USA, accrual share, clinic cost), location small multiples and change vs last period, payer mix by location, unposted revenue, mapping fixes per run, gates that tied out, gates declared, regular pay vs accrual, driver coverage, direct vs pooled cost, biggest cost changes, cost per provider FTE.
- **Read-only viewers get the charts.** Charts need permission to see results; only things you act on need permission to run.
- **Retired:** Booked by period by process, Runs by state, Average time to finish, Gate variance over time. A board that has one keeps it, with a note saying why it was retired.

### Dashboard charts: a library of 37 widgets (2026-10-01)

- **The dashboard has charts.** Customise → **Add a widget** opens a searchable library grouped by Overview, QB Revenue, QB MX Payroll, QB USA Payroll and P&L, each entry showing the kind of chart it draws.
- **New widgets:** period countdown ring; runs this period by process; runs by state; runs per period; average time to finish; runs by person; booked by period stacked by process; revenue trend, payer mix, by location, by clinic group, by department, payer mix over time, unmapped items in the last run; MX payroll cost trend and cost by department, location and expense account; USA payroll total trend, entries by kind, gates expected vs actual, gate variance over time; P&L cost by account, clinic and department, provider FTEs by clinic, cost trend.
- **Every chart has hover tooltips and a Table button** showing the same numbers as text. Charts show totals only — never a patient, an employee, or a provider's own pay.
- **A new dashboard starts with charts on it**; a layout you already saved stays as you left it.
- API: `GET /api/v2/dashboard/widgets/{id}` returns one widget's numbers (`series` + `points`); 403 when that widget's process is not open to you.

### Dashboard widgets, and three sidebar pins (2026-10-01)

- **The dashboard is a board of widgets.** Each one is a square (one column) or wide (two) tile. **Customise dashboard** lets you drag tiles into a new order (or use the keyboard on the handle: Space, arrows, Space), switch a tile between square and wide, remove it, and add one from the list. Save keeps it for your sign-in on every device; Cancel throws the edit away.
- **Widgets:** This period, Needs attention, the close checklist, Booked by period, Recent runs, Start a run, and four small ones: QB Revenue's last run and its blockers, QB MX Payroll's last booking and its journal count, QB USA Payroll's gates (how many are off, how many declared), and the P&L's cost upload for this period. A widget for a process you cannot open is not offered.
- **Your old layout carries over:** sections you had hidden stay off, in your order.
- **The sidebar pins at most 3 processes.** With nothing pinned, it shows the first 3 you can open. **P&L by Provider pins like a process**, so until it is pinned it lives on **All processes**.
- **All processes is tiles:** pinned processes are wide tiles at the top of their group, the rest are square, each with its last run, Open, and the pin star.
- API: `PUT /api/v2/me/dashboard-preferences` takes `widgets` (`id` + `square`|`wide`); `GET /api/v2/dashboard` adds `processes[].last_counts` and `pnl_cost`. Alembic `0036` lowers the pin limit to 3 and keeps the first 3 of any longer list.

### Superadmins see every screen again (2026-10-01)

- **A superadmin in their own organization sees every process in the sidebar, P&L by Provider included**, whether or not the organization has switched that module on. The server already granted them everything, but told the app only the organization's own modules, so anything switched off stayed hidden. A "View as role" preview and a support session still show only what that role, or that organization's admin, would see.

### AWS: spend approved, a "write" sign-in role (2026-10-01)

- **The AWS cost estimate is approved** (≈ $239/month steady state) together with the health canary for production only (≈ +$10.40). Alerts go to billing@meridiansgrp.com. The Phase 6 and Phase 8 alarm costs (≈ +$7) are still waiting, because with them the bill goes over the ~$250 ceiling.
- **A third AWS sign-in role, `meridian-shared-sso-write`**: it can build and change resources but cannot manage users or permissions (AWS PowerUserAccess). It goes to the user passed as `-c ssoWritePrincipalId`, next to the existing admin and read-only roles.
- **Security Hub stays off for now** (`-c enableSecurityHub=false`), saving about $5-20/month until SOC 2 work starts. Audit logging, threat detection and the HIPAA rules checker stay on.

### Review is its own page: "Waiting on you" (2026-09-30)

- **Review in the sidebar opens `/review`, titled "Waiting on you"**, instead of the run history with two filter chips. It lists the runs that need your answer or are blocked, newest first, for the processes you can see: process, period, what it is waiting on (the step, or the error code with a plain sentence), who started it, and a **Continue** or **Fix** button that opens the run at the right step. Test-mode runs are left out, as in Runs.
- **Nothing waiting** now says so: "Nothing is waiting on you. Runs that need an answer or are blocked show up here." with a link to Runs.
- **The sidebar lights Review on that page, not Runs**, and shows a count beside Review when runs are waiting (a dot on the collapsed sidebar); no count at 0. The phone's tab bar goes to the same page.
- **The dashboard's "cannot book" and "waiting on you" buttons open this page.** `/runs?state=needs_input,blocked` still works as a filtered run history.
- API: `GET /api/v2/runs/attention-count` (the badge's count, same permission, organization and Test-mode rules as `GET /api/v2/runs`), and each row of `GET /api/v2/runs` now carries `blocked_code` for a blocked run.

### Superadmins can work inside any organization — visibly (2026-09-30)

- **Support mode.** In the Superadmin console (now linked from the sidebar, ADMIN & SETTINGS, for superadmins), **Enter org** asks for a reason (10-500 characters) and lets a Meridians superadmin act as that organization's **admin** for up to two hours, without becoming a member. A red bar on every screen says `Support mode: <Org> — <reason> — ends in 1h 42m` with **Exit**. Needs a sign-in with two-factor authentication; refused during "View as role".
- **Everything is recorded.** One audit row per request with the reason, plus start / end / expiry rows. **Patient-level data stays closed** unless the session was started (or upgraded) with PHI access and its own reason; the bar then shows a PHI badge.
- **The organization can see it:** Settings → Security → **Meridians support access** lists who entered, when, why, whether patient data was opened, and for how long (admins only; only their own organization).
- **Console:** create an organization (you are not made a member — enter it to invite its first admin); each organization has its own page with its members **by name**, modules, run history and support log; a **Superadmins** page where adding or removing a superadmin needs a **second superadmin's approval** (a development laptop applies your own request at once). With only one superadmin, `scripts/add_superadmin.py` is the audited way to add the second (`docs/runbooks/support-access.md`).
- **Org switcher:** someone in more than one organization picks which one to work in from the sidebar footer; the server only ever accepts one of their own organizations.
- **Sidebar:** the processes show their original icons again (QB Revenue, MX Payroll, QB USA Payroll, P&L), grey like the other icons, instead of the colour dots.
- **Test mode banner:** when only stand-in figures are on (Test mode itself off), it no longer says "Test mode is on"; a small line says "Stand-in figures are shown for data that isn't connected yet."
- Database: Alembic `0035_superadmin_control` (support sessions, org selection, superadmin change requests and their audit tables). ADR 0051.

### You only see the processes you can use (2026-09-30)

- **The sidebar, the dashboard, the Processes page, the Runs filters and the help pages show a process only if your organization has it switched on AND your role lets you open it.** A Member no longer sees QB MX Payroll, QB USA Payroll or P&L by Provider. (This replaces the old "show everything the organization owns, so people know who to ask".)
- **The sidebar has three sections**: Dashboard, Runs and Review at the top; **Processes** (your pinned processes, or every process you can open when nothing is pinned, each with its colour dot, then "All processes"); **Admin & settings** (Mappings with configuration access, API platform for admins where it is on, Settings). An empty section is not shown. Collapsed, the sections keep their dividers.
- **Opening a process you cannot use by its address** (for example `/processes/qb-usa-payroll/new` or `/pnl-provider`) now shows "You don't have access to QB USA Payroll. Ask an administrator of Stella Mattina Health to grant it." instead of a wizard that fails at every step; a process your organization does not have says so.
- **Runs**: a role that can see a process's results but not start it sees its runs and no "Start a run" button. On the all-processes view, "Start a run" opens the Processes page (it used to lead to a missing page).
- **P&L by Provider follows its own switches.** It used to come with Configuration, for organizations and roles alike, so everyone with Configuration saw it. It now needs its own module and its own role permission, like every other process. Stella Mattina has no P&L module today, so nobody there sees it until a superadmin turns it on and roles are granted it.
- **Local development:** after "Reset" in Sign in as, or signing out, the local user is the seeded dev superadmin again (`dev@localhost`), as before Sign in as existed.

### Local sandboxes: a branch with its own copy of the live configuration (2026-09-30, local development only)

- **`scripts/sandbox.sh new <name>`** makes a git branch and worktree, its own database copied from a snapshot of the live configuration (`sandbox.sh golden`, a read-only pull), and an env file outside the repo. `start`/`stop`, `list`, `refresh` (fresh copy) and `drop` (asks first; keeps uncommitted work and unmerged branches) manage it. Anything saved stays in that sandbox.
- **Local only, enforced.** A sandbox cannot post to QuickBooks, send e-mail or webhooks, or write to S3; every organization in it is in Test mode; it refuses to start if any database or service address is not this machine. `--phi` does the same with patient data, on the PHI drive only.
- **QuickBooks posting switch.** `MERIDIAN_QBO_POSTING=off` refuses every journal create before anything is sent.
- `scripts/pull_live_data.py --target-db` loads another local database; `scripts/local_db_bootstrap.sh` honours `MERIDIAN_LOCAL_ENV_FILE`; `scripts/serve_api.sh` honours `MERIDIAN_HOST`.

### Live pull and local seed agree; Sign in as lists every local user (2026-09-30, local development only)

- **The pull and the seed no longer undo each other.** A pulled organization keeps its live name, modules, roles and mappings; the seed only adds its test users to it, on the live roles of the same name. Running either script again, in any order, changes nothing.
- **"Sign in as" lists every local user**, including the pull's one-per-role users, grouped by organization and labelled from the database ("Payroll — Stella Mattina Health"). Any of them can be chosen.
- **The pull copies every live P&L configuration.** A retired configuration with the same name as the active one used to be refused; it is now copied (the schema already matched live).
### Processes catalogue and sidebar pins (2026-09-30)

- **New Processes page (`/processes`, linked from the sidebar)**: every process your organization has and you may open, grouped into Revenue, Payroll and Other, with search, a category filter, the last run, Open, and a star to pin it. A process added later appears here by itself.
- **The sidebar shows only pinned processes** (up to 6) plus the Processes link. An org admin sets the organization's default on the Processes page; anyone can star their own instead, and "Reset to organization default" goes back. Processes you cannot open are never shown. **With nothing pinned the sidebar is exactly as before** (every process), plus the Processes link — so nothing changes until someone pins.
- **Stored in Postgres on AWS** (Alembic `0034_process_pins`, org-scoped with row-level security) and in the organization's settings on Render (no Supabase migration). Org default changes are logged (`process_pins_change`).
- **Every process now declares a category and a one-line description** in its manifest; the conformance suite and `scripts/new_process.py` (`--category`, `--description`) enforce it.

### Pull live data onto the laptop to test (2026-09-30)

- **`scripts/pull_live_data.py` copies the live organizations' configuration into the local database** (organizations, roles, permissions, modules, every mapping table), read-only against live, keeping the live organization ids. Secrets in settings (tokens, ACH, keys) and e-mails are removed, and no real person is copied: each (organization, membership type, role) becomes one synthetic user such as "Payroll (Stella Mattina Health)".
- **`--full` also copies employee rosters and patient data, but only into a separate database on the encrypted PHI drive** (`/Volumes/MeridianPHI/Meridian/local-pg`); it refuses to run when that drive is not mounted, and logs every pull (counts only) on the drive.
- **Every pull ends with a live-vs-local check per table** (row count and checksum, `OK`/`DIFF`); `--dry-run` shows the counts and the schema differences without writing anything.
### Preview Meridian on the Mac as each kind of user (2026-09-30, local development only)

- **The local login page has "Sign in as (local test users)"**: pick an admin, a non-superadmin admin, a Payroll, Revenue or Member user, the second clinic's admin, or someone in no organization, and the app answers exactly as it would for that person — same screens, same refusals. A bar at the top names the test user and has a Switch button; signing out goes back to the list. None of this exists on Render, staging or production.
- **The local "Local Dev" organization now has production's shape**: the modules and the Member, Payroll and Revenue roles live Stella Mattina has, with the same permissions. The made-up "Administrator" and "Clerk" roles are gone; re-running the seed cleans them out of an existing local database.

### Web addresses: www / app / api (2026-09-29, ADR 0050 — built, not deployed)

- **On AWS, `www.meridiansgrp.com` becomes the public website only**; any app page asked for there (like `/login`) moves to the same page on **`app.meridiansgrp.com`**, where Meridian now lives. The bare domain goes to `www`.
- **The partner API gets its own address, `https://api.meridiansgrp.com/v3/...`**; anything else on that address is "not found". The OpenAPI document now lists it as the server.
- **Staging is `staging-app.meridiansgrp.com` and `staging-api.meridiansgrp.com`** (the old `staging.` name is gone); staging shows the marketing pages on `staging-app`.
- **E-mail links, the sign-in callback and the QuickBooks connect callback are built from `PUBLIC_APP_URL`**; Render still uses `https://www.meridiansgrp.com`, so nothing changes there until the cutover.
- **The marketing site's "Go to Portal" buttons link straight to the app** when the two addresses are split; on a laptop and on Render they work as before.

### Repository tidy-up (2026-09-29)

- **Eight Jinja templates nothing rendered are deleted** (`home`, `index`, `results`, `processing`, `landing`, `base`, `components/_data_table`, `components/_modal`); every template with a caller stays until Phase 11.
- **Four finished one-off scripts are deleted**: `migrate_sqlite_to_supabase.py`, `backfill_config_mappings.py`, `move_client_data_out.py`, `gen_migration_017.py`.
- **Docs tidied**: unused diagrams, mock pages and superseded notes deleted; the old UI design note merged into `web/DESIGN.md` §8; process explainers now in `docs/processes/`, plans in `docs/plans/`.
- **Wearbly's code is gone from Meridian** (tracker T:105, retired); its five `uniform_*` tables stay until Andres approves dropping them (T:245).
- **The invoice and service-agreement builders moved out of the repo** to Meridians Logic's own tools (`ml-build-invoice`, `ml-build-agreement`); the app never used them.
- **`MERIDIAN_SQLITE_PATH` sets where the legacy CLI's SQLite file lives**; unset, it is still `data/revenue.db`.
- **Nothing generated lands in the checkout's `output/` any more**: `scripts/build_docs.py` needs `--out` for the engineering guide, and the QB USA workbook and two tests no longer create an empty `output/journal_entries/` when they only build rows.

### See the product as a role would

- **"View as this role" (Settings → Roles) shows an admin exactly what a role can see and do**, enforced by the server on every request until you press Exit in the banner (or two hours pass); it can only take access away, and starting or stopping it is audited.
- **"Compare roles" (Settings → Roles) lays every role side by side**, area by area, with what each one can use and whose results it can see, and a "View as" button per role.

### Test the partner API on a laptop with a real token

- **`scripts/local_api_partner.sh` lets you call `/api/v3` on your Mac the way a partner would.**
  It starts a second local API on :5051 that checks tokens for real (against a laptop-only
  signing key, since there is no Cognito locally), mints a one-hour token for an approved API
  client, and prints ready-to-paste `curl` commands. `--stop` stops it; development only.
- **It now logs in with the client's real secret, like a partner does.** The secret the admin
  screen shows is remembered on the laptop (as a salted hash, never the secret itself) and the
  :5051 API answers `POST /oauth2/token` the way Cognito does. Put the secret in `.env` as
  `meridiasn_test_api` (`--secret-env` for another name); `--whoami` lists which `/api/v3` calls
  the token can make; `--mint` keeps the old secret-free shortcut. Restart the :5050 API after
  re-running `scripts/local_db_bootstrap.sh`, then rotate the client's secret once.

### Invoice screen removed

- **The Invoices screen is gone from the app.** It raised Meridians Logic's own invoices and had
  nothing to do with the accounting processes. Invoices are built with
  `scripts/build_meridians_invoices.py`, as before; the database drops the empty invoice tables.
### Test mode, per organization, that keeps test runs out of the books

- **Every run made while an organization's Test mode is on is a TEST run, for good.** The flag is
  set when the run is created; turning Test mode off later does not change it.
- **A TEST run is never sent to QuickBooks.** "Send to QuickBooks" answers that test runs are never
  posted (`TEST_RUN_NOT_POSTED`), before QuickBooks is contacted.
- **A TEST run sends no completion email and no webhook event** to any subscriber.
- **A TEST run never becomes the period's booking.** It does not replace a real run of the period,
  a real run is never replaced by it, and a test run of a file already booked for real is refused
  instead of retiring that booking. Its batch is left out of totals, as before.
- **Run history hides TEST runs** unless "Show test runs" is ticked; a TEST run carries a TEST tag
  in the history and on its own screens. The dashboard's counts, close checklist and trend leave
  them out.
- **A TEST run's downloads are named `TEST_<file>`.** The files' contents are unchanged.
- **The Test mode banner says what it does:** "Test mode is on — runs are tagged TEST, nothing is
  posted to QuickBooks or emailed." The Settings card no longer claims runs read a fixed file, and
  its two unused file-path fields are gone.
- The API: runs carry `is_test` (v2 and v3); the run lists take `include_test=true`.

### Concurrency fixes from the Codex review

- **A QuickBooks journal can no longer be posted twice after a long pause.** When an attempt to
  send a journal failed and then stalled for more than ten minutes before recording the failure,
  it could mark as failed a send that another attempt had meanwhile started, and a third attempt
  would then post the journal again. A failure is now recorded only by the attempt that still
  holds the journal (CODEX-1).
- **Cancelling or finishing a run no longer erases what the worker just wrote.** A run moved to a
  final state at the same moment the worker saved progress used to lose the worker's update; the
  two are now combined (CODEX-2).
- **Two runs of the same period finishing at the same time leave exactly one current booking.**
  Before, each could mark the other as replaced, leaving none. Now the newest run of the period
  always stays and the older one points at it (CODEX-3).

### Stage 2 pass 2 fixes: clinic groups fixable in the app, clearer stops, limits of 1 per 30 s

- **A revenue run stopped because a clinic group is incomplete can now be fixed in the app.**
  The stopped run lists which groups are missing which field (for example "Fallback location:
  Forest") and links straight to Mappings → Clinic groups, where a group's locations, fallback
  location, hospital journal file and bank account key can now be edited. It no longer says
  "Everything is mapped" while nothing can run. New database only (S2P2-N1).
- **A run stopped for missing QuickBooks mappings names each table in words** ("QuickBooks
  accounts", "QuickBooks classes", …) instead of "Qb account map", in English and Spanish
  (S2P2-N6).
- **Partner API limits of one every 30 seconds** (Andres's decision): a webhook test ping and a
  webhook redrive are limited to one per subscription every 30 seconds, and starting a job
  through the partner API to one per organization and process every 30 seconds. A refused call
  gets `429` and a `Retry-After` saying how many seconds to wait. The existing hourly and
  per-delivery limits stay (ANDRES-LIMITS).
- **Webhooks: each subscription now gets its own event id.** A receiver that serves two
  subscriptions no longer rejects the second copy of an event as a replay. The id stays the same
  on every retry and redrive; to act once per run, use the run id and event type (S2P2-N7).
- **Mexico payroll's new-run page no longer promises a review step it does not have** (S2P2-N2).
- **A US payroll run stopped for an empty roster says so in words**, explains how the roster is
  loaded, and links to help, instead of "The run stopped with ROSTER_EMPTY" (S2P2-N3).
- **A replaced run's tie-out says it was replaced and links to the run that replaced it**,
  instead of "Tie-out pending. Nothing has been computed yet" (S2P2-N8).
- For developers: logs name the database actually used (Postgres or Supabase) (S2P2-N4), and
  starting the api no longer creates an empty `output/` folder in the code folder (S2P2-N5).
### Every process stops with an error code and can be run again

- **Mexico payroll and US payroll now pause instead of failing when the fix is on your side.**
  Missing or unreadable QuickBooks mappings, an empty or unreadable MX column map, an empty US
  payroll employee roster, or US benefit overrides the database could not read: the run stops
  with nothing booked, says why (with an error code), and shows a **Run it again** button, the
  same screen QB Revenue already had. Running it again reuses the file(s) you uploaded; you do
  not upload anything again. A file that cannot be read, or an internal error, still fails as
  before.
- US payroll's "Run it again" reads the period again and takes you back to the roster review or
  the preview. It never books by itself: booking is still the Book button.
- English and Spanish.

### Stage 2 local test fixes: webhooks in scope, local downloads, loud Cognito gaps

- **Security (partner API): a webhook now tells a client only about runs it may read.** A
  client allowed only QB Revenue no longer receives run events for Mexico payroll runs; a client
  whose allowed processes are narrowed later stops hearing about the others at the next retry
  (S2-F7).
- **On a laptop with `STORAGE_BACKEND=local`, run files are stored and downloadable.** Revenue and
  Mexico payroll results are kept under `$MERIDIAN_DATA_DIR/storage/`, "Download" and "Download
  everything" work through a short-lived local link, US payroll "Book" no longer answers 503, and
  the results screen no longer mentions Supabase (S2-F5). Nothing changes on Render or AWS.
- **The local seed includes a made-up US payroll roster and its overrides**, so a US payroll run
  works on a fresh laptop. An empty roster now says `ROSTER_EMPTY` instead of "the file could not
  be processed" (S2-F4).
- **Approving a machine client on a laptop without Cognito is a clear 503, not "something went
  wrong"**; development without a Cognito pool uses the built-in stand-in (S2-F6).
- **`AUTH_BACKEND=cognito` with a Cognito setting missing now refuses to start**, in development
  too. It used to quietly let everyone in as the developer. Use `AUTH_BACKEND=disabled` for that
  (S2-F13).
- **New database only:** a month with no US payroll benefit overrides is read as "none", never
  from a local file, and the warning names the database it asked (S2-F12).
- For developers: the "mappings.xlsx missing" warning prints once, not 35 times (S2-F11); the test
  suite no longer leaves an empty `output/` batch folder in the working tree (S2-F15).
### A run whose start was cut off is sent to the worker again

- **New database only (not Render): if the server stopped in the split second after marking a run
  "queued" but before handing it to the worker queue, the run is now sent again within about five
  minutes.** Before, on the AWS worker queue, nobody ever sent it: the run stayed on the
  processing screen and every new attempt was refused until someone cancelled it. The resend
  carries the same job, so a copy that did arrive runs only once; it is tried at most three times
  in all, by one server at a time.

### A re-run that fails keeps the month's earlier booking

- **Re-running the same revenue or Mexico payroll file for a month that was already booked, when
  the re-run then fails, now leaves the earlier booking in place.** Before, the failed re-run's
  record blocked the earlier booking from coming back, so the month showed no booking at all
  (revenue on the new database and on Render; Mexico payroll left a stuck "processing" record).
  The failed re-run is now set aside first, then the earlier booking is put back, in one step on
  the new database.
### Stage 2 local test fixes: JE dates, `npm run dev`, and screens that say what happened

- **Changes on Render today: leaving "Journal entry date" empty on a revenue run now uses the
  period end date.** The React form sent an empty date and every journal entry was booked with
  a blank date. The form, the API and the processor now all treat an empty date as "use the
  fiscal calendar".
- **`npm run dev` works again** (every page answered 500). A new check boots the dev server in
  CI and asks for pages, so this cannot come back unnoticed.
- **The revenue results screen shows the "this file was already run" warning**, like QB USA.
- **MX payroll: the exchange rate is only asked for a raw peso export.** A processed workbook is
  already in dollars and never used the rate; the screen no longer requires one or says every
  amount is divided by it.
- **The processing steps follow revenue and MX runs** instead of sitting on "Validating".
- **Copy:** MX no longer asks you to "choose the period first"; a QB USA run waiting for roster
  answers shows "Pending", not "Out of balance by zero dollars"; "Qb location" now reads
  "QuickBooks location".
### Stage 2 fix F3: unposted journal entries on the new database

- **New database only: the unposted journal entries now come from your clinic groups in the
  database**, not from `config/mappings.xlsx`. Before, the new stack had no such file, so every
  unposted entry was skipped while the run still said "Booked" and "Ties". Clinic groups now
  also hold the hospital file and the fallback location code (migration `0029`).
- **New database only: a run that asks for unposted entries stops before booking** when the
  clinic groups are missing or incomplete (`UNPOSTED_CONFIG_UNAVAILABLE`), and says which groups
  lack what. Nothing is booked; add them, then retry.
- **The results screen says what happened to the unposted entries** when you asked for them
  and got none: "not needed" (every group matches its bank deposit) or "not made" (no clinic
  groups, or the step failed). Render/Supabase still reads the workbook, as before.
- The local and sandbox seeds fill the clinic groups (example values), so a local run makes the
  same unposted files as the golden set, with no workbook in place.

### Stage 1 review, round 3: QuickBooks errors in our words, and runs that say exactly what they need

- **Changes on Render today: a failed "Send to QuickBooks" no longer shows QuickBooks' own
  error text.** That text could quote account and customer names. The message is now ours
  ("QuickBooks could not be reached. Nothing was sent…", "Class or location tracking is turned
  off…"), and each journal that did not post says why with a short code, the same as on the
  new database.
- **Adding the same QuickBooks mapping twice at the same moment now says "already exists"**
  instead of "could not be saved, try again".
- **A payer type with no revenue account now links to Mappings → Payers**, where it is fixed,
  instead of to the QuickBooks accounts table, where it cannot be.
- **The provider P&L says when your QuickBooks mappings are missing**, in your language, with a
  button to the QuickBooks mappings screen, instead of showing a dash that looked like "no data".
- **New database only:** the revenue run's check before booking now asks for exactly the
  unposted lines the run will write — a month with nothing unposted no longer needs the
  unposted account mapped. If the unposted QuickBooks file still cannot be written after the
  booking, the booking is taken back and the run says why (paused for a missing mapping, or
  failed), never "complete" without it.
- **New database only:** a NetSuite-only Mexico payroll run says whether it needed the QuickBooks
  mappings at all ("not needed"), or that it had none to translate QuickBooks class names with.
- **New database only:** the US payroll benefit overrides are refused, not replaced by a local
  file, when there is no organization or database to read them from.
- For developers: `QB_MAPPINGS_UNAVAILABLE` is defined once (`src/qb_mappings.py`); a failed
  qb-usa parse carries its error code on the error itself, not in its wording.

### A screen to enter your QuickBooks mappings, and a clear message when a run is missing them (critic R2-M4)

- **Nothing changes for anyone using Meridian today on Render.** On the new database a run
  whose organization has no QuickBooks mappings of its own stops before anything is booked;
  until now there was no screen to add them.
- **New screen: Mappings → QuickBooks mappings** (`/config/quickbooks`). Accounts, classes,
  clinics, catch-all codes, payer labels and payroll locations: list, add, edit, deactivate
  and delete, in English and Spanish. A **Preview** button shows what the next revenue and
  payroll run will be coded from and marks what is missing. Provider codes stay where they
  were, beside each provider on Mappings.
- **A blocked revenue run no longer contradicts itself.** It used to say "Every unmapped item
  has a mapping now" under a notice saying the organization had no mappings. It now says what
  is missing, in your language, with a link straight to the table that fixes it, and "Run it
  again" once you have added them. A Mexico payroll run refused the same way says the same.
- **The results screen says where the QuickBooks lines came from**: a quiet "Coded from your
  QuickBooks mappings", or a warning when the built-in defaults were used.
- **Fixed: deleting a mapping could never be confirmed.** The confirm closed the edit window
  behind it, which took the confirm with it. Deactivating was unaffected.
- For developers: `/api/v2/config/qb-accounts` (and the five other kinds) — GET, POST, PATCH,
  DELETE, `config:access`, the same service `/api/v3/mappings/qb-*` uses; each write logs a
  `qb_mapping_change` event. On Supabase the answer is 503 with `details.reason: "backend"`.
### QuickBooks runs on the new database refuse maps that do not cover the file

- **Nothing changes for anyone using Meridian today.** This is the AWS (Postgres) path, which is not live yet; the current system behaves exactly as before.
- **One missing QuickBooks mapping now stops the run before anything is booked.** Before, an organization whose QuickBooks mappings existed but lacked one row (one account, clinic, class, payer label or "Other" provider code) got a finished run whose QuickBooks file quietly carried the raw NetSuite value instead. The revenue run now checks the whole file against the organization's mappings before it saves anything, pauses, and lists exactly which items are missing; add them and press retry. The Mexico payroll run does the same check and fails with the list (run the file again once they are added).
- **A QuickBooks export problem is never hidden any more.** The Mexico payroll run used to log a QuickBooks export failure and still say "complete". On the new database it now fails the run.
- **Other places that silently used built-in defaults now refuse instead:** the Mexico payroll column map for raw files, the provider P&L roster and preview, and the US payroll benefit overrides when the database could not be read.
- The local test organizations gain the two rows the sample files needed (a "Selfpay" payer label and the Mexico payroll column map), so their output is unchanged.
### Stage 1 review, round 2: safer logs everywhere, bounded webhook tests, no false "still sending", tests in random order

- **Logs are cleaned of secrets on every server, Render included.** The filter that strips
  passwords, tokens and personal details from log lines used to switch on only together with the
  new JSON log format, so Render (which keeps its plain-text format) would have had none after
  the merge. Now the filter, and the switch-off of the web server's raw access line (which
  carries full URLs), are always on; only the JSON format stays optional (`MERIDIAN_JSON_LOGS`).
- **A QuickBooks journal that was never sent is no longer shown as "still being sent" for ten
  minutes.** If Meridian could not reach QuickBooks even to check whether a journal was already
  there, pressing Push again was refused for ten minutes. Now it goes through at once, with the
  same QuickBooks request id, so it still cannot post twice. And a journal QuickBooks confirmed is
  reported as posted even if another attempt had already given up on it.
- **Partner webhooks:** the "send a test" button is limited to 10 an hour per subscription and 60
  an hour per organization, like re-sending already was; a re-sent delivery is no longer queued
  a second time by the clean-up sweep. The background worker now refuses to start on AWS if its
  webhook settings are missing, instead of quietly doing nothing.
- **Tests run in a random order in CI** (a small built-in shuffle, no new package), once per push
  for the database tests. It already found and fixed one test that only passed when another had
  run first.
- Smaller fixes: temporary copies of uploaded files left by a crashed server are cleaned up at
  start and by the regular clean-up job; a partner API client can no longer list "every address" as its
  allowed network; a file link inside the laptop file store is never followed; the laptop webhook
  sender starts and stops with the server however it is launched; database revision `0028` gives
  the future audit export (Stage 3) its own permission to record how far it has exported.

### Stage 1 review fixes: tests that no longer depend on their order, a double-execute race, and worker tidy-ups

- **Nothing changes for anyone using Meridian today.** All of this is on the AWS path, which is
  not live yet.
- **The database tests pass in any order.** One test counted a job another test file had left
  behind, so the suite went red whenever the files ran in a different order. Each recovery test
  now starts from a clean slate and only counts its own jobs. Running the database test files
  forward, reversed and in three random orders gives zero failures each time.
- **A golden-file test only passed on the day it was written.** The revenue workbook's calendar
  sheet lists every day from 2020 to 2036, today included, and the comparison treated "today" as
  the time stamp. It now treats only real time stamps that way.
- **Pressing "execute" twice at the same moment could fail a good run.** On the partner API
  (`/api/v3`), two execute requests on the same draft each prepared the uploaded file in the
  same temporary folder, and whichever finished first deleted the other's copy. The second one
  then answered an error, and in some timings marked the run as failed after the first had
  already started it. Each request now uses its own folder, and a late refusal never fails a run
  another request already started. A two-thread test proves it.
- **Cancelling a run while its file is being read now stops that job cleanly.** The job's hold
  on the run is released at once and it cannot record anything more on the cancelled run.
- **A job queued in the same microsecond it was picked up no longer waits 15 minutes.**
  (Database revision `0026`.) The same revision adds an index for the clean-up job that expires
  abandoned drafts, and corrects a database comment.
- **The QuickBooks-token safety check on a database downgrade now really runs.** It could not
  see any rows before, so it never fired (the downgrade failed anyway, for another reason).
- **USA payroll jobs re-check every uploaded file** is a real ADP or carrier file before using
  it, as revenue and Mexico payroll already did.
- **The laptop file store keeps each organization's files apart** and refuses any path outside
  that organization's folder, like the cloud store does.
- A local-only plugin file is ignored on any deployed server; the attempt limit (3), written in
  seven places, is now checked to be the same everywhere; the CSV type check's real reach is
  written down and pinned by a test.
### QuickBooks Mexico payroll runs on the new database no longer fall back to built-in account codes (critic H-1, payroll)

- **Nothing changes on Render/Supabase.** This is the new-database (AWS) side only.
- On the AWS database, a QB MX Payroll run whose organization has no QuickBooks payroll mappings (payroll accounts and classes) — or whose mappings cannot be read at that moment — now stops with `QB_MAPPINGS_UNAVAILABLE` before the file is read or anything is booked, and says what to do (add the mappings, or run the file again in a moment). It used to carry on silently with the account and class codes built into the code. This process has no "fix and retry" pause, so the run shows as failed and the file is simply run again.
- Every QB MX Payroll run now says where its QuickBooks lines were coded from (`qb_maps_source`), like QB Revenue runs.
- The local and sandbox seeds now fill the QuickBooks payroll mappings too (synthetic rows), so local payroll runs are coded from the database and still match the golden journal entries byte for byte.
- QB USA Payroll is not affected: its account paths are fixed in code by design and it does not read these mapping tables.

### The QuickBooks mapping tables can now be filled through the API (critic H-1 follow-up)

- **Nothing changes on Render/Supabase.** This is the new-database (AWS) side only.
- Six new mapping kinds on `/api/v3/mappings/{kind}`: `qb-accounts`, `qb-departments` (QuickBooks classes), `qb-clinics`, `qb-other-codes`, `qb-payer-labels` and `qb-locations`. They list, add, edit and delete the QuickBooks mapping tables a QuickBooks revenue or payroll run is coded from, with the same permissions (`mappings:read` / `mappings:write`), the same "another organization's row is not found" rule and the same refusal of unknown fields as the other mapping kinds.
- The staging sandbox seed (`scripts/seed_sandbox_org.py`) now fills every one of those tables through the API, so a practice QuickBooks run in the Sandbox organization is coded from its own mappings instead of being stopped. The local seed writes the same rows through the same code.
- The generated API documents, TypeScript types and Python client include the new kinds.

### QuickBooks: one safe way to send, even when two sends overlap (Stage 1 review, H-3 and H-4)

- **Nothing changes on Render/Supabase.** This is the AWS (RDS) side only.
- **Every send to QuickBooks on the new database is written down first.** Before, pressing "Send to QuickBooks" on the new database only used the safety ledger when the push ran on the background worker; with the worker switched off (today's default) it skipped it. Now the send in the request uses the same ledger, so a repeated or retried send can never book an entry twice.
- **Two sends that overlap no longer both send the same entry.** If an earlier send of an entry started less than 10 minutes ago (it may still be at QuickBooks), the second send leaves that entry alone and says so ("another send of it started less than 10 minutes ago"); sending again after that is safe.
- **A background send stops as soon as it cannot prove it still owns the run** — when its heartbeat could not be saved, when its lease ran out, or when someone asked for a newer send — and is picked up again later instead of being marked failed.
- **Errors from QuickBooks are never shown word for word** on the new database: the screen gets a code and a plain sentence, because QuickBooks' own message can quote account or customer names.
### Webhooks on a laptop go out for real; bounded redrive; lost deliveries are found again (critic Stage 1 H-2, M-7, M-8)

- **Nothing changes for anyone using Meridian today.** This is the partner API (`/api/v3`), which
  is off on Render.
- **A deployed server can no longer run webhooks on stand-ins.** Outside development, the
  partner API now refuses to start unless the real queue, secret store and event bus are
  configured; before, it quietly used an in-memory queue nobody emptied and secrets that
  vanished on restart. On AWS the partner API is switched on by the same setting that builds
  those pieces, so one cannot be on without the other.
- **On a laptop, webhooks are delivered.** A test ping, a finished run or a retry now reaches
  the subscribed address: a background helper in the api sends them, and signing secrets are
  stored encrypted in the local database so they survive a restart. The local setup script
  creates the encryption key.
- **Re-sending a failed webhook is limited:** 3 times per delivery, only for events up to 7 days
  old, and at most 20 attempts per subscription per hour. Every attempt is in the audit log.
- **A webhook whose retry was lost is picked up again** by the 5-minute background sweep
  (database change `0025_webhook_delivery_sweep`), instead of waiting forever.
### QuickBooks revenue runs on the new database no longer fall back to built-in account codes (critic H-1)

- On the AWS database, a QB Revenue run whose organization has no QuickBooks revenue mappings — or whose mappings cannot be read at that moment — now stops as **blocked** with `QB_MAPPINGS_UNAVAILABLE` before anything is booked, and offers **Retry**. It used to carry on silently with the account and clinic codes built into the code. Supabase/Render runs are unchanged.
- Every QB Revenue run now says where its QuickBooks lines were coded from (`qb_maps_source`: `postgres`, `supabase` or `hardcoded`).
- The local seed (`scripts/seed_local_dev.py`) now fills the QuickBooks revenue mapping tables with synthetic rows, so local runs are coded from the database and still match the golden journal entries byte for byte; the sandbox seed posts the QuickBooks provider codes and names the tables it cannot fill.
### Security fixes from the Stage 1 review (critic round 1: mediums and lows)

- **Nothing changes on the live site (Render).** Every change below is on the new AWS/Postgres path,
  or is switched off there unless you opt in.
- **A database hiccup can no longer switch every module on.** If the list of modules an
  organization has cannot be read, the new platform now shows none for that request instead of
  all of them (the partner API always; the Supabase site keeps its old behaviour until it retires).
- **Sign-in lockout and API limits never switch themselves off.** If the counter store is down,
  a partner's sign-in is refused ("try again shortly") and the limits keep counting inside the
  server instead of disappearing.
- **A partner behind a shared office or cloud address is no longer locked out by someone else's
  bad sign-ins**, as long as their registered address list covers it.
- **Secrets fetched while the app runs are now hidden in logs too** (webhook signing secrets,
  QuickBooks tokens), and so is anything inside structured log details.
- **Approving your own API client is only allowed on a laptop now.** On staging and production a
  second superadmin must approve it.
- **One encryption method for stored secrets.** The half-finished sign-in store now uses the same
  standard AES-GCM helper as the QuickBooks tokens (anyone mid-sign-in during the switch just
  signs in again).
- **API call records have a retention rule:** kept 400 days in the database and removed only
  after they are safely copied to the locked audit archive (which is built with the AWS stage;
  until then nothing is removed).
- **QuickBooks will work on AWS:** the server settings for the QuickBooks app (its id, secret,
  environment and return address) are now part of the AWS setup, read from a secret you create
  once.
- **The new log format is opt-in for the live site** (`MERIDIAN_JSON_LOGS=1`), so merging this work
  does not change Render's logs by surprise.
- **Nine decision records written** (ADRs 0027, 0031, 0033, 0034, 0045-0049) for choices that had
  none; a stale tracker reference fixed.

### Tidy-up for the move to AWS: the open-items list, the guides and the compliance table (Phase 12 T28)

- **Nothing changes for anyone using Meridian.** This is paperwork and dead-code removal.
- **The migration tracker is drained.** Every row now starts with its ID and a status:
  closed (with its evidence), a duplicate merged into the row that carries the text, or open
  with the stage it waits on — local work, the AWS stage, or a decision from Andres. The
  count is at the bottom of `docs/migration-tracker.md`: 82 closed, 24 duplicates merged,
  96 open (5 local, 47 AWS, 38 waiting on Andres, 6 held for the port gate).
- **Five settings nothing reads any more are gone** from `render.yaml` and the README
  (`SUPABASE_JWT_SECRET` and the four Google/Microsoft client ids), plus one unused alias in
  `src/settings.py`; a new test fails if any of them comes back. They can also be deleted from
  the Render dashboard and from `.env.example` by hand.
- **The guides match the code again:** the README's "Running it" covers the job worker and
  the partner API (`/api/v3`); `scripts/README.md` lists every script; the repository map
  (`docs/architecture/repo-layout.md`) matches the files; `workers/`, `migrations/` and
  `lambda/` have a README of their own.
- **The compliance table is up to date** with what was built on 2026-09-24 — the security test
  suite, the security lint, the one-owner-per-URL check, the upload file-type and malware
  checks, sealed QuickBooks tokens, the webhook outbox, the double-press and double-post
  guards, and the structured logs — each marked "in code, not deployed yet".
- The decommission runbook no longer passes a setting that does nothing at that step.
- The database changes that must wait for the port-gate check (exact money amounts, time
  zones on timestamps, and three keys) are written and held on a separate branch,
  `hold/post-parity-schema`, until that check has run.

### Cleanup: no fake QuickBooks button, safer push redelivery, zip-bomb control, ruff S baselines gone

- **"Send to QuickBooks" only appears where it can work.** The results screen now asks the
  process list (`/api/v2/processes`, new `quickbooks_push` flag, true when the process
  declares a QuickBooks push job) instead of showing the button on every process. QB Revenue
  and MX Payroll have no push, so they no longer show a button that could only fail.
- **A QuickBooks send interrupted by a server restart now finishes by itself** (new database,
  background worker, not switched on yet): the next server picks the send up again, and the
  journal-entry ledger still makes a double post impossible.
- **A late duplicate of a run's processing message no longer raises an alarm.** The database now
  remembers which background jobs already finished a run (`settled_job_ids`, revision 0024), so a
  copy that arrives after the QuickBooks send is recognised and dropped quietly.
- **A send waiting in the queue says "queued", not "interrupted".** It shows as interrupted only
  after 20 minutes with no worker picking it up; pressing the button then starts a fresh send
  instead of answering "this run changed". Two presses at once start exactly one.
- **The zip-bomb test for stored uploads now proves the bomb check itself.** It used a file
  the type check also refused, so switching the bomb check off did not make it fail. It now
  uses a real workbook with one padded sheet, which only the bomb check can refuse; the
  security suite's "controls off" run (`--known-bad`) is red for every test.
- **The last per-file exceptions to the security lint (ruff `S`) are gone.** Nine silent
  `except: pass` blocks in the old Flask app now log what failed (the error type only); the
  upload fingerprint and a config label say their MD5 is not a security use; the dashboard
  queries no longer build SQL from a variable; the local Flask dev server listens on this
  computer only (`127.0.0.1`) instead of the whole network; the worker's type checks are
  real checks instead of `assert` (which Python can strip). Two SQL lines that build column
  names from a fixed list carry a one-line reason instead.
### Webhook re-publishing moves into the worker; QuickBooks tokens are encrypted (D17, ADR 0044)

- **The 5-minute job that re-sends missed webhook events now runs inside the always-on
  worker** instead of starting its own server every five minutes: a small "tick" message
  goes on the job queue and the worker does the same pass the manual command
  (`python -m workers.outbox_sweep`) does. About $6 a month per environment cheaper once
  AWS is live; nothing changes before then.
- **QuickBooks sign-in tokens are now encrypted by the app before they are stored** on the
  new database (AWS). A database copy or backup shows scrambled bytes, not a token that
  could post to someone's books. The key lives in AWS KMS (a key service); on a laptop a
  development key from `MERIDIAN_DEV_QBO_TOKEN_KEY` is used, and it is refused anywhere
  else. The database itself now refuses any unencrypted token. Tokens saved before this
  change keep working and are encrypted by a one-time command
  (`scripts/encrypt_qbo_tokens.py`). The old database (Supabase) is unchanged.

### Phase 11 E2 - sending a payroll run to QuickBooks can never post an entry twice (new database only, not switched on)

- **"Send to QuickBooks" becomes a background job** for QB USA Payroll when the background
  worker is switched on for it: the button answers at once, the page checks every two
  seconds until the send is over, and then says what happened, journal by journal.
- **Every journal entry is written down before it is sent**, so a send that is retried,
  delivered twice, or interrupted halfway (a timeout, a server restart) never puts the same
  entry into QuickBooks twice. If QuickBooks did not answer, the next try looks the entry up
  first and, if it is missing, resends it under the same QuickBooks request id; if
  QuickBooks refused it, the next try uses a new id.
- **A send that did not go through leaves the run booked** and shows which entries failed and
  why ("QuickBooks refused it", "QuickBooks did not answer", "tracking is turned off", …) in
  English and Spanish. Pressing the button again is safe.
- **The manual posting script (`scripts/qbo_post_je.py`) uses the same safeguard** on the
  new database and records the QuickBooks request id next to the entry it posted.
- Nothing changes on Render/Supabase or while the worker is off: the send still happens
  inside the request, as before.

### API v3: start and drive a run over the new API (Phase 12 T18, behind `MERIDIAN_API_V3`)

- **QB Revenue and MX Payroll runs can be started through `/api/v3`, with the endpoints
  built from each process's manifest** (no hand-written route per process): create a draft
  run (an `Idempotency-Key` is required, so a retried request never makes a second run),
  get a short-lived pre-signed upload straight to storage (the manifest's file types and
  size limit are written into it), then `execute` (again with a key: one booking, however
  many times it is sent), `retry` a blocked run, list the run's files and get a signed
  download link. Nothing is processed until the malware scan has marked the uploaded file
  clean; a file it did not clear fails the run. Patient-data files are listed and
  downloadable only with the `phi:read` scope, and each download is audited. QB USA
  Payroll is not on v3 yet (its roster review and gate declarations come with the React
  move). Off by default; nothing changes on Render.

### Quality gates and stale docs (local-first Stage 1D)

- **The code-format check is green again:** two test files that had drifted from the
  formatter's layout were reformatted (no test changed what it checks).
- **Every web address now has exactly one owner, checked on every build:** a new check
  (`scripts/lint_route_ownership.py`) fails if the new API (FastAPI) and the old Flask app
  both answer the same address, or if the web app's "send this to the old app" list names
  an address the new API already serves. Until now that rule was only a convention.
- **The database-dependent patient-data tests always run in CI now:** the PHI split and
  parity tests moved to the CI job that requires a database, where a missing database or
  a missing `psql` fails the build instead of quietly skipping the tests.
- **The public marketing pages use the design tokens:** their colours and shadows come
  from named tokens (`--mkt-*` in `tokens.css`) instead of raw hex values, so the
  "no raw colour" check now covers every page with no exceptions. Nothing looks different.
- **Tests for the old database (Supabase) are now kept apart from the rest:** seven test
  files that mixed both kinds were split, so the old-database tests sit together in
  `tests/legacy_supabase/` and can be deleted in one go when Supabase is retired. The
  same tests run; none was changed.
- **The security linter (ruff's bandit rules, `S`) is on for the Python code.** It found
  one real gap, now closed: the QuickBooks duplicate check put a date straight into a
  QuickBooks query, and now refuses anything that is not a plain `YYYY-MM-DD` date. The
  other findings were fixed (checks that `python -O` could silently skip are now always
  on; two PDF scripts escape their text like the web app does) or marked with a one-line
  reason where the code is safe. Files other work is changing right now are listed in
  `pyproject.toml` to be cleaned up with that work.
- **The paperwork caught up with the code.** The list of things only you can do now covers
  every phase report 0-8 (55 items, Phase 7's and Phase 8's included); a new status note
  (`docs/reports/status-2026-09-24.md`) says where the migration stands; outdated and
  duplicate rows in the migration tracker were closed or corrected; and two documents you
  sign now exist as drafts: the note explaining the one unencrypted network hop inside AWS
  (`docs/compliance/in-transit-encryption.md`, two facts to check first) and the custody
  form for the retained Supabase archive (`docs/compliance/evidence/`).

### Decision D18 - "Connect QuickBooks" moved into the app's Settings screen

- **Admins connect QuickBooks from Settings → QuickBooks.** The card shows whether the
  organization is connected, to which company, since when and by whom, and offers Connect,
  Reconnect and Disconnect (with a confirm), in English and Spanish. Before this the only way in
  was an old Flask page no screen linked to, which did not work on meridiansgrp.com at all.
- **Safer round trip to Intuit.** The one-time code that ties the Intuit sign-in back to the
  person who started it is now kept on the server, tied to that admin and that organization,
  and can be used only once; a link started by anyone else, reused, or tampered with is refused.
  Every connect and disconnect is recorded in the audit log. Disconnecting also asks Intuit to
  cancel the saved sign-in.
- **The old `/qbo/connect` and `/qbo/callback` Flask pages are gone.** Andres still has to add
  the new return address at Intuit and set the QuickBooks settings on the server before the
  first production connect (tracker row "Register the production QuickBooks redirect URI").

### Phase 11 H1/H2 - the background worker's cloud setup, written and switched off

- **The cloud side of the background worker is ready but not turned on.** One switch
  (`worker_enabled`, off) adds the job queue, a 15-minute clean-up timer, one always-on worker
  running the same code as the app, and five alerts (stuck or refused jobs, worker down,
  clean-up not running). With the switch off, nothing that would be deployed changes at all.
  Turning it on costs about $15 a month per environment and waits for Andres's approval.
- **Groundwork for partner notifications:** a 5-minute job that resends any run notification a
  hiccup left unsent is set up behind the (off) API-platform switch, and the background worker
  may publish those notifications when both switches are on. About $6 a month per environment
  once turned on. A scheduling setting that would have blocked app deploys once the API
  platform was on is fixed.
- **Fixed: the website container's log lines said "development" on AWS**, so the alert that
  counts website errors could never fire there. The container is now told which environment
  it is in.

### Phase 11 G2 - the old Flask API routes: dead ones deleted, the live sign-in moved

- **The ten old `/api/v1` routes are gone** (revenue and payroll batch lists, one batch's
  results, the four config lists, settings read/update, "who am I"). Nothing in the app,
  the scripts or the infrastructure called them, and Andres approved removing them on
  2026-09-22. Two of them read batches without limiting the answer to the caller's
  organization. `/api/v1/health`, which every health check uses, stays.
- **Thirteen more unused Flask API routes are gone:** the fiscal-calendar import, the old
  one-shot revenue API, the whole-workbook config export/import, and the nine `/api/mso/*`
  routes behind the ADP Payroll tab of the old (unused) configuration page, which went too.
  Those nine wrote to a local JSON file and showed raw error text to the user.
- **"Sign in with Google" and "Sign in with Microsoft" now run on the new API server.**
  Same cookies, same security checks, same redirects; the old Flask version is deleted.
- **Every Flask route that is left now has a written reason and a place it will be removed**
  (the table in `docs/reports/phase-11-plan.md` §2.6.1). Still waiting on Andres: whether
  the QuickBooks "connect" page should exist in production and where.

### Phase 11 - the progress bar moves during a background-worker run (new database only, not switched on)

- **A revenue, MX payroll or QB USA payroll run done by the background worker now shows each
  step on the processing screen as it happens** ("Enriching transactions...", 45%), the same
  steps and wording the app shows today, instead of sitting on "running" until it finishes.
  Only the worker that owns the run can move its bar, and the wording comes from a fixed list
  per process, never from the data being processed.

### Phase 11 - every download is there after a background-worker run (new database only, not switched on)

- **The results screen now offers the NetSuite journal-entry files, the enriched-data workbook,
  the revenue workbook and the validation report as well as the QuickBooks files,** stored in
  AWS when the run finishes instead of on the one server that ran it. The workbooks hold
  patient details, so they go to the protected (PHI) storage, and every time one is saved or a
  download link is made for it, the access is written to the PHI audit log. The QB USA payroll
  review workbook's download link is audited the same way.

### Phase 11 C7 - a run that has to be restarted still books once (new database only, not switched on)

- **A revenue, MX payroll or QB USA payroll run whose background worker dies part-way now
  books into the same batch when it is restarted,** instead of leaving a half-written second
  one behind. The batch number is reserved and written on the run before anything is booked,
  so a restart at any point finds it; a retry after "blocked" reuses it too. Journal lines,
  employees and tie-out totals are written once, and the files come out with the same names
  and the same bytes on every attempt.

### Phase 11 D4 wave - runs go through the job queue; safer uploads and executes

- **Revenue, Mexico payroll and US payroll runs can now be handed to the background worker's
  queue instead of running inside the web server** (new database only, off by default). A new
  setting lists which processes use the queue (`WORKER_PROCESSES`); with it empty everything works
  exactly as before. On the queue, the web server only records "this run is waiting" and the
  worker picks it up, marks it running and does the work - on this computer through an
  in-memory queue, on AWS through Amazon SQS (`JOB_TRANSPORT`). Tested to produce the very same
  journal-entry files as before.
- **A process can be paused for maintenance** (`PROCESS_SUBMISSIONS_PAUSED`, new database only).
  While paused, new runs, exports and retries answer "This process is paused for maintenance"
  (`PROCESS_PAUSED`) and nothing starts; earlier runs stay readable and downloadable, and the
  process list shows it switched off. This is step one of rolling a process back.
- **A run whose background worker died is picked up again automatically** (new database only). If
  the part of the server doing the work is killed mid-run, another one now resumes the same job
  within about a minute of its time running out, the way Amazon's queue would, instead of the run
  sitting "running" forever. After three failed tries the run is marked failed, as before.
- **An uploaded file must really be the kind of file its name says.** A `.xlsx`, `.xlsm` or
  `.xls` must be an Excel workbook inside (either the newer or the older Excel format, whichever
  the name says, since Excel files are often saved under the other extension), and a `.csv`
  plain text. A web page, a PDF, a program, a Word document or anything else renamed to look
  like a spreadsheet is now refused with "That file is not the kind of file its name says it
  is" (`FILE_TYPE_INVALID`) before it is saved or opened. This applies everywhere, today's
  system included.
- **Two people pressing "export" (or "retry") on the same run at the same moment can no longer
  both start it** (new database only). Before, two such clicks that each carried a different
  duplicate-protection key, or none, could both pass the "is this run ready?" check and book the
  period twice. Now starting a run is a single database step that only one request can win; the
  other gets "This run changed while your request was being handled" (`RUN_STATE_CHANGED`) and
  reloads.
- **A duplicate-protection key left behind by a request that crashed now times out after 15
  minutes** (new database only). Before, such a key answered "still being handled" forever and
  the screen had to use a new key; now, after 15 minutes by the database's clock, the next
  request with the key checks whether the run was started and, if not, starts it.

### Phase 12 T19 - partners can be told when a run finishes (new database only, not switched on)

- **When the background worker finishes a run it now records a "run completed / failed /
  blocked / needs input" event in the same step as the run itself,** so an event is never lost
  and never announced for a run that did not change. The event holds ids and the event name
  only, never a name, amount or patient detail. It is handed to AWS after the run is saved,
  and a five-minute clean-up job re-sends anything that did not go out. Nothing is sent until
  the AWS event bus is configured.
- **Every other way a run changes state now records its event too:** the regular clean-up that
  closes abandoned or stuck runs, a run the API marks failed or cancels, and the older
  in-app processing. Each change records exactly one event, even when two of them race to
  close the same run. New event name `run.expired` for a run closed without finishing (timed
  out or cancelled); partners can subscribe to it (database revision 0020).

### Phase 11 F1-F3 - adding a process: a conformance suite, a scaffold, a generic create form

- **A conformance suite now judges every process** (`tests/conformance/`). Ten checks: the
  database allows it, its wizard steps and jobs fit the run state machine, the API document
  names it, it has a create route, its background jobs are wired (or listed as known debt
  with the task that wires them), every piece of run state it writes is classified, its
  uploads have a type, a size limit and a validator, the validator refuses a bad file
  without repeating the file's contents in a message or a log line, its permission is one
  the roles screen knows, and its calculation code imports no web or AWS code. Each check
  is proved able to fail by a deliberately broken fake process.
- **`scripts/new_process.py <id>` scaffolds a new process** (a folder with its description,
  calculation stub and background-job handler, its tests, the database change that lets the
  database accept it, and the wiring into the process list), and `docs/adding-a-process.md`
  explains the rest. A test scaffolds one in a throwaway copy of the code and runs the
  conformance suite on it: everything passes except "has a create route", because routes are
  still written by hand per process (that part is Phase 11 D4).
- **The process list now tells the app what each run's settings are** (F3, merged from its own
  branch). Every process on `/api/v2/processes` carries the fields its "new run" screen needs,
  straight from the process definition.
- **A new process gets a working "new run" screen without anyone building one.** Numbers,
  yes/no, dates, choices, required fields and limits are shown and checked the way the server
  checks them, in English and Spanish.
- **The three existing processes keep their own screens, unchanged.** QB USA Payroll's period
  and accrual days, QB Revenue's period choice and bank deposits, and MX Payroll's exchange
  rate are now registered custom steps.

### Web server logs in the monitoring format

- **The web app's server now writes one structured log line per request and per server error**,
  in the same format as the back end. The "web server errors" alarm can finally count something.
  The lines name the page's route pattern, never the address typed, and hide anything shaped
  like an email, account number, password or sign-in token.

### MX employee roster: see and reactivate deactivated employees

- **New "Show deactivated employees" switch on the MX roster screen.** Deactivated employees are
  listed with a "Deactivated" tag and a Reactivate button, so bringing someone back no longer
  means retyping their payroll code. The preview still shows only the active employees payroll
  will use. In English and Spanish.

### Phase 11 E3 - pressing "run" twice cannot start a booking twice (new database only)

- **The run and retry buttons can now send a one-time key.** On the new database, a repeat with
  the same key shows the same run instead of starting the export again; the same key used for a
  different request is refused with a clear message; a repeat while the first is still starting
  is told to wait. The old database behaves as before.
- **Running the same file twice shows a warning with a link to the earlier run** ("These same
  files were already run on ..."). It never blocks the run.
- **Groundwork for sending journal entries to QuickBooks from the background worker:** a push can
  now be picked up for a finished run, a failed push never marks the booked run as failed, and
  the record of what was sent to QuickBooks keeps every request id used.
- **Three decision records written:** how the worker checks a job before trusting it (0029), how
  a run is reserved by one worker at a time (0030), and how QuickBooks posts are made safe to
  retry (0032).

### Phase 11 C6: QB MX Payroll can run on the background worker

- **A QB MX Payroll run can now be carried out by the separate background worker**
  (new database only; not switched on yet), with the same files byte for byte, and a
  file whose month cannot be read still fails the run instead of being booked.

### Phase 11 C4: QB Revenue can run on the background worker

- **A QB Revenue run can now be carried out by the separate background worker**
  (on the new database only; nothing sends it there until the switch-over). The worker
  writes the same journal-entry files, byte for byte, and a worker that dies part-way
  is picked up by another one that finishes the run once, without booking it twice.
- **On the new database a revenue run reads the organization's own output settings**
  (which files to generate, file names) instead of the shared local settings file.

### Phase 11 C5 - QB USA Payroll keeps nothing in the server's memory (new database only)

- **On the new database, a QB USA Payroll run can be read on one server and booked on
  another.** Reading the files now saves what the review and preview screens show (the
  questions, the journal totals, the checks) as the run's own saved records, and every
  screen reads those. Booking reads the uploaded files again and refuses to book if the
  result is not exactly the preview the accountant approved. The numbers do not change.
- **The people behind a failed check are only shown on the preview screen**, and each time
  they are shown it is recorded, because a carrier-bill row is health-plan data. The
  progress view shows how many people, not who.
- **Booking the same files a second time still shows the "already run" warning** on this
  new path (it was being skipped once booking moved to the background job), and pressing
  "run" twice with the same key still books once.
- The old site on the old database works exactly as before.

### Local mode fixes and dead-code removal

- **Fixed: on the new database, a QB Revenue run used the built-in mappings instead of the
  organization's own.** It now reads the organization's accounts, clinics, providers and payer
  labels from the database, as it already did on the old one.
- **Fixed: the "test mode" banner and the test-run marker on a batch read one shared local
  file on the new database.** They now read the organization's own settings there.
- **The local sign-in bypass shows the local organization's real name** instead of
  "Local Dev" when running on the new database.
- **Removed two old setting names.** `DATABASE_MODE=local` no longer means "use SQLite" (set
  `DATABASE_BACKEND=sqlite`), and `LOCAL_ORG_ID` is no longer read (use `LOCAL_DEV_ORG_ID`).
- **Removed leftover code with no effect:** three empty sign-in cache-clearing functions,
  and a second copy of the "database refused the write" error.
- **The upload history can now be limited to the last N days** on both databases (the
  option existed but did nothing). Nothing uses it yet.
- **Upload records no longer pretend to accept "who uploaded this"** — it was never saved.
- **The MX employee list can now include deactivated employees** at the data level; the
  screen does not show them yet.

### Tests - QB USA Payroll is now checked on every push

- **QB USA Payroll now has a made-up month of input files** (`tests/fixtures/qb_usa_payroll/`,
  written by `scripts/make_sample_qb_usa_payroll.py`, with every expected total worked out by
  hand in its README). The parser, gates, CSV export and review workbook now run end to end in
  CI instead of only on Andres's laptop. The MX "excel" (processed workbook) method is pinned
  in the golden test too.

### Phase 11 G1 and G6 - dead payroll screens stay gone; five security follow-ups closed

- **The five old payroll screens (ADP payroll and booking payroll v1-v5) stay deleted.** They
  were removed on 2026-09-22; a test now fails if any of their pages, templates or shared
  in-memory session stores comes back. Their calculation code and permission names are kept.
- **A database session now checks that the person belongs to the organization it names.**
  A request for an organization you are not a member of is refused before anything is read
  (answered as "not found"). Superadmins still reach organizations through the audited
  console.
- **Invite and "processing complete" emails escape every value typed by a person** (an
  organization name, a role, a period), and an email whose subject contains a line break
  or other control character is not sent.
- **Invoice errors are logged by kind only, never with the error's full text,** and a build
  check now stops new code from writing full error tracebacks without a reason.
- **The tenant-isolation check can now read the generic database helpers** of the settings
  API, so ten statements it used to skip are verified.
- **Fixed: pressing "produce the document" twice on an invoice wrote the PDF twice.** The
  second press is now refused before anything is rendered, and a render that fails frees
  the invoice for the next try.

### Phase 11 B1-B3 - the calculation code moves out of the web server file

The numbers do not change. One QB USA Payroll bug is fixed along the way (below).

- **A new "golden" test pins what the three processes write** (every journal-entry CSV byte
  for byte, every workbook cell, the run's final status) on made-up inputs, captured before
  any code moved, so a move that changes one cent fails the build.
- **QB Revenue's calculation code now lives in its own process folder**
  (`src/processes/qb_revenue/processor.py`) instead of the web server file. Same journal
  entries, byte for byte.
- **Fixed: the port-gate script could have written its output into the code folder.** It
  now points the moved revenue code at the folder you give it.
- **QB MX Payroll's calculation code now lives in its own process folder**
  (`src/processes/mx_payroll/processor.py`). Same journal entries, byte for byte.
- **QB USA Payroll's parse and export code now lives in its own process folder**
  (`src/processes/qb_usa_payroll/processor.py`). Same QuickBooks files, byte for byte.
- **Fixed: a QB USA Payroll run started from the new app could fail before reading its
  files,** because the parse looked for the organization in a place only the old pages
  have. It now uses the organization and person saved on the run itself.
- **The app no longer reads the database migration files when it starts** to learn which
  processes the database allows; that list is written in the code, and a build check compares
  it with the migrations instead.
- **The file types each process declares now include what Windows and some browsers really
  send** (a `.csv` labelled as an Excel file, a workbook with no type), so the future direct
  upload will not refuse them. The label is only a hint; the file's contents are what is
  checked. Nothing enforces these rules yet.

### Phase 11 C1, C2, D5 - uploads kept by version, declared run state, the run sweeper

Groundwork for the separate worker, for the new database (RDS) only. Nothing on Render or
Supabase changes.

- **Uploaded files are kept by exact version, and nothing is processed until the malware
  scan clears it.** On the new database each uploaded export is stored in the patient-data
  bucket under its run, with its version and fingerprint written on the run. The processing
  step fetches exactly that version, checks the fingerprint, and refuses any file the AWS
  malware scanner has not marked clean ("This file failed its safety check") or has not
  finished scanning ("still being scanned, try again"). A retry after a server restart now
  finds its file again instead of saying the upload is gone. Stored uploads are now labelled
  so the bucket deletes them after 30 days.
- **Abandoned and stuck runs are tidied up (`python -m workers.sweep`).** A wizard left
  half-finished past its expiry is marked expired and its one-run-only roster answers are
  deleted; a run whose worker died three times is marked failed. `--dry-run` lists what would
  change without changing it. The worker does the same when the (not yet scheduled) `sweep`
  job arrives.
- **Every piece of a run's saved progress now has a declared privacy class.** Each process
  lists what it keeps about a run and how sensitive each item is (public, staff personal data,
  patient data, or "never saved"). On the new database, saving anything unlisted, or patient
  data, into a run's progress record is refused before it is written, and "never saved" items
  are no longer kept in the server's memory between requests (one exception, QB USA Payroll's
  parsed period, stays until its export is moved; it is on the tracker).
- **Fixed: an ordinary progress update could erase the worker's record of what it had saved.**
  The worker writes down each saved result's exact version on the run; a progress update from
  the web server that had read the run a moment earlier used to overwrite that record. The
  database now always keeps the worker's record, and nothing else can change it.

### Phase 11 C3, D3, D6 - saved run results, the worker loop, the worker image

Groundwork for running processes on a separate worker. None of it is switched on: nothing on
Render or Supabase changes.

- **A run's in-between results can be saved outside the program's memory
  (`src/process_state.py`).** Each saved piece is plain JSON in the patient-data bucket, under
  the run's own `state/` folder, and the exact saved version is written down on the run. Only
  the worker currently holding the run can write one, and a reader gets exactly the version
  that was written down, checked against its fingerprint; anything else is refused. Reading or
  writing a piece that holds patient data leaves two rows in the patient-data access log
  (`phi.open_state`).
- **The worker loop (`python -m workers`).** It picks up a job, asks the database whether the
  job is genuine, takes a time-limited claim on the run, runs the process's step, and records
  where the run ended up. A job that arrives twice runs once. A worker that crashes mid-run is
  replaced and the run resumes; one that crashes three times has its run marked failed. A job
  that does not match its run (wrong organization, wrong person, a person no longer in the
  organization, different files) is set aside with a reason code and never runs. An error
  inside a step fails the run with a code, never with the error's text.
- **The worker ships in the same container image as the web server,** started with a different
  command (`python -m workers`). The image build now checks the worker can start. The image
  has not been built yet (Docker is off on this machine); the next staging build will.

### Security fixes - database revision 0013 and the test suite

- **Revision 0013 no longer lets the database owner read every organization's API clients.**
  The migration account joined the API-lookup role in a way that inherited its "see every
  row" rule, so with no organization chosen it could still read all `api_clients` and
  `partner_baas` rows. It now joins only to hand ownership over (as revision 0011 already
  did), and a test proves the owner sees nothing without an organization.
- **The test suite can no longer touch a live database.** One test read the live database
  address out of `.env` during every normal run. It now checks the same privacy rules on a
  throwaway local database, the tests never load `.env`, and any attempt to connect somewhere
  other than this computer is refused unless `MERIDIAN_LIVE_DB_TESTS=1` is set on purpose.

### Logging hardening - structured JSON logs, with names, ids and secrets held back

- **The server now writes one JSON line per log record** (the format the AWS alarms were built
  to read), including one line per request with the route, the status and how long it took.
  Until now the alarms for crashes, database-pool timeouts, sign-in failure spikes and bulk
  downloads had nothing to count.
- **A redaction filter sits in front of every log line.** Secrets from the server's settings,
  sign-in tokens, passwords in connection strings, emails, Social Security numbers and long
  account numbers are replaced with `[REDACTED:…]`, and an error is logged as its type and
  where it happened, never its text (a spreadsheet error can quote a patient's cell).
- **Every request line names who signed in and which sign-in system vouched for them**
  (Cognito or the old Supabase login), so the migration window can be audited.
- AWS library debug output (which can include email recipients) stays off even when debug
  logging is on. The "logs have gone quiet" alarm now counts every request, so a day with no
  errors no longer looks like a broken pipeline.

### Auth hardening - sign-in steps, invite codes, and sign-in state shared across servers

- **A half-finished sign-in now survives landing on a different server.** When Meridian runs on
  more than one server (AWS), the "type your 6-digit code" step is saved in the database
  (encrypted, for five minutes) instead of in one server's memory, so it no longer fails at
  random. The Render deployment is unchanged.
- **Sign-in rate limits are shared across servers too.** Five wrong passwords a minute means
  five in total, not five per server.
- **New sign-in steps instead of "ask an administrator":** someone given a temporary password is
  asked to choose a new one, and someone without an authenticator app is walked through setting
  one up (show the key, type the first code) right on the sign-in page. English and Spanish.
- **The authenticator setup key also comes as a copyable `otpauth://` link**, which many apps
  accept pasted. Still no QR code, on purpose (no new library).
- **Invite codes work again.** Someone invited by email signs in, lands on the "no organization
  yet" page and types the code from the email to join. Each code works once, expires after seven
  days, joins only the organization that sent it, and every use is recorded.
- **The Users list keeps showing names and email addresses after the move to AWS sign-in.**
  Addresses come from one read of the sign-in directory; an admin can see the names of the
  people in their own organization (and only theirs).
- **Opening the API platform screen no longer writes an audit entry for everyone.** The app now
  knows up front who is a Meridian superadmin, so the Partner BAAs tab appears only for them and
  their agreements are read only when they open that tab.

### Phase 8 infrastructure pass - sign-in settings on AWS, email alarms, backup watch, safer builds

- **The app on AWS now gets its sign-in settings automatically.** The Cognito ids, region and
  client secret are wired into the server's configuration, and the server may run the sign-in
  and MFA steps against its own user pool (and only that one).
- **Switching email back to Resend is one setting**, not a code change, with the steps written
  down in the email-cutover runbook.
- **New alarms:** email bounce and complaint rates over AWS's limits, a broken email template,
  and backups that quietly stopped happening (not only ones that failed).
- **Log housekeeping:** log groups AWS creates on its own now get a retention period and our
  own encryption key; the database and log encryption keys only accept Meridian's own log groups.
- **Builds use exact, fixed base images**, and the database certificate file must match a
  recorded fingerprint (the fingerprint itself still has to be recorded once, by hand).
- **Identity backup tools:** scripts to export the user directory and rebuild it in a new pool.
- The infrastructure-change preview in CI is quieter, and the staging start-up check no longer
  hides a failed AWS read.

### Phase 12 T15 - the API security test suite, and a guard against "zip bomb" spreadsheets

- **Every security test now proves it can fail.** `pytest tests/security --known-bad` runs each
  test against a deliberately broken copy of the protection it checks, and every one of them
  fails, as it should. A new test cannot be added without saying how to break it.
- **New checks:** forged or expired sign-in tokens, a sign-in token's own claims ("I am an
  admin") granting nothing, session cookie flags, oversized requests, security headers on every
  answer including errors, and error messages that never repeat SQL, file paths or what was sent.
- **Spreadsheet uploads are checked before they are opened.** An Excel file is a zip archive,
  and a tiny one can be built to expand to gigabytes. Uploads whose contents are too many,
  too big or too compressed are refused with a plain message; normal workbooks are unaffected.
- Error answers from the API are now never cached by the browser (a crash answer used to slip
  past that rule).

### Phase 12 T12 gaps - usage numbers, partner agreements, and "Finish rotation" only when it applies

- **Usage per API client:** requests per day, errors and error rate over the last 7, 30 or 90
  days, and the last addresses it called from.
- **Partner agreements (BAAs) screen, superadmins only:** record a signed agreement (step by
  step, with a preview) and revoke one with a reason. Revoking takes medical-data access away
  from every client under it on its very next request.
- **"Finish rotation" only shows while a secret rotation is actually in progress.**

### Local test harness - the AWS-shaped app runs on a Mac with made-up data

Meridian can now run on a laptop the way it will run on AWS: a private PostgreSQL database
with the same locked-down roles, local files instead of S3, no sign-in, and two made-up
organizations to click through. Nothing here reaches production.

- **One command sets up the database** (`scripts/local_db_bootstrap.sh`): creates it the
  first time, brings the tables up to date, and fills in two synthetic organizations with
  users, roles, modules and every mapping screen's data. Running it again changes nothing.
- **A Docker version** (`docker-compose.local.yml`) is written but not yet tried, because
  Docker was off.
- **Four things that stopped the app working on the new database are fixed:** creating an
  organization (now one audited database function that makes the creator its admin), the
  settings screen saving to a local file instead of the organization, the stand-in local
  user having an id the database refused, and the health check failing on the new database.
- **README:** the "Running it" section describes the local setup and lists every
  environment variable by name.

### Phase 11 D1, D2, E1 - the job queue message, run leases and the idempotency ledger

Groundwork for running processes on a separate worker instead of inside the web server.
None of it is switched on: nothing on Render or Supabase changes.

- **The "please run this" note has a fixed shape (`workers/contract.py`).** It carries ids
  only, names whether a person or (later) an API client asked, and anything unexpected in it
  is refused. Two ways to deliver it: in memory (laptop and tests) and Amazon SQS.
- **Database revision 0011: run leases and the worker's security check.** Before the worker
  touches a run it asks the database whether the note is genuine: same organization, same
  person (still a member), same process, right step, same uploaded files. A run can be
  "claimed" by one worker at a time, and a sweeper retires abandoned or stuck runs.
- **Database revision 0012: a ledger so nothing posts to QuickBooks twice.** Before a journal
  is sent, a row records it; a repeat finds the row and returns the earlier answer instead of
  posting again (`src/idempotency.py`). The tie-out table also gains a place for QuickBooks'
  request id. Nothing writes to either yet.

### Phase 11 A1-A3, B0 - each process described in one place

Nothing changes on screen or in the numbers. This is groundwork for running processes on a
separate worker later.

- **Each process now has a "manifest":** one small file that says its name, colour, the
  files it accepts (type, count, size limit), its wizard steps, who may use each step, and
  whether it handles patient data. The three live processes each have one, stating exactly
  what they do today.
- **A manifest the database would reject is refused at start-up,** so a new process cannot
  ship half-registered.
- **The five lists that used to name the processes by hand are now built from the
  manifests** (the navigation list, the roles-screen list, which process can be retried, which
  processes store their totals in the tie-out table, which processes a run may belong to). The
  process list the app shows is checked to be byte-for-byte the same as before.
- **New tests keep the manifests, the database rules, the run states and the published API
  description in agreement,** so adding a process in one place and forgetting another fails
  the build.
- **A new build check keeps each process's calculation code free of web and cloud code,** so
  the same code can later run on a separate worker without changes.

### Phase 12 T13 - screens for managing API access and webhooks

The new API (`/api/v3`) lets another company's system talk to Meridian, and webhooks let
Meridian tell a system when a run finishes. These are the screens an organization admin uses
to manage both. The API is still switched off in production, so nobody sees any of this yet.

- **One new page, "API platform", with three tabs:** the API clients, the webhooks, and a log
  of every webhook message sent (with a button to resend one that gave up).
- **Asking for API access is a step-by-step form with a preview.** Nothing is created until
  a superadmin approves it, and the password it gets (the "secret") is shown exactly once, in
  a window that will not close until you tick "I have stored this secret".
- **Every serious change asks why.** Approving, disabling, re-enabling and revoking a client
  need a reason, which goes in the audit trail. Revoking also needs the client's name typed
  out, because it cannot be undone. Changing what a client may do shows the before and after
  first.
- **The menu link only appears when it can work:** for organization admins, and only on a
  server where the new API is switched on.
- **Two screens from the plan are not here yet,** because the server side for them does not
  exist: request counts and error rates per client, and a page for recording partner
  agreements (BAAs).

### Phase 7 (code complete 2026-09-16; critic PASS at round 2) - email moves to Amazon, one switch at a time

Meridian sends two emails: an invitation with a join code, and a note saying a run finished.
Both go out today through Resend, an outside company with no agreement in place to handle
anything to do with patients. This phase builds the replacement and puts it behind a switch.
Nothing changes for anyone until that switch is thrown, which is a separate, deliberate act.

- **The letters are unchanged, and that is checked automatically.** The invite email and the
  run-finished email look exactly as they do now, down to the last character. A test renders
  each one through the old sender and the new one and fails if a single byte differs, so
  "nobody notices" is a property the build enforces rather than something we hope for.
- **One email per event - there is no "send it both ways to be safe".** The tempting way to
  switch providers is to send through both for a week and compare. That would mean two
  emails, with two different join codes, to somebody who was invited once. So the switch has
  three settings - the old provider, the new one, and off - and no fourth.
- **Turning it on is one setting. Turning it back is the same setting.** The rollback is not
  a code change, a deploy or a decision tree; it is the word `resend` where the word `ses`
  was. Everything about the old provider stays in place - the key, the account, the code -
  until the new one has been live and quiet for a day.
- **The system will refuse to start if nobody has said which provider to use.** That is
  deliberate and it has a price: the setting has to be added to the hosting dashboard before
  this reaches production, or the next deploy fails. The alternative was worse. If an unset
  value quietly meant "keep using the old provider", then after the switch the software
  could go on mailing through a company we have no agreement with, while every document said
  otherwise. A loud failure on a deploy is cheaper than a silent one for months.
- **The machine may only send as one address, and the permission says so.** The part of the
  system that sends email is allowed to send from `no-reply@` and nothing else - not
  billing, not anybody's personal mailbox. This is not about tidiness: a fake message from
  our own domain, correctly signed, is the most convincing message anyone in the company
  will ever receive.
- **Bad news has somewhere to arrive.** Failed deliveries, spam complaints, outright
  rejections, and the case where the message could not be built at all now all report to one
  place. That last one matters more than it sounds: when a template breaks, nothing is sent
  and nothing bounces, so without this event a broken email looks identical to one nobody
  has opened yet. Somebody still has to confirm the notification address by clicking a link,
  and until they do these reports arrive nowhere - that is written down as an open item.
- **No email address and no message text is ever written to the logs.** Not on success, not
  on failure. Even the error handed back when a send fails is now a short code rather than
  the provider's own sentence, because that sentence quotes the address it could not deliver
  to. Logs are kept for over a year; an address in one is an address kept for over a year.
- **There is a written procedure for the day it is switched**, with the exact commands to
  check first - is the account out of its sending sandbox, are the mail records answering,
  is the "do not mail this address" list empty, does one real test message arrive properly
  signed - then the flip, the rollback, and what to watch for 24 hours.

### Phase 9/10 runbooks - the two days that cannot be improvised, written down early

- **There are now step-by-step instructions for the switchover day and for turning the old
  system off**, written months before either happens, because the worst possible time to work
  out what order to do something in is while the site is in maintenance mode. Both are drafts
  until somebody has followed them: the switchover is rehearsed twice on the practice
  environment first, and the second rehearsal has to be done **without editing the file** - if
  you had to correct it as you went, it has not been proved.
- **The switchover runbook is built around one sentence:** until the first person saves
  something on the new system, going back costs five minutes. After that, going back means
  re-typing that person's work. So everything that can be checked is checked before that
  moment - the data is proved equal to the cent, every file is confirmed to exist, and the
  test run against the new system deliberately only *reads*. It names the one unavoidable
  write there is (a startup marker the software leaves) rather than claiming there are none.
- **Two points where I stop and ask you**, in writing, on the day: once before the freeze
  starts, and once immediately before the change that moves real traffic. Not a thumbs-up from
  last week - a yes, in words, with the consequences read back to you first.
- **The old system is left switched on.** Not suspended, not scaled down - running and paid,
  on the old data, for two full closes. That is what a rollback actually is, and a suspended
  service is not one you can reach in five minutes.
- **The decommissioning runbook is ordered so the only irreversible act happens last and
  fourth.** Before anything is cancelled, a complete copy of the old database is taken, its
  checksum recorded, and it is **restored into a scratch database and counted** - because a
  backup nobody has restored is a file, not a backup. The copy goes into the storage area
  nothing can delete from for seven years, with your name on it as custodian and a written
  retention and disposal rule. The phrase "delete after verification" is explicitly banned
  from that step: after the cancellation, that copy is the only record of the old database.
- **Every deletion step says what it destroys before it says how**, and each one is preceded
  by the same stop-and-ask. The cancellation of the old database has its exact wording written
  out to be read aloud, because that is the one thing in this whole migration with no undo, no
  support ticket and no recovery window.
- **Three things the writing turned up and could not resolve** are now open items with your
  name or mine on them: the deployment pipeline cannot actually deploy the live system today
  even though the switchover checklist assumes it can; two of the phase reports the checklist
  depends on have not been written yet; and the custody record for that seven-year archive has
  nowhere to live until the compliance evidence folder gains an entry for it.

### Phase 8 - what "ready" means, written down, and two gaps in the build closed

Phase 8 is the phase before anything real moves, and most of what it produces is not
software - it is proof. This part of it is the part that could be done before the AWS
account is paid for and switched on.

- **There is now one document that says what "ready" means.** Eight things, each with the
  piece of paper that proves it: the security scores are clean, the backup can actually be
  restored and was timed, every password has been changed once through the written
  procedure, a deliberate attempt to delete a backup was refused, and the bill matches the
  estimate. Before this, "ready" was a word. A new runbook holds the exact commands for each
  one, and says plainly which of them cannot be done at all until the account is deployed -
  so "not done" and "cannot be done yet" stop looking the same in a status report.
- **The build now checks whether a change touches anything that is actually running.**
  Until now it could only tell you the infrastructure code still made sense to itself. It
  now compares it with what is deployed - using a new identity that is allowed to **read**
  and nothing else, and that cannot deploy anything even if somebody tried. While it is not
  switched on, the check quietly skips rather than turning the build red for no reason.
  It runs after a change is merged rather than while it is being reviewed: running it earlier
  would mean letting code nobody had read yet reach the account, even in read-only form, and
  on an account that will hold patient data "read-only" is not the same as harmless. The
  check also refuses outright any change that would delete or recreate a database, an
  encryption key, a storage bucket, the login directory or a backup vault - those have to be
  done deliberately, by hand, with the procedure open.
- **The website's own ingredients are now checked for known security problems.** The
  server's were, since the beginning; the container images were, since earlier this year;
  the part that runs in your browser was not. Five known problems were fixed by this change
  alone, including one rated critical. Four more cannot be fixed without a large version
  upgrade, so they are written down - with a reason, a name, and a date they must be looked
  at again. An expired excuse fails the build, which is what stops "temporarily accepted"
  quietly becoming "accepted".
- **Two security services were watching less than they were supposed to.** A well-known
  benchmark that auditors ask for by name was not switched on; it is now. And the automatic
  software scanner was only looking at the containers, not at the small function that briefly
  sees a person's password while their account is being moved across - the one place in the
  whole system where a password exists in readable form. It looks at both now.
- **A decision that had been deferred twice is now made: no Macie.** Macie is the Amazon
  service that would go and *look* inside the file storage to confirm that patient data is
  only where we believe it is. The reason is not the money (about $2 a month): today it would
  have nothing to look at, because there is no real data in the new system yet, so it would
  only ever find our own test files. So the answer is no, with three specific
  events written down that change the answer - the first being real data living there for a
  full period after the switchover.
- **The list of things only you can do is now one list.** It was scattered across eight phase
  reports: forty-one items, each with your name on it and whether it has moved. Some are
  signatures, some are money, some are a single click in a dashboard. Two of them are
  currently blocking everything else.
- **The threat model was re-walked for everything built since the beginning.** Seven new
  surfaces - the two web frameworks running inside one another, the window where two
  different logins are both accepted, the emergency cross-organisation read, the account
  migration function, the deploy identity, the proxy still running on the old host, and the
  header that proves a request came the right way. Four new gaps came out of it, and they
  were written down rather than rounded off.

### Phase 6 (code complete 2026-09-16; critic PASS at round 3) - the system can now tell you when it is broken

Until now, if the new setup had failed at three in the morning, the way anyone would have
found out is by trying to use it. That is the gap this closes. None of it changes what the
software does; all of it changes what you get told.

- **About thirty things now watch themselves, and all of them write to one place.** Whether
  the site is answering, how slow it is, whether anything is behind it, how full the
  database is, how close it is to running out of connections, whether the backups ran,
  whether a password rotation failed, whether the security services found something. Each
  one sends an email when it goes wrong **and another when it comes right** - because an
  alarm that only ever tells you about bad news is one you stop reading, since the only way
  to learn something recovered is to go and look.
- **Nothing reaches you until you click a link in an email.** That is a rule of Amazon's,
  not a choice: a person has to confirm the address before anything can be sent to it. It
  has not been done. Until it is, every one of these alarms fires into an empty room and the
  only symptom is silence. It is the first step in the new alerts runbook and it is written
  down as an open item with your name on it.
- **One alarm is not about speed or capacity at all.** The part of the system that does
  revenue runs deliberately runs as exactly one copy, because two copies could each pick up
  the same run and book the same journal entry twice. So "there are now two copies" is an
  alarm - a bookkeeping alarm wearing a capacity alarm's clothes. It waits half an hour
  before saying anything, so that an ordinary update is never mistaken for it.
- **Nothing that could contain a person's details is ever looked for by text.** The checks
  that read the application's own logs are written to look at *named fields* - a status
  code, an error code - and never to search the text of a line for a word. Searching text
  for words is how a patient name ends up copied into a monitoring rule that then keeps it
  for four hundred days. The consequence is honest and deliberate: **those particular
  checks find nothing at all today**, because the application does not yet write its logs
  in the structured form they read. The dashboard says so in as many words, so a row of
  zeroes is not mistaken for good news, and fixing it is an open item.
- **There is one screen that answers "is it healthy?" without asking a question.** A single
  dashboard per environment: how slow, how busy, how broken, how full, then the sign-in
  helper, the backups, and a security row - and at the bottom, every alarm's current state
  in one block. It deliberately shows **no log text anywhere**, only counts, because a
  dashboard is the thing most likely to end up in a screenshot.
- **A nightly job that had no way of reporting its own failure now has one.** A small piece
  of Amazon plumbing reads the failure queue and emails anything that is not the one
  harmless, expected message. The old manual check stays as well, on purpose: it is the
  only thing that confirms the nightly job ran *at all* on the nights when nothing went
  wrong.
- **An optional outside-in check was built and left switched off.** It would fetch the site
  from the public internet every five minutes, which is the only way to catch problems that
  are invisible from inside - an expired certificate, wrong DNS, a broken cache layer. It
  costs about $10 a month per environment, which is more than the budget's remaining
  headroom, so it ships turned off with the number written down and the decision left to
  you.
- **Every log store in the whole setup is now checked automatically** for having both an
  expiry date and its own encryption key. All of them pass today. The check exists so that
  the next one added without them fails the build instead of being discovered a year later.
- **None of this is evidence yet.** The plan asks that each alarm be set off deliberately
  once, on the practice environment, with the resulting email kept. That has not happened,
  so the compliance rows that point at this work still point at a plan rather than at proof.

### Phase 5b (code complete 2026-09-16; critic PASS at round 3) - the last Jinja screens move, and two are switched off

The old software still answered a handful of pages directly. After this phase it answers
none of them. Six path families left in two slices: four are rebuilt on the new software
and two are switched off because nobody should be using them. Nothing an ordinary user
does every day is in this list.

**The invoice wizard is a real screen again.** The invoicing pages have been rebuilt.
They look like the rest of Meridian now instead of like the old site, and they work the way the new screens do: the whole invoice is held in
the page while you fill it in, and the server is only asked twice — once to check the
figures, and once to actually raise it.

- **Raising an invoice is three steps.** Fill in who it is for and what is being billed,
  press Preview and read the figures the server worked out, then generate. The download
  button is in the top-right corner, where it is on every other screen here.
- **Opening the page no longer uses up an invoice number.** It shows you the next one in
  the series as a suggestion; the number is only taken when you actually generate the
  invoice. So opening the wizard, changing your mind and closing it leaves no gap in the
  numbering for somebody to wonder about later. You can still type your own number, and
  the series carries on above whatever you typed.
- **Refreshing the page, or opening two of them, no longer scrambles the invoice.** The old
  pages remembered a half-finished invoice on the server, one per person, so a second tab
  quietly edited the same one and a refresh lost it. Each page now keeps its own.
- **Empty lines are dropped rather than complained about.** A row you cleared out is a row
  you did not want, and the preview shows you exactly the lines that will be printed.
- **The figures on the preview are the figures on the PDF.** They are calculated once, on
  the server, rather than once in the browser and again for the document.
- **Bank details are not sent to the browser.** The invoice PDF still carries the account
  for the client to pay against; the screen only ever shows the last four digits.
- **Past invoices are listed under the wizard** and can be downloaded again. Someone who is
  allowed to raise invoices but not to read the history sees a line explaining that,
  instead of a broken page.
- **Everything the old pages did has been deleted**, with a test that fails if anything
  anywhere still points at them. The one file kept is the PDF design itself, which is what
  the client receives and is not a screen.

- **Your profile page still works, and there is now one place to change your name.** The
  old `/profile` page showed your name, your organization and a "Change password" button.
  The new software already had all of that inside Settings, sitting next to the
  authenticator setup, so the address `/profile` now simply takes you there rather than
  offering you a second form that could disagree with the first.
- **"Change password" sends you somewhere that still exists.** The old button emailed a
  link into the sign-in system that is being replaced, which after the switch-over would
  have been a link into a system that is no longer in charge. It is now a link to the same
  "forgot your password" page the sign-in screen offers, and there is exactly one way to
  reset a password.
- **The employee roster for Mexican payroll has its own screen.** Same list, same fields,
  same permission — whoever can fix a mapping can fix a roster row. Two things are
  deliberately new: a **Preview** that shows the roster exactly as the payroll run will
  read it, and a confirmation that names the employee code before taking somebody off the
  list. Taking somebody off still deletes nothing; a period that was already booked is
  unchanged, and saving the same code again brings them back.
- **The administrator's console across every organization is rebuilt, and looking at it is
  now recorded.** It is the one screen in the product that reads across customers, and
  until now it did so through a key that could step over every protection in the database
  and left no trace. It now reads each organization one at a time, with exactly the same
  restrictions any member of that organization has, and writes an entry saying who looked
  at which organization and why. Nobody — including whoever looked — can read that log
  back, amend it or erase it through the application.
- **That console tells you two things where it used to tell you one.** It had a single
  green light built from "the database answered" and "the settings workbook loaded", so a
  missing workbook and a database outage looked identical on the one screen meant to tell
  them apart. They are two answers now.
- **The console shows no names.** It lists organizations, how many people are in each and
  which parts of the product they have. It does not list who those people are: an
  organization's own administrators can see their own colleagues, and nobody needs a
  directory of every customer's staff.
- **To anyone who is not an administrator, that console does not exist.** Asking for it
  gives the same "no such page" answer as a made-up address, rather than "this exists and
  you may not have it".
- **A developer-only test page is gone.** It let an administrator upload a file and run it
  through the system with the results thrown away. The real screens do that properly, for
  every organization, and this one accepted an upload nobody was checking.
- **Wearbly's screens are switched off.** The uniform-ordering product has been on hold for
  a while, and creating an order has in fact never worked against the real database — the
  job failed every time and said so. Rather than leave six pages that lead to a failure,
  the pages are gone. **Nothing was deleted**: the orders, the catalogue, the sizes and the
  column mappings are all still there and still readable, and so is the receipt design.
  Whether Wearbly comes back properly or is retired is Andres's decision, and it is a
  decision that can still be taken either way.
- **The "Sign out" link in the old page frame is gone, because signing out belongs to the
  new software now.** The new screens have had their own sign-out all along; what has been
  removed is a second one that would have stopped working.
- **The list of pages the old software still answers is now empty.** It was six at the
  start of this phase and is zero at the end of it, and the rules that route traffic were
  updated in the same change, with tests that fail if the two ever disagree. There is also
  a new test that fails if anything anywhere still links to a page that has been removed,
  because a dead link is a visitor hitting an error, not a tidy-up job for later.

### Phase 5a — data layer port, FastAPI beside Flask, containers (code complete 2026-09-16; critic PASS at round 5)

#### The new web server starts serving, one page at a time

Nothing looks different and nothing behaves differently. This is a change of plumbing, and
it is deliberately small: two of the roughly ninety things the site answers have been moved
onto the new software, and the other eighty-eight are answered by the old software running
underneath it, at the same address, exactly as before.

- **There is now a way to put a build on the staging servers, and it has not been used.**
  A single button in GitHub runs the whole thing: the test suite, then a build of both
  programs for the kind of processor the servers use, then a scan of both for known
  security problems, then — only if all of that passed — the upload and the rollout, and
  finally a wait until the new version is actually answering requests rather than merely
  accepted. Nothing about it is automatic: it cannot be set off by merging anything, and it
  refuses to start unless the words `deploy-staging` are typed into it. It stays that way
  until the cost of running a staging environment is approved, because pressing it starts
  something that costs money every hour. It has never been pressed.
- **Each build is labelled with the exact commit it came from, and that label can never be
  reused.** So the question "which version is running?" has one answer, and going back to
  yesterday's version means running the same button from yesterday's commit rather than
  hoping a shared label still points where it used to.
- **GitHub is not given an AWS password.** It is given the ability to ask AWS, at the moment
  it runs, for an hour of access — and only from two named branches of this one repository.
  What it can do with that hour is deliberately small: push the two images, deploy the one
  set of servers, and ask whether they came back healthy. It cannot touch the database, the
  sign-in system, or anything else.
- **The site is now served by its new web server**, with the old one running inside it. A
  visitor cannot tell, and is not supposed to be able to: same address, same pages, same
  sign-in, same cookies. The two pieces that moved are the "are you alive?" check the
  hosting provider makes every few seconds, and the sign-in calls the new screens use
  (signing in, signing out, the authenticator code, and the two halves of a password
  reset).
- **A page is never half-moved.** Each one leaves the old software in the same change that
  adds it to the new, so there is never a moment where two different pieces of code could
  answer the same request and disagree. There are tests that fail if that ever stops being
  true.
- **Sign-in was not rewritten, only re-plumbed.** The decisions about what a valid password
  is, what an authenticator code is worth, how long a half-finished sign-in stays usable and
  what an error says are the same lines of code they were yesterday; only the layer that
  turns them into a web response is new. That is why the sign-in tests were kept word for
  word and simply pointed at the new server.
- **Protections moved with it.** The anti-forgery check on every sign-in, the five-attempts-a-
  minute limit on password guesses, and the headers that stop the site being framed or
  sniffed are all still there, and are now set once for both halves rather than twice.
- **An unexpected error still tells you nothing it should not.** It gives a reference number
  and a sentence; the technical detail goes to the log, where it can be looked up by that
  number.
- **One thing changes for whoever deploys it:** the start command is now `uvicorn
  api.main:app`. Running `python web_app.py` still works for local Jinja work but no longer
  answers the two moved paths.
- **The settings and mapping-editing calls moved next.** Editing or deleting a payer,
  location, provider, department or QuickBooks provider code, adding a clinic group, reading
  and saving the application settings, resetting them, reading and renaming the organization,
  and the provider P&L's roster and period preview are all answered by the new server now.
  Nothing about what they do changed — the same org filter, the same "that name is already
  taken" refusal, the same settings that save a warning and refuse an error — and their tests
  were kept word for word and pointed at the new server. Who may call them is unchanged too:
  the mapping calls still need the configuration permission, and the settings and
  organization calls are still admins only.
- **User management moved with them.** The member list, the invites, role changes, removals
  and the whole roles-and-permissions matrix are answered by the new server now. The four
  refusals that keep an organization usable are the same code they were: you cannot remove
  your own account, you cannot remove or demote the last admin, you cannot delete a role
  somebody still holds, and you cannot give two roles the same name. All eight calls are
  still admins only, the invite still goes out through the same mechanism the old admin page
  used, and inviting is still capped at forty an hour — it is the one call that sends mail to
  an address the caller chose.
- **The provider P&L moved next.** Saving and reading the P&L rulebook, uploading a period's
  cost ledger or driver sheet, reading either of them back, downloading the blank driver
  template and downloading the finished P&L workbook are answered by the new server now.
  Nothing about what they do changed: a preview is still the real parse of the real file and
  still writes nothing, a second upload for a period still retires the first rather than
  deleting it, the uploaded file is still removed on every way out of the request including a
  refusal, and the workbook still only formats figures the browser computed. The uploads are
  read by the same file-reading code the old server used, so a spreadsheet that was accepted
  yesterday is accepted today, and downloads arrive with the same filename as before.
- **The revenue and Mexico payroll runs moved next.** Starting a run, watching it, cancelling
  it, retrying a blocked one, the run history and the download links are answered by the new
  server now. The processing itself did not move an inch: the same code does the same work in
  the same way, started the same way, writing to the same place — the Jinja wizard and the new
  screens are still two front ends over one run. The safety rule that matters most is
  untouched: a revenue run that meets a provider, facility or payer nobody has mapped stops
  before a single journal entry exists, says which ones and how much money each is holding up,
  and is restarted by the same button after the mapping is added — including after a deploy.
  Sending the same upload twice with the same reference still gets you the run you already
  have rather than booking the period a second time, and a download link is still short-lived,
  still issued rather than proxied, and still recorded with who asked for it.
- **The calls every screen makes moved next.** Signing in and landing somewhere now goes
  entirely through the new server: who you are and what you may do, the list of processes and
  where each one starts, the combined run history, the security token the browser needs before
  it can save anything, and the health check the deploy watches. So do the four mapping lists
  the "this run is blocked" screen reads and the four "add a mapping" buttons on it, which is
  the path back out of a blocked revenue run. Nothing about what any of them says changed:
  the same processes in the same order under the same names, the same permissions read fresh
  from the database on every request rather than trusted from a token, and a process your
  organization has switched off is still shown as switched off rather than quietly vanishing.
  Saving your display name or your language is still genuinely partial — saving one never
  silently reverts the other — and your dashboard layout still follows your account rather
  than the browser you last used.
- **The US payroll run moved last, and with it the last of the API.** Uploading the month's
  files, the roster review where you tell it how to code somebody it does not recognise, the
  preview with its checks, declaring a check you expect to fail, exporting, watching it run,
  pushing to QuickBooks and downloading what it produced are all answered by the new server
  now. None of the accounting moved: the same code reads the same files, applies the same
  checks and writes the same journal entries, on the same background worker, to the same run
  the old wizard uses — the two screens are still two front ends over one run. The refusals
  that matter are untouched: a period whose files are wrong is rejected whole rather than half
  accepted, a preview is refused outright while anybody on the payroll is still uncoded rather
  than quietly leaving them out, a failed check nobody has signed off still stops the export,
  and it stops the download too — re-checked against the database, so it survives a restart.
  Answering "just this run" instead of "from now on" still means exactly that, and next month
  starts clean.
- **The dashboard moved, and with it the last page on the old server's side of the API.**
  What the home screen shows in one request — who you are, which organization, the processes
  you may open and where each one last got to, the ten most recent runs across all of them,
  the "this period" counters, the close checklist and the last six periods' totals — is
  answered by the new server now. Nothing it says changed: the same period read from the same
  fiscal calendar, the same counts over the same runs, and a process you cannot open is still
  listed and marked as such rather than hidden. Because it was the last one, the old server's
  whole set of API pages was deleted rather than left empty, and there is now a test that
  fails if a single one of them ever comes back.

- **Two invoices can no longer be given the same number.** The invoice number used to be
  worked out by looking up the highest one so far and adding one, with nothing stopping two
  people who looked at the same moment from both being handed `INV-2026-042` — and nothing
  in the database refusing the second one when it was saved. There is now a counter per
  practice group that moves in a single step, so two people asking at the same moment get
  two different numbers, and the database itself refuses a duplicate as a last line of
  defence. Existing numbers were read and the counter started from where each group had
  already got to, so nothing restarts at 001 and no number is skipped. A number you type in
  yourself is still honoured; if somebody else has taken it in the meantime, the invoice is
  saved with the next free one instead of failing. Nothing about how an invoice looks, or
  what it says, changed.
- **The screens that read and write directly to the old database now go through one place
  per screen instead.** The invoice wizard, the QuickBooks US payroll run, the user and
  organization admin screens and the Wearbly uniform pages had their database calls written
  out by hand inside each page. They now sit in modules that speak to either database, which
  is what lets the site be moved one screen at a time. Nothing a user does changed.
- **Three of those hand-written calls were reaching more widely than they should.** The
  permissions matrix, the "how many people hold this role" count and the "is anyone still
  using this role" check all asked their question without saying which practice group they
  meant, and were relying on a database rule that the server's own credentials skip past.
  They now say it. No evidence any of them ever returned another group's data — the pages
  that use them are administrators-only and always passed an id from their own group — but
  they were one refactor away from being able to.
- **A long-standing fault in the Wearbly uniform pages came to light.** Every one of its
  database lookups asked for something the database layer does not have, and every failure
  was being swallowed — so saved column mappings never loaded, no brands ever appeared, no
  price was ever found and the order page showed nothing. Two of the lookups also named
  columns that do not exist. The lookups are fixed. Creating an order still does not work:
  it has the same fault in the saving half, and repairing that is a decision about whether
  Wearbly is still a product rather than part of this move, so it is written down and
  waiting on an answer.

#### The foundations the data move stands on

- **There is now one way in and out of the new database, and it knows which practice
  group it is working for.** Every piece of code that reads or writes goes through a
  single door that stamps the connection with the organization before it is used and wipes
  the stamp clean afterwards. That is what stops a query with a forgotten filter from
  showing one client's rows to another: the database itself refuses, rather than relying
  on every one of two hundred queries being written correctly.
- **Patient identifiers get their own locked room, with a visitors' book.** One module,
  and only one, can open it. Every time it does, it writes down who opened it, for which
  organization, what they did and how many rows they touched — and never the values
  themselves. The book cannot be edited or erased by the application, only added to.
- **The stand-in code used in place of a patient account number is provably the same one
  the data move already wrote.** There is a test that computes it both ways — in Python
  and in the database — and fails if they ever disagree, because if they did, the link
  between a row and the patient behind it would be quietly lost.
- **A database error no longer poisons the rest of the page.** Four places in the code
  deliberately shrug off a database problem and carry on; previously that left the
  connection in a broken state and the *next* thing you clicked failed instead. Now the
  failed step is the only casualty.
- **The application can be packaged to run on Amazon.** Two container images, one for the
  backend and one for the web app, along with a list of everything that must never go into
  them — client workbooks, the staff email list, exports, the scratch files in the project
  folder. The backend image refuses to build if the fiscal calendar is missing from it, or
  if the staff email list has found its way in.
- **The Amazon side of the running application is written down as code**: where the images
  are stored, how many copies of the app run (exactly one for the part that books journal
  entries, on purpose — two would double-book silently), how much memory each gets, and an
  automatic undo if a new version fails to start.
- **Nothing is deployed and nothing is switched on.** Production is still on Render and
  Supabase, and the new database code still refuses every request with a message naming the
  step that owes it, so switching it on early fails loudly instead of half-working.

### Phase 5a - who you are, and what you may do, now have an Amazon version too

Signing in, the organization you belong to, the permissions your role grants, the modules
your practice has, and the invitations you send all read rows from a database. Those reads
had one version, written for the old database and run with a master key that switches the
database's own protections off. They now have a second version, run as an ordinary
application account with those protections on — so a mistake in the code above them reads
nothing instead of reading somebody else's rows.

- **The safety net is now underneath the membership and invitation screens too.** On the
  old path, "which organization is this person in" was asked with a key that bypasses every
  rule the database has, and the only thing keeping one client's rows away from another's
  was the question being written correctly. On the new path the database answers the same
  question with its own rules applied: a member sees their own membership and the
  organizations they belong to, and nothing else, even if the question is wrong.
- **An invitation can be redeemed without being able to see anybody else's.** Joining by
  code is the one moment somebody is signed in and belongs to nothing yet. The session now
  declares the code it is holding and the database shows it that one invitation — not a
  list, not a neighbouring organization's, and not enough to guess one. Accepting it and
  marking it used are ordinary writes inside the organization the code names, and they both
  happen or neither does, so a forwarded code cannot be used twice.
- **A bug that would have broken every invitation on the new database is fixed.** The code
  that decides whether an invitation has expired assumed the date arrived as text. From the
  new database it arrives as a date, and the old line would have failed on every single
  redemption — the one screen a brand-new user sees. It now accepts either, with a test for
  each.
- **A busy moment no longer reads as "you have no permissions".** Two places quietly
  carried on after a database error: one decides what a role may do, the other records the
  address an invitation was sent to. Both now tell the difference between "the database
  said no" — which they still shrug off, as they always did — and "the server is too busy
  to ask", which they refuse to dress up as an answer.
- **Your name and preferences are saved as you, not as an administrator.** Display name,
  language and dashboard layout are written by a session that is only allowed to write your
  own row, so a mistake in the code above it cannot overwrite somebody else's. One
  consequence is visible and is written down as an open item: on the new database the
  members screen can show other people's names only once a rule is added that says a
  colleague may read them.
- **Nothing is switched on.** Production still signs in against, and reads from, the old
  database. Both versions are kept working side by side and both are tested, including
  tests that create a second organization and a second person purely to prove neither can
  see the other.

### Phase 5a - every database operation now has an Amazon version

The sixty-three things the application asks the database to do — book a period, read back a
batch, save an allocation, update a mapping — each had one version written for the old
database. They now have a second version written for the new one. Both are kept working
side by side until the switch is thrown, and both are tested.

- **Patient identifiers stop being written next to the money.** When a period is booked,
  the account number, claim number and encounter number now go straight into the locked
  room described above, and what is stored beside the amounts is only the stand-in code.
  Nothing has to be cleaned up afterwards, because nothing sensitive is written in the open
  in the first place.
- **Nothing readable goes past the database's own activity log.** Bulk writes — every
  transaction in a period, every employee in a payroll run, every raw uploaded row — are
  loaded through a channel whose contents are not recorded in that log. Amazon keeps it for
  400 days, and a patient account number or an employee name in it would be a leak that no
  amount of later tidying could take back.
- **A re-upload can no longer quietly lose an old booking.** Asking to delete a period whose
  identifiers are already in the locked room now refuses with a sentence explaining why and
  what to do instead, rather than failing with a database error naming a schema the caller
  is not allowed to see. The proper fix is a small schema change, and it is written down as
  an open item rather than left implied.
- **Two things that used to read half a month now read all of it.** The old database
  answered a request with at most a thousand rows, so a period of sixteen thousand
  transactions came back as a sixteenth of itself and looked like a thin month. The new one
  has no such limit and the workaround is gone.
- **An empty box stays an empty box.** A field a spreadsheet left blank is stored as blank,
  not as "nothing at all" — a distinction that sounds pedantic and is exactly what a
  journal entry's description line is built out of.
- **Every read and every write names the practice group it is for.** Not one of the sixty-
  three relies on the database's own safety net to keep one client's rows away from
  another's; the safety net is underneath, and there are tests that create a second
  organization for the sole purpose of proving it sees nothing.
- **Fourteen more pieces of the app can now talk to the new database.** Run state, the
  provider P&L's rulebook and uploads, the QuickBooks mapping tables, the payroll roster,
  the export tie-out, the QuickBooks connection, the application settings and the Wearbly
  lookups all read and write through the new plumbing when it is switched on, and through
  the old one when it is not. Nothing any of them does changed.
- **A run can no longer lose the write that retired it.** Two things saving progress for the
  same run at the same instant used to both try to create it, and the loser's write was
  quietly dropped — which is how a re-booked period could keep two "completed" runs in the
  history with nothing to say which one went to QuickBooks. It is now a single instruction
  the database settles, with no gap in the middle.
- **Five lookups stopped being able to read every client's rows.** Provider start dates, the
  QuickBooks account and department maps, the payroll roster, the benefit overrides and the
  Mexico location remap each had a shape — call it without naming a practice group — that
  applied no filter at all, and the server's key skips the database's own safety net. No
  code in the app takes that shape, so nothing wrong has happened; but "no caller does that
  yet" is not a protection. All five now fall back to the practice group they were given and
  refuse outright when there is none, on both databases.
- **The Wearbly size lookup has never worked, and now does.** It asked for a column the table
  does not have, the error was swallowed, and it quietly fell back to guessing the size from
  the text. Every size mapping anyone configured has been ignored since the feature was
  built. **This changes what Wearbly produces**, so it is written down as a decision for
  Andres rather than assumed: keep the fix, undo it, or empty the table.
- **A page missing a section is no longer how the app tells you it is overloaded.** The
  places that deliberately shrug off a database error and carry on now let two things
  through: "every connection is busy" and "that write was for a different practice group".
  Neither is the database answering a question, and neither should look like a paragraph
  that just happened not to render.
- **Nothing is switched on.** Production is still on Render and Supabase. The final check
  before this can be trusted — reload a real closed period and prove the journal entry
  files come out byte for byte identical — needs a copy of the production database and the
  original workbooks, neither of which is on the machine this was written on. The exact
  commands are written down and the check is an open item with a person's name on it.

### Phase 4 — Sign-in moves to Amazon, written as code (2026-09-16)

Nothing has changed for anyone signing in today. Sign-in still goes to Supabase; this is the
new arrangement written down and tested, ready to be switched on later in Phase 4.

- **Two-step sign-in (an authenticator code as well as a password) is now required by the
  configuration.** It does not exist on the live system yet — that is the single biggest
  open security gap — and it starts working the day sign-in is switched over.
- **Your name, picture, language and dashboard layout now have a proper home in the
  database** instead of being tucked inside the sign-in service's own records. They are
  copied across automatically, nothing is retyped, and nobody but you (or an administrator)
  can read your row.
- **Nobody is forced to reset their password when the switch happens.** The piece that makes
  that possible now works: the first time you sign in after the switch, it checks your
  existing password with the old service and moves your account across without telling you
  anything happened. If it cannot check — the old service is slow or down — it says "sign-in
  is temporarily unavailable" rather than "wrong password", because a machine that cannot
  check your password has not decided your password is wrong. It says exactly the same thing
  when the password really is wrong, so that nobody can use the login box to find out which
  email addresses are real.
- **It writes down a domain and never a person.** The only things it records are which email
  *domain* was involved, what happened and how long it took. Those records are kept for 400
  days, which is why nothing else goes in them.
- **Accounts that sign in with Google or Microsoft are created and linked by hand first**, by
  a new script, before either of those buttons is switched on — that is the step that stops
  duplicate empty accounts appearing. A second new script reports every week how many people
  have moved across, so the day the old service is switched off is a known quantity rather
  than a surprise.
- The whole procedure is written down as a runbook, including what to check before the switch
  and how to undo it.
- **Password resets become real resets.** Today's emailed link signs you in without changing
  anything; the replacement changes the password and the old one stops working.
- **Sign-in checks got faster and more honest.** The app used to remember, for up to a
  minute, who a session belonged to and what they were allowed to do — so removing somebody's
  access took up to a minute to take effect. That memory is gone; every request now asks.
- **The screens for all of that now exist.** Signing in asks for your authenticator code as
  a second step; "Reset your password" and the page that spends the emailed code are new
  screens in the main app; and Settings has a section for setting up an authenticator on
  your phone. All four still behave exactly as before until sign-in is switched over.
- **Asking to reset a password no longer tells a stranger whether you have an account.**
  The answer is now word-for-word the same whether or not the address belongs to anybody,
  which is why the screen says "if an account exists" rather than "we sent it".
- **Four ways of handing the server a sign-in token have been deleted.** The riskiest was an
  address the site would accept tokens at with no protection against another website
  submitting the form for you. The others put tokens in the web address itself, where they
  end up in browser history and in server logs. Signing in with Google or Microsoft now
  works one way only, and the tokens never leave the server.
- **The sign-up page is gone.** Joining Meridian was already by invitation only, so a page
  inviting strangers to request an account led nowhere. **Note:** invited people cannot yet
  redeem their code — the screen that does that is still to be built, and it is on the
  migration tracker.
- The users list no longer makes one call per person to fetch names.
- Google and Microsoft sign-in stay, and are deliberately switched off until each account has
  been linked by hand — turning them on first would silently create empty duplicate accounts.
- Written up as a decision record (ADR 0021) so the reasoning is citable, with the parts of
  the old API contract it replaces marked rather than rewritten.
- **The sign-in screens are real.** Login asks for the authenticator code when the account has
  one; forgot-password and reset-password are React pages; an account section enrols an
  authenticator. The old signup page, the old forgot-password page and a route that accepted
  tokens from the browser are deleted.
- **Nobody is created twice.** Users who only ever signed in with Google or Microsoft are
  created and linked in advance by a script that dry-runs by default; password users migrate on
  their first sign-in. The switch itself (Flip 1) has not happened and waits for approval.
- Reviewed by a separate critic in three rounds; round two caught a script that would have
  locked every password user out on day one.

### Phase 3 — Data tier, written as code (2026-09-16)

Still nothing in AWS: the staging rehearsal load waits on the cost approval and on confirmation that patient data may be loaded.

- The database history is a five-step Alembic chain proven from an empty PostgreSQL 17 in CI; the last step moves patient identifiers into a locked `phi` schema and replaces them with a keyed token.
- The database, storage buckets, secrets and locked backup vaults exist as code (`data` stack); the network is split so the database can persist while everything billable by the hour is torn down between sessions.
- An S3 storage backend behind `STORAGE_BACKEND=s3`, a PHI split script whose key can never reach a log, a parity suite that compares both databases to the cent, and a journal-entry diff gate for later phases.
- Runbooks: data load, migrations, restore drill, secret rotation (including key rotation at head), database access, staging session.
- Reviewed by a separate critic: data tier passed in two rounds; the split and parity tooling took three rounds (a key-in-log critical and a constraint check that could never pass were both caught before anything ran).

### Phases 1–2 — AWS foundation and network, written as code (2026-09-15)

Nothing has been created in AWS yet: the cost estimate (`docs/reports/phase-1-cost-estimate.md`) waits for approval.

- The whole AWS setup now exists as code in `infra/` (AWS CDK, Python): security logging and alerts, budgets and cost-anomaly alerts, the DNS zone with every live record copied and checked, email sending (SES) ready to verify, sign-in administration (Identity Center), encryption keys, the private network, the load balancer, the CloudFront edge with a web firewall, and a locked-down admin path with no open ports.
- Every resource is named and tagged by rule; a check fails the build if a tag is missing; no account id is written anywhere in code.
- Runbooks: break-glass access, Identity Center bootstrap, DNS nameserver switch, secret rotation, staging teardown, database access.
- The database schema history is now managed by Alembic: the 37 Supabase files replay verbatim, a reconciliation step closes the 242 differences found against the live database, and row-level security keyed on the organisation is proven in tests.
- Reviewed by a separate critic in four rounds until no critical or high findings remained.

### Phase 0 — Inventory, safety sweep, harden in place (2026-09-15)

The first phase of moving Meridian onto Amazon Web Services. Nothing moved yet. This phase
was about knowing exactly what we have, getting things out of the repository that should
never have been in it, and fixing problems that would otherwise be carried to the new home.

#### The repository was cleaned out

What this repository can show for itself — the rest is a record kept outside it, because a
file that has been moved out leaves no trace here by design:

- **The ignore list now blocks client data from coming back.** `.gitignore` names the real
  mapping workbook, the employee and provider rosters, the seed SQL, the `Resources/` and
  `Examples/` folders, `data/input/` and every database file. Only redacted `*.example.*`
  copies are tracked.
- **There is a script that does the move, so it is repeatable and reviewable:**
  `scripts/move_client_data_out.py`. It has a `--dry-run` and prints what it would move, so
  anyone can see the rule before anything moves.
- **Other products and instance-identifying files are no longer in the working tree.** The
  scheduler, the code grader and the trial environment file are not here; their paths are
  ignored so a stray copy cannot be committed.
- The branches of work that had drifted apart were merged back together, so there is one
  current version of the code again instead of three.

#### The build now checks itself

- **CI runs the full backend test suite on every push and pull request.** Until now those
  tests existed but nothing ran them — only the front-end checks ran. It is worth being
  precise about what that does and does not guarantee: the build reports a failure, but this
  GitHub plan has no branch protection, so nothing *mechanically* prevents a red commit from
  being merged or deployed. Reading the result is still a person's job.
- The test machine installs LibreOffice on purpose, and fails the build if it is missing.
  Without it, the tests that verify spreadsheet numbers quietly skip and everything looks
  fine when it is not.
- Library versions are now pinned. Two builds a week apart used to install different
  versions of the libraries that calculate journal entries — meaning the same input could
  produce different numbers. They cannot now.
- Every change is scanned for accidentally committed passwords and keys, both before the
  commit is made and again in the build.
- Libraries we depend on are checked automatically for known security problems.

#### The founding documents

These did not exist before. They are the basis for everything that follows.

- A threat model: what could go wrong at each point where data crosses a boundary.
- A classification of exactly what patient information Meridian holds and where it sits.
- A map of what data leaves our systems, to whom, and carrying what.
- Full inventories of the database, the settings, the outside connections and the screens.
- Fifteen decision records explaining the choices behind the move and why.
- A record of how the domain name and email are set up today.
- A control matrix mapping every security and privacy requirement to what we do about it,
  where it is implemented and where the proof lives — plus a list of what only a person can do.

#### Security fixes

- **Names are no longer written to the logs.** Employee names and identifiers were being
  recorded in the system's activity logs. They are not any more.
- **Editing another organisation's roles is blocked.** An administrator could change the
  permissions of a role belonging to a different customer. Each of those places now checks
  ownership first, with a test that proves it.
- **The silent fallback to a local database is gone.** If one setting was missing, the
  system quietly wrote journal entries to a temporary local file instead of the real
  database — and the file disappeared on the next restart. It now refuses to start rather
  than pretend to work.
- **QuickBooks postings carry a request id**, so if a posting times out and is retried, the
  same journal entry cannot be booked to the customer's books twice.

## v1.3.52 — 2026-10-19
- **Ask Meridian no longer shows tokens or cost on the question screen**, not even to superadmins. This month's asks, tokens and cost by model now sit at the top of the Ask log page (superadmins only), next to each ask's cost. Every ask is still logged.

## v1.3.51 — 2026-10-18
- **Operations is ready for AWS**: it reads a slimmed copy of the Cobalt (eClinicalWorks) snapshot through the same audited door as Reports & dashboards, and every uncached request writes an opened and a closed audit row (`mart:operations.kpis`, `.claims`, `.portfolio`).
- **The copy keeps only the fields the screens use**: no payment check or ERA numbers, no billing logs or notes, and a diagnosis description is kept only when it is common and clean. Clinician NPIs are kept for now (one switch, `KEEP_CLINICIAN_NPI`, pending owner confirmation).
- **Andres runs the copy by hand for now**: `scripts/ecw_mart_staging/9-copy-cobalt.sh`, then `scripts/ecw_mart_production/10-copy-cobalt.sh`. Operations on AWS is as fresh as the last copy.

## v1.3.50 — 2026-10-18
- **Ask a question works on AWS** through Amazon Bedrock, with a $10 a month cap.
- **eCW data reaches the AWS app** through a nightly copy with the patient columns removed, and every read is logged. Reports & dashboards and Ask show numbers once it is deployed.
- **The Executive Report shows a red sample-data banner**, and only admins can open it.
- **A question grouped by something (like month) comes back sorted by it** when you haven't picked a sort.
- **The Collections column's collapse button is at the top**, so it's easy to fold away.

## v1.3.49 — 2026-10-18

- **Payroll DB, Operations, Reports & dashboards and Ask a question are now their own rights on Settings > Roles**: an admin can give or hide each per role, and the server enforces it; everyone keeps exactly what they had (Ask a question needs Reports & dashboards too).

## v1.3.48 — 2026-10-18
- A person whose role changed from admin to member no longer sees the admin's filter choices for up to an hour (small groups stay hidden).

## v1.3.47 — 2026-10-16
- Any question, saved question or report card can be downloaded as an Excel file in the Meridian Excel format. It follows the same "<11" rule for hidden small counts, and downloads of individual rows are logged.
- A whole report downloads as one Excel file: an Overview sheet plus one sheet per card.
- Any chart can be saved as a PNG picture from its menu (and from the question page's new Download menu).
- CSV files are now named after the question and date, and the CSV now writes "<11" for hidden small counts instead of leaving the cell blank, everywhere.
- The PDF shows Chicago time, repeats the filters on each tab, and says up front when the PDF maker is not set up.

## v1.3.46 — 2026-10-15
- Changing a report filter no longer leaves cards on "Too many requests": a card waits and retries (2 s, 4 s, then 8 s, up to ~90 s) while it shows loading; a card that timed out is run once more.
- Small tables on a narrow report tile drop to a tighter size when they still don't fit, so every column shows; very wide tables still scroll sideways.

## v1.3.45 — 2026-10-15
- Adding a question to a report with a Report day (Save → "Also add to a report", ⋯ → Add to report) now defaults to "Follow the Report day — add a daily copy": a fixed date, "this week" or "this month" becomes the Report day, and a question with no date filter gets one on the date you pick (the main date preselected). The original question is kept; trend charts and custom date ranges stay as they are; "Keep as is" is still there.
- The dashboard editor's Add question does the same silently when the conversion is clear, reuses an identical "(daily)" copy instead of making another, and removes copies it made if you cancel.

## v1.3.44 — 2026-10-15
- Ask Meridian no longer locks a question to today's date: "today" / "yesterday" written as a fixed date becomes a relative day, so the question follows a report's Report day.

## v1.3.43 — 2026-10-15
- A question saved with the "Automatic" chart type now shows the same chart on a report as on its own page (e.g. a bar chart), instead of a table.

## v1.3.42 — 2026-10-15
- A saved table's look (hidden columns, column order, number formats, color rules, compact rows) now shows on report tiles and on the question page after reload; drill and "See these rows" still work.
- A report tile keeps the question's saved chart look even if loading the question's settings fails (the report now carries them).
- Tables on a report tile fit the card: text wraps, tighter spacing, no sideways scroll for narrow cards.
- "Remove from report" in a tile's ⋯ menu for people who can edit the report, with a confirm; the question itself is kept.
- "Ask for related" under a question's result: Ask Meridian suggests 3–4 follow-up questions; clicking one runs it through Ask (same access, limits and monthly cap as Ask).

## v1.3.41 — 2026-10-15
- Fixed "A filter connection has a setting that is not allowed" when adding a question to a report or connecting a filter in the dashboard editor: the server now accepts the empty field the app sends with each connection.

## v1.3.40 — 2026-10-15
- Data browser and "learn about this table" pages, with safe sample values for category columns.
- Admins can edit table and column names, descriptions, types and hidden columns.
- Segments (saved filters) with a history of edits.
- Metrics catalog with the Operations metrics built in (no rate under 20 scheduled visits).
- Metrics now show in the Summarize step and segments in the Filter step.
- Models (saved questions used as data sources, with friendly column names) work in questions, dashboard filters (Report day included) and "See these rows".
- Warnings before deleting a model, metric or segment that other items use.
- Models, metrics, tables and segments appear in search and on the BI home page.
- Metabase export of models, metrics, segments and table metadata.
- Members can no longer see a filtered average/min/max (or any conditional total) on provider, diagnosis or procedure reports, which could reveal groups under 11; admins unchanged.
- Dashboard "See these rows" works again (it always failed with a missing dashboard id).

## v1.3.39 — 2026-10-15
- Add to report: with the search box empty, the Dashboard list now shows your pinned, recent and bookmarked dashboards instead of "No dashboards found".

## v1.3.38 — 2026-10-15
- Save question has an "Also add to a report" option: pick a dashboard and tab, and the new question is placed there right after it is saved.
- Adding a question to a report (from Save or the question's ⋯ menu) now shows a confirm step: for each report filter, the column it will follow (Clinic follows Location name when the question has no Clinic name column), or "Don't follow"; and for a "this week" question, keep the week or change to the Report day, which saves a "(daily)" copy and puts that on the report.
- Adding a question in the dashboard editor connects it to the report filters by the same column name or the Clinic ↔ Location name pair; it never guesses beyond that.

## v1.3.37 — 2026-10-15
- Report filter lists (like Clinic) open instantly after the first time: the choices are kept for an hour per person instead of being counted again on every click.

## v1.3.36 — 2026-10-15
- The chart on a question now carries its name as the title (the AI's title for an asked question, the generated "<count> by <group>" for a new one, the saved name for a saved one) instead of "Question results".

## v1.3.35 — 2026-10-15
- Ask Meridian (type a question, get a ready-made BI question) is now part of the app: it uses Claude Haiku 4.5 on Amazon Bedrock, with Sonnet only when the first answer fails the checks; the query goes through the same checks as a hand-built one.
- Faster: an ask takes about 10 seconds instead of up to a minute — the dropdown values are looked up in the background (never waited on), the big prompt is kept cached for an hour, small mistakes are fixed without a second AI call, and the screen shows progress ("Writing the query… 3s").
- Saving a question now fills in the name and description: the AI's title and one-line summary for an asked question, "<count> by <group>" for a hand-built one; report cards take their title from that name.
- Safety: a monthly AI spending cap per organization (BI_ASK_MONTHLY_CAP_USD, default $25); the ask log keeps only the shape of each query (numbers, dates and IDs removed); rare values (fewer than 11 records) are never shown to the AI; one timing line per ask in the server log.

## v1.3.34 — 2026-10-15
- Charts easier to read: a bar's number turns sideways inside the bar when it is wider than the bar (like the old staff reports), and on charts with bars and a line only the bars are numbered, so the target line's numbers no longer sit on top of the bar numbers.

## v1.3.33 — 2026-10-15
- Daily Report - Clinic: Patient collections now shows Target, Collected, Vs target and % for the day, the week and the period (target from eCW's expected patient payment per claim; DRAFT).
- New "Open notes days" card: per provider, open notes divided by their average completed visits per working day over the last 28 full days (DRAFT, to confirm with staff). Saved daily so past Report days can show it.
- Billable Nurse Visits row now has counts (completed "Nurse Visit" appointments).
- Fixed: Report day lookups now work for a reader without direct table rights.

## v1.3.32 — 2026-10-15
- Daily Reports get a "Report day" filter: pick a past day and the whole report is worked out as if that day were today (today, current week and period, closed-week averages, targets, next business days); nothing after that day counts. Leave it empty (or pick today) for the latest data.
- The daily data copy now also saves that day's open notes, Expected Visits and next-4-days schedule (totals by clinic and provider only), so later those cards can show a past day too; a day before recording started shows "Not recorded for this day".
- The daily copy job now reports a failure when it could not save that day's totals.

## v1.3.31 — 2026-10-15
- "Add to report" on a saved question: pick a dashboard and its tab, and the question is placed at the first free spot, already connected to the dashboard's filters when the match is clear (for example Clinic).
- A dashboard filter set to a value now replaces the question's own "equals" filter on the same column (a question saved for Bishop follows the Clinic filter) instead of combining with it and showing nothing.
- Adding a question in the dashboard editor connects it to the dashboard's filters the same way, and a double click adds it once.
- Re-creating the Daily Reports keeps the questions and tabs you added by hand.

## v1.3.30 — 2026-10-14
- Download PDF now makes 16:9 slides (the shape of a PowerPoint slide): each tab starts on a new slide with the header, cards keep the screen layout and continue on the next slide, and every slide shows "Page N of M". Letter pages are still a choice.

## v1.3.29 — 2026-10-14
- Daily Report PDF is easier to read: tables print at 12px with roomier columns (instead of 9px); wide week tables wrap into a second block, so the pages are longer but still one page per tab.

## v1.3.28 — 2026-10-14
- Daily Report dashboards now hold exactly what the old Bishop and All Clinics reports show, laid out like them: All Clinics is one "Daily report" page in two columns plus "Provider detail"; Clinic is one page. The clinic summary and the by-clinic table are one table each again, and the doctor tables end with a Total.
- Download PDF makes one page per tab by default (All Clinics 2 pages, Clinic 1, like the old reports); "Letter pages, for printing" is still a choice. Long week tables print whole.

## v1.3.26 — 2026-10-14
- Added read-only data views over the eCW data mart (fiscal weeks, per-clinic and per-provider daily/weekly numbers, targets, open notes, wait time, follow-up) for the dashboards.
- Rebuilt "Daily Report - All Clinics" and "Daily Report - Clinic" to copy the staff's old PDF reports on that data: fiscal weeks (W42 / P10 / Y26), targets with Vs target and compliance, show rate = completed / potential, Total = clinic + hospital.
- Patient feedback, booking capacity / fill rate, open notes days, billable nurse visits and the patient collections target show as quiet "Coming soon" boxes.

## v1.3.25 — 2026-10-14
- The downloaded PDF is now made for reading on a computer: Letter landscape pages laid out like the screen (cards side by side, tables whole, long tables continue with their header repeated).

## v1.3.24 — 2026-10-14
- Added a twice-daily read-only copy of the eCW data mart into the local `mart` schema (patient-identifying columns and patient-level tables left out), the base for moving dashboards off the Cobalt feed.

## v1.3.22 — 2026-10-13
- Dashboards redesigned: clear section headings with a one-line description, simpler number tiles ("Not posted yet" / "No data yet" instead of a bare dash), quiet dashed "Coming soon" boxes, plain column names (Day, Clinic, Provider, Week).
- Chart colors now come from Meridian's navy, blues and greys, and a category keeps one color on every chart (GYN, OB, MFM, PCP, Hospital, Other).
- Daily Report - All Clinics has 7 tabs (Overview, Clinics this week, Clinics next week, Visit detail, Providers, Provider detail, Notes); the Clinic report gets a Notes tab. Every number is still there; the notes no longer print.
- The downloaded PDF is made for reading on a phone: half-letter pages, one column, large text, wide tables split into readable blocks, page numbers.
- Reports & dashboards home: pinned and dashboards first, no repeated items, empty sections hidden.

## v1.3.21 — 2026-10-13
- "Download PDF" on a dashboard now saves a PDF file straight away (made on the server), instead of opening the print screen. The file name carries the dashboard, its filter values and the date, e.g. "Daily Report - Clinic - 001 Bishop - 2026-10-13.pdf". Portrait is the default.

## v1.3.20 — 2026-10-13
- Dashboards can be downloaded as a PDF: pick the tabs, landscape or portrait, and the PDF follows the dashboard layout with a header and page numbers. In edit mode a card can start a new page or be left out of the PDF.
- Dashboard cards are easier to read: titles wrap instead of being cut off, the "Showing 1 row · ms" line is gone from charts and numbers, and text and placeholder boxes have the normal light border instead of a black one.
- Daily Report: weekly charts show whole weeks only and start Aug 3, 2026 (where the eCW copy is complete), so they no longer dip at both ends. A "Payments posted through" tile shows the latest date eCW has posted, which explains a dash in today's or this week's collections.
- Number cards can show a date.

## v1.3.19 — 2026-10-13
- Reports & dashboards home: the page is now titled "Reports & dashboards", lists dashboards first, and saved questions are called reports when you browse them. "Build a question" left the side panel (it lives under "Ask a question"); SQL snippets and Trash moved to the bottom.
- Folders can be filtered to show all, only dashboards, or only reports.
- Daily Report - All Clinics now has every section of the staff PDF that eCW can supply: New OB by clinic and provider, per-doctor clinic, delivery, surgery and hospital follow-up visits, collections today/week/month, the combined all-clinics weekday summary, and 24 weeks of history.
- New OB now counts "New OB With Sono" visits (draft, staff to confirm). Hospital visits count when booked and not cancelled, because eCW never marks them completed.

## v1.3.18 — 2026-10-13
- New "Daily reports" folder with two live dashboards rebuilt from the Stella Mattina Daily Report: All Clinics (visits, clinic schedule this week and next, visit detail, collections, providers) and Clinic (pick a clinic with the filter).
- Numbers we don't have yet (targets, open notes, wait time, patient feedback, booking capacity) show as labeled placeholders until the other database is connected.
- New data for reports: confirmed and insurance-verified flags, line of service, visit category, provider type, and a Payments table for collections (draft groupings, to be confirmed by staff).
- Pivot tables now show totals on dashboards, percent formatting, and cleaner column names.
- Fix: admins' formula reports by provider and day were refused; they now run with exact numbers.

## v1.3.17 — 2026-10-13
- Click to drill on tables and charts: zoom in on time and number ranges, break out by clinic, provider or visit type, and use quick filters.
- Column header menu on tables: sort, filter, distribution, summarize, and summarize by time.
- Back and breadcrumbs after drilling, so you can step back to where you were.
- "See these rows" shows the individual rows behind a number (up to 2,000, de-identified).
- Every view of individual rows is recorded in an audit log that only Meridian superadmins can read.
- Admins now see exact small counts (no "<11"); everyone else is unchanged.
- Dashboard card click behavior: filter other cards, or link to a dashboard, a question or a web address, with an editor to set it up.
- Dashboard shortcuts: `e` to edit and `s` to save.
- Fixes: the pencil no longer overlaps card text, row charts are no longer cut off, and your first save no longer bounces off a missing security token.

## v1.3.16 — 2026-10-13
- Dashboards: build a dashboard from your saved questions, with a drag-and-resize grid you can also move with the keyboard.
- Add text, heading and link cards to explain your numbers.
- Tabs: split a dashboard into several tabs.
- Dashboard filters: date (including month, quarter and relative dates), category, number, ID and location, with default values.
- Per-card wiring: choose which cards each filter affects, link filters together, and optionally add an Apply button.
- Cards load in parallel, with their own rate limit so a big dashboard stays fast.
- Auto-refresh and fullscreen view for wall displays; a menu on each card.
- Dashboards live in folders and show up in search, bookmarks, pins, Popular and the trash.
- Dashboard history: see earlier versions and revert to one.
- Admins can export a dashboard in Metabase format.
- Fixed a bug where removing a dashboard tab could also delete cards just moved off it.
- Fixed a bug where moving a question card while its folder was moved could wrongly say "not found".
- Sidebar: "Ask a question" is one clear place to ask anything; "Reports & dashboards" holds saved questions, folders and dashboards.
- Appointment and claim reports run much faster (a filter on new patients went from timing out to under a second).

## v1.3.15 — 2026-10-13
- Search in Questions: press Cmd/Ctrl+K to find questions and collections by name or description (never by their SQL).
- Bookmarks: keep your own shortcuts to questions and collections, shown in the sidebar and on the home page.
- Pin an item to the top of a collection for everyone; pinned items show as cards above the list.
- Recently viewed and Popular (what the most different people opened in the last 30 days, with no names shown).
- A new Questions home page at /bi with Pinned, Recently viewed, Bookmarks and Popular.
- SQL snippets for admins: save a piece of SQL once and drop it into any SQL query with `{{snippet: name}}`.
- Keyboard shortcuts in Questions: `?` shows the list, `g` then `h` goes home, `c` then `q` starts a new question.
- Chart hover boxes leave out series with no value at that point (hidden small counts still show as "<11").

## v1.3.14 — 2026-10-13
- Questions page: save a question into a collection and open it again by its link. The creator or an admin can save changes, anyone can save an edit as a copy; saving SQL questions is for admins only.
- Collections: a private "My collection" that only you can see, shared collections inside each other, move, duplicate, move to the trash and restore (kept for 30 days), and bulk actions on several items at once.
- Question history with Revert: every save is kept (the last 50), and reverting adds a new entry instead of erasing anything.
- A new sidebar and breadcrumbs for the whole Questions area, plus a Trash page.
- Admins can export one question for another reporting tool.

## v1.3.13 — 2026-10-12
- Questions page, joins: a join can now keep all rows of the joined table, or all rows of both tables, and each join condition can compare with equals, not equal, less than, at most, more than or at least (two conditions make a range). Rows with no match show blank values.
- Summaries can be combined with math, like `Sum([Total charge]) / Count()` or `(Sum([a]) - Sum([b])) / Sum([a]) * 100`; dividing by zero gives a blank value, not an error.
- SQL mode: a new "Field filter" variable type stands for a whole condition on one data column (`WHERE {{region}}`): pick the table, the column and a filter type (text, number or date, including relative dates) and the values; with nothing picked it filters nothing.
- Small-count protection for all three: reports on diagnoses, procedures or provider-by-day counts refuse right and full joins and non-equal join conditions, only allow math over summaries that cannot expose a small group, and hide the result of math for groups under 11.

## v1.3.12 — 2026-10-12
- Questions page, joins: add up to three joined tables (keep all rows, or only rows that match). The columns that link two tables are suggested from the data's own links, and you choose which of the joined table's columns to show.
- Custom columns written as formulas, like a spreadsheet cell (`case(...)`, `concat(...)`, dates, math), with suggestions as you type, a list of functions, a Format button, and clear messages that point at the exact spot of a mistake. Formulas also work inside filters and summaries.
- Summarize again: after a summary you can filter, add a column, or summarize that result a second time (up to five stages). Each message from the server now lands on the right stage, with a plain note when a sensitive report refuses a step.
- A column checklist on the Data step to choose exactly which columns a question returns.
- Open as SQL: from View the SQL, organization admins can turn a question into SQL (a one-way step, with a warning that SQL has no small-count hiding).
- SQL mode for organization admins: a SQL box with `{{variables}}`, a panel to set each variable's type and value, Run (or run only the selected text), and the results as a table or a chart. It never runs by itself when you open a link. Members never see it, and the button is reachable on a phone too.
- Six more charts: pivot table, waterfall, scatter and bubble, box plot, treemap and sankey, each with settings. Counts under 11 are never drawn as zero: they are gaps, left out of totals, and shown as `<11`; totals that leave something out carry a star.
- Table settings: reorder columns, color rules (single values or color ranges, up to eight, first match wins) and mini bars.
- Series colors: pick a color for each series or pie slice from the chart palette.
- The Funnel chart in the Questions page now speaks Spanish.
- English and Spanish throughout.

## v1.3.11 — 2026-10-12
- New Questions page (Beta, in the sidebar for organizations with P&L by Provider): build a question step by step without writing SQL. Pick a table, filter by date, number, category or text, summarize and group by (dates by week, month and so on; numbers in bins), sort and limit. Each step has a Preview button that shows ten rows right there, and "View the SQL" shows exactly what will run.
- Results show as a table or as one of 12 charts (table, number, trend, progress, gauge, bar, row, line, area, combo, pie or donut, funnel). The page picks a sensible chart for the question and a Visualization button lists the others, best fits first. A Settings panel changes things like stacking, goal lines, labels, axis ranges and scales, and which columns show.
- Counts under 11 show as `<11` (never as zero, and left empty in the CSV), with a notice saying how many rows are hidden; in charts they are gaps or skipped slices.
- Problems from the server show next to the step that caused them; slow, unavailable and no-access cases each have their own message.
- The whole question, chart and settings are saved in the page link, so sharing or reloading the link brings it back.
- English and Spanish. New test that `/api/v2/me` reports the user's role in the organization.

## v1.3.10 — 2026-10-12
- BI query engine (backend only): a saved question written as JSON is checked against the analytics catalog and turned into one safe, parameterized SQL query over the analytics views, always limited to the signed-in organization, capped at 2,000 raw or 10,000 summarized rows and cut off after 10 seconds. New endpoints: `GET /api/v2/bi/catalog`, `POST /api/v2/bi/query` and `POST /api/v2/bi/query/compile` (shows the SQL without running it). Groups under 11 rows in diagnosis, procedure-code and provider-by-day summaries keep their row but show no numbers, and tricks that could reveal them (running totals, filtering on a count) are refused.
- Admin-only native SQL (`POST /api/v2/bi/native`): one read-only SELECT with `{{variable}}` inputs, run with its own read-only database login (`ECW_READER_USER` / `ECW_READER_PASSWORD`) and stopped by a timer if it runs too long; switched off unless that login is set and the data holds a single organization.
- An adapter that converts a question to and from Metabase's query format, for the later Metabase switch.

## v1.3.9 — 2026-10-12
- New analytics views in the eClinicalWorks snapshot database (appointments, claims, claim lines, diagnoses, facilities, providers, visit types) with dates, money and yes/no flags already typed and bad values turned into blanks. A script, `scripts/apply_analytics_views.py`, builds them safely and can create a read-only role that sees only these views.
- Operations now reads those views instead of the raw eCW data. The numbers are identical; the region, scheduling-mix and visit-type rules now live in one place in the database.
- Every Operations table footer shows how many rows it has and how long the query took.
- Operations page: Region, Facility, Resource and Dates are now pill filters (the date pill shows the dates it resolved to, and an X clears each one), and each card has an info icon, a menu with Download CSV and Full screen, and clear loading, empty and error states.
- New docs for the future BI tool: `docs/bi/metric-definitions.md` (every Operations metric in plain words plus SQL) and `docs/bi/metabase-metadata.md` (connection steps, security model, column tags).

## v1.3.8 — 2026-10-12
- QB MX payroll (named JE): an account with money that is not ticked "standard" in the QB account map is now written on its own line (and flagged as unmapped if it has no QB name) instead of its amount being folded silently into the cent adjustment on the last line.

## v1.3.7 — 2026-10-12
- Operations is now eight tabs: Region Overview, Patient Access, Volume & Productivity, Weekly Comparison, No-Show — Tracking & Recovery, Ultrasound Tracking, Billing and Portfolio.
- New Region and Resource filters beside Facility (Facility only lists the chosen region); everything stays in the page link.
- Sortable tables with color rules, mini bars, totals and row counts; values printed on the bars; a Miss / Watch / Meets legend.
- Patient Access: Booked > Kept > Arrived > Billed funnel with a steps-and-rates table, Show rate and Completion rate (each one formula), scheduling mix, cancel / no-show / reschedule cards, appointments by visit type and by hour.
- Weekly Comparison: this week against last week (same weekdays) by facility and provider, with arrows (green when no-show or cancel rates fall).
- Ultrasound, Billing and Portfolio come from claims: counts and amounts only, no patient lists. Claims reach a facility only through a recent appointment, so many show as Unassigned (shown, never hidden).
- Chart kit: DataTable, Funnel, StatPair, DashboardGrid, value labels and band legend.

## v1.3.6 — 2026-10-12
- New: Operations (beta), in the sidebar. Read-only no-show, access and volume dashboards from the eClinicalWorks snapshot: no-show rate by facility (Meets / Watch / Miss against a 10% target), hour, weekday, visit type, new vs. established and booking lead time; status mix, cancel and reschedule rates, lead time; completed visits by provider, facility, visit type and week. Filter by dates, facility and provider; the headline tiles compare with the previous period of the same length. Only past appointments count toward rates. Capacity and fill rate aren't in the eCW feed, so they aren't shown.
- Charts use Recharts (new dependency). They live in a reusable chart kit (`web/src/components/charts/`) for the upcoming report builder.

## v1.3.5 — 2026-10-08
- Payroll DB: new "Totals by person per period" view. One row per person per fiscal period, with their paychecks added together (most periods have two); the Paychecks column says how many. Downloads match.
- Payroll DB is now titled "Historical Payroll DB".
- Payroll DB: the Location filter finds Mexico people (Mexico runs carry no location, so they are listed as "Mexico").
- Typing in a text box or a pick-list no longer shows a second blue box inside or around it; one focus ring, on the box itself.
- QB USA: the ADP workbook is kept exactly as uploaded, beside the run's files.

## v1.3.4 — 2026-10-07
- New: Payroll DB (beta), in the sidebar. Everyone paid through QB USA and QB MX payroll, one line per person per pay run, in USD. Filters on top (search, country, pay dates, department, location, and more: employee, entity, pay type, QB class and department, amount range, hours, what they got paid for, new or missing people), totals by person, department, location, pay run or period, and two downloads: what the filters show, or everything. Read-only. USA people come from each run's review workbook; Mexico from the stored run. Only the newest completed run per period counts.

## v1.3.3 — 2026-10-07
- QB USA payroll: UNUM and BCBS charges for people not paid on the run (leavers still on the bill) are now split equally, to the cent, across everyone paid on that company, inside each person's benefits. They used to go to one Shared Services line. A month's redistribution list still comes first; the Shared Services line is used only when nobody on that company was paid. The review workbook lists each split and who was missing.

## v1.3.2 — 2026-10-05
- QB MX payroll: the provider's single-sheet export ("ACUMULADO…") now books the QuickBooks journal by department and NAME QUICKBOOKS position, read from the file. A row with no position stays grouped by department with Name blank. A file with no NAME QUICKBOOKS column stops the run and names it; nothing is booked.
- Mappings: new "MX payroll accounts" section. Choose the account each payroll-file column is booked to. A column not on the list still goes to Salaried Wages (71215) with a warning that now points here.
- QB USA payroll: a person can have a "QuickBooks name (LLC)" on US payroll people. On the LLC journals their lines are split by department and that name; everyone else stays grouped by department with Name blank.
- Mappings: US payroll people shows the location and department ADP gives each person (saved from each run) instead of "From ADP rules", and the edit form starts from them. Clicking a row in any Mappings table opens Edit.
- QB MX payroll: a severance (Indemnización) row in the single-sheet file is now booked like the rest of that person's pay, to Salaried Wages under their department and position, instead of in full to 21251.
- QB MX and QB USA payroll: a line whose amount is negative goes out as a positive credit; QuickBooks rejects negative debits.
- QB MX payroll: a NAME QUICKBOOKS header written slightly differently (other capitals or spacing) now stops the run naming the column it found.
- Mappings: Delete shows its confirm again (it closed the edit panel instead). Deactivating an MX payroll column asks first and says the money goes to 71215. Clinic groups and other rows that can't be edited open their details again. US payroll people: the LLC name is marked "Not used" for Stella Mattina Health people, and on a phone the ADP value says "From ADP".
- QB USA payroll: a QuickBooks name with * or ? no longer throws off the review workbook's totals; names are limited to 100 characters.
- Mappings → Providers: a provider's first and last day worked now save (they were sent to the wrong record). A provider with only a QB code can be edited on desktop, without a department to pick.

## v1.3.1 — 2026-10-02
- Mappings: editing US payroll people is now its own permission. Everyone who can open Mappings still sees the list; only a role with the second Configuration box ticked on Settings → Roles ("Can edit US payroll people") can change it. Administrators can always edit.
- Mappings: US payroll people no longer has a one-click Deactivate in the table. A person is switched off, or back on, inside Edit.
- QB MX payroll: when a raw provider file has the total column under a slightly different name (for example without accents), the run still stops, and the message now names the column it found and the exact name it needs. Nothing is booked.

## v1.3.0 — 2026-10-02
- Mappings: new "US payroll people" section, for organizations with QB USA payroll. Change a person's provider code, QuickBooks location or department, or switch them off, without a developer. A change applies from the next payroll run; journals already exported keep the old code.
- QB MX payroll: a raw provider file with no "Total Nómina - Cancelación Provisiones" column now stops the run and names the column, instead of booking with a warning. Nothing is booked.

## v1.2.3 — 2026-10-01
- QB MX payroll: a raw provider file is now tied, person by person, to its own total column ("Total Nómina - Cancelación Provisiones"). Money in a column that has no account is booked to Salaried Wages instead of being left out, and the results screen names those columns.
- QB MX payroll: the main and provision journals add up to the month to the cent (rounding cents go on the last main line); a difference of a dollar or more stops the run.
- QB MX payroll: a person with no department, or one the journal has no place for, stops the run and is named by employee number instead of being left out. A severance row is booked as before and is not tied to the total column.
- QB MX payroll: the month is read from titles worded "DEL MES DE SEPTIEMBRE DEL 2026", a pay date typed as text is formatted like a real date, and an amount typed as "1,000.00" is read as a number.
- QB USA payroll: a UNUM or BCBS bill with no charges for the month (for example last month's bill) stops the run instead of booking no benefits.

## v1.2.2 — 2026-10-01
- QB USA payroll: holiday pay that ADP's register carries in Gross Pay but under no earnings column (Labor Day, the 09-18 run) is booked with the person's regular wages when the register's own hours prove it is time at their regular rate. It no longer fails G2 and G3; pay under any other unknown code still does.

## v1.2.1 — 2026-09-30
- QB USA payroll: reads the client's hand-edited BCBS bill (headers lower down, upper-case and abbreviated) as well as the raw portal export.
- QB USA payroll: several ADP invoices for the same pay date and company (off-cycle runs) are all kept; only the same invoice number twice is a duplicate.
- QB USA payroll: an off-cycle invoice joins the previous or next pay run, whichever its gross wages tie to; none is dropped any more.
- QB USA payroll: the review workbook's G1/G3 control rows name every invoice merged into them.
- Upload preview: shows the date for ADP invoices, registers and the UNUM bill.

## v1.2.0 — 2026-09-29
- Every upload and every generated output (all processes) is now copied to Supabase Storage (`uploads` / `outputs`, under `{org}/{process}/{date}/`), so nothing is lost when Render redeploys. Kept 7 years; nothing is deleted automatically.

## v1.1.0 — 2026-09-29
- QB MX payroll: the QuickBooks JE is split by QuickBooks Name (NAME QUICKBOOKS) within each Class, matching the client's August 2026 upload.
- QB MX payroll: reads the USD columns and the exchange rate beside them (the peso block and the YTD rate were being picked up).
- QB MX payroll: JE numbers JE-NOM-{MM}main / JE-NOM-{MM}trans, descriptions by each JE's month, 30.334-day basis, zero lines dropped, cent difference booked on the last main line.
- QB MX payroll: a file with a blank NAME QUICKBOOKS or more than one FECHA stops with the rows to fix.

## v1.0.1 — 2026-09-24
- QB MX payroll: the upload step asks for the exchange rate (MXN per USD); a peso file without one is refused.
- Results screen: Grand total shows the journal entries' total instead of "—".

## v1.0.0 — 2026-09-24
- Version number shown in the sidebar.
- QB MX payroll: raw provider exports with a blank first row are read correctly (they used to book $0).
- QB MX payroll: "Cancelación Provisión" columns reduce cost whatever their sign.
- QB MX payroll: a run that reads $0 regular payroll fails instead of booking.
- Upload preview finds a `FECHA` date column below a title row.
