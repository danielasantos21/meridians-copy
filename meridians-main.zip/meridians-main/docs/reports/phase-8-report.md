# Phase 8 report — Hardening and production readiness (groundwork complete; deploy-time steps gated on approval)

**Date:** 2026-09-16 · **Branch:** `aws-migration` · **Plan:** `docs/aws-migration-plan.md` Phase 8 · **Critic:** round 1 FAIL (3 high), **PASS at round 2** (`f907c22`); the two round-2 mediums are fixed in the recording commit or carried as a tracker row.

## What was built

- **Read-only `cdk diff` in CI** on pushes to the two branches (post-review, by decision): an OIDC role that can assume only the CDK lookup role, template-mode diff, and a grep gate that fails the job on a removal or replacement of a database, key, bucket, user pool or backup vault. Pre-merge diffs are run locally; the account-wide reach of the lookup role is why (threat model §13.7.5).
- **Security Hub** standards FSBP, NIST 800-53 r5 and CIS v3; **Inspector** on ECR and Lambda with a working update path.
- **npm audit gate** with an expiring allowlist (four postcss advisories vendored in Next 15, reviewed by 2026-12-31); the Next.js critical advisory is closed by the lockfile refresh.
- **`docs/runbooks/production-readiness.md`**: every Phase 8 step with commands, evidence and owner; restore-drill cadence; Security Hub triage; the pen-test scope and an ASVS checklist for the FastAPI surface; the consolidated needs-a-human table (41 rows).
- **Threat model §13** for every surface added since Phase 0; **ADR 0026** defining "ready"; Macie deliberately off with a named decider and reversal triggers.

## Evidence

| Check | Result |
|---|---|
| Infra tests | 545 passed; synth clean |
| Workflows | all three parse; `infra-diff` skips cleanly until the role variable exists |
| Web | 1007 vitest passed incl. the audit-gate suite; `npm audit` gate exits 0 today |

## Not yet run — deploy-time (runbook §12)

Security Hub score and triage, Config conformance, GuardDuty/Inspector triage, the diff job actually running, ZAP baseline, restore drill and DR test, secrets rotation evidence, vault-lock verification, DNS/TLS checks, production deploy and bill check, smoke tests, and the pen test itself.

## Needs a human

- Set repository variables `AWS_DIFF_ROLE_ARN` (after the foundation stack deploys) and the four `deploy.yml` variables.
- Bootstrap a staging-only CDK qualifier with scoped execution policies before the first `deploy.yml` dispatch.
- Macie: confirm "off" (≈ $2/month, nothing to classify yet) or say when to turn it on.
- Fund and schedule the pen test.
