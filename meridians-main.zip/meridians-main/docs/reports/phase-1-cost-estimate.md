# Phase 1 cost estimate — for Andres's approval before any billable resource is created

**Date:** 2026-09-15, revised 2026-09-16 with the Phase 3 data tier (§2a, and the §2/§3 rows that moved) · **Status:** APPROVED by Andres 2026-10-01 — the ≈ $239 steady-state total (§3) and the production-only health canary (≈ +$10.40, T:55). Phase 6's ≈ +$4 (T:58) and Phase 8's ≈ +$3.10-3.70 (T:61) are still not approved: with them the steady state is ≈ $257, over the ~$250 ceiling. Alerts go to billing@meridiansgrp.com. **Security Hub is deployed off** (`-c enableSecurityHub=false`, ≈ −$5-20) and Macie is not built: SOC 2 evidence is not needed yet, HIPAA's core (CloudTrail, GuardDuty, Config, KMS) stays on. Turn Security Hub on with one foundation deploy when SOC 2 starts · **Source:** plan §5 (rates from this account's bill and the Pricing API) refined with the CDK foundation stack's actual resource list (`infra/meridian/stacks/foundation.py`).

All figures monthly, pre-tax unless marked; Texas data-processing tax ×1.066. Confidence per line as in the plan.

## 1. What would be created in Phase 1 (account level, once)

| Line | Pre-tax | Confidence |
|---|---:|---|
| CloudTrail second trail (management copy + S3 data events for `meridian-*` buckets) | 0.30 | MEDIUM |
| AWS Config recorder + delivery + HIPAA conformance pack (130 rules) | 9.00 | **LOW ($5–25)** |
| GuardDuty detector — base analysis + S3 data-event protection only | 8.84 | MEDIUM |
| Security Hub — FSBP + NIST 800-53 (there is no HIPAA standard in Security Hub; HIPAA is the Config pack) | 10.00 | **LOW ($5–20)** |
| Inspector (ECR image scans; no images until Phase 5a) | 2.00 | MEDIUM |
| IAM Access Analyzer (external-access analyzer, free; the paid unused-access analyzer is not created) | 0.00 | HIGH |
| KMS: 1 foundation CMK | 1.05 | HIGH |
| S3: audit (Object Lock) + Config buckets | 0.50 | HIGH |
| CloudWatch: trail log group (400 days) + 4 alarms | 2.40 | MEDIUM |
| SNS + AWS Budgets (3 budgets; first two free) | 0.60 | HIGH |
| Cost Anomaly Detection (3 monitors + 1 subscription) | 0.00 | HIGH |
| **Foundation subtotal** | **≈ 34.70** (range 28–57) | |
| × 1.066 | **≈ 37** | |

Not billable in Phase 1: Identity Center, AWS Organizations (free), IAM roles, the GitHub OIDC provider, SES domain verification (sandbox).

### What "Phase 1" actually bills — three numbers, not one

The ≈ $37 above is the **foundation stack alone**. Two other Phase 1 stacks cost money the moment they deploy, and the earlier version of this report folded them in inconsistently. Stated separately so the approval is unambiguous:

| Deploy | Adds, taxed | Note |
|---|---:|---|
| `meridian-shared-foundation` | **≈ 37** | The table above. Once, for the account. |
| `meridian-shared-dns` | **+ 0.50** | The Route 53 hosted zone (ADR 0017), plus a few cents of queries. Once, for the account. |
| `meridian-<env>-data` | **+ ≈ 5 per environment** | Five customer-managed KMS keys at $1/key/month, ×1.066. Charged per environment, and **only once that environment's data stack is deployed** — so staging alone is +$5, staging and production together +$10. Phase 3 fills this stack in; §2a below prices it. |
| `meridian-<env>-vpc` | **0** | Added in Phase 3 by the ADR 0020 split. A VPC, six subnets, an internet gateway, two gateway endpoints and four security groups: **none of them is billed**, which is the entire argument for persisting it. |
| `meridian-shared-identity` | 0 | IAM and Identity Center are free. |

So "Phase 1, everything deployed, staging only" is **≈ $42.50/month taxed**; with production's data stack as well, **≈ $47.50**.

### Config records every resource type — deliberately, and it is the line to watch

The Config recorder runs with `AllSupported: true`, which means it records configuration items for **every** resource type in the account, **including the other owner's** (ADR 0001). That is the single biggest driver of the LOW-confidence $5–25 Config line, and it is the obvious thing to cut.

It stays on. The conformance pack is 130 AWS-authored rules spanning resource types across the whole account, and a rule whose resource type is not recorded does not fail — it reports `NOT_APPLICABLE`, which in a compliance report reads exactly like a pass. Scoping the recorder to "the types Meridian uses" would therefore convert an unknown number of HIPAA controls into silent no-ops, and the list would need revisiting every time a later phase introduces a service. A wrong bill is visible within a month; a control that is quietly not evaluated is not visible at all.

**If the Config line lands at the top of its range**, the fix in preference order is: (1) drop the daily snapshot to weekly, (2) scope the recorder to Meridian's resource types *plus* all IAM and global types, and record in `docs/compliance/` exactly which conformance-pack rules that makes `NOT_APPLICABLE`, (3) only then consider narrowing the pack itself. Do not do (2) without writing down (2)'s second half.

### GuardDuty: which features, and why it matters to this number

The detector's feature set is pinned in `infra/meridian/stacks/foundation.py` (`GUARDDUTY_FEATURES`) rather than left to AWS's defaults, because otherwise the enabled features — and so this line — are whatever AWS ships on the day of the deploy.

| Feature | State | Why |
|---|---|---|
| base detector (CloudTrail, VPC flow logs, DNS logs) | always on | Not a feature; it is the detector. The $8.84 is essentially this. |
| `S3_DATA_EVENTS` | **ENABLED** | The one extra we buy. It is how GuardDuty sees reads and writes against the future `meridian-<env>-s3-phi` bucket. Billed per million events; negligible at this volume. |
| `EBS_MALWARE_PROTECTION` | **DISABLED** | EC2 volume scanning, billed per GB scanned. Meridian runs no EC2 workload. This is the expensive default. |
| `EKS_AUDIT_LOGS`, `LAMBDA_NETWORK_LOGS`, `RDS_LOGIN_EVENTS`, `RUNTIME_MONITORING` | **DISABLED** | Nothing in the estate produces these yet. Revisit `RDS_LOGIN_EVENTS` in Phase 3 when RDS exists — it is cheap and it watches the database that will hold PHI. |

**Malware Protection for S3** is separate from all of the above: it is configured per bucket, billed per GB scanned, and is attached to the `phi` upload bucket in the Phase 3 data stack — not here, and not in this number.

## 2. Per environment (created in Phases 2–3, listed now so the whole picture is approved once)

| Environment | State | Pre-tax | Taxed |
|---|---|---:|---:|
| Staging | idle (`vpc` at $0 + `data`: RDS `t4g.micro` **stopped**, buckets, 5 CMKs, 4 secrets, locked vault) | ≈ 12 | ≈ 13 |
| Staging | during a session (+ NAT, ALB, api/web tasks, WAF, logs, RDS running), pro-rated | ≈ 125 (≈ $4/day) | ≈ 133 |
| Production (from Phase 8) | single-AZ, before the Phase 11 worker | ≈ 197 | ≈ 210 |
| Production | steady state with worker + SQS (Phase 11+) | ≈ 212 | ≈ 226 |

**The Phase 3 data tier does not move these numbers, and it is worth saying why**, because
§2a adds ~$6.30 taxed to staging idle and ~$34 to production. Both were already in the
plan's §5 figures — the ~$13 staging idle line has always meant "the data stack's stopped
database, buckets, keys and secrets", and production's ≈ $210 has always carried an RDS
line. §2a is those lines itemised against the CDK that now exists, not new spend. The two
genuinely new items are the **DR vault's KMS key** (+$1.07 taxed per environment) and the
**cross-region copy** (+$0.43/$0.85), together under $2.50 across both environments.

**The ADR 0020 split costs $0.** Everything moved into the persistent `vpc` stack — VPC,
subnets, internet gateway, gateway endpoints, security groups — is free. The alternative
considered and rejected was to stop destroying the whole network stack, which would have
left the NAT gateway standing at **$37.50/month per environment** and taken staging idle
from ~$13 to ~$51, past its own $75 budget before anything ran.

### 2a. The data tier (Phase 3), priced

New in Phase 3: RDS, three S3 buckets, three more secrets, the AWS Backup vault and its
cross-region copy. Everything here is in `meridian-<env>-data`, which **persists** — so the
staging column is what staging costs when nobody is using it.

| Line | Staging idle (stopped) | Staging running | Production | Confidence |
|---|---:|---:|---:|---|
| RDS instance hours — `t4g.small` prod / `t4g.micro` staging, single-AZ (D-14) | 0.00 | 12.41 | 23.36 | HIGH |
| gp3 storage, 20 GB at $0.115/GB — **billed while stopped** | 2.30 | 2.30 | 2.30 | HIGH |
| Automated backup storage, 7 days PITR (free up to 100 % of allocated storage) | 0.00 | 0.00 | 0.00 | HIGH |
| **RDS subtotal** | **2.30** | **14.71** | **25.66** | |
| AWS Backup — 35-day vault, ~20 GB warm at $0.05/GB (**daily in production; staging is one on-demand point per session**, M-2) | 0.50 | 0.50 | 1.00 | MEDIUM |
| AWS Backup — cross-region copy to `us-west-2`, storage + transfer | 0.40 | 0.40 | 0.80 | **LOW** |
| S3 — three buckets, ~50 objects plus JE output; Object Lock and versioning add no rate | 0.30 | 0.50 | 1.00 | MEDIUM |
| S3 — the `archive` bucket (added 2026-09-16, ADR 0020 §5b): empty until Phase 10, then **one** compressed `pg_dump` of a few tens of MB at $0.023/GB-month | 0.00 | 0.00 | 0.01 | HIGH |
| Secrets Manager — 3 new at $0.40 (db-app, db-phi, phi-hmac-key) | 1.20 | 1.20 | 1.20 | HIGH |
| KMS — **unchanged at 5 keys**: the `audit` bucket reuses the `logs` CMK (ADR 0020 §6) | — | — | — | HIGH |
| KMS — the DR vault's own key, in `us-west-2` (regional; `us-east-1` keys cannot encrypt there) | 1.00 | 1.00 | 1.00 | HIGH |
| CloudWatch — 2 RDS log groups, 400 days, CMK | 0.20 | 0.40 | 0.60 | MEDIUM |
| GuardDuty Malware Protection for S3 — $0.60/GB scanned, phi bucket only | 0.00 | 0.30 | 0.60 | **LOW** |
| Performance Insights — **enabled**, free tier (7 days, default metrics) | **0.00** | **0.00** | **0.00** | HIGH |
| EventBridge Scheduler — 1 schedule, 30 invocations/month (14 M free) | 0.00 | 0.00 | 0.00 | HIGH |
| SQS dead-letter queue + SNS topic for the stop schedule (M-1), and from Phase 6 the EventBridge Pipe that drains it. **The CloudWatch alarm this line used to name was withdrawn** (ADR 0020 §7c); an age alarm replaced it, and alarms 1-10 are free anyway | 0.00 | 0.00 | 0.00 | HIGH |
| **Data-tier subtotal, pre-tax** | **≈ 5.90** | **≈ 19.01** | **≈ 31.86** | |
| × 1.066 | **≈ 6.30** | **≈ 20.30** | **≈ 34.00** | |

Five lines are worth a sentence each:

- **The stopped instance still bills for storage.** $2.30/month is the floor of a staging
  database that nobody is running, and it is most of what "staging idle ≈ $13" is made of.
  D-15's nightly stop saves the $12.41 of instance hours, not the disk.
- **Performance Insights is $0.00 because the free tier covers it** — and an earlier
  version of this line said the opposite. It claimed AWS does not support Performance
  Insights on `db.t4g.micro` / `db.t4g.small`; that is a MySQL and MariaDB rule, not a
  PostgreSQL one (critic H-3). `describe-orderable-db-instance-options --engine postgres
  --engine-version 17` lists both classes with `SupportsPerformanceInsights: true`, so it
  is now **on in both environments** at the free settings: 7 days of retention and the
  default metric set, which is $0.00/month at any instance size. The number in the table
  does not change; the reason does. Paid retention (up to 24 months) would be ~$0.02/vCPU-hour
  and is not enabled. `pg_stat_statements` stays alongside it. ADR 0020 §3b.
- **The stop schedule's dead-letter queue and alarm are $0.00.** One SQS queue taking at
  most one message a day is inside the 1 M-request free tier for ever, and one CloudWatch
  alarm is inside the 10-alarm free tier. The SNS topic has no subscribers yet (ADR 0020
  §7c). Critic M-1.
- **KMS does not move.** The `audit` bucket reuses the `logs` CMK rather than taking a
  sixth key (ADR 0020 §6), so the $5/environment from §1 is unchanged. The one new key is
  the DR vault's, and it has to be new: a KMS key is regional.
- **The cross-region copy is the LOW-confidence line.** Storage is predictable; the
  first-copy data transfer out of `us-east-1` is not, until there is a month of it. If it
  lands high, the lever is copying weekly instead of daily — which lengthens the DR
  recovery point and therefore needs an ADR 0007 conversation, not a config change.
- **Malware Protection is billed per GB scanned**, so it is zero while nothing is uploaded
  and rises with real workbooks. A period's billing export is a few MB; even a busy month
  is well under a dollar.

### The network and edge line, corrected (finding L-5)

ADR 0018 originally carried the WAF as "$8.60 + rules" and the per-environment network
and edge as ≈ $75/month. The WAF figure was wrong. AWS bills a web ACL at **$5.00/month
+ $1.00 per rule per month + $0.60 per million requests inspected**; this ACL has
**six** rules, and Meridian's request volume is well under a million a month, so the
line is **$11.60**, not $8.60.

The sixth rule is `meridian-body-size-non-upload` (finding M-K, ADR 0018 §8): it blocks
request bodies over 64 KB outside `/api/v2/`, and it costs **$1.00/month** — the price
of narrowing "body inspection is off for every POST in the product" to "body inspection
is off on the upload prefix". That is the cheapest line in this report per unit of risk
removed.

| Line | $/month | Confidence |
|---|---:|---|
| NAT gateway (730 hours at $0.045; ADR 0018 §1 chose one, not one per AZ) | 37.50 | HIGH |
| ALB (730 hours at $0.0225 + a nominal LCU) | 24.73 | HIGH |
| WAF: $5 web ACL + $1 × 6 rules + requests | 11.60 | HIGH |
| CloudFront (PriceClass 100, low volume, no cache on dynamic paths) | ~1.00 | MEDIUM |
| VPC flow logs + WAF logs to CloudWatch (400 days, CMK) | ~1.50 | MEDIUM |
| Ops instance `t4g.nano` (staging default on, production default off) | 3.10 | HIGH |
| **Per-environment network + edge** | **≈ 79** | |

The origin-verify secret's $0.40 has moved off this line and onto the `data` stack's,
with the secret itself (finding L-6). WAF logging (L-4) is new and is the reason the
logs line went from ~$1.00 to ~$1.50; at Meridian's volume the WAF log group ingests
tens of megabytes a month.

**+$4 per running environment against the earlier figure** ($3 for the corrected web
ACL price, $1 for the sixth rule). It does not move the approval: staging pays it only
during a session, and production's ≈ $209 taxed already carried a WAF line that was
understated by most of it.

## 3. Totals against the ~$250/month ceiling

| Period | What is running | Taxed / month |
|---|---|---:|
| Phase 1 (now) | foundation only | **≈ 37** |
| Phase 1 (now) | foundation + dns | **≈ 37.50** |
| Phase 1 (now) | foundation + dns + staging data-stack keys | **≈ 42.50** |
| **Phase 3 (staging data tier deployed)** | foundation + dns + staging `vpc` ($0) + staging `data` with RDS **stopped** | **≈ 44** |
| Phases 2–7 | foundation + staging idle (+ ≈ $12–40 per phase for staging sessions) | **≈ 50** + sessions |
| Phase 8–9 (production deployed, Render + Supabase still paid ≈ $57) | foundation + staging idle + production | **≈ 260 AWS** + 57 |
| Steady state after Phase 10 | production + staging idle (foundation included in production's security lines) | **≈ 239** |
| **+ Phase 6 observability, as deployed — AWAITING APPROVAL** | 27 alarms in staging / 26 in production (first 10 free, then $0.10 each), 1 dashboard/env (first 3 free), 9 log metric filters/env (8 patterns, the 5xx one on both application log groups) ($0, they are filters not custom metrics until they match), 6 EventBridge rules + 2 stop-schedule rules + 1 custom bus (staging only; AWS-service events are free, and ~30 custom PutEvents a month is $0.00003), 1 EventBridge Pipe (staging only, ~30 invocations/month), 1 log group (staging only, a few KB) | **≈ +4** |
| **+ the health canary, IF approved** — production only | Synthetics, 1 canary at 5-minute intervals: ~8,640 runs × ≈ $0.0012 | **≈ +10.40** |
| **+ the health canary, IF approved** — both environments | as above × 2 | **≈ +20.80** |

**The ≈ $239 approved total is unchanged; the three rows above are additions to it, and NONE of them is approved.**
Phase 6's own ≈ $4 fits inside the ≈ $11 of headroom — but *fitting inside the headroom is not
the same as being approved*, and an earlier draft of this paragraph said it "needs no decision",
which was this document deciding a spend on Andres's behalf. The rule is any rise above the
approved total, not any rise that can be absorbed: ≈ $239 → **≈ $243**, and it is his to say yes
to. `docs/migration-tracker.md` carries it as an open row and ADR 0024 §7 lists it beside the
canary. The canary is the larger and separate decision:
production-only takes the steady state to ≈ $249, which is *at* the ~$250 ceiling with no headroom
left, and both environments takes it to ≈ $260, which is over it. That is why the canary ships
switched off behind `-c enableCanary=true` (ADR 0024 §8) with an open row in
`docs/migration-tracker.md` naming Andres as the approver — a stack does not get to make a spend
decision. The ≈ $4 line assumes the log metric filters keep matching nothing; once the JSON
formatter lands they publish custom metrics at $0.30 each per month, which is another ≈ $2/env and
should be re-measured rather than re-estimated.

The plan's ≈ $239 steady-state figure already contains the foundation's security services (Config, GuardDuty, Security Hub, Inspector, Access Analyzer, CloudTrail); the foundation is not additive to it. Headroom is thin (≈ $11): if Config and Security Hub both land at the top of their ranges, production alone is ≈ $250. Levers in that case: a Compute Savings Plan after one measured month (≈ $13–20), or dropping the NIST standard in Security Hub (≈ $3–5).

**What Phase 3 changes here: about $2.50 across both environments**, and nothing structural.
§2a's data-tier lines were already inside the ≈ $13 staging-idle and ≈ $210 production
figures; the genuinely new money is the DR vault's KMS key and the cross-region copy. The
≈ $44 row above is the first one that is not a forecast — from the Phase 3 deploy onward it
is a bill, and the first real month is what should replace §2a's LOW-confidence lines.

**Three levers exist here if the ceiling gets tight**, in preference order, and each has a
decision attached rather than being a config change: drop the cross-region copy to weekly
(lengthens the DR recovery point — ADR 0007); shrink production to `t4g.micro` (D-14 sized
it for ~76 000 transactions); drop the RDS log exports to `postgresql` only (loses the
upgrade record). None of them is worth doing pre-emptively.

## 3b. Phase 12 — pending approval (added 2026-09-24, T01)

> **Not approved. Nothing here changes the ≈ $239 approved total above.** These are the lines
> Phase 12 (the `/api/v3` platform) would add once its resources are deployed. Each is a rise above
> the approved total and needs Andres's yes before it is created. Source of the work:
> `docs/reports/phase-12-plan.md` §8.2; decisions in ADRs 0037, 0038, 0042.

**What the pricing check found** (public AWS pages only, read 2026-09-24; no AWS account call, no
Pricing API call):

| Finding | Confidence | Source |
|---|---|---|
| **No monthly fee per machine-to-machine (M2M) app client.** AWS removed that price dimension on 3 Nov 2025. The pricing page: "There is no additional charge for the number of app clients you have registered in your account." The Phase 12 plan's "~$6 per client" line is obsolete. | HIGH | https://aws.amazon.com/about-aws/whats-new/2025/11/amazon-cognito-removes-machine-machine-app-client-price-dimension ; https://aws.amazon.com/cognito/pricing/ |
| **$0.00225 per successful M2M token response** (= $2.25 per 1,000), billed monthly; **no free tier** for M2M tokens. $0.002925 only with multi-Region replication, which Meridian does not use. | HIGH | https://aws.amazon.com/cognito/pricing/ |
| **Two active secrets per app client** (`AddUserPoolClientSecret` / `DeleteUserPoolClientSecret`), so rotating a client's secret needs no second app client and costs nothing. | HIGH | https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-settings-client-apps.html ; https://docs.aws.amazon.com/cognito-user-identity-pools/latest/APIReference/API_AddUserPoolClientSecret.html |
| The existing placeholder machine client (`infra/meridian/stacks/auth.py:636-663`) **costs nothing** while nothing requests tokens with it. | HIGH (follows from the two rows above) | as above |

**Re-priced monthly lines (pre-tax; × 1.066 Texas tax for the taxed figure):**

| Line | Estimate | Confidence | Basis |
|---|---:|---|---|
| Cognito M2M app clients | **$0.00** | HIGH | no per-client fee |
| Cognito M2M tokens — a script run a few times a day (~90 tokens) | ≈ $0.20 | MEDIUM (volume is a guess; price is HIGH) | 90 × $0.00225 |
| Cognito M2M tokens — a client holding a cached 15-minute token all day, every day (~2,880 tokens) | ≈ $6.48 | MEDIUM | 96/day × 30 × $0.00225 |
| Secrets Manager, one per webhook subscription (1-2) | $0.40-0.80 | HIGH (from the plan, not re-read today) | $0.40 per secret |
| CloudWatch: ~5 more alarms + ~4 matching metric filters | ≈ $1.70 | MEDIUM (from the plan) | $0.10/alarm, $0.30/metric |
| WAF: one more rate rule (`/api/v3`), production | $1.00 | HIGH (from the plan) | $1 per rule |
| EventBridge, SQS, Lambda webhook sender | ≈ $0.00 | HIGH (from the plan) | free tiers at this volume |

**Lines the T21 `cdk synth` shows that the table above does not name** (2026-09-24; all behind
`-c enableApiPlatform=true`, off by default, so none is billed until the flag is deployed). Each is
inside the rounding of the scenarios below, which are unchanged:

| Line | Estimate | Confidence | Basis |
|---|---:|---|---|
| Daily idle-client sweep: one Fargate api task (1 vCPU / 2 GB arm64) for ~1 minute a day, started by EventBridge Scheduler | ≈ $0.02-0.05 | MEDIUM | ~30 task-minutes/month at the api task's size; Scheduler is inside its free tier. Created only when `-c apiIdleSweepActor` is also passed |
| KMS requests on the existing `logs` CMK from the two webhook queues, and Secrets Manager `GetSecretValue` calls from the sender | ≈ $0.00-0.05 | MEDIUM | $0.03 per 10,000 KMS requests, $0.05 per 10,000 secret reads; SQS reuses a data key for 5 minutes. **No new CMK** — the queues use the existing `logs` key |
| Webhook sender's log group (400-day retention) and the NAT data processing for outbound webhook POSTs | ≈ $0.00-0.10 | MEDIUM | ids-only log lines; a few KB per delivery at $0.045/GB NAT processing. No new NAT hours — the sender uses the NAT `edge` already runs |

The synth adds **2** alarms and **1** metric filter (DLQ depth; machine-token refusals), inside the
"~5 alarms + ~4 metric filters" line above. The plan's other two alarms (new client IP, scope
change) are not built: nothing emits those events yet (`docs/migration-tracker.md`).

| Scenario | Pre-tax | Taxed | Steady state |
|---|---:|---:|---:|
| One light machine client + 1-2 webhook subscriptions | ≈ +$3.30-3.70 | **≈ +$3.50-3.95** | ≈ $239 → **≈ $243** |
| One always-on machine client + 2 subscriptions | ≈ +$9.98 | **≈ +$10.64** | ≈ $239 → **≈ $250** (at the ceiling) |
| Plan §8.2's original figure, for comparison | ≈ +$9-12 | ≈ +$10-13 | ≈ $249-252 |

Not included, and each its own decision: one-off staging sessions for the sandbox, ZAP and the
end-to-end test (≈ $20-35 once); the partner mTLS surface (≈ $1-3 plus an optional ≈ $8-10
regional WAF, only if a PHI partner signs — ADR 0042); the unapproved Phase 6 ≈ $4 and canary rows
above. With the Phase 6 ≈ $4 also approved, the light scenario is ≈ $247.

## 4. Budgets and alarms that enforce this (in the foundation stack)

**Precondition, and it is a real one.** The two per-environment budgets filter on the `Environment` cost-allocation tag. A resource tag only becomes a cost-allocation tag once it is activated in Billing (`aws ce update-cost-allocation-tags-status …`, `infra/README.md` → "Pre-deploy checks"). Until that is done, **both environment budgets report $0.00 for ever** — no error, because a filter that matches nothing is a valid filter — and the only budget doing any work is the unfiltered $300 account one. Activation is not retroactive and takes up to 24 hours, so it has to happen before the spend it is meant to catch.

- `meridian-staging`: limit $75, alert at 40 % actual ($30) and 100 % forecast.
- `meridian-production`: limit $250, alert at 60 % ($150) and 100 % forecast.
- Account-wide: $300 (this also sees the other application's spend on the shared account — its ≈ $162/month of assistant-app + Bedrock cost is not Meridian's and is excluded above).
- Cost Anomaly Detection: **$0.00 — now in the foundation stack** (finding H-3). It was deferred to Phase 2 on the reasoning that it needs tagged spend to learn a baseline from; that was right about the baseline and wrong about the conclusion, because the monitors have to *exist* before they can start learning, and creating them costs nothing. Three monitors and one subscription, **but the stack creates only two of them**:
  - one `CUSTOM` monitor per environment, filtered on the `Environment` cost-allocation tag — a per-environment baseline is the useful one, since staging is spiky by design and production is not, and one combined monitor would learn neither. `CUSTOM` monitors have no per-account limit, so these two are always created;
  - one `DIMENSIONAL` monitor on `SERVICE`, **account-wide and unfiltered**, which is the only thing that sees untagged spend and the other owner's (ADR 0001) — precisely what the tag-filtered pair are blind to. **AWS allows exactly one of these per account, and this account already has AWS's own `Default-Services-Monitor`** (finding H-G — `aws ce get-anomaly-monitors` confirms it). Creating a second fails part way through the changeset and rolls the whole foundation stack back, so `enableServiceAnomalyMonitor` defaults to **false** and the subscription attaches to the existing monitor by ARN via `-c existingServiceAnomalyMonitorArn=...`. Attaching is a reference, not ownership: nothing in this stack can change or delete it. Still $0.00 either way;
  - one subscription to `meridian-shared-sns-security-alerts`, **DAILY**, at a **$20 absolute** threshold (`ANOMALY_TOTAL_IMPACT_ABSOLUTE`). Absolute, not percentage: on a ~$40/month account a percentage threshold fires on rounding. $20 is about 8 % of the ~$250 ceiling and roughly half a month of a NAT gateway somebody forgot to destroy.
  
  **Two caveats.** The two `CUSTOM` monitors share the budgets' manual precondition — the `Environment` tag must be activated as a *cost-allocation* tag in Billing or they monitor nothing, quietly; the `SERVICE` monitor needs no activation and works from day one, which is a second reason it exists. And `AWS::CE::*` is a global service with a **us-east-1-only endpoint**: CloudFormation will only create these resources in a `us-east-1` stack. The estate is all `us-east-1` (plan §1), so this is satisfied today — the foundation and network stacks now *assert* it at synth whenever the region is concrete — but it is a real constraint on ever moving the foundation stack, and the monitors would have to stay behind.
- Amazon Macie (PHI discovery in S3): **still deferred, now past Phase 3.** `AWS::Macie::Session` is account-level and the foundation stack is not Phase 3's to change, so Phase 3 attaches GuardDuty Malware Protection to the `phi` bucket (priced in §2a) and leaves Macie to a foundation change with a tracker row behind it. It is billed per GB classified, so enabling it before the Phase 3 step 11 load buys nothing and starts a meter. It is not in any figure in this report.

## 5. What I need from you

Reply "approved" (or with changes) to this estimate. Until then no billable resource is created — the CDK app only synthesizes. The existing `meridian-monthly` ($50) and `meridian-trial` ($60) budgets stay until the trial instance is torn down (Phase 3, with your go-ahead).
