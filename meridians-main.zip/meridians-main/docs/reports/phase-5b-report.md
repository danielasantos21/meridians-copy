# Phase 5b report — the last Jinja screens leave, in React over `/api/v2`

**Date:** 2026-09-16 · **Branch:** `aws-migration` · **Plan:** `docs/aws-migration-plan.md` Phase 5b · **Critic:** rounds recorded in `critic-log.md`.

> **Status: written.** "What was built", the evidence, the open items and the accepted risks
> are complete; the lead completes the critic line as each round closes.

## What was built

- **The `jinja` allowlist is empty.** Six Jinja families went in two slices: `/profile` (a
  redirect to `/settings#profile`), `/superadmin`, `/config/mx-employees`, `/logout` and
  `/wearbly` in one; `/invoice` in the other. Each with its Flask routes, its templates and
  its Next proxy handler, and `infra/meridian/edge_paths.py`'s pin went from 15 ALB patterns
  to three — `/auth/*`, `/api/*`, `/static/*`.
- **The invoice wizard is React** (`web/src/app/invoice/`) over a new `/api/v2/invoices`
  resource. The draft lives in the page, not in a Flask session, so a refresh cannot lose it
  and two tabs cannot merge into one document; the server keeps nothing between steps, which
  is also what makes the resource safe under more than one api task.
- **The invoice number is spent before the document is rendered.** `create_invoice` writes
  the row (allocating, and retrying once onto a fresh number if revision 0007's unique index
  refuses the one the form showed) and renders under the number the row ended up carrying —
  so a document can never go out under a number the database disagrees with.
- **`POST /api/v2/invoices/{id}/render`** (round 1, P5AR5-03), for the one state that
  ordering can leave: the row exists, its number is spent, and the render failed after it.
  It produces the missing document from the stored row under the row's own number, refuses
  (409 `INVOICE_ALREADY_RENDERED`) an invoice that already has one, and the create's failure
  message no longer says "raise it again" — which would spend a second number.
- **`GET /{id}/download` has three answers, not two** (round 1, P5B-05): 404 for an id this
  organization does not have, **409 `INVOICE_NOT_RENDERED`** for a row that is recorded with
  no document, and its own 404 for a filename whose file has left the disk. The React history
  hides the download link for such a row and offers "Produce the document" instead.
- **ADR 0011's one audited function exists** — `src/pg.with_superadmin`, with Alembic
  revision `0010_superadmin_org_list` behind it — and, from round 1 (P5B-01), **every**
  superadmin surface path goes through it, including the module write. One
  `audit.superadmin_access` row per organization reached, written before the read, with its
  own reason.
- **The superadmin console fails closed on an unreadable module set** (round 1, P5B-06):
  `enabled_modules: null` plus `modules_error: true`, never the fail-open "every module this
  product has" that invited a superadmin to switch off a module that was never on.
- **The sidebar's Invoices link is gated on `invoice:access`** (round 1, P5B-07). The
  endpoints always enforced it; the link did not, so a user without the grant reached a
  wizard whose every call 403s.
- **`scripts/generate_wearbly_order_2026_06_04.py` writes a PDF and nothing else** (round 1,
  P5B-03). Its service-key `uniform_orders` insert is deleted, which is what makes
  "no code writes that row" true rather than merely claimed.

## Evidence

| Check | Result |
|---|---|
| **Plan verify: "an invoice generated through the React wizard byte-matches one generated through the old Jinja path"** | **PASS — byte-identical HTML.** Old and new both `7786 bytes, sha256 f22fdccf82e5ca99579589188d00accf026c298d17b2aee09016476a7e12fc0b`. See *How the byte-compare was run* below. |
| `templates/invoice/pdf_template.html` at `b1beb08^` vs today | byte-identical (`diff` clean) — the document itself never changed, only how it is rendered |
| Backend tests (`DATABASE_BACKEND=sqlite STORAGE_BACKEND=local AUTH_BACKEND=disabled`) | round-1 critic fixes: **2348 passed, 114 skipped** (baseline at `24a43f5`: 2316 passed, 114 skipped — no new skips) |
| `ruff check` · `ruff format --check` · `mypy` | clean |
| `scripts/lint_no_phi_logging.py` | 138 files clean |
| `scripts/lint_org_scope.py` | 97 statements without an explicit predicate, 56 unverifiable — unchanged from baseline; the ratchet passes |
| `scripts/generate_openapi.py --check` | clean (regenerated for `renderInvoice` and the two new invoice error codes) |
| `web`: `npx tsc --noEmit` · `npx vitest run` · the three `web.yml` grep gates | clean |

### How the byte-compare was run (one-off, not a test)

The old render was deleted in `b1beb08`, so it was reconstructed rather than waived. It is
**not** kept as a test: it cannot run without files that are no longer in the tree. The harness
itself is committed, at `scripts/oneoff/compare_invoice_html.py`, so the next person can repeat
the run rather than rebuild it from this prose (critic P5BR2-08). `pyproject.toml` sets
`testpaths = ["tests"]`, so pytest does not collect it and a harness that needs an argument
cannot turn the suite red.

```sh
SCRATCH=$(mktemp -d)                      # outside the repo
mkdir -p "$SCRATCH/old"                   # tar -x -C will not create it
git archive b1beb08^ | tar -x -C "$SCRATCH/old"
PYTHONPATH=. venv/bin/python scripts/oneoff/compare_invoice_html.py "$SCRATCH/old"
```

The harness renders one fixed invoice — three line items exercising `qty`/`rate`, `sub`, and
neither — plus one fixed config through both paths and compares the strings:

- **old:** `<scratch>/old/src/invoice_generator.generate_pdf(data, config, app)`, with a
  throwaway Flask app whose `template_folder` is the archived `templates/` and whose `money`
  filter is `web_app.money_filter` copied verbatim from `b1beb08^`. The HTML is captured at
  the `render_template` call, before WeasyPrint.
- **new:** `src/invoice_generator.render_invoice_html(data, config)`.

**The HTML is compared, not the PDF.** WeasyPrint stamps a creation time into every document,
so two renders of identical HTML are never byte-identical — comparing PDFs would prove the
clock works. The HTML is what the document *is*; the PDF is a deterministic function of it
plus the bundled fonts.

**Result, verbatim:**

```
old: 7786 bytes, sha256 f22fdccf82e5ca99579589188d00accf026c298d17b2aee09016476a7e12fc0b
new: 7786 bytes, sha256 f22fdccf82e5ca99579589188d00accf026c298d17b2aee09016476a7e12fc0b
RESULT: byte-identical
```

No lines differ, so the "differs only in the number/totals source" case does not arise.

## Not yet run

Everything below is verified locally and unverified against a deployed environment, because
there is not one yet. Carried from Phase 5a:

- The in-container invoice render byte-compared against one rendered on the Mac (Phase 5a's
  verify list) — still waiting on a staging environment.

This phase's own, none of which can run before staging exists:

- **The six retired Jinja families, walked in a browser against the deployed React app.** The
  allowlist is empty and `npx vitest run` is green, but no screen has been opened by a person
  against a server that is not `localhost`.
- **`POST /invoices/{id}/render` against real Postgres under real concurrency.** The
  `pdf_filename IS NULL` race is covered by a threads test on the ephemeral fixture
  (`tests/test_invoice_numbers_pg.py`); two web workers on one RDS instance is the thing that
  test stands in for, and it has not been run.
- **Invoice PDFs surviving a task replacement.** They are on local disk (see *Accepted risk*),
  so the failure is a deployment-shaped one and cannot be reproduced on a Mac.
- **The superadmin console's audit trail read back out of `audit.superadmin_access` on a
  deployed database.** The rows are asserted in tests against the fixture database only.
- **Cognito's `MFA_SETUP` and `NEW_PASSWORD_REQUIRED` screens** — see *Needs a human*.
- Accessibility coverage of the new screens is in `web/src/__a11y__/`; the axe run is part of
  `npx vitest run` and is green, but no screen-reader pass has been done by a person.
- Nothing in this phase has been deployed. `deploy.yml` has still never been dispatched.

## Accepted risk

- **Invoice PDFs stay on local disk** at `output/invoices/`, exactly where the Flask route
  put them. Moving them into the artifacts bucket is a storage decision, not a front-end one:
  the store is keyed `{org_id}/{batch_id}/…` and an invoice has no batch. A task replacement
  therefore loses the files, and `/download` answers its "not on this server any more" 404.
  `docs/migration-tracker.md` carries the row. It is listed under *Needs a human* as well,
  because "where do invoice PDFs live" is a decision somebody takes rather than a risk that
  can simply be accepted and left (critic P5BR2-07).
- **44 dead `render_template()` calls, their templates and their routes are still in the
  tree.** Nothing reaches them, and they retire with the process wizards in Phase 11; the
  tracker row naming the directories is the owner.
- **The audit trail costs one extra pooled checkout** per named-org superadmin request. With
  `PG_POOL_MAX` at 8 that is well inside the budget, but it is a real cost taken on purpose.
- The Supabase path writes no `audit.superadmin_access` rows at all: there the service key is
  the bypass and nothing enforces anything behind it. It goes in Phase 10.

## Needs a human

- **Wearbly: repair or retire.** The screen and its worker are gone and the one remaining
  writer (a one-off script's service-key insert) is deleted, so the four `uniform_*` tables
  now have a reader and no writer. The data and the receipt builder are intact; the decision
  is Andres's.
- **`normalize_size` on Supabase** (the other open Wearbly row) still wants an answer before
  the next order is generated.
- **The `MFA_SETUP` and `NEW_PASSWORD_REQUIRED` screens do not exist, and dual acceptance
  must not close before they do.** Cognito can answer either challenge to a user who signs in
  correctly — the first for a pool with MFA required, the second for every pre-provisioned
  user on their first sign-in — and React has no screen for either. The user is stuck at the
  sign-in form with no way forward and no message that says why. It is a gap in Phase 5b's
  own surface, so it is a gate on dual acceptance and not a Phase 7 row (critic P5BR2-07).
- **Invoice PDFs are written to local disk** at `output/invoices/`, which is a decision
  somebody has to take rather than a risk to note: on a container platform a task replacement
  loses every file, and `/download` then answers its "not on this server any more" 404 for
  invoices a client is chasing. The options are the artifacts bucket (with a key that does not
  need a batch id) or accepting that a PDF is regenerated on demand. `docs/migration-tracker.md`
  carries the row; the choice is Andres's.
- The staging environment, which every remaining verify item waits on.

<!-- Critic: the lead completes this line. -->
**Critic:** round 1 FAIL (2 high), round 2 FAIL (1 high), **PASS at round 3** (`6c2cb7d`); the round-3 medium and low are tracker rows.
