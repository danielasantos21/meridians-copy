# Phase 11 — Process framework: detailed implementation plan

**Status:** plan only. No code, no AWS. Written 2026-09-22 on branch `aws-migration` at `e06061c`.
**Implements:** `docs/aws-migration-plan.md` Phase 11 (:561-580), §2.5 (:216), D-16 (:828), §4 (:606-622);
`docs/aws-migration-prompt.md` PROCESS FRAMEWORK (:167-199), PHASE COMPLETION LOOP (:422-464), THE CRITIC (:466-487).
**Citations:** `path:line` refers to the working tree at `e06061c`. `docs/architecture/inventory-process-registry.md`
cites the older commit `4ccddcb`, so its line numbers differ from the ones below. Where they differ, the numbers
here are the current ones.

---

## 0. Bottom line

- Most of what Phase 11 needs can be built and tested on the Mac today. Very little of it can be **switched
  on** before cutover, because switching on means a second execution path that also has to work on
  Supabase. §4 tags every task and gives the rule.
- The plan's 27-40 days is too low. It leaves out retiring the Flask surface and the tracker rows parked on
  Phase 11. Honest total: **~55-67 days**, of which **~44-51** is the plan's own scope (§9).
- Andres has to answer six questions before this phase can finish (§7.2). The two that block the most work:
  **the rehearsal periods** (without them there is no JE gate) and **whether a second api task is worth
  ~$31/month** (without that, "lift desiredCount" means rolling deploys only).
- Three facts the plan does not know yet:
  1. `templates/` cannot simply be deleted. `src/invoice_generator.py:937` loads the invoice PDFs from it.
  2. Task-local disk is a bigger blocker to a second api task than the in-memory dicts are.
  3. There are **14** live thread sites, not 15.

---

## 1. Plain-language summary

Today, when someone starts a revenue or payroll run, the web server does the work itself on a background
**thread** (a second line of work inside the same running program). That is why production must run exactly
one copy of the api. With two copies, a run could start on copy A and have its next step land on copy B.
Copy B cannot see A's memory or A's disk. Worse, redeploying kills whatever run is in progress.

Phase 11 moves the work out of the web server:

1. **A manifest per process.** A manifest is a small Python file that describes one process: its name,
   colour, inputs, wizard steps, permissions, and whether it touches PHI. The five hand-kept lists that
   describe processes today are generated from these manifests. There is still one registry; it is just
   defined in one place.
2. **A queue and a worker.** **SQS** (Amazon Simple Queue Service) is a managed mailbox. The api drops a small
   "please run this" note into it. A separate **worker** container (a second program on AWS Fargate) picks the
   note up and does the work. If the worker crashes, the note reappears and another attempt takes it. After
   three failed attempts the note moves to a **DLQ** (dead-letter queue): a holding pen for notes that keep
   failing, with an alarm on it.
3. **State out of memory.** Every intermediate result is written to Postgres or to S3 as JSON. Nothing a later
   step needs lives only in one program's memory.
4. **Idempotency.** An operation is idempotent when doing it twice has the same effect as doing it once. Because
   a queue can deliver the same note twice, every QuickBooks post is recorded in a table *before* it is sent. A
   repeat checks that record instead of posting again.
5. **A conformance suite.** This is a standard set of tests every process must pass before it counts as
   registered: bad files are rejected, permissions hold, audit rows are written, retries are safe, and no PHI
   appears in logs.
6. **Switch processes over one at a time.** Each process is compared **byte for byte** against the old
   output for two real closed periods. Only then are its old Flask code and templates deleted. When the last one
   is gone, Flask and `web_app.py` go too.

Other terms used below:
- **Parquet**: a compact file format for tables. It needs the `pyarrow` library, which is not installed.
  This plan uses JSON unless that changes.
- **Lease**: a "claimed by worker X until time T" stamp on a run, so two workers never run the same job at once.
- **SECURITY DEFINER function**: a database function that runs with its owner's rights. It is used here so
  the worker can check a job is genuine before it is allowed to see any tenant's rows.
- **Transport**: how a job gets from the api to the code that runs it. Either an in-process thread (today) or SQS.

---

## 2. Starting state (evidence)

### 2.1 The registry is five lists plus two per-process tables

| # | What | Where | Contents |
|---|---|---|---|
| 1 | `process_runs.PROCESSES` | `src/process_runs.py:79` | `qb-revenue`, `mx-payroll`, `qb-usa-payroll`. Enforced at `create_run` (`:565-566`) |
| 2 | `auth.ALL_PROCESSES` + `PROCESS_LABELS` | `src/auth.py:1503-1535` | 8 underscore permission scopes plus `local_plugins.EXTRA_PROCESSES` (`:1498-1501`) |
| 3 | `role_permissions.process` CHECK | `supabase_migrations/migrations/030_role_permission_processes.sql` (in the Alembic baseline) | 11 values. Tested against #2 by `tests/test_role_permission_constraint.py` |
| 4 | `PROCESS_CATALOGUE` | `src/api/v2/routes.py:60-84` | key, name (from #2), colour, permission, steps. Served by `processes()` at `:537` |
| 5 | `qb_export_artifacts.PROCESSES` | `src/qb_export_artifacts.py:50` | `qb-revenue`, `mx-payroll` |
| — | `SPECS` / `Spec` | `src/api/v2/oneshot_runs.py:223-236`, `:340-374` | per-process permission, params model, store and worker names (`web_app` attributes), `supports_retry`, public params |
| — | `RETRY_PROCESSES` | `src/api/v2/state_machine.py:66` | `qb-revenue`. The same fact as `Spec.supports_retry`, stored twice |
| — | `process_runs.process` CHECK | `supabase_migrations/migrations/022_process_runs.sql:60-61` | the same three ids. **No test compares it to #1** |

The state machine is data: `TRANSITIONS` at `src/api/v2/state_machine.py:35`, `ACTION_STATES` at `:53`,
`actions_for` at `:69`, `assert_transition` at `:127`.

### 2.2 Thread sites: 14 live (the plan says 15)

| Site | Starts | Reached from |
|---|---|---|
| `web_app.py:3036` | `process_in_background` | `/revenue/process` (dead Jinja) |
| `web_app.py:3135` | `process_in_background` | `/api/processing/<job_id>/retry` (Flask) |
| `web_app.py:3362` | `process_in_background` | `/qb-revenue/process` (dead Jinja) |
| `web_app.py:4200` | `process_payroll_in_background` | `/mx-payroll/process` (dead Jinja) |
| `web_app.py:4917` | `qb_usa_payroll_process_background` | `/qb-usa-payroll/process/<id>` (dead Jinja) |
| `web_app.py:7542` | `adp_payroll_process_background` | `/adp_payroll` family |
| `web_app.py:8577`, `:8964` | `booking_payroll_process_background` | `/booking_payroll` family |
| `web_app.py:9858` | `adp_v3_process_background` (daemon) | `/booking_payroll_v3` |
| `web_app.py:10470` | `bkv4_process_background` (daemon) | `/booking_payroll_v4` |
| `web_app.py:11070` | `bkv5_process_background` (daemon) | `/booking_payroll_v5` |
| `src/api/v2/oneshot_runs.py:703` | `web_app.<spec.worker_attr>` | `POST /api/v2/{qb-revenue,mx-payroll}/runs` (**live, React**) |
| `src/api/v2/oneshot_runs.py:818` | the same, with retry params | `POST …/retry` (**live**) |
| `src/api/v2/qb_usa_runs.py:1426` | `web_app.qb_usa_payroll_process_background` | `POST /api/v2/qb-usa-payroll/runs/{id}/execute` (**live**) |

The live React path reaches the worker functions through `import web_app` (`src/api/v2/oneshot_runs.py:94-96`,
`src/api/v2/qb_usa_runs.py:107-109`). **So `web_app.py` cannot be deleted until those functions have moved.**

### 2.3 Run state: 4 `RunStore`s plus 10 plain dicts

| Store | Where | Volatile (process-local) keys |
|---|---|---|
| `processing_status` (qb-revenue) | `web_app.py:47` | `result`. `_retry_params` goes to the `params` column |
| `payroll_processing_status` (mx-payroll) | `web_app.py:3622` | none |
| `qb_usa_payroll_sessions` | `web_app.py:4310` | `result` (a `RunResult` dataclass tree; not JSON), `prompts`, `alerts` |
| `qb_usa_payroll_jobs` | `web_app.py:4311` | none |
| `_volatile` cache | `src/run_store.py:61` | holds all of the above, keyed `org\|run`. **It is never bounded and never expires** |

**Plain dicts (not tenant-bound; Codex CX-API-03, tracker row 151):** `adp_payroll_session`/`_job_status`
(`web_app.py:7341-7342`), `booking_payroll_*` (`:8330-8331`), `adp_v3_*` (`:9541`, `:9543`), `bkv4_*`
(`:10124`, `:10127`), `bkv5_*` (`:10749`, `:10751`). That is **five families**. Tracker row 133 says "three";
that is wrong. None of these is reachable on AWS, because the edge routes only `/api/*`, `/auth/*` and
`/static/*` to the api (`web/next.config.mjs:104-108`, and the `jinja` list at `:89-93` is empty).

`_RUN_OVERRIDES` **no longer exists.** `src/qb_usa_payroll_roster.py:142-171` is now a delegation to
`process_runs.run_state.run_overrides`. The plan's reference to `:142` is obsolete.

### 2.4 What else stops a second api task (the plan does not list these)

| Blocker | Evidence | Why it matters |
|---|---|---|
| **Task-local upload disk** | `unique_upload_path` `web_app.py:371`; the qb-usa `input_dir` under `UPLOAD_FOLDER` (`src/api/v2/qb_usa_runs.py:947`); revenue retry checks `Path(params["filepath"]).exists()` (`src/api/v2/oneshot_runs.py:672-677`) | A review on task A and an execute on task B finds no input files. This is a harder blocker than the dicts |
| Runs die with the task | every §2.2 thread | A deploy mid-run leaves a `running` row that nothing resumes |
| MFA half-sign-in store | `_pending` dict, `src/api/v2/auth_routes.py:334-336` (tracker row 84, still open) | MFA fails closed on the other task. Flaky, not unsafe |
| Per-task rate limiter | ADR 0023 (`api.deps.RateLimiter`) | N tasks allow N× the limit per client |
| No TTL sweeper | `expires_at` is set, but no code moves a run to `expired`. A grep of `src/`, `api/` and `scripts/` found no sweeper | Abandoned runs keep `run_overrides` until something sweeps them |

### 2.5 Wizards per process

| Process | Live UI | Dead Flask wizard (to delete) | Worker function (to move) |
|---|---|---|---|
| qb-revenue | React `web/src/app/processes/[process]/…` → `/api/v2/qb-revenue/runs` (FastAPI `api/routers/oneshot_runs.py`) | `/revenue/*` (4), `/qb-revenue/*` (6), `/process`, `/processing`, `/results`, `/download`, `/preview`, `/download_all`, `templates/revenue/`, `templates/qb_revenue/` | `WebProcessor` `web_app.py:942`, `process_in_background` `:1767`, `validate_file_headers` `:829` |
| mx-payroll | React → `/api/v2/mx-payroll/runs` | `/mx-payroll/*` (6), `/qb-payroll` redirects (2), `templates/mx_payroll/` | `process_payroll_in_background` `:3943`, `_mx_detect_schedule` `:4061` |
| qb-usa-payroll | React → `/api/v2/qb-usa-payroll/runs` (review, preview, declarations, execute, quickbooks) | `/qb-usa-payroll/*` (13), `templates/qb_usa_payroll/` | `_qb_usa_db` `:4332`, `_qb_usa_run` `:4341`, `_qb_usa_require_supabase` `:4387`, `qb_usa_payroll_process_background` `:4943` |

The React side still branches on process ids in `web/src/components/create-run-form.tsx`, `results-screen.tsx`,
`shell/sidebar.tsx` and `web/src/lib/run-view.ts`.

### 2.6 The rest of the Flask surface

`web_app.py` has **156** `@app.route`s and **58** `render_template` calls. The families besides §2.5:
`/admin` (7), `/config` (12), `/settings` (3), `/dashboard` (2), public pages (6), `/setup-org`, `/login`, plus
the five payroll families (49). Several are **reachable through the edge today**:

- `/auth/google`, `/auth/microsoft`, `/auth/callback` (`web_app.py:2149-2164`, referenced from
  `web/src/components/login-form.tsx`);
- `/api/*`: 32 routes. That is 10 × `/api/v1/*` (`:8056-8184`), 9 × `/api/config/*`, 9 × `/api/mso/*`,
  2 × `/api/processing/*`, `/api/process`, `/api/fiscal-calendar/import`. None has a consumer in `web/src`.

Two more need checking:
- `/qbo/connect` and `/qbo/callback` (`:2265`, `:2275`) are **not** under an edge prefix. Whether Intuit's
  redirect depends on them (`QBO_REDIRECT_URI`, `src/qbo_client.py:373`) is **unclear**.
- Flask is imported outside `web_app.py` by `src/auth.py`, `src/run_store.py:283`, `src/api/v2/limits.py`,
  `src/api/v2/errors.py` and `scripts/oneoff/compare_invoice_html.py`.

**PDF templates live in `templates/`:** `src/invoice_generator.py:937` uses `FileSystemLoader(REPO_ROOT / "templates")`,
and `src/wearbly_pdf.py:9` has its own loader. So "delete `templates/`" must first move `templates/invoice/`,
`templates/agreement/` and `templates/wearbly/receipt.html`.

### 2.6.1 G2 route inventory (2026-09-24)

Every rule in `web_app.app.url_map` at `aws-migration` 32388a2 (108), minus what FastAPI already
serves (no overlap — nothing was shadowed), minus the `jinja` allowlist (empty). "At the edge" means
under a proxied prefix in `web/next.config.mjs` (`/api/*`, `/auth/*`, `/static/*`), which is all the
ALB and the Next proxy send to the api; every other Flask path is unreachable on meridiansgrp.com.
"Callers" is a grep of `web/src`, `web/next.config.mjs`, `api/`, `src/`, `workers/`, `scripts/`,
`infra/`, `lambda/`, `docs/runbooks/`, `render.yaml` and `templates/` (comments and docstrings
skipped). Plan §7.2 item 4's "30 days of ALB logs" is superseded by Andres's 2026-09-22 answer for
`/api/v1`, and nothing else here is deleted on the strength of logs.

**Totals: 23 deleted, 3 ported, 82 left (each with its reason).** After G2 Flask serves 82 rules. **D18 (2026-09-24):** `/qbo/connect` and `/qbo/callback` ported too — 5 ported, 80 left.

| Route(s) | Edge | Verdict | Evidence |
|---|---|---|---|
| `/api/v1/revenue/batches`, `/api/v1/revenue/results/<id>`, `/api/v1/payroll/batches`, `/api/v1/config/{providers,locations,payers,employees}`, `/api/v1/settings` GET+PUT, `/api/v1/user/me` (10) | yes | **Deleted** | no caller anywhere; Andres yes 2026-09-22 (§7.2); two read `import_batches` with no `org_id` predicate. `/api/v1/health` stays (FastAPI, D-25) |
| `POST /api/fiscal-calendar/import` | yes | **Deleted** | no caller anywhere |
| `POST /api/process` | yes | **Deleted** | no caller anywhere (pre-wizard revenue API; now `/api/v2/qb-revenue/runs`) |
| `GET /api/config/export`, `POST /api/config/import` (bare) | yes | **Deleted** | no caller anywhere (whole-workbook round trip) |
| `/api/mso/{department,location,account,employee}` POST + DELETE `<key>`, `/api/mso/sync_from_excel` (9) | yes | **Deleted**, with the ADP Payroll tab of `templates/config.html` | only caller was that tab; the page has no edge route (tracker "44 dead `render_template()` calls") and the ADP screens went in G1. Wrote local `config/mso_mappings.json`; `str(e)` answers (CX-API-05). Allocations live on in `/api/v3/allocations` |
| `/auth/google`, `/auth/microsoft`, `/auth/callback` | yes | **Ported** → `api/routers/oauth.py` | live: `web/src/components/login-form.tsx:339,346`; `/auth/callback` is `infra/meridian/stacks/auth.py` `CALLBACK_PATH` and Supabase's redirect. `tests/test_oauth_state.py` on FastAPI alone |
| `/static/<path:filename>` | yes | **Left — live**, moves with the mount (G4/G5) | `src/email_service.py:91` (the email logo at `{SITE_URL}/static/images/logo.svg`), `src/app_settings.py:53` (invoice logo). Porting is a FastAPI `StaticFiles` mount, but not a pure translation — Flask answers `Cache-Control: no-cache` with an ETag and Starlette sends no `Cache-Control` at all, a caching change for the edge — and until `templates/` goes Flask's `static` endpoint is also what every surviving template's `url_for('static')` builds |
| `/api/config/meta`, `/api/config/add/{provider,location,department,payer}` (5) | yes | **Left** — retire with the Jinja wizards (I2 revenue, I3 mx-payroll) | only callers: `templates/{revenue,qb_revenue,mx_payroll}/processing.html`. Deleting them first would half-break wizards the plan keeps until their rehearsal. Four still answer `str(e)` (CX-API-05). `tests/test_security.py` SEC-05 covers the permission |
| `/api/processing/<id>/status`, `/api/processing/<id>/retry` | yes | **Left** — I2 (plan §"deletion order") | callers: `templates/{processing,revenue/processing,qb_revenue/processing}.html` |
| `/api/config/export/<table>`, `/api/config/import/<table>` | yes | **Left** — G5, with `templates/config.html` | only caller: that page's Revenue tab (`exportTable`/`importTable`). Both answer `str(e)` (CX-API-05) |
| `/qbo/connect`, `/qbo/callback` | **no** | **Ported (D18, 2026-09-24)** → `/api/v2/qbo/connection` (`api/routers/qbo.py`) + a React card on `/settings` | decision D18 option 2 (provisional). Not a translation, as this row said: GET status / POST connect / DELETE disconnect for the SPA, and the callback at `QBO_CALLBACK_PATH` (default `/api/v2/qbo/connection/callback`, under the proxied `/api/*` prefix). The `state` left the Flask session for the parked-challenge store (revision 0017), bound to org + user and spent on first use; `require_role('admin')` became `require_admin`; connects and disconnects are audited (revision 0021). `tests/security/test_qbo_connection.py` with known-bad controls. What is left is Intuit-side (tracker row "Register the production QuickBooks redirect URI"). `docs/runbooks/cutover.md:676`'s rollback-window rule now means "no QuickBooks card", not "no `/qbo/connect`" |
| `/revenue`, `/revenue/process`, `/revenue/processing/<id>`, `/revenue/results/<id>`, `/index`, `/process`, `/processing/<id>`, `/results/<id>`, `/download/<path>`, `/preview/<path>`, `/download_all/<id>`, `/qb-revenue` + `/process`, `/processing/<id>`, `/results/<id>`, `/download-all/<id>`, `/download/<id>/<path>` (17) | no | **Left** — I2 (NEEDS-AWS) | plan §"deletion order" row "After I2"; no edge route |
| `/mx-payroll` + `/process`, `/processing/<id>`, `/results/<id>`, `/download-all/<id>`, `/download/<id>/<path>`, `/qb-payroll`, `/qb-payroll/<path>` (8) | no | **Left** — I3 (NEEDS-AWS) | plan row "After I3"; no edge route |
| `/qb-usa-payroll` + `/accrual`, `/upload`, `/review/<id>` GET+POST, `/preview/<id>`, `/process/<id>`, `/processing/<id>`, `/status/<id>`, `/results/<id>`, `/download/<id>`, `/download-workbook/<id>`, `/history` (13 rules) | no | **Left** — I4 (NEEDS-AWS) | plan row "After I4"; no edge route |
| `/login`, `/dashboard` | no (only under `MERIDIAN_JINJA_AUTH=1`) | **Left** — the rollback hatch; G5 | `web/next.config.mjs` `JINJA_AUTH`; `infra/meridian/edge_paths.py` `jinja_auth_families()` |
| `/dashboard/preferences`, `/setup-org`, `/admin/{users,generate-invite,organization,roles,roles/<id>/update,roles/<id>/delete,users/assign-role}`, `/config`, `/config/invoice/save`, `/config/edit/{payer,location,provider}`, `/config/add/{provider,location,department,clinic_group}`, `/config/mx-column-map/{save,delete,seed}`, `/settings`, `/settings/save`, `/settings/reset`, `/`, `/features`, `/pricing`, `/privacy`, `/terms`, `/security` (30) | no | **Left** — G5, with `templates/` | tracker row "44 dead `render_template()` calls" owns them: dead as URLs, deleted in the commit that deletes `templates/` and `web_app.py`. React equivalents exist (`/onboarding/org`, `/admin/*`, `/config`, `/settings`, the marketing pages) |

### 2.7 QuickBooks posting today

- `push_batch_to_qbo` (`src/qb_usa_payroll_quickbooks.py:111-178`) runs **synchronously inside the request**
  (`src/api/v2/qb_usa_runs.py:1432`, route `api/routers/qb_usa_runs.py:243`).
- Protection has two layers: a date pre-check (`journal_entries_on_date`), and a **derived** Intuit
  `requestid` (`journal_request_id`, `src/qbo_client.py:323-347`), passed at `:310`. Nothing is persisted
  before the call.
- A second poster exists: `scripts/qbo_post_je.py:108-111` (manual CLI, Supabase-only).
- Tracker row 49 (`qbo_request_id` on `qb_export_tie_out`, owed "before the Phase 11 idempotency table") is still open.

### 2.8 Infra hooks already in place

- `infra/meridian/stacks/api.py:1-24` is the empty `ApiStack`, reserved for SQS and EventBridge.
- `infra/meridian/stacks/compute.py:141` has `API_DESIRED_COUNT = 1`, and `_service` pins `single_task` at `:895-907`.
  Its docstring (`:7-17`) still says "five wizards" and cites stale lines (tracker row 133).
- The api `HealthyHostCount > 1` alarm is in `infra/meridian/stacks/observability.py:531-540` and `:610-619`.
- A KMS-encrypted SQS pattern already exists (`data.py:1062-1066`, `stop_dlq`).
- Buckets are **versioned** (`data.py:1157-1184`), which makes `input_object_versions[]` possible.
- GuardDuty Malware Protection tags objects in the `phi` bucket, **but no code reads the tag** (tracker row 89).

---

## 3. Target design

### 3.1 Manifest schema

`src/processes/<pkg>/manifest.py` exports `MANIFEST`. The dataclasses live in `src/processes/manifest.py`, which
imports nothing from `auth`, `api` or `web_app`, so there is no import cycle.

```python
from dataclasses import dataclass, field
from typing import Callable, Literal

StateClass = Literal["public", "personnel", "phi", "never"]  # §3.6


@dataclass(frozen=True)
class InputSpec:
    role: str  # 'billing_export', 'register', 'invoice', ...
    extensions: tuple[str, ...]  # ('.xlsx',) — checked before storage
    max_files: int = 1
    validate: Callable | None = (
        None  # (local_path) -> None | raises ProcessInputError(code, details)
    )


@dataclass(frozen=True)
class StepSpec:
    id: str  # must be a state_machine step: upload, roster_review, preview, mapping_fix, processing, results
    level: Literal["access", "results"]  # §12.11 — permission is per step
    custom: bool = False  # React renders a registered custom component for this id


@dataclass(frozen=True)
class JobSpec:
    kind: Literal["parse", "execute", "retry", "qbo_push"]
    handler: Callable  # (JobContext) -> JobOutcome ; pure src/ code
    from_states: frozenset[str]  # legal states when the job starts (checked against TRANSITIONS)
    timeout_s: int  # sets the lease; the worker heartbeats before it expires


@dataclass(frozen=True)
class ProcessManifest:
    id: str  # hyphenated; process_runs.process
    permission: str  # underscored; role_permissions.process
    label: str  # replaces the PROCESS_LABELS entry
    color: str
    params_model: type  # pydantic, extra='forbid' — the §12.4 discriminated union member
    public_params: tuple[str, ...]
    envelope: type  # RunEnvelope variant (schemas.py)
    inputs: tuple[InputSpec, ...]
    steps: tuple[StepSpec, ...]
    jobs: dict[str, JobSpec]
    outputs: tuple[str, ...]  # storage subfolders written; bucket from src/storage.bucket_for
    period_source: Literal["required", "derived", "parsed"]  # §12.5
    idempotency: Literal["content_hash_warn", "always_new"]  # §12.9
    supports_retry: bool  # §12.8 — the single source for RETRY_PROCESSES and Spec.supports_retry
    artifact_persistence: Literal["tie_out", "own_tables"]  # replaces qb_export_artifacts.PROCESSES
    touches_phi: bool
    state_fields: dict[str, StateClass] = field(
        default_factory=dict
    )  # every run_state / state-object key
    readiness: Callable | None = None  # the existing qb-usa 'roster_ready' extension point
    scopes: tuple[str, ...] = ()  # Phase 12 machine scopes; declared now, enforced in Phase 12
```

The loader, `src/processes/__init__.py`, imports the three packages plus an optional `local_plugins`
(an absent module is fine, per D-24). It **refuses registration** when a manifest fails static checks:
- an unknown step or state;
- a job whose `from_states` is not reachable in `TRANSITIONS`;
- a permission not in the role_permissions CHECK;
- an id not in the `process_runs` CHECK;
- an input with no validator;
- `touches_phi=False` together with a `phi` state field.

The **dynamic** conformance suite (§4 F1) cannot run at import time. It gates merge in CI. That is the honest
meaning of "a process that fails is not registered".

### 3.2 One registry: what each existing list becomes

| Existing | After Phase 11 |
|---|---|
| `process_runs.PROCESSES` | `frozenset(REGISTRY)` |
| `routes.PROCESS_CATALOGUE` | built from `REGISTRY` (key, name, colour, permission, step ids), plus `create.params_schema` (JSON Schema from `params_model`) for the React form |
| `auth.ALL_PROCESSES` / `PROCESS_LABELS` | `MODULE_SCOPES` (the non-process scopes `config`, `invoice`, `pnl_provider`, plus `adp_payroll`/`booking_payroll` unless G1 deletes them) + manifest permissions + `EXTRA_PROCESSES` |
| `state_machine.RETRY_PROCESSES` | `{m.id for m in REGISTRY if m.supports_retry}` |
| `qb_export_artifacts.PROCESSES` | `{m.id … if m.artifact_persistence == "tie_out"}` |
| `oneshot_runs.SPECS` | removed. Its fields come from the manifest; `worker_attr`/`store_attr` disappear with `web_app` |
| 022 / 030 CHECKs | **kept** (database integrity). `new-process` writes the Alembic revision that widens them, and a test asserts CHECK == registry in both directions |

### 3.3 Execution: one code path, two transports

```
api (FastAPI)                                   worker (python -m workers)
  create/execute/retry/push                       receive (long poll 20 s)
    ├─ write process_runs row + inputs            ├─ app.authorize_job(...)  ← BEFORE any tenant context
    └─ enqueue(JobMessage) ──transport──▶         ├─ app.claim_run(...) lease
        inprocess: thread → workers.run_job       ├─ with_org(org, actor): manifest.jobs[kind].handler
        sqs:       SendMessage                    ├─ heartbeat: ChangeMessageVisibility + lease extend
                                                  └─ write state (Postgres/S3) → set_state → DeleteMessage
```

`workers.run_job(msg)` is the **only** implementation. `JOB_TRANSPORT=inprocess` runs it on a thread
(the shape used on the laptop and in tests). `JOB_TRANSPORT=sqs` is for ECS. A per-process allowlist,
`WORKER_PROCESSES`, moves processes onto SQS one at a time (§5). This is a transport switch, like
`STORAGE_BACKEND`. It is not a second implementation.

### 3.4 Queue message contract (Codex PS-5)

```json
{"v": 1, "job_id": "<uuid4>", "kind": "execute",
 "run_id": "<uuid>", "org_id": "<uuid>", "actor_user_id": "<uuid>", "process_id": "qb-usa-payroll",
 "input_object_versions": [{"bucket_role": "phi", "key": "<org>/<run>/uploads/<name>", "version_id": "…", "sha256": "…"}]}
```

- It is a pydantic model with `extra='forbid'`. `kind` and `job_id` extend the plan's five fields: `kind`
  because qb-usa has parse, execute and push stages; `job_id` for the lease and for logs.
- It carries **ids only**. No filenames beyond the storage key, no amounts, no PHI.
- **The actor may be a machine client (Phase 12 dependency).** Phase 12 starts runs from API clients, so
  the actor is `{"actor_type": "user"|"client", "actor_id": "<uuid>"}` rather than a bare `actor_user_id`;
  `authorize_job` checks membership for a user and an enabled, un-revoked `api_clients` row in the same org
  for a client (`docs/reports/phase-12-plan.md`). Build the two-variant shape in D1 so Phase 12 does not
  change the message contract.
- **Authorisation.** `app.authorize_job(run_id, org_id, actor, process, versions)` is a SECURITY DEFINER
  function owned by the migrator role, with EXECUTE granted to the worker's role. It checks all of the following:
  - the row exists;
  - `org_id` matches;
  - `created_by` = actor, **and the actor is still a member of the org** (this answers CX-BE-01 for the worker);
  - `process` matches;
  - the state is one of that job's `from_states`;
  - `process_runs.inputs` records exactly those `version_id`s.
- If any check fails, the message goes to the DLQ with a `reason` attribute (a code, never a value) and is
  deleted. `with_org()` is never called on the message's word alone.

This function is needed because under `FORCE ROW LEVEL SECURITY` as `meridian_app`, nothing can read the row
**before** `app.org_id` is set. A narrow definer function is the only way to follow the plan's "re-read before
setting context" rule.

### 3.5 Leases, retries, resumability

- Extend `process_runs` (no new table) with `lease_owner TEXT`, `lease_expires_at TIMESTAMPTZ`,
  `attempts INT NOT NULL DEFAULT 0` and `last_job_id TEXT`.
- **Claim:** `UPDATE … SET lease_owner=%s, lease_expires_at=now()+%s, attempts=attempts+1 WHERE run_id=%s
  AND org_id=%s AND (lease_expires_at IS NULL OR lease_expires_at < now()) RETURNING …`. If no row comes back,
  someone else holds the run: the worker leaves the message for later and does not run.
- **Standard SQS** (at-least-once) plus lease plus idempotency table. FIFO is not needed.
- **Advisory locks are not used.** A session lock would pin a pool connection (`PG_POOL_MAX` 8) for a whole run.
- **Visibility:** 15 min, with a heartbeat every 2 min (so the queue does not hand the note to someone else
  while work is still going). `maxReceiveCount` = 3, then DLQ. DLQ retention 14 days.
- **Resume after a kill:** the lease expires, SQS redelivers, and a new claim succeeds. Handlers must be
  re-runnable. Outputs go to deterministic keys. `batch_id` is **reused** from `process_runs.batch_id` if one
  was already allocated (task C7; whether each processor supports this is **unverified**).
- **Sweeper:** job kind `sweep`, sent every 15 min by EventBridge Scheduler. `app.expire_stale_runs()` (definer)
  moves `draft`/`needs_input` runs past `expires_at` to `expired` and drops `run_overrides`. It moves `running`
  runs with an expired lease and `attempts >= 3` to `failed`.

### 3.6 State serialization rules (PS-2, PS-15)

**Classes.** Each run_state or state-object key must be declared in `manifest.state_fields`. An undeclared key
**raises**; this is the existing `_jsonable` fail-loud rule, extended from "serializable" to "classified".

| Class | Store | Access |
|---|---|---|
| `public` | `process_runs.run_state` / `params` | normal repository |
| `personnel` (employee names, pay aggregates) | `run_state` for small data (it already holds these, `src/run_store.py:34-35`); `phi` bucket `{org}/{run}/state/*.json` for larger objects (fail closed to the stricter bucket) | normal repository; bucket IAM |
| `phi` (patient identifiers, raw billing rows) | `phi` bucket `{org_id}/{run_id}/state/` only | through a new `src/phi.py` entry, `open_state()`, that writes `audit.phi_access` opened/closed rows the way `with_phi_access` does (`src/phi.py:240`) |
| `never` | not persisted; recomputed from the uploads object | — |

**Format:** JSON only (`json.dumps`, Decimals as strings, DataFrames as `orient="split"` with a dtype map).
**Never pickle.** Parquet only if Andres approves `pyarrow` (§7.2).

**Prefix separation (PS-15):**
- the api writes only `*/uploads/*`;
- the worker writes only `*/state/*` and the output subfolders;
- the reader loads state only from a `state/` key **and** a `version_id` recorded in `run_state.state_objects`.
  An object whose version was not recorded is refused.

**Per key:**

| Key today | Decision |
|---|---|
| qb-revenue `result` (`web_app.py:47`) | Persist the `result_overview` summary that already exists (public). Verify the results page needs nothing else, since tie-out comes from `qb_export_tie_out`. Drop the rest |
| qb-revenue `_retry_params.filepath` | Replaced by `input_object_versions` in `process_runs.inputs` |
| mx-payroll | Nothing volatile. Inputs move to the `phi` bucket `uploads/` |
| qb-usa `result` (`RunResult`) | **Never serialized whole.** A `parse` job writes a *review snapshot* (prompts, alerts, via explicit `to_json` on `PersonPrompt`/`ChangeAlert`; personnel) and a *preview snapshot* (journal lines and gates; the class is decided in C5, fail closed to `personnel` in the `phi` bucket). `execute` recomputes from the uploads object |
| qb-usa `RunResult.inputs` / `employee_runs` (DOB, member IDs, net pay, deposit splits) | `never`. This keeps the deliberate drop at `web_app.py:5106-5109`. A conformance test fails if any of these field names appears in stored state |
| `_volatile` (`src/run_store.py:61`) | Deleted |

### 3.7 Idempotency (§12.9, PS-11)

- The create step keeps `process_runs.idempotency_key` and its unique partial index (022/0008). **It is not
  duplicated.**
- The new table covers `run.execute` and `qbo.journal`:

```sql
-- Alembic 0012_job_idempotency (sketch)
CREATE TABLE public.job_idempotency (
    org_id              uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    scope               text        NOT NULL CHECK (scope IN ('run.execute','qbo.journal')),
    idempotency_key     text        NOT NULL,   -- header value, or journal_request_id(...) for qbo.journal
    run_id              uuid        REFERENCES public.process_runs(run_id) ON DELETE SET NULL,
    request_fingerprint text        NOT NULL,   -- sha256 of canonical request; same key + different body → 422
    qbo_request_id      text        CHECK (char_length(qbo_request_id) <= 50),
    state               text        NOT NULL CHECK (state IN ('pending','completed','failed')),
    remote_result       jsonb,                  -- {qbo_txn_id, doc_number}; ids only
    attempts            int         NOT NULL DEFAULT 0,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (org_id, scope, idempotency_key)
);
CREATE INDEX ix_job_idem_run     ON public.job_idempotency (org_id, run_id);
CREATE INDEX ix_job_idem_pending ON public.job_idempotency (updated_at) WHERE state = 'pending';
ALTER TABLE public.job_idempotency ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_idempotency FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant ON public.job_idempotency
    USING (org_id = app.current_org_id()) WITH CHECK (org_id = app.current_org_id());
GRANT SELECT, INSERT, UPDATE ON public.job_idempotency TO meridian_app;   -- no DELETE
-- same revision: ALTER TABLE qb_export_tie_out ADD COLUMN qbo_request_id text  (tracker row 49)
```

**QBO journal algorithm** (per journal, inside the `qbo_push` job):
1. `INSERT … ON CONFLICT (org_id, scope, idempotency_key) DO NOTHING RETURNING`. The key is the existing
   `journal_request_id(org, batch, journal_no, txn_date)`.
2. If a row already exists and it is `completed`, return its `remote_result`.
3. If a row already exists and it is `pending`, **re-query QBO**. The existing `journal_entries_on_date` finds it
   by DocNumber. If found, mark `completed`. If not found, call `create_journal_entry` again with the **same**
   requestid. The length of Intuit's replay window is not documented in this repo; verify it.
4. For a new row, call create, then update the row to `completed` in its own statement.

`scripts/qbo_post_je.py` either calls the same helper or is retired (§7.1).

Duplicate *input* stays a `DUPLICATE_INPUT` warning carrying `previous_run_id`, keyed on the uploads' `sha256`.
It never blocks.

### 3.8 CDK additions (all behind context flag `worker_enabled`, default `false`)

| Stack | Addition |
|---|---|
| `api.py` (`ApiStack`) | Queue `meridian-<env>-sqs-jobs`: KMS CMK, visibility 900 s, receive wait 20 s, TLS-only policy, redrive to `-sqs-jobs-dlq` (maxReceiveCount 3, 14 d). EventBridge Scheduler rule every 15 min sends the `sweep` job (a scheduler role with `sqs:SendMessage` on this queue only) |
| `compute.py` | ECR repo for `worker` (or a second tag in the api repo; one image with two CMDs is simpler, §7.1). Task def ARM64 0.5 vCPU / 1 GB, `stopTimeout` 120 s. Service `svc-worker`: desired 1, no target group, min 100 / max 200. Role `meridian-<env>-iam-ecs-worker-task` with: `sqs:ReceiveMessage/DeleteMessage/ChangeMessageVisibility/GetQueueAttributes` on jobs; `sqs:SendMessage` on the DLQ; `s3:GetObject/GetObjectVersion/GetObjectTagging` on `phi` `*/uploads/*`; `s3:PutObject/GetObject` on `*/state/*` and output subfolders; `kms:Decrypt/GenerateDataKey` on the two bucket keys and the queue key; the DB secret through the execution role. **The api task role gains `sqs:SendMessage` on jobs only** |
| `observability.py` | Alarms: DLQ `ApproximateNumberOfMessagesVisible > 0`; jobs `ApproximateAgeOfOldestMessage > 900`; worker `RunningTaskCount < 1` (BREACHING on missing); metric filter `job_refused` > 0; dashboard row |
| `infra/tests/` | assertions: no wildcard actions, KMS on both queues, redrive = 3, visibility > the longest `timeout_s` in the registry (read from the manifests, **not retyped**) |

### 3.9 The `desiredCount` lift

Two parts, which can be decided separately:

- **Always:** remove the `single_task` pin (`compute.py:895-907`) so the api deploys rolling (min 100 / max 200).
  That ends the 3-6 minutes of hard downtime per deploy. Retire the `HealthyHostCount > 1` alarm, or repurpose it
  as `< desired`, **in the same commit**. Correct the docstring at `compute.py:7-17` (tracker row 133).
- **Cost decision:** `API_DESIRED_COUNT = 2` in production adds **~$28.83/month before tax** (plan §5 line) and
  goes past the approved ~$238 ceiling. **Recommended default:**
  - once the heavy pandas work lives in the worker, measure api memory;
  - if the api fits in 0.5 vCPU / 1 GB, run **two small api tasks for the price of one large one**;
  - until measured, steady state stays at 1 task with rolling deploys, and the plan's "`desiredCount=2` end-to-end"
    check runs as a timed test (§6).

---

## 4. Work breakdown

**Tags.**
- **[LOCAL-NOW]**: built and tested on the Mac with `tests/pg_fixture.py` (Docker or Homebrew Postgres),
  botocore's built-in `Stubber` (no new dependency) and `cdk synth`. **Safe to merge now:** it changes no
  runtime path on Render or Supabase.
- **[LOCAL-NOW†]**: built and tested now, but the commit that *switches it on* waits for cutover (Phase 9).
  Switching on earlier would mean the Supabase backend also needs it, which is exactly the dual maintenance
  D-16 removes. Keep the switch-on commit separate and small.
- **[NEEDS-AWS]**: needs deployed staging or production.
- **[NEEDS-ANDRES]**: blocked on a decision or consent.

**Timing rule for B-tasks:** the processor code moves change the code that produces JEs. Land them **before the
Phase 9 rehearsal freeze** (so the rehearsal diffs cover them) or **after cutover**. Never in between.

### A — Manifest and registry (plan: 3-4 d)

| Id | Task | Files | Proof | Dep | Tag | d |
|---|---|---|---|---|---|---|
| A1 | Manifest dataclasses, loader, three manifests stating today's literal values | `src/processes/{__init__,manifest}.py`, `src/processes/{qb_revenue,mx_payroll,qb_usa_payroll}/manifest.py` | `tests/test_process_manifest.py`: each manifest equals today's literals; loader works with no `local_plugins`; static refusals fire on bad manifests | — | LOCAL-NOW. **Built 2026-09-24.** **Deviations:** (1) `InputSpec` also carries `content_types` and `max_bytes` (default 50 MiB = `settings.DEFAULT_MAX_UPLOAD_BYTES`; `MERIDIAN_MAX_UPLOAD_BYTES` still applies on top) for phase-12-plan §3.9 item 1, and `max_files` is `int | None` (None = qb-usa's one dropzone, where the contents decide). (2) `JobSpec` is `(kind, from_states, timeout_s, handler=None)`: `handler` stays None until D3 builds `JobContext`, and `timeout_s` is a 600 s placeholder under the 900 s visibility until D3 measures real runs; the job start states are today's (qb-revenue execute `draft`, retry `blocked`; mx execute `draft`; qb-usa parse `draft`/`needs_input`, execute `needs_input`/`ready`, qbo_push `completed`). (3) `state_fields` are empty: C2 declares them. `scopes` are empty: Phase 12 declares them. (4) The validators are thin adapters over today's checks (`validate_file_headers`, `_mx_detect_schedule`, `identify_csv`), raising `ProcessInputError(code, message, details)`; the create path does not call them yet (C1 does). (5) Extra refusals beyond §3.1: duplicate id or permission, a job whose key is not its kind, `supports_retry` without a `retry` job (or the reverse), an input with no file type, an unknown state class, an envelope whose `process` is not the id. (6) The CHECK values are read at import from the Alembic chain (`migrations/baseline/*.sql`, then each revision's `upgrade` half, latest wins); none found → refused. (7) The plugin hook is `local_plugins.EXTRA_MANIFESTS` (optional attribute; `EXTRA_PROCESSES` keeps its meaning). (8) qb-usa's `readiness` moved from `routes._roster_ready` into its manifest. **Changed after the A1 review (2026-09-24):** (6) is superseded: the loader no longer reads `migrations/` at all. The allowed values are stated in `src/processes/__init__.py` (`PROCESS_RUNS_CHECK_VALUES`, `ROLE_PERMISSIONS_CHECK_VALUES`) and A3 compares them with the Alembic chain and the Supabase migrations in CI (the SQL parser moved into `tests/test_registry_conformance.py`); a test imports the registry under an audit hook that fails any open of a `migrations` path. Widening a CHECK = an Alembic revision + that edit, one commit. (1) is refined: `content_types` is now a dict, extension → accepted types (canonical first), from `manifest.BROWSER_CONTENT_TYPES`: `.csv` also accepts `application/vnd.ms-excel` (Windows with Excel) and `text/plain`; `.xlsx`/`.xlsm`/`.xls` also accept `application/octet-stream` (a browser with no type registered). A Content-Type is documented as a hint picked from the file NAME, never the gate: the gate is the input's `validate`, which opens the bytes (a workbook parser, `identify_csv`), plus the Phase 12 malware tag. There is no separate magic-byte check (none exists in the repo); the loader refuses an input without one content-type entry per extension. | 1 |
| A2 | Derive the lists (§3.2) from the registry. `SPECS` keeps only its callables for now | `src/process_runs.py`, `src/api/v2/routes.py`, `state_machine.py`, `src/qb_export_artifacts.py`, `src/auth.py`, `oneshot_runs.py` | the whole suite green; a **snapshot test**: the `/api/v2/processes` JSON for a fixed caller is byte-identical before and after; `tests/test_role_permission_constraint.py` green | A1 | LOCAL-NOW. **Built 2026-09-24.** Snapshot: `tests/snapshots/api_v2_processes.json`, three fixed callers (admin; a member with partial permissions; the same member in an org with two modules), captured at `6c06bd5` in its own commit before the refactor, and asserted byte-for-byte in `tests/test_api_v2_cross_cutting.py`. **Deviations:** (1) `state_machine.RETRY_PROCESSES` is now the cached function `retry_processes()`: the loader checks manifests against `TRANSITIONS`, so the state machine reads the registry lazily to avoid an import cycle. (2) `PROCESS_CATALOGUE` does NOT yet carry `create.params_schema`: adding it changes the `/api/v2/processes` bytes and the v2 OpenAPI, so it lands with its consumer, F3. (3) `auth.MODULE_SCOPES` is a dict (scope → label) of the five non-process scopes; `ALL_PROCESSES` = manifest permissions + `MODULE_SCOPES` + `EXTRA_PROCESSES` and `PROCESS_LABELS` likewise, same order as before. (4) `SPECS` entries are built by `oneshot_runs._spec(key, **callables)`; `routes._roster_ready` moved into the qb-usa manifest's `readiness`. (5) `schemas.ProcessKey` stays a hand-written `Literal` (the OpenAPI/TS client needs it statically); A3 holds it equal to the registry. (6) `PROCESS_CATALOGUE` is annotated `tuple[dict[str, Any], ...]` so the v3 callers keep type-checking. | 1-1.5 |
| A3 | Registry ↔ schema tests: 022 CHECK == registry, permissions ⊆ 030 CHECK, steps ⊆ state machine, OpenAPI enum == registry | `tests/test_registry_conformance.py` | reads the SQL off disk, the same way the existing constraint test does | A1 | LOCAL-NOW. **Built 2026-09-24.** Checks both chains: the Supabase migrations (022, latest `*_role_permission_processes.sql`) and the Alembic chain the loader reads. Also added: `TRANSITIONS` == `process_runs.VALID_STATES` == `schemas.RunState`; `schemas.ProcessKey` and the `RunEnvelope` variants == registry; every process enum anywhere in `openapi/meridian-v2.json`, the envelope discriminator and the `/api/v2/{id}/runs` paths == registry. The v3 document has no process enum (its `key` is a string), so there is nothing there to compare. **Changed after the A1 review (2026-09-24):** the Alembic SQL parser moved here from the loader; new tests hold the loader's stated CHECK values equal to BOTH chains, keep the widening-revision and empty-chain parser tests, and assert that importing the registry opens nothing under `migrations/`. | 0.5 |

### B — Take the processors out of `web_app.py` (plan: part of serialization)

| Id | Task | Files | Proof | Dep | Tag | d |
|---|---|---|---|---|---|---|
| B0 | Purity lint: `src/processes/**/processor.py` imports no flask, fastapi, boto3 or `web_app` | `scripts/lint_processor_purity.py`, CI | a test with a planted bad import fails | A1 | LOCAL-NOW. **Built 2026-09-24.** CI: a `Lint (processor purity)` step in `.github/workflows/backend.yml` next to the PHI lint, and a `processor-purity` pre-commit hook; `tests/test_lint_processor_purity.py` plants 15 bad import forms. **Deviation:** the banned list is wider than the plan's four: also `werkzeug`, `starlette`, `botocore`, and the HTTP layer (`api`, `src.api`: routers, the v2 error envelope); lazy imports inside functions, relative imports and `importlib.import_module`/`__import__` with a literal name all count, and there is no escape hatch. Only `processor.py` files are held to it (none exist until B1), so a manifest's lazy `web_app` validator call is allowed until B1-B3 move those checks. | 0.5 |
| B1 | Move `WebProcessor`, `process_in_background` and `validate_file_headers` to `src/processes/qb_revenue/processor.py`. `web_app` re-imports the names | as named | `test_revenue_qb_export.py`, `test_run_isolation.py`; a **golden test**: synthetic workbook (seed: `deploy/aws-trial/make_sample_revenue.py`) → `scripts/diff_je_output.py` exits 0 before vs after | B0 | LOCAL-NOW (timing rule). **Built 2026-09-24**, before the Phase 9 rehearsal (timing rule). **Gate:** `tests/test_processor_golden.py` captured every output of all three processors on synthetic inputs in its own commit (`24d77d6`) before anything moved (`make_sample_revenue.py` rows on an `All clinics` sheet plus an invented `Hosp_WSC` sheet, every output switch on, unposted with invented deposits, `emit_qb`): 20 JE CSVs byte-identical, 3 workbooks cell-identical, status and result identical after the move; `diff_je_output.py` before vs after: `20 identical, 0 differ, 0 missing`, exit 0. **Deviations:** (1) what revenue shares with mx-payroll (`OUTPUT_FOLDER`, `_require_je_date`, the lazy `db` property, `_publish_qb_export`, `_run_overview`) moved to `src/processes/shared.py`, held to the purity rules by construction (the B0 lint still scans only `processor.py`). (2) The one Flask dependency, "the request's org database if a request is being served" (`get_org_db`/`has_request_context` in `_lazy_db` and `get_db`), is now installed from outside: `shared.use_request_database(...)`, which `web_app` calls at import with late-binding lambdas; outside a request (every worker thread) the behaviour is unchanged, `get_database(org_id=None)`. (3) `processing_status` (the qb-revenue `RunStore`) moved with its worker; `web_app` re-imports it, so `oneshot_runs` reaches the same object. (4) `web_app` re-imports only the names something uses (`WebProcessor`, `process_in_background`, `processing_status`, `validate_file_headers`, and the shared helpers); `REQUIRED_HEADERS`/`parse_overview_sheet`/`_require_je_date` had no other consumer, and the imports only the moved code used are gone. (5) mypy: the moved processor carries 14 pre-existing findings (implicit-Optional defaults, loose annotations; `web_app.py` was never checked), so it has an `ignore_errors` override in `pyproject.toml` until C4-C7 rework it; `shared.py` is fully checked. (6) **Found and fixed:** `scripts/run_port_gate.py` redirected output by setting `web_app.OUTPUT_FOLDER`, which no longer steers the moved processor, so the gate would have written its PHI-adjacent batch folder into the repository's `output/`. It now imports the processor and sets ITS `OUTPUT_FOLDER`; a new test pins that. It no longer imports `web_app` (so it no longer picks up `.env` mid-run; it reads the environment it was started with, as its docstring says). (7) The moved code logs under `src.processes.qb_revenue.processor`/`src.processes.shared`, not `web_app`. (8) The manifest's validator calls the processor directly instead of importing `web_app`. | 1.5-2 |
| B2 | The same for mx-payroll (`process_payroll_in_background`, `_mx_detect_schedule`) | `src/processes/mx_payroll/processor.py` | `test_mx_payroll_column_map.py`, `test_payroll_qb_export.py`, golden diff on the existing fixtures | B0 | LOCAL-NOW (timing rule). **Built 2026-09-24.** **Gate:** there was no MX workbook among the existing fixtures (the real ones are client data), so `tests/test_processor_golden.py` builds an invented raw provider export (five made-up employees across five NetSuite departments, one with an indemnification, pesos at 18.25) and pins `_mx_detect_schedule`'s answer, the four JE CSVs (NetSuite and QB, main and provision) byte for byte and the run status, captured at `24d77d6` before the move; identical after it, and `diff_je_output.py` before vs after: `4 identical`, exit 0. The `excel` (processed-workbook) method is not covered: building a 103-column processed workbook by hand was out of proportion to a verbatim move; the wrapper code is shared by both methods and only the `PayrollProcessor` reader differs, which did not move. **Deviations:** (1) `payroll_processing_status` moved with its worker; `PAYROLL_PROCESSING_STEPS` (a Jinja-page concern) stays in `web_app`. (2) It reuses B1's `src/processes/shared.py` (`OUTPUT_FOLDER`, lazy `db`, `_publish_qb_export`, `_run_overview`). (3) `web_app` keeps re-exporting `PayrollWebProcessor` and `_run_overview` only because tests hold it to those seams (`# noqa: F401`). (4) mypy `ignore_errors` override as in B1 (2 pre-existing findings). (5) One `ruff format` change inside the moved code: a string literal split over two lines became one (same value). (6) The manifest's validator calls the processor directly. | 1 |
| B3 | The same for qb-usa (`_qb_usa_db`, `_qb_usa_run`, `_qb_usa_require_supabase`, `qb_usa_payroll_process_background`). `push_batch_to_qbo` stops taking `webapp` | `src/processes/qb_usa_payroll/processor.py`, `src/qb_usa_payroll_quickbooks.py` | `test_qb_usa_payroll*.py`, `test_qbo_*`; golden diff | B0 | LOCAL-NOW (timing rule). **Built 2026-09-24.** **Gate:** the real qb-usa inputs are client data (their tests skip on a fresh clone), so `tests/test_processor_golden.py` drives the export worker with a hand-built `RunResult` (two journals, one passing and one declared failing gate) against a recording database and storage: the two QuickBooks JE CSVs byte for byte, the review workbook's cells, the batch, journal and gate rows, the overview and the job status; and the parse wrapper `_qb_usa_run` on a stub parser (parsed, blocked-with-prompts, failed, cached). Captured at `24d77d6`, identical after the move. The parser itself (`process_qb_usa_payroll`) did not move and is not re-run on synthetic ADP files: none exist. **Deviations:** (1) **Behaviour change, deliberate:** `_qb_usa_db` read the org and user off Flask's `g`, which outside a Flask app context raises `RuntimeError` (reproduced). The processor's `_qb_usa_db(org_id, user_id)` takes them explicitly and `_qb_usa_run` passes the SESSION's ids, which every create path stores (Jinja upload from `g`, `qb_usa_runs.create_run` from the caller), so the Jinja page is unchanged and the FastAPI `/api/v2/qb-usa-payroll` create/get/review/preview/execute path, which reaches `_qb_usa_run` with no Flask context, no longer fails before the parser runs; a new test pins it. `web_app._qb_usa_db()` stays as the Flask adapter (`g` → the processor's). **Still open:** `qb_usa_runs.submit_review` calls `_webapp()._qb_usa_db()` (the adapter) from FastAPI, so it hits the same `RuntimeError`; not changed here (outside B3's files), see the report. (2) Also moved, because the worker calls them: `_qb_usa_undeclared`, `_qb_usa_clear_run_overrides` and the two `RunStore`s (`qb_usa_payroll_sessions`, `qb_usa_payroll_jobs`). `_qb_usa_roster`, `_qb_usa_load_from_db` and the `_QBUSA*Row` stand-ins stay in `web_app` (routes only). (3) `push_batch_to_qbo` AND `get_push_status` stop taking `webapp`; they look the processor module up at call time so a test patching its `_qb_usa_require_supabase` is the one that answers; `qb_usa_runs.push_to_quickbooks` and two tests updated. (4) The qb-usa processor is mypy-clean as moved, so it has no override. (5) `web_app` drops the now-unused module-level `tempfile`, `RunStore` and `LocalStorageManager` imports; the moved `_qb_usa_require_supabase` keeps its original function-local `LocalStorageManager` import (B1's `ruff --fix` had hoisted it; undone here). | 1.5 |

### C — Inputs to object storage and state serialization (plan: 10-15 d)

| Id | Task | Files | Proof | Dep | Tag | d |
|---|---|---|---|---|---|---|
| C1 | Create writes uploads to `{org}/{run}/uploads/` and records `{key, version_id, sha256}` in `process_runs.inputs`. `materialize_inputs()` downloads to a temp dir, verifies version and hash, and **refuses anything not tagged `NO_THREATS_FOUND`** (closes tracker row 89). Removes `unique_upload_path`, `params.filepath` and the local `input_dir` | `src/storage.py`, new `src/process_inputs.py`, `src/api/v2/oneshot_runs.py`, `qb_usa_runs.py` | `test_storage_s3.py` with Stubber: version pinned, tag refused → `FILE_UNSAFE` envelope; `LocalStorageManager` path for laptop tests | A2 | LOCAL-NOW†. **Built 2026-09-24** (`tests/test_process_inputs.py` — local store and botocore `Stubber`: version pinned, every non-clean GuardDuty status refused before any byte is fetched, untagged → pending, tampered hash/version/key/path refused, and on pg_fixture the recorded list is exactly what `app.authorize_job` accepts, a changed version or a missing file `inputs_mismatch`; `tests/test_process_inputs_oneshot_api.py`, `tests/test_process_inputs_qb_usa_api.py` — the v2 routes on the RDS path). **Deviations:** (1) **Gated on `database_is_postgres()`** (`process_inputs.enabled()`); off RDS nothing changes and tests assert it (`UPLOAD_FOLDER`, `params.filepath`, the qb-usa `input_dir`). (2) **Nothing is removed yet:** `web_app.unique_upload_path`/`UPLOAD_FOLDER` and the non-RDS branches stay for the Supabase path, and `web_app.py` was off-limits (parallel B1-B3); tracker row "The local upload folder is still the Supabase path's input store" owns the deletion. (3) A new module, `src/process_inputs.py` (`S3InputStore` / `LocalInputStore`, the shape of C3's state backends), rather than new `S3StorageManager` methods; `src/storage.py` only gains `vet_upload`, the one ingress gate (size, zip-bomb bound, type) that `_check_upload` now also calls. The record is `{bucket_role, key, version_id, sha256}` (what 0011 compares) plus `path` (where the file goes back in the input directory) and `bytes`; `message_versions()` is the four-field form for a `JobMessage`. (4) **The gate:** the tag is read for the exact version (`GetObjectTagging` + `VersionId`); `NO_THREATS_FOUND` only; any other status → `FILE_UNSAFE` (422, `details.reason` a code), no tag after the wait → `FILE_SCAN_PENDING` (409). Both codes are new in `errors.py`, contract §4.2 and both OpenAPI documents. A worker thread waits up to 300 s for the scan; a request never waits. `LocalInputStore` has no scanner (an untagged object passes, a tag is honoured) and is only built where dev fallbacks are permitted. (5) **Still pre-scan:** the create validates (one-shots) and classifies + first-parses (qb-usa) the request's own bytes before GuardDuty has scanned the stored object — that work is synchronous in the request until D4/C5 move it to a job. The one-shot worker always materializes through the gate (even on the task that took the upload), a qb-usa task rebuilding its inputs goes through it, and qb-usa's execute refuses to book unless every input is clean. Tracker row 88 is narrowed, not closed. (6) qb-usa stores the CLASSIFIED files (Excel already converted to CSV, canonical names) at their input-directory paths, not the raw browser bytes, so any task rebuilds the exact directory the processor reads. (7) The only local copy is a deterministic per-run scratch directory in the OS temp dir (`meridian-inputs/{org}/{run}`, never `UPLOAD_FOLDER`): the one-shot worker's is dropped when it returns (a retry after a restart refetches by version — the old `Path(filepath).exists()` failure is gone); qb-usa's stays until cancel, and a task without it rebuilds it (`ensure_local_inputs`). (8) Cancel leaves the stored objects (the api may only put under `uploads/`, PS-15); every put now carries `RAW_UPLOAD_TAG`, so `data.py`'s 30-day raw-upload lifecycle rule — which matched nothing until now — expires them. (9) A refused input fails a one-shot run (`failed`, the error code) before the worker opens it; an unreachable store fails it as `PERSISTENCE_UNAVAILABLE`. | 2 |
| C2 | Declared state classes: `RunState._persist` refuses undeclared keys; delete `_volatile`/`volatile=` | `src/run_store.py`, the manifests | new tests: undeclared key raises; `personnel` into a `touches_phi=False` process is fine, `phi` refused | A1 | LOCAL-NOW†. **Built 2026-09-24** (`tests/test_run_state_classes.py`; `tests/test_process_runs_pg.py` adjusted to declared keys). **Deviations:** (1) **Gated on `database_is_postgres()`** (`process_runs.run_state_classes_enforced()`): on RDS a `RunState` write or a `patch_run_state` naming an undeclared key, a `phi` key or a platform key raises `process_runs.RunStateRefused(code, process, key)` before anything is written; `never` keys are neither persisted nor cached (and `patch_run_state` refuses them). The Supabase path on Render is untouched: `volatile=` keys still go to `_volatile`, any JSON key is still persisted. (2) **`_volatile` is not deleted, and `volatile=` stays** (web_app's four `RunStore(...)` calls are off-limits to this task): on RDS the cache holds only `run_store.LEGACY_CACHE_ON_POSTGRES` — qb-usa `result`/`prompts`/`alerts` — because `web_app.qb_usa_payroll_process_background` raises instead of recomputing when `sess['result']` is missing; tracker row "One process-local run cache is left on RDS" owns it (B3 or C5). qb-revenue's `result` cache IS gone on RDS: its only reader (`oneshot_runs._result_overview`) reads the persisted `result_overview`. (3) The three shipped manifests now declare every key their writers use (inventory: a key spy over the process test suites plus an AST scan of `web_app.py` and the v2 run modules). Shared pieces live in `src/processes/manifest.py`: `RUN_STATUS_FIELDS` (the job-status vocabulary, spread into each manifest) and `PLATFORM_STATE_FIELDS` (`state_objects`, `run_overrides`, `superseded_by_run_id` — written only by their own functions, refused from any application write and from a `JobOutcome`, and the loader refuses a manifest that declares one). `src.processes.state_class(process, key)` answers a key's class. (4) Classes chosen fail closed: `error` and `workbook_error` are `personnel` (legacy workers still write an exception's text there, CX-API-05); `user_email`, `declared_by`, `declaration_note`, `cancelled_by`, `result_overview` (pay aggregates) and qb-usa `blockers` (employee keys) are `personnel`; mx-payroll `result` is `personnel` (always persisted, payroll totals); qb-revenue `result` and qb-usa `result`/`prompts`/`alerts` are `never`. (5) **The upsert race is fixed in `PostgresRunStore.upsert`**, not by fencing: a caller's `run_state.state_objects` is dropped from every write, and the `ON CONFLICT` arm re-attaches the STORED `state_objects`. So an api write from a snapshot read before the worker recorded a version, a terminal `set_state`, or a `patch_run_state` keeps the record, and no write can forge or clear it (pg tests for all three). Only `src/process_state.py`'s fenced UPDATE writes the key. Other `run_state` keys keep today's last-writer-wins window (documented in `patch_run_state`); the worker's settle already merges with `||`. (6) A static guard (`test_every_key_todays_writers_use_is_declared`, with a planted-key control) scans `web_app.py`, the v2 run modules and any `src/processes/**/processor.py` (B1-B3's destination) for keys a run-store writer uses that no manifest declares. | 1.5 |
| C3 | State-object store: JSON to `{org}/{run}/state/`, writer metadata, version recorded in `run_state.state_objects`, reader refuses unrecorded versions and non-`state/` keys; `src/phi.py` `open_state()` with audit rows | new `src/process_state.py`, `src/phi.py` | pg_fixture + Stubber: tampered version refused; the `phi` class writes two `audit.phi_access` rows; `lint_no_phi_logging.py` clean | C2 | LOCAL-NOW. **Built 2026-09-24** (`tests/test_process_state.py`). **Deviations:** (1) C2 has not landed, so the classification rule is enforced here for state objects only: a name must be declared in `state_fields` as `personnel` or `phi`; `public` (belongs in `run_state`), `never` and undeclared names are refused. The shipped manifests declare nothing yet, so nothing can write until C2/C5 declare fields; `state_objects` is a reserved `run_state` key C2 must allow. (2) The version is recorded by ONE fenced `UPDATE` (`lease_owner`, `last_job_id`, `lease_expires_at > now()`, revision 0011): only the current lease holder records; a worker that lost its lease gets `lease_lost`, and its put stays an unrecorded version that is never read. (3) The reader is stricter than "a `state/` key": the record must name exactly `{org}/{run}/state/{name}.json`, its class must equal the declared one, and the bytes must match the recorded sha256 as well as the version. (4) `phi.open_state(action, org, run, name, user)` is `with_phi_access` with `action` `state_write`/`state_read` and `object_name` `state:{run}/{name}`; writes are audited as well as reads (a pair of rows each). `personnel` objects also land in the `phi` bucket (`bucket_for('state')` fails closed to `phi`) but are not PHI accesses, so no audit rows. (5) DataFrame `orient="split"` encoding lands with its first consumer (C4/C5); until then any non-JSON type is refused by type name, never value. (6) `LocalStateBackend` (immutable version files under `data_path('output', 'state')`) serves the laptop and tests; `default_backend()` refuses local disk where dev fallbacks are not permitted. Objects are capped at 50 MiB (the §7.1 parquet trigger). | 1.5 |
| C4 | qb-revenue: persist `result_overview` only; results and artifacts read tie-out; retry uses `input_object_versions` | `src/processes/qb_revenue/*`, `oneshot_runs.py` | `test_api_v2_oneshot_runs.py` with the cache removed; a retry after a simulated restart still works | B1, C1-C2 | LOCAL-NOW†. **Built 2026-09-24** (`tests/test_oneshot_jobs_pg.py`): `processor.handle_job` is the `execute`/`retry` `JobSpec.handler`; through `workers.run_job` on pg_fixture + `InProcessQueue` + `LocalStateBackend`, the golden synthetic export gives all 20 JE CSVs byte-identical to `tests/golden/processors/qb_revenue/journal_entries/`, and the two QuickBooks CSVs byte-identical in the artifact store, tied out once; killed after the checkpoint → the resume does not recompute (one compute, one batch, one tie-out set, `attempts` 2); killed mid-compute → recomputed from the upload, one live batch; blocked → a `retry` job after a simulated restart (new queue, no local files) completes from the recorded upload version; a flagged upload fails `FILE_UNSAFE` unopened; the org's settings, not the file, decide the outputs. **Deviations:** (1) **Gated on `database_is_postgres()`**: the handler refuses off RDS (`WORKER_NOT_ENABLED`) and nothing enqueues it until D4, so the live create/retry still run `process_in_background` on the in-process thread, unchanged (goldens byte-identical on that path; Render/Supabase untouched). (2) Two steps and a CHECKPOINT state object, `revenue_outputs` (`personnel`): *compute* (the recorded upload through the malware gate, the header check again after the gate, `process_with_progress` + the unposted step into per-run scratch) and *export* (publish + email, then the checkpoint is re-recorded as `notified` so a second resume does not mail twice). The checkpoint holds only the QuickBooks CSVs (base64) and a totals-and-ids summary, and is keyed to the `job_id`, so a `retry` job recomputes. `_workbook_data` (the enriched DataFrame = the whole billing export, PHI) and `result` are **not** serialized: they live only inside the compute step, and a kill there recomputes from the upload (class `never`, §3.6). Persisting a PHI copy would serve only the workbook re-export, whose file is scratch on this path. (3) **Outputs:** the batch folder and the archive copy go to `<tmp>/meridian-jobs/{org}/{run}`, removed when the job returns, never `output/`/`archive/` in the working directory (`WebProcessor(output_root=...)`; `OUTPUT_FOLDER` stays the default, so `run_port_gate.py` still steers the thread path). Durable: the database rows, the tie-out, the QuickBooks CSVs in the artifact store (`_publish_qb_export`, unchanged, `artifacts` bucket) and `run_state.result_overview`. The NetSuite CSVs and the three workbooks (`data/`, `reports/`: PHI) are **not kept** on the worker path, which is what Render does today (only the QuickBooks CSVs reach storage); uploading them to the `phi` bucket is a decision for Andres. **Changed 2026-09-24 (worker download parity, directed by the lead):** on RDS both the worker job and the thread now publish them (`shared.publish_run_outputs`: the NetSuite JE CSVs to the `artifacts` bucket; the enriched-data, revenue and validation workbooks to the `phi` bucket, each write through a new audited `src.phi.open_artifact`), record the list in `run_state.published_outputs` (declared `public` in `RUN_STATUS_FIELDS`: names, sizes, sha256), and the v2 artifact endpoints list and sign them after the tie-out's QuickBooks CSVs (the path rebuilt from org/batch/subfolder/name, never read back; a `phi`-bucket mint — these workbooks, qb-usa's review workbook, any bundle — is an audited `artifact_mint`). The job publishes the workbooks in its compute step, before its checkpoint (they are PHI and never ride in the `personnel` checkpoint); C7's fixed batch and file names make a recompute overwrite the same keys. The thread path writes the revenue workbook twice (before and after unposted, each under "now"); only the newest is published, so both paths list the same files. `tests/test_worker_downloads_pg.py`: the worker's list equals the thread's for the golden inputs (revenue and mx), every file equals the thread's and the golden (CSVs byte for byte, workbooks cell for cell; the revenue workbook's "Lookup Table" sheet prints the org's provider table — the database's on RDS, `mappings.xlsx`'s in the golden run — and is compared with the thread's only), the audit rows, the forged-list refusal, nothing off RDS. (4) `JobOutcome.batch_id` (new, optional): the settle writes `process_runs.batch_id` (`COALESCE`, fenced like the rest; `_checked` refuses a non-int). The tie-out, the artifacts and §12.10's batch supersede are keyed on it. C5 may want the same field. (5) **Tracker T:44:** the four `AppSettings()` reads are `WebProcessor.app_settings()` = `shared.org_app_settings(org_id)`: `organizations.settings.app_settings` on `DATABASE_BACKEND=postgres`, the file elsewhere; `WebProcessor(org_id=...)` also uses it for `__init__`'s exporters, and `process_in_background` passes its org, so the thread path on RDS reads the org's settings too. (6) Codes only: a processor failure settles `EXPORT_FAILED` (never `str(e)`); input refusals keep their code (`FILE_UNSAFE`, `FILE_SCAN_PENDING`, `FILE_HEADERS_INVALID`); also `RUN_EXPIRED`, `PERSISTENCE_UNAVAILABLE`, `LEASE_LOST`. No mid-job progress on the worker path (D3's `JobContext` has no fenced progress write): the run shows `running` until it settles. **Changed 2026-09-24 (mid-job progress):** `JobContext.progress(percent, step_code)` writes `run_state.step`/`message`/`progress` (the thread's keys, what the React processing screen reads) in one UPDATE fenced on the lease AND the state the job runs in; the code must be a key of a new manifest field, `progress_steps` (code → the fixed sentence the thread shows; the loader refuses a non-code key or an empty sentence), and the sentence written is the manifest's, never the handler's; a percent outside 0-100 or an undeclared code raises `ProgressRefused`; a lease lost or a run moved under the job → False, nothing written; a database error on a progress write is skipped (logged by class), never fatal to the booking. The three handlers use it: qb-revenue and mx-payroll pass `shared.job_progress(ctx)` as the processor's `progress_callback`; qb-usa's `_RunReport.progress` now goes through it (it was an UNFENCED `patch_run_state`), and its failure step is a code (`error` "Nothing was saved." / `error_recorded` "Export failed after the run was recorded."; the batch id is on the run, no longer in the sentence). `tests/test_job_progress_pg.py`: for the golden inputs a poll of the v2 envelope after each fenced write shows exactly the (step, sentence, percent) the thread path writes after the same step (revenue, mx), qb-usa's six steps, the fences, the refusals. (7) A kill mid-compute leaves the dead attempt's `processing` batch; the resume's own `create_batch_superseding` (same file, same period) retires it, so there is one live batch but two rows. Reusing the batch id is C7. (8) mypy: the B1 `ignore_errors` override is gone (with C6): Optional defaults typed, and the annotations of `get_database`, `load_revenue_maps` and `export_revenue_qb(hospital_transactions)` corrected (no runtime change). (9) `oneshot_runs.py` is unchanged: C1 already made the RDS create/retry use recorded input versions, and C2 already removed qb-revenue's `result` cache on RDS; the Supabase path keeps its `volatile=('result',)`. `_generate_unposted` was lifted verbatim out of `process_in_background` so the thread and the job share it. | 1.5 |
| C5 | qb-usa: `parse` job writes review and preview snapshots; review, preview and declarations endpoints read snapshots instead of calling `_qb_usa_run`; `execute` recomputes from uploads; decide the class of the preview journal lines (fail closed) | `src/processes/qb_usa_payroll/*`, `src/api/v2/qb_usa_runs.py`, `api/routers/qb_usa_runs.py` | the contract §3A walk-through as a test; **§12.6 preserved**: a raised roster exception gives `has_result:false` and preview 409; a canary test: no DOB, member-id or net-pay field names in any stored state | B3, C1-C3 | LOCAL-NOW†. **Built 2026-09-24** (`tests/test_qb_usa_snapshots_pg.py`, pg_fixture + `InProcessQueue` + `LocalStateBackend`: the §3A walk-through on the RDS routes with both jobs; §12.6 — a RAISED roster exception gives `has_result:false` and preview 409; parse on worker A, execute on worker B (no scratch files, no cache, its own queue, lease owner and store object) → the real parser's nine JE CSVs on `tests/fixtures/qb_usa_payroll/clean` byte-identical to the in-memory golden `tests/golden/processors/qb_usa_payroll_parser/`, and on the stand-in parser byte-identical to the legacy worker's; the roster-blocked set's prompt stored field for field; a parse killed mid-write resumes on another worker with one recorded version per name; a tampered snapshot (sha mismatch) is refused by the routes and by the execute job; a changed run-only answer after the preview → `PREVIEW_STALE`, nothing booked; a file GuardDuty did not clear → `FILE_UNSAFE`, never parsed; canary: date-of-birth, net-pay, member-id and deposit column names and values in the raw inputs reach neither the `process_runs` row nor any state object). **Deviations:** (1) **Gated on `database_is_postgres()` AND the RDS run store being in use** (`qb_usa_runs._snapshots_enabled()`, `process_runs._postgres_configured()`): the lease, the `state_objects` record and `app.authorize_job` only exist there. The Supabase path and the dev fallback (postgres with no `POSTGRES_URL` → in-memory run store, what `test_process_inputs_qb_usa_api.py` runs) keep the in-request parse. (2) **Three state objects, not two** (`src/processes/qb_usa_payroll/snapshots.py`, explicit field lists, never `asdict`): `review_snapshot` **personnel** (prompts, alerts, has_result, the fixed error sentence, roster source); `preview_snapshot` **personnel** (journal number/date/variant/kind/line count/total, a **sha256 of each journal's lines**, gate figures, offender COUNT and the "checks/why" text computed from the full offenders so it reads as it did live — it can name one employee); `gate_offenders` **phi**, because a G5 offender is a carrier-bill row (subscriber id + premium: group-health-plan data) — written and read only through `phi.open_state` (audited), read only by `GET …/preview` when it will show a preview. **The class decision for the preview journal lines: not stored at all** (the digest is); the RunResult, `inputs`, `employee_runs`, maps and roster tables stay `never`. Every document carries the parse's job id and a reader refuses a mixed set. (3) **Behaviour change, deliberate:** on RDS the envelope (poll, review, declarations) carries gate offender COUNTS and `offenders: []` in every state; the people come only from the preview endpoint (the React preview screen already reads them there). (4) **Execute recomputes, and proves it books the preview:** `execute_job` requires every input clean, parses the recorded uploads, and refuses `PREVIEW_STALE` unless its preview document equals the recorded one (totals, gates and the per-journal line digests, so a re-coded person is caught), `SNAPSHOT_REFUSED` when the recorded preview fails verification; then the same `_export` as the legacy worker (split out of `qb_usa_payroll_process_background`; the B3 golden is unchanged). A refused execute is terminal `failed` (`running` cannot go back to `needs_input`); job failures record codes only, never exception text. (5) **Transport:** the v2 routes run the jobs through `workers.run_job` on a private one-message `InProcessQueue` (`workers/inprocess.py`): the parse synchronously in the create/review request (as before, after the request's own no-wait input fetch, so a pending scan is still a 409), the execute on a thread, the request answering once the job holds the lease and the run is `running` (so the envelope is still `running:processing`). That is D4's mechanism for this one process on RDS; D4 still owns `enqueue()`/SQS, `WORKER_PROCESSES` and the other two thread sites. **Open (D4):** nothing redelivers an in-process message, so a task killed mid-job leaves a leased run the sweeper fails only at `attempts >= 3`. **Closed 2026-09-24 (D4):** `Dispatcher.recover()` over `app.redeliverable_jobs` (0022). (6) Jobs act for the run's **creator** (`app.authorize_job` accepts no one else), whoever pressed the button; the route has already checked the caller. (7) A failed parse's `process_runs.error.message` is now the settle's ("The run stopped with FILE_UNREADABLE."); the code is unchanged. (8) A snapshot the routes cannot verify answers 500 `INTERNAL_ERROR` with `details.reason` (the `StateError` code): no new error code. (9) The poll never parses on RDS; a run with no recorded parse answers the plain envelope; review/preview/declarations parse (as a job) only when no parse is recorded. (10) `_decide_state` moved into the processor (`decide_state`), shared by the routes and the parse job. (11) `LEGACY_CACHE_ON_POSTGRES` is deleted and on RDS `RunState` neither reads nor writes `_volatile`; the legacy `qb_usa_payroll_process_background` re-parses a session with no result (Jinja path) instead of raising; tracker row closed. (12) Not done here: `batch_id` reuse on a resumed execute (C7 — a resume after the batch row allocates a second batch). | 3-4 |
| C6 | mx-payroll: inputs only | `src/processes/mx_payroll/*` | `PERIOD_UNDETECTABLE` still fails the run | B2, C1 | LOCAL-NOW†. **Built 2026-09-24** (`tests/test_oneshot_jobs_pg.py`): `processor.handle_job` is the `execute` `JobSpec.handler`; through `workers.run_job` the golden raw export gives the four JE CSVs byte-identical to `tests/golden/processors/mx_payroll/journal_entries/`, the two QuickBooks CSVs in the artifact store once; killed after the checkpoint → one compute, one batch; a stored file whose period cannot be read fails the run with `PERIOD_UNDETECTABLE` and books nothing (the manifest's validator runs on the materialized file, after the malware gate). **Deviations:** (1) More than "inputs only": the same two-step handler and checkpoint as C4 (`mx_outputs`, `personnel`: the QuickBooks CSVs and a totals summary) and the same per-run scratch output, so a resumed attempt publishes instead of booking again. mx-payroll had nothing volatile to move. (2) On completion the worker path writes `result_overview` only; the thread path also persists the whole `result` (`personnel`, carrying local file paths) and still does. (3) The raw-export exchange-rate rule is re-checked in the job (`VALIDATION_ERROR`), as `_mx_prepare` does at create. (4) A failure after the batch exists restores the booking it superseded (the thread's rule), then settles `JOB_FAILED`/`EXPORT_FAILED` with no text. (5) `_run_processor` was factored out of `process_payroll_in_background` so the thread and the job set the processor up identically. | 0.5 |
| C7 | Re-runnable handlers: reuse `process_runs.batch_id`; deterministic output keys; `superseded` still set once | the processors, `src/process_runs.py` | run a handler twice in a row → one batch, identical outputs, one `supersede_earlier_runs` effect | C4-C6 | LOCAL-NOW†. **Built 2026-09-24** (`tests/test_rerunnable_jobs_pg.py`, pg_fixture + `InProcessQueue`: revenue killed before its transactions, after its quarantined transactions and after its journal lines → the resume books into the SAME batch id, two rows in all (the clean run's, retired once, and the resumed one's), journal lines and transactions equal to a clean run's, one tie-out set, the 20 JE CSVs byte-identical to the golden, and the earlier run of the period superseded once by this run; a blocked revenue run retried → the id its first attempt allocated, one row; an attempt stopped by SIGTERM and one whose settle hit a database outage → redelivered into the same batch, one row, one tie-out set; mx killed after its employees → one row, employees not doubled, golden CSVs; qb-usa `execute` killed on its first upload → resumed on another worker into the same batch, one row, three journal and three gate rows (C5's open item closed); the batch folder and revenue workbook names identical on every attempt; the intent's fence and validation; an application write can neither forge nor clear it; `insert_transactions` on a reopened batch replaces unquarantined rows, keeps an identical quarantined set and refuses a different one). **Deviations:** (1) **Write-ahead, not "reuse `process_runs.batch_id`" alone:** the id is allocated from the sequence (`DatabasePostgres.allocate_batch_id`) and recorded on the run BEFORE the row exists, in `run_state.batch_intent` (a new PLATFORM key, `{batch_id, supersedes: {id, status}}`), by a new fenced `JobContext.record_batch` (the D3 context gains its first extra callable; `BatchNotRecorded` when the lease is gone or another id is already recorded). `process_runs.batch_id` has a foreign key, so it can only point at a row that exists; `record_batch` sets it once the row is in. Reading `process_runs.batch_id` alone would leave the window between the INSERT and the record, where a kill still creates a second row. `shared.open_job_batch` then inserts the row WITH that id if it is missing (never inserted, or deleted by a `blocked` rollback — so a `retry` reuses the id too), or reopens it (`reset_batch_for_rerun`: journal lines, unmapped items, payroll employees, qb-usa journal and gate rows, the tie-out and the upload's source-transaction copy, in one transaction; status back to `processing`) after checking it is the same booking (`BATCH_MISMATCH` otherwise). The booking it retires is recorded in the intent, so a failure after a resume restores the right one with its status. `PostgresRunStore.upsert` keeps the stored `batch_intent` as it keeps `state_objects`. (2) **Transactions cannot all be deleted:** identifiers quarantined in `phi.transaction_identity` block the delete (no DELETE grant), so `insert_transactions` on a reopened batch deletes the dead attempt's rows only when none is quarantined, keeps an identical fully quarantined set (skipping the insert), and raises `BatchRerunConflict` otherwise (a mapping changed between attempts). (3) **Deterministic names:** the processors' "now" (batch folder, revenue workbook) is the RUN's creation time on the worker path (`shared.run_stamp`, `WebProcessor.run_stamp`, `RevenueWorkbookExporter.stamp`); the thread path keeps "now". (4) The processors take the reuse through a `batch_opener` attribute (None = `create_batch_superseding`, unchanged for the thread path, the CLI and the Supabase backend); qb-usa's `_export` asks its report object for the batch (`create_batch`), the legacy worker's creating one as before. `create_batch`, `create_payroll_batch` and `qb_usa_payroll_store.create_run_batch` accept a pre-allocated `batch_id` (RDS only). (5) qb-usa's job no longer writes `process_runs.batch_id` unfenced (`_RunReport.batch` is gone; `record_batch` does it) and settles with `JobOutcome.batch_id`. (6) `superseded` once: the processors' supersede runs only when the row is first inserted; §12.10's run supersede is the settle's, which lands once. | 1-1.5 |

### D — Worker and queue (plan: 5-7 d, together with E)

| Id | Task | Files | Proof | Dep | Tag | d |
|---|---|---|---|---|---|---|
| D1 | `JobMessage` model; `JobQueue` protocol with `InProcessQueue` and `SqsQueue` | `workers/contract.py`, `workers/transport.py` | Stubber: SendMessage and ReceiveMessage shapes; `extra='forbid'` rejects unknown fields | — | LOCAL-NOW. **Done 2026-09-24** (`tests/test_job_transport.py`). **Deviation:** the actor is `{"actor_type": "user"\|"client", "actor_id"}` (Phase 12 R17) instead of `actor_user_id`; a second message type `SweepMessage` (`kind: "sweep"`, no run) shares the v1 contract so D5 needs no new shape; parsing is strict JSON and the error lists field codes, never values; `bucket_role` is `phi` only (uploads always land there) and every input key must sit under this run's `{org}/{run}/uploads/`. `InProcessQueue` reproduces SQS semantics (visibility, fresh receipts, redrive after 3, stale-receipt heartbeat → `ReceiptExpired`) so D3 can be tested on it; it does not start threads (that is D4's dispatch). Malformed bodies are dead-lettered by the transport (`malformed_message`) and never reach the loop. | 1 |
| D2 | Alembic `0011_process_runs_worker`: lease columns, `app.authorize_job`, `app.claim_run`, `app.expire_stale_runs` (definer, `SET search_path`), grants | `migrations/versions/0011_*.py` | `tests/test_worker_authorization_pg.py`: cross-org, wrong actor, actor removed from the org, wrong state, wrong version → refused; double claim → one winner; downgrade works | — | LOCAL-NOW (additive; RDS-only chain). **Done 2026-09-24** (`tests/test_worker_authorization_pg.py`, `tests/test_migration_chain_roundtrip.py`). **Deviations:** (1) the functions are owned by a NOLOGIN `meridian_job_control` role with column grants + `USING (true)` policies for that role only, not by the migrator (FORCE RLS binds the owner; 0013's lesson), and the migrator's membership is `INHERIT FALSE` so those policies never reach its sessions (a control test proves an inheriting migrator would see every run); (2) EXECUTE goes to `meridian_app`: there is no separate worker DB role, the worker runs the api image; (3) `authorize_job` returns one row `(authorized, reason, current_state)` with a reason code, and a run in another org answers `run_not_found` like a missing one (no tenant probing); it takes the job's `from_states` as an argument; the client-actor branch reads `api_clients`/`created_by_client_id`, which 0013 creates, so 0013 grants the three columns and a policy (branch is planned lazily; before 0013 a client is `actor_unknown`); inputs compare as a multiset of `{bucket_role,key,version_id,sha256}` against `process_runs.inputs->'object_versions'` (the key C1 must write); (4) `claim_run` counts attempts per job (`last_job_id`; a new job restarts at 1) so a run's parse/execute/push claims do not add up to the sweeper's 3, and refuses terminal runs; (5) `expire_stale_runs(dry_run)` also fails a stale-lease `parsing` run (same lost-worker case), returns `(run, org, from, to)` ids only, error `{code: RUN_FAILED}`; (6) heartbeat and release are ordinary scoped UPDATEs under `with_org` in D3, not definers; (7) the round trip is head → 0005 → head (0001-0003 and 0005 refuse to downgrade by design). 0013 re-pointed onto 0011. | 1.5 |
| D3 | `workers/main.py` loop: authorize → claim → heartbeat → dispatch → transition → delete; refusal goes to the DLQ with a reason code; SIGTERM releases the lease; structured logs with ids only | `workers/{main,run_job,__main__}.py` | InProcessQueue + pg_fixture: happy path; duplicate delivery → one execution; **kill simulation** (lease expires mid-handler) → the second worker resumes, no orphaned state object; handler exception → `failed` with a code and no `str(exc)` | D1, D2, C3 | LOCAL-NOW. **Built 2026-09-24** (`tests/test_worker_loop_pg.py`: happy path, duplicate body, redelivery while running + stale-receipt heartbeat, kill → resume with one recorded state key, three lapsed leases → DLQ `max_receive_count` → `expire_stale_runs` fails the run, wrong org / wrong actor / removed actor / wrong process / `inputs_mismatch` → DLQ with the code, lease stolen → no settle, SIGTERM through the real signal path). The handler is a test double through `JobSpec.handler`; the real processors are untouched. **Deviations:** (1) `authorize_job` is called with the job's `from_states` PLUS its working state (`parse`→`parsing`, `execute`/`retry`→`running`) so a killed job can resume; the resume is allowed only when the run's `last_job_id` is this job (read in-org after authorize), otherwise DLQ `state_not_allowed`. (2) The worker, not the api, moves the run into the working state, and only where `TRANSITIONS` allows it (`needs_input`→`parsing` is not legal, so a re-parse stays in `needs_input`); D4 must stop the api setting `running` itself. (3) A redelivery of a job that already settled (`last_job_id` = this job, lease NULL/NULL) is acknowledged and deleted, not dead-lettered: on `state_not_allowed` (0011 answers that only after org, actor and process matched, which is what justifies entering `with_org`) and also after a successful authorize (a parse that settles back into `needs_input`). (4) The lease is `JobSpec.timeout_s` (the 600 s placeholder, under the 900 s visibility); the heartbeat (every 120 s, and `ctx.heartbeat()` on demand) extends both. The lease owner is the worker id plus a per-delivery suffix, so two deliveries in one process never share a lease. Every write after the claim — working state, heartbeat, state-object record, settle, release — is fenced on `lease_owner` + `last_job_id`, and the settle also on the state the job ran in, so a run cancelled or swept mid-job is not overwritten. (5) A stale receipt on heartbeat is noted and the job carries on (the lease decides); the final delete is then a no-op and the redelivery is acknowledged as a duplicate. (6) SIGTERM raises `WorkerStopping` only while a handler runs; release sets `lease_owner = NULL`, `lease_expires_at = now()` (not NULL: claimable at once and still visible to the sweeper) and the message visibility to 0. (7) A handler exception fails the run with the exception's own well-formed `code` (e.g. `ProcessInputError`) or `JOB_FAILED`, logging the class name only; an outcome the platform cannot accept fails it with `ILLEGAL_TRANSITION`, `STATE_UNDECLARED` (a `run_state` key not declared `public`/`personnel`, or a reserved one) or `JOB_OUTCOME_INVALID`. (8) Refusal codes beyond 0011's: `unknown_process`, `unknown_job`, `no_handler` (every shipped manifest until B1-B3 wire handlers) and `sweep_not_enabled` (D5 plugs in there). A database error before settle leaves the message for redelivery; it is not a refusal. (9) `JobContext`/`JobOutcome` live in `src/processes/manifest.py`; a handler gets ids plus `write_state`/`read_state`/`heartbeat` callables and nothing else. (10) `python -m workers [--once] [--wait-seconds N]` reads `MERIDIAN_JOBS_QUEUE_URL`/`MERIDIAN_JOBS_DLQ_URL` (`src/settings.job_queue_urls`, for H1 to set) and `MERIDIAN_WORKER_ID` (default host/pid). (11) A `completed` settle runs `supersede_earlier_runs` best-effort, as `process_runs.set_state` does. **Open (E2):** `qbo_push` starts from `completed`, and `app.claim_run` refuses terminal runs, so a `qbo_push` job can never be claimed as 0011 stands. **Closed 2026-09-24** (E2 prerequisite, revision `0018_push_claim_and_input_digest`): `app.claim_post_completion` leases a `completed` run for `qbo_push` only (any other kind raises; `claim_run` unchanged); the worker claims through it when `POST_COMPLETION_KINDS` meets a terminal run, settles a successful push back into `completed` without superseding, and on a failed push RELEASES the lease and leaves the message (redelivery, then DLQ) instead of turning the booked run `failed` (`tests/test_post_completion_claim_pg.py`, `tests/test_worker_post_completion_pg.py`). | 2-2.5 |
| D4 | Replace the three live thread sites (`oneshot_runs.py:703`, `:818`, `qb_usa_runs.py:1426`) with `enqueue()`. Add a per-process `PROCESS_SUBMISSIONS_PAUSED` switch that returns 503 (rollback step 1). `WORKER_PROCESSES` allowlist | `src/api/v2/*`, `api/routers/*`, `src/settings.py` | `test_api_v2_*` green on the `inprocess` transport; paused → 503 envelope | D3, C4-C6 | LOCAL-NOW†. **Built 2026-09-24** (`tests/test_job_enqueue_pg.py`: the one-shot v2 routes on RDS with stand-in handlers — the worker, not the api, moves `draft`→`running`→`completed`; blocked → retry through the queue; mx; per-process allowlist; empty allowlist and off-RDS = the old thread; pause → 503 + the catalogue; SQS send via botocore `Stubber` with the worker half driven from the sent body; a refused send → 503 with the run given back or failed. `tests/test_job_enqueue_qb_usa_pg.py`: qb-usa's execute through the dispatcher with the real C5 jobs, unrouted keeps its private queue, SQS + a queued poll, pause. `tests/test_job_enqueue_golden_pg.py`: the routed v2 create with the REAL C4/C6 handlers books the golden qb-revenue (20) and mx JE CSVs byte for byte. `tests/test_inprocess_redelivery_pg.py`: redelivery. `tests/test_execute_compare_and_set_pg.py`, `…_qb_usa_pg.py`: the compare-and-set). **Deviations:** (1) **Gated on `database_is_postgres()` AND the runs in `PostgresRunStore` AND the process on `WORKER_PROCESSES`** (`runs_common.jobs_routed`); empty (the default) is today's behaviour — the one-shots on `web_app`'s thread, qb-usa's C5 jobs on a private one-message queue — and Supabase is never routed. The switch-on is the env var (I2-I4), not a code change. (2) **Nothing is deleted:** the thread sites are the §5.2 rollback target and go per process after its gate (§5.3; tracker row "Two execution paths per one-shot process"). (3) **The api's start is ONE compare-and-set** (`process_runs.begin_action`): same state/step/`last_job_id` as the state check read, no queued job, no live lease → `step = processing` plus a queued-job marker (`last_job_id` = the new job, `attempts` 0, an ownerless lapsed lease, so `claim_run` makes it attempt 1 and D3's "already settled" test cannot match). The loser gets `409 RUN_STATE_CHANGED` (new code). The legacy thread path on RDS uses the same UPDATE, moving `blocked`→`running` itself as it always did. This closes E3's open item (6). A start no worker claimed is taken back (`abandon_action`); a routed create whose job cannot be queued is left `failed` with the code, so an Idempotency-Key replay does not find a `draft` nothing will move. (4) **qb-usa: only `execute` is enqueued**; its `parse` stays in the create/review request (`inprocess.run_now`, the same `run_job`) even when routed, because both answer WITH the parse (tracker row, with F3/T20). (5) **The in-process transport is a process-wide `Dispatcher`** (`workers/inprocess.py`): one `InProcessQueue` with SQS's semantics, a thread per delivery, a background pump; `workers/dispatch.enqueue` is the api's one door to either transport, and in-process it waits until the handler has begun so the request still answers `running`. On SQS the run answers `draft`/`ready` with step `processing`; the one-shot poll keeps a queued run on `processing` and the qb-usa poll never re-parses it. (6) **Redelivery** (the C5 open item): a dead delivery thread's message reappears after its visibility timeout; a KILLED process is covered by `Dispatcher.recover()` over the new definer `app.redeliverable_jobs` (revision **0022**; written beside 0020/0021, re-pointed onto `0021_qbo_connection_audit` at the merge): a working run whose lease lapsed after 1-2 claims, or a queued job unclaimed after 5 min, is delivered again with the SAME `job_id`; at 3 claims the sweeper still fails it; runs routed to SQS are SQS's; a job this process dead-lettered is not retried by it. The api starts the dispatcher at boot on RDS (`api/main.py`). (7) `PROCESS_SUBMISSIONS_PAUSED` → `503 PROCESS_PAUSED` (new code, retryable) on create/execute/retry and qb-usa's review (a parse), RDS only; `/api/v2/processes` lists the process `enabled: false`. (8) An unknown id in `WORKER_PROCESSES`/`PROCESS_SUBMISSIONS_PAUSED`, or an unknown `JOB_TRANSPORT`, is a configuration error, not ignored. (9) `test_api_v2_*` themselves run on the in-memory store, where nothing is routed (they stay green, unchanged apart from the D4-wave upload fixtures); the routed-path proofs are the new pg modules above. (10) In the same wave: E3's stale `pending` key times out after 15 min by the database clock; the C1 follow-up magic-byte check (`src/file_signature.py`, `FILE_TYPE_INVALID`) at every upload ingress. ADR 0028 written. | 1 |
| D5 | Sweeper job plus a CLI (`python -m workers.sweep --dry-run`) | `workers/sweep.py` | expired `needs_input` → `expired`, overrides dropped; stale `running` → `failed` after 3 attempts | D2 | LOCAL-NOW†. **Built 2026-09-24** (`tests/test_worker_sweep_pg.py`: expired `needs_input`/`draft` → `expired` with `run_overrides` dropped and the rest of `run_state` kept; stale `running`/`parsing` at 3 attempts → `failed`, at 2 left alone; dry run lists the same moves and writes nothing; the `sweep` message sweeps and is deleted; off RDS → DLQ; a database outage → left for redelivery; CLI `--help` with no environment, `--dry-run`, refusal off RDS). **Deviations:** (1) Gated on `database_is_postgres()`: off RDS the `sweep` message is dead-lettered as `sweep_not_enabled` (the code D3 reserved) and the CLI exits 2, so nothing on Render/Supabase changes; the switch-on is H1's EventBridge schedule, and nothing sends a `sweep` before it. (2) No new SQL: the job is exactly one call of D2's `app.expire_stale_runs(dry_run)` through `pg.with_anonymous()` (cross-org by design; the definer is the only door). (3) A database error before the sweep leaves the message for redelivery (`transient`), like a job that could not start; a duplicate delivery is harmless (the second sweep finds nothing). (4) The CLI prints run and org ids (uuids) and a count per `from->to`; the worker's log line carries the counts only. | 0.5-1 |
| D6 | Worker image: Dockerfile stage or second CMD; `.dockerignore` test; CI build and scan | `Dockerfile.api` (or `workers/Dockerfile`), CI | a local `docker build`; `test_dockerignore.py` | D3 | LOCAL-NOW. **Built 2026-09-24, NOT BUILT AS AN IMAGE:** the Docker daemon on the Mac is off, so there was no local `docker build`; validated by inspection and by `tests/test_dockerignore.py`. **Deviations:** (1) §7.1's default taken: no second stage and no `workers/Dockerfile` — the worker is `Dockerfile.api` unchanged with `command: ["python", "-m", "workers"]` set by the worker task definition (H1). (2) Instead of a second `CMD`, the build smoke-tests the worker: `test -f /app/workers/__main__.py && python -m workers --help && python -c "import workers.run_job, src.processes"` (the last proves `migrations/` is in the image, (originally because the registry read the Alembic chain; B1-B3 moved that check into CI, the smoke test still stands) at import; none of it needs a database, queue or environment — checked on the Mac with an empty environment). (3) CI build and scan need no new step: `deploy.yml` already builds `Dockerfile.api` and Trivy-scans it (HIGH/CRITICAL fail), and that one image is the worker too. (4) `test_dockerignore.py` gains: the worker's runtime paths (`workers/`, `src/processes/`, `src/process_state.py`, `migrations/`) are not dropped by `.dockerignore` (a deliberately over-broad matcher with known-bad controls), and the Dockerfile stays single-stage with the smoke test and the api `CMD` unchanged. | 0.5 |

### E — Idempotency

| Id | Task | Files | Proof | Dep | Tag | d |
|---|---|---|---|---|---|---|
| E1 | Alembic `0012_job_idempotency` (§3.7) + `qbo_request_id` on `qb_export_tie_out`; `src/idempotency.py` with begin, settle and complete | migration, module | pg_fixture: RLS cross-org invisible; same key + different fingerprint → conflict; no DELETE grant | D2 | LOCAL-NOW. **Done 2026-09-24** (`tests/test_job_idempotency_pg.py`). **Deviations:** (1) the policy is the standard `meridian_org_isolation` (not `tenant`) and the table is in `scripts/tenant_tables.txt` (MIGRATION_ADDED); TRUNCATE is withheld as well as DELETE; (2) the run reference is a composite FK `(run_id, org_id)` → `process_runs (run_id, org_id)` with `ON DELETE SET NULL (run_id)`, so a record cannot point at another org's run; (3) `attempts` starts at 1 (counts begins that did remote work or reconciliation) and CHECKs bound the key (≤200), fingerprint (64 hex) and `remote_result` (a JSON object); (4) `begin` returns one of `new`/`completed`/`pending`/`retry` in one transaction (insert, else `SELECT … FOR UPDATE`): `failed` rows are re-armed to `pending` as a `retry`, a completed replay writes nothing; `settle(outcome)` closes a pending row as `completed`/`failed` and is idempotent for the same outcome; `complete` is `settle('completed')`; `remote_result` accepts ≤8 lower_snake_case keys with short string/int ids only; `fingerprint()` is sha256 of canonical JSON (Decimal as text, floats not coerced); (5) `qbo_request_id` on `qb_export_tie_out` is added but nothing writes it until E2, so tracker row 49 is narrowed, not closed. `0013_api_platform` re-pointed onto 0012. | 1 |
| E2 | QBO push becomes job `qbo_push` using the §3.7 algorithm; `POST …/quickbooks` returns 202; React polls; `scripts/qbo_post_je.py` routed through the helper or retired | `src/qb_usa_payroll_quickbooks.py`, `qb_usa_runs.py`, `web/src/…` | fake QBO client counting creates: **redelivery after a create but before completion → exactly 1 create**; pending + QBO has it → completed with no create; pending + QBO lacks it → the same requestid is sent | E1, D3, B3 | LOCAL-NOW†. **Prerequisites built 2026-09-24** (with E3): the claim path (D3's open item, above) and the ledger side of the requestid question — ADR 0032: an ambiguous failure (`idempotency.failure_kind`: no response, 5xx, 408) leaves the row `pending` and the resend reuses the requestid; a definite one (other 4xx) is settled `failed` and the next `begin` rotates to `attempt_request_id(first, n)`, keeping the old id in `job_idempotency.qbo_request_id_history` (0018; ≤ 20, then "needs a person"). The caller always sends `claim.record["qbo_request_id"]`. **Built 2026-09-24** (`tests/test_qbo_push_job_pg.py`, C5's RDS world — the real `PostgresRunStore`, parse and execute jobs, the push on a run the real execute booked, its real `qb_usa_payroll_journal` rows — with a fake QuickBooks that keeps its entries in a list (so a double post shows as two), replays a requestid it has answered, and can be scripted to lose an answer after booking, time out, answer 5xx/4xx, or have the worker SIGTERMed right after booking: the route answers 202 and the run settles `completed` with every journal posted once; pushing again after success sends nothing (the ledger answers); a second press while queued queues nothing; another org's run 404s and a message naming the wrong org is dead-lettered `run_not_found`; a duplicate delivery posts once; a lost answer after booking is found by DocNumber on the retry, not resent; with the lookup blind the retry resends the SAME requestid and Intuit's replay leaves one entry; 5xx and a bookless timeout resend the same requestid; a 4xx rotates to `attempt_request_id(first, 2)` with the first kept in the history; **redelivery after the create but before the ledger's `complete` → exactly one create**; killed mid-push → resumed on another worker with no duplicate; a superseded push job does nothing; QuickBooks not connected → `failed` with the code; unrouted → the request path, 200 `QuickbooksPushOut`, no ledger row; a known-bad control — the ambiguous failure classified definite, the lookup blind — books the journal twice. `tests/test_qbo_post_je_ledger_pg.py`: the CLI on RDS. Web: `results-screen.test.tsx` (202 then poll, 200, reasons, EN+ES, vitest-axe).) **Deviations:** (1) **Gated on `runs_common.jobs_routed("qb-usa-payroll")`** (RDS, runs in `PostgresRunStore`, qb-usa on `WORKER_PROCESSES`); elsewhere — Supabase/Render, and RDS with the allowlist empty — `push_to_quickbooks` is unchanged (synchronous, 200 `QuickbooksPushOut`, no ledger). The route therefore documents two success answers (`generate_openapi.Route.also`: 202 `RunEnvelope`); tracker row "Two QuickBooks push paths". (2) **The push status is `run_state.quickbooks_push`** (declared `public`: status, job id, times, per journal the number, QuickBooks id, requestid sent and a failure CODE — never QuickBooks' text), on a new `QBUSAPayrollRun.quickbooks_push` (`QuickbooksPushStatus`). The api writes `queued` with the job id before the send, after the D4 compare-and-set (`runs_common.start_job` gains `to_step` — a finished run keeps its step — and `message`, so the id is known before the send); the job writes `succeeded`/`failed` in its settle. The envelope reads a queued push against the lease: a live lease for this job is `running`; no live lease and a mark older than the 900 s visibility, or 3 claims, is `interrupted` (safe to push again). While a push is in flight a second press answers the run and queues nothing. (3) **A push that could not post everything settles `completed` with status `failed`**, not D3's release path: the run was booked and pressing again asks for a new job, which the ledger makes safe. Only a database error (or a vanished run) raises, which releases the lease and leaves the message for redelivery (`released` now counts as "left for redelivery" in `start_job`). Whole-push refusals are codes (`PushRefused`: `QBO_NOT_CONNECTED`, `QBO_RECONNECT_REQUIRED`, `QBO_TRACKING_OFF`, `QBO_UNAVAILABLE`, `NO_JOURNALS`); per journal `src/qbo_posting.FAILURE_CODES`. (4) **One helper, `src/qbo_posting.post_journal_once`**, §3.7 per journal; the DocNumber lookup runs for `new`/`retry` too (the pre-check the push always had, which also catches a hand-keyed entry), and is the reconcile for `pending`. A payload that cannot be built settles a new/re-armed row `failed` (nothing sent) but leaves a `pending` one pending. An exception with no HTTP status is ambiguous; `QboHttpError(status)` is raised by `QboClient.create_journal_entry` only (same message as before; token code untouched). (5) A push job whose `quickbooks_push.job_id` names a newer press does nothing (the newer one reports). (6) **`scripts/qbo_post_je.py` is routed, not retired** (§7.1's default): on RDS it posts through the same helper and writes `qb_export_tie_out.qbo_request_id` (tracker row 49 closed — qb-usa has no tie-out rows, its requestids are in the ledger and on the run); on Supabase it is unchanged. (7) **React:** `sendToQuickBooks` answers `queued` (the envelope) or `done` (the results); the run shell polls a completed run while its push is queued or running (`pushInFlight`, the same 2 s poll); the results dialog opens when the job this press asked for settles, lists the journals that did not post with a reason per code, EN+ES; the dead mock (`MOCK_PUSH`, `NotBuiltError`, its strings) is gone. (8) **Side effect:** after a push the run's `last_job_id` names the push job, so a LATE duplicate of the run's execute message is dead-lettered `state_not_allowed` instead of acknowledged as a duplicate (it books nothing either way). (9) An in-process push killed with its api process is not redelivered by `Dispatcher.recover()` (0022 excludes finished runs); it reads `interrupted` after 15 min and pressing again is safe. No migration. **Follow-up 2026-09-24 (cleanup wave, revision 0024 `job_redelivery_history`) closes (8), (9) and the unclaimed-SQS-push case:** (8) the worker's settle appends its job id to `process_runs.settled_job_ids` (newest first, at most 20, CHECK-bounded; never an api write), and a delivery whose job id is there is acknowledged as a duplicate, so a late execute after a push no longer dead-letters (`state_not_allowed` is still the answer for a job the run never settled). (9) `app.redeliverable_jobs` now also answers a `completed` run whose post-completion job lapsed after 1-2 claims or sat queued past the grace (new partial index `idx_process_runs_finished_lease`), and `inprocess.resume_kind` maps a finished run to the manifest's post-completion kind, so `Dispatcher.recover()` resumes the SAME push. Unclaimed SQS push: the envelope reads `queued` until `PUSH_LOST_SECONDS` (visibility 900 s + 300 s margin) after the mark, then `interrupted`; pressing again then replaces the lost never-claimed marker through `begin_action(lost_after=...)` (one compare-and-set, database clock; two presses, one winner); the lost message, should it still arrive, finds a newer push on the run and posts nothing. Tests: `tests/test_job_redelivery_history_pg.py`, `tests/test_qbo_push_job_pg.py`. | 2 |
| E3 | `Idempotency-Key` on `POST …/execute` (`execute_run` already accepts `idempotency_key`, `qb_usa_runs.py:1341`; extend it to the one-shots) + `DUPLICATE_INPUT` from input `sha256` | `src/api/v2/*` | a repeat with the same key returns the original run; the same file → a warning with `previous_run_id` | E1, C1 | LOCAL-NOW†. **Built 2026-09-24** (`tests/test_execute_idempotency_pg.py`, `tests/test_execute_idempotency_qb_usa_pg.py`: the ledger rows, and the v2 routes with the runs in `PostgresRunStore`). **Deviations:** (1) **Gated on RDS** (`execute_idempotency.enabled()`: `DATABASE_BACKEND=postgres` AND the runs in `PostgresRunStore`); off RDS qb-usa keeps its `run_state.execute_idempotency_key` check and the one-shots ignore the header, as before. (2) One wrapper, `src/api/v2/execute_idempotency.run_once`, over qb-usa `execute` and the one-shots' `execute` and `retry` (v3 has no execute route); the ledger key is `"<process>:<header>"` (scope `run.execute`), the fingerprint `{process, run_id, action, body}` with qb-usa's `confirm_declared_gates` as a set. (3) Answers: repeat → the same run's envelope (202, current state); different request → `409 IDEMPOTENCY_CONFLICT` `payload_mismatch` (the contract's 409, not §3.7's 422); a request still in flight → `409` `in_progress`, `retryable` — never a second start; a refusal is settled `failed` and not cached; an exception AFTER the effect settles `completed` so the retry replays. "Did it take effect?" is read from the run (the action no longer available), not from the exception. A process killed between `begin` and the first write leaves the key `pending` for good (the client uses a new key). (4) The header is validated (1-128 visible ASCII, else 422) on RDS only. (5) `DUPLICATE_INPUT` compares the recorded sha256 multiset through a new IMMUTABLE `app.input_digest(inputs)` with an expression index (revision 0018) — no column to keep in step; "before" = the newest earlier run of the org and process in `running`/`blocked`/`completed`/`superseded`. It is added at create for the one-shots (create is execute, §12.1, in the seed write) and at `execute` for qb-usa (so it is not yet visible on qb-usa's review/preview screens — a C5/F3 follow-up), stored in `run_state.warnings` (declared `public` in `RUN_STATUS_FIELDS`), with the id in `details.previous_run_id` (the `Warning` schema has no top-level field). A failed lookup adds nothing. (6) Not closed: two concurrent executes with DIFFERENT keys (or none) still both pass the state check before either writes; the key closes only the same-key race. **Closed 2026-09-24 (D4 wave):** the start is a compare-and-set (`process_runs.begin_action`, `409 RUN_STATE_CHANGED`); and a key left `pending` by a dead request now times out after 15 minutes by the database clock (`idempotency.begin(stale_after_seconds=…)`). | 1 |

### F — Conformance, scaffold, React shell (plan: 4-6 d, plus the React part the plan does not count)

| Id | Task | Files | Proof | Dep | Tag | d |
|---|---|---|---|---|---|---|
| F1 | `tests/conformance/`, parametrized over `REGISTRY`: file validation, the permission matrix per step (§12.11) plus cross-org 404, audit (`artifact_downloads` per mint; `audit.phi_access` when `touches_phi`), idempotency (redelivery), error envelope, **no PHI in logs** (seeded canary identifiers, caplog scan), state classification | `tests/conformance/*.py` | a deliberately broken demo manifest fails each check (a known-bad control per check) | D3, E1, C2 | LOCAL-NOW. **Built 2026-09-24** (`tests/conformance/`: `checks.py` holds ten checks as plain functions `check(subject, world) -> problems`; `test_conformance.py` runs every one over every `REGISTRY` process, 30 cases, all green; `test_known_bad.py` builds a fake process in a temp folder that passes all ten (the control-positive), then breaks it one way at a time, 45 known-bad controls, at least one per check, enforced). The checks: `db_checks` (id and permission in the Alembic CHECKs and in the loader's stated values), `state_machine`, `openapi` (every process enum, the `RunEnvelope` discriminator, the envelope pins its id), `http_routes` (`POST /api/v2/{id}/runs`), `handlers`, `state_fields`, `inputs`, `file_validation`, `permissions` (auth vocabulary and label, step levels, `api_scopes.PROCESS_BOUND_SCOPES`), `purity` (the B0 lint on `processor.py` and `handler.py`). **Deviations:** (1) **The HTTP-level items of the plan's list are not re-implemented per manifest**: the permission matrix per step, cross-org 404, the mint audit and the error envelope run against the real routes in `tests/security/test_object_level_authz.py` (already parametrized over `PROCESS_CATALOGUE`) and `tests/test_api_v2_*`, and redelivery in `tests/test_worker_loop_pg.py`. The routes are still hand-written per process, so there is no generic surface a manifest could drive yet; they join the suite when D4 generates them. (2) **"No PHI in logs" is proved at the validator:** `file_validation` feeds each input's `validate` junk bytes and a well-formed table of canary identifiers per extension, under a root log capture at DEBUG, and requires a `ProcessInputError` with a code registered in `errors.STATUS_FOR_CODE` and the canary in no message, no detail, no log line. Handlers are not invoked (the real ones are not wired, and invoking a processor from a test harness would need its inputs and database). (3) **Handlers:** none of the six shipped jobs was wired when F1 was built (D3's `no_handler`; C4/C6 have since wired qb-revenue `execute`/`retry` and mx-payroll `execute`, and C5 qb-usa `parse`/`execute`, whose rows went at the merges; only qb-usa `qbo_push` (E2) is left), so the suite keeps `HANDLER_PENDING` — one row per job, with the task that wires it (D4 with C4/C6, C5, E2). A wired handler must live in the process's own package (so the purity check sees it) and take one argument; **a row whose job is wired, or names a job the manifest lacks, fails**, so the list can only shrink. It is the one list the suite keeps; every other comparison reads its source. (4) **CHECKs:** compared with the Alembic chain (the schema production moves to), not the Supabase 022/030 files; A3 still holds those equal to the registry, which means adding a process before cutover also needs the Supabase side widened (see `docs/adding-a-process.md`). (5) **`state_fields`** also scans `handler.py`/`processor.py`: the keys of a `JobOutcome(run_state={...})` literal must be declared `public`/`personnel`, and a `write_state`/`read_state` name `personnel`/`phi` (D3/C3's rules); a non-literal `run_state` or state name is itself a finding, because it cannot be checked. (6) Rules added beyond the plan's list: steps start at `upload` and end at `results`; a step is `custom=True` exactly when it is not one the standard shell renders (`upload`, `processing`, `results`); only `results` is at the `results` level; an `execute` job exists; `execute`/`retry` can move each start state to `running`; `timeout_s` is under the 900 s visibility; id, permission and colour are well formed; an input's content types are a canonical-first subset of `BROWSER_CONTENT_TYPES` and `max_bytes` is at most the platform's 50 MiB. (7) `tests/conformance` joins the mypy-enforced list. | 2-3 |
| F2 | `scripts/new_process.py <id>` (`--help`, `--dry-run`): writes the folder, manifest, processor stub, tests and the Alembic CHECK-widening revision; `docs/adding-a-process.md`. CI generates `demo` in a temp dir, runs conformance and discards it | as named | the CI job is green with **zero edits under `infra/`** | F1 | LOCAL-NOW. **Built 2026-09-24** (`scripts/new_process.py`, `docs/adding-a-process.md`, `tests/test_new_process.py`). The CI job is a normal test in the one pytest run: it copies the parts of the repository a process touches into a temp folder, scaffolds `demo` there, regenerates the v2 OpenAPI, asserts the changed files are exactly the expected set and none is under `infra/`, runs `ruff check`, `ruff format --check` and `mypy` on them, then runs the conformance suite, the scaffold's own tests, A3's Alembic check and the migration chain tests (`test_chain_upgrades_from_empty`, the head → 0005 → head round trip, on the ephemeral Postgres) in a fresh interpreter in the copy. The real tree is never written. **Deviations:** (1) **One conformance check stays red on a scaffold, by design: `http_routes`.** The `/api/v2/{id}/runs` routes are hand-written per process (`api/routers/oneshot_runs.py`, `qb_usa_runs.py`) and listed by hand in `generate_openapi.py`'s `ROUTES`, so a scaffold has none; writing a router is D4's generic surface, not a scaffold's. The test asserts the failure set is EXACTLY `{demo-http_routes}`, so it fails the day D4 lands until the expectation is removed. (2) Besides the plan's files the scaffold writes `handler.py` (the `execute` handler, held to the purity lint by F1) and edits, in place: `src/processes/__init__.py` (the stated CHECK values and the manifest list), `src/api/v2/schemas.py` (`ProcessKey`, `<Name>CreateParams`, `<Name>Run`, the `RunEnvelope` union — a registered process must be a `ProcessKey` or `/api/v2/processes` fails validation), `tests/test_migrations.py` (`HEAD_REVISION`) and the Processes table in `docs/adding-a-process.md` (the "docs entry"). It refuses and writes nothing when the id is malformed or taken, the folder exists, or an edited file has changed shape. (3) The stub `execute` handler completes the run with a count of the inputs and records one `personnel` state object (a working example of the `JobContext` → `JobOutcome` contract, not a calculation); the validator checks a header row and refuses with `FILE_UNREADABLE`/`FILE_HEADERS_INVALID`. (4) The revision widens `role_permissions_process_check` only when the permission is new; its downgrade narrows both back and refuses while rows use the new values. The revision id is capped at 32 characters (`alembic_version.version_num`). (5) **Adding a real process still has manual steps, listed in `docs/adding-a-process.md` §4:** routes (D4), the React run/results screens where they branch on the three ids, the two tests pinned to today's three processes (`test_process_manifest.py`'s catalogue literal, the A2 snapshot), and, before cutover, the Supabase 022/030 CHECKs that A3 still holds equal to the registry. | 1.5 |
| F3 | React: create form from `create.params_schema`; custom-step registry (`roster_review`, `preview`, `mapping_fix`); remove process-id branches | `web/src/components/{create-run-form,results-screen}.tsx`, `shell/sidebar.tsx`, `web/src/lib/run-view.ts` | vitest; `web/src/__a11y__/`; the generated TS client type-checks | A2 | LOCAL-NOW. **Built 2026-09-24, on its own branch** (commit `063773d`, `worktree-agent-a8f0aebc79a99bb16`, merged separately from F1/F2; the two touch disjoint files). `/api/v2/processes`: each descriptor's `create` gains `params_schema`, the JSON Schema of the manifest's `params_model` (`model_json_schema(mode="validation")`, the model docstring dropped), built once in `PROCESS_CATALOGUE` (`routes.params_schema`); `sc.CreateSpec.params_schema` is required. **This deliberately changes the `/api/v2/processes` bytes and the v2 OpenAPI:** the A2 snapshot `tests/snapshots/api_v2_processes.json` is re-captured with the test's own helper (parsed, with `params_schema` dropped, every other byte is the A2 capture's), `openapi/meridian-v2.json` and `web/src/lib/api/schema.d.ts` regenerated, `tests/test_process_manifest.py`'s catalogue literal extended, contract §3.1b documented. React: `web/src/components/create-params/` — `SchemaParamsForm` renders integer, number, boolean, string, date and string-enum fields (nullable, required, min/max/exclusive bounds enforced as the server does; an object/array field is named on screen as needing a custom step), labels from `screens.create.param.<name>` (EN+ES) or the schema title; `registry.tsx` `CUSTOM_CREATE_STEPS` maps a process id to its create step (`Params`, `defaults`, `incomplete`, copy keys), and a process with none gets `genericCreateStep(schema)` from the catalogue (fetched only then). Tests: `schema-form.test.tsx` (20, including the generic path through `CreateRunForm` against the real snapshot schemas), `web/src/__a11y__/create-params.axe.test.tsx` (EN+ES at 375 and 1280 px, zero violations); the existing `create-run-form.*` tests unchanged and green. **Deviations:** (1) **No hand-built form is replaced**: the generic form cannot reproduce any of the three exactly (qb-usa's typed period picker that spells the period back and the accrual days prefilled from `accrual-preview` with `accrual_days_prefill`; qb-revenue's auto/manual period, a UI state with no param of its own, and `bank_deposits`, a `Dict[str, float]` edited as a table; mx-payroll's "nothing to choose" sentence, pesos hint and `18.25` placeholder), so all three moved verbatim into registered custom steps. (2) The per-process branches removed from `create-run-form.tsx`: `FILE_NOUN`, `FILE_SECTION_COPY`, `defaultParams`, the `ParamsForm` dispatch, the three-way `needsPeriod`, the "The files" check and the revenue manual-period state (now a form-local `ui` record that is never sent). (3) **No run-step registry was added**: `roster_review`, `preview` and `mapping_fix` are already chosen by step id (not process id) in `run-view.ts`'s `screenFor()` table; a second table would be a second registry. (4) Not done (outside the brief): `results-screen.tsx`, `shell/sidebar.tsx` and `run-view.ts` still branch on process ids; a new process still needs its key in `web/src/lib/api/runs.ts` (`ProcessKey`/`PROCESS_KEYS`) and `PROCESS_META`/`PERIOD_BASIS` (typecheck forces them). (5) Two behaviours exist on the generic path only: a loading line while the catalogue loads, and a "could not be loaded" line with Start disabled if it fails. | 1.5-2.5 |

### G — Retire Flask (not in the plan's composition)

| Id | Task | Files | Proof | Dep | Tag | d |
|---|---|---|---|---|---|---|
| G1 | Delete the five dead payroll families: 49 routes, 10 dicts, 6 thread sites, 5 template dirs. The `src/adp_*`/`booking_*` processors stay unless told otherwise | `web_app.py`, `templates/…` | extend `test_retired_jinja_paths.py`; `test_adp_*`/`test_booking_payroll.py` still green | — | **Done 2026-09-24.** Andres approved 2026-09-22. **Deviation: the deletion itself had already landed** in `8ac4928` (2026-09-22, `refactor(cx-api-03)`): 49 routes (`/adp_payroll` 10, `/booking_payroll` 13, `_v3` 9, `_v4` 8, `_v5` 9), the 10 dicts, the 5 background workers, 5 template dirs and 3 orphan `src/` modules nobody imported (`adp_payroll_processor`, `adp_je_generator`, `mso_allocation_aggregator`). This task re-proved them dead (no reference in `web/src`, `next.config.mjs`, `api/`, `src/`, `workers/`, `templates/`, `docs/runbooks/`) and added the guard: `tests/test_retired_jinja_paths.py` now asserts no reference to any family path anywhere, no Flask rule at or under one, no `url_for` to a deleted view, the 5 template dirs gone, no `web_app` attribute for any of the 10 dicts or 5 workers, and — D7 — the 7 remaining `src/adp_*`/`booking_*` processors and the `adp_payroll`/`booking_payroll` scopes still present. | 1 |
| G2 | Remaining reachable Flask routes (§2.6). For each: zero consumers (the grep in §2.6 — *not* ALB logs, superseded 2026-09-22, see deviation (1)) → delete; otherwise port to a FastAPI router. `/api/v1/*` depends on §7.2 D-25 | `web_app.py`, `api/routers/*` | `test_fastapi_app.py` one-commit rule; `test_retired_*` | — | **Done 2026-09-24** (grep and port; the route table is §2.6.1). **23 deleted, 3 ported, 82 left, each with its reason.** Deleted: `/api/v1`'s 10 non-health routes (Andres's yes of 2026-09-22 supersedes §7.2 item 4's 30 days of ALB logs; the evidence is the grep), `POST /api/fiscal-calendar/import`, `POST /api/process`, the bare `/api/config/export` + `/api/config/import`, and the nine `/api/mso/*` routes with the ADP Payroll tab of `templates/config.html` that was their only caller (plus `load/save_mso_mappings`, the never-called `validate_allocations_against_employees`, the flat `api_error()`, and `Database*.create_adp_payroll_batch`, whose only caller was its own test). Ported: `/auth/google`, `/auth/microsoft`, `/auth/callback` → `api/routers/oauth.py` in the commit that deleted the Flask views (same cookies, `state` check, PKCE verifier, `next` guard, 302s; `tests/test_oauth_state.py` now runs on FastAPI with no mount). Guard: `tests/test_retired_flask_api.py` (no Flask rule, no caller in `web/`, `api/`, `src/`, `workers/`, `scripts/`, `infra/`, `lambda/`, `docs/runbooks/`, `render.yaml` or `templates/`, no view left on `web_app`; Flask serves nothing under `/auth`). **Deviations:** (1) the evidence is grep only, as decided; no log evidence was gathered for the other 13 deletions because none of them has a caller the edge could carry. (2) `/qbo/connect` + `/qbo/callback` are LEFT and NEED ANDRES: not at the edge, laptop-registered redirect URI, no React caller, and a port needs a decision on where QuickBooks is connected in production (tracker row). (3) `/static/*` is live (email and invoice logos) and LEFT for G4/G5: porting changes the cache headers and Flask's `static` endpoint still builds `url_for('static')` for every surviving template. (4) The Jinja-only `/api/config/meta` + `/api/config/add/*` and `/api/processing/*` stay with the wizards (I2/I3), and the per-table config export/import with `config.html` (G5), so no surviving page is half-broken. | 2-4 |
| G3 | MFA `_pending` → a short-TTL Postgres row (tracker 84) — **DONE 2026-09-24** on the auth-hardening branch (tracker T:83): `public.auth_pending_challenge`, Alembic `0017_auth_state`; `tests/test_auth_state_pg.py` stashes on one instance and redeems on another | `src/api/v2/auth_routes.py`, Alembic | two app instances in one test: stash on A, redeem on B | D2 | LOCAL-NOW† | 1 |
| G4 | Remove Flask from `src/auth.py` (decorators, `g`), `run_store._request_org_id`, `api/v2/limits.py`, `errors.py`; decide multipart (§7.2); remove the WSGI mount (`a2wsgi`, added 2026-09-22) | as named, `api/main.py`, `requirements*.txt` | the full suite; `grep -ril flask src api workers` empty | I4 | LOCAL-NOW† | 2-3 |
| G5 | Final commit: move `templates/{invoice,agreement}` and `wearbly/receipt.html` to `src/pdf_templates/` (update `invoice_generator.py:937`, `wearbly_pdf.py:9`); delete `web_app.py` and the rest of `templates/`; update CLAUDE.md, `README.md`, `repo-layout.md` Rule 2 | as named | `test_invoice*` byte-identical HTML (the same method as Phase 5b §Evidence); `grep -r flask` empty (§6 defines the scope) | G4 | LOCAL-NOW† | 1 |
| G6 | Tracker rows parked on Phase 11 that are **independent now**: CX-BE-01 membership assertion in `with_org`, CX-BE-04 `exc_info` lint, CX-BE-05 email escaping (**its own row says "before the SES flip"**, which is before Phase 11, so do it now), CX-BE-07 lint `TABLES`, invoice re-render race | `src/pg.py`, `scripts/lint_*`, `src/email_service.py`, `src/invoice_generator.py` | each row's own test | — | **Done 2026-09-24**, all five rows closed in the tracker. **Deviations:** (1) CX-BE-01 admits a superadmin as well as a member (the console reaches an org through `with_superadmin`'s audited check, then an ordinary `with_org`), maps `NotAMember` to a 404 in `api/errors.py`, and needed test fixtures that stub `org_context` to seed the membership they claim (`tests/pg_members.py`); one test's cross-org read was the behaviour the row closes and now asserts refusal. (2) CX-BE-04: the 207 existing traceback sites are grandfathered per file by a lower-only ratchet (`scripts/phi_exc_info_baseline.json`) rather than marked one by one — they are safe behind `RedactingFilter`, and marking them would have touched files parallel agents own; new sites must be marked or converted. (3) CX-BE-07: pg_store held 10 of the 56, not 56; ratchet 97/56 → 96/46. (4) Invoice race: fixed with a claim before rendering (the row's first option), plus a 600 s takeover so a killed render cannot strand the invoice; `api/routers/invoices.py` changed with it. | 2.5-3.5 |

### H — Infrastructure (plan: part of worker, 5-7 d)

| Id | Task | Files | Proof | Dep | Tag | d |
|---|---|---|---|---|---|---|
| H1 | CDK: queue + DLQ + scheduler, worker service and role, api `SendMessage`; `worker_enabled` flag default off | `infra/meridian/stacks/{api,compute}.py` | `infra/tests/` assertions (§3.8); `cdk synth` for both envs; unchanged `cdk diff` with the flag off | D6 | LOCAL-NOW. **Built 2026-09-24, not deployed** (`infra/meridian/stacks/worker.py`, `infra/tests/test_worker.py`). With `-c worker_enabled=true`: `meridian-<env>-sqs-jobs` + `-sqs-jobs-dlq` (the `phi` CMK, TLS-only, visibility 900 s, wait 20 s, redrive after 3, DLQ 14 d, both tagged `phi`); schedule group `meridian-<env>-schedule-worker` with `meridian-<env>-schedule-sweep-runs` (`rate(15 minutes)`, D1's `SweepMessage` as the body, 2 retries in 10 min) and role `meridian-<env>-iam-sweep-scheduler` (`sqs:SendMessage` on the job queue + the key through SQS; trust pinned to this account and schedule group); log group `/meridian/<env>/ecs/worker` (`logs` CMK, 400 d); task family `meridian-<env>-ecs-worker` (ARM64 0.5 vCPU / 1 GB, the api repository AND tag, `command: ["python","-m","workers"]`, `stopTimeout` 120, no port, `PGPASSWORD` only); service `meridian-<env>-ecs-svc-worker` (desired 1, no load balancer, 100/200 with the rolling-back circuit breaker, private-app + `app` SG, no ECS Exec); task role `meridian-<env>-iam-ecs-worker-task` (receive/delete/change-visibility on jobs; send on the DLQ; `GetObject`/`GetObjectVersion`/`GetObjectTagging`/`GetObjectVersionTagging` on `phi` `*/*/uploads/*`; put/get/get-version on `*/*/state/*` and the output subfolders `journal_entries` (artifacts) and `data`/`reports`/`bundle` (phi); the two bucket keys through S3 and the `phi` key through SQS; SES as the one mailbox — no delete, no list, no secret, no `*`); the api task role gains `sqs:SendMessage` on the job queue only (+ the key through SQS) and `MERIDIAN_JOBS_QUEUE_URL`/`MERIDIAN_JOBS_DLQ_URL`. **Off is byte-identical:** every template of both environments synthesized from `cad08ee` (pre-H1) and from this branch with the flag absent is byte-for-byte the same (combined sha256 of the 11 templates: staging `500e24d67452a8a7…`, production `e16814ddebf2d791…`, staging with `enableApiPlatform=true` `57822d8625c6e923…` — identical before and after; only the jsii temp-dir names in `*.metadata.json` stack traces differ; the separate, deliberate commit that sets `APP_ENV` on the web task — an orchestrator item, not behind the flag — is the only flag-off change on the branch, one variable in each `compute` template, re-checked after the T19 infra commit); durably, `test_worker.py` asserts `worker_enabled=false` ≡ absent, that no off template names anything the worker adds, and that turning it ON only adds (every off resource and output unchanged, or changed by addition in exactly the api task definition/role, the execution role's log grant and the dashboard's alarm carpet). **Deviations:** (1) **Everything is in `compute`, not `api`** (§3.8's row): `deploy.yml` deploys `compute` alone (`--exclusively`, `-c apiImageTag=<sha>`), so a worker elsewhere would lag the api image, and a queue in `api` (which imports `compute`) would not exist when the worker's first task starts — it would crash-loop, trip the circuit breaker and roll the `compute` update back. The alarms are `observability`'s as planned (H2). (2) The queue key is **`phi`**, not `logs` as for the webhook queues: a message's input keys end in the uploaded file's name, and the DLQ keeps it 14 days. (3) The worker **reuses the api's execution role** (it already pulls this repository and resolves `db-app`) and connects as **`meridian_app`** — D2's question answered with the default, recorded in `worker.py` and the tracker. (4) Beyond §3.8's role: `GetObjectVersionTagging` (the scan verdict is read per version, which S3 authorizes under that action) and SES send (the processors' completion notice), both scoped as above; no `GetQueueAttributes` (the transport never calls it) and no `ListBucket`. (5) The sweep's `job_id` is a fixed uuid4 (Scheduler's execution id is not one; a sweep has no lease). (6) The flag is spelled `worker_enabled` as the plan has it, not camelCase like `enableApiPlatform`. **Cost if enabled** (Andres's approval list; not enabled): ≈ $15.4/month pre-tax per environment (≈ $16.4 taxed), almost all the always-on Fargate task; production's approved "with worker + SQS" steady state already assumes it (tracker row). **Tests:** `infra/tests/test_worker.py`, 53 (both environments where it matters). | 2 |
| H2 | Alarms and dashboard (§3.8) | `observability.py` | `infra/tests/test_observability*` | H1 | LOCAL-NOW. **Built 2026-09-24, not deployed** (`observability._worker_alarms`, `infra/tests/test_worker.py`; runbook `docs/runbooks/alerts.md` §10 with the Job DLQ triage and every reason code). Five alarms to `meridian-<env>-sns-alerts`, each with OK actions: `jobs-dlq` (DLQ visible ≥ 1, 5 min), `jobs-age` (oldest message > 900 s), `worker-task-count` (Container Insights `RunningTaskCount` < 1, 3 of 4 × 5 min, BREACHING), `sweep-stalled` (no `sweep done` for an hour — a `$.message` equality filter on the worker log group into `Meridian/App` `WorkerSweepsCompleted` by `Environment`; BREACHING in production, MISSING in staging whose database sleeps overnight), `sweep-dropped` (`AWS/Scheduler` `InvocationDroppedCount` for the worker's schedule group). **Deviations:** (1) no separate `job_refused` filter — every refusal is dead-lettered, so `jobs-dlq` is the same signal once; (2) no dashboard row — the alarms join the alarm carpet; (3) the sweeper alarm is two (stalled: any cause; dropped: the send itself), since "sweeper failures" has two places to fail. Test counts in the H1 cell. | 1 |
| H3 | Staging: deploy with the flag on; run all three processes on SQS; **killed worker** (`ecs stop-task` mid-run) → resume; **PS-14 rollback rehearsal** (§5.2) | runbook `docs/runbooks/phase-11-worker.md` | a runbook log with the evidence | H1-H2, D4 | NEEDS-AWS | 1.5 |
| H4 | Production: worker deployed, `WORKER_PROCESSES` empty (everything still `inprocess`); smoke test | — | alarms green for 24 h | H3 | NEEDS-AWS | 0.5 |
| H5 | The `desiredCount` lift (§3.9): rolling deploys, alarm change, docstring fix; right-size or set count 2 per §7.2 | `compute.py`, `observability.py` | a deploy with zero 5xx; the `desiredCount=2` e2e test (§6) | I4 | NEEDS-AWS + NEEDS-ANDRES (cost) | 1 |

### I — Per-process migration (plan: 5-8 d)

| Id | Task | Dep | Tag | d |
|---|---|---|---|---|
| I1 | Capture baselines: tag the last pre-Phase-11 image; on a staging RDS restored from a production snapshot, run each process for both rehearsal periods → OLD outputs (kept on the encrypted volume, never in the repo) | Andres names the periods | NEEDS-AWS + NEEDS-ANDRES | 1 |
| I2 | qb-revenue onto SQS, gate, then delete its Flask routes, templates and thread sites (`web_app.py:3036`, `:3135`, `:3362`) | I1, H4, C4 | NEEDS-AWS | 1.5-2 |
| I3 | mx-payroll, the same (`:4200`) | I2 | NEEDS-AWS | 1-1.5 |
| I4 | qb-usa-payroll, the same, including `qbo_push` against the QBO **sandbox** (`scripts/qbo_seed_sandbox.py`) (`:4917`) | I3, C5, E2 | NEEDS-AWS | 2-3 |
| I5 | G4 → G5 → H5; close the tracker rows; phase report | I4 | mixed | 0.5-1 |

---

## 5. Per-process migration, gate, rollback, deletions

### 5.1 Order and gate

The order is qb-revenue → mx-payroll → qb-usa-payroll. Simplest first: revenue has no human step and exercises
`blocked → retry`. qb-usa goes last because it has human steps and QBO.

For each process:
1. `WORKER_PROCESSES += <id>` on staging (restored snapshot). Run both rehearsal periods through the worker
   → NEW outputs.
2. **Gate:** run `scripts/run_port_gate.py` (refuses any backend but `postgres`), then
   `scripts/diff_je_output.py OLD NEW` exactly as `docs/je-diff-procedure.md` describes. Exit 0 for both
   periods; no tolerance, no `--ignore`.
   - OLD and NEW must run against the **same** database snapshot. Mappings live in Postgres, so a mapping
     edited between runs is a false diff.
   - qb-usa: also compare the review and preview snapshots against the old in-memory `RunResult`.
3. Production: `WORKER_PROCESSES += <id>`. Run one real period in parallel with Andres's normal close. Book it
   only after Andres checks the totals.
4. **Only then**, in a separate commit: delete that process's Flask wizard routes, `templates/<dir>/`, its thread
   site(s) and the `inprocess` fallback for it. The deletion commit is the one a revert restores.

### 5.2 Rollback (Codex PS-14), rehearsed once on staging before I2

1. `PROCESS_SUBMISSIONS_PAUSED=<id>`: `/api/v2/<id>/runs` returns 503, and `/api/v2/processes` shows the
   process disabled.
2. Drain: wait for `ApproximateNumberOfMessages` + `…NotVisible` = 0 for that process (the worker logs
   `job_id` per process), or purge. Confirm there are no `running` rows with a live lease.
3. In **one** deploy: revert the deletion commit, set `WORKER_PROCESSES -= <id>` (back to `inprocess`), and if
   H5 has landed, restore `API_DESIRED_COUNT=1`, the single-task pin and the `>1` alarm.
4. Confirm the restored path reads the last serialized `process_runs` row and state objects. It must not rely on a
   module dict; C2 deleted `_volatile`, so none exists to rely on.
5. Unpause.

After G4 and G5 there is no Flask path to restore. Rollback is then "pause, drain, revert to the previous image",
and the queue contract (`v:1`) must be readable by the previous image.

### 5.3 What gets deleted, and when

| When | What |
|---|---|
| Any time Andres consents (G1) | 5 payroll families: 49 routes, 10 dicts, 6 threads, `templates/{adp_payroll,booking_payroll*}/` |
| After I2 | `/revenue/*`, `/qb-revenue/*`, `/process`, `/processing`, `/results`, `/download*`, `/preview`, `/api/processing/*`, threads `:3036/:3135/:3362`, `templates/{revenue,qb_revenue}/` |
| After I3 | `/mx-payroll/*`, `/qb-payroll*`, thread `:4200`, `templates/mx_payroll/` |
| After I4 | `/qb-usa-payroll/*`, thread `:4917`, `templates/qb_usa_payroll/`, the `inprocess` transport in production config (it stays for tests) |
| G2 (evidence-driven) | `/api/config/*`, `/api/mso/*`, `/api/process`, `/api/fiscal-calendar/import`, `/auth/*` Flask handlers, `/qbo/*`, `/api/v1/*` (per §7.2) |
| G5, last | `web_app.py`, the rest of `templates/`, the Flask dependencies, the WSGI mount and its adapter, `api/uploads.py`'s werkzeug use, in one commit that also updates `CLAUDE.md` "Front End" and `README.md` |

---

## 6. Verification and exit criteria (mapped to the PHASE COMPLETION LOOP)

| Loop criterion | Phase 11 evidence |
|---|---|
| Features work for real | `new_process demo` → registered, conformance-green, **zero `infra/` edits** (F2 CI job). All three processes run on SQS in production (I2-I4) |
| All tests pass | unit, pg_fixture, migrations 0011/0012 up and down, `cdk synth`/`diff`, `tests/conformance/`, security (cross-org job message refused, wrong-actor refused, a cross-org run read is 404) |
| Byte-diff | `diff_je_output.py` exit 0 for both rehearsal periods × three processes; the report pasted (it is salted and safe) |
| Resilience | killed worker mid-run → the run resumes to `completed`, no orphaned `state/` object (H3). SQS redelivery → exactly one QBO create (E2 test + H3 sandbox) |
| Scale-out | `desiredCount=2` in production for the test window: a qb-usa run with review on task A and preview/execute on task B (proved by `ecs_task_id` in the structured logs), and the export on the worker |
| No Flask | `grep -ril flask --include='*.py' --include='*.txt' --include='*.toml' --include='Dockerfile*' src api workers scripts requirements* Dockerfile*` is empty. `tests/` may keep a retired-path test that names the word; the exact grep is agreed in the report rather than hidden |
| Fable critic + Codex | zero open critical/high. The critic list's "second registry", "double-post on retry", "half-migrated paths" and "unsafe concurrency" each map to A3, E2, §5.3 and D2/D3 |
| Tidy | `repo-layout.md` rows 8-9 true (`src/processes/`, `workers/`); tracker Phase 11 rows closed; no `web_app.py` |
| Docs | ADRs (§8), `docs/adding-a-process.md`, runbook `phase-11-worker.md`, control matrix rows (idempotency, DLQ alarm, PHI state audit), `CHANGELOG.md`, phase report, Obsidian note under `NS_Proccess/` |

---

## 7. Risks and open decisions

### 7.1 Decisions with a recommended default (Claude proceeds unless the trigger fires)

| Decision / risk | Default | Trigger that changes it |
|---|---|---|
| Worker image | The same image as the api with a different CMD (one build, one scan) | image size or cold start hurts the api → split the Dockerfile stage |
| Lease vs advisory lock | Lease columns on `process_runs` | a measured need for sub-second mutual exclusion |
| Standard vs FIFO queue | Standard + lease + idempotency | ordering between jobs of one run becomes required |
| Visibility / heartbeat | 900 s + heartbeat every 120 s | a measured run over 60 min → raise it and recheck the Fargate stop timeout |
| State format | JSON only | Andres approves `pyarrow` **and** a state object exceeds ~50 MB |
| Where payroll `personnel` state lives | Small data in `run_state` (as today); objects in the `phi` bucket (fail closed) | a compliance reviewer classifies payroll data differently |
| Keep the DB CHECKs | Yes. The scaffold writes the widening revision | adding processes becomes frequent enough that the revision is friction |
| Per-task rate limits at N=2 | Accept; WAF rate rules at the edge cover the gap; record it in an ADR | a security test shows lockout bypass by alternating tasks → a Postgres fixed-window counter |
| `scripts/qbo_post_je.py` | Route it through `src/idempotency.py` | Andres says it is unused → retire it |
| Early build | LOCAL-NOW tasks may start before cutover; LOCAL-NOW† switch-on commits wait; B-tasks follow the timing rule | Andres wants Phase 11 fully after cutover → just start later; nothing is lost |

### 7.2 Decisions only Andres can make

**Answered by Andres on 2026-09-22:**
- **Rehearsal workbooks: Andres does not have them.** The JE diff gate needs another input source — see the
  open item in `docs/runbooks/production-readiness.md` row 17.
- **The five dead payroll families: delete (yes).**
- **`/api/v1`'s 10 non-health routes: delete in Phase 11 (yes).** `/api/v1/health` stays until Phase 12 D-25.
- **Second api task: no.** Keep one task and right-size once heavy work moves to the worker; no +$29/month.
- **Wearbly: retire.** `a2wsgi`: added.


1. **Rehearsal periods and input workbooks** (`docs/je-diff-procedure.md` §Rehearsal periods). Without them
   I1-I4 cannot run. They may already be settled by Phase 9.
2. **Cost:** a second api task (+~$28.83/mo pre-tax, past the ~$238 ceiling), versus right-sizing to
   2 × 0.5 vCPU / 1 GB at about today's cost, versus staying at 1 task with rolling deploys. The recommendation
   is to measure, then right-size.
3. **Delete the five dead payroll families now** (tracker row 151; recommended; they are not tenant-bound on
   Render today). Also say whether their `src/adp_*`/`booking_*` processors and `adp_payroll`/`booking_payroll`
   scopes stay.
4. **`/api/v1` in Phase 11:** D-25 puts its retirement in Phase 12, but "no Flask" at the end of Phase 11 needs
   it gone or ported. ~~Recommendation: 30 days of ALB access logs after cutover~~ — **superseded
   2026-09-22:** the evidence is the grep of §2.6 only (G2 deviation (1)); retire it with your sign-off if
   the grep finds no caller, otherwise port the 9 read endpoints thinly.
5. **Dependencies:** `python-multipart` (to drop werkzeug parsing, tracker rows 97/139) or keep werkzeug
   standalone; `pyarrow` only if parquet is wanted. (`a2wsgi` was added 2026-09-22 with Andres's approval; it is removed with the mount in G5.)
6. ~~**Wearbly:** a framework process or retired~~ — **decided 2026-09-22: retire** (readiness row 26). Its code removal still needs a separate yes before anything is deleted.

Also confirm at the time (already agreed in the plan, but it is a delete): the G5 commit that removes
`web_app.py` and `templates/`.

### 7.3 Risks

| Risk | Mitigation |
|---|---|
| The B-task moves change JE output subtly (import-order side effects, module globals such as the one `test_run_isolation.py` guards) | golden diffs per move; the timing rule; the full gate in I |
| C5 is the largest unknown: the qb-usa review/preview snapshot has to reproduce what the in-memory `RunResult` showed | the contract §3A walk-through as a test; a snapshot vs `RunResult` diff on staging in I4 |
| Batch reuse on retry (C7) is unverified for every processor | C7 fails first if a processor allocates unconditionally; budget +1 d |
| Intuit's `requestid` replay window is unknown | the §3.7 re-query path does not depend on it; ADR 0032 (2026-09-24): an ambiguous failure reuses the requestid, a definite one rotates to a derived new one, and the ledger records both |
| `/auth/*` and `/qbo/*` Flask handlers may be live dependencies (IdP or Intuit redirect URIs) | G2 requires evidence before deleting; `QBO_REDIRECT_URI` checked first |
| The `templates/` delete breaks invoice PDFs | G5 moves the PDF templates first; byte-identical HTML test |
| A definer function is a privileged door | `SET search_path`, EXECUTE only for the worker/app role, returns ids and state only, pg_fixture tests of every refusal |

---

## 8. Proposed new ADRs (titles only)

**Numbers 0027-0034 are reserved for these** (recorded 2026-09-24 in `docs/adr/README.md`). Phase 12's
ADRs, written first, were given **0035-0043** so the two phases do not collide. If Phase 11 needs more
than eight, it continues from **0044**.

- **0027: Process manifest as the single registry.** The manifests generate the five lists; the DB CHECKs stay,
  and the scaffold widens them.
- **0028: Generic worker, one `run_job`, two transports.** Inprocess for dev and tests, SQS on ECS;
  `WORKER_PROCESSES` for per-process cutover.
- **0029: Job message contract and pre-context authorization.** The `v:1` schema; `app.authorize_job` as a
  SECURITY DEFINER function.
- **0030: Run leases instead of advisory locks.** The claim, heartbeat and sweeper semantics.
- **0031: Worker state classification and storage.** The public/personnel/phi/never classes, JSON-only, prefix
  separation, `phi.open_state()`.
- **0032: Idempotency table and the QBO posting algorithm.** The scopes, the pending re-query, the `requestid`
  derivation kept.
- **0033: Lifting the single-task api.** Rolling deploys, the alarm change, the right-sizing or count-2 decision
  and its cost.
- **0034: Retiring Flask.** The deletion order, what moved (PDF templates), and the fate of `/api/v1`.

---

## 9. Effort vs the plan's 27-40 days

| Group | Plan composition | This plan | Notes |
|---|---:|---:|---|
| A Manifest + registry | 3-4 | 2.5-3 | the inventory work is already done |
| B Processor extraction | (inside 10-15) | 4.5-5 | the plan never counted moving code out of `web_app.py` |
| C Inputs + serialization | 10-15 | 11-12.5 | C5 (qb-usa) is 3-4 of it |
| D Worker + queue | 5-7 (with E) | 6.5-7.5 | |
| E Idempotency | ↑ | 4 | |
| F1-F2 Conformance + scaffold | 4-6 | 3.5-4.5 | |
| H Infra + staging + prod | (inside worker) | 6 | |
| I Migrate three | 5-8 | 6-8.5 | |
| **Subtotal, plan scope** | **27-40** | **~44-51** | |
| F3 React generic shell | — | 1.5-2.5 | the prompt requires it; the plan did not count it |
| G Flask retirement + parked tracker rows | — | 9.5-13.5 | G6 (2.5-3.5) can be done now and removed from Phase 11 |
| **Total** | **27-40** | **~55-67** | LOW confidence, like the plan's |

**How to shrink it:**
- Do the [LOCAL-NOW] rows now, while waiting on AWS approvals: A, B (timing rule), C3, D1-D3, D6, E1, F1-F3, G6
  and H1-H2 are about **25-30 days**. That takes the post-cutover work down to roughly 30-38 days.
- G1 and G2 get cheaper if Andres agrees to delete rather than port.
