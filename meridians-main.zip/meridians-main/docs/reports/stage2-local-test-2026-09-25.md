# Stage 2 — local end-to-end test (2026-09-25)

> **Pass 2 (same day, `39ef260`, no workarounds): READY for Stage 3.** All fifteen pass-1
> findings are fixed and verified; every JE CSV downloaded from the React results screens is
> byte-identical to `tests/golden`. One new medium finding (N1: an unposted-config block cannot
> be fixed from the app) should be fixed before the Phase 8/9 data copy, not before Stage 3
> starts. See [Pass 2](#pass-2--no-workarounds-39ef260) at the end. The text below is pass 1.

**Pass 1 bottom line: NOT ready for Stage 3 yet.** Every gate is green and all three processes produce
journal entries that are byte-identical to `tests/golden` — but only after working around
three product bugs. Two of them would book wrong or incomplete journal entries from the React app
(F2 blank JE date, F3 unposted JEs silently skipped). One makes `npm run dev` unusable (F1). The
rest are medium or low. Details, repro steps and the blocker list are below.

- Tested commit: `aws-migration` @ `0e50195` (worktree branch `worktree-agent-a5a65afa9dd351ad4`)
- Data: synthetic only (the golden harness's inputs, `tests/fixtures/qb_usa_payroll/`, the two
  seeded orgs). No client data, no PHI, no AWS, no Intuit, no Supabase, no `.env` read.
- Plan section: `docs/reports/local-first-plan-2026-09-24.md` Stage 2, steps 1-6.

## 1. Environment and exact commands

| Item | Value |
|---|---|
| Machine | macOS (Darwin 25.5), Homebrew PostgreSQL **18.3** (D5: Docker off, so no compose run) |
| Python | the project venv (`…/NS_Proccess_QB/venv/bin/python`), `PYTHON_DOTENV_DISABLED=1` everywhere |
| Node | v24.7.0 (the web `package.json` asks for 22.x: `EBADENGINE` warning only) |
| Database dir | session scratchpad `…/scratchpad/s2-pgdata` (outside the repo), port 55432 |
| Secrets | throwaway, generated with `openssl rand` into `s2-secrets.env` (scratchpad, 0600); never printed |

Scratch files below live in the session scratchpad (`/private/tmp/claude-501/…/scratchpad/`),
not in the repo. They are test harness, not product code.

```bash
# 1. database: initdb, roles, alembic upgrade head (0028), seed 2 synthetic orgs + all QB maps
. s2-secrets.env        # MERIDIAN_LOCAL_PGDATA=…/s2-pgdata + 4 throwaway passwords/keys
scripts/local_db_bootstrap.sh
#   -> 0028_api_request_export_writer; orgs 5eed…a1 "Local Dev", 5eed…b2 "Synthetic Second Clinic";
#      318 mappings; qb_account 15, qb_clinic 17, qb_department 11, qb_location 2,
#      qb_other_code 3, qb_payer_label 5, qb_provider 33 rows per org

# 2. api (s2-api.sh)
set -a; . s2-pgdata.env; set +a     # APP_ENV=development DATABASE_BACKEND=postgres
                                    # STORAGE_BACKEND=local AUTH_BACKEND=disabled
                                    # EMAIL_BACKEND=disabled MERIDIAN_API_V3=1 POSTGRES_URL=…
export WORKER_PROCESSES=qb-revenue,mx-payroll,qb-usa-payroll JOB_TRANSPORT=inprocess
export MERIDIAN_DATA_DIR=…/s2-data MERIDIAN_SCRATCH_DIR=…/s2-scratch FLASK_SECRET_KEY=<throwaway>
scripts/serve_api.sh                # first run; later runs used s2_serve.py (same uvicorn args + hooks, §1.1)

# 3. web
cd web && npm ci
npm run dev                         # FAILS — every page and /api proxy call is 500 (finding F1)
npm run build && npm run start      # used instead, on :3000 (same rewrites to :5050)

# 4. second api instance for /api/v3 machine tokens (s2-api-b.sh), :5051, same database
AUTH_BACKEND=cognito COGNITO_USER_POOL_ID=us-east-1_S2LOCALPOOL COGNITO_CLIENT_ID=… \
COGNITO_CLIENT_SECRET=<throwaway> COGNITO_REGION=us-east-1 MERIDIAN_PORT=5051  (+ hook 4)
```

### 1.1 Harness workarounds (scratchpad only, nothing committed)

`s2_serve.py` runs the same `uvicorn api.main:app` as `serve_api.sh` (same host/port/proxy
flags) with test seams the pytest suite already uses. Each one exists because of a finding:

| # | Workaround | Why | Same seam in the tests |
|---|---|---|---|
| W1 | `next build && next start` instead of `next dev` | F1 | — |
| W2 | copy each worker job's batch folder aside before `discard_job_output` deletes it | On `STORAGE_BACKEND=local` the worker publishes nothing, so the JE CSVs exist nowhere after a run (F5). Needed to diff them | `tests/test_oneshot_jobs_pg.py` `capture_then_discard` |
| W3 | qb-usa: `_qb_usa_require_supabase` returns a recording store under `s2-storage/` | qb-usa refuses to book on local storage (F5) | golden `_RecordingStorage` |
| W4 | `config/mappings.example.xlsx` copied to `$MERIDIAN_DATA_DIR/config/mappings.xlsx` | unposted JEs need that file (F3) | golden `workdir` fixture does exactly this |
| W5 | JE date typed as `2025-07-28` instead of left empty | F2 | golden passes `None` |
| W6 | synthetic qb-usa roster + P08-2026 overrides inserted (`s2_seed_usa.py`, from the fixture files through the product's own parser) | local seed has no qb-usa roster (F4) | `tests/qb_usa_synthetic.py` (`allow_csv_master`) |
| W7 | `app.state.cognito_client_admin = FakeCognitoClientAdmin()` | approve → 500 on a laptop (F6) | every admin-client test |
| W8 | instance B: laptop-only pool, JWKS from `s2-jwks.json`, tokens from `s2_mint.py` | no Cognito locally | `tests/security/machine_support.py` |
| W9 | webhook sender: `hooks.s2-receiver.test` → 93.184.215.14 → dialled at 127.0.0.1:8443, TLS trusting a throwaway CA | the sender only dials public IPs on 443 (correct SSRF rule) | `test_webhook_local_delivery.py` `FakeResolver`/`RecordingSocketFactory` |

All other names still go through the real resolver, so the SSRF checks in §5 hit the real rule.

## 2. Results at a glance

| Step | Result |
|---|---|
| 1 Bring-up (bootstrap, api, web) | **PASS with F1** (web only via build+start) |
| 2a qb-revenue in the React app | **FAIL as shipped** (F2, F3); **PASS** 20/20 CSVs byte-identical with W4+W5 |
| 2b mx-payroll raw + excel method | **PASS** 4/4 + 4/4 byte-identical |
| 2c qb-usa-payroll clean + roster_blocked | **FAIL as shipped** (F4, F5); **PASS** 9/9 + 9/9 byte-identical with W3+W6 |
| 2d Downloads | **NOT TESTABLE locally** (F5): no object store, no signed URL |
| 2e /config/quickbooks: delete a row → blocked → add back → retry | **PASS** |
| 3 Worker kill mid-run → redelivery | **PASS** (one result, one batch, 27 JE rows, 20/20 identical) |
| 3b QBO push | NOT TESTABLE (Intuit); fake-QBO pg tests **110 passed** |
| 4 API v3 (client via admin screens, scopes, masking, BOLA, lockout, quota, webhooks, SSRF, replay) | **PASS** with W7-W9; F6, F7 found |
| 5 Gates | **PASS** (numbers in §6) |

Screenshots: `…/scratchpad/s2-shots/01-…48-*.png` (48 files). Logs: `…/scratchpad/s2-logs/`.
Two screenshots (37, 43) show one-time secrets; they are throwaway local values, but do not copy
those files anywhere.

## 3. Step 2 — every process in the React app

Driven with the Playwright MCP browser against `localhost:3000`. JE CSVs compared with
`s2_cmp.py` (run stamp `_YYYYMMDD_HHMMSS` normalised to `_TS`, then raw bytes).

### qb-revenue (golden input: `make_sample_revenue.py` rows + one hospital sheet, P07 FY25, the 8 golden bank deposits)

| Run | Setup | Result |
|---|---|---|
| `29369169…` | as a user would: JE date empty | 11 CSVs **differ** (Date column empty), 9 **missing** (all 8 `JE_Unposted_*` + `JE_Revenue_Unposted_*_QB`). Screen says **Booked**, tie-out "Ties" |
| `8d8fdc1e…` | JE date typed `2025-07-28` | 11 identical, 9 still missing |
| `02366641…` | + W4 | **20/20 byte-identical** |

Upload → processing → results all render. There is no preview step for revenue (the only human
stop is "Fix mappings"). Downloads: see F5.

### mx-payroll

| Run | Input | Result |
|---|---|---|
| `7f881f4c…` | raw export, rate 18.25 | **4/4 identical** (`JE_Payroll_Main/Provision_P08_FY26[_QB].csv`) |
| `f4b00d48…` | processed "-2" workbook (excel method), Preview dialog used | **4/4 identical** |
| `add240f8…` | same workbook, rate **20** (via the proxy) | 4/4 identical — the typed rate is ignored (F9) |

### qb-usa-payroll

| Run | Result |
|---|---|
| `f0a2f1d5…` (fresh local stack) | **Failed `FILE_UNREADABLE`** — the real cause is an empty roster (F4) |
| `8e87e383…` (after W6) | parse → preview: 9 JEs, 22/24 gates, the 2 expected G5 UNUM failures; declared both in the UI; **Book → 503 `PERSISTENCE_UNAVAILABLE`** ("Storage fell back to local disk … Supabase", F5). After W3 + api restart, booked from the same preview: **9/9 byte-identical** to `qb_usa_payroll_parser` (parse and book in different api processes) |
| `29198077…` roster_blocked (roster seeded without Garrow) | stops at Roster review with the one prompt (`DJ8:000415`); answered in the UI (DJ8, smllc_hourly, OBG Northside, 302 Front Desk, run-only) → preview → declare → book: **9/9 byte-identical**; DUPLICATE_INPUT warning shown on results |

### /config/quickbooks — missing mapping

Deactivated account `41002` on the Accounts tab → revenue run `97aaad16…` stopped
**Blocked — "Nothing was booked — QuickBooks mappings are missing"**, listing `Qb account map: 41002`
with links "Open Accounts" (`/config/quickbooks?section=qb-accounts`) and "Open QuickBooks mappings".
Followed the link, reactivated, "Run it again" → Booked, batch 10, **20/20 identical**.
Screens 24-28.

### MFA / invite screens

Not provable here: `AUTH_BACKEND=disabled` means every request is the dev superadmin; there is no
Cognito to send an invite, enrol TOTP or challenge MFA. Needs Stage 3.

## 4. Step 3 — worker kill and redelivery

`s2-kill-midrun.sh`: created a revenue run through the proxy, waited for the log line
`job started kind=execute`, slept 0.5 s, `kill -9` the api. Last lines before the kill: the
revenue workbook sheets (after the JE CSVs and batch 12 were written). Restarted the api.

| Time (UTC) | Event |
|---|---|
| 09:06:31.144 | `job started` execute, attempt 1 |
| 09:06:31.73 | SIGKILL |
| 09:16:31 | lease (10 min) lapsed |
| 09:16:43.082 | `job delivered again after its process was lost` (recover tick) |
| 09:16:43.085 | `job started` execute, attempt 2 |
| 09:16:44.946 | `job settled` state=completed |

Run row after: `completed | results | attempts 2 | batch 12 | settled_job_ids = {84573cc4…}` (one
job id, settled once). `import_batches` 11 → 12 (one new batch). `journal_entries` for batch 12:
27 rows, debit = credit = 11,663.24 — the same as normal runs (batches 4, 10, 11). Captured CSVs:
**20/20 byte-identical**. The screen showed "Booking… 95%" during the gap, then Booked (29, 42).

QBO push: cannot run without Intuit. Evidence instead: `test_qbo_push_job_pg`,
`test_qbo_post_je_ledger_pg`, `test_qbo_push_concurrency_pg`, `test_worker_post_completion_pg`,
`test_post_completion_claim_pg`, `test_job_redelivery_history_pg` → **110 passed**.

## 5. Step 4 — API v3

**Machine client via the admin screens** (`/admin/api/clients/new`, screens 30-38): 4-step wizard
(name/kind → scopes + processes → network → preview) → "Awaiting approval" → Approve with a reason.
First approve: **500** (F6). With W7: secret shown once, fingerprint `sha256:789d…`, status Active,
"Approved by its requester" (D22 allows this in development). Scopes granted: `runs:read
processes:run artifacts:download webhooks:manage mappings:read journal-entries:read`; process QB Revenue.
The usage panel later counted 314 requests / 7 errors, last address 127.0.0.1 (screen 48).

Against instance B with tokens for that client (`s2_v3.py`, all **PASS**):

| Check | Answer |
|---|---|
| `/api/v3/health` no token | 200 |
| `/api/v3/runs` no token | 401 `AUTH_REQUIRED` |
| `runs:read` → list | 200, 7 runs (qb-revenue only), org B's run absent |
| run detail without `phi:read` | 200 with `input_file`, `batch_id`, `created_by` = **null** (human sees them) |
| org B's run `0b0b…b2b2` | **404** `RUN_NOT_FOUND` (human via v2 and v3: 404 too) |
| `runs:read` only → webhooks list | 403 `SCOPE_INSUFFICIENT` |
| token claiming ungranted `phi:read` | still masked (grant wins) |
| token claiming ungranted `mappings:write` → POST mapping | 403 |
| expired token / unknown `kid` | 401 / 401 |
| 14 forged tokens from 198.51.100.77 | 401 ×10 (with growing delay), then 429 `QUOTA_EXCEEDED` (address locked) |
| valid token from the locked address | 429; from another address: 200 |
| per-client quota | 429 `QUOTA_EXCEEDED` at call 300 of the minute, `Retry-After: 21` |

**Webhooks** (receiver `s2_receiver.py`: HTTPS on 127.0.0.1:8443, verifies with
`src.webhooks.signing.verify` and one replay cache):

| Check | Result |
|---|---|
| Human, React "Add a webhook" (screens 39-47): create → secret shown once → "Send test" | delivered, 200, receiver **verified** |
| First test ping sent while TLS was misconfigured (harness CA), then api restarted | the drainer's stalled-delivery sweep re-found it after the restart (2 failed attempts before) and delivered it on the next one, signed with the **original** secret → verified |
| Machine client (`webhooks:manage`) subscribe + `/test` via instance B | 201, 202, delivered, verified |
| `run.completed` events after an mx and a revenue run | both delivered through the outbox → drainer → receiver, verified. The mx one should not have reached this revenue-only client (F7) |
| Replay the delivered request byte for byte | receiver 401 `replayed_event` |
| One body byte changed | 401 `signature_mismatch` |
| Same request checked 301 s later | `timestamp_out_of_tolerance` |
| SSRF at subscribe (human and machine): `https://127.0.0.1`, `localhost`, `http://…`, `10.0.0.5`, `169.254.169.254`, `[::1]`, `[::ffff:127.0.0.1]`, `:8443`, `100.64.0.1` | all 422 `WEBHOOK_URL_REJECTED` (screen 40 for the UI) |

Logs: 72 synthetic identifiers from the inputs (patient account/claim/encounter numbers, MX
employee codes and names, qb-usa names) searched in both api logs (655 KB): **0 hits**.

## 6. Step 5 — gates on `0e50195`

| Gate | Result |
|---|---|
| `pytest -q` | **4929 passed, 116 skipped, 0 failed** (4 m 50 s) |
| `*_pg.py`, `MERIDIAN_TEST_SHUFFLE_SEED=random`, `MERIDIAN_PG_REQUIRED=1` | **883 passed, 0 failed**, seed `1319316039` |
| `pytest tests/security` | **701 passed** |
| `pytest tests/security --known-bad` | **656 failed, 0 passed** (45 deselected) — every breaker red, as required |
| `pytest infra/tests` | **754 passed** |
| `web: npm run typecheck` | clean |
| `web: vitest run` | **1247 passed** (104 files) |
| `cdk synth` | not run (D2: no CDK CLI) |

## 7. Findings

Severity is about what happens after cutover. None were fixed here (instructions: findings only).

### High

**F1 — `npm run dev` is broken: every page and every proxied API call answers 500.**
Repro: `cd web && npm run dev`, open any page. Log: `Module build failed: UnhandledSchemeError:
Reading from "node:fs" is not handled by plugins … Import trace: node:fs ./src/lib/server-log-node.ts`.
Cause (likely): `src/instrumentation.ts` hides the runtime check inside `enabled()`, so webpack
cannot drop the `import("./lib/server-log-node")` from the non-Node compile; Next's documented
pattern tests `process.env.NEXT_RUNTIME === "nodejs"` inline. Came in with `66dd5cc`
(web JSON logs). `next build` + `next start` work. The web test suite mocks the module, so no gate
catches it.

**F2 — The React revenue form books journal entries with an empty date.**
Repro: new QB Revenue run, leave "Journal entry date" empty (the screen says that means "use the
period end date"), run. Every `JE_Revenue_*.csv` has an empty first column and the QuickBooks CSV
an empty date. Cause: `web/src/components/create-params/registry.tsx:81` defaults `je_date: ""`;
`RevenueCreateParams.je_date` accepts `""`; the processor only looks up the calendar when
`je_date is None` (`src/processes/qb_revenue/processor.py:615` and `:988`), so `""` is used as the
date. The unposted path is fine (`_require_je_date` treats `""` as missing). Came in with F3's
generic form (`063773d`); both the thread path and the worker path are affected on this branch.
Fix direction: treat blank as absent at the API edge.

**F3 — Unposted journal entries are silently skipped on the new stack.**
Repro: fresh local stack (no `config/mappings.xlsx` under `MERIDIAN_DATA_DIR`), revenue run with
"Generate the unposted entry too" and 8 deposits. Result: no `JE_Unposted_*` files and no
`JE_Revenue_Unposted_*_QB.csv`; the run is "Booked", the tie-out "Ties", and neither the screen nor
`warnings` says anything. The log has one WARNING: `Could not load unposted_config sheet
(FileNotFoundError)` from `src/unposted_generator.py:157`. `UnpostedJEGenerator` reads the
`unposted_config` sheet from the workbook only — no database source and no example fallback
(unlike `Config.load`). On AWS there is no such workbook, so unposted revenue would never be booked.
The golden and pg tests copy the example workbook into place (W4), which hides this.

### Medium

**F4 — qb-usa cannot run on the local stack, and the failure is reported as a bad file.**
(a) `scripts/seed_local_dev.py` seeds no `qb_usa_employee` / location / department rules /
`ts_benefit_override`, so every qb-usa run fails. (b) The failure reaches the user as
`FILE_UNREADABLE` ("The run stopped with FILE_UNREADABLE") while the log says the roster is empty
(`ValueError` in `_resolve_period_roster`). Repro: fresh bootstrap, upload the `clean` fixture set.

**F5 — `STORAGE_BACKEND=local` (decision D4) is a dead end for results and downloads.**
- revenue/mx on the worker path: `publish_run_outputs` returns `[]` for `LocalStorageManager` and
  the job then deletes its batch folder, so the CSVs exist nowhere; the results screen says
  "Exports not in storage … on a server with no Supabase" and "This run produced no files".
- qb-usa: `_qb_usa_require_supabase` refuses local storage, so **Book** answers 503
  `PERSISTENCE_UNAVAILABLE` "…refusing to silently skip the Supabase Storage upload".
- downloads need a signed URL, which local storage cannot give (with W3, "Download everything"
  navigated to a relative filesystem path → 404).

The plan's Stage 2 step 2 ("… → JE download") cannot pass locally until there is a local object
store (LocalStack, D4) or a streamed local download. Also the messages still name Supabase on a
Postgres stack.

**F6 — Approving a machine client on a laptop is an unhandled 500.**
Repro: `/admin/api/clients/new` → submit → Approve. `api/main.py:311` always wires
`BotoCognitoClientAdmin`; with no `COGNITO_*` env, `cognito._env` raises `RuntimeError` inside
`BotoCognitoClientAdmin._call` (`src/cognito_client_admin.py:248-254`), which only catches
`ClientError`/`BotoCoreError`, so the screen shows "Something went wrong on our side" instead of
the router's own 503 `IDENTITY_PROVIDER_UNAVAILABLE`. The module docstring says the fake runs "on a
developer machine", but nothing selects it outside tests.

**F7 — Webhook run events ignore the client's allowed processes.**
Repro: machine client allowed only QB Revenue subscribes to `run.completed`; finish an mx-payroll
run. The client receives `run.completed` with the mx run's id, process and state — and gets 404 if
it asks for that run. Events should follow the same process scope as `/api/v3/runs`.

### Low

- **F8** The revenue results screen never shows `DUPLICATE_INPUT` (the API returns it: run
  `29369169…` `warnings[0].code = DUPLICATE_INPUT`); the qb-usa screen does.
- **F9** MX excel method: the screen requires an exchange rate and says every amount is divided by
  it, but for a processed workbook the typed rate is ignored (rate 20 and 18.25 give identical CSVs).
- **F10** While a killed run waits for redelivery the screen shows "Exporting revenue workbook… 95%"
  next to a sub-stepper stuck on "Step 1 of 7: Validating, current step".
- **F11** The bootstrap/seed prints "config/mappings.xlsx missing — reading the redacted example
  workbook instead" 35 times.
- **F12** On Postgres, an empty `ts_benefit_override` falls back to the local JSON file (a config
  file on the RDS path) and the warning says "Supabase and ts_benefit_overrides.local.json both absent".
- **F13** Development with `AUTH_BACKEND=cognito` but one `COGNITO_*` variable missing silently
  falls back to the auth bypass: every request, with or without a token, is the dev superadmin
  (seen on instance B before `COGNITO_CLIENT_SECRET` was set). By design (`dev_fallbacks_permitted`),
  but worth a startup warning.
- **F14** Copy: the MX new-run page says "Choose the period first. Nothing is preselected…" though
  MX has no period to choose; the qb-usa roster-review tie-out says "Breaks … Out of balance by zero
  dollars" while it is only waiting for answers; field labels "Qb location/department/class".
- **F15** A pytest run from the repo root leaves an empty `output/P01_FY26_<stamp>/` folder in the
  working tree (gitignored).
- Known, already queued: qb-usa `DUPLICATE_INPUT` only appears after booking, not at preview.

## 8. What could not be tested locally, and why

| Item | Why |
|---|---|
| Cognito sign-in, MFA enrolment/challenge, invites, Google/Microsoft federation | no Cognito; `AUTH_BACKEND=disabled`. Machine tokens were verified against a laptop-only pool (W8) — the JWT checks are real, the pool is not |
| SES delivery | `EMAIL_BACKEND=disabled` |
| GuardDuty malware tagging | local input store has no scanner (the pg tests cover the gate) |
| WAF / CloudFront, mTLS origin header | no edge locally |
| Pre-signed POST to real S3; v3 `processes/*/runs` + `/uploads`; downloads | no S3 (D4) — see F5 |
| QuickBooks sandbox push | no Intuit (fake-QBO pg tests instead, §4) |
| Real-data JE parity | D8: synthetic only |
| Docker compose, worker image, SQS worker loop | D5: Docker off; `JOB_TRANSPORT=inprocess` only |
| `cdk synth` | D2 |

## 9. Ready for Stage 3?

**No — fix these first (all are local work, no AWS needed):**

1. **F2** blank JE date from the React revenue form (wrong JEs).
2. **F3** unposted JEs need a database source for `unposted_config` (and a loud refusal when it is
   missing) — otherwise unposted revenue is never booked on AWS.
3. **F1** `npm run dev`.
4. **F5** decide how Stage 2 proves results/downloads: LocalStack (D4) or a local streamed
   download; otherwise the "upload → … → download" line of the plan stays untested until staging.
5. **F4/F6/F7** before the partner API is switched on (F7 is a small data leak to partners).

After those, re-run §3 without W2-W7 (keep W8-W9, which only stand in for AWS). Everything else
held: golden parity on all three processes, kill/redelivery with exactly one result, tenant
isolation, masking, scopes, lockout, quotas, signed webhooks with replay protection, and every gate.

---

## Pass 2 — no workarounds (`39ef260`)

**Verdict: READY for Stage 3. No blockers.** Every pass-1 finding (F1-F15) is gone. All three
processes were run through the React app exactly as a user would — `npm run dev`, JE date left
empty, no workbook copied into place, no recording store, no fake Cognito admin injected — and
every JE CSV downloaded from the results screens is byte-identical to `tests/golden`. Kill and
redelivery gave exactly one result. The partner API, webhooks, SSRF and replay checks all held.
Eight new findings, one medium (N1) and seven low; none books a wrong journal entry.

- Tested commit: `aws-migration` @ `39ef260` (worktree branch `worktree-agent-a79f6b266228d6b1f`)
- Data: synthetic only (golden-harness inputs, `tests/fixtures/qb_usa_payroll/`, the two seeded
  orgs). No client data, no PHI, no AWS, no Intuit, no Supabase, no `.env` read
  (`PYTHON_DOTENV_DISABLED=1`; the worktree has no `.env`).

### P2.1 Environment and exact commands

| Item | Value |
|---|---|
| Machine | macOS (Darwin 25.5), Homebrew PostgreSQL 18.3, Docker off (D5) |
| Python | the project venv, `PYTHON_DOTENV_DISABLED=1` |
| Node | v24.7.0 (`EBADENGINE` warning only, as in pass 1) |
| Database | scratchpad `s2p2-pgdata`, port **55433** (55432 left alone), alembic head `0031_queued_job_resend` |
| Data / scratch dirs | `MERIDIAN_DATA_DIR=…/scratchpad/s2p2-data`, `MERIDIAN_SCRATCH_DIR=…/s2p2-scratch` (README lists both; they keep run data out of the repo) |
| Secrets | throwaway, `openssl rand` into `s2p2-secrets.env` (0600), never printed |

```bash
s2p2-mksecrets.sh                       # throwaway passwords/keys + the two dirs above
s2p2-bootstrap.sh                       # = scripts/local_db_bootstrap.sh with those exports
#   -> alembic 0031; orgs 5eed…a1 "Local Dev", 5eed…b2 "Synthetic Second Clinic"; 318 mappings;
#      "qb-usa (Local Dev): 10 synthetic employees, 3 P08-2026 overrides"
s2p2-api.sh                             # set -a; . s2p2-pgdata.env; set +a;
                                        # WORKER_PROCESSES=qb-revenue,mx-payroll,qb-usa-payroll;
                                        # scripts/serve_api.sh   (plain, no hooks) — steps 1-3
cd web && npm ci && npm run dev         # :3000, compiles /instrumentation, every page 200
```

For step 4 only, api A was restarted through `s2p2_serve.py` (same uvicorn arguments as
`serve_api.sh`) and a second instance B was started on :5051. The only seams left are the two
pass 1 already classed as AWS stand-ins:

| # | Seam | Why it is still needed |
|---|---|---|
| W8 | instance B: `AUTH_BACKEND=cognito` against a laptop-only pool; JWKS from `s2p2-jwks.json`, tokens from `s2p2_mint.py` | no Cognito locally |
| W9 | the webhook sender resolves only `hooks.s2-receiver.test` to 93.184.215.14 and dials it at 127.0.0.1:8443 (TLS trusts a throwaway CA); every other name goes through the real resolver | the sender correctly dials only public IPs on 443 |

W1-W7 are gone: no `next build`, no capture hook, no recording store, no copied
`mappings.xlsx`, no typed JE date, no hand-seeded roster, no injected `FakeCognitoClientAdmin`.

**Test setup done in the database (not product workarounds).** The app has no screen for
the qb-usa roster or for clinic groups' unposted fields (see N1, N3), so three scenarios were
set up with `psql` as `meridian_migrator` under `app.org_id`, and every change was undone
afterwards:
Garrow's roster row `is_active=false` (roster_blocked), all 10 roster rows inactive (ROSTER_EMPTY),
Forest's `primary_location_code` set to NULL (unposted block), the three P08 overrides inactive
(F12), and one synthetic org-B `process_runs` row `0b0b…b2b2` for the BOLA checks.

Screenshots: `…/scratchpad/s2p2-shots/01-…40-*.png`. Logs: `…/scratchpad/s2p2-logs/`
(`api.log`, `api-b.log`, `receiver.jsonl`, `gate-*.log`). Downloads: `…/scratchpad/s2p2-dl/`.
Screenshots 29 and 33 show one-time secrets (throwaway local values; do not copy them anywhere).

### P2.2 Results at a glance

| Step | Pass 1 | Pass 2 |
|---|---|---|
| 1 Bring-up (bootstrap, api, `npm run dev`) | PASS with F1 | **PASS** |
| 2a qb-revenue in the React app, JE date empty | FAIL as shipped (F2, F3) | **PASS** — 20/20 downloaded CSVs byte-identical, incl. all 8 `JE_Unposted_*` + `JE_Revenue_Unposted_*_QB` |
| 2b mx-payroll raw (rate 18.25) + processed workbook (no rate) | PASS | **PASS** — 4/4 + 4/4 downloaded, byte-identical |
| 2c qb-usa clean + roster_blocked, **Book** | FAIL as shipped (F4, F5) | **PASS** — Book works on local storage; 9/9 + 9/9 downloaded, byte-identical |
| 2d Downloads from the results screens | NOT TESTABLE (F5) | **PASS** — per-file signed downloads and "Download everything" (zip, 23 files; its 20 JE CSVs identical) |
| 2e /config/quickbooks: deactivate → blocked → reactivate → retry | PASS | **PASS** — 20/20 identical after retry |
| 2f Unposted config removed → blocked → restore → retry | — | **PASS** on the API (`UNPOSTED_CONFIG_UNAVAILABLE`), 20/20 identical after retry; screen gaps → N1 |
| 3 Worker kill mid-run → redelivery | PASS | **PASS** — one result, one batch, 27 JE rows, 20/20 identical |
| 4 API v3 (admin screens, scopes, masking, BOLA, lockout, quota, webhooks, SSRF, replay) | PASS with W7-W9, F6, F7 | **PASS** with W8-W9 only |
| 5 Gates | PASS | **PASS** — pytest 5061 / 0 failed, shuffled pg 939 / 0, security 719, known-bad 674 red / 0 passed, infra 754, web 1273 (P2.6) |

### P2.3 Step 2 — every process in the React app

Driven with the Playwright MCP browser against `localhost:3000` (`npm run dev`). Every JE file
was fetched with the row's **Download** button on the results screen (signed local URL,
`POST …/artifacts/{id}/download-url` → 201) and compared with `s2p2_cmp.py`: raw bytes, only a
`_YYYYMMDD_HHMMSS` stamp in a file *name* normalised.

**qb-revenue** (golden input, P07 FY25, "Choose it myself", 8 golden bank deposits, JE date
**left empty**):

| Run | What | Result |
|---|---|---|
| `3a98eb50…` | first run | Booked, batch 1, 23 files; **20/20 JE CSVs byte-identical** (dates filled from the period end); tie-out "Ties", 12,209.99 |
| same | "Download everything" | `QB_REVENUE_P07_2025.zip`, 23 entries; its `journal_entries/` 20/20 identical |
| `2716269f…` | /config/quickbooks loop (below) | 20/20 identical; results show the **Duplicate input** notice (F8) |
| `dd436ac3…` | unposted-config loop (below) | 20/20 identical after retry |
| `edf5ca34…` | the killed run (step 3) | 20/20 identical |

**mx-payroll**

| Run | Input | Result |
|---|---|---|
| `a6bcb956…` | processed workbook, exchange rate left **empty** | Booked, batch 3; **4/4 identical** to `mx_payroll_excel` |
| `17343056…` | raw export, rate 18.25 | Booked; **4/4 identical** to `mx_payroll` |
| `1bd00fdf…` | raw export, rate 18.25 (first try) | Booked, then **Superseded** by `a6bcb956` (same period) — read-only, no downloads, as designed |

**qb-usa-payroll** (the fixture ADP files + the two carrier bills; P08 FY26; accrual days
worked out as 10 by the screen; roster from Postgres, seeded by the bootstrap)

| Run | Result |
|---|---|
| `78631191…` clean | parse → preview: 9 JEs, 22/24 gates, the 2 expected G5 UNUM failures; declared both in the UI; **Book → Booked, batch 5**; 9/9 downloaded **byte-identical** to `qb_usa_payroll_parser`; tie-out "Declared", variance −53.60 (19.60 + 34.00) |
| `fcfe3428…` roster_blocked (Garrow inactive) | stops at **Roster review** with the one prompt (`DJ8:000415`, labels "QuickBooks location/department/class"); answered DJ8 / smllc_hourly / OBG Northside / 302 Front Desk, run-only → preview → declare → **Book: 9/9 identical**; "Duplicate input" shown on results; run-only answer not saved (9 of 10 roster rows active afterwards) |
| `fbbf5c4e…` all roster rows inactive | **Failed `ROSTER_EMPTY`** at upload, "Nothing was saved" (F4b fixed; wording → N3) |
| `ef6f209e…` no P08 overrides active | preview with 3 failed gates; log: "no benefit overrides in postgres for P08-2026; booking raw carrier matches only"; **no JSON fallback** (F12); run cancelled |

**/config/quickbooks — missing mapping.** Deactivated `41002` on the Accounts section → revenue
run `2716269f` **Blocked** "Nothing was booked — QuickBooks mappings are missing", listing
`Qb account map` / `41002` with "Open Accounts" (`/config/quickbooks?section=qb-accounts`) →
followed the link, **Reactivate** → back to the run → **Run it again** → Booked, batch 7,
**20/20 identical**. Screens 18-21.

**Unposted config removed → blocked → restore → retry.** Forest's `primary_location_code` set
to NULL → run `dd436ac3` **Blocked** at step "Fix mappings" with "Some clinic groups are missing
what the unposted journal entries need … Nothing was booked." The API answers
`error.code = UNPOSTED_CONFIG_UNAVAILABLE`, `details = {reason: incomplete, missing:
{primary_location_code: [Forest]}}`, no batch. Restored the value → **Run it again** → Booked,
batch 8, **20/20 identical**. The screen does not show which group/field is missing and there is
no screen to fix it (N1). Screens 22-23.

### P2.4 Step 3 — worker kill and redelivery

`s2p2-killer.sh` watched api A's log; the run was started **from the React form** (no typed JE
date). On `job started kind=execute` it slept 0.5 s and `kill -9`'d api A (the screen then showed
"Request failed (500)" until the api was back — expected with the api down).

| Time (UTC) | Event |
|---|---|
| 11:02:01.968 | `job started` execute, attempt 1, run `edf5ca34…` (api A) |
| 11:02:02 | SIGKILL (last lines: revenue workbook lookup tabs; batch 9 already allocated) |
| 11:02:25 | api A restarted (with W9 for step 4); api B started on :5051 |
| 11:12:01 | lease lapsed |
| 11:12:31.185 | **api B**: `job delivered again after its process was lost` |
| 11:12:31.193 | `job started` execute, **attempt 2** |
| 11:12:32.948 | `job settled` state=completed |

Run row after: `completed | results | attempts 2 | batch 9 | settled_job_ids = {246fa66a…}` (one
job id, settled once). Batch 9 has **27** `journal_entries` rows, debit = credit = 11,663.24 —
the same as batches 1, 7 and 8. No extra batch. While waiting the screen showed "Booking the
period … Exporting revenue workbook… 95%" with the sub-stepper on "Step 5 of 6: Exporting,
current step" (F10 fixed; screen 35). Downloads after: **20/20 identical**. Either api task may
recover a lost job because both share the database; here B won, and the result is still one.

### P2.5 Step 4 — API v3 and webhooks

**Machine client through the admin screens** (screens 25-29, api A, **no injected fake**):
`/admin/api/clients/new` → name + Partner → scopes `runs:read processes:run artifacts:download
webhooks:manage mappings:read journal-entries:read`, process QB Revenue → Any address → Preview
→ Submit → "Awaiting approval" → Open the client → **Approve** with a reason → secret shown once,
fingerprint `sha256:7113…`, status Active, "Approved by its requester". The api logged
"Cognito is not configured: machine clients use the in-memory fake (development only …)" — the
F6 fix selecting the fake by itself. Usage panel afterwards: 322 requests, 11 errors (screen 39).

Against instance B with tokens for that client (`s2p2_v3.py`, **15/15 PASS**;
`s2p2_v3_more.py`, **5/5 PASS**):

| Check | Answer |
|---|---|
| `/api/v3/health` no token / `/api/v3/runs` no token | 200 / 401 `AUTH_REQUIRED` |
| `runs:read` → list | 200, 4 runs, all qb-revenue (mx and qb-usa runs absent); org B's run absent |
| run detail without `phi:read` | `input_file`, `batch_id`, `created_by` = null |
| org B's run `0b0b…b2b2` | machine 404 `RUN_NOT_FOUND`; human via v2 and v3: 404 |
| `runs:read` only → webhooks list | 403 `SCOPE_INSUFFICIENT` |
| token claiming ungranted `phi:read` / `mappings:write` | still masked / 403 |
| expired token / unknown `kid` | 401 / 401 |
| 14 forged tokens from 198.51.100.77 | 401 ×10, then 429 `QUOTA_EXCEEDED`; valid token from that address 429, from another 200 |
| per-client quota | 429 `QUOTA_EXCEEDED` at call 300, `Retry-After: 41` |
| artifacts of the killed revenue run | 200, 20 artifacts; signed download of `JE_Revenue_Posted_P07_FY25_QB.csv` = **golden bytes** |
| artifacts of an mx run / start an mx run | 404 `RUN_NOT_FOUND` / 403 `SCOPE_INSUFFICIENT` |
| create a qb-revenue draft run → ask for an upload | 201 → **503 `PERSISTENCE_UNAVAILABLE`** "no object storage for direct uploads" (clean refusal; pre-signed POST needs S3) |

**Webhooks** (receiver `s2p2_receiver.py`, HTTPS 127.0.0.1:8443, verifies with
`src.webhooks.signing.verify` and one replay cache; logs the path per request):

| Check | Result |
|---|---|
| Human, React "Add a webhook" with `https://169.254.169.254/latest` | refused at create: "That address cannot receive webhooks." (screen 32) |
| Human, React "Add a webhook" `…/human` → secret shown once → **Send test** | delivered, 200, **verified** |
| Machine (`webhooks:manage`) subscribe `…/machine` + `/test` via B | 201, 202, delivered, **verified** |
| `run.completed` for the **mx** run `93c2d8ce` | delivered to `/human` only — **nothing for the revenue-only machine client** (F7 fixed; delivery log, screen 40) |
| `run.completed` for the **revenue** run `edf5ca34` (after redelivery) | delivered to `/machine`, verified; to `/human` the receiver answered `replayed_event` (same event id, one shared replay cache → N7), the sender retried, and after a receiver restart the retry at 11:18:58 was **verified** |
| Replay a delivered request byte for byte | 401 `replayed_event` |
| One body byte changed | 401 `signature_mismatch` |
| Same request checked 301 s later | `timestamp_out_of_tolerance` |
| SSRF at subscribe through the proxy: `https://127.0.0.1`, `localhost`, `http://…`, `10.0.0.5`, `169.254.169.254`, `[::1]`, `[::ffff:127.0.0.1]`, `:8443`, `100.64.0.1` | all 422 `WEBHOOK_URL_REJECTED`; machine `https://127.0.0.1/hook` 422 too |

Logs: 72 synthetic identifiers from the inputs searched in both api logs (541 KB): **0 hits**.

### P2.6 Step 5 — gates on `39ef260`

Run with `s2p2-gates.sh` (logs `s2p2-logs/gate-*.log`), `PYTHON_DOTENV_DISABLED=1`.

| Gate | Result |
|---|---|
| `pytest -q` (everything) | **5061 passed, 116 skipped, 0 failed** (5 m 31 s) |
| `*_pg.py`, `MERIDIAN_PG_REQUIRED=1`, `MERIDIAN_TEST_SHUFFLE_SEED=random` | **939 passed, 0 failed**, seed `839701410` |
| `pytest tests/security` | **719 passed** |
| `pytest tests/security --known-bad` | **674 failed, 0 passed** (45 deselected) — every breaker red, as required |
| `pytest infra/tests` | **754 passed** |
| `ruff check .` | All checks passed |
| `lint_no_phi_logging.py`, `lint_processor_purity.py`, `lint_route_ownership.py` | exit 0 each |
| `lint_org_scope.py` | exit 1 with the known backlog list — `continue-on-error` in CI by design; the enforcing ratchet (`tests/test_lint_org_scope_ratchet.py`) passed inside `pytest -q` |
| `web: npm run typecheck` | clean |
| `web: vitest run` | **1273 passed** (106 files) |
| `cdk synth` | not run (D2: no CDK CLI) |

### P2.7 Pass-1 findings, verified

| # | Result | Evidence |
|---|---|---|
| F1 `npm run dev` 500s | **PASS** | `npm run dev` → "Compiled /instrumentation", `/` and `/api/v2/org` 200; the whole pass ran on it; no `UnhandledSchemeError` in `web.log` |
| F2 blank JE date | **PASS** | JE date left empty on every revenue run; 20/20 CSVs byte-identical (the golden has the period-end date) |
| F3 unposted silently skipped | **PASS** | no `mappings.xlsx` anywhere under `MERIDIAN_DATA_DIR`; all 8 `JE_Unposted_*` + the unposted QB CSV produced and identical; incomplete config → blocked `UNPOSTED_CONFIG_UNAVAILABLE`, no batch |
| F4 qb-usa roster/overrides + FILE_UNREADABLE | **PASS** | bootstrap seeds 10 employees + 3 overrides; clean and roster_blocked book from the seed; empty roster → `ROSTER_EMPTY` |
| F5 local storage dead end | **PASS** | results list files on the worker path; per-file and zip downloads work; qb-usa **Book** works; the machine client's signed download works. v3 direct uploads still need S3 (clean 503) |
| F6 approve → 500 | **PASS** | approved in the UI with no injected fake; the app chose the fake itself (logged) |
| F7 webhook events ignore allowed processes | **PASS** | mx `run.completed` reached the human subscription only; revenue reached the machine |
| F8 revenue screen hides DUPLICATE_INPUT | **PASS** | "Duplicate input — These same files were already run on 2026-09-25" on runs `2716269f`, `edf5ca34` |
| F9 MX rate ignored | **PASS** | the field is optional and says a processed workbook does not use it; the processed run with no rate matches the golden |
| F10 stuck sub-stepper | **PASS** | during the wait: "Step 5 of 6: Exporting, current step" next to 95% (screen 35) |
| F11 35× "mappings.xlsx missing" | **PASS** | printed once by the seed |
| F12 empty overrides fall back to JSON | **PASS** | overrides inactive → "no benefit overrides in postgres for P08-2026 …"; no JSON read, no Supabase in the message |
| F13 partial Cognito config → silent bypass | **PASS** | `AUTH_BACKEND=cognito` without `COGNITO_CLIENT_SECRET` (port 5052): the api exits 1 with "Refusing to fall back — nobody would be authenticated." |
| F14 copy | **PASS** (residue → N6) | MX page no longer mentions a period; roster review tie-out says "Tie-out pending"; roster labels "QuickBooks location/department/class" |
| F15 pytest leaves `output/P01_FY26_<stamp>/` | **PASS** | `find output -maxdepth 1` before/after the full `pytest -q`: no new `P01_FY26_<stamp>` folder (the empty `output/` subfolders that do exist come from starting the api → N5) |

### P2.8 New findings

None were fixed (instructions: report only).

**N1 (medium) — An unposted-config block cannot be resolved from the app.**
Repro: set one clinic group's `primary_location_code` (or `hospital_location` where needed) to
NULL; start a revenue run with "Generate the unposted entry too". The API is right
(`blocked`, `UNPOSTED_CONFIG_UNAVAILABLE`, `details.missing = {primary_location_code: [Forest]}`,
no batch). The screen is not:
(a) it says "the groups are listed with this error" but lists nothing — `details.missing` is not
rendered; (b) the same screen says "Every unmapped item has a mapping now … Everything is
mapped. Run it again from where it stopped", which contradicts the block; (c) there is no React
screen and no v2 route that edits a clinic group's `hospital_location` / `primary_location_code`
(`web/src/app/config/collections.ts`: clinic groups are `editable: false`, "no PATCH/DELETE
endpoint exists for clinic groups"; those two fields are not even shown). The only fix is SQL.
Why it matters: the progress log already notes that the Phase 8/9 copy must fill these two
fields for real orgs; any org it misses cannot book unposted revenue until someone edits the
database. Fix before the data copy/cutover.

**N2 (low) — MX new-run page promises a human stop that does not exist.** The footer says
"Nothing is booked by this step. The run stops for a human before any journal entry exists.",
while the header says "No human step" and the run goes straight to Booked.

**N3 (low) — ROSTER_EMPTY reaches the user as a bare code, and the roster has no screen.** The
failed run says only "The run stopped with ROSTER_EMPTY." (plus a request id) — no sentence
saying the qb-usa roster is empty or where to fill it; and there is no React screen for the
qb-usa roster at all (only a run's roster review, "Save this coding permanently").

**N4 (low) — Logs still say "Supabase" on the Postgres stack.** `src.config`
"load_enrichment_config: … from Supabase" and `src.qb_mappings` "load_payroll_maps: loaded 9
accounts, 11 departments from Supabase" on every run (the data came from local Postgres).

**N5 (low) — Starting the api creates `output/{journal_entries,data,reports}` in the repo.**
With `MERIDIAN_DATA_DIR` pointing elsewhere, the worktree still gets an empty `output/` tree
at api start (folder timestamp = api start, 10:50:17 UTC). Likely source: the relative
defaults `"output/journal_entries"` / `"output/data"` / `"output/reports"` in
`src/app_settings.py:24-26` (and the exporters' `output_dir` defaults), which ignore
`MERIDIAN_DATA_DIR`. The run data itself went to `MERIDIAN_DATA_DIR`. Gitignored, so harmless,
but it is the same class as F15 and it is data-in-the-code-folder.

**N6 (low) — Missing-mappings block shows the raw kind name "Qb account map".** Residue of F14.

**N7 (low, design question) — One event id is sent to every subscription.** A `run.completed`
fans out to both subscriptions with the same `Meridian-Event-Id`. A receiver that serves two
subscriptions and follows the documented rule ("rejects anything … seen before") drops the
second as a replay (seen here: `/human` answered 401 `replayed_event` until the receiver was
restarted). Per-subscription event ids, or documenting that the replay key is (subscription,
event id), would remove the trap. This harness has one receiver for both; a partner with two
subscriptions to one endpoint would hit it too.

**N8 (low) — A superseded run's page says "Tie-out pending. Nothing has been computed yet".**
MX run `1bd00fdf` was booked and then superseded; its page shows the "pending / nothing
computed" tie-out card instead of saying the figures belong to the replacing run.

### P2.9 Still not testable locally

| Item | Why |
|---|---|
| Cognito sign-in, MFA enrolment/challenge, invites, federation | no Cognito; `AUTH_BACKEND=disabled`. Machine tokens verified against a laptop-only pool (W8) |
| SES delivery | `EMAIL_BACKEND=disabled` |
| v3 `POST /runs/{id}/uploads` (pre-signed POST) and GuardDuty malware tagging | no S3; the api refuses cleanly (503 `PERSISTENCE_UNAVAILABLE`) |
| Real S3 signed URLs, CloudFront/WAF, mTLS origin header | local disk store signs its own URLs; no edge |
| QuickBooks sandbox push ("Send to QuickBooks") | no Intuit; covered by the fake-QBO pg tests in the gates |
| SQS worker loop, worker image, Docker compose | D5; `JOB_TRANSPORT=inprocess` only |
| Real-data JE parity | D8: synthetic only |
| `cdk synth` | D2 |

### P2.10 Ready for Stage 3?

**Yes.** Nothing found in pass 2 books a wrong or incomplete journal entry, leaks data across
tenants or processes, or blocks a Stage 3 task. Carry into Stage 3 (fix before the Phase 8/9
data copy and cutover, not before Stage 3 starts):

1. **N1** — render `details.missing` on the unposted block, drop the "everything is mapped" line
   there, and give clinic groups' `hospital_location` / `primary_location_code` an edit path
   (screen + v2 route), so a real org the copy misses can be fixed without SQL.
2. The lows N2-N8 whenever convenient (N3's roster screen is the only one that is more than copy).
