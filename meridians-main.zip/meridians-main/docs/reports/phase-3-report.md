# Phase 3 report — Data tier (code complete; staging load gated on approval)

**Date:** 2026-09-16 · **Branch:** `aws-migration` (`b9dd888`) · **Plan:** `docs/aws-migration-plan.md` Phase 3 · **Critic:** data tier PASS at round 2 (`cc485f6`); PHI split + parity PASS at round 3 (`474ca48`) after a critical and a high in rounds 1–2; the round-3 medium and lows are fixed in the following commit.

## What was built

- **Alembic chain 0001–0005** (`migrations/`, ADR 0019): 0001 replays the 37 Supabase files verbatim; 0002 closes the 242 statements of drift measured against the live schema dump in `migrations/baseline/`; 0003 adapts to RDS (`phi` and `audit` schemas, `meridian_app` and `phi_access` roles, `app.current_org_id()`); 0004 forces row-level security on the 63 tenant tables listed in `scripts/tenant_tables.txt` (generated from the schema, read by the org-scope lint); 0005 drops the three identifier columns from `transactions` and makes `patient_ref` mandatory. Proven from an empty PostgreSQL 17 in CI (`migrations` job).
- **Ephemeral-Postgres test fixture** (`tests/pg_fixture.py`, `tests/conftest.py`): a PG 17 container or local server per session at 0003 or head, connections as owner, `meridian_app` and `phi_access`. Cross-org reads as `meridian_app` return zero rows with the `WHERE org_id` removed; `app.org_id` is empty after checkout.
- **`data` stack** (ADR 0020): RDS PostgreSQL 17 single-AZ (D-14), `t4g.micro` staging / `t4g.small` production, encrypted with the RDS CMK, not public, deletion protection in production, 7-day PITR, Performance Insights, pgaudit `ddl,role,write` into a PHI-classified log group, `rds.force_ssl`, `timezone=UTC`, RDS-managed master credential, nightly stop schedule in staging. Three S3 buckets (`artifacts`, `phi`, `audit` with Object Lock), each on its own CMK, TLS-only and KMS-only policies, malware scanning on `phi`. Secrets Manager entries for the app, both DB roles, the PHI HMAC key and origin-verify. AWS Backup: compliance-locked vaults, daily production backups with a `us-west-2` copy, on-demand staging backups.
- **`vpc`/`edge` split** (ADR 0020 §2): the persistent, free `vpc` stack holds subnets so RDS survives staging teardown; everything billable-by-the-hour is in `edge`.
- **`S3StorageManager`** (`src/storage.py`, `STORAGE_BACKEND=s3`): the same five methods and `assert_org_path` choke point, SSE-KMS on every put and a raise (not a warning) when it is refused, presigned downloads as attachments, journal entries to `artifacts` and everything else to `phi`.
- **PHI split** (`scripts/split_phi.{sql,py}`): moves `patient_id`, `claim_no`, `encounter_id` to `phi.transaction_identity`, tokenises `patient_ref` with an HMAC key delivered as a libpq startup option so pgaudit can never write it to a log, records a key fingerprint that refuses a different key without `--rotate`.
- **Parity suite** (`scripts/verify_parity.{sql,py}`): per-table counts, journal-entry sums to the cent by batch, transactions by batch, the payroll gate variance, tie-outs, all sequences, constraint diff, identifier checksum, row checksums, and a global-only null-org-row check that aborts on any non-zero count. Runs at 0003 (global) and at head (per organisation under RLS).
- **JE diff gate** (`scripts/diff_je_output.py`, `docs/je-diff-procedure.md`): content comparison with ids normalised and no allowlist of differences.
- **Runbooks:** `data-load.md` (order: upgrade to 0003 → restore → split → parity → head → parity per org), `migrations.md`, `restore-drill.md`, `rotate-secrets.md`, `db-access.md` (`sslmode=verify-full`), `staging-teardown.md`; `scripts/staging_session.sh` deploys/tears down the transient stacks, drains the stop-schedule dead-letter queue and waits for the on-demand backup.

## Evidence

| Check | Result |
|---|---|
| Backend tests (CI `backend` job) | green at `b9dd888` (all three jobs) |
| Migration chain from empty PG 17 (CI `migrations` job) | green |
| `tests/test_split_phi.py` + `tests/test_verify_parity.py` + `tests/test_migrations.py` | 83 passed |
| Infra tests | 339 passed; synth for both environments without credentials |
| PHI-log lint, ruff, mypy (50 files) | clean |

## Phase 3 Verify list — what is NOT yet run

These are staging checks. They need the cost approval and the PHI-on-AWS confirmation first:

- Step 11 rehearsal load with timings recorded in `docs/runbooks/data-load.md` §Timings.
- Step 13 copy of the ~50 storage objects and `head_object` on every `storage_path`.
- Step 14 restore drill with the elapsed time written down (the first evidenced RTO).
- Step 15 trial-instance teardown (destructive, asks first) and end-of-session staging teardown.
- `SHOW shared_preload_libraries` includes `pgaudit`; a `put-object` without KMS headers fails; `list-recovery-points` shows a locked vault.

## Accepted risk / deferred (tracker)

- `src/database.py` does not yet write `patient_ref`; after 0005 any application insert into `transactions` fails until the Phase 5a repository layer routes identifiers through `src/phi.py`.
- `source_transactions` stays in `public` until Phase 5a, so the PHI quarantine is partial (ADR 0012, dated note).
- `tests/test_run_isolation.py` and `tests/test_pnl_rls_live.py` still run against the fake-Supabase pattern; porting them onto the PG fixture is a Phase 5a item with the data-layer port.
- 21 money columns stay `double precision` and 22 timestamps stay naive until the parity suite is clean on real data (tracker rows).
- The stop-schedule dead-letter alarm was removed because it could not fire for the likeliest fault; `staging_session.sh up` drains the queue by hand until Phase 6 wires an EventBridge Pipe.

## Needs a human

- Cost approval (`docs/reports/phase-1-cost-estimate.md`) — nothing deploys before it.
- Confirmation that PHI may be loaded into the AWS account (BAA active) before step 11.
- Name the two rehearsal periods and the location of their input workbooks (`docs/je-diff-procedure.md`); without them the JE gate does not exist.
- Trial instance teardown (step 15) — ask before deleting.
- `codex login` so the Codex review can run for Phases 0–3.
