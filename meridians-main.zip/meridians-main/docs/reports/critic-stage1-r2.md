# Critic review — Stage 1 exit, round 2

Repo `NS_Proccess_QB`, branch `aws-migration`, HEAD `0bf8e17`, scope `e0cf79b..HEAD` (44 commits, 9 merges,
143 files / +9655 −429 excluding generated openapi, schema.d.ts, python client, goldens). Read-only. Date 2026-09-25.
Round 1: `docs/reports/critic-stage1-r1.md` (HEAD `be3163e`, FAIL: 5 high / 11 medium / 17 low).

## Gates I ran (all local, no network, no AWS)

| Gate | Result |
|---|---|
| `pytest tests/` (CI backend job shape, three migration files excluded) | **4678 passed / 116 skipped / 0 failed** (237 s). `scripts/check_pytest_skips.py` reports the same 116 skips as round 1 (all allow-listed reasons; the local ceiling message is cosmetic — CI sets `MAX_SKIPPED=122`) |
| CI `migrations` job (`MERIDIAN_PG_REQUIRED=1`, real Postgres, non-superuser migrator) | 106 passed → **4784 total**, matches the log's claim |
| `pytest tests/security --known-bad` | **587 failed / 0 passed / 45 deselected** — every control still goes red when its breaker is applied |
| `pytest infra/tests` | **753 passed** |
| `alembic -c migrations/alembic.ini heads` | one head, `0027_api_request_retention`; chain 0023 → 0024 → 0025 → 0026 → 0027 linear |
| All 52 `tests/**/*_pg.py` files in ONE shuffled order (seed 20260925, order saved in `scratchpad/shuffle-order.txt`) | **833 passed / 0 failed** (93 s) — one more manual data point; still no CI enforcement (R2-M9) |
| Secrets scan of every added line (AKIA, PEM, `password=`, long base64, bank numbers) | nothing but test constants; `.env.example` untouched |

Method: five parallel read-only sub-audits (H-1 + v3 kinds; H-2/M-7/M-8 + 0025; H-3/H-4 + leases + 0026;
security mediums + 0027 + AEAD + logging; H-5 + input-prep race + docs), each report spot-checked by me against
code before anything below was written. Where I disagreed with a sub-auditor I say so.

---

## Round-1 findings — verdicts

### HIGH

| # | Verdict | Evidence |
|---|---|---|
| **H-1** revenue/payroll silent hardcoded maps | **PARTIAL** — core fixed, one table short + one consumer missed (see R2-H1 below) | `src/processes/qb_revenue/processor.py:91-127` `org_qb_maps` raises `ProcessInputError(QB_MAPPINGS_UNAVAILABLE)` when `source=="hardcoded"` on Postgres, before `create_batch_superseding` (:438-445, :752-760); blocked state carries `blocked_code`/`qb_maps_source` (:1232-1249), envelope `src/api/v2/oneshot_runs.py:519-525`. mx: `src/processes/mx_payroll/processor.py:55-77` → `failed` with `error_code`. Local seed fills the six `qb_*_map` tables through the v3 creators (`scripts/seed_local_dev.py:246-251`). Golden proof is real, not vacuous: `tests/test_qb_revenue_maps_source_pg.py:173-219` seeds, runs `handle_job`, byte-compares to the goldens, then mutates one `qb_clinic_map` row and sees exactly that cell change; known-bad control :236-254. `tests/test_pnl_facts.py:239-264` no longer enshrines the fallback. 11 + 12 + 57 + 20 tests pass. |
| **H-2** webhook fakes in production, no drainer | **RESOLVED** (api) | `api/main.py:255-263` `create_app` calls `webhook_ports.check_configuration()` whenever `api_v3_enabled()`; refusal outside `dev_fallbacks_permitted()` (`src/webhooks/ports.py:454-474`); Lambda gets `APP_ENV=production` (`infra/meridian/stacks/api.py:365-366`); CDK now sets `MERIDIAN_API_V3=1` ONLY inside `_api_platform_environment` with the four webhook vars (`compute.py:1069`), pinned by `infra/tests/test_api_platform.py:565-604`. Local path: `src/webhooks/local.py` — FakeQueue drainer thread through the same `engine.handle` (SSRF guard, tenant re-check, signing identical), sealed secrets in `public.webhook_local_secrets` (0025:108-124, FORCE RLS, AAD `{purpose, org_id, ref}`), dev key refused outside dev twice. End-to-end proof: `tests/security/test_webhook_local_delivery.py:164-211` (HTTP app + real drainer + restart survival). 33 tests pass. Residuals → R2-M1, R2-L1..L4. |
| **H-3** RDS push bypasses ledger when unrouted | **RESOLVED** | `src/api/v2/qb_usa_runs.py:2026-2034`: legacy `push_batch_to_qbo` reachable only when `not jobs_routed AND not database_is_postgres`; RDS unrouted → `_push_through_ledger` (:1940-1987) → `push_batch_once`. Every `create_journal_entry` caller on Postgres goes through `post_journal_once` (`src/qbo_posting.py:248`; `scripts/qbo_post_je.py:180-196` when `database_is_postgres`). `str(exc)` gone from the RDS response (:1961-1986, code + fixed sentence). Ordering test is genuine: `tests/test_qbo_push_job_pg.py:685-724` snapshots the ledger row AT the fake create and asserts `pending`; known-bad control :737-756 restores the legacy path and sees `None`. Supabase path unchanged (still returns/logs Intuit's body — pre-existing, tracker T:195). |
| **H-4** concurrent push resends; no lease re-check | **RESOLVED** | `src/idempotency.py:191-199, 400-403` `_TAKE_PENDING` takes a `pending` row only when `updated_at <= now() - IN_FLIGHT_SECONDS` else `Claim("in_flight")`; `IN_FLIGHT_SECONDS = 600` (`qbo_posting.py:79`) pinned to the qbo_push job timeout (`test_qbo_push_concurrency_pg.py:376`); `_renew` re-stamps just before the create (:244); `in_flight` writes nothing (no re-arming → no permanent lock); same requestid kept across attempts; lookup-before-resend for expired-window rows (:218). `still_mine` (`keep_alive` + re-read `quickbooks_push.job_id`) runs at the top of EVERY journal iteration (`src/qb_usa_payroll_quickbooks.py:285-286`). Heartbeat DB error now returns False → `LEASE_LOST` stop before the next QBO call (`workers/run_job.py:774-788`). 11 concurrency tests pass. Residual → R2-M3. |
| **H-5** order-dependent gate | **RESOLVED (isolation), PARTIAL (CI ask)** | `tests/worker_support.py:146-178` `quiesce_redeliverable` settles leftover cross-org jobs in the `world` fixtures; `Handler(org=…)` routes foreign calls to `handler.foreign` (`test_job_redelivery_history_pg.py:65-87`, known-bad control :230-266). Reproduced green: r1's failing order 61/0, reverse 61/0, three heavy files prepended 121/0, and my own 52-file shuffle (below). NOT done: random order in CI — no `pytest-randomly`/`xdist` in the venv, workflows run plain `pytest tests/` (`.github/workflows/backend.yml:126`); the "5 orders" is a manual one-off, not a gate → R2-M9. |

### MEDIUM (round 1)

| # | Verdict | Evidence |
|---|---|---|
| M-1 LocalStorageManager confinement | **RESOLVED** | `src/storage.py:170-236` roots at `{base}/{org}`, `assert_org_path` first-segment compare (`:58-61`, `org1x` ≠ `org1`), `_confined()` resolves symlinks and requires root ∈ parents (:181-187), `_segment()` forbids `/ \ NUL . ..`. 13 tests. Low residual: `upload_output_file` confines the dir, not the final file (:201-204). Note: publish/download/qb-usa still refuse local storage (`src/processes/shared.py:159,231`, `oneshot_runs.py:1364-1373`, `qb_usa_payroll/processor.py:184`) so Stage 2 never exercises this end to end — recorded in the log, fine. |
| M-2 qb-usa job revalidation | **RESOLVED** | `src/processes/qb_usa_payroll/processor.py:717-718`; `tests/test_job_path_revalidates_inputs.py` 7 pass. |
| M-3 redaction of runtime secrets / extras | **RESOLVED** (two lows) | `src/log_safe.py:252-278` bounded registry (1024, versioned, locked); `_clean_extra` recurses to depth 6 (:284-313); registered at every entry: webhook secrets (`signing.py:59, 98-103`), QBO tokens (`qbo_token_crypto.py:319-360`). Lows: Cognito client secret only via the env snapshot; base64/URL-encoded forms unregistered; bytes that fail UTF-8 dropped (KMS DEKs never appear as text — acceptable). |
| M-4 modules fail open | **RESOLVED on Postgres/v3 by D20** | `src/auth.py:1815-1838` → `set()` on Postgres; `api/v3/access.py:48-50` machines fail closed on every backend; v3 HUMANS on Supabase still fail open (exactly what D20 says, no more). UX consequence → R2-M6. |
| M-5 quotas/lockout fail open | **RESOLVED by D21** | `api/v3/quotas.py:272-277` peek failure → 503 before any auth (no bypass window); `record_auth_failure`/`cap` fall back to `LocalQuotaStore` (:213, 314-353); Postgres counts survive the outage so lockout is not reset. Lows → R2-L8, R2-L9. SPOF consequence → R2-M7. |
| M-6 self-approval | **RESOLVED by D22** | `src/api_clients.py:219-228`: pinned constant wins, else `app_env() in DEV_ENVS`; `FLASK_ENV=testing` refuses (pinned test); both approve sites check (:728, :871); audited (:746). Still needs-a-human #3 (a second superadmin). |
| M-7 unbounded redrive | **RESOLVED for redrive** | Postgres-side per-delivery cap 3 / 7 days re-checked inside the reopening UPDATE (`src/webhooks/subscriptions.py:367-387`), 20/h per (org, subscription) via `quotas.cap` → `PgQuotaStore` (`api/v3/routers/webhooks.py:397-402`). The INTENT ("Meridian re-POSTs at a third party unbounded") survives through `/test` → R2-M2. |
| M-8 no due-delivery sweep | **RESOLVED** | 0025 `app.due_webhook_deliveries(grace, limit)` SECURITY DEFINER, `search_path` pinned, bounds enforced in-body, PUBLIC revoked, EXECUTE to `meridian_app` only, owner `meridian_job_control` with column-level SELECT on ids only (0025:85-177); partial index on `(COALESCE(next_attempt_at, created_at), id) WHERE status IN ('pending','failed')` and an EXPLAIN test; list-only (the claim stays the conditional UPDATE in `engine.process_delivery:441-457`, paused/revoked subscriptions dropped by `tenant_check:347-363`); swept from the worker 5-min tick (`workers/outbox_sweep.py:69-104`) and by the local drainer every 30 s (`local.py:255-267`). Lease 60 s + Lambda 60 s + grace 300 s → a live attempt is never swept concurrently. 11 migration tests pass. |
| M-9 shared `meridian_app` role | **OPEN, tracked** | Tracker T:175 (Stage 3, "before H4"), ADR 0048:64-70. Row text still frames it as optional — R2-L15. Stays on needs-a-human. |
| M-10 QBO env on AWS | **RESOLVED by D24** | `compute.py:452-460` Secrets Manager `meridian-<env>/qbo-oauth` when `worker_enabled`; JSON keys → `QBO_CLIENT_ID/SECRET` for api (:878-893) and worker (`worker.py:617-618`); execution-role `GetSecretValue` scoped to that ARN (:689-695); `QBO_ENVIRONMENT` production iff env is production, redirect URI from the public hostname (:895-903). Synth pins `infra/tests/test_worker.py:1024-1039` (never plain env). `worker_enabled=False` → `INTEGRATION_NOT_CONFIGURED` naming the missing vars, not 503 (`qbo_connection.py:227-233`). |
| M-11 ALB-log evidence that does not exist | **RESOLVED** (sub-auditor said not done; I disagree) | `docs/reports/phase-11-plan.md:556` G2 row, deviation (1): "the evidence is grep only, as decided", citing Andres's 2026-09-22 yes, and :177. Low: the row's criterion column still reads "grep **and** 30 days of ALB access logs" and :686 still recommends ALB logs → R2-L16. |

### LOW (round 1)

| # | Verdict | Evidence |
|---|---|---|
| L-1 hand-rolled AEAD | **RESOLVED (D26)** | `src/aead.py` AES-256-GCM, `os.urandom` 12-byte nonce, 32-byte key enforced, mandatory AAD; challenge key = HMAC(handle, fixed label) — NOT the QBO dev key (`auth_routes.py:434-476`); `qbo_token_crypto` delegates (:66-135); no other cipher in `src/` or `api/`. 13 tests. |
| L-2 `local_plugins` import | **RESOLVED** | `src/processes/__init__.py:213-219` `is_production()` guard; 5 tests. Info: unset `APP_ENV`+`FLASK_ENV` is "not production" — consistent with `settings.py`. |
| L-3 cp1252 / `csv_not_text` | **RESOLVED (documented + pinned)** | `src/file_signature.py:43-52`, `tests/test_file_signature.py`. |
| L-4 shared-egress lockout | **Trade-off recorded (D21)**, exemption needs verified token + allowlist match (`api/v3/deps.py:136-147, 185-189`) | low residual R2-L10 (`0.0.0.0/0` accepted as allowlist). |
| L-5 0023 downgrade guard untested | **RESOLVED** | Guard rewritten (RLS hid the rows — it never fired), `tests/test_qbo_token_sealed_downgrade_pg.py` 1 real test with sealed rows. |
| L-6 MAX_ATTEMPTS duplicated | **RESOLVED** | `tests/test_max_attempts_pinned.py` reads all 7 copies (4 migrations, transport, `PUSH_MAX_ATTEMPTS`, infra `JOBS_MAX_RECEIVES` by AST) and pins 3. |
| L-7 false 0011 comment | **RESOLVED** | 0026 `LEASE_OWNER_COMMENT` (:177-182), asserted `test_claim_boundary_sweep_index_pg.py:116-125`. |
| L-8 abandoned-wizard sweep index | **RESOLVED** | 0026 `idx_process_runs_state_expiry (state, expires_at)`, generic-plan EXPLAIN test :97-113. |
| L-9 `audit.api_request` retention | **RESOLVED (0027, D23)** | Definer `app.prune_api_request_audit`, owner `meridian_job_control`, `search_path` pinned, EXECUTE to `meridian_app` only (0027:154-158); prune bound = `least(now()-400d, exported_through)` from singleton `audit.api_request_export`, no row → 0 rows deleted; the INSERT-only trigger's exception is `current_user = 'meridian_job_control' AND OLD.at < now()-400d AND OLD.at <= exported_through` (:99-105) — no GUC, the app role has no membership in the control role (0011:414 grants only the migrator, `INHERIT FALSE`), so the app cannot tamper; the app role also cannot advance the watermark (:86). Scheduled from `workers/sweep.py:116-127` with limit 5000. Downgrade restores 0013's trigger. 14 tests. Info: no role yet has INSERT on `audit.api_request_export` — the Stage 3 export must add its grant or the prune never fires (R2-L17). |
| L-10 fence inconsistency | **RESOLVED** | `run_job.LIVE_LEASE` (:269) used by `_fenced` (:292-293) and verbatim in `process_state._RECORD_SQL` (:331-336); pinned `test_worker_loop_pg.py:539-540`. |
| L-11 heartbeat True on DB error | **RESOLVED** | see H-4. |
| L-12 same-microsecond `busy` | **RESOLVED** | 0026 `<=` in both claim functions (:114, :170), bodies otherwise byte-equal to 0011/0018 (test :128-139), same-instant test :82-86, known-bad downgrade control. Low residual: `begin_action` still `<` against `_release`'s `= now()` → a retryable 409, not a stall (R2-L11). |
| L-13 cancel leaves lease | **RESOLVED** | `process_runs.LEASE_VOID_STATES` (:69), `_announced` NULLs owner/expiry under `FOR UPDATE` (:579-590); 4 tests. |
| L-14 ADR gaps | **RESOLVED** | ADRs 0045-0049 exist with Status, indexed `docs/adr/README.md:71-75`; one code claim per ADR spot-checked true. Low: line cites already drifted in all five (R2-L18). ADR 0038 itself NOT updated for the 0025 sweep/local store (decision lives in the 0025 docstring and `ports.py` header) — R2-L19. |
| L-15 version/CHANGELOG | **PARTIAL, not blocking** | CHANGELOG "Unreleased" covers the wave; 2.0.0-at-merge proposal recorded only in the plan log (:183); `web/package.json` still 1.0.1; CHANGELOG.md:31 is a garbled sentence. |
| L-16 unflagged JSON logs | **PARTIAL — the fix introduced a redaction gap** | see R2-M5. |
| L-17 stale T:86 cite | **RESOLVED** | `local-first-plan-2026-09-24.md:76` now cites T:209 and explains the renumbering. |

---

## NEW / RESIDUAL findings (round 2)

### CRITICAL — none

### HIGH

#### R2-H1 · H-1 is one table short: a Postgres org with *partial* QB maps still gets a silent wrong QuickBooks JE, and the P&L roster still reads hardcoded maps
- The guard refuses only when `accounts` / `clinic` / `provider` (revenue, `src/qb_revenue_mappings.py:227`) or `accounts` / `departments` (payroll, `src/qb_mappings.py:230`) are EMPTY. `qb_other_code_map`, `qb_payer_label_map`, `qb_department_map` (revenue) and a partially filled `qb_account_map` (payroll) pass the guard with `qb_maps_source == "postgres"` on the envelope.
- mx payroll: the QB export is wrapped in `except Exception: logger.exception(...)` and unmapped accounts/classes are "left as raw NetSuite values" with only a `logger.warning` (`src/processes/mx_payroll/processor.py:381-405`); `qb_files["unmapped_accounts"]` never reaches the results envelope (grep: only those four lines). A Postgres org whose `qb_account_map` misses one row gets a **completed** run whose QuickBooks CSV carries NetSuite account numbers in the QB account column — or no QB CSV at all if the exporter raised — and the UI says success. This is the exact failure mode H-1 named (silent wrong JE, no signal to the user), reached from a different table.
- Revenue: `src/revenue_qb_exporter.py:142` `map_provider(..., self.m["other_code"])` and `:181` `self.m["other_code"][service_line]` raise `KeyError` on an empty `qb_other_code_map` for every provider not in `qb_provider_map` → `EXPORT_FAILED` *after* `import_batches` exists (the "recorded failure" the UI warns about). Not silent, but a fail-late where the guard could have refused.
- `src/pnl_facts.py:194-196` (`pnl_roster`) and `:446-448` (`revenue_provider_facts`) call `load_revenue_maps` with no source check; on Postgres with empty/unreadable `qb_*_map` the provider P&L roster served by `/api/v2` (`config_routes.py:790`, `pnl_routes.py:236, 289`) and the P&L facts come from the defaults (`config/provider_maps.json` if present on that host, else the redacted example — either way not the org's data), silently. Same class as H-1; `tests/test_pnl_facts.py:239-264` now monkeypatches the loader to "postgres" so the test passes without production refusing.
- Also same class, out of H-1's literal scope, flagged for the same fix: `ts_benefit_override` read failure on qb-usa falls through to `{}` with `source="code"` and the run completes with "raw carrier matches only — the accountant totals will NOT tie" (`src/qb_usa_payroll_maps.py:271-341`, their own comment :228-233; `maps_source` is on the result at `qb_usa_payroll/processor.py:367` but nothing refuses `"code"` on Postgres); `load_mx_column_map` (`src/payroll_processor.py:500-523`) silent hardcoded fallback for the NetSuite JE; `payroll_processor.qb_to_ns_departments` (:344-348) / `reload_column_map` (:554-559) still fall back — masked in mx only because :186 re-assigns afterwards.
- Fix: (1) the "required" set in both loaders must be every table the exporter indexes (`other_code`, `payer` for revenue; full coverage check for payroll: refuse when the export would leave an unmapped account/class, or at minimum surface `unmapped_*` on the envelope and mark the run `blocked`/`failed`, never `completed`); (2) `pnl_facts` and the qb-usa `ts_benefit_override` reader refuse `hardcoded`/`code` on Postgres like the processors do; (3) a test that a Postgres org with `qb_account_map` missing one row does NOT complete an mx run.
- Severity: HIGH — it is the finding H-1 was, on the target backend, with a completed run and a clean envelope. Not a double-post; a wrong post.

### MEDIUM (10)

- **R2-M1** Worker has no fail-closed webhook configuration check. `src/webhooks/outbox.py:161-165` `publisher_from_env` → `None` without `WEBHOOK_EVENT_BUS`; `ports.py:519-523` `webhook_queue_from_env` → `None` without `WEBHOOK_QUEUE_URL`; `workers/outbox_sweep.py:90-92` then only COUNTS due deliveries. A deployed worker missing one variable silently never publishes or re-enqueues; the api refuses to boot in the same situation. CDK couples the vars (`worker.py:599-604`) but the runtime does not. Fix: the same `check_configuration()` in `workers/main.py` when `sweep_enabled()`.
- **R2-M2** `/test` ping is unbounded per subscription (`api/v3/routers/webhooks.py:334-352`): a `webhooks:manage` client can direct ~300 signed POSTs/min (× up to 8 retries on 5xx) at any public URL and create more subscriptions to the same URL. Redrive is capped; the M-7 intent ("Meridian as a signed request cannon") is not met until `/test` gets the same `quotas.cap` per (org, subscription).
- **R2-M3** False 600 s hold after a lookup failure on a never-sent journal. `src/qbo_posting.py:196-222`: `begin` stamps `updated_at` for a `new` or taken row; if `lookup` then raises, the row stays `pending` with a fresh stamp and the caller gets `QBO_UNAVAILABLE` ("try again later"); every press within 10 min then answers `QBO_IN_FLIGHT` ("another send may still be running") for a journal nothing ever sent. Same for `JOURNAL_NOT_BUILT` on a taken `pending` row (:237). Not a double-post risk; a misleading-message / 10-minute availability regression versus pre-fix. Fix: on `claim.outcome == "new"` a lookup failure can settle `failed` (nothing was ever sent under that requestid); on `pending` say so honestly.
- **R2-M4** Revenue `blocked` screen contradicts itself and has no way out. `web/src/components/screens/mapping-fix-screen.tsx:139-146` renders "Every unmapped item has a mapping now… Run it again from where it stopped" (`screens.ts:497-500`) under the notice that the org has NO QuickBooks mappings; there is no React screen that writes `qb-*` rows (grep `qb-accounts|qb-clinics|qb-departments` in `web/src` → only `schema.d.ts`), only `/api/v3/mappings/qb-*` for machine clients; `qb_maps_source` is rendered nowhere. "Maps source shown" is API-only. A human hitting this block cannot fix it in the product. mx: `failed` is terminal (no `supports_retry`), user re-uploads — acceptable, but the English `_MAPS_REFUSED` sentence has no i18n key (Spanish users get English).
- **R2-M5** L-16's fix ties REDACTION to the JSON-format flag. `configure_logging` is the only thing that installs `RedactingFilter` (`src/log_setup.py:258-262` `build_handler`), suppresses `uvicorn.access` (raw path + query) and pins botocore to INFO; `api/main.py:371-372` calls it only when `json_logging_enabled()`; unset + Supabase → off; `tests/test_json_logs_gate.py:49` pins "leaves Render logging alone"; `render.yaml` sets no `MERIDIAN_JSON_LOGS`. So the aws→main merge ships the redaction filter to Render switched OFF. Not a regression versus `main` (which has no `log_setup.py`), but a regression versus `e0cf79b` and an odd security posture: the format may be optional, redaction should not be. Fix: gate the formatter only; always install the filter and the access-log suppression. Either that or set `MERIDIAN_JSON_LOGS=1` in `render.yaml` in the merge commit (Andres's D25 revisit trigger).
- **R2-M6** D20 on Postgres turns a transient RDS error into an empty menu and 404s for every human in the org for that request, with only a log line (`src/auth.py:1815-1821`): no 503, no UI signal, no named event in `log_setup.EVENTS`. Accepted by D20's revisit trigger; recording it as a live ops/UX risk to watch at Stage 2/3 (a flaky pool reads as "all my modules vanished").
- **R2-M7** D21 makes `api_quota_window` a single point of failure for the whole `/api/v3`: `auth_gate` peek failure → 503 for every bearer request, human or machine (`api/v3/quotas.py:272-277`), even though only a trivial read failed. Accepted by D21; recording it as the trade-off it is (lock/bloat/vacuum on one small table takes the partner API down).
- **R2-M8** Pre-existing, still live on today's Render production: the Supabase push path returns and logs Intuit's response body (`src/api/v2/qb_usa_runs.py:2036` `str(exc)`, `src/qb_usa_payroll_quickbooks.py:199, 206`; `QboHttpError.__str__` embeds `resp.text[:400]`). Tracker T:195. Nothing in this wave touches it; it is one line to fix on the branch that is about to merge to `main`.
- **R2-M9** The H-5 "any order" claim is a manual one-off: no random-order plugin in the venv, `.github/workflows/backend.yml:126` and `deploy.yml:215` run plain `pytest`. The critic's ask ("run the pg suites once with random order in CI") is neither done nor recorded as declined; CHANGELOG.md:14-15 and the tracker read as if it were a gate. My own shuffled run (below) is one more data point, not a gate either.
- **R2-M10** The sandbox/local seed ships the client's real QuickBooks account paths and clinic names as "synthetic" (`scripts/seed_sandbox_org.py:86-188`, e.g. the `41001 TOTAL FEE FOR SERVICE REVENUE:…` paths and `OBG <clinic>` names): by construction it is the subset of Stella Mattina's chart of accounts the synthetic inputs touch, because the goldens were captured from the hardcoded defaults. The `"mattina" not in bodies` test passes only because the strings do not contain that word. This is D9 (open) in code form — needs Andres, not a code fix.

### LOW (20)

- **R2-L1** Drainer starts only from `api.main.__getattr__("app")` (`api/main.py:384-386`), not `create_app`: `--factory create_app`, `web_app.py` and tests get an undrained FakeQueue and no dev-key boot check (`subs.create` 500s on `require_wrapper`, `local.py:105-111`). Documented launch is `uvicorn api.main:app`; still, put it in `create_app`.
- **R2-L2** No drainer shutdown hook (no lifespan/atexit); the daemon thread dies mid-send on exit; 60 s lease + sweep recovers (`local.py:298-305`).
- **R2-L3** Dev-key rotation has no re-seal for `webhook_local_secrets`; secrets silently read as missing → `SECRET_UNAVAILABLE` drops (`local.py:130-143`). Bootstrap preserves the key (`local_db_bootstrap.sh:196-214`), which mitigates.
- **R2-L4** Laptop with `QBO_TOKEN_KMS_KEY_ARN` set: `require_wrapper` returns the KMS wrapper (`qbo_token_crypto.py:230-232`) whose grant is conditioned on `purpose=qbo-token`; sealing with `purpose=webhook-secret` fails → uncaught `TokenKeyUnavailable` → 500 in `subs.create`.
- **R2-L5** `SealedSecretStore` trusts the org embedded in the ref string rather than a session org (`local.py:145-151, 179-192`); unreachable with attacker input today (refs come only from `webhook_subscriptions.secret_arn` under the owner's org). Design smell.
- **R2-L6** Redriven rows are "due since creation": redrive sets `next_attempt_at = NULL` (`subscriptions.py:380-381`) and 0025 uses `COALESCE(next_attempt_at, created_at)`, so every sweep tick re-enqueues a duplicate message until the row is claimed. Harmless (conditional claim), noisy.
- **R2-L7** `_complete` can raise `IdempotencyStateError` if another attempt took and rotated the row (>600 s later); it is not in `_DATABASE_ERRORS`, so the job/API reports failure although the entry WAS created; self-heals via lookup on the next attempt (`qbo_posting.py:224, 257`).
- **R2-L8** `LocalQuotaStore.hit` eviction (`api/v3/quotas.py:197-198`) keeps only windows whose start equals the current bucket's window start, dropping live counts of other window sizes when >10 000 keys — weakens the outage fallback under pressure.
- **R2-L9** A locked address now runs full JWT verification + DB lookup before its 429 (`api/v3/deps.py:181`); lockout no longer saves the verification work.
- **R2-L10** `0.0.0.0/0` / `::/0` accepted as an IP allowlist (`src/api_clients.py:464-468`), making the L-4 exemption vacuous for that client (self-inflicted by the org admin; refuse or warn).
- **R2-L11** `process_runs.begin_action` still `lease_expires_at < now()` (:649) against `_release`'s `= now()` (`run_job.py:327`) → same-microsecond 409 `RUN_STATE_CHANGED` (retryable, not a stall).
- **R2-L12** `upload_output_file` confines the directory, not the final file (`src/storage.py:201-204`); a pre-existing symlink named as the filename is followed by `write_bytes` (needs prior FS access).
- **R2-L13** Crash-leaked per-pin scratch dirs: `tempfile.mkdtemp(prefix=f"{run}.pin-", dir=<tmp>/meridian-inputs/<org>)` (`src/process_inputs.py:565-580`), removed in `finally` (`process_api.py:445`) but not on SIGKILL/OOM; they hold the full uploaded (PHI-bearing) bytes and no startup/periodic sweep of `meridian-inputs` exists (grep). Dies with the Fargate ephemeral disk; not attacker-triggerable. Add a sweep on worker/api start.
- **R2-L14** v3 mapping kinds: DB `UNIQUE(org_id, key)` violation on a concurrent exact duplicate is caught by the broad `except Exception` → 503 `PERSISTENCE_UNAVAILABLE` instead of 409 `MAPPING_EXISTS` (`config_routes.py:745-753`); app `_key_taken` is case-insensitive but the constraint is not (case-variant duplicates land); `_require_postgres` → 503 for a permanent condition (:223-229); `QbClinicPatch.service_line: null` → NOT NULL violation → 503 not 422. Object-level authz, scopes, `extra="forbid"`, RLS, SQL binding all verified clean.
- **R2-L15** Tracker T:175 (M-9) still reads "worth doing if a reviewer wants…"; not updated with the r1 "hard pre-production item" verdict.
- **R2-L16** `phase-11-plan.md:556` G2 criterion column and :686 still cite "30 days of ALB access logs" although deviation (1) in the same row records grep-only; `docs/migration-tracker.md:265-266` carries two contradictory summary lines (205/85/96 vs 203/82/97).
- **R2-L17** 0027: no role has INSERT on `audit.api_request_export` (:86); the Stage 3 export needs a grant or the prune never fires. Put it on the tracker row now.
- **R2-L18** ADR 0045-0049 line cites already drifted (0045 `run_job.py:580-586` → 609-614; 0047 `idempotency.py:166` → 184; 0048 `run_job.py:216` → 224, `api/main.py:367` → 379; 0049 four cites). Cite symbols, not lines.
- **R2-L19** ADR 0038 not updated for 0025 (`due_webhook_deliveries`, local sealed store, redrive bounds); the record lives in the 0025 docstring and `ports.py` header.
- **R2-L20** `QB_MAPPINGS_UNAVAILABLE` string literal duplicated in `errors.py:80` and both processors instead of imported; `MAX_LEASE_SECONDS`/`POST_COMPLETION` constants in 0026 unpinned (the 0011/0018 bodies are byte-compared, so low).

### INFO (not counted)
- `webhook_local_secrets` is in `scripts/tenant_tables.txt` and `pg_store.TABLES` gained the six `qb_*_map` tables (allowlist, so the lint covers them).
- Stale pre-fix `pending` ledger rows are older than 600 s and are simply taken and reconciled (lookup first) — no lock-in on deploy.
- Ledger row lock and `process_runs` row lock are never held in the same transaction; no connection is held across the Intuit call — no deadlock path.
- No PHI in webhook payloads (ids only), none in the new log lines (counts/class names/fixed codes); no SQL string interpolation of runtime values anywhere in the diff.
- `superadmin.py` comments updated for D20 (console still uses `_fetch_org_modules`, correct).
- `web/src/lib/api/v3/schema.d.ts` regenerated with the six kinds; `tests/test_openapi_matches_routes.py` guards drift (I did not re-run `generate_openapi.py --check`; the full suite includes that test and passed).

---

## Verified clean this round (in addition to round 1's list)

0025/0026/0027 definer functions (owner, secdef, `search_path`, PUBLIC revoked, single-role EXECUTE, column-level
grants, bounded limits, downgrade order, `CREATE OR REPLACE` preserving owner/secdef); INHERIT FALSE memberships
untouched; 0027 trigger exception role-gated with no GUC and no app-role path; local sealed store AAD binds
purpose+org+ref, dev key refused outside dev, fresh DEK per write; `aead.py` correct primitives and no key reuse
across purposes; QBO env via Secrets Manager for api AND worker with IAM scoped to the ARN; infra coupling of
`MERIDIAN_API_V3` to the platform vars pinned; ledger-before-create ordering test with known-bad control; in-flight
window not re-armed by refused attempts; `still_mine` before every journal; heartbeat failure stops before the
next QBO call; fence predicate shared verbatim; cancel voids the lease; per-pin scratch dirs 0700, UUID-only path
components; `pin_inputs` single conditional UPDATE + `fail_unpinned_draft` under `FOR UPDATE`; v3 kinds
org-scoped on every statement with RLS beneath, strict schemas, keyset pagination; seeds validated through the
same creators; storage confinement resolves symlinks and compares the first segment exactly; self-approval
refused in testing/staging/production; quota fallback never resets Postgres lockout state; secret registry
bounded and locked; goldens byte-identical from DB maps with a mutation proof.

---

## Verdict — Stage 1 exit: **FAIL** (one unresolved HIGH)

Four of the five round-1 highs are resolved with real tests and known-bad controls (H-2, H-3, H-4; H-5 in
isolation terms). **H-1 is PARTIAL:** the refusal covers three of the six revenue tables and two of the payroll
tables, the mx QB export still completes with raw NetSuite values (or no QB CSV) on a partial map with nothing on
the envelope, and `pnl_facts` still consumes the hardcoded maps on Postgres. That is the silent-wrong-JE failure
H-1 described, reached from a different table (R2-H1). Zero critical. Ten medium (three of them accepted
trade-offs D20/D21 recorded for the stage report, one pre-existing Render leak, one needs-Andres data question),
twenty low.

Fix R2-H1 (and, while in the same files, R2-M1/M2/M3/M5 — each is small), re-run the gates, and I will review
the delta only.

## Needs-a-human (for the stage report)

1. **D9 / R2-M10:** the local + sandbox seed carries the client's real QuickBooks account paths and clinic
   names. Decide: acceptable as "not PHI, not secret" in a tracked repo, or replace with invented paths and
   recapture the goldens.
2. **D22:** production needs a second superadmin to approve API clients (self-approval now refuses outside
   development). Until one exists, either pin `SELF_APPROVAL_ALLOWED = True` in a reviewed commit or accept
   that no client can be approved in production.
3. **D25 / R2-M5:** decide whether Render gets `MERIDIAN_JSON_LOGS=1` at the merge, or (my recommendation) the
   code is changed so redaction is unconditional and only the format is flagged.
4. **D20 / D21 trade-offs (R2-M6, R2-M7):** empty menu on a transient RDS error; whole-v3 503 when
   `api_quota_window` is unreadable. Both are documented; confirm you want them as-is for Stage 2/3.
5. **Redrive bounds** 3 / 7 days / 20 per hour (log entry 2026-09-25) — still awaiting your OK; `/test` will
   need a bound too (R2-M2).
6. **mx refusal UX:** `failed` (terminal, re-upload) vs a real `blocked` + retry as revenue has (log entry
   2026-09-25). And R2-M4: there is no in-app screen to enter `qb-*` mappings — until one exists a Postgres
   org can only be seeded by an API client or the seed script.
7. **Create `meridian-<env>/qbo-oauth`** (JSON `client_id`/`client_secret`) in Secrets Manager before the first
   `worker_enabled` deploy; register the production redirect URI with Intuit (D18, D24).
8. **Local env:** regenerate `.env` via `scripts/local_db_bootstrap.sh` — `MERIDIAN_DEV_QBO_TOKEN_KEY` is now
   required whenever `MERIDIAN_API_V3=1` (webhook sealed store).
9. Still open from round 1: D6, D10-D17, D19; Docker Desktop off (compose + worker image unproven); tracker
   T:175 `meridian_worker` login role before production (M-9); real-data JE parity on the encrypted volume (D8);
   BAAs, written policies, pen test, auditor, signatures; the aws→main version bump (2.0.0 proposed).
10. **Random order in CI (R2-M9):** approve adding `pytest-randomly` (a new dependency — asking per CLAUDE.md)
    or an equivalent shuffle step to the backend workflow; otherwise record the decision not to.
