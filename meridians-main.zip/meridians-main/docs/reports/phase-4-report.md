# Phase 4 report — Auth on Cognito (code complete; staging verification and Flip 1 gated on approval)

**Date:** 2026-09-16 · **Branch:** `aws-migration` (`cc8f0d1`) · **Plan:** `docs/aws-migration-plan.md` Phase 4 steps 1–8 · **Critic:** round 1 FAIL (1 high), round 2 FAIL (1 critical, 4 high), round 3 FAIL (2 high), **round 4 PASS** (`2648d0f`); the round-4 mediums and lows are fixed in the following commit.

## What was built

- **`user_profiles`** (revision 0006): name, avatar, language and dashboard preferences move out of Supabase Auth metadata into Postgres, with a one-time backfill that runs only where `auth.users` exists. Own-row policies under RLS, superadmin read. `src/auth.py` reads and writes it when Cognito is the identity provider.
- **ADR 0021** supersedes contract §0/§6: HttpOnly cookie plus CSRF double-submit for the browser, Bearer for machines, dual issuer acceptance during the window with an `AUTH_ACCEPT_SUPABASE_TOKENS` off switch for Phase 10, `custom:app_uid` so no application row is ever rewritten, ID token 60 minutes, refresh 30 days, machine tokens 15 minutes, local JWKS verification only.
- **`auth` stack**: one pool per environment, email as username, `custom:app_uid` immutable, MFA ON with TOTP only, Plus tier with threat protection in AUDIT, deletion protection, email through the shared SES identity, confidential web client, client-credentials machine client with a resource server, per-environment callback URLs, Google and Microsoft providers behind separate create and enable flags so federated users can be linked before sign-in opens, and the User Migration trigger on a Lambda with an explicit role scoped to its own log group and one legacy secret.
- **`src/cognito.py`**: sign-in with `SECRET_HASH`, MFA challenge, refresh keyed on the pool username, forgot and confirm password, TOTP enrolment wrappers, hosted-UI authorize URL and code exchange, and `validate_token` (issuer, audience, `token_use=id`, clock leeway, cached JWKS that survives a fetch outage for known keys, fails closed otherwise).
- **User Migration Lambda** (`lambda/user_migration/`): stdlib only, reads the legacy Supabase credentials from Secrets Manager at cold start, checks the password against Supabase inside a total three-second budget, returns the same message and the same request profile for unknown, federated-only and wrong-password cases, logs only the email domain and an outcome word. The user snapshot it bundles is gitignored; an example file is tracked.
- **Operator scripts**: `snapshot_legacy_users.py` (0600 file, domains only in output), `preprovision_cognito_users.py` (federated-only users created and linked by pool username, `--link-only` for dual-identity users after they migrate, dry run by default), `cognito_migration_report.py` (weekly percentage out of migratable users).
- **React screens**: login with an MFA step, `/forgot-password`, `/reset-password`, and a security section for TOTP enrolment. The Jinja signup, forgot-password and callback templates, the `/auth/set-session` route and the dead token branches are deleted; there is no `@csrf.exempt` route left. The ALB path pin shrank with the Jinja list.
- **Startup guard**: `AUTH_BACKEND=cognito` requires the four `COGNITO_*` variables; `SUPABASE_URL` stays required while any switch says `supabase`.
- **Runbook** `docs/runbooks/cognito-user-migration.md`: snapshot → deploy providers → pre-provision → verify → open sign-in → Flip 1 preconditions → weekly report → cut-off.

## Evidence

| Check | Result |
|---|---|
| Backend tests under CI's switches | 1437 passed, 114 skipped (the pre-existing client-input skips) |
| Infra tests | 388 passed; credential-free synth for staging and production |
| Web | tsc clean, 883 vitest passed, production build clean, raw-colour and viewport gates clean |
| Lints | ruff, mypy (56 files), PHI-log lint (107 files) clean |
| CI | backend and web workflows green at `cc8f0d1` (the web workflow now runs on this branch) |

## Not yet run — staging verification and Flip 1 (steps 9–10)

Both need the cost approval, a deployed staging `auth` stack, and your go-ahead:

- A Supabase-era password signs in and lands in Cognito with the right `custom:app_uid`; permissions resolve identically.
- MFA enrol and challenge round-trip (the `SECRET_HASH` username choice can only be proven live).
- One Microsoft link and one Google link for a pre-provisioned user land in the same account.
- `ForgotPassword` response and latency compared for a stranger and a known user.
- The Lambda's p99 inside its budget; both workforce members enrolled in MFA on staging.
- **Flip 1 in production is a stop-and-ask item.** It is a Render config change (`AUTH_BACKEND=cognito`) and stays reversible until Phase 10.

## Accepted risk / deferred (tracker)

- In-process store for the half-finished MFA sign-in; fails closed with more than one worker. Moves to a shared store in Phase 5a.
- No QR code for TOTP enrolment (secret shown as text with the `otpauth://` URI); `MFA_SETUP` and `NEW_PASSWORD_REQUIRED` challenges have no screen yet.
- Invite redemption lost its only screen with `/signup`; the invite email points at login until the onboarding screen gains a code field.
- `get_org_members` shows no email in Cognito mode until the members screen reads the pool.
- Profile reads and writes go through the service key until Phase 5a, so the 0006 policies are not yet what protects them.
- The Jinja `/profile` page still sends a Supabase reset email.

## Needs a human

- Cost approval (Phase 1) — nothing deploys before it.
- **Entra app registration**: Cognito's Microsoft provider must reuse the registration Supabase uses (add the Cognito redirect URI), or every Microsoft subject in the snapshot is useless. External tenant admin.
- Fill `meridian-<env>/legacy-supabase-auth` with the production Supabase URL and **anon** key before Flip 1 (console, never a file).
- Hand-edit `.env.example` (write-protected for the agent): add `cognito` and the `COGNITO_*` variables including `COGNITO_DOMAIN`.
- Generate the user snapshot on the day of each auth-stack deploy (`scripts/snapshot_legacy_users.py`).
- Approve Flip 1 when staging verification is clean and no close is running.
