# Phase 0 report — inventory, safety sweep, threat model, baseline, harden in place

**Date:** 2026-09-15 · **Branch:** `aws-migration` (rebased on `main` after the QBO merge) · **Plan:** `docs/aws-migration-plan.md` Phase 0 · **Prompt:** `docs/aws-migration-prompt.md`

## What was built

| Area | Delivered | Evidence |
|---|---|---|
| Git reconcile (D-23) | In-flight QBO work committed; `andres-try` fast-forwarded into `main` and pushed; `aws-migration` rebased on `main` (37 migrations) | `git log main..aws-migration` |
| Safety sweep | Other products (`schdualer/`, Code Grader seams), client workbooks, `output/`, screenshots, `.trial-env` moved to `~/Business/Meridians Logic/Products/…`; then `scripts/move_client_data_out.py` moved `Resources/`, `temp/`, `data/input/`, `data/revenue.db`, real `config/*` files, real seeds, `.dev-cookies`; 30 client-naming docs untracked and moved; real names replaced in 47 tracked files; tenant UUID backfills moved to ignored seeds | `git status --porcelain --ignored` shows only `.env`, `CLAUDE.md`, tooling; `.gitignore`; `supabase_migrations/seeds/*.example.sql` |
| Inventory | Data layer (65 live tables, 74 live policies, 202 `.table(` sites), web surface (21 rewrites, 78 Jinja screens: 16 reachable / 12 wizards / 6 auth / 44 dead), process registry (five lists to reconcile), config + external calls (47 env vars; NetSuite is not wired), DNS | `docs/compliance/inventory-*.md`, `docs/architecture/inventory-*.md`, `docs/architecture/dns.md` |
| PHI + threat model | PHI determination in writing; classification table; data flows today/target; STRIDE model per trust boundary; OWASP API Top 10 mapping; control matrix (112 controls, status per row) | `docs/compliance/phi-classification.md`, `data-flows.md`, `threat-model.md`, `control-matrix.md` |
| Decisions | ADRs 0001–0015 with alternatives and triggers; provisional decisions P-1…P-10 | `docs/adr/` |
| Repo hygiene | Target layout + today's tree; folder READMEs; `CHANGELOG.md`; `docs/migration-tracker.md`; local `CLAUDE.md` updated (D-01) and recorded in `README.md` | `docs/architecture/repo-layout.md` |
| CI / tooling | Backend workflow with LibreOffice + skip audit; `requirements.lock.txt` (Python 3.13, pip-audit clean); ruff + mypy (enforced scope) + pre-commit + gitleaks; Node 22; web raw-colour gate green again | `.github/workflows/backend.yml`, `pyproject.toml`, `tests/allowed-skips.txt` |
| Harden in place | Names/ids out of logs (+ AST lint, 122 exception sites converted); explicit `DATABASE_BACKEND` / `STORAGE_BACKEND` / `AUTH_BACKEND` switches, fail-loud in production; SQLite cannot be built in production; cross-org role update/delete/assign → 404, no write; payroll table reads name `org_id`; QuickBooks `requestid` keyed on (org, batch, DocNumber, TxnDate) and required; Wearbly receipts upload/download removed (P-5); storage tidy; secret-key fallback removed; temp files via `mkdtemp` + `secure_filename`; 10 undefined-name bugs fixed | commits `fef0bae`, `2e37697`; tests listed below |

## Tests

Backend in CI (Linux): run 35045898441 on `de2ef3b` green (1070 passed, 123 skipped) and run 35047940075 on `fa0e0fb` green (a superset of the Phase 0 tree at `e59073b`); run 35048756757 on `d6b8b8e` green; locally at the close of Phase 0 (`d6b8b8e`): 1104 passed / 114 skipped (plus 65 infra tests). Every skip reason is allow-listed with a cap in `tests/allowed-skips.txt` (the gate failed run 35045704425 on `2e37697` for two unlisted reasons — it is a real gate). 106 skips are the QB USA payroll pipeline, which needs a synthetic ADP/benefits input set (tracker row, Phase 5a). Web: **855 passed**, `tsc` clean. Lint set clean: ruff, ruff format, mypy (enforced scope), PHI-log lint (95 files).

New security test files (parametrised cases in parentheses): `tests/test_role_org_isolation.py` (15), `tests/test_qb_usa_payroll_org_scoping.py` (17), `tests/test_qbo_request_id.py` (16), `tests/test_no_phi_logging.py` (48), `tests/test_settings.py` (49), `tests/test_wearbly_receipts_bucket_removed.py` (7), `tests/test_api_v2_users.py` (+1 ID-swap).

## Reviews

- **Fable critic, round 1 (on `fef0bae`): FAIL** — 4 critical, 9 high, 9 medium. Addressed in `2e37697`/`de2ef3b`.
- **Fable critic, round 2 (on `2e37697`/`de2ef3b`): FAIL** — 1 critical (employee-roster names in five tracked files, one inside a runtime warning string), 5 high (lint bypass shapes, a "CI green" claim written before the run finished, report untracked, skip caps not at the observed numbers, account/pool ids in the plan). Addressed in `e59073b`.
- **Fable critic, round 3 (on `e59073b`): FAIL** — 2 high: a provider name inside `web/public/help/qb-revenue.pdf` (regenerated from the scrubbed HTML), and the lint passing `emp_name = row['Employee Name']` (normalised key matching, person-prefixed `*_name` rule, bare-record names, helper following 3 levels — 7 tests). Both fixed in `d6b8b8e`.
- **Fable critic, round 4 (on `d6b8b8e`): PASS** — 0 critical, 0 high; 3 medium fixed in the closing commit (lint false positive on `type(e).__name__`; one unlisted provider surname in a test fixture; the PDF sweep is a one-off, not automated — see below).
- **Codex review: NOT RUN** — the Codex CLI is not authenticated in this session (`codex login` is a human step). Tracked in `docs/migration-tracker.md`; to be run before the branch merges to `main`.

## Phase 0 Verify list (plan)

| Item | Status |
|---|---|
| Working tree holds no client data, PHI, or other product | MET after round 3 (a provider name survived in a help PDF export until `web/public/help/qb-revenue.pdf` was regenerated from the scrubbed template; a one-off text + PDF + workbook token sweep against the ignored seeds was run at rounds 3 and 4 and is clean; it is not automated because the token list is client data and cannot live in CI). Accepted residue: three provider surnames as lookup keys in `src/database.py` (tracker, Phase 5a), synthetic sample data, English words. |
| `aws-migration` rebased on a `main` containing the QBO work | MET |
| Full `pytest` green in CI | MET — runs 35045898441 (`de2ef3b`), 35047940075 (`fa0e0fb`), 35048756757 (`d6b8b8e`) |
| One real revenue run + one real payroll run on Render byte-identical to the previous run | NEEDS A HUMAN — requires the closed-period inputs on the laptop; procedure arrives in Phase 3 (`docs/je-diff-procedure.md`) |
| Cross-org `role_permissions` write returns 404 | MET (update, delete, assign; v2 twin) |
| A commit to `main` produces no Render deploy | NEEDS A HUMAN — Auto-Deploy toggle in both Render services; `render.yaml` now says `autoDeploy: false` |
| ADRs and inventory exist | MET |

## Open risks

1. **Merging `aws-migration` to `main` before the Render dashboard has the three backend switches set to `supabase` will crash-loop production** (fail-loud is the point). Order: Auto-Deploy off → set the vars → merge → deploy manually.
2. History: bank/payroll workbooks exist in the history of four local branches and the two retired GitHub repos, and the provider seed plus the BKv5 comparison docs are in `main`'s history on GitHub (tracker). The private repo mitigates; a purge is Andres's call.
3. The PHI-logging defence is source-side; a redacting logging filter (library tracebacks quoting cell values) lands in Phase 6 before logs reach CloudWatch.
4. Type checking is enforced on five files; the legacy debt (~400 findings) is paid per module as each is ported (Phase 5a).

## Needs a human (Andres)

- Turn **Render Auto-Deploy OFF** on both services and set `DATABASE_BACKEND=supabase`, `STORAGE_BACKEND=supabase`, `AUTH_BACKEND=supabase` in both dashboards — **before** any merge to `main`.
- Run `! codex login` in this session so the Codex review can run (exit criterion).
- **AWS BAA:** already ACTIVE on the account since 2026-07-13 (AWS Artifact). Confirm you accept that PHI may land on AWS from Phase 3's staging rehearsal onward — I will not load real data before you say so.
- Collect the signed **Stella Mattina ↔ Meridians Logic BAA** (D-03) and file it under `docs/compliance/evidence/` (a reference, not the document).
- **DNS:** decide GoDaddy → Route 53 nameserver move (`docs/architecture/dns.md`); the apex cannot reach CloudFront otherwise.
- Mount the PHI volume and move `~/Business/Meridians Logic/Products/Meridian/data/to-vault/` into it.
- Recover the Google and Microsoft OAuth client secrets from the Supabase dashboard (needed in Phase 4; they are in no file).
- Confirm Microsoft-side MFA is enforced for the superadmin account (interim control until Phase 4).
- Decide on the history purge: `main` on GitHub (provider seed, BKv5 docs), four local branches (bank/payroll workbooks), two retired GitHub repos.
- Obsidian vault: this session cannot read `~/Desktop/Obsidian Vault` ("Operation not permitted"); grant the terminal Full Disk Access or move the vault, then the note in `docs/reports/` is copied there.
- Plan steps 9–10 (Render/Supabase HIPAA quotes in writing; who owns the `ai.meridiansgrp.com` stack) — questions only you can ask.
