# Phase 2 report — Network & IaC (code complete; deployment gated on approval)

**Date:** 2026-09-15 · **Branch:** `aws-migration` (`aa2b10b`) · **Plan:** `docs/aws-migration-plan.md` Phase 2 · **Critic:** three rounds, PASS at round 3 with one medium open (WAF rule 0 shape) fixed in the next commit.

## What was built (`meridian-<env>-network`)

- VPC with 2 AZs and public / private-app / isolated-data subnets, one NAT gateway, gateway endpoints for S3 and DynamoDB only (D-19), KMS-encrypted flow logs (400 d).
- Security groups: ALB admits 443 only from CloudFront's managed prefix list; app tasks only from the ALB; data only from app + ops; ops has zero ingress. Tested: no `0.0.0.0/0` ingress anywhere; egress tightened on ALB and ops.
- ALB: HTTPS only (port 80 removed), TLS 1.3/1.2 policy, invalid headers dropped, 120 s idle, access logs; the default action is a fixed 403 and every forward requires the `X-Origin-Verify` header from Secrets Manager — version-pinned on both the ALB and CloudFront so a rotation is one `put-secret-value` plus two deploys with no outage (ADR 0018 §7, runbook).
- API path patterns are generated from `web/next.config.mjs` (`infra/meridian/edge_paths.py`), pinned and re-parsed in tests; health checks `/api/v1/health` (api) and `/` (web).
- CloudFront: HTTPS-only origin `origin-<env>.meridiansgrp.com`, TLS 1.2_2021, no caching on `/api/*` and `/auth/*`, long cache on `/_next/static/*`; WAF (Common, KnownBadInputs, IP reputation, 2000/5 min per IP, 100/5 min on auth paths, a non-upload body-size rule) with logging to `aws-waf-logs-meridian-<env>` (CMK, 400 d, auth/cookie redacted). Public aliases stay behind `createDnsAliases=false` until Phase 9.
- Certificates split: staging validates only `staging.` + `origin-staging.`; production the apex, `www`, `origin-production.`.
- SSM-managed `t4g.nano` ops instance (IMDSv2, no key pair, zero ingress) in staging by default; ECS Exec documented as the alternative.
- D-15: `docs/runbooks/staging-teardown.md` + `scripts/staging_session.sh` (dry-run, refuses production, deploys the transient stacks by name).

## Evidence

Synth for both environments without credentials, byte-identical on repeat; 230 infra tests; CI green (run 35056338499). Cost: ≈ $79/month per environment pre-tax while running (NAT, ALB, WAF, CloudFront, flow logs, ops instance), inside the plan's staging-session figure.

## Phase 2 Verify list

All six items (`cdk diff` clean on a second run, tag filter returns the stack's resources, direct ALB curl rejected, CloudFront returns the ALB 503, SSM session with zero ingress, destroy + redeploy < 20 min with an identical diff) are **deploy-time checks — NOT YET RUN**; the code shapes for each are present and tested. They run in the first staging session after the cost approval.

## Accepted risk

WAF `SizeRestrictions_BODY`, `CrossSiteScripting_BODY`, `GenericRFI_BODY` are counted, not blocked, so Excel uploads pass; tightened with real uploads in Phase 5a (ADR 0018 §8, dated).

## Needs a human

- Cost approval (Phase 1) — nothing deploys before it.
- The CloudFront prefix-list id and the hosted-zone id are context values read once after the shared stacks deploy (`infra/README.md`).
