# Critic review — Stage 1 exit, round 1

Repo `NS_Proccess_QB`, branch `aws-migration`, HEAD `be3163e`, scope `463b9d1..HEAD` (768 files; generated
artefacts skipped). Read-only. Date 2026-09-24.

## What I ran (all local, no network, no AWS)

| Gate | Result |
|---|---|
| `pytest tests/` (CI backend job shape, migrations excluded) | 4437 passed / 116 skipped / 0 failed (241 s) |
| `pytest tests/test_migrations.py tests/test_split_phi.py tests/test_verify_parity.py` (CI `migrations` job, real Postgres, `MERIDIAN_PG_REQUIRED=1`) | 106 passed → 4543 total, matches the claim |
| `pytest tests/security --known-bad` | 503 failed / 0 passed / 45 deselected — every control genuinely goes red |
| `pytest infra/tests` | 741 passed |
| `web: vitest run` | 102 files / 1219 passed |
| Migration chain round-trip | `upgrade head → downgrade 0005 → upgrade head` with catalog identity (grants, owners, secdef, search_path, memberships) as non-superuser `meridian_migrator` — real, not vacuous |
| Order-dependent failure reproduced | `pytest tests/test_qbo_push_job_pg.py tests/test_worker_post_completion_pg.py tests/test_job_redelivery_history_pg.py` → **1 failed** / 54 passed (see H-5) |
| Secrets scan of every added line | only test constants (`dsnpassw0rd`, RFC TOTP example, `AKIATEST…`); tracked `config/*.json` hold no routing/account/secret keys |
| Golden + fixture synthetic-ness | `TEST-0001`, `PROVIDER 010`, `SYN-*` ids; no names/SSNs/DOBs |

Method: five parallel read-only sub-audits (migrations+pg.py; workers+idempotency+QBO; api/v3+webhooks+security
tests; inputs/storage/registry/auth/QBO-crypto/logging; infra+web+docs), each claim re-verified against
code by me before it appears below.

---

## CRITICAL — none

## HIGH (blocks Stage 1 exit)

### H-1 · Revenue JEs on the Postgres path silently fall back to checked-in Stella Mattina mappings
- `src/qb_revenue_mappings.py:182-249` `load_revenue_maps`: any exception or an empty `qb_account_map` /
  `qb_clinic_map` / `qb_provider_map` returns `default_revenue_maps()` with `source="hardcoded"` and one
  `logger.error`. `src/processes/qb_revenue/processor.py:468, :852, :1072` pass `maps` straight into JE
  generation; nothing in `src/processes/**`, `src/processes/shared.py`, `src/api/v2/oneshot_runs.py` or
  `web/` reads `maps["source"]` / `source_error`.
- `scripts/seed_local_dev.py` and `scripts/seed_sandbox_org.py` insert no `qb_*_map` rows (the only seed
  is `supabase_migrations/seeds/017_qb_mapping_tables_seed.example.sql`).
- Failure: every Stage 2 revenue run on Postgres is coded from the defaults, not the org's mappings, and
  the golden compare passes anyway (the goldens were produced from the same defaults) — the local test
  proves nothing about mapping correctness. In production a transient DB error mid-run yields a
  QuickBooks JE with the wrong accounts, silently. Pre-existing on Supabase, but this diff added the
  Postgres path and kept the silent default.
- Fix: on `database_is_postgres`, `source == "hardcoded"` → `ProcessInputError` / `blocked` (no silent
  default); expose `source` on the results envelope; make the local seed populate the `qb_*_map`
  tables from the example seed; update `tests/test_pnl_facts.py:220`, which enshrines the fallback.

### H-2 · Webhook engine runs on in-memory fakes by default, on a production code path, with no drainer
- `src/webhooks/ports.py:395-400` `adapters_from_env`: no `WEBHOOK_QUEUE_URL` → `FakeQueue` +
  `InMemorySecretStore` + `InProcessPublisher`; `src/webhooks/engine.py:158-163` caches them as the
  process's ports. No `APP_ENV`/production guard. Outside `tests/`, only
  `lambda/webhook_sender/handler.py:85` ever calls `engine.handle`; nothing in `api/`, `workers/`,
  `src/`, `scripts/` runs `FakeQueue`.
- Failure A (Stage 2): `MERIDIAN_API_V3=1` locally → `POST /api/v3/webhooks/subscriptions` returns 201 with
  a secret whose only copy is a dict in one process and writes `secret_arn='local:…'` to Postgres;
  `/test`, redrive and fan-out enqueue into a queue nobody drains; every delivery stays `pending`
  forever while the API answers 202. Stage 2 step 4 ("webhooks to a local receiver") cannot pass with
  the app as built.
- Failure B (AWS): `MERIDIAN_API_V3` and CDK `enableApiPlatform` are independent switches (the queue env
  comes only from `compute._api_platform_environment`; `MERIDIAN_API_V3` is set nowhere in `infra/`), so
  v3 on + platform off, or one dropped env var, ships mock persistence: secrets lost on restart
  (`SECRET_UNAVAILABLE` drops), deliveries never sent. The T19 tag documents only the worker half.
- Compounded by A-M1 below (no DB-side redrive of stalled deliveries).
- Fix: `adapters_from_env` raises at startup when `APP_ENV` is staging/production (or
  `DATABASE_BACKEND=postgres` outside development) and no queue URL is set; for local dev add a real
  drainer (a `FakeQueue` runner thread in the api process or a `webhook_delivery` kind on the in-process
  job dispatcher) so local deliveries actually go out; README env table documents it; a test proves a
  local subscription receives its `/test` event.

### H-3 · On RDS the QuickBooks push bypasses the idempotency ledger unless `qb-usa-payroll` is routed
- `src/api/v2/qb_usa_runs.py:1949-1958`: `if rc.jobs_routed(PROCESS): _push_as_job(...)` else
  `push_batch_to_qbo(org_id, batch_id)`. `push_batch_to_qbo` (`src/qb_usa_payroll_quickbooks.py:160-190`)
  calls `create_journal_entry` with only the DocNumber pre-check and a derived requestid — no
  `job_idempotency` row before the call. `WORKER_PROCESSES` defaults to empty (`src/settings.py:1128`),
  and the Phase 11 plan's own H4 step keeps it empty in production ("everything still inprocess").
- The progress log's E2 claim — "every QBO journal goes through the idempotency ledger" — is false on the
  default configuration of the target backend. It violates the PROCESS FRAMEWORK rule "persist an
  idempotency record before the QBO call" and leaves two QBO posting implementations selected by an
  env var (half-migrated path).
- Same block wraps any exception as `ApiError(EXPORT_FAILED, str(exc))`; `str(QboHttpError)` embeds
  `resp.text[:400]` (`src/qbo_client.py:387-390`) — Intuit's error body (can quote account/customer names)
  goes into the API response.
- Fix: on `database_is_postgres` always post through `post_journal_once` (synchronously when not
  routed) or refuse with 503 until routed; never `str(exc)` on this path; a test that the unrouted push
  writes a ledger row before the fake QBO client is called.

### H-4 · Concurrent QBO push attempts can resend the same journal; the push never re-checks its lease
- `src/qbo_posting.py:178-208`: a `pending` ledger row is read as "the earlier attempt died" → lookup →
  resend with the same requestid. But `pending` is also exactly what a *live* concurrent attempt looks
  like. `src/qb_usa_payroll_quickbooks.py:269-290` iterates journals without `ctx.heartbeat()` /
  `shared.keep_alive` (which the revenue and MX processors do use: `qb_revenue/processor.py:1244`,
  `mx_payroll/processor.py:606`); `src/processes/qb_usa_payroll/processor.py:916-967` checks
  `quickbooks_push.job_id` once before the loop.
- Scenario: worker A holds the push lease (600 s). Its heartbeat cannot reach the DB —
  `workers/run_job.py:507-514` returns True on a psycopg error without extending — or the user sees
  `interrupted` after `PUSH_LOST_SECONDS` and presses again (`qb_usa_runs.py:1837-1851`, new job). B
  claims via `claim_post_completion` and walks the same journals while A is still sending. Per journal B
  sees `pending`, lookup finds nothing yet, B posts with the SAME requestid while A's identical request is
  in flight. The only thing standing between that and two JEs is Intuit's requestid cache under
  concurrent requests, which Intuit does not document. A's settle is fenced afterwards, but the JE exists.
- Fix: pass `ctx` into `push_batch_once`; `shared.keep_alive(ctx)` and re-read `quickbooks_push.job_id`
  before EACH journal; in `post_journal_once` treat a `pending` row younger than the lease length as
  in-flight (`QBO_IN_FLIGHT`, no resend) — `_BUMP_PENDING` leaves `updated_at` alone, so its age is
  usable; make heartbeat DB errors count as "not extended" (F5). Downgrade to medium only with a written
  Intuit statement that concurrent same-requestid creates are deduplicated.

### H-5 · The "4543 / 0 failed" gate is order-dependent
- `tests/test_job_redelivery_history_pg.py:174-197`
  `test_a_push_killed_with_its_process_is_resumed_by_the_next_process` fails deterministically after
  `test_qbo_push_job_pg.py` / `test_worker_post_completion_pg.py` in the same session (reproduced by the
  sub-auditor twice and by me once: 1 failed / 54 passed); passes alone. `Dispatcher.recover()` is
  cross-org (`app.redeliverable_jobs`, 0024) and redelivers leftover completed runs from earlier files in
  the shared pg fixture; `handler.calls` then holds a foreign job id.
- Failure: any reordering (`-p randomly`, a new file, `-k`) turns the green gate red or hides a real
  regression behind "flaky". A gate that depends on collection order is not evidence.
- Fix: assert on calls filtered to `run_id`, or truncate `process_runs` per test in the fixture; run the
  pg suites once with random order in CI.

---

## MEDIUM (11)

- **M-1** `src/storage.py:148-200` `LocalStorageManager`: no `{org}/` prefix, no `assert_org_path`, no root
  confinement (`download_file` reads any path). Only under `dev_fallbacks_permitted()`, production
  refuses it — but Stage 2 (`STORAGE_BACKEND=local`, two synthetic orgs) therefore never exercises
  storage-layer isolation. Fix: mirror `S3StorageManager`'s prefix/assert/confinement.
- **M-2** `src/processes/manifest.py:124-136` says every input validator is re-run by the job on the
  materialized file; true for qb_revenue (`processor.py:1283-1286`) and mx_payroll (`:640-645`), false for
  qb-usa — `validate_adp_export` is referenced only from its manifest (`:127`). Fix: call it after
  materialize; conformance check that each manifest validator runs on the job path.
- **M-3** `src/log_safe.py:226-278` `RedactingFilter`: (a) secret values snapshotted from `os.environ`
  once at install — runtime-fetched secrets (`src/webhooks/ports.py:341`, KMS data keys) never redacted;
  (b) `extra=` dict/list values not redacted, only `str`. Fix: recurse into mapping/sequence extras;
  register runtime secrets.
- **M-4** `src/auth.py:1809-1813` `get_org_modules` fails OPEN (`ALL_PROCESSES`) on any exception;
  `api/v3/access.py:47-50` depends on it → a transient DB error enables every module for that request.
  Fix: fail closed on postgres/v3 (error = no modules or 503).
- **M-5** `api/v3/quotas.py:147-149, 172-174, 195-198`: `auth_gate`, `record_auth_failure`, `cap`
  log-and-continue on store errors → under an auth-failure flood that stresses Postgres, lockout and the
  300/min + 30/h caps switch themselves off. Fix: 503 from `auth_gate`/`cap` when the store is down.
- **M-6** `src/api_clients.py:211` `SELF_APPROVAL_ALLOWED = True`: the requester approves their own
  client, so "admin approval" is a one-person control. Documented (ADR 0037 d2). Needs-a-human, not code.
- **M-7** `src/webhooks/subscriptions.py:332-336` redrive resets `attempt = 0` with no per-delivery or
  per-subscription cap → a `webhooks:manage` client can make Meridian re-POST 8 signed requests per
  redrive at a third party, bounded only by the 300/min caller quota. Fix: cap via `quotas.cap`.
- **M-8** `src/webhooks/engine.py:484-493` a failed delivery relies solely on the queue's delayed
  message; no definer function/sweep for due `pending`/`failed` deliveries, no index on
  `next_attempt_at` (0013/0014), `outbox_sweep` republishes events not deliveries, manual retry accepts
  only `dead`/`dropped` (`subscriptions.py:335`). In-process (Stage 2) a restart strands the row
  forever. Fix: `app.due_webhook_deliveries(limit)` + partial index, swept from the worker tick.
- **M-9** api and worker share `meridian_app`, so the api container holds EXECUTE on every worker
  definer function (`claim_run`, `claim_post_completion`, `expire_stale_runs`, `redeliverable_jobs`,
  `unpublished_api_events`, `authorize_job`; 0011/0018/0019/0022): a compromised api can lease/abandon
  any org's run and distinguish `actor_mismatch` from `run_not_found`. Recorded (tracker T:175,
  `infra/meridian/stacks/worker.py:58`). Acceptable for Stage 1 only because written down; the
  `meridian_worker` login role + grant revision is a hard pre-production item.
- **M-10** `infra/meridian/stacks/compute.py`: no `QBO_CLIENT_ID` / `QBO_CLIENT_SECRET` /
  `QBO_ENVIRONMENT` in the api or worker task definitions (only `QBO_TOKEN_KMS_KEY_ARN` :965-969) while
  `src/qbo_client.py:42/:506` reads them → the D18 "Connect QuickBooks" card answers 503 on AWS until
  someone sets env by hand (drift / plain-env secret). Fix: Secrets Manager reference like
  `COGNITO_CLIENT_SECRET` (`compute.py:842`) for api AND worker, with a test.
- **M-11** Render-merge evidence gap: G2 deleted `/api/config/export|import`, `/api/fiscal-calendar/import`,
  `/api/process`, `/setup-org`, `/qbo/*`, `/api/mso/*`, `/api/v1/*` non-health from `web_app.py` citing
  "web/src grep AND 30 days of ALB access logs". Render has no ALB logs; only the grep half exists
  (I confirmed: no `web/src` consumer). Record the deletions as approved-by-Andres (09-22) with grep-only
  evidence rather than citing logs that do not exist.

## LOW (17)

- L-1 `src/api/v2/auth_routes.py:438-500` hand-rolled HMAC-SHA256-CTR encrypt-then-MAC for the parked
  challenge store while `src/qbo_token_crypto.py` uses `cryptography` AESGCM — a second, undocumented AEAD.
- L-2 `src/processes/__init__.py:213-221` imports gitignored `local_plugins` at registry build with no
  `is_production()` guard.
- L-3 `src/file_signature.py:158-166` cp1252 decode means `csv_not_text` fires only on NUL (document).
- L-4 `api/v3/quotas.py` `_ip_bucket` counts forged-token 401s from any source → shared-egress lockout of
  a partner IP (documented trade-off).
- L-5 0023 `REFUSE_SEALED_DOWNGRADE` untested (round-trip downgrades with zero sealed rows).
- L-6 `MAX_ATTEMPTS = 3` duplicated in 0011/0020/0022/0024, `workers/transport.py:57`,
  `infra/meridian/stacks/worker.py:129`; no test pins them equal.
- L-7 0011 comment "lease_owner set only by app.claim_run" is false (`src/process_runs.py:585-590`,
  `workers/run_job.py:303,403` write lease columns directly; org-scoped, harmless).
- L-8 No index for the sweeper's abandoned-wizard branch (0020 `state IN ('draft','needs_input') AND
  expires_at < now()`).
- L-9 `audit.api_request` retention unimplemented (ADR 0040 Proposed) — unbounded growth; Stage 3.
- L-10 Fence inconsistency: `src/process_state.py:325-332` requires `lease_expires_at > now()`;
  `workers/run_job.py:254-274` `_fenced` checks only owner/job_id → a lapsed lease with no usurper makes
  `write_state` raise `lease_lost` and `_settle(failed)` LANDS, contradicting the docstring
  (`run_job.py:50-52`). Same predicate on both sides.
- L-11 `workers/run_job.py:507-514` heartbeat returns True on DB errors without extending (precondition
  for H-4 / L-10).
- L-12 `src/process_runs.py:583-591` `begin_action` sets `lease_expires_at = now()`; both claims require
  `< now()` strictly → same-microsecond `busy` and a 900 s stall. Use `<=`.
- L-13 `cancel` from `parsing` (`state_machine.py:60`) during a leased synchronous parse leaves
  `lease_owner` set forever and `_RECORD_SQL` still records state objects on the expired run.
- L-14 ADR gaps 0027/0031/0033/0034; decisions with no ADR: D17 (outbox sweep as a worker message kind vs
  ADR 0038), D18 (QBO connect over /api/v2), execute compare-and-set + 15-min stale key
  (`RUN_STATE_CHANGED`), in-process redelivery model (0022/0024), magic-byte check.
- L-15 `CHANGELOG.md` "Unreleased" + `web/package.json` 1.0.1 after 184 commits; not a violation until
  the main merge, but one bump (2.0.0) must cover it then.
- L-16 `api/main.py:360` `log_setup.configure_logging()` runs unflagged, so Render's log format flips to
  JSON + redaction at merge. Beneficial, but it is a production behaviour change not behind a switch —
  note it in the merge checklist.
- L-17 `docs/reports/local-first-plan` cites "T:86 invite-redeem"; the code exists
  (`web/src/app/onboarding/org/page.tsx`) but tracker T:86 is now the Macie row — stale cite.

---

## Verified clean (so the next round does not re-audit them)

Migrations/RLS: every hand-over membership `WITH INHERIT FALSE, SET TRUE`, chain-wide guard
(`tests/test_migrations.py:1454`); all new tenant tables ENABLE+FORCE RLS with `meridian_org_isolation`
and listed in `scripts/tenant_tables.txt`; definer functions pin `search_path`, revoke PUBLIC EXECUTE,
column-level grants; audit tables INSERT-only with `refuse_change` triggers; `partner_baa_id` cross-org FK
closed at the app layer (`api_clients.py:452-455`); hot-path indexes present (0011/0013/0018/0022/0024);
Alembic reads only `MERIDIAN_DATABASE_URL`; `pg.py` resets ROLE/`app.*` on return.

Workers/idempotency: `claim_run`/`claim_post_completion` single conditional UPDATE; settle/progress/batch
fenced on owner+job_id (+state); outbox event in the settle transaction; `_settled_by` +
`settled_job_ids` acknowledge late duplicates; lease owner unique per delivery; execute compare-and-set
(`begin_action`) yields one `RUN_STATE_CHANGED` for two executes with different/no keys; stale-key re-arm
+ CAS = no double execute; `PostgresRunStore.upsert` keeps `state_objects`/`batch_intent` (C2 fixed);
sweeps bounded + indexed; every new path gated for Render (`execute_idempotency.enabled()`,
`rc.jobs_routed`, `begin_action` None off Postgres, `inprocess.start_if_rds`, `sweep_enabled`).

API v3/webhooks: scopes/org from Postgres rows, never claims; human-only scopes refused for machines;
`phi:read` needs active BAA + mTLS subject; every handler `id AND org_id`, uniform 404; single masking
serializer; `extra="forbid"`; keyset pagination 1-100; pre-signed POST pins key/content-type/length/KMS
and the raw tag so an uploader cannot self-apply the GuardDuty tag; SSRF guard covers every IP spelling,
every A/AAAA incl. mapped/NAT64/6to4/Teredo, pinned IP + hostname TLS, no redirects; payload ids only;
attempts claimed by conditional UPDATE + lease, 8 retries → dead; secrets shown once; machine tokens 15 min;
audit rows hold route template + one UUID. Security tests run against real Postgres RLS as `meridian_app`;
known-bad breakers genuinely remove both isolation layers.

Inputs/crypto/auth: single process registry (`process_runs.PROCESSES = frozenset(REGISTRY)`; conformance
test holds CHECKs equal to both chains); QBO token envelope (fresh DEK, random nonce, AAD, dev key refused
outside dev, trigger + CHECK forbid plaintext writes, Supabase path unchanged); QBO OAuth state server-parked,
single-use, org+user bound, 600 s; federated OAuth constant-time state / PKCE verifier on Supabase; upload
vetting size → container (10k/1 GiB/250:1) → extension → magic bytes; `adopt_upload` gates on the exact
VersionId tag; `configure_logging` runs from every real entrypoint; fixtures and goldens synthetic; `web_app`
imports clean under `DATABASE_BACKEND=supabase`.

Infra/web: IAM wildcards only in KMS key policies / no-resource actions; worker role scoped to queue, DLQ,
`phi/*/*/uploads/*`, `*/*/state/*`, output subfolders, `kms:ViaService s3`, token key with
`EncryptionContext purpose=qbo-token`; SQS KMS + DLQ redrive 3 / 14 d; log groups KMS + retention; alarms
wired to the alerts topic; tag aspect fails synth on an untagged resource; flag-off byte-identity is a real
test; no public IPs. Web: no placeholder/TODO/mock in admin/api, create form, custom steps, sign-in
challenges, results screen, QBO card; secrets shown once and dropped; QBO push 202 → poll with abort/unmount
cleanup; Radix dialog a11y; labels present.

---

## Verdict — Stage 1 exit: **FAIL**

Five unresolved HIGH findings (H-1 … H-5), zero critical. Two of them (H-1, H-2) mean Stage 2 as
planned would either pass without proving anything (H-1) or cannot pass at all (H-2, step 4). Fix,
re-run the gates (including the pg suites in random order), and I will re-review the deltas.

## Needs-a-human (for the stage report)

1. Andres decisions still open: D6 (`.env.example` edit), D9 (real clinic names in the sandbox seed),
   D10 (`MERIDIAN_LOCAL_PGDATA`), D11 (zip-bomb limits), D12 (create parses unscanned bytes — accepted?),
   D13 (run `scripts/pin_rds_ca_bundle.py`; `Dockerfile.api` refuses to build until then), D14
   (+$3.10-3.70/month alarms), D15 (7-year Cognito export retention), D16 (`authorize_job` actor
   widening), D17 (outbox sweep placement), D18 (Intuit redirect URIs + `QBO_*` env; `.env.example`
   line), D19 (30/org/process/hour cap).
2. Docker Desktop is off: `docker-compose.local.yml` and the worker image (D6: "NOT BUILT AS AN IMAGE")
   are unproven; Stage 2 step 1 needs Docker or an explicit Homebrew-Postgres substitute.
3. API-client self-approval (`SELF_APPROVAL_ALLOWED = True`, ADR 0037 d2) — a one-person control until a
   second admin exists; quarterly access review must flag it.
4. Tracker T:175 — separate `meridian_worker` login role + grant revision before H4/production.
5. Real-data JE parity (port gate) needs the rehearsal workbooks and a production dump on the encrypted
   volume (D8); `hold/post-parity-schema` merges only after it.
6. Signatures: in-transit position paper + custody template (2 VERIFY items); BAAs (AWS, partners),
   written policies, penetration test, auditor — not blocking, on the list.
7. Version/CHANGELOG: choose the release number for the aws→main merge (one bump covering ~40 entries).
