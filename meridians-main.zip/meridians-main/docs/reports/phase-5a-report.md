# Phase 5a report — Data layer port, FastAPI beside Flask, containers (code complete; staging deploy gated on approval)

**Date:** 2026-09-16 · **Branch:** `aws-migration` · **Plan:** `docs/aws-migration-plan.md` Phase 5a · **Critic:** five rounds (1 critical and 9 highs found and fixed across rounds 1–4), **PASS at round 5** (`24a43f5`); the round-5 mediums are fixed in the following commits.

## What was built

- **Repository layer** (`src/pg.py`, ADR 0022): pooled psycopg2 connections, `with_org` and `with_user` scopes that set and reset the session variables RLS reads, autocommit by default with explicit transactions, a bounded checkout with a timeout, typed errors that the swallow-and-continue call sites cannot hide, `verify-full` TLS outside dev, and a COPY path that stages through a temp table (COPY FROM is refused under RLS) with an explicit org predicate and a row-count check.
- **PHI choke point** (`src/phi.py`, ADR 0012): the only module that touches the `phi` schema; every access writes an opened row before and a closed row after into `audit.phi_access`; the `patient_ref` token is byte-identical to the split script's, proven by a test that computes both.
- **`DatabasePostgres`**: all 63 methods of the Supabase class, with explicit `org_id` predicates and RLS as the second layer, ISO-string timestamps so callers are unchanged, identifiers routed through `src/phi.py`, an atomic transaction-plus-identity insert with a compensating delete, and per-area tests on a real PostgreSQL 17 as the non-superuser app role. The fake-Supabase tests still run under `tests/legacy_supabase/`.
- **Call-site ports**: `web_app.py`'s 47 data sites into store modules (`org_admin_store`, `qb_usa_payroll_store`, `uniform_store`, invoice helpers), plus the small modules and `src/process_runs.py` and the v2 API / `src/auth.py` sites (merged as they landed; see the tracker for anything still on the Supabase-only path).
- **Invoice numbering** (revision 0007): a per-org counter moved by one atomic statement and a unique index, replacing read-max-then-increment.
- **FastAPI beside Flask** (ADR 0023): the process is a FastAPI app with Flask mounted under it; every `/api/v2` module except `/dashboard` is served by FastAPI with the same envelope, CSRF, rate limits and OpenAPI document; uploads go through the same werkzeug parser; body size is bounded on the streamed path; the rate limiter keys on the authenticated user and on the rightmost forwarded address.
- **Containers**: `Dockerfile.api` (Python 3.13, non-root, RDS CA bundle, fiscal calendar asserted present, uvicorn) and `web/Dockerfile` (Next standalone, runtime proxy so no API origin is baked at build), with `.dockerignore` files that keep client data, secrets and the user snapshot out of every image.
- **`compute` stack**: ECR (immutable, scanned), ECS Fargate on ARM64, one api task by design, circuit breaker with rollback, task and execution roles scoped to named secrets and buckets.
- **Deploy workflow** (`.github/workflows/deploy.yml`): dispatch-only with a confirm gate; tests → arm64 build → Trivy on the tarballs → OIDC push → `cdk deploy` of the staging compute stack. It has never run.

## Evidence

| Check | Result |
|---|---|
| Backend tests under CI's switches | 2316 passed, 114 pre-existing environment skips; PG tests run on the fixture |
| Org-scope lint | 97 violations / 56 unverifiable, down from 111 / 42, with a ratchet test against a committed baseline |
| Infra tests | 499 passed; credential-free synth both environments |
| Web | tsc, vitest, production build, colour and viewport gates clean; the routes manifest carries no baked origin |
| CI | backend and web workflows green at `24a43f5` |

## Not yet run — needs the staging environment

- **The port gate** (`scripts/run_port_gate.py` + `scripts/diff_je_output.py`): restore production into the fixture, re-run a booked period, byte-compare the JE CSVs. Needs the production dump and the two rehearsal workbooks. Until it passes, the port is unit-verified only.
- The Phase 5a verify list: a full revenue run and a QB USA payroll run on staging, an invoice PDF byte-compared with one rendered locally, upload/download round trips, forced task replacement mid-run, apex and `www` termination.
- The first dispatch of `deploy.yml` (needs four repository variables, the foundation stack redeployed for the OIDC role, and the `edge` stack up).

## Accepted risk / deferred (tracker)

- Flask serves zero `/api/v2` routes; the blueprint is deleted. `web_app.py` keeps only the Jinja process wizards until Phase 11.
- Four cross-org superadmin reads stay on the Supabase-only path until the audited bypass ADR 0011 describes exists.
- Wearbly writes are broken today and frozen (P-5); decision needed: repair or retire.
- Chunked uploads through the WSGI mount are bounded but still buffered; `a2wsgi` is a dependency decision.
- `MFA` handle store, rate limiter and wizard state are in-process (one api task by design).

## Needs a human

- Cost approval (Phase 1) — the staging deploy and every verify item above wait on it.
- Production dump + rehearsal workbooks for the port gate.
- `a2wsgi` dependency: yes or no.
- Wearbly: repair or retire.
- Confirm the CDK bootstrap qualifier before the first `deploy.yml` dispatch.
