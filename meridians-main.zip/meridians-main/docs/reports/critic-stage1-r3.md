# Critic review — Stage 1 exit, round 3 (delta only)

Repo `NS_Proccess_QB`, branch `aws-migration`, HEAD `db89cd6`, scope `82cf10d..HEAD` (17 commits, 3 merges:
R2-M4 `128941a`, R2-H1 `154f443`, R2 hardening `bb316a7`, plus `1625d3c` refusal sentences; 89 files / +6421 −401
excluding generated openapi, `schema.d.ts`, python client, goldens). Read-only. Date 2026-09-25.
Rounds 1–2: `docs/reports/critic-stage1-r1.md` (FAIL 5H/11M/17L), `docs/reports/critic-stage1-r2.md` (FAIL 1H/10M/20L).

## Gates I ran (all local, no network, no AWS)

| Gate | Result |
|---|---|
| `pytest tests/` (CI backend job shape, three migration files excluded) | **4823 passed / 116 skipped / 0 failed** (257 s); `scripts/check_pytest_skips.py` OK (116 ≤ 122, all allow-listed) |
| CI `migrations` job (`MERIDIAN_PG_REQUIRED=1`, non-superuser migrator) | **106 passed** → 4929 total, matches the log's claim |
| CI random-order step (`MERIDIAN_TEST_SHUFFLE_SEED=random`, `MERIDIAN_PG_REQUIRED=1`, all 56 `tests/**/*_pg.py`) | **883 passed / 0 failed**, seed `3225315674` printed top and bottom (114 s). NB the log says "shuffled pg 993 / 0"; `find tests -name '*_pg.py'` collects 883 for me — a numbers nit, not a failure |
| `pytest tests/security --known-bad` | **656 failed / 0 passed / 45 deselected** — every control (including the 63 new v2 kind tests and the log-redaction breakers) goes red with its breaker applied |
| `pytest infra/tests` | **754 passed** (172 s) — the one new test is the M1 worker/`MERIDIAN_API_V3` pin |
| `alembic heads` | one head, `0028_api_request_export_writer`; chain 0025 → 0026 → 0027 → 0028 linear |
| `web`: `vitest run` | **1247 passed / 0 failed** (104 files) |
| Secrets/PHI scan of added lines | test constants only; `.env` untouched; no bank numbers, keys or person names |

Method: I read the whole non-generated delta file by file, then traced each fix from its entry point to the
exporter/DB and back to the envelope/screen, and cross-checked with the new tests' names and bodies. Where I
did not run something myself I say so.

---

## R2-H1 — verdict: **RESOLVED**

The fix does what round 2 asked: the required set is no longer a list of tables, it is what the exporter
indexes for *this* file, computed by the exporter's own builders as a dry run, before anything books.

Evidence, per branch of the finding:

- **Revenue partial maps.** `src/revenue_qb_exporter.py` `unmapped_for_run` runs `build_posted_rows` (with
  `collect=True`, `output_dir=None`, nothing written) over the run's enriched clinic + hospital transactions,
  and, when the run will make unposted JEs, `build_unposted_rows` over one synthetic 43006 entry per
  `(location_code, department)` pair. The builders now record `other_codes` (`_other_code`), `payer_labels`
  (`_payer_label`) and the 18099 clearing account (`_clearing_account`) — exactly the three the r2 finding
  named — in addition to accounts / departments / locations / payers. `WebProcessor._qb_preflight`
  (`src/processes/qb_revenue/processor.py`) calls it in BOTH the thread path and the worker `_compute`
  path after `_load_qb_maps` and before `_open_batch`; the read+enrich is handed to the run (`pre`) so the
  file is not read twice. Refusal is `blocked`, `QB_MAPPINGS_UNAVAILABLE`, `qb_maps_source == "postgres"`,
  `qb_maps_reason == "incomplete"`, `qb_unmapped` keyed by mapping table (manifest `public`), flattened into
  `error.details` by `oneshot_runs._qb_maps_details`. I checked the pre-check against the exporter line by
  line: the posted dry run is the same call the real export makes (same transaction set: `enrichment_result.
  transactions` + every hospital list); the unposted pre-check uses `tx.location_code`, which is what the
  JE `Location` column carries (`je_generator` `location=agg_line.location_code`) and what
  `unposted_generator` reads back (`row.get('Location')`), so the same string reaches `build_unposted_rows`
  in both. `qb_date("")` returns `""` (no raise in the dry run). Nothing the exporter indexes is missing
  from the pre-check.
- **Backstop.** `RevenueQBExporter(strict=True)` builds every row first and raises `QbExportRefused` before
  `_write`; `export_revenue_qb`/`export_revenue_qb_unposted` re-raise it and wrap any other exception as
  `QbExportRefused(reason="export_failed")` when strict; `_generate_unposted` re-raises instead of
  `logger.warning`. `test_without_the_preflight_the_strict_export_still_refuses` covers it.
- **mx partial maps.** `payroll_qb_exporter.unmapped_for_run` runs `build_qb_rows` (the same builder
  `_export` writes from, `payroll_qb_exporter.py:149-150`) over main + provision lines; locations are now
  recorded (`_map_loc`). `PayrollWebProcessor.process_with_progress` computes the JEs (`_generate_jes`,
  pure arithmetic — I read the code between the preflight and the booking: the roster sync reads
  `file_roster`/`roster_overrides` and writes to the DB, it does not mutate `payroll_result`) before the
  roster sync and the batch, refuses `failed` + `incomplete` + per-table list, and books the SAME
  `pre_jes`. The strict export is no longer inside `except Exception: logger.exception`.
- **Column map.** `load_mx_column_map` on Postgres uses `get_mx_payroll_column_map(strict=True)` (raises
  instead of `[]`) and raises `MxColumnMapUnavailable` on empty; `reload_column_map` remembers it and only
  `read_payroll_data_raw`/`read_payroll_data_test_method` call `_require_column_map` — I grepped:
  `column_to_account`/`negate_columns` are read only inside those two readers (`payroll_processor.py:1629,
  1637, 1883, 1893`), so the excel/spec methods are untouched (`test_the_excel_method_does_not_need_the_
  column_map`). The local seed writes the column map (`seed_mx_column_map`).
- **P&L.** `pnl_roster` and `revenue_facts` call `load_org_revenue_maps` → `RevenueMapsRefused` on a
  hardcoded bundle when `refuses_fallback(db)`; all four route callers (`config_routes.pnl_providers`,
  `pnl_preview`; `pnl_routes.drivers_template`, `load_drivers`) convert it to 409 `QB_MAPPINGS_UNAVAILABLE`
  with `details.reason`. grep: no other caller of `pnl_roster`/`revenue_facts`/`load_revenue_maps` outside
  `org_qb_maps` (which already refuses).
- **qb-usa overrides.** `_load_overrides_supabase` raises `BenefitOverridesUnavailable` on a read error
  when strict; `_parse` turns it into the fixed `OVERRIDES_REFUSED` sentence; `error_code_for` maps it to
  `QB_MAPPINGS_UNAVAILABLE` on the job (`parse_job`, `execute_job`) and v2 (`_envelope`, `_sync`,
  `get_preview`, `_execute`) paths.
- **One switch:** `qb_mappings.refuses_fallback(db)` (settings backend OR `is_postgres(db)`), used by every
  refusal; Supabase/SQLite/CLI byte-identical.
- **Tests:** `tests/test_qb_maps_coverage_pg.py` (7 revenue gaps each blocked with `_open_batch` spied and
  `[]`, thread + worker, 43006 required only with unposted, retry-after-add → goldens, backstops with the
  preflight monkeypatched away, 3 mx gaps → failed with nothing booked, empty/unreadable column map,
  excel still books, P&L routes ×3, 4 known-bad controls) and `tests/test_qb_usa_overrides_refusal_pg.py`
  (7, with 2 known-bad). All pass in my full run, my shuffled run, and go red under `--known-bad` where
  they are controls.

Residuals from this fix are lows (R3-L1..L3, L6, L7 below). None is a silent wrong JE.

## Round-2 mediums — verdicts

| # | Verdict | Evidence |
|---|---|---|
| R2-M1 worker fail-closed webhook check | **RESOLVED** | `src/webhooks/ports.py` `worker_config_problems`/`check_worker_configuration` (dev → `[]`; v3 on OR either var set → both required); `workers/main.py:110` calls it before the first receive; CDK copies `MERIDIAN_API_V3` to the worker only with the platform (`WORKER_ENV_FROM_API`), pinned by `infra/tests/test_worker.py` and `test_api_platform.py` (copied, never assigned). grep: nothing else in the worker branches on the flag. 11 tests + known-bad. |
| R2-M2 `/test` unbounded | **RESOLVED** | `api/v3/routers/webhooks.py:346-360`: 404 first, then `quotas.cap` 10/h per (org, subscription) and 60/h per org (`subs.TESTS_PER_*`), counted whether or not queued; `tests/security/test_webhook_redrive_and_sweep.py`. |
| R2-M3 false 600 s hold | **RESOLVED, safe** | `idempotency.release()` is a compare-and-set on the attempt's own stamp (`_RELEASE`: `state='pending' AND updated_at = %s`), moving it back exactly `IN_FLIGHT_SECONDS`, so `_TAKE_PENDING`'s `<=` takes it at once. Called only on the two paths where nothing was sent (`lookup` raised; `JOURNAL_NOT_BUILT` on a taken row). I walked the interleavings: a release can never touch a row another attempt has taken (different stamp), a create with no answer still holds (`test_a_create_with_no_answer_still_holds_the_journal`), and the SAME requestid is kept, so two attempts cannot send the same journal. L7 folded in: `_complete` swallows `IdempotencyStateError` only when `state == "failed"`, reports the success, and the next attempt's lookup completes the row. 5 tests + known-bad. |
| R2-M4 blocked screen contradiction / no way in | **RESOLVED** | `api/routers/config.py` `_register_qb_map_routes` ×6: GET/POST/PATCH/DELETE, `config:access`, `CSRF` + `WRITE` on every unsafe method, same `config_routes` service as v3 (org-scoped `_find` → 404, `extra="forbid"`, case-insensitive 409), `qb_mapping_change` audit line with ids only; `web/src/app/config/quickbooks/` screen (list/add/edit/deactivate/delete, preview, EN+ES, Supabase 503 `reason: backend` rendered as "not on this database"); `qb-mappings-missing.tsx` renders OUR sentence by `details.reason` + process, lists `details` per table with a link to the section, keeps `retry`; `mapping-fix-screen.tsx` no longer shows "Every unmapped item has a mapping now" for this case; `results-screen.tsx` `MapsSource`. Delete-confirm fix: `onOpenChange` ignores the close while `confirmDelete` is up (`mapping-section.tsx:687-690`). 63 pg security tests (all red under `--known-bad`), 26 vitest. Residual: R3-L4 below. |
| R2-M5 redaction tied to JSON flag | **RESOLVED** | `api/main.py:408` always `configure_logging(json_format=json_logging_enabled())`; `build_handler` installs `RedactingFilter` unconditionally, formatter only switches (`TextFormatter`); `uvicorn.access` suppression + INFO pins unchanged. The filter clears `exc_info`/`exc_text`/`stack_info` (`src/log_safe.py:365-367`) so `logging.Formatter.format` cannot append a traceback under `TextFormatter`. Render's start is `uvicorn api.main:app` (`render.yaml:43`) → goes through `__getattr__("app")` → configured. `tests/security/test_log_redaction_every_backend.py` (3, with the pre-fix gate and a no-filter breaker). |
| R2-M6 D20 empty menu on RDS blip | **UNCHANGED — accepted trade-off** | Not in the delta; still on needs-a-human. |
| R2-M7 D21 quota table SPOF | **UNCHANGED — accepted trade-off** | Not in the delta; still on needs-a-human. |
| R2-M8 Supabase push returns Intuit body | **NOT RESOLVED** | `src/api/v2/qb_usa_runs.py:2049` still `raise ApiError(err.EXPORT_FAILED, str(exc))` on the non-Postgres, unrouted path; `QboError` embeds `resp.text[:400]` (`src/qbo_client.py:273, 389`). Pre-existing on today's Render; the fix is one line; still open at the merge. |
| R2-M9 random order not a gate | **RESOLVED** | `tests/shuffle.py` (stdlib `random`, modules then tests within, seed printed top and bottom, replayable) + `tests/conftest.py` hooks; `.github/workflows/backend.yml` "Tests (Postgres suites, random order)" with `MERIDIAN_PG_REQUIRED=1`; `tests/test_shuffle_order.py` pins hook, replay and CI step. Reproduced myself (883/0, seed above). Note the fix found and fixed one real order dependency (`test_api_request_retention_pg.py`). |
| R2-M10 real client account paths in seed | **NOT RESOLVED — needs Andres (D9)** | Unchanged; D9 still open in the log. |

## Round-2 lows — verdicts

| # | Verdict |
|---|---|
| R2-L1 drainer only via module attr | **RESOLVED** — `api/main._lifespan` on `create_app`, every serving mode; `test_every_way_of_serving_the_app_starts_and_stops_the_drainer` |
| R2-L2 no drainer shutdown | **RESOLVED** — lifespan `finally: stop_drainer()` |
| R2-L3 dev-key rotation re-seal | **NOT RESOLVED** (declined with reason in tracker S1R2-LOWS; laptop only) |
| R2-L4 KMS wrapper on a laptop → 500 | **RESOLVED** — `SealedSecretStore._key` refuses a `KmsKeyWrapper` at boot, names the variable |
| R2-L5 sealed store trusts org in ref | **NOT RESOLVED** (declined with reason; unreachable with caller input) |
| R2-L6 redriven rows due-since-creation | **RESOLVED** — `next_attempt_at = now` on redrive |
| R2-L7 `_complete` raises after a meanwhile-settle | **RESOLVED** (see M3) |
| R2-L8 `LocalQuotaStore` eviction | **RESOLVED** — per-entry window (`v[0] + k[1] > now`), 2 tests |
| R2-L9 lockout after full verification | **NOT RESOLVED** (deliberate, documented) |
| R2-L10 `/0` allowlist | **RESOLVED** — `prefixlen == 0` refused, tests |
| R2-L11 `begin_action` `<` vs `= now()` | **RESOLVED** — `<=` |
| R2-L12 `upload_output_file` follows a link | **RESOLVED** — `O_NOFOLLOW`, `StoragePathError`, test |
| R2-L13 crash-leaked pin dirs | **RESOLVED** — `sweep_stale_pin_scratch` (only `<run>.pin-*` dirs, never links, mtime > 1 h) at api start and on the sweep tick. Cannot hit a live pin: a pin lives for one `pin_inputs` request (`process_api.py:407-445`, adopt + validate + prepare, removed in `finally`), and files are written directly under it so its mtime is fresh. On AWS the worker's tick sweeps its own (empty) disk — harmless. |
| R2-L14 v3 kind error mapping | **PARTIAL** — `_require_postgres` now carries `details.reason: "backend"`; a concurrent exact duplicate (DB unique violation) is still 503 `PERSISTENCE_UNAVAILABLE` not 409 (`config_routes.py:757-764`); `service_line: null` still 503 not 422 |
| R2-L15 T:175 wording | **RESOLVED** — tracker row now "a hard pre-production item, not an option" |
| R2-L16 G2 ALB text | **RESOLVED** — criterion column and :686 recommendation struck |
| R2-L17 no INSERT on `audit.api_request_export` | **RESOLVED** — 0028 `meridian_audit_export` (NOLOGIN NOBYPASSRLS NOINHERIT, nobody a member; USAGE audit, SELECT api_request, SELECT/INSERT/UPDATE(exported_through, recorded_at) on the export row, no DELETE/TRUNCATE; app role still cannot write the watermark; clean downgrade). 4 pg tests. |
| R2-L18 ADR line cites drifted | **RESOLVED** — 0 `.py:NNN` cites left in 0045–0049 |
| R2-L19 ADR 0038 not updated for 0025 | **RESOLVED** — "Amendments" §8–11 |
| R2-L20 duplicated literal / unpinned constants | **PARTIAL** — 0026 constants pinned; `QB_MAPPINGS_UNAVAILABLE` still a literal in both processors and two exception classes (`qb_revenue_mappings.py:271`, `qb_usa_payroll_maps.py:226`) |
| r1 L-15 version/CHANGELOG | **PARTIAL (carried)** — CHANGELOG "Unreleased" has all three entries; `web/package.json` still `1.0.1` (2.0.0 proposed for the merge commit) |

## New findings in the delta

### CRITICAL — none
### HIGH — none

### MEDIUM — none new

### LOW (7 new)

- **R3-L1** Strict unposted refusal after the batch is booked. `_qb_preflight` is a superset of the
  unposted export, so `QbExportRefused` from `_generate_unposted` is reachable only if a `qb_*_map` row is
  deleted between the preflight and the unposted export (a concurrent edit on the new screen). When it is:
  thread path → `status: error` with the counts-only sentence, but the batch stays `completed` with no
  Unposted_QB CSV; worker path → the generic `_error_code(exc)` code. Not silent; honest state would be
  `failed` with `EXPORT_FAILED` on both paths. (`qb_revenue/processor.py:1317-1321`, `:1395`, `:1577`.)
- **R3-L2** The unposted pre-check is conservative on purpose: it requires 43006, and a clinic/class/
  catch-all row for every `(location_code, department)` pair with a non-zero posted amount, even when the
  unposted generator would emit nothing for that clinic group (zero unposted amount) or the pair only has
  debit lines. A false *block* (with the list) never a false pass. Worth one sentence in the refusal text.
- **R3-L3** qb-usa overrides: only the *raising* read is strict. `_load_overrides_supabase` still returns
  `None` when `postgres_session(db)` is `None` or `scope_org` is empty (`qb_usa_payroll_maps.py:318-324`),
  after which `load_qb_usa_payroll_maps` falls through to the local JSON file and then `source="code"` on
  Postgres too. Unreachable with `get_database(org_id=…)` today; close it with the same `strict` check.
- **R3-L4** `sectionFor` (`web/src/app/config/quickbooks/specs.ts:337-345`) maps the `account_codes` key
  (a payer type with no revenue account — an enrichment/`account_codes` sheet fix) to `qb-accounts`, the
  wrong table; a user follows the link to `qb_account_map` and cannot fix it there. Add
  `[/account_codes|payer.*account/, "providers"|null]` before the `/account/` rule, or point it at Mappings.
- **R3-L5** The provider P&L page on Postgres with empty/unreadable maps: `pnl-provider/page.tsx:206`
  sets `roster: {status: "error"}` and, by that page's own rule, shows "—" and no panel — a 409
  `QB_MAPPINGS_UNAVAILABLE` reads as "no data", with no link to the new screen. Stage 2 UX only.
- **R3-L6** Behaviour change for a NetSuite-only mx run on Postgres with a hardcoded payroll bundle:
  `qb_to_ns_departments` now answers `{}` (`payroll_processor.py:611-612`), so a file carrying QB class
  paths resolves departments through the stored roster with only a warning — no refusal, no envelope
  field. Consistent with "never the checked-in taxonomy", but the run's answer is silently different from
  before; either refuse like the QB run or say so on the result.
- **R3-L7** `error_code_for(error)` recognises the overrides refusal by string equality with the sentence
  (`qb_usa_payroll_maps.py:235`); a wording edit in one place silently turns it back into `FILE_UNREADABLE`.
  Carry a code on the exception/`_parse` tuple instead.

### INFO (not counted)
- `_qb_preflight` reports `str(e)` for a file that cannot be read before the batch (same as the run's own
  read did); on the worker path that becomes `EXPORT_FAILED` (a code), on the thread path the text.
- 0028 grants `SELECT` on the whole `audit.api_request` to the export role — by design (it ships them).
- `MERIDIAN_API_V3` on the worker: the only consumer is `worker_config_problems`; nothing starts a local
  queue or requires the dev sealing key in the worker.
- Shuffle hook runs before the `live` skip marking; module-scoped fixtures still built once per module.
- Log line claims "shuffled pg 993 / 0"; 56 `_pg.py` files collect 883 here.
- The log entry says Render's `uvicorn.access` line goes away at merge — true, and an operational change
  Andres should hear as such (below).

---

## Verdict — Stage 1 exit: **PASS**

Zero unresolved critical or high across all three rounds: r1 H-1..H-5 resolved (H-1 via R2-H1 now complete
on every table the exporters index, with a pre-batch check and a strict backstop, proven by real tests with
known-bad controls). Mediums: **0 new**; carried **4** (R2-M6, R2-M7 accepted trade-offs; R2-M8 pre-existing
Render leak, unresolved; R2-M10 needs Andres). Lows: **7 new**, carried unresolved **5** (R2-L3, L5, L9,
L14 partial, L20 partial) + r1 L-15 partial.

## Needs-a-human (for the stage report)

1. **R2-M8** — decide whether the one-line `str(exc)` → code fix on the Supabase push path
   (`qb_usa_runs.py:2049`) goes in before the aws→main merge. It is live on Render today.
2. **D9 / R2-M10** — the local + sandbox seed still carries the client's real QuickBooks account paths and
   clinic names (now plus a `Selfpay` label). Keep as "not PHI, not secret", or replace and recapture goldens.
3. **D22** — a second superadmin exists in production before any API client can be approved.
4. **D20 / D21** (R2-M6, R2-M7) — confirm the trade-offs as-is for Stage 2/3.
5. **Bounds** — redrive 3 / 7 days / 20 per hour, and now `/test` 10 per subscription / 60 per org per hour:
   OK?
6. **mx refusal UX** — still `failed` (re-upload), not `blocked` + retry as revenue has; the new screen makes
   it navigable but the choice is still yours.
7. **Render at merge** — with redaction always on, Render's log lines change shape (plain text + `exception=`
   summary) and uvicorn's access line disappears. If you rely on that access line for anything, say so
   before the merge; the alternative is `MERIDIAN_JSON_LOGS=1` plus a JSON-aware log view.
8. **Secrets Manager** `meridian-<env>/qbo-oauth` before the first `worker_enabled` deploy; Intuit production
   redirect URI (D18, D24). **Local `.env`** regenerated via `scripts/local_db_bootstrap.sh`
   (`MERIDIAN_DEV_QBO_TOKEN_KEY`).
9. **T:175** `meridian_worker` login role before production (now recorded as hard); the version bump
   (2.0.0 proposed) in the merge commit; Docker Desktop off (compose + worker image unproven); real-data JE
   parity on the encrypted volume (D8); BAAs, policies, pen test, auditor, signatures; D6, D10–D17, D19.
10. **Stage 3 export** — 0028 gives the exporter its role; the Stage 3 change must make its login role a
    member (NOINHERIT → `SET ROLE`) in the same change that builds it, or the prune still never fires.
