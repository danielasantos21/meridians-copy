# Phase 7 report — the SES transport ships; the flip waits for ECS

**Date:** 2026-09-16 · **Branch:** `aws-migration` · **Plan:** `docs/aws-migration-plan.md` Phase 7 · **ADRs:** [0014](../adr/0014-email-ses.md), [0025](../adr/0025-email-ses.md) · **Runbook:** [email-cutover](../runbooks/email-cutover.md)
**Critic:** round 1 FAIL (3 high), **PASS at round 2** (`6c2cb7d`); the round-2 mediums and lows are tracker rows, and the CI switch omission was fixed in the same commit that recorded the pass.

> **The headline, because it changed during the round:** Phase 7 delivers the SES transport,
> its IAM grant, its event plumbing and its runbook. It does **not** deliver the cutover.
> The flip now happens after Phase 9, on ECS, with the task role — see "Accepted risk".

## What was built

- **A fourth backend switch, `EMAIL_BACKEND ∈ {resend, ses, disabled}`**, the same fail-loud
  shape as the Phase 0c three: unset in a named environment raises at startup. `resend` is
  still the default and still what production runs.
- **`SesEmailSender`** — SESv2 `send_email`, one identity, one configuration set, two message
  tags (`env`, `template`), no `ListManagementOptions`. It inherits both templates from
  `_EmailSender`, so the invite and the run-complete notice are the same bytes whichever
  transport sends them.
- **Nothing a recipient can be read out of reaches a log.** The success line carries the SES
  message id and the template name; the failure line carries the SES error **code**. Round 1
  (P7-01) removed the last leak: `exc_info=True` put botocore's prose — which quotes the
  address — into `exc_text`, in a log group with 400-day retention.
- **The task role's grant is two resources and a condition** (`ses:FromAddress`), so a
  compromised api task cannot send as `billing@`, and a send that omits the configuration set
  is denied by IAM rather than delivered with no bounce publishing.
- **`scripts/ses_smoke.py`** sends one templated message and prints one message id. Round 1
  (P7-09) shut the other door: library logging is pinned to `CRITICAL` with a null handler, so
  Python's last-resort handler cannot write a botocore message to a terminal whose scrollback
  is pasted into a runbook.
- **A startup guard beside the Cognito one** (round 1, P7-03): `EMAIL_BACKEND=ses` with any
  `MERIDIAN_SES_*` missing refuses to boot, naming the variable. The lazy failure it replaces
  was the worst shape available — "invite sent", a row written, and nobody mailed.
- **The facade never raises** (P7-03). `_EmailServiceFacade.current()` is called after the
  invite row is written; a misconfiguration now returns
  `{"success": False, "error": "EMAIL_NOT_CONFIGURED"}` instead of losing the row.
- **One `From`, one display name, both transports** (P7-05). `EMAIL_FROM_DISPLAY_NAME`
  (default `Meridian`) is read by Resend and by SES, so the flip is invisible in the inbox.
  The `ses:FromAddress` condition compares the address, not the display phrase.
- **Links follow `SITE_URL`** (P7-07), with the production literal as the fallback — a
  staging deployment mails staging links instead of walking a tester into production.
- **Bounded in time as well as attempts** (P7-04): `connect_timeout=5`, `read_timeout=15` on
  the botocore `Config`, because five retries at botocore's 60-second default is five minutes
  of a web worker held open inside the request an admin is waiting on.
- **The SES ARNs take their region from the stack that owns the identity** (P7-11), and
  `ses_region()` refuses a concrete mismatch at synth. Two spellings of one region is a grant
  that denies every send after a deploy that reported success.

## Evidence

| What | Command | Result |
|---|---|---|
| Backend suite | `DATABASE_BACKEND=sqlite STORAGE_BACKEND=local AUTH_BACKEND=disabled pytest tests -q` | 2392 passed, 114 skipped (baseline at `0100a26`: 2382 / 114 — **+10 tests, no new skips**) |
| Infra suite | `pytest infra/tests -q` | 519 passed (+3) |
| Synth | `cd infra && npx cdk synth -c env=staging -c allowNoIdentityCenter=true -q` | clean |
| Lint / types / PHI lint | `ruff check . && ruff format --check . && mypy && python scripts/lint_no_phi_logging.py` | clean |
| The log-leak test can actually see a leak | `tests/test_email_ses.py::test_a_client_error_traceback_never_reaches_the_log` | the helper now formats every record through `logging.Formatter`, so `exc_text` is in scope; a synthetic `ClientError` quoting an `example.com` address is asserted absent |
| Both transports, one `From` | `test_both_transports_send_one_identical_from_string` | driven through a stub `sesv2` client and a stub `resend` module — not a monkeypatched `send` |
| Startup guard | `tests/test_security.py` SEC-07 | importing `web_app` with `EMAIL_BACKEND=ses`, `FLASK_ENV=production` and no SES vars raises, naming `MERIDIAN_SES_FROM_EMAIL` |

## Not yet run

Everything that needs AWS. Nothing in this phase has sent a message.

- The runbook has **never been executed** — §0.1 through §0.7 and the flip itself.
- No SES message has been sent from any Meridian process, in any environment.
- `infra/meridian/stacks/compute.py`'s grant has never been assumed: the ECR repositories are
  empty and no ECS task has ever run (`docs/migration-tracker.md`, the `deploy.yml` row).
- The `dkim=pass` / `spf=pass` / `dmarc=pass` header check in §0.7 is a plan, not a result.

## Accepted risk

- **Resend keeps sending, with no BAA, until after Phase 9.** This is the round's one real
  decision (ADR 0025 §3). SES needs an AWS identity; Render has none, and manufacturing one
  means a long-lived IAM user whose access key sits in a dashboard outside AWS for a few
  weeks, plus two things to remember to delete. The exposure is unchanged from today — the
  two messages carry no PHI (`docs/compliance/inventory-config-and-external-calls.md` §2.2)
  and neither may start to — and it is bounded by Phase 9 rather than open-ended. It is
  **provisional**: if Phase 9 slips far enough that the BAA gap outweighs the credential, it
  reopens.
- **`src/email_service.py` is still untyped** and outside `[tool.mypy] files`. Deliberate:
  typing a module in the commit that changes what it sends hides one change behind the other.
  Tracker row; `scripts/ses_smoke.py` **is** type-checked.
- **The 24-hour watch in runbook §3 is manual.** The bounce/complaint alarms belong to
  `observability.py`, which this phase does not own.
- **`UnconfiguredEmailSender` is cached like any other transport**, so a configuration fixed
  without a restart is not picked up until `reset()` or a redeploy. Acceptable: the startup
  guard means a deployed process cannot reach that state in the first place.

## Needs a human (Andres)

1. **Set `EMAIL_BACKEND=resend` in the Render dashboard on `meridian-api` before this branch
   reaches `main`.** Unset raises at startup and the next deploy crash-loops. This row does
   **not** close at the flip any more — `resend` is the correct Render value for the whole
   remaining life of the Render services.
2. **SES production access** — the sandbox has not been left. Support case, 1–2 business days.
   More runway than it looked, now that the flip is post-Phase 9, but still a blocker for it.
3. **Confirm the SNS subscription** on `meridian-shared-sns-email-events`. AWS will not do it;
   a human clicks the link. Until then every bounce fires into an empty topic and the only
   symptom is silence.
4. **Close the Resend account** — after the flip, which is after Phase 9, not at the end of
   this phase.
5. **The bounce/complaint alarm** is Phase 6 round 2's, and is now tracked as such
   (`docs/migration-tracker.md`): bounce > 5 %, complaint > 0.1 %, plus a
   `RENDERING_FAILURE` count — the one event with no bounce and no delivery.
