# Local-first plan: finish everything that needs no AWS, test locally, then finish the migration

Date: 2026-09-24 · Branch: `aws-migration` · Sources: `phase-11-plan.md` §4 tags, `phase-12-plan.md` §4
tags, `migration-tracker.md`, `runbooks/production-readiness.md` §12-13, phase reports 0-8.

**Order:** Stage 0 (git housekeeping) → Stage 1 (build everything tagged LOCAL-NOW, including the local
test harness) → Stage 2 (end-to-end local test) → Stage 3 (AWS, after cost approval).

**Guard rails (unchanged from the migration prompt):** nothing merges to `main` and nothing reaches
Render. New behaviour sits behind `DATABASE_BACKEND=postgres` / `STORAGE_BACKEND=s3|local` /
`MERIDIAN_API_V3` / `JOB_TRANSPORT` / `WORKER_PROCESSES`. Tasks tagged LOCAL-NOW† (in the Phase 11
plan) are **built and tested now, but switched on only at cutover**. Every stage ends with the phase
completion loop: tests green, Fable critic, Codex review, CHANGELOG, report, vault note.

---

## Stage 0 — Git housekeeping (first, about half a day)

| # | Step | Why |
|---|---|---|
| 0.1 | Confirm who owns Phase 12 right now: three other Meridian sessions are busy, and five worktrees are locked by pid 90651, which is no longer running | Avoid two sessions building the same task |
| 0.2 | Commit or drop the staged `create-run-form` hand port | It duplicates `main`'s `ec29299` and would conflict with itself |
| 0.3 | Merge `main` → `aws-migration` (6 commits, incl. `7a27e13`). Regenerate `openapi/meridian-v2.json` and `web/src/lib/api/schema.d.ts` instead of hand-merging them | Stay current. No Render impact |
| 0.4 | Recover the orphaned work: T14 commit `824841d` and the T13 admin-screen draft (worktree `adf7a…`); 30 uncommitted files of T21/T22 CDK and seed tooling (worktree `a22db…`); 2 test edits (`a47f…`, `a8bd…`) | This is finished or nearly finished work. The seed scripts are exactly what local testing needs |
| 0.5 | Prune worktrees that are 0 commits ahead with a clean tree (`a1260…`, `a8fc…`, `abca…`, `ac1d…`, `ad37…`, `ae68…`) | Tidy. Deleting them needs Andres's OK |
| 0.6 | Push `aws-migration` (21 commits not pushed) | Backup |

## Stage 1 — Build everything that needs no AWS

### 1A. Local test harness (build early, so everything after it gets tested against it)

| # | Item |
|---|---|
| H1 | `docker-compose.local.yml`: Postgres 17 (named volume) + api (`Dockerfile.api`) + web. LocalStack (S3 + KMS) is added only if decision D4 says so |
| H2 | `scripts/local_db_bootstrap.sh`: create the migrator role and database, set `MERIDIAN_APP_DB_PASSWORD` / `MERIDIAN_PHI_DB_PASSWORD` / `MERIDIAN_PHI_HMAC_KEY` from `.env`, `alembic upgrade head` |
| H3 | Postgres-mode gaps that block a local run: `create_organization` Postgres twin (T:115), `settings_manager` reading the wrong store (T:116), the `LOCAL_DEV_ORG_ID` org row |
| H4 | Synthetic seed (committed from Stage 0.4): `seed_sandbox_org.py` (org, members, roles, modules, mappings), `make_sample_revenue.py`, synthetic QB USA payroll fixtures (T:62). No client data, no PHI |
| H5 | Local dev mode documented in README + `.env.example`: `APP_ENV=development DATABASE_BACKEND=postgres STORAGE_BACKEND=local AUTH_BACKEND=disabled EMAIL_BACKEND=disabled MERIDIAN_API_V3=1`. Replace the stale `run_migrations.py` / Jinja text (README:247-261) |

### 1B. Phase 11: the locally buildable set (the plan estimates about 25-30 days)

- **Build and merge on this branch (LOCAL-NOW):**
  - A1-A3: process manifest + registry, snapshot test that keeps `/api/v2/processes` byte-identical. A1 also adds `max_bytes` / content types to `InputSpec` (needed by Phase 12 §3.9).
  - B0-B3: purity lint; move the revenue / mx / qb-usa processors out of `web_app.py`, checked with golden JE diffs on synthetic data. This must land **before** the Phase 9 rehearsal freeze.
  - C3: state-object store + `phi.open_state()` audit.
  - D1-D3: `JobMessage`, `InProcessQueue`, Alembic **0011**, the worker loop, and kill/redelivery tests.
  - D6: worker image.
  - E1: Alembic **0012** idempotency.
  - F1-F2: conformance suite, `new_process.py` scaffold + docs.
  - G1: delete the 5 dead payroll families (approved 2026-09-22).
  - G6: parked tracker rows (CX-BE-05 before the SES flip).
  - H1-H2: CDK queue/worker/alarms behind `worker_enabled=false`, `cdk synth` only.
- **Build now, switch on at cutover (LOCAL-NOW†):** C1, C2, C4-C7 (upload layout, state classes, per-process snapshots), D4 (`enqueue()` on `JOB_TRANSPORT=inprocess`), D5 sweeper, E3 idempotency key, G3 MFA pending store. Each one is gated on `database_is_postgres()`.
- **Alembic chain:** 0011 revises 0010, and 0013 is re-pointed to 0012. Any local database stamped at 0013/0014 is rebuilt; no deployed database exists.
- **F3 (generic React create form):** build it on this branch. It reaches Render only through the eventual aws→main merge.

### 1C. Phase 12: the rest of the local work

| Task | Note |
|---|---|
| T14 | Merge `824841d` (Stage 0.4) |
| T13 | Admin screens: finish the recovered draft; vitest + axe + Playwright against the local API |
| T15 | Security suite + known-bad controls + zip-bomb bound |
| T17 | Runbooks: revoke client, onboard partner, webhook DLQ triage |
| T18, T19 | **Unblocked by 1B**: process endpoints and outbox/event emission, on the in-process queue and a PutEvents fake |
| T21 | CDK, synth + infra tests only (needs `cdk` installed, decision D2) |
| T22 | Sandbox tooling: written and dry-run tested (merged in Stage 0.4) |
| T28 | Local parts of the cleanup: tracker drain, dead flags, READMEs, layout doc, control matrix |
| T20 | **Not now.** React stays on v2 until cutover (phase-12-plan:627) |

### 1D. Items left over from Phases 0-8 that need no AWS

| Group | Items (tracker line) |
|---|---|
| Dead code / duplicates | `DATABASE_MODE` alias (T:30), `LOCAL_ORG_ID` fallback (T:34), no-op cache invalidators (T:33), duplicate `PgWriteRefused` (T:74) |
| Auth screens and state | `MFA_SETUP` + `NEW_PASSWORD_REQUIRED` screens (T:85), invite-redeem screen + route (T:209, closed; cited as T:86 before the T28 renumbering, which is now the Macie row; 17 codes are waiting), TOTP QR code (T:84, decision D3), members `ListUsers` join against the fake (T:31/T:114), FastAPI rate limiter → Postgres (T:98) |
| Logging (deadline 2026-10-31) | JSON formatter, redacting filter, botocore pin, all-requests heartbeat, issuer in audit rows (T:51/52/59/134/139/144) |
| Storage / PHI | S3 upload tag writer + GuardDuty tag reader, tested with moto/Stubber (T:87/88); `phi.hmac_key()` from Secrets Manager with an env fallback (T:99) |
| CDK / infra (synth only) | `COGNITO_*` in the task definition (T:102), `emailBackend=resend` rollback flag (T:143), base images pinned by digest + CA checksum (T:153), KMS log-group condition (T:154), SES alarms (T:39), log-retention policy (T:60/65), backup-freshness checker (T:160), `cognito_export/import.py` (T:159), `deploy.yml` input (T:124), noisy `infra-diff` (T:136), `staging_session.sh` (T:140) |
| Quality gates | mypy + `email_service.py` (T:40/42), ruff `S` (T:43), G-8 route lint (T:132), org-scope baseline (T:77), split the fake-Supabase tests (T:75), port the live RLS tests to pg_fixture (T:72), PHI tests into the CI `migrations` job (T:80), marketing lint exclusion (T:61) |
| Data | `config/*.json` → Postgres (T:44/63), `source_transactions` → `phi` schema (T:79), upload-history / roster fixes (T:106/107/122) |
| Docs | Stale tracker/readiness/status rows (T:47/125/138/145, PR §13, status §25-28), `patient_ref` row closure (T:78), custody-record skeleton + in-transit position-paper draft (Andres signs) |
| **Held back** | Post-parity schema revisions (T:70/71/73/100/105/112): write them now, **merge only after the port gate**, which needs Andres's workbooks |

## Stage 2 — Local end-to-end test (after Stage 1 closes)

1. `docker compose up`, run the bootstrap, and seed two synthetic orgs.
2. **Every process end to end in the React app** (localhost:3000) with synthetic inputs: upload → preview → run → JE download. Compare against golden output.
3. **Worker:** kill mid-run → redelivery → exactly one result. Retries never double-post a JE (idempotency).
4. **API v3:** machine client (fake Cognito keys), scopes, masking without `phi:read`, another org's run → 404, quotas/lockout, webhooks to a local receiver (SSRF refusal, signature replay rejected).
5. `pytest` full suite + `tests/security` + `--known-bad` (all red), web tests, `cdk synth` + infra tests.
6. Write the results into a local-test report. Every failure goes back into Stage 1.

**Not testable locally (proved in Stage 3):** real Cognito sign-in / MFA / federated IdPs, SES delivery,
GuardDuty malware tagging, WAF/CloudFront, pre-signed POST against real S3, the real-data JE parity check
(no workbooks).

## Stage 3 — Finish the migration on AWS (after cost approval)

This follows the existing plan: Phase 1-8 deploys and verify lists (PR §12), Flip 1 (Cognito),
Phase 9 cutover (ask first), Phase 10 decommission (ask first). Then the Phase 11 switch-ons
(C/D4/D5/E2/E3/G3, I1-I5, G4-G5: Flask and `templates/` deleted) and Phase 12 T18 live, T20, and T23-T27.

---

## Decisions waiting on Andres (Stage 0-2 need these)

| # | Decision | Default if no answer |
|---|---|---|
| D1 | Who owns Phase 12 right now (3 busy sessions, stale locks)? OK to recover and prune the worktrees in Stage 0.4-0.5? | Wait. No worktree gets touched without a yes |
| D2 | Install `aws-cdk` CLI (npm) for `cdk synth` | Skip synth; infra unit tests only |
| D3 | Add a QR-code library for TOTP setup (new dependency) | Show the secret as text; no QR |
| D4 | Local storage: plain disk (`STORAGE_BACKEND=local`) or LocalStack for S3 + KMS | Plain disk. LocalStack later if needed |
| D5 | Start Docker Desktop (the daemon is off) | Homebrew Postgres 18 (target is 17) |
| D6 | `.env.example` is permission-denied for Claude: allow the edit, or edit it by hand | Claude writes the variable list into the README; you paste it |
| D7 | G1 detail: keep or delete the `src/adp_*` / `booking_*` processors and scopes | Keep them; delete only the route families |
| D8 | Real-data JE parity needs the rehearsal workbooks + a production dump (PHI on the Mac) | Synthetic data only; parity is proved on staging |

---

## Provisional decisions (taken 2026-09-24, Andres said "do that" without answering D1-D8)

| # | Taken | Trigger to revisit |
|---|---|---|
| D1 | No session owns Phase 12: the other live sessions (meridian-5c, ns-proccess-qb-f1) confirmed they work in `~/Desktop/Meridian`, and pid 90651 (the worktree locks) is dead. Stale work is **copied** out of the worktrees; no worktree is unlocked, pruned or deleted | Andres says prune |
| D2 | No `cdk` install; infra unit tests only | Andres OKs the install |
| D3 | No QR library; TOTP secret shown as text | Andres OKs the dependency |
| D4 | `STORAGE_BACKEND=local` | S3-specific behaviour needs a local proof |
| D5 | Docker daemon off, so Homebrew Postgres 18 / `pg_fixture`; the compose file is written but only proved once Docker runs | Andres starts Docker |
| D6 | `.env.example` not edited; the variable list goes in the README | Andres grants the edit |
| D7 | Keep the `src/adp_*` / `booking_*` processors; delete only the route families | Andres says delete |
| D8 | Synthetic data only | Workbooks arrive |
| D20 | **Module access fails CLOSED** (critic M-4): on `DATABASE_BACKEND=postgres` an unreadable org-module list is the empty set; `/api/v3` machine callers fail closed on every backend. The Supabase/Render path keeps its fail-open answer until Phase 10 (tracker T:199) | Andres wants Render changed before cutover, or a transient-error outage shows users an empty menu often enough to matter (then 503 instead of an empty set) |
| D21 | **Auth lockout fails CLOSED; quotas fall back to in-process counting** (critic M-5): an unreadable failure count is `503 PERSISTENCE_UNAVAILABLE`; failure counts and caps count per task while the store is down (the `PgRateLimiter` rule, never unlimited). A locked shared-egress ADDRESS admits a verified client whose own IP allowlist covers it (L-4) | Store outages cause user-visible 503s in production, or a pen test shows the allowlist exemption abused |
| D22 | **`SELF_APPROVAL_ALLOWED` defaults to refusing outside development** (critic M-6): a second superadmin approves in staging and production; allowed only with `APP_ENV=development`; `True`/`False` still pin it | Andres rules a one-person approval acceptable in production until a second superadmin exists (pin `True` in a reviewed commit, ADR 0037) |
| D23 | **`audit.api_request` retention: 400 days in RDS, then pruned — but only rows the audit export has recorded** (critic L-9). The plan (ADR 0040 d4) keeps six years in the Object-Locked bucket, so the 400-day prune is gated on the export watermark; with no export yet (T:57 (c)) nothing is deleted | The export is built (Stage 3), or an auditor wants the rows in RDS longer |
| D24 | **QuickBooks OAuth env on AWS rides `worker_enabled`** (critic M-10): the flag that creates the token key; secret `meridian-<env>/qbo-oauth` created by hand on the `logs` CMK; `QBO_ENVIRONMENT` production/sandbox by environment; redirect URI from the public hostname | QuickBooks is needed on AWS before the worker is switched on (then a separate flag) |
| D25 | **The api's JSON log format is on by default only on Postgres** (critic L-16); Render opts in with `MERIDIAN_JSON_LOGS=1` | Andres wants the JSON logs on Render at the merge (set the variable) |
| D26 | **One AEAD helper (`src/aead.py`, AES-256-GCM)** replaces the challenge store's hand-rolled cipher (critic L-1); in-flight challenge rows simply stop opening (sign in again) | A second construction is ever proposed (it must use this helper) |

## Progress log

- 2026-09-24 Stage 0.2 `d5b4a69` FECHA port committed · 0.3 `b6f222a` main merged (8 conflicts; full suite 2927 passed / 5 failed, all `DATABASE_BACKEND must be set`) · 0.4 T14 cherry-picked; T17/T21/T22 recovery and the T13 finish are in progress
- 2026-09-24 T13 finished on `worktree-agent-a5aea2481920af2ca` @ `6ac2522` (web 1078 passing), waiting to merge. **New Stage 1 item (T12 gaps found by T13):** v3 endpoints for usage metrics (requests/day, error rate), a partner-BAA record/revoke endpoint + screen (§3.8 item 9), and a rotation-in-progress flag on the client resource, then wire them into the T13 screens
- 2026-09-24 **Stage 0 closed.** T17 `c7047b9`, T21 `ac8faa1` (synth only), T22 `55134a3` (write only), test-env fix `c30c943`, T13 merged `6c06bd5`, pushed. pytest 3001 passed / 0 failed, infra 629, web 1078. New Andres item **D9**: sandbox seed uses the client's real clinic names (from `mappings.example.xlsx`, as ADR 0041 says), so keep them or switch to fictional ones? Default: keep until a partner sandbox exists
- 2026-09-24 Stage 1 wave 1 started: harness (H1-H5), P11 registry (A1-A3, B0), P11 queue + Alembic 0011/0012 (D1, D2, E1), P12 T15 + T12 gap endpoints
- 2026-09-24 P11 A1-A3, B0 merged (pytest 3079 passed). Follow-ups for the wave-2 registry agent: (a) no runtime parse of `migrations/` at import; CHECK values live in the registry, and a CI test holds them equal to the chain; (b) the qb-usa `.csv` input also accepts `application/vnd.ms-excel`; (c) processors raise `ProcessInputError`, not `ApiError` (boundary confirmed)
- 2026-09-24 P11 D1, D2, E1 merged (chain 0010→0011→0012→0013→0014). **Security fix queued (priority 1):** 0013's `GRANT meridian_api_lookup TO CURRENT_USER` inherits, so the migrator reads every org's `api_clients` / `partner_baas`; use `WITH INHERIT FALSE, SET TRUE` + `SET ROLE` in the downgrade (0011's pattern). Also queued: `tests/test_pnl_rls_live.py` connects to `SUPABASE_DB_URL` from `.env` (live DB) → port it to pg_fixture (T:72); a worker DB login role (for H1/CDK); C1 must write `inputs.object_versions`; E2 decides Intuit requestid reuse on retry; ADRs 0029/0030/0032
- 2026-09-24 Stage 1A harness merged `63c9b6f`: `scripts/local_db_bootstrap.sh` + `scripts/seed_local_dev.py` (2 synthetic orgs), Alembic 0015 `create_organization`, settings on Postgres, fixed-UUID dev user. Proved end to end on Homebrew PG18 (v1/v2/v3 health, v2 reads/writes, Next proxy). Compose file unproven (Docker off). **Gaps queued:** `qb_revenue_mappings.load_revenue_maps` has no Postgres path (would use hard-coded maps); `routes._test_mode_flags` reads the file; the bypass org name is hard-coded; T:62 synthetic QB-USA fixtures go with the Stage 2 golden work; `MERIDIAN_LOCAL_PGDATA` location needs Andres (D10)
- 2026-09-24 Combined branch `63c9b6f`: pytest 3211 passed / 117 skipped / 0 failed (live-DB test excluded)
- 2026-09-24 P12 T15 + T12 gaps merged: Alembic 0016; security 498 green, `--known-bad` 456 red / 0 passed; pytest 3278 passed. Andres items **D11**: zip-bomb limits (10k entries / 1 GiB total / 250:1 above 10 MB); a BAA picker in the client form? Queued: `/me` exposes an `is_superadmin` flag so the BAA tab doesn't need an audited probe on every visit; T18/T26 deferred tests are in a tracker row
- 2026-09-24 Security fix merged (0013 no longer inherits; conftest guard: no .env, loopback-only psycopg2, `MERIDIAN_LIVE_DB_TESTS=1` to opt in; T:72 closed)
- 2026-09-24 0015/0016 made non-inheriting too (`c…` fix, caught by the new chain-wide test). P11 C3, D3, D6 merged `7a21ca9`: pytest **3358 passed / 0 failed**. Worker follow-ups: **E2 blocker**: qb-usa `qbo_push` starts from `completed`, but `claim_run` refuses terminal runs, so it needs a claim variant; D4 must enqueue from `draft` and let the worker set `running`; H1 worker env vars `MERIDIAN_JOBS_QUEUE_URL` / `_DLQ_URL` / `MERIDIAN_WORKER_ID`; C2 race: `PostgresRunStore.upsert` overwrites `run_state` wholesale (it could drop `state_objects`)
- 2026-09-24 Logging hardening merged (T:51/52/59/133/138/143 closed); the worker entrypoint is wired to `log_setup.configure_logging()`. Open: the web container writes no JSON yet (new tracker row); first ECS deploy needs `-c structuredLogsLive=true`
- 2026-09-24 P11 B1-B3 merged: 3 processors out of `web_app.py`; golden JE diff 20 revenue + 4 MX + 2 qb-usa CSVs byte-identical (synthetic inputs); registry no longer reads `migrations/` at runtime; per-extension content types. Found and fixed: qb-usa FastAPI path crashed on Flask `g` (parse + `submit_review`); `run_port_gate.py` output could land in the repo's `output/`. Queued: a magic-byte file signature check in the input validators (C1 follow-up; the error becomes `FILE_TYPE_INVALID`); golden coverage for the MX `excel` method and the qb-usa parser (needs synthetic ADP files, with T:62)
- 2026-09-24 Merged: auth leftovers (0017; T:83/84/85/86/98/31/114 closed; G3 done), P11 C1/C2/D5 (uploads by version behind the GuardDuty gate, declared run-state classes, sweeper), local gaps + dead code (T:30/33/34/74/106/107/115 closed). `a4…`: pytest **3545 passed / 0 failed**, drift in step. Andres items: **D6** `.env.example` line 47 still names `LOCAL_ORG_ID`; your `.env` may need `DATABASE_MODE=local`→`DATABASE_BACKEND=sqlite` and `LOCAL_ORG_ID`→`LOCAL_DEV_ORG_ID`. **D12**: create still validates/parses unscanned request bytes until D4/C5 move that into a job (accept, or wait on the scan now?); cancelled uploads kept 30 days by lifecycle. Queued: MX `include_inactive` + a Reactivate toggle; config/*.json still read on postgres (qb_revenue processor `AppSettings()` ×4, `web_app.py:706`, `booking_je_exporter.py:42`, mso/allocations/roster/provider maps/prefs)
- 2026-09-24 Wave 3 started: C4+C6 (+ qb_revenue AppSettings → org settings), C5 (qb-usa snapshots + drop the legacy cache), E3 + a `claim_run` variant for post-completion jobs (E2 blocker), F1-F3
- 2026-09-24 Merged: infra leftovers (T:154/102/143/39/60/65/160/124/136/140 closed, Cognito sign-in IAM), synthetic qb-usa fixtures + goldens (T:62 closed, MAX_SKIPPED 122), G1 guards (families already deleted 09-22) + G6 (`with_org` refuses non-members, email escaping, invoice render race, traceback ratchet). Ten new traceback sites fixed. **pytest 3816 passed / 0 failed**, infra 665, mypy clean; pushed. Andres items: **D13** run `scripts/pin_rds_ca_bundle.py` and compare the digest with AWS's published list (`Dockerfile.api` refuses to build until then; the local compose build skips it); **D14** +$3.10-3.70/month production alarms (unapproved); **D15** a nightly Cognito export into the 7-year Object-Locked bucket keeps every email 7 years: OK?
- 2026-09-24 P11 E3 merged (0018 `claim_post_completion` for `qbo_push`, Idempotency-Key on v2 execute/retry, DUPLICATE_INPUT warning, Intuit requestid rotation after a definite failure, ADRs 0029/0030/0032). **Queued (correctness):** a compare-and-set on the run's step so two concurrent executes with different/no keys can't both pass (a double JE risk); a stale `pending` idempotency key times out (15 min); qb-usa DUPLICATE_INPUT at preview (with F3/C5)
- 2026-09-24 P11 C4 + C6 merged (real handlers; worker path byte-identical to the goldens; kill/resume tested; T:44 progress; B1 mypy override gone). **Parity gaps before switch-on (queued, build now):** the worker path must keep today's downloads (NetSuite CSVs to artifacts, the enriched/validation/revenue workbooks to the phi bucket) and show mid-job progress (a fenced progress callable on `JobContext`); otherwise the screens regress at cutover
- 2026-09-24 P11 C5 done on `worktree-agent-a3ddbef9f2bc5ba99` @ `94ec5c1` (merge after the C4×E3 integration fix): qb-usa parse/execute as jobs, 3 snapshots (review + preview personnel, gate_offenders phi via `phi.open_state`), legacy cache removed on RDS, the worker-B JE CSVs byte-identical. Queued: D4 redelivery of in-process messages; C7 batch reuse on resumed execute. **D16 (Andres/critic):** jobs act for the run's creator only; if the creator leaves the org, the run can't proceed. Widen `authorize_job` to any current member with the process permission (the actor on the message)?
- 2026-09-24 C4×E3 fix: 0018's `app.input_digest` index ran as `meridian_job_control` without EXECUTE, so every API-started run would fail to claim (caught in integration; regression test added). F1-F3 merged (conformance suite, `new_process.py` scaffold, generic create form + custom steps), then C5. T19 (outbox events, 0019) is being integrated. **T19 open (default: build both before T24):** `expire_stale_runs` and API-side `set_state` change run state without an event; the worker CDK needs `WEBHOOK_EVENT_BUS` + PutEvents + the 5-min outbox sweep schedule (sent to the H1-H2 agent)
- 2026-09-24 Integration fixed (C5×F1, C5×E3: a real bug where DUPLICATE_INPUT was lost on the RDS path), T19 merged (0019), web JSON logs + MX include_inactive merged. **pytest 4064 / 0 failed, web 1184, drift in step**; pushed
- 2026-09-24 Wave 4 started: D4 enqueue + in-process redelivery + execute compare-and-set + stale idempotency key + magic-byte check; C7 + worker-path parity (downloads, progress); T19 follow-ups (sweeper/set_state events); quality gates + stale docs; G2 remaining Flask routes + `/api/v1` non-health deletion (approved 09-22)
- 2026-09-24 P11 H1/H2 merged (worker infra behind `worker_enabled=false`; synth byte-identical off; T19 infra behind `enableApiPlatform`; web `APP_ENV`; fixed a cross-stack task-revision export that would have broken the first deploy). infra 734 passed. Costs if enabled: worker ≈ $15.40/env/month (inside the approved "with worker" estimate); **D17** outbox sweep as its own 5-min task ≈ $6/env/month. Queued: move it into the always-on worker as a new message kind (≈ $0) unless Andres prefers the separate task
- 2026-09-24 T19 follow-up merged (0020: sweeper + set_state emit exactly once; `run.expired` event type). pytest 4082 / 0 failed
- 2026-09-24 P11 G2 merged: 23 dead Flask routes deleted (incl. `/api/v1` non-health, `/api/mso/*`, the ADP tab), `/auth/google|microsoft|callback` ported to FastAPI; 82 Flask rules remain, each tied to I2/I3/G4/G5. pytest 4152 / 0 failed. **D18** QuickBooks connect: provisional option 2 (a React button + `/api/v2/qbo/connection`), being built; Andres registers the production redirect URI at Intuit
- 2026-09-24 Quality gates merged: ruff `S` on (one real finding fixed: a QBO query date literal), route-ownership lint (G-8), T:75/T:80/T:61/T:78 closed, readiness §13 now Phases 0-8, new `docs/reports/status-2026-09-24.md`, DRAFT in-transit paper + custody template (**Andres signs; 2 VERIFY items**). The per-file `S` baselines for D4/C7 files and the T19b `process_runs.py` entry come off during T28. pytest 4186 / 0 failed; pushed
- 2026-09-24 P11 C7 + parity merged (one batch per run on resume/retry incl. qb-usa; worker-path downloads equal the thread path's; fenced `JobContext.progress`). pytest 4225 / 0 failed
- 2026-09-24 D18 QuickBooks connect merged (React settings card, `/api/v2/qbo/connection`, 0021 audit, Flask `/qbo/*` deleted). pytest 4266, web 1204. **Andres (D18):** set `QBO_CLIENT_ID`, `QBO_CLIENT_SECRET`, `QBO_ENVIRONMENT` (+ optional `QBO_REDIRECT_URI`/`QBO_CALLBACK_PATH`), and register `https://www.meridiansgrp.com/api/v2/qbo/connection/callback` + `http://localhost:3000/api/v2/qbo/connection/callback` at Intuit; `.env.example`'s old `QBO_REDIRECT_URI=…:5050/qbo/callback` line must change (Claude can't edit that file). **Security queued:** QBO OAuth tokens sit in plaintext columns (disk encryption only), so envelope-encrypt them with KMS/app key before cutover
- 2026-09-24 D4 + compare-and-set + stale keys + redelivery + magic bytes built; being rebased onto current head (0022, tolerant Excel container check)
- 2026-09-24 D4 merged (enqueue behind `JOB_TRANSPORT`/`WORKER_PROCESSES`/`PROCESS_SUBMISSIONS_PAUSED`; in-process redelivery 0022; execute compare-and-set `RUN_STATE_CHANGED`; stale idempotency keys expire in 15 min; file-signature check, tolerant across Excel containers). The D4 agent's own merge of aws-migration into its branch was blocked by the permission system; the orchestrator did the usual branch→aws-migration merge instead. **All gates green: pytest 4379 / 0 failed, web 1204, lints, drift**
- 2026-09-24 Wave 5 started: E2 (qbo_push job + 202 + polling), T18 (v3 process endpoints), D17 outbox sweep inside the worker + QBO token envelope encryption
- 2026-09-24 D17 + QBO token envelope built (branch `worktree-agent-a87374d36f77a8a53`): the outbox sweep is an `outbox_sweep` job-queue tick the worker handles (≈ −$6/env/month; `ApiStack._outbox_sweep` gone); QBO tokens sealed on RDS (ADR 0044, revision 0023, `meridian-<env>-kms-tokens` behind `worker_enabled`, ≈ +$1/env/month). Env vars: `QBO_TOKEN_KMS_KEY_ARN` (AWS, set by `compute`), `MERIDIAN_DEV_QBO_TOKEN_KEY` (laptop only). Flag-off synth byte-identical.
- 2026-09-24 D17 + QBO token envelope encryption merged (0023, ADR 0044; outbox sweep is a worker message kind ≈ $0; tokens sealed with AES-GCM + KMS-wrapped data key on RDS; `scripts/encrypt_qbo_tokens.py` re-seals old rows). pytest 4425 / 0 failed. **Andres:** D17 ≈ $0 placement OK? token CMK ≈ +$1/env/month or reuse an existing key (ADR 0044); laptop needs `MERIDIAN_DEV_QBO_TOKEN_KEY` (32 random bytes, url-safe base64) to connect QBO locally
- 2026-09-24 E2 merged (qbo_push job; every QBO journal goes through the idempotency ledger; 202 + React polling; `HANDLER_PENDING` empty; row 49 closed) and T18 merged (v3 process endpoints generated from the manifests; pre-signed uploads; malware gate; BOLA/idempotency/rate tests). **All gates green: pytest 4512 / 0 failed, web 1214, lints, drift**; pushed. Andres items: **D19** v3 job-start cap 30/org/process/hour OK?; qb-usa stays off v3 until T20
- 2026-09-24 Cleanup wave: fake "Send to QuickBooks" on revenue/mx, E2 open items (in-process push redelivery, late duplicate execute → DLQ alarm, unclaimed SQS push UX), zip-bomb breaker, remaining ruff S baselines; T28 local (tracker drain, READMEs, layout doc, control matrix) + post-parity schema revisions on a HOLD branch
- 2026-09-24 Cleanup merged: T28 local (tracker drained: 82 closed / 96 open by stage), catalogue-driven QBO button (no fake button), E2 open items (0024), zip-bomb breaker, ruff S baselines gone, flaky tamper test fixed. Held: `hold/post-parity-schema` (renumber its 0024 → 0025 at merge; merge only after the port gate). **Stage 1 build complete, all gates green:** pytest 4543 / 0 failed, `--known-bad` 503 red / 0 passed, web 1219, ruff/format/mypy/lints/drift clean, single Alembic head 0024. Next: Stage 1 close = Fable critic + Codex review of `463b9d1..HEAD`
- 2026-09-25 **Stage 1 critic round 1: FAIL** (0 critical, 5 high, 11 medium, 17 low; `docs/reports/critic-stage1-r1.md`). Codex review hit its usage limit mid-run (retry after 04:45); its partial notes flagged journal-posting retry races (= H-4) and **concurrent input preparation**. Fix wave: H-1 revenue maps; H-3/H-4 QBO push ledger + concurrency; H-2 webhook fakes/drainer; H-5 test order + input-prep race + worker lows; security fail-open mediums + ADRs
- 2026-09-25 Critic H-3/H-4 merged (ledger on every RDS push incl. unrouted; QBO_IN_FLIGHT; heartbeat DB error = not extended; fence aligned). Found: revenue golden + worker-downloads tests are **date-dependent** (green 09-24, red 09-25, Calendar sheet); fix agent dispatched
- 2026-09-25 Critic H-2 merged (0025; webhook fakes refused outside dev; local sealed secrets + drainer; redrive ≤3/7 days/20 per hour; stalled-delivery sweep). **Andres:** redrive limits OK?; local env now needs `MERIDIAN_DEV_QBO_TOKEN_KEY` (bootstrap generates it)
- 2026-09-25 Critic H-1 merged (QB_MAPPINGS_UNAVAILABLE; local seed fills qb_*_map; goldens byte-identical from DB maps). Golden harness fix merged (it masked "any cell dated today", which captured a Calendar row on 09-24; now masks only the labelled run stamps; proven across 6 fake dates). Queued: the same silent-fallback fix for payroll maps + v3 mapping kinds for the sandbox (agent running). **D9** (real clinic names in local seed) still open
- 2026-09-25 Critic security fixes merged (D20-D26 recorded above; 0027 re-chained onto 0025). **All gates green: pytest 4668 / 0 failed, infra 753, web 1219.** Andres: create `meridian-<env>/qbo-oauth` before the first `worker_enabled` deploy; confirm D22 (production needs a second superadmin to approve API clients); `MERIDIAN_JSON_LOGS=1` on Render for JSON logs after merge; version proposal for aws→main = one bump to **2.0.0** in the merge commit. Remaining critic r1 items: H-5 + input-prep race + worker lows (agent running), payroll maps fallback (agent running)
- 2026-09-25 Critic H-5 + worker lows merged: test isolation (5 orders, 829/0 each); **Codex's input-prep race was real** (shared scratch dir deleted mid-check; now per-pin dirs + fail only unpinned drafts; flaky test 70/70); 0026 claim `<=` + sweeper index; the 0023 downgrade guard never fired (RLS hid rows), now fixed; qb-usa job revalidates; local storage org-confined. **pytest 4714 / 0 failed, `--known-bad` 530 red / 0 passed**; pushed. Open for Stage 2: local publish/download refuse local storage, so storage isolation isn't exercised end to end locally
- 2026-09-25 Payroll half of H-1 + v3 QuickBooks mapping kinds merged (mx refuses hardcoded maps → `failed` with QB_MAPPINGS_UNAVAILABLE; 6 new v3 kinds; seeds go through the service functions). **All gates green: pytest 4784 / 0 failed, `--known-bad` 587 red / 0 passed, infra 753, web 1219**; pushed. Starting critic round 2; Codex re-run after 04:45. Andres: mx refusal is `failed` (no `blocked` state in mx); want a real blocked + retry? `ts_benefit_override` read failure still falls back silently (not an H-1 table)
- 2026-09-25 **Critic round 2: FAIL** (0 critical, 1 high R2-H1, 10 medium, 20 low; `docs/reports/critic-stage1-r2.md`). r1 H-2..H-5 resolved; H-1 partial (partial maps still produce silent wrong QBO JEs; pnl_facts on defaults). Fix wave: R2-H1 complete; R2-M4 mapping screens; R2-M1/M2/M3/M5/M9 + lows
- 2026-09-25 R2-M4 merged (`/api/v2/config/qb-*` routes, /config/quickbooks screen, missing-mappings run screens, maps source on results; fixed a delete-confirm bug on both config screens)
- 2026-09-25 R2-H1 merged (every mapping row a run needs is checked before booking; P&L, overrides and the MX column map refuse fallbacks), refusal sentences for `incomplete`/`column_map_*`, R2 hardening merged (0028; worker webhook config fail-closed; `/test` caps; no false in-flight hold; **redaction always on, so Render log lines become plain text and uvicorn's access line goes away at merge**; CI random test order). **All gates green: pytest 4929 / 0 failed, shuffled pg 993 / 0, `--known-bad` 656 red / 0 passed, infra 754, web 1247**. Critic round 3 (delta) next; Codex after 04:45
- 2026-09-25 **Critic round 3: PASS** (0 unresolved critical/high across rounds 1-3; `docs/reports/critic-stage1-r3.md`). Carried: R2-M8 (Supabase push `str(exc)`), 7 new lows (R3-L1..L7), L14/L20. Cleanup agent dispatched; Codex review re-run after 04:45 is the last Stage 1 gate
- 2026-09-25 Critic r3 cleanup merged (R2-M8 Supabase push codes: **Render's push error text changes**; exact unposted pre-check; post-booking refusal handled; benefit overrides strict; structured parse codes; mapping 409s; P&L banner). pytest 4979 / 0 failed. Queued: failed-run restore of a superseded booking may violate one-live-booking on Postgres (agent running). Stage 2 local test running on 0e50195
- 2026-09-25 **Stage 2 pass 1** written (`docs/reports/stage2-local-test-2026-09-25.md`): all JE CSVs byte-identical, worker kill/resume OK, v3 + webhooks + SSRF OK, but **not ready**: F1 `npm run dev` 500s (instrumentation node:fs); F2 React revenue form sends an empty JE date (blank dates in every CSV); F3 unposted JEs silently skipped without `config/mappings.xlsx`; F4 no qb-usa roster/overrides in the seed + misleading FILE_UNREADABLE; F5 local storage has no downloads; F6 laptop client approval 500; F7 webhook run events ignore the client's allowed processes (security); F8-F15 lows. Fix wave, then Stage 2 pass 2 without workarounds
- 2026-09-25 Failed re-booking restore fix merged (real bug: a failed re-run of a booked file left the period with NO live booking; also on Supabase, where the same fix applies)
- 2026-09-25 Codex review attempt 2 hit its usage limit again (next window 09:48). Partial: it judged the input-prep and journal-posting fixes correct and was checking crash windows between the queued marker and queue delivery; agent dispatched to settle that. **Andres:** Codex quota is the blocker for the Codex gate (more credits, or accept the Fable critic PASS + a narrower Codex pass after 09:48)
- 2026-09-25 S2 fixes F1/F2/F8/F9/F10/F14 merged (next dev boots + CI dev-boot check; blank JE date resolved on every backend — real bug on Render too; DUPLICATE_INPUT shown; MX rate optional for processed workbooks; per-process stepper; copy)
- 2026-09-25 S2-F3 merged (0029: unposted config in config_clinic_groups; blocks with UNPOSTED_CONFIG_UNAVAILABLE; truthful unposted status). pytest 5007 / 0 failed. Stage 3 note: the Phase 8/9 data copy must fill `hospital_location` + `primary_location_code` for real orgs (Supabase lacks them) or their unposted runs block; the revenue workbook's lookup tabs still read the sheet (Excel tabs only, not JEs)
- 2026-09-25 Crash-gap fix merged (0031, re-chained onto 0029): on SQS a job marked queued but never sent was never re-sent and blocked new starts forever; now re-sent with the same job_id after a 5-min grace, ≤3 sends, one api task per grace. pytest 5019 / 0 failed. Open (ADR 0028): a job whose 3 sends were all refused stays queued until cancelled
- 2026-09-25 S2 fixes F4-F7/F11-F13/F15 merged (webhook events filtered by the client's allowed processes; local disk store + signed local downloads; qb-usa synthetic roster + overrides seed, ROSTER_EMPTY; Cognito dev config fails loud; F11/F12/F15). **All gates green: pytest 5061 / 0 failed, web 1273, lints, drift, single head 0031**; pushed. Stage 2 pass 2 (no workarounds) starting
- 2026-09-25 **Stage 2 pass 2: READY FOR STAGE 3** (`docs/reports/stage2-local-test-2026-09-25.md` "Pass 2"): no workarounds; every JE CSV downloaded from the React app byte-identical to golden (revenue 20/20 ×5 runs, mx 4/4 ×2, qb-usa 9/9 ×2); worker kill/resume OK; v3 20/20 checks; webhooks scoped (F7), SSRF/replay refused; gates green (pytest 5061, shuffled pg 939, `--known-bad` 674/0, infra 754, web 1273). All F1-F15 verified fixed. **Open (non-blocking):** N1 medium (no in-app fix for an UNPOSTED_CONFIG block: no clinic-group unposted-field screen/route; contradictory copy; fix before the Phase 8/9 data copy); N2-N8 lows (MX copy, ROSTER_EMPTY sentence + no roster screen, "Supabase" in logs, empty `output/` from app_settings defaults, raw "Qb account map" label, one event id across subscriptions vs replay rule, superseded-run tie-out copy). **Codex gate still open** (quota; retry after 09:48 on a narrower scope)

## Andres's answers (2026-09-25)

| # | Answer |
|---|---|
| D9 | **Keep** the example workbook's clinic names / QB account paths in the seeds |
| D22 | **Yes**: production needs a second superadmin to approve an API client |
| Refusals | **Every process blocks with an error code and can be re-run**: mx-payroll and qb-usa get `blocked` + retry like qb-revenue for fixable refusals (missing maps, config, roster, overrides) |
| D25 | Render's plain-text logs after the merge are **OK** |
| ADR 0044 | **Dedicated KMS key** for QuickBooks tokens approved (≈ $1/env/month); interpretation of "make a vault for it", to confirm |
| Limits | **1 every 30 seconds**: `/test` ping per subscription, v3 job start per org+process, webhook redrive per subscription (plus the existing per-delivery 3 / 7-day bounds) |
| N1-N8 | **Fix** |
- 2026-09-25 N1-N8 + 1-per-30s limits merged (clinic-group unposted fields editable in /config; per-subscription webhook event ids (contract change, pre-cutover); no `output/` in the repo; copy/labels; limits: /test and redrive 1 per 30 s per subscription, v3 job start 1 per 30 s per org+process + the 30/h cap). pytest 5085 / 0 failed. Waiting: blocked+retry-everywhere agent; Codex after 09:48
- 2026-09-25 **Codex review (narrow scope) done**: 0 critical, 1 high (ledger `_fail()` not fenced to its attempt → possible double JE after a >600 s pause), 2 medium (set_state lost update vs worker; concurrent completions supersede each other). Fix agent dispatched. Merge agent combining ANDRES-BLOCKED-RETRY with N1 on the blocked screen
- 2026-09-25 ANDRES-BLOCKED-RETRY merged (`ccd8791` + `50b1d14`): mx + qb-usa block with codes and re-run; the blocked screen handles QB maps / roster empty / unposted config separately. **All gates green: pytest 5101 / 0 failed, shuffled pg 949, `--known-bad` 690/0, web 1304**. Waiting on the Codex-findings fix
- 2026-09-25 **Codex findings fixed and merged** (all 3 reproduced first): CODEX-1 high: ledger failure settled only on the row the attempt holds (no double JE); CODEX-2: terminal set_state merges run_state under the row lock; CODEX-3: supersession serialised per period, newest completed run stays. **All gates green: pytest 5114 / 0 failed, `--known-bad` 690 red / 0 passed, web 1304, ruff/format/mypy clean.** Stage 1 gates now satisfied: Fable critic PASS (r3) + Codex review with its findings fixed. **Stages 0-2 complete.** Next is Stage 3 (AWS), which starts with Andres approving the cost estimate
- 2026-09-28 Ponytail pass independently verified by Fable + Opus (ultra): no behaviour change (only the email-failure log lost its traceback; workbook fallback known). Merged since: dev sign-in bypass reads org modules (sidebar showed no processes); **invoice feature removed** (0032, live tables empty, billing script kept); **per-org Test mode** (runs stamped `is_test`; no QBO post / email / webhook; never becomes or retires a booking; hidden from lists; `TEST_` downloads); `scripts/local_api_partner.sh` (partner-style :5051, `/oauth2/token` with the real client secret, `--whoami`). **D5 closed:** Docker up, `docker-compose.local.yml` proven on PostgreSQL 17.11 (build, migrate to 0032 + seed, db/api/web healthy) and the PG suites pass on Docker postgres:17 (995 passed). pytest 5107 passed on the partner branch, 5071 on the merged test-mode tree
- 2026-09-28 **D13 closed:** RDS global CA bundle pinned (`787810f`, sha256 e5bb2084…c7e3): 108 self-signed AWS roots = rds-ca-rsa2048/rsa4096/ecc384-g1 × 36 regions, matching AWS's published CA list; same digest via Python and curl; production `Dockerfile.api` build accepts it; infra pin tests 105 passed
- 2026-09-28 **Second person (Meridian workforce, full data access) — decided:** start AWS with Andres as the only admin; add them later via Identity Center (operator + break-glass admin, MFA), app superadmin (= D22 second approver), GitHub, and HIPAA onboarding (confidentiality agreement, training, policies 04/05, device per 06) BEFORE they get AWS access. One account stays OK only if no one outside Meridian's workforce holds admin (read-only IAM check at Stage 3 start)
