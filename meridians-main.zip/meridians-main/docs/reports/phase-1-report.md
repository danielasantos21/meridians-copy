# Phase 1 report — AWS foundation (code complete; deployment gated on approval)

**Date:** 2026-09-15 · **Branch:** `aws-migration` (`aa2b10b`) · **Plan:** `docs/aws-migration-plan.md` Phase 1 · **Critic:** four rounds, PASS at round 4 (`docs/reports/critic-log.md`).

## Status in one line

Every Phase 1 resource is written in CDK, synthesizes for both environments without credentials, and is tested (230 infra tests); **nothing has been created in AWS** because the cost estimate is not yet approved (the phase's exit criterion) and two human steps precede the first deploy.

## What was built

| Plan step | Delivered | Where |
|---|---|---|
| 1 BAA | AWS BAA found ACTIVE in Artifact since 2026-07-13; BAA register written | `docs/compliance/baa-register.md` |
| 2 IAM triage | Identity Center permission sets (admin, read-only) and assignments as CDK, created only when the instance/principal ids are passed; require-MFA policy + humans group; break-glass role with MFA trust, alarm on every AssumeRole, runbook with the two-step MFA session | `infra/meridian/stacks/identity.py`, `foundation.py`, `docs/runbooks/{identity-center-bootstrap,break-glass}.md` |
| 3 SES | Domain identity with Easy DKIM 2048, custom MAIL FROM `mail.`, configuration set (TLS required, reputation metrics, bounce/complaint/reject events to SNS); Route 53 zone with all sixteen live records copied and verified; nameserver-switch runbook with a two-direction check (`scripts/dns_zone_diff.py` + candidate-name sweep) | `infra/meridian/stacks/dns.py`, `infra/dns/meridiansgrp.com.zone.json`, `docs/runbooks/dns-nameserver-switch.md`, ADR 0017 |
| 4 CDK skeleton | `infra/` app in Python; env as context; no account id in code (tested); tag Aspect fails synth on a missing tag (tested); synth for both envs in CI | `infra/`, `.github/workflows/backend.yml` job `infra` |
| 5 Security services | Second CloudTrail trail (validation, S3 data events for `meridian-*`, Object-Locked audit bucket 7 y, KMS log group 400 d); alarms for human console `Create*`/`Delete*`, root use, break-glass, IAM policy changes; GuardDuty (features pinned); Security Hub FSBP + NIST 800-53 (there is no HIPAA standard; HIPAA is the Config pack); Config recorder + vendored HIPAA conformance pack as a CDK asset; Access Analyzer; Inspector (ECR); singleton flags + pre-deploy checks for each | `foundation.py`, `infra/conformance-packs/`, ADR 0016 |
| 6 KMS | Five CMKs per environment (rds, artifacts, phi, logs, backups) with rotation, Retain | `infra/meridian/stacks/data.py` |
| 7 Tags/cost | Budgets (staging 75, production 250, account 300) tagged; Cost Anomaly Detection (per-environment tag monitors, the account's existing service monitor adopted by ARN); cost-allocation tag activation documented as a pre-deploy step | `foundation.py`, `infra/README.md` |
| 8 CI OIDC | GitHub OIDC provider + one deploy role per environment trusting exactly one branch, assuming only the `cdk-*` bootstrap roles; CI has no stored keys | `foundation.py` |
| 9 Cost estimate | Written for approval | `docs/reports/phase-1-cost-estimate.md` |

## Evidence

- `npx cdk synth -c env=staging|production -c allowNoIdentityCenter=true` succeeds with no credentials; two synths are byte-identical.
- 230 infra tests (`infra/tests`), CI run 35056338499 green (backend, infra, migrations jobs).
- Read-only account survey (2026-09-15): no GuardDuty, Security Hub, Config recorder, OIDC provider, Identity Center, hosted zone, or CDK bootstrap exists yet; SES is in sandbox with no identities; the `Environment`/`Project` cost-allocation tags are inactive; the account already has AWS's default service anomaly monitor (adopted, not duplicated).

## Decisions made in this phase

- ADR 0016 (second trail, not the other app's), ADR 0017 (Route 53 zone; registrar stays GoDaddy), provisional: Identity Center requires an **organization** instance — see the decision below.

## Phase 1 Verify list

| Item | Status |
|---|---|
| BAA date recorded | MET (register) — Andres to confirm PHI may land from Phase 3 |
| MFA devices listed | NEEDS A HUMAN (runbook §6–8) |
| Identity Center sign-in works | NEEDS A DECISION + A HUMAN (organization instance vs IAM-users fallback) |
| Long-lived key inactive | NEEDS A HUMAN (last step of the triage order) |
| SES Verified + production-access case open | BLOCKED: DNS records live only in Route 53 until the nameserver switch, or the interim GoDaddy records (runbook §3e) |
| `cdk synth`/`diff` clean in CI; tag Aspect fails untagged | synth MET; `cdk diff` deferred (tracker: needs the OIDC read-only role deployed) |
| Security Hub both standards | in code; verified after deploy |
| Budgets exist | in code; verified after deploy |
| **Cost estimate approved in writing** | **BLOCKED ON ANDRES** |

## Open risks

1. Config `AllSupported` in a shared account records the other application's resources too — cost band $5–25; kept because scoping would turn HIPAA controls into silent no-ops (reason in `foundation.py`).
2. First deploy needs three one-off human steps in order: activate cost-allocation tags; run the pre-deploy singleton checks; `cdk bootstrap` (default qualifier; never the other app's state bucket).
3. `enableServiceAnomalyMonitor` defaults false because this account already has one; a fresh account must set it true.

## Needs a human (Andres)

- Approve `docs/reports/phase-1-cost-estimate.md` (≈ $37/month now; ≈ $239 steady state).
- Decide: create an AWS Organization (this account as management) so Identity Center can carry permission sets — or the IAM-users + MFA fallback (runbook §0).
- Decide: early nameserver switch to Route 53, or hand-add the SES DKIM/MAIL FROM records at GoDaddy (runbook §3e).
- After deploy: enrol MFA, complete the IAM triage in order, file the SES production-access request (text in runbook §7), run the break-glass drill.
- Confirm PHI may land on AWS from Phase 3's staging rehearsal onward (BAA is active).
