# Phase 12 plan — API platform, API security, and final cleanup

**Date:** 2026-09-22 · **Branch:** `aws-migration` · **Status:** plan only. No code, no AWS.
**Sources:** `docs/aws-migration-plan.md` Phase 12 (lines 582-602), Phase 11 (561-578), D-18, D-25, §4
deferred table; `docs/aws-migration-prompt.md` API PLATFORM (201-226), API SECURITY (230-261),
KEEPING IT TIDY (265-343), PHASE COMPLETION LOOP (422-462), THE CRITIC (466-485);
`docs/api-v2-contract.md` §4, §8, §9, §11, §12.9; ADRs 0002, 0003, 0010, 0011, 0012, 0021, 0023, 0024, 0026.
**Depends on:** `docs/reports/phase-11-plan.md` (written separately). This plan **assumes the
Phase 11 manifest exactly as the migration plan's Phase 11 step 1 describes it** and does not
redesign it. §3.9 lists the fields Phase 12 reads from it and the two it needs Phase 11 to allow.

---

## 1. Plain-language summary

Meridian's server today speaks two "dialects" to the outside world: `/api/v1`, a small, old set
of URLs nobody calls any more except the health check, and `/api/v2`, the set the React app uses.
Phase 12 builds **`/api/v3`**: one set of URLs that the React app, our own scripts, and outside
companies' systems all use, with the same rules for everyone. Then it switches the old two off
and cleans up everything the migration left behind.

The words used below, defined once:

| Term | Plain meaning |
|---|---|
| **REST** | A style of API where each URL is a *thing* (a run, a mapping) and the HTTP verb says what to do with it (`GET` = read, `POST` = create, `PATCH` = change, `DELETE` = remove). |
| **Endpoint** | One URL + one verb, e.g. `GET /api/v3/runs/{run_id}`. |
| **OpenAPI** | A machine-readable description of every endpoint (inputs, outputs, errors). Tools read it to generate client code, so nobody hand-writes the calling code. |
| **Scope** | A named permission a caller carries, like `runs:read`. An endpoint declares which scope it needs; a caller without it is refused. |
| **Object-level authorization** | Checking not just "may this caller read runs?" but "may this caller read *this* run?". The run must belong to the caller's organization. If it does not, we answer **404 not found**, never 403, so the answer does not even confirm the run exists. |
| **Property-level authorization** | Only returning the *fields* a caller may see, and refusing request fields we did not declare. |
| **OAuth client-credentials** | How a machine logs in: it sends a client id + secret to Amazon Cognito and gets back a short-lived **access token** (≤ 15 minutes), which it then sends on every call. No human, no password, no browser. |
| **Resource-server scopes** | The scope names Cognito is allowed to put in those machine tokens (`meridian-api/runs:read`). |
| **`revoked_epoch`** | A timestamp on each machine client's database row. Any token *issued before* it is refused. Because we check the row on every request, revoking a client works within a minute even though its last token is still "valid" for up to 15. |
| **Webhook** | Meridian calling *the partner's* URL when something happens (`run.completed`), instead of the partner asking over and over. |
| **HMAC signature** | A fingerprint of the webhook body made with a secret only Meridian and the receiver know. The receiver recomputes it; if it matches, the message really came from us and was not altered. A timestamp and a unique event id inside it stop someone replaying an old message. |
| **SSRF** (server-side request forgery) | Tricking *our* server into calling an address the attacker cannot reach themselves — e.g. AWS's internal metadata address `169.254.169.254`, which hands out credentials. A webhook URL is exactly that risk, because the attacker chooses it. |
| **DNS rebinding** | A trick where a hostname looks safe when we check it and then points at an internal address a moment later when we connect. The defence is to connect to *the exact IP we checked*, not to look the name up twice. |
| **mTLS** (mutual TLS) | Normal HTTPS proves the *server* is who it claims; mutual TLS also makes the *client* present a certificate. Required for any partner allowed to read PHI, so a stolen token alone is useless. |
| **WAF rate rules** | Rules at the edge (AWS WAF, in front of CloudFront) that block an IP sending too many requests, before they reach our code. |
| **OWASP API Security Top 10** | The industry list of the ten most common ways APIs get broken. Every one gets a test. |
| **ZAP** | OWASP ZAP, a free scanner that pokes a running website for common security mistakes. The "baseline" scan is the gentle, repeatable kind. |
| **Outbox** | A table where we write "event X happened" in the same database transaction as the change itself, so an event is never announced for a change that rolled back (or lost for one that didn't). |
| **Sandbox org** | A fake organization inside staging, filled with generated data, where a partner can practise against the API without ever touching real data. |

**The honest headline.** About half of Phase 12 (scopes, machine auth, webhooks machinery, security
tests, admin screens, audit) can be built and tested on the Mac today against the local Postgres
fixture, with no AWS spend. The process endpoints and webhook *events* must wait for Phase 11's
worker, and deployment, ZAP, the sandbox and the retirement of `/api/v1`/`/api/v2` need staging or
production. The plan's 28-44 days is **light by about a third**: re-pricing each item gives
**~49-70 days**, mostly because moving the React app from `/api/v2` to `/api/v3`, the phase-close
review loops and four items added since the estimate (quotas in Postgres, the API audit table, the
staging wipe, ADRs/runbooks) were never priced. §8 shows how to trim it to ~42-55.

---

## 2. Starting state (evidence)

### 2.1 API surfaces that exist

| Surface | Where | What it is | Who calls it |
|---|---|---|---|
| `/api/v1/health`, `/health` | `api/routers/health.py:47-51` (FastAPI) | Liveness, v1 body `{"status","version":"1.0.0","database"}` | ALB target group (`infra/meridian/stacks/edge.py:103`), container health check (`infra/meridian/stacks/compute.py:705`), observability (`observability.py:309`), Render (`render.yaml:44`); pinned by `infra/tests/test_edge.py:212`, `test_compute.py:28` |
| `/api/v1/*` (10 routes) | `web_app.py:8056-8184` (Flask) — revenue batches/results, payroll batches, config providers/locations/payers/employees, settings GET/PUT, `user/me` | Legacy JSON; each is `require_auth` + `require_org` + `require_permission` | **Nobody found.** `grep` over `web/src`, `src`, `scripts`, `tests` finds only comments (`src/api/v2/config_routes.py:18-19`, `scripts/serve_api.sh:7`) and `tests/test_fastapi_app.py` |
| `/api/v2/*` | FastAPI routers `api/routers/*.py` (12 modules, prefixes at e.g. `core.py:56`, `auth.py:39`), framework-free logic in `src/api/v2/*`; Flask mounted underneath at `/` (`api/main.py:290-295`) | The contract in `docs/api-v2-contract.md`; **82 paths / 109 operations** in `openapi/meridian-v2.json` | The React app via same-origin proxy (`web/next.config.mjs` `PROXIED_PREFIXES` `/api/:path*`; `web/src/lib/proxy.ts`), 15 client modules in `web/src/lib/api/` |
| `/auth/*` (Flask) | `web_app.py` | OAuth callbacks (Cognito hosted UI, QuickBooks connect) | Browser redirects; proxied (`next.config.mjs` `/auth/:path*`). Not API, but must survive `/api/v2` retirement — Phase 11 ports or keeps them. |

OpenAPI today: FastAPI's own `/openapi.json` is **disabled** (`api/main.py:238-240`);
`openapi/meridian-v2.json` is produced by `scripts/generate_openapi.py` from a hand-maintained
`ROUTES` registry, and `scripts/check_api_drift.sh` regenerates it plus
`web/src/lib/api/schema.d.ts` and fails on drift. The TypeScript toolchain is **already installed**:
`openapi-typescript` (dev) and `openapi-fetch` (runtime) in `web/package.json`.

### 2.2 Auth that exists

- **Humans:** `api/deps.py:141-169` `resolve_identity` — bearer header first, else cookie with
  silent refresh; `src/auth.py:544-591` `_fetch_user` does dual-issuer verification (Cognito
  first, Supabase fallback behind `AUTH_ACCEPT_SUPABASE_TOKENS`). Org and permissions are read from
  Postgres on every request (`api/deps.py:172-194`), never from a token (ADR 0021 "No roles… in any
  claim").
- **Authorization:** `require_permission(process, level)` (`api/deps.py:220-249`),
  `require_admin` (`:252-266`), superadmin via `src/pg.with_superadmin` (`src/pg.py:847`), which
  writes `audit.superadmin_access` (`migrations/versions/0010_superadmin_org_list.py:107`).
- **Machines: nothing authorizes them yet.** `src/cognito.py:547` refuses any token whose
  `token_use` is not `id`, deliberately, and the docstring (`src/cognito.py:37-42`) says machine
  authorization "gets its own scope check when the resource server is used (Phase 12)". The CDK
  already creates a resource server `meridian-api` with **`runs:read` and `runs:write` only, no
  `phi:read`** (`infra/meridian/stacks/auth.py:173-181`) and one placeholder machine client
  `meridian-<env>-auth-machine` with client-credentials, 15-minute tokens, a generated secret and
  token revocation (`auth.py:636-663`, validity `:161`). A Cognito domain exists (`auth.py:318`).
- **CSRF:** double-submit, bearer-exempt (`api/deps.py:303-344`).
- **Rate limits:** in-process fixed window (`api/deps.py:575-584`), correct only at one api task
  (ADR 0010). WAF: `RateLimitPerIp` 2000 and `RateLimitAuthPerIp` 100 per 5 min
  (`edge.py:111-112`, `:1127-1152`).
- **Tenant scope:** `src/pg.with_org(org_id, user_id)` (`src/pg.py:678-708`) sets `app.org_id` /
  `app.user_id` (`:323-336`); RLS keyed on it (revision 0004). A machine caller has no user id —
  `with_org` already accepts that (`user_id` optional, identity-table policies then match nothing).
- **PHI:** `src/phi.py` is the only door to the `phi` schema, audits every access to
  `audit.phi_access`, never logs a value.

### 2.3 What the React app uses

Only `/api/v2` (and `/auth/*` redirects), through the same-origin proxy; no CORS on the API side
(`next.config.mjs` header comment). No `/api/v1` caller.

### 2.4 Security tests that exist

- **No `tests/security/` folder.** The control matrix already names its files
  (`docs/compliance/control-matrix.md:244-253`): `test_auth_*`, `test_unknown_fields_rejected.py`,
  `test_phi_masked_without_scope.py`, `test_rate_limits.py`, `test_oversized_payload.py`,
  `test_route_authz_matrix.py`, `test_scope_enforcement.py`, `test_execute_rate_and_idempotency.py`,
  `test_webhook_ssrf_blocked.py`, `test_idp_claims_not_authz.py`; readiness adds
  `test_session_cookie_flags.py` and `test_security_headers.py`
  (`docs/runbooks/production-readiness.md:334, 344`).
- Existing relevant tests: `tests/test_security.py` (10 tests; #13 in
  `docs/plans/api-v2-follow-ups.md` says one never asserted what its name claims),
  `tests/test_run_isolation.py` (7), `tests/test_pnl_rls_live.py` (5),
  `tests/test_api_v2_cross_cutting.py` (21), `tests/test_signed_url_downloads.py` (16),
  `tests/test_api_v2_auth_cognito.py` (22), `tests/test_lint_org_scope.py`,
  `tests/test_no_phi_logging.py`, `tests/test_qbo_request_id.py`.
- Local Postgres for tests: `tests/pg_fixture.py` (Docker `postgres:17` or Homebrew `initdb`; the
  Mac has `/opt/homebrew/bin/postgres`). Alembic head is `0010`.

### 2.5 Things the plan names that do not exist on this branch

- `deploy/aws-trial/make_sample_revenue.py` exists **only on the `aws-trial` branch** (commit
  `0ec2da8`); there is no `deploy/` folder here. It reads `config/mappings.example.xlsx` and
  writes a 20-row PHI-free workbook. It must be harvested into `scripts/`.
- `scripts/staging_wipe.py` **does not exist** (tracker row, `docs/migration-tracker.md:166`).
- `docs/runbooks/revoke-api-client.md` and `onboard-partner.md` are listed as "Phase 12" in
  `docs/runbooks/README.md:36, 39` and do not exist.
- The JSON log formatter the Phase 12 alarms need is itself open (tracker line 52, Phase 6 → 8).

### 2.6 Tracker rows Phase 12 owns (and the bigger job)

Explicitly Phase 12: mypy on the whole tree (line 42, ~400 findings at baseline); the
`DatabaseSQLite` drift, closed by deleting the legacy CLI (line 114); the three dead
cutover/decommission flags plus `src/auth.py`'s two-issuer branch (line 132); zip-bomb bound on
workbook uploads (line 160); `staging_wipe.py` (line 166). **But Phase 12's exit is an empty
tracker**, and about **140 rows** are open today (lines 28-167). Most close in their own phases;
whatever is left on Phase 12's first day is Phase 12's.

---

## 3. Target design

### 3.1 Shape of `/api/v3`

**Decision (recommended default): v3 = the already-ported v2 families re-homed under
`/api/v3`, unchanged in request/response models wherever they already fit, plus the new platform
resources.** The v2 FastAPI routers already use pydantic models and the contract §4 envelope. Re-
homing them makes the React move a regenerate-and-rename job rather than a rewrite, and keeps "one
implementation": a v2 route and its v3 twin call the same `src/` function, and the v2 decorator is
deleted in the React-switch commit for that family (tracker row while both exist).

v3-wide rules, enforced structurally (a test fails if a route breaks them):

1. **Every route declares a scope** through one dependency (`require_scope(...)`); a route with
   none fails `tests/security/test_route_authz_matrix.py`. Public routes declare `PUBLIC`
   explicitly (health, sign-in).
2. **Every id in a path is resolved with `org_id = %s`** (the lint `scripts/lint_org_scope.py`
   already checks statements) and under `with_org` (RLS); miss → `404 NOT_FOUND`-family code.
3. **Request models `extra='forbid'`**; unknown query parameters → `422 VALIDATION_ERROR` naming
   them (contract §11 already does this for filters).
4. **Response models carry a field classification** (`json_schema_extra={"x-classification":
   "phi"|"pii"|"internal"}`); one serializer masks `phi` fields to `null` unless the caller holds
   `phi:read`. A test walks every v3 response model.
5. **No PHI, secrets or internal ids in URLs or query strings.** Public ids only (`run_id` UUIDs,
   never `batch_id` or `org_id` for machine callers).
6. **Postgres only.** v3 routers are mounted only when `DATABASE_BACKEND=postgres`; under
   `supabase` they are absent (no dual maintenance before cutover; flag `MERIDIAN_API_V3=1` on top).
7. **Wrong method → 405**, via explicit handling in v3 (fixes tracker line 99 for v3 even while the
   Flask mount exists).
8. **CORS allowlist is empty** (same-origin by proxy); preflights get no `Access-Control-Allow-*`.
   Security headers from `src/http_headers.py` on every response (already in `api/main.py:246-268`).

### 3.2 Endpoints

Legend — **Scope:** what the caller must hold. **Org check:** how object-level authz is done.
**PHI masked:** fields nulled without `phi:read`. "Human-only" scopes can never be granted to a
machine (DB CHECK + `HUMAN_ONLY_SCOPES`).

| Method | Path | Scope | Org check | PHI fields masked | Built |
|---|---|---|---|---|---|
| GET | `/api/v3/health` | PUBLIC | — | — | LOCAL-NOW |
| POST | `/api/v3/auth/{login,logout,mfa,mfa/setup,mfa/verify,forgot-password,reset-password}`, GET `/api/v3/csrf` | PUBLIC (rate-limited per IP) | — | — | re-home |
| GET/PATCH | `/api/v3/me`, PUT `/api/v3/me/dashboard-preferences` | `profile:self` (human-only) | self row only | — | re-home |
| GET/PATCH | `/api/v3/org`, `/org/members[/{id}]`, `/org/roles[/{id}]`, POST `/org/invites` | `org:admin` (human-only) | membership org; id + `org_id` | — | re-home |
| GET | `/api/v3/processes` | `runs:read` | org modules | — | LOCAL-NOW |
| GET | `/api/v3/runs` (filters: `process,state,fiscal_year,period,created_by,from,to`, keyset) | `runs:read` + per-process `results` permission (humans) / `allowed_processes` (machines) | `org_id` predicate + RLS | `input_file` (`internal`, hidden from machines) | LOCAL-NOW (read of `process_runs`) |
| GET | `/api/v3/runs/{run_id}` | same | `run_id AND org_id`; miss → 404 | same | LOCAL-NOW |
| GET | `/api/v3/runs/{run_id}/journal-entries`, `/api/v3/journal-entries?run_id&fiscal_year&period&location` | `journal-entries:read` | via run's org | none (aggregated lines) | LOCAL-NOW |
| GET | `/api/v3/runs/{run_id}/artifacts` | `runs:read` | run org; artifacts classified `phi` omitted without `phi:read` | `phi` artifacts | AFTER-P11 (artifact store moves in P11) |
| POST | `/api/v3/runs/{run_id}/artifacts/{artifact_id}/download-url` | `artifacts:download` (+ `phi:read` for `phi` artifacts) | run org + storage path prefix `{org_id}/` (contract §8.4) | n/a | AFTER-P11 |
| GET | `/api/v3/runs/{run_id}/downloads` (audit list; follow-up #7) | `audit:read` (human-only, admin) | run org | — | AFTER-P11 |
| POST | `/api/v3/processes/{process}/uploads` → pre-signed POST (size + content-type conditions) | `processes:run` | upload key `{org_id}/uploads/{upload_id}` in the `phi` bucket | — | AFTER-P11 |
| POST | `/api/v3/processes/{process}/runs` (`Idempotency-Key` required) | `processes:run` | upload ids must be this org's and malware-tagged clean | — | AFTER-P11 |
| POST | `/api/v3/runs/{run_id}/actions/{action}` — `review`, `declarations`, `retry` (from the manifest/state machine `available_actions`) | `processes:run` | run org; action must be in `available_actions`, else 404 (contract §12.1, §12.8) | — | AFTER-P11 |
| POST | `/api/v3/runs/{run_id}/actions/execute` (books to QuickBooks) | `processes:execute` + `Idempotency-Key` | same | — | AFTER-P11 |
| GET | `/api/v3/mappings/{kind}` (`providers,locations,payers,departments,clinic-groups,qb-provider-codes`; since the critic H-1 follow-up also `qb-accounts,qb-departments,qb-clinics,qb-other-codes,qb-payer-labels,qb-locations`) | `mappings:read` | `org_id` predicate | — | LOCAL-NOW |
| POST/PATCH/DELETE | `/api/v3/mappings/{kind}[/{id}]` | `mappings:write` | id + `org_id` | — | LOCAL-NOW |
| GET | `/api/v3/employees?entity=mx\|us` | `employees:read` | `org_id` | compensation fields not exposed at all (`pii`) | LOCAL-NOW |
| PUT/POST/DELETE | `/api/v3/employees/{id}`, `/employees/import` | `employees:write` | id + `org_id` | — | LOCAL-NOW |
| GET/PUT | `/api/v3/allocations?employee_id&period` | `allocations:read` / `allocations:write` | `org_id` | — | LOCAL-NOW |
| GET | `/api/v3/revenue/summaries?fiscal_year&period&location` | `revenue:read` | `org_id` | none — aggregates only | LOCAL-NOW |
| — | transaction-level revenue rows | **not exposed in v3** (service dates are identifiers) | — | — | only on P-1/P-2 trigger, `phi:read` + mTLS |
| GET/POST | `/api/v3/webhooks/subscriptions`, GET/PATCH/DELETE `/{id}`, POST `/{id}/rotate-secret`, POST `/{id}/test` | `webhooks:manage` | `org_id`; machines only their own subscriptions (`api_client_id`) | — | LOCAL-NOW |
| GET | `/api/v3/webhooks/deliveries?subscription_id&status`, POST `/deliveries/{id}/redrive` | `webhooks:manage` | `org_id` | — | LOCAL-NOW |
| GET/POST | `/api/v3/admin/api-clients`, PATCH `/{id}`, POST `/{id}/{approve,rotate-secret,revoke,disable}`, GET `/{id}/usage` | `clients:manage` (human-only, org admin); `approve` = superadmin | `org_id`; approve via `with_superadmin(reason)` | — | LOCAL-NOW (Cognito behind a port) |
| GET/POST | `/api/v3/admin/partner-baas` | superadmin (human-only) | superadmin scope, audited | — | LOCAL-NOW |
| * | settings, invoices, pnl, dashboard, superadmin families | `settings:admin`, `invoices:*`, `pnl:*`, `dashboard:self`, `superadmin` (all human-only) | as v2 | — | re-home |

### 3.3 Error envelope and pagination

- **Envelope: unchanged** — contract §4.1 `{"error": {code, message, details, field_errors,
  request_id, retryable}}`, installed by `api/errors.py`. New codes:
  `SCOPE_INSUFFICIENT` 403 (`details.required_scope`; checked **before** any object is loaded, so it
  reveals nothing about existence), `NOT_FOUND` 404 (generic; every cross-org miss uses the
  resource's `*_NOT_FOUND` or this), `METHOD_NOT_ALLOWED` 405, `UNSUPPORTED_MEDIA_TYPE` 415,
  `UPLOAD_NOT_SCANNED` 409, `UPLOAD_REJECTED` 422 (malware or type), `WEBHOOK_URL_REJECTED` 422
  (one generic message — never "resolves to a private address", which would make the endpoint a
  probe of our internal DNS), `IDEMPOTENCY_KEY_REQUIRED` 428, `QUOTA_EXCEEDED` 429 (+`Retry-After`).
  A revoked, disabled or unknown machine client gets plain `401 AUTH_REQUIRED` — no reason.
- **Pagination: contract §11 verbatim** — keyset, `limit` 1-100 default 25, opaque `cursor`
  (base64url of `{created_at, id}`, strictly parsed; a bad cursor is 422), response
  `{data, page: {next_cursor, has_more, limit}, meta: {total_estimate}}`. Every list endpoint is
  bounded (critic: "unbounded queries") and backed by an `(org_id, …, created_at DESC, id DESC)` index.

### 3.4 Scope model

One module, `src/api_scopes.py` (authorization rules are business logic, so `src/`), with the
catalogue, `HUMAN_ONLY_SCOPES`, and two functions:

- **Humans — `scopes_for_human(identity)`**, derived on every request from the rows `require_org`
  already read (never cached, never a claim):

  | Source row | Scopes |
  |---|---|
  | `permissions[process].access` | `processes:run` for that process |
  | `permissions[process].results` | `runs:read`, `artifacts:download`, `journal-entries:read`, `processes:execute` for that process (contract §12.11: booking is a results-level act today) |
  | `permissions.config.access` | `mappings:read/write`, `employees:read/write`, `allocations:read/write` |
  | `permissions.revenue.results` | `revenue:read` |
  | org role `admin` | `org:admin`, `clients:manage`, `webhooks:manage`, `settings:admin`, `audit:read` |
  | new `roles.can_read_phi` (default false) | `phi:read` (P-1: nobody needs it today) |
  | always | `profile:self`, `dashboard:self` |

- **Machines — effective scopes = token `scope` claim ∩ `api_clients.granted_scopes`**, plus
  `allowed_processes` narrowing `processes:*`/`runs:read` per process. Cognito resource-server
  scopes (`infra/meridian/stacks/auth.py:177-181`) become the machine-grantable catalogue:
  `runs:read`, `processes:run`, `processes:execute`, `artifacts:download`, `journal-entries:read`,
  `mappings:read`, `mappings:write`, `employees:read`, `allocations:read`, `revenue:read`,
  `webhooks:manage`; `phi:read` is added to the resource server **only when the first partner BAA
  is recorded** (keeps ADR 0021's rule that a scope nothing checks must not exist). `runs:write`
  is renamed `processes:run` — safe because nothing has ever used it.
- Enforcement: `require_scope("runs:read")` in `api/v3/deps.py` is the only place a scope is
  compared. Handler code never reads scopes.

### 3.5 Tables (Alembic DDL sketches)

One revision after Phase 11's (numbers TBD; Alembic is a linear chain). All tenant tables get the
`org_id` RLS policy of revision 0004 and grants to `meridian_app` only.

```sql
-- partner BAAs: no phi:read without a row here (baa-register.md "Future API partners")
CREATE TABLE public.partner_baas (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id        uuid NOT NULL REFERENCES public.organizations(id),
  partner_name  text NOT NULL,
  document_ref  text NOT NULL,          -- evidence-store key, never the document
  signed_on     date NOT NULL,
  expires_on    date,
  approved_by   uuid NOT NULL,          -- superadmin
  approved_at   timestamptz NOT NULL DEFAULT now(),
  revoked_at    timestamptz
);

CREATE TABLE public.api_clients (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id              uuid NOT NULL REFERENCES public.organizations(id),
  name                text NOT NULL CHECK (length(name) BETWEEN 3 AND 80),
  kind                text NOT NULL CHECK (kind IN ('internal','partner','sandbox')),
  status              text NOT NULL CHECK (status IN ('pending_approval','active','disabled','revoked')),
  cognito_client_id   text UNIQUE,      -- null until approved
  secret_fingerprint  text,             -- sha256 prefix for display/rotation; never the secret
  granted_scopes      text[] NOT NULL DEFAULT '{}',
  allowed_processes   text[] NOT NULL DEFAULT '{}',
  ip_allowlist        cidr[],           -- null = any
  mtls_subject        text,             -- required for phi:read
  partner_baa_id      uuid REFERENCES public.partner_baas(id),
  revoked_epoch       timestamptz NOT NULL DEFAULT 'epoch',   -- tokens with iat < this are refused
  requested_by        uuid NOT NULL,
  approved_by         uuid, approved_at timestamptz,
  disabled_at         timestamptz, disabled_reason text,
  last_used_at        timestamptz, last_used_ip inet,         -- written at most once a minute
  created_at          timestamptz NOT NULL DEFAULT now(),
  CHECK (NOT granted_scopes && ARRAY['org:admin','clients:manage','audit:read','settings:admin',
                                     'superadmin','profile:self','dashboard:self']),
  CHECK (NOT ('phi:read' = ANY(granted_scopes)) OR (partner_baa_id IS NOT NULL AND mtls_subject IS NOT NULL)),
  CHECK (status <> 'active' OR (approved_by IS NOT NULL AND cognito_client_id IS NOT NULL))
);
-- Pre-tenant lookup: the api must find the row from the token's client_id BEFORE it knows the org,
-- which RLS forbids. One SECURITY DEFINER function returns only the auth columns, like with_user().
CREATE FUNCTION app.api_client_for_token(p_cognito_client_id text) RETURNS TABLE (
  id uuid, org_id uuid, status text, granted_scopes text[], allowed_processes text[],
  ip_allowlist cidr[], mtls_subject text, revoked_epoch timestamptz) ...;

CREATE TABLE public.webhook_subscriptions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id          uuid NOT NULL REFERENCES public.organizations(id),
  api_client_id   uuid REFERENCES public.api_clients(id),   -- null = created by a human admin
  url             text NOT NULL CHECK (url LIKE 'https://%' AND length(url) <= 2048),
  event_types     text[] NOT NULL CHECK (cardinality(event_types) > 0),
  secret_arn      text NOT NULL,        -- Secrets Manager; value never in Postgres
  status          text NOT NULL CHECK (status IN ('active','paused','disabled')),
  failure_streak  int NOT NULL DEFAULT 0,  -- auto-pause after N consecutive DLQ'd deliveries
  created_by      uuid, created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.api_events (          -- the outbox
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),  -- = event_id in the signature
  org_id        uuid NOT NULL,
  type          text NOT NULL,              -- run.completed, run.failed, run.blocked, run.needs_input, run.expired (T19 follow-up, 0020)
  subject_id    uuid NOT NULL,              -- run_id; ids only, never PHI
  occurred_at   timestamptz NOT NULL DEFAULT now(),
  published_at  timestamptz                 -- null until PutEvents succeeded
);
CREATE INDEX ON public.api_events (published_at) WHERE published_at IS NULL;

CREATE TABLE public.webhook_deliveries (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id          uuid NOT NULL,
  subscription_id uuid NOT NULL REFERENCES public.webhook_subscriptions(id),
  event_id        uuid NOT NULL REFERENCES public.api_events(id),
  attempt         int  NOT NULL DEFAULT 0,
  status          text NOT NULL CHECK (status IN ('pending','delivered','failed','dropped','dead')),
  last_status_code int, last_error_code text,   -- our code (e.g. TENANT_MISMATCH, SSRF_BLOCKED), not the body
  next_attempt_at timestamptz, delivered_at timestamptz,
  UNIQUE (subscription_id, event_id)            -- fan-out is idempotent
);

-- extend, never parallel (prompt: PROCESS FRAMEWORK)
ALTER TABLE public.process_runs       ADD COLUMN created_by_client_id uuid REFERENCES public.api_clients(id);
ALTER TABLE public.artifact_downloads ADD COLUMN api_client_id       uuid REFERENCES public.api_clients(id);
ALTER TABLE public.roles              ADD COLUMN can_read_phi boolean NOT NULL DEFAULT false;

-- append-only audit, same pattern as audit.superadmin_access (0010) and audit.phi_access (0003)
CREATE TABLE audit.api_request (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  at timestamptz NOT NULL DEFAULT now(),
  request_id text NOT NULL, org_id uuid, user_id uuid, api_client_id uuid,
  method text NOT NULL, route text NOT NULL,      -- the matched template, never the raw URL
  record_id uuid,                                  -- the public id acted on, if any
  scope_used text, status smallint NOT NULL, ip inet
);  -- GRANT INSERT only to meridian_app; retention per the HIPAA 6-year rule via the audit export
CREATE TABLE audit.api_client_change (             -- grants, approvals, rotations, revocations
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, at timestamptz NOT NULL DEFAULT now(),
  api_client_id uuid NOT NULL, actor_user_id uuid NOT NULL, action text NOT NULL,
  scopes_before text[], scopes_after text[], reason text
);
CREATE TABLE public.api_quota_window (             -- ADR 0010 reopened: shared counters, no Redis
  bucket text NOT NULL, window_start timestamptz NOT NULL, hits int NOT NULL,
  PRIMARY KEY (bucket, window_start)
);
```

### 3.6 Machine-auth flow

1. **Request** (org admin, admin screen): name, kind, scopes, processes, optional IP allowlist →
   row `pending_approval`; `audit.api_client_change`.
2. **Approve** (superadmin, reason required, `with_superadmin`): the api creates a Cognito app
   client (`CreateUserPoolClient`, client-credentials, `GenerateSecret`, access token 15 min,
   allowed OAuth scopes = the granted set) through a `CognitoClientAdmin` port; the secret is
   returned **once** to the approver's screen, fingerprinted, never stored or logged. Status →
   `active`.
3. **Token:** the machine calls Cognito's `/oauth2/token` (client id + secret) → access token
   (`token_use=access`, `client_id`, `scope`, `iat`, `exp`).
4. **Each request:** new `src/cognito.validate_machine_token` (sibling of `validate_token`,
   `src/cognito.py:513`): signature via the same JWKS cache, `iss`, `exp`, `token_use == "access"`,
   `client_id` present → `app.api_client_for_token(client_id)` → refuse (401, no reason) if no row,
   status ≠ `active`, `iat < revoked_epoch`, caller IP outside `ip_allowlist`; effective scopes =
   token ∩ row; tenant = the **row's** `org_id` (never anything in the token);
   `with_org(row.org_id)` with empty user id. `phi:read` additionally requires a verified
   `X-Meridian-Client-Cert-Subject` equal to `row.mtls_subject`, accepted **only** when the request
   carries the API-Gateway origin-verify secret; otherwise the PHI endpoint answers 404 on every
   hostname (plan step 4; Codex PS-4).
5. **Revoke:** set `status='revoked'`, `revoked_epoch=now()` (effective on the next request, so
   "within one minute" holds trivially), then disable/delete the Cognito app client so no new
   token mints. **Rotate:** add a second secret to the same app client, hand it over once, delete
   the old after the partner confirms — *Cognito multi-secret rotation must be verified in T01*;
   fallback is a second app client mapped to the same row for the overlap.
6. **Lifecycle:** daily job disables clients with `last_used_at` older than 90 days (reason
   recorded); `scripts/api_access_review.py` writes the quarterly access-review report (clients,
   scopes, approver, last use, BAA status) to the audit evidence location, not the repo.
7. **Detection:** JSON log events `api_client_new_ip`, `api_client_scope_change`,
   `api_auth_failure` → metric filters → alarms (auth-failure spike, new client IP, scope
   escalation). **Blocked on the JSON formatter** (tracker line 52).

Why not "secret stored hashed in Postgres" as the plan says: Cognito, not Meridian, checks the
secret, so a hash of it in Postgres verifies nothing. The row keeps a **fingerprint** (to show
which secret is live during rotation). Meridian-held secrets that *we* send (webhook signing,
our own scripts' client secrets) live in Secrets Manager. Recorded as a provisional decision.

### 3.7 Webhook delivery architecture

```
run state change (worker, Phase 11) ──same txn──▶ api_events row (outbox)
        │ after commit: PutEvents                      ▲ sweep every 5 min re-publishes rows
        ▼                                              │ with published_at IS NULL
EventBridge bus meridian-<env>-events  ── rule source=meridian.runs ──▶ SQS meridian-<env>-sqs-webhooks
                                                                         │ (KMS, DLQ after 8 receives)
                                                                         ▼
                        Lambda meridian-<env>-lambda-webhook-sender (in VPC, own SG: 443 out, 5432 to RDS)
                          1. fan-out message: with_org(event.org_id) → subscriptions for type →
                             INSERT webhook_deliveries … ON CONFLICT DO NOTHING → one SQS message each
                          2. delivery message: RE-READ delivery, subscription, api_clients row, run
                             (all under with_org(delivery.org_id)); event org = run org = subscription
                             org = client org, subscription active, client active with webhooks:manage
                             — else status='dropped', reason code, no send
                          3. SSRF guard → pinned HTTPS POST → 2xx = delivered; else visibility backoff
```

- **SSRF guard** (`src/webhooks/ssrf.py`, stdlib only): at subscribe time *and* at every attempt:
  scheme `https`, port 443, hostname not an IP literal, `socket.getaddrinfo` → **every** A/AAAA
  answer must be public (reject `is_private`, loopback, link-local incl. `169.254.0.0/16` and
  `fd00:ec2::254`, multicast, reserved, unspecified, CGNAT `100.64.0.0/10`, `198.18.0.0/15`,
  IPv4-mapped/NAT64 forms unwrapped first, and the VPC CIDR from config). Then **connect to the
  validated IP** (`http.client.HTTPSConnection` subclass that opens the socket to the IP and wraps
  it with `ssl.create_default_context().wrap_socket(sock, server_hostname=host)` — certificate
  checked against the hostname), no redirects (http.client never follows), 3 s connect / 10 s
  total, response body read capped at 4 KB and discarded. Network backstop: the sender's security
  group; the ALB SG only admits CloudFront (ADR 0015); Lambda has no IMDS.
- **Signature contract** (plan step 5, Codex M): headers `Meridian-Event-Id`,
  `Meridian-Signature: t=<unix>,v1=<hex HMAC-SHA256(secret, "<t>.<event_id>.<body>")>`; during a
  rotation's 24-hour overlap two `v1=` values are sent. Receivers reject `|now − t| > 300 s` and
  de-duplicate on `event_id`. Body: `{"id","type","occurred_at","data":{"run_id","process","state"}}`
  — ids only, no org id, no PHI. Verification helpers ship in both generated clients.
- **Secrets:** one Secrets Manager secret per subscription, value `{current, previous,
  previous_expires_at}` (one secret, not two, during overlap); encrypted with the existing
  artifacts CMK; the sender role reads only `meridian-<env>-webhook-*`.
- **Retries:** attempt 1 immediate, then visibility backoff ≈ 1 m, 5 m, 30 m, 2 h, 6 h, 12 h, 12 h
  (≈ 1.3 days, 8 receives) → DLQ; delivery `dead`; subscription auto-paused after 5 consecutive
  dead deliveries. **Redrive** (admin screen) re-enqueues the delivery id only — the tenant
  re-check in step 2 runs again. DLQ-depth alarm → `alerts.md`.
- **Why a Lambda, not the worker:** its own security group and IAM role separate "calls arbitrary
  internet URLs" from "reads PHI and posts to QuickBooks". Reserved concurrency 2 caps fan-out.
  (Alternative and trigger in §6.)

### 3.8 Admin screens (React, `web/` only)

`web/src/app/admin/api/…`, same design system and CLAUDE.md process-page rules (centred, stepped,
preview before commit, primary action top-right):

1. **API clients list** — name, kind, status, scopes, last used, BAA badge.
2. **Request a client** — stepped: name/kind → scopes/processes → IP allowlist → preview → submit.
3. **Approve** (superadmin) — reason field; shows the BAA row for `phi:read`.
4. **Secret shown once** — modal with copy button, explicit "this will not be shown again".
5. **Client detail** — edit scopes (preview the diff), rotate, disable, revoke (typed confirmation).
6. **Usage** — requests per day, error rate, last IPs (from `audit.api_request`, bounded window).
7. **Webhook subscriptions** — list/create/pause/rotate/test.
8. **Delivery log** — per subscription, status, attempts, our reason code, redrive.
9. **Partner BAAs** (superadmin) — record/revoke.

### 3.9 Process endpoints from the Phase 11 manifest (dependency, stated)

Phase 12 reads, from `src/processes/<id>/manifest.py` as Phase 11 step 1 defines it: `id`,
`name`, input types + validation, wizard steps including custom steps, outputs, required
permissions/scopes, `touches_phi`. It generates the five process endpoints in §3.2 by iterating the
registry — **no second registry, no per-process router**. It needs Phase 11 to allow two things,
which this plan asks the Phase 11 plan to include rather than adding later:

1. Each input type carries `max_bytes` and allowed content types (→ the pre-signed POST policy's
   `content-length-range` and `Content-Type` conditions), and the create-params pydantic model
   (contract §12.4's discriminated union) is reachable from the manifest.
2. **The queue-message actor may be a client.** Phase 11's message contract is `{run_id, org_id,
   actor_user_id, …}` and the worker refuses a message whose actor differs from the run row
   (plan line 570). A machine-started run has no user: the contract needs
   `actor: {kind: user|client, id}` matched against `created_by` / `created_by_client_id`.

### 3.10 OpenAPI and generated clients

- v3's document is generated from the FastAPI app itself (`app.openapi()` on a v3-only app, offline
  by `scripts/generate_openapi.py --v3`) → `openapi/meridian-v3.json`, checked in; not served live
  (inventory stays private; partners receive it at onboarding). `check_api_drift.sh` covers both
  documents until v2 retires. The hand `ROUTES` registry retires with v2.
- **TypeScript:** `openapi-typescript` → `web/src/lib/api/v3/schema.d.ts`, `openapi-fetch` client —
  **no new dependency**. Webhook verifier uses Web Crypto (no dependency).
- **Python:** `clients/python/meridian_client/` (a new top-level folder → `repo-layout.md` update).
  Two options, **needs Andres**: (a) `openapi-python-client` as a pinned **dev-only** generator; the
  generated package needs `httpx` + `attrs` at runtime *in the consumer's environment*, not the
  server's; (b) no new dependency — a small generator in `scripts/` emitting a stdlib-`urllib`
  client with `TypedDict`s (+~1 day). Default if no answer: (b). Webhook verifier: stdlib `hmac`.
- Both clients cache the 15-minute machine token until 60 s before expiry (this is also the cost
  control in §8).

### 3.11 Sandbox org (D-18)

- `scripts/make_sample_revenue.py` harvested from `aws-trial:deploy/aws-trial/make_sample_revenue.py`
  (output path moved to a temp dir; never committed), plus `scripts/seed_sandbox_org.py`
  (`--dry-run`): creates the org "Sandbox", its mappings from `config/mappings.example.xlsx`, and
  synthetic runs by calling the v3 API as a sandbox client (API-first, no DB backdoor).
- `scripts/staging_wipe.py` (`--dry-run`, `--confirm-env staging`, refuses production by account +
  stack name): drop and recreate the staging database from Alembic, empty both buckets including
  all object versions, write a wipe record to the Object-Locked audit bucket.
- **Mutual exclusion:** a sandbox session opens only if the newest wipe record is newer than the
  newest restore record; the restore procedure (`docs/runbooks/data-load.md`) gains a refusal if
  any `api_clients` row with `kind='sandbox' AND status='active'` exists. Sandbox Cognito app
  clients are deleted at session end (they cost money while they exist, §8).

### 3.12 Security test catalogue (`tests/security/`, OWASP API Top 10 2023)

Every test has a **known-bad control**: the same test run against a deliberately broken variant
(dependency override removing the check) must fail — otherwise it proves nothing (control-matrix
§3 rule).

| OWASP | Test file | What it attacks |
|---|---|---|
| API1 BOLA | `test_object_level_authz.py` | Every v3 route with an id: org A caller with org B's ids (runs, JEs, mappings, employees, subscriptions, deliveries, clients) → 404 identical to a random id (body + timing class); machine client of org A likewise; RLS proof with the predicate removed (known-bad) still returns nothing |
| API2 Broken auth | `test_auth_tokens.py`, `test_machine_tokens.py`, `test_session_cookie_flags.py` | expired / wrong `iss` / wrong `aud` / alg `none` / HS256-with-public-key / `token_use` swap (ID token as machine, access token as human) / revoked (`iat < revoked_epoch`) / disabled / unknown client / IP outside allowlist; cookie flags |
| API2 lockout | `test_progressive_lockout.py` | repeated 401s from one IP / one client id → growing delay, then `QUOTA_EXCEEDED` |
| API3 BOPLA | `test_unknown_fields_rejected.py`, `test_phi_masked_without_scope.py`, `test_response_field_classification.py` | extra body/query fields → 422; every `phi` field null without `phi:read`; every response model field classified |
| API4 Resources | `test_rate_limits.py`, `test_oversized_payload.py`, `test_zip_bomb_workbook.py` (tracker line 160), `test_pagination_bounds.py` | per-user / per-client quotas across two app instances (shared counter), 413 on body and chunked body, xlsx entry-count/ratio bound, `limit=1000` → 422 |
| API5 BFLA | `test_route_authz_matrix.py`, `test_scope_enforcement.py`, `test_human_only_scopes.py` | every route declares a scope; each scope-less / wrong-scope call → 403; machine can never hold `clients:manage` etc. (DB CHECK and API) |
| API6 Business flows | `test_execute_rate_and_idempotency.py` | execute without `Idempotency-Key` → 428; same key twice → one QBO post (fake QBO); execute caps |
| API7 SSRF | `test_webhook_ssrf_blocked.py`, `test_webhook_dns_rebinding.py` | `169.254.169.254`, `[::ffff:169.254.169.254]`, `fd00:ec2::254`, `localhost`, decimal/octal IP forms, `http://`, port 8080, redirect to metadata, a name that resolves public-then-private between check and connect (fake resolver) → the socket connects to the first-checked IP or refuses |
| API7 replay | `test_webhook_signature_replay.py` | tampered body, old `t`, duplicate `event_id`, rotation overlap both secrets verify |
| API7 tenancy | `test_webhook_tenant_recheck.py` | subscription moved/disabled/client revoked between enqueue and retry → `dropped`, nothing sent |
| API8 Misconfig | `test_security_headers.py`, `test_cors_denied.py`, `test_errors_do_not_leak.py`, `test_method_not_allowed.py` | headers on 200/4xx/5xx; foreign `Origin` gets no ACAO; forced exception → envelope with `request_id` only, no traceback/SQL/org id; 405 |
| API9 Inventory | `test_v1_v2_retired.py` (at retirement), `test_openapi_matches_routes.py` | every mounted route is in the OpenAPI doc and vice versa; retired prefixes 404 |
| API10 Unsafe consumption | `test_idp_claims_not_authz.py`, `test_malware_tag_required.py` | a token claiming `custom:role=admin` grants nothing; a run cannot start on an upload without the clean tag |
| Audit | `test_api_audit_row.py`, `test_no_phi_in_api_logs.py` | every v3 call writes one `audit.api_request` row with no PHI; `meridian_app` cannot UPDATE/DELETE it |

Plus, on staging: **ZAP baseline, authenticated** (bearer header injected), target **no HIGH**,
MEDIUMs to the tracker; and the external pen test before any real partner reaches production
(`needs-a-human`).

### 3.13 Retiring `/api/v1` and `/api/v2` (D-25)

**Cross-phase catch:** the ten non-health `/api/v1` routes live in `web_app.py:8056-8184`, and
**Phase 11 deletes `web_app.py`**. They cannot survive to Phase 12. Recommended: with Andres's
sign-off, Phase 11 deletes them in the Flask-removal commit (no caller exists — §2.1), with
`test_v1_v2_retired.py`'s v1 half landing there. Only `/api/v1/health` (FastAPI) reaches Phase 12.

Sequence (each step its own commit and deploy):

1. **Add** `GET /api/v3/health` (same body shape with `version` = v3) — additive, both paths live.
   Deploy to staging, then production.
2. **Switch families** to v3 in React one at a time (session → config → users → invoices → pnl →
   dashboard → superadmin → runs/processes), each commit: regenerate types, switch the
   `web/src/lib/api/*` module, delete that family's v2 decorators, update the drift gate. React
   tests + Playwright walk of the screen.
3. **D-25 commit** (with Andres's written sign-off): change `API_HEALTH_PATH` (`edge.py:103`),
   `HEALTH_PATH` (`observability.py:309`), the container check (`compute.py:705` via the import),
   the infra tests, and delete `/api/v1/health` + `/health` — in one commit. Safe because every
   running task already answers `/api/v3/health` from step 1; deploying a health-check path the
   old tasks do not serve is what would cause an outage, and step 1 removes that case.
4. **v2 end:** delete `api/routers/*` v2 modules, `openapi/meridian-v2.json`, the `ROUTES`
   registry, `web/src/lib/api/schema.d.ts` (v2); rename `src/api/v2/` (framework-free services the
   v3 routers still call) to `src/api/services/` in the same commit. `/api/:path*` stays proxied.
5. `test_v1_v2_retired.py`: `/api/v1/*` and `/api/v2/*` → 404 envelope; nothing in `web/`,
   `infra/`, `scripts/`, `docs/runbooks/` references them.

### 3.14 Final cleanup

- `docs/migration-tracker.md` **Open items empty** — including line 42 (mypy covers `src/` and
  `api/`), line 114 (legacy CLI `process_revenue.py`/`process_unposted.py`, `data/revenue.db`,
  `DatabaseSQLite` deleted — **destructive, Andres**), line 132 (dead flags `renderRecords`,
  `acceptSupabaseTokens`, `legacyMigration`, `lambda/user_migration/`, `src/auth.py`'s Supabase
  branch and `settings.accept_supabase_tokens()`), line 160, line 166.
- Every folder README true; `docs/architecture/repo-layout.md` matches `git ls-files` (adds
  `clients/`, `api/v3/`, `src/webhooks/`, `lambda/webhook_sender/`; removes `templates/`,
  `supabase_migrations/` note, `tests/legacy_supabase/`); `CHANGELOG.md`; control matrix OWASP
  rows → "in place" with evidence; `README.md`; local `CLAUDE.md` + tracked note (API section).
- The placeholder `meridian-<env>-auth-machine` CDK client is deleted (clients are runtime rows
  now) — see §8, it may cost money.

---

## 4. Ordered work breakdown

Tags: **[LOCAL-NOW]** Mac + local Postgres, no AWS; **[AFTER-P11]** needs the Phase 11 manifest or
worker; **[NEEDS-AWS]** staging/production; **[NEEDS-ANDRES]** a decision, approval or signature.

**Ordering risk, stated plainly.** Building v3 before Phase 11 risks rework only where it touches
runs: the run *store*, artifact storage, the state machine and the queue contract all change in
Phase 11. So everything that reads or drives runs beyond a plain `process_runs` read is
AFTER-P11. The platform machinery (scopes, machine auth, audit, quotas, webhook sender, admin,
mapping/employee/allocation resources, tests) does not depend on Phase 11 and is safe now.
**Second risk:** D-16 put Phase 12 after cutover so it would not compete with it. LOCAL-NOW work is
worth doing only while the cutover is waiting on Andres (status report §"What blocks"), and it
ships behind `MERIDIAN_API_V3` (off) and `DATABASE_BACKEND=postgres`, so nothing reaches Render.

| # | Task | Goal | Files | Tests | Deps | Days | Tag |
|---|---|---|---|---|---|---|---|
| T01 | ADRs + pricing check | Write ADRs 0035-0043 (§7; renumbered from 0027+, see the §7 note); verify Cognito M2M pricing and multi-secret rotation with the Pricing API/docs; record provisional decisions | `docs/adr/`, `docs/reports/phase-1-cost-estimate.md` | — | — | 1-1.5 | LOCAL-NOW (pricing read needs no spend) |
| T02 | v3 skeleton | `api/v3/` package (routers, deps, schemas), mounted behind both flags; `/api/v3/health`; 405 handling; empty CORS; reuse `api/errors.py` | `api/v3/*`, `api/main.py` | `test_v3_mount.py`, `test_method_not_allowed.py`, `test_cors_denied.py` | — | 1-1.5 | LOCAL-NOW |
| T03 | Caller + scopes | `Caller` (human/machine), `src/api_scopes.py`, `require_scope`, human derivation | `src/api_scopes.py`, `api/v3/deps.py` | `test_scope_enforcement.py`, `test_route_authz_matrix.py`, `test_human_only_scopes.py` | T02 | 1.5-2 | LOCAL-NOW |
| T04 | Alembic revision | §3.5 tables, RLS, grants, `app.api_client_for_token`, append-only audit | `migrations/versions/00NN_api_platform.py` | migration up/down on `pg_fixture`; RLS cross-org; audit append-only | Phase 11 revisions merged first *or* renumber at merge | 1.5-2 | LOCAL-NOW. **Deviation (2026-09-24, built as `0013_api_platform` revising 0010):** `app.api_client_for_token` also returns `baa_active` (a revoked/expired BAA must drop `phi:read` on the next request) and is owned by a NOLOGIN `meridian_api_lookup` role with a column grant + SELECT-only policy (FORCE RLS applies to the owner, so an owner-owned definer function would see nothing); audit tables also carry an append-only trigger (owner included); `DELETE` revoked from `meridian_app` on `api_clients`, `partner_baas`, `api_events`. **Security fix (2026-09-24, edited in place — applied nowhere but throwaway test databases):** the migrator's membership in `meridian_api_lookup` is now `WITH INHERIT FALSE, SET TRUE` (the 0011 `meridian_job_control` pattern) and the downgrade `SET ROLE`s for the function drop; the plain `GRANT … TO CURRENT_USER` inherited the lookup role's `USING (true)` policies, so the owner read every org's `api_clients`/`partner_baas` with no `app.org_id`. Proven by `test_the_owner_sees_no_client_or_baa_without_an_org` + a known-bad control, and chain-wide by `tests/test_migrations.py::test_the_migrator_inherits_no_role_the_chain_granted_it`. |
| T05 | Machine tokens | `validate_machine_token`, row lookup, `revoked_epoch`, IP allowlist, PHI cert-subject gate | `src/cognito.py`, `api/v3/deps.py` | `test_machine_tokens.py` (locally generated RSA JWKS, as the Cognito tests do) | T03, T04 | 1.5-2 | LOCAL-NOW |
| T06 | API audit | Middleware writing `audit.api_request` (route template, record id, scope, status, ip) | `api/v3/audit.py` | `test_api_audit_row.py`, `test_no_phi_in_api_logs.py` | T04 | 1-1.5 | LOCAL-NOW |
| T07 | Read resources | `/processes`, `/runs` (read), `/journal-entries`, `/mappings`, `/employees`, `/allocations`, `/revenue/summaries`; keyset helper; masking serializer | `api/v3/routers/*`, `api/v3/pagination.py`, `api/v3/masking.py` | `test_object_level_authz.py`, `test_pagination_bounds.py`, `test_phi_masked_without_scope.py`, `test_response_field_classification.py` | T03-T06 | 3-4 | LOCAL-NOW |
| T08 | Write resources | mapping / employee / allocation writes reusing `src/api/v2` service functions | `api/v3/routers/*` | `test_unknown_fields_rejected.py`, BOLA on writes | T07 | 1.5-2 | LOCAL-NOW |
| T09 | Quotas + lockout | Postgres fixed-window counters (per client, per user, per IP on auth), progressive lockout | `api/v3/quotas.py` | `test_rate_limits.py` (two app instances, one DB), `test_progressive_lockout.py` | T04 | 1-1.5 | LOCAL-NOW. **Deviation (2026-09-24):** "per IP on auth" is the auth-FAILURE counter (lockout) only; per-IP allowances on the sign-in routes land when those routes are re-homed under v3 (T20). Only bearer-token 401s are counted (cookie 401s from one office NAT must not lock the office out), and a client-id bucket counts only signature-verified tokens. |
| T10 | SSRF + signing | `src/webhooks/ssrf.py`, pinned HTTPS sender, `signing.py` (sign/verify, overlap) | `src/webhooks/*` | `test_webhook_ssrf_blocked.py`, `test_webhook_dns_rebinding.py`, `test_webhook_signature_replay.py` (local TLS server with a test CA) | — | 2-2.5 | LOCAL-NOW |
| T11 | Webhook engine | subscriptions API, outbox publisher (port), fan-out + delivery state machine with tenant re-check, retry schedule, redrive — driven by an in-process fake queue | `src/webhooks/engine.py`, `api/v3/routers/webhooks.py`, `lambda/webhook_sender/handler.py` | `test_webhook_tenant_recheck.py`, fan-out idempotency, DLQ path | T04, T10 | 2-2.5 | LOCAL-NOW. **Deviation (2026-09-24):** revision `0014_webhook_delivery_history` adds `webhook_deliveries.created_at` + `last_attempt_at` and the `(org_id, created_at DESC, id DESC)` index the §3.3 delivery log needs (0013 had no `created_at`); ports live in `src/webhooks/ports.py` and the CRUD in `src/webhooks/subscriptions.py`; DELETE is a soft delete (`status='disabled'`, secret deleted, delivery log kept — the FK and the audit value of the log); a test ping is a `webhook.test` event through the same engine; a URL refused by the SSRF guard at delivery is a failed attempt (`SSRF_BLOCKED`, retried per schedule, then `dead`), not a drop, since DNS may recover; the engine marks `dead` itself at attempt 8 and the Lambda copies the message to the DLQ (the SQS redrive policy stays the backstop for crashes). |
| T12 | Client admin API | request/approve/grant/rotate/revoke/disable; `CognitoClientAdmin` port + fake; 90-day disable job; `scripts/api_access_review.py` | `api/v3/routers/admin_clients.py`, `src/api_clients.py`, `scripts/` | revoke-within-one-request, approval required, phi:read refused without BAA+subject | T04, T05 | 2-2.5 | LOCAL-NOW (real Cognito: T24). **Gaps T13 found, closed 2026-09-24** (revision `0016_api_client_admin_gaps`): `GET …/usage?days=1..90` now returns requests and errors per UTC day, the error rate and the last five addresses, read from `audit.api_request` through two aggregate-only `SECURITY DEFINER` functions (`app.api_client_usage`, `app.api_client_recent_ips`) owned by a NOLOGIN `meridian_usage_reader` — `meridian_app` still cannot read a raw audit row; both refuse unless the org named is the session's, answer nothing past 90 days, and ride `idx_api_request_client`. `GET/POST /admin/partner-baas` + `POST /{id}/revoke` (`src/partner_baas.py`). `api_clients.rotation_started_at` → `rotation_in_progress` on the client resource. **Deviations:** (1) the BAA routes declare `clients:manage` and check the superadmin in `src/` through `with_superadmin` (like `approve`), because no v3 caller is ever granted the `superadmin` scope; a non-superadmin gets 403 `PERMISSION_DENIED`, and each call writes an `audit.superadmin_access` row (who revoked and why also land on the row: `revoked_by`, `revoked_reason`); (2) usage counts only calls that authenticated as the client — a refused token's audit row names no client; (3) the rotation flag is a display hint kept beside Cognito, which stays the authority (`complete` still asks Cognito how many secrets exist). |
| T13 | Admin screens | §3.8 screens in React | `web/src/app/admin/api/**`, `web/src/lib/api/v3/*` | vitest + vitest-axe; Playwright walk against local api | T12, T11, T14 (TS types) | 3-4 | LOCAL-NOW  **Built 2026-09-24.** `/admin/api` (tabs: API clients, Webhooks, Delivery log), `/admin/api/clients/new` and `/admin/api/webhooks/new` (stepped, preview before submit), `/admin/api/clients/[clientId]` (approve, edit access with a diff preview, rotate / finish rotation, disable / enable, revoke with a typed name, usage), all over T14's `platform.ts`; EN + ES. **Deviations:** (1) §3.8 item 6 *Usage* shows what `GET …/usage` returns — last use, last IP, the idle-disable date; requests per day and error rate need an aggregate endpoint over `audit.api_request` that T12 did not build. (2) §3.8 item 9 *Partner BAAs* is not built: there is no v3 endpoint to record or revoke a BAA, so the request and edit forms take a BAA id typed by hand and the server checks it is in force. (3) The sidebar link (and the gate) show only for the org `admin` role AND when `GET /api/v3/health` answers `3.x` (`web/src/lib/api/v3/use-available.ts`), failing closed — v3 is off on Render. (4) "Finish rotation" is offered on every active client: the API does not say whether a rotation is in progress, so the server's 409 is shown on the page. (5) No Playwright walk: the repo has no Playwright test setup (only `scripts/capture_screens.mjs`), and a local v3 needs Postgres plus the Cognito/Secrets ports wired into a running server; the screens are covered by vitest + vitest-axe at 390 and 1280 px instead. **Deviations (1), (2) and (4) closed 2026-09-24** with the T12 gaps: a usage panel (7/30/90-day window, requests per day as CSS bars with a visually-hidden table, error rate, recent IPs); a **Partner BAAs** tab and a stepped `/admin/api/baas/new` (agreement → preview → record) with revoke-with-reason naming how many clients lose `phi:read`; "Finish rotation" only while `rotation_in_progress`. **New deviations:** `/me` carries no superadmin flag, so the BAA tab appears only when `GET /admin/partner-baas` succeeds (one audited superadmin read per visit to `/admin/api`); the request/edit forms still take a typed BAA id (no picker). |
| T14 | OpenAPI + clients | v3 document, drift gate, TS client, Python client, verify helpers | `scripts/generate_openapi.py`, `scripts/check_api_drift.sh`, `openapi/meridian-v3.json`, `clients/python/` | `test_openapi_matches_routes.py`; `npm run typecheck`; Python client smoke vs `TestClient` | T07; **Python generator choice** | 2-3 | LOCAL-NOW + NEEDS-ANDRES (dep). **Built 2026-09-24** (dep approved 2026-09-22: `openapi-python-client==0.29.1`, `requirements-dev.txt` only). **Deviations:** the v3 document is post-processed after `app.openapi()` — every error answer is the §4.1 envelope (FastAPI's `HTTPValidationError` removed), each operation carries `x-required-scope` read from `require_scope`, the six raw-body handlers get their request models from a declared table (a test fails if a mutating operation has neither a body nor a `V3_BODYLESS` entry), `Paged_X_` components are renamed `PagedX`, and the scope catalogue is published as `x-scopes`; the Python client is generated with `--meta none` (a package, no `pyproject.toml`) by `scripts/generate_python_client.py`, and the hand-written verifier + token cache are `clients/python/meridian_helpers.py` beside it; the TS side adds `webhook-signature.ts`, `machine-token.ts` and typed wrappers (`platform.ts`) next to `client.ts`; CI: pytest holds the JSON + Python client in step, the `web` workflow regenerates both `schema.d.ts`. |
| T15 | Security suite | Rest of §3.12, known-bad controls, zip-bomb bound in the upload path | `tests/security/*`, `src/storage.py` or upload validation | itself | T02-T12 | 3-4 | LOCAL-NOW  **Built 2026-09-24.** New: `test_auth_tokens.py` (human ID tokens: expired, wrong iss/aud, `alg: none`, HS256 with the public key, unknown key, access-token-as-human), `test_session_cookie_flags.py`, `test_oversized_payload.py` (declared and chunked), `test_zip_bomb_workbook.py`, `test_security_headers.py` (200/401/403/404/405/413/422/500), `test_errors_do_not_leak.py`, `test_idp_claims_not_authz.py`, plus `test_api_client_usage_and_baas.py` for the T12 gaps. **`--known-bad`** (`tests/security/known_bad.py`, option in `tests/conftest.py`): every test names a breaker (`@breaks`, a module `KNOWN_BAD` table or `KNOWN_BAD_DEFAULT`) installed after fixture setup and undone before teardown; the inline `test_known_bad_*` controls are deselected under the flag; `test_known_bad_registry.py` fails the normal run if any test lacks a breaker. Result: 498 passed / `--known-bad` 456 failed, 0 passed, 42 deselected. Zip-bomb bound: `src/storage.check_workbook_container` (central directory only: > 10 000 entries, > 1 GiB declared, > 250:1 on an entry over 10 MB), called from `api/uploads.form_and_files` (`FILE_UNREADABLE` 422) and `S3StorageManager._check_upload`. Error envelopes now carry `Cache-Control: no-store` on `/api/` and `/auth/` (a 500 bypassed the middleware that set it). **Deviations:** `test_execute_rate_and_idempotency.py` and `test_malware_tag_required.py` wait for T18 (no v3 process endpoints to attack), `test_v1_v2_retired.py` for T26, and `test_openapi_matches_routes.py` stays in `tests/` where T14 put it (tracker rows); the legacy Jinja upload handlers in `web_app.py` are not bounded (deleted with the Flask mount; tracker row); the nine BOLA list tests' breaker hands the caller org B's id (tenant confusion) rather than stripping the predicate and RLS from every list route; a few breakers fail on a second layer that stays on (a DB CHECK, a 503 reaching Postgres) — still red, noted in the files. |
| T16 | Mobile readiness | `docs/plans/mobile-readiness.md` (bearer flow, refresh, MFA challenge, pre-signed uploads; never `custom:app_uid`, never cache PHI) | docs | — | T05 | 1-1.5 | LOCAL-NOW |
| T17 | Runbooks | `revoke-api-client.md`, `onboard-partner.md`, webhook DLQ triage in `alerts.md` | `docs/runbooks/` | — | T11, T12 | 1-1.5 | LOCAL-NOW. **Built 2026-09-24** (recovered from a dead agent's worktree and finished): `revoke-api-client.md`, `onboard-partner.md`, and `alerts.md` §8 — the `api` stack's two alarms plus webhook DLQ triage and redrive (missing from the recovered work; written here). **Deviation:** `onboard-partner.md` covers clients that do not read PHI; a PHI client is a stop-and-ask-Andres, because the T25 ingress, a BAA-recording screen and `phi:read` on the resource server do not exist yet. Never executed — T24 makes them evidence. |
| T18 | Process endpoints | generated from manifests: upload (pre-signed POST, malware tag gate), create run (idempotent), actions, artifacts, downloads | `api/v3/routers/processes.py` | BOLA, `test_malware_tag_required.py`, `test_execute_rate_and_idempotency.py`, redelivery | Phase 11 manifest + §3.9 items | 3-4 | AFTER-P11. **Built 2026-09-24 (local).** `api/v3/routers/processes.py` has no per-process code: `build_router()` iterates the registry (`src/process_api.api_processes()`) and generates `POST /api/v3/processes/{id}/runs` per manifest (body = its `params_model`, strict), `POST /runs/{run_id}/uploads`, one `POST /runs/{run_id}/actions/{kind}` per job kind a manifest declares with a handler (today `execute` → `processes:execute`, `retry` → `processes:run`), `GET /runs/{run_id}/artifacts` (`runs:read`) and `POST /runs/{run_id}/artifacts/{artifact_id}/download-url` (`artifacts:download`); the framework-free half is `src/process_api.py`. Flow: create → a `draft` at step `upload` (creator = the person, or the machine client in `created_by_client_id`); upload → a 300 s pre-signed POST (`S3InputStore.presigned_post`, botocore signs locally) whose policy pins the exact key `{org}/{run}/uploads/{upload_id}-{name}`, the one `Content-Type` the manifest lists for the extension, `content-length-range` 1..min(`InputSpec.max_bytes`, `MERIDIAN_MAX_UPLOAD_BYTES`), SSE-KMS with the bucket's key and the raw-upload tag, recorded on the run in ONE conditional UPDATE (`process_runs.add_pending_upload`: draft only, `max_files` held); execute → for a draft, every grant is pinned at its CURRENT version only if GuardDuty tagged THAT version `NO_THREATS_FOUND` (`process_inputs.adopt_upload`: untagged `409 FILE_SCAN_PENDING`, run untouched; any other verdict `422 FILE_UNSAFE`, run failed; then size/type/`vet_upload`), the manifest's validator opens the bytes, the manifest's new `prepare` derives the job params, both written once (`process_runs.pin_inputs`, conditional on the inputs as read), then D4's `runs_common.start_job` (`begin_action` compare-and-set, `enqueue` on `WORKER_PROCESSES`, else the in-process `run_job`) inside E3's `run.execute` ledger (`execute_idempotency.run_once`, shared with v2). The worker gates the version again. BOLA: a run is read by `run_id AND org_id` under RLS; invisible (another org's, a process the caller holds neither the route's scope nor `runs:read` for, nothing) is one `404 RUN_NOT_FOUND`, visible-but-not-actionable is `403 SCOPE_INSUFFICIENT`; `phi`-bucket artifacts are left out of the list and 404 on download without `phi:read`, and a mint goes through v2's audited path (`audit.phi_access` pair; `artifact_downloads` now records `api_client_id`). A machine-started job acts as its client: `workers/inprocess.job_message` falls back to `created_by_client_id` (the actor `app.authorize_job` already accepted), so redelivery and `Dispatcher.recover()` rebuild it too. Job starts are capped at `quotas.JOB_START_LIMIT` (30) per org and process per hour (`quotas.cap`, shared counters) on top of the per-caller allowance; every call gets its `audit.api_request` row (T06); `PROCESS_SUBMISSIONS_PAUSED` → 503 on create/upload/actions. Tests: `tests/security/test_malware_tag_required.py` (9), `test_execute_rate_and_idempotency.py` (8), `test_object_level_authz_processes.py` (18), each test with its breaker; `tests/test_v3_process_endpoints_pg.py` (22: generation, the flow end to end through the real `run_job`, mx's period from the file, refusal fails the run, retry from `blocked`, grant limits, pause, redelivery after a dead delivery thread, `recover()` of a killed process's machine job). OpenAPI v3 (+8 operations, +12 schemas, purely additive), TS types, Python client regenerated. Counts: full suite 4436 passed / 116 skipped; `tests/security` 548 passed, `--known-bad` 502 failed / 1 passed / 45 deselected (the one pass, `test_zip_bomb_workbook.py::test_the_storage_gate_refuses_a_bomb_as_a_raw_upload`, predates T18: since the D4 wave `vet_upload` also refuses the bomb on its file signature, so switching off the container bound alone leaves it refused); `check_api_drift.sh`, ruff (S on), ruff format, mypy, the org-scope / PHI-logging / route-ownership / processor-purity lints green; no migration. Also hardened in passing: `Dispatcher.recover()` skips a run whose recorded inputs are malformed instead of aborting the whole pass (`KeyError`/`TypeError` were uncaught). **Deviations:** (1) the upload is `POST /runs/{run_id}/uploads`, not `/processes/{process}/uploads`: the key must sit under the run (`{org}/{run}/uploads/`, C1/PS-15 and `app.authorize_job`), so a v3 run is create (draft) → upload → `execute`, not v2's create-is-execute multipart (§12.1). (2) `ProcessManifest.prepare` (+ `PreparedRun`) added; qb-revenue's and mx-payroll's `derive_params` are now the ONE place v2 (`oneshot_runs._revenue_prepare`/`_mx_prepare`) and v3 build a run's params; v3 generates endpoints only for a manifest with `prepare`, so **qb-usa has none yet** (its create classifies and parses; review and declarations are custom steps) — tracker row. (3) The plan's `UPLOAD_NOT_SCANNED`/`UPLOAD_REJECTED` are C1's `FILE_SCAN_PENDING` (409) / `FILE_UNSAFE` (422): one catalogue; new v3 code `IDEMPOTENCY_KEY_REQUIRED` (428) on create and execute. (4) The create key is `process_runs.idempotency_key` namespaced `v3:<process>:<key>` plus a fingerprint of params and caller in `inputs.create_fingerprint` (other params or another caller → `409 IDEMPOTENCY_CONFLICT`); no new ledger scope, no migration. (5) An action a process does not declare is 404, one not legal now 409 (`RUN_STATE_INVALID`, or `RUN_STATE_CHANGED` for the loser of a race); `qbo_push`, `review`, `declarations` and `GET /runs/{id}/downloads` are not built (tracker). (6) A v3 run writes no `uploads` table row (`upload_id` null on its batch). (7) Browser use of the pre-signed POST needs bucket CORS + CSP (tracker, R12); the React app stays on v2. (8) The TS types were generated with the main checkout's `web/node_modules` (openapi-typescript 7.13.0; the worktree has none) and `tsc --noEmit` is clean. |
| T19 | Event emission | outbox write in the worker's state-change transaction, PutEvents port, 5-min sweep | `workers/`, `src/webhooks/outbox.py` | outbox-rollback test; sweep republishes | Phase 11 worker, T11 | 1-1.5 | AFTER-P11. **Built 2026-09-24 (local).** `workers/run_job._settle` writes the `api_events` row through `src/webhooks/outbox.record_run_event` (T11's `engine.record_event`) inside the fenced UPDATE's own transaction — `_fenced` now runs in `PgSession.transaction()` (the layer is autocommit) and takes a `same_transaction` callback — and only when the settle lands AND changes the state into `completed`/`failed`/`blocked`/`needs_input` (a `qbo_push` settling `completed` back into `completed` announces nothing). After commit `outbox.publish_after_commit` hands it to the `EventPublisher` port (T11's `EventBridgePublisher`, `PutEvents` with `{event_id, org_id, type}`) and stamps `published_at`; it never raises (logs the class name) — the job is settled and the message deleted either way. `python -m workers.outbox_sweep [--dry-run]` re-publishes rows still unpublished after a 60 s grace, oldest first, ≤ 500 a pass, each under its own org's `with_org`; the cross-org list comes from revision `0019_outbox_sweep`'s `app.unpublished_api_events` (ids only, bounded, owned by `meridian_job_control`, which gains 4-column SELECT + a `USING (true)` policy on `api_events` alone). Publishing locks the row `FOR UPDATE SKIP LOCKED`, so the worker and the sweep do not both publish it; a duplicate publish anyway is harmless (fan-out is keyed on the event id). `tests/test_webhook_outbox_pg.py` (31): each settled state → its event; rollback after the outbox INSERT → no event and no state change (known-bad control: `transaction()` disabled → phantom `run.completed`); lease lost → no event; failed publish → job settled, sweep republishes, grace respected, dry run writes nothing, bus failure leaves rows; same event published twice → one delivery through T11's engine with the same `Meridian-Event-Id`; cross-org (another org's session publishes nothing, the app role alone lists nothing, each event goes out under its own org); every `api_events` column and every detail field classified id / event type / timestamp (known-bad: a name, a member id, free text); the EventBridge adapter through botocore `Stubber` only (exact request; `FailedEntryCount` and a service error leave the row unpublished). **Deviations:** (1) the sweep is its own job (`workers/outbox_sweep.py`, meant for EventBridge Scheduler → ECS RunTask every 5 min, T21's idle-sweep shape), not D5's sweeper: D5 runs every 15 min and the v1 job contract has no message kind for it; the schedule and the worker's `WEBHOOK_EVENT_BUS` + `events:PutEvents` are a tracker row (not in `infra/`). (2) Without `WEBHOOK_EVENT_BUS` the worker records and does not publish (the engine's in-process publisher would stamp rows into a queue no worker drains). (3) ~~Only the worker's settle emits~~ — **closed 2026-09-24 (T19 follow-up):** revision `0020_sweeper_run_events` makes `app.expire_stale_runs` insert its `run.failed` / `run.expired` rows in the same call (control role: 3-column INSERT on `api_events` + a `FOR INSERT` policy that admits only the state the run is in); `process_runs.set_state` on RDS (`PostgresRunStore.upsert_announced`) records its event in the UPDATE's transaction, deciding on a `FOR UPDATE` read, which also covers the in-process threads' `run_store` settles. The writer whose statement changes the state owns the event, so two writers racing to one state emit one. New event type `run.expired` (§3.5). `tests/test_run_event_writers_pg.py` (18). **D17 (2026-09-24, provisional: the ≈ $0 option):** the 5-minute sweep is no longer its own ECS task. It is an `outbox_sweep` tick on the job queue — `workers.contract.OutboxSweepMessage`, a v1 body of the `sweep` tick's shape (a pre-D17 image dead-letters it as `malformed_message`; the runbook's rollback note says to disable the schedule first) — that `workers.run_job` hands to `workers/outbox_sweep.run_outbox_sweep_job`, the same `run_pass` the CLI runs (the CLI stays for manual runs). Off RDS it is dead-lettered as `outbox_sweep_not_enabled`; a database outage leaves it for redelivery; a bus failure still deletes it (the next tick finds the rows). Infra: schedule `meridian-<env>-schedule-outbox-sweep` (`rate(5 minutes)`, 2 retries inside 4 min) in the worker's schedule group through the existing `meridian-<env>-iam-sweep-scheduler` role, only with `enableApiPlatform` AND `worker_enabled`; `ApiStack._outbox_sweep` and `meridian-<env>-iam-outbox-sweep` removed; with the api platform alone synth warns `meridian:outbox-sweep-needs-worker`. Flag-off synth byte-identical (all templates, both environments, and worker-only too); the api-only combination loses the schedule, role and three compute exports that only it imported (never deployed, so no export-in-use trap). Cost ≈ −$6/env/month (≈ 8 640 Scheduler invocations and ~26 000 SQS requests a month, inside both free tiers). `tests/test_worker_outbox_sweep_pg.py` (13), `infra/tests/test_worker.py` / `test_api_platform.py` updated. |
| T20 | React → v3 | §3.13 step 2, family by family | `web/src/lib/api/**`, `api/routers/*` (delete v2) | web tests per family; Playwright | T14; runs family AFTER-P11 | 4-6 | LOCAL-NOW (non-run families) / AFTER-P11 |
| T21 | CDK | resource-server scopes, delete placeholder machine client, api IAM for app-client admin scoped to the pool ARN (no `DescribeUserPoolClient`), events bus rule, `sqs-webhooks` + DLQ (KMS), sender Lambda + SG + role, `webhook-*` secret policy, WAF `/api/v3` rate rule, alarms (DLQ depth, auth failures, new IP, scope change) | `infra/meridian/stacks/{auth,api,edge,observability}.py`, `infra/tests/*` | `cdk synth` + infra tests locally; tag/naming tests | T11, T12 | 2-3 | LOCAL-NOW (synth) → NEEDS-AWS (deploy). **Synth-only built 2026-09-24**, all behind `-c enableApiPlatform=true` (default off: `meridian-<env>-api` stays empty and a deploy changes nothing). **Deviations:** the alarms live in `stacks/api.py`, not `observability.py` (they exist only with the flag), and 2 of the 4 are built — DLQ depth and machine-token refusals; new-client-IP and scope-change have nothing emitting them yet (tracker row); the refusal metric is `MachineTokenRefused-<env>` because a plain-text filter cannot carry the `Environment` dimension; both queues use the existing `logs` CMK (no new key); the sender reads the `meridian_app` password from its secret ARN at cold start (never a Lambda env var) and still logs in as `meridian_app` (a dedicated login is a tracker row); names `compute` shares with `api` live in `infra/meridian/api_platform.py` (avoids an import cycle); the daily idle sweep is EventBridge Scheduler → ECS RunTask of the api task, created only with `-c apiIdleSweepActor=<id>`; the seven Cognito IAM action names were verified against the Service Authorization Reference (ADR 0037). Checked by `infra/tests/test_api_platform.py` (in-process synth, bundling skipped); `cdk` CLI not run, and the sender Lambda asset has never been built (needs Docker — tracker row). |
| T22 | Sandbox tooling | harvest `make_sample_revenue.py`; `staging_wipe.py`; `seed_sandbox_org.py`; restore refusal | `scripts/*`, `docs/runbooks/data-load.md` | dry-run tests; refusal test | T12 | 2-2.5 | LOCAL-NOW (write) → NEEDS-AWS (run). **Written 2026-09-24, never run against AWS.** `scripts/make_sample_revenue.py`, `seed_sandbox_org.py`, `staging_wipe.py`, `restore_guard.py` and the shared `sandbox_session.py`; `data-load.md` step 0. `tests/test_sandbox_tooling.py` uses recording fakes plus an autouse guard that fails any test reaching boto3, the network, psycopg2 or Alembic. **Deviations:** the restore refusal is its own script (`restore_guard.py`, exit 3), reading `api_clients` through the audited superadmin scope and failing closed; the wipe also deletes the runtime Cognito app clients and refuses unless the database's own `inet_server_addr()` is in staging's VPC range; the seed does not create the org (no v3 endpoint — Andres creates it in the console) or start synthetic runs (v3 process endpoints are T18, AFTER-P11), and writes the workbook for a manual upload instead. Sample data: placeholder providers/payers, synthetic accounts/claims/amounts; the facility names come from `config/mappings.example.xlsx`, which holds the client's real clinic names (**NEEDS-ANDRES:** keep, or swap for fictional ones before the first outside partner). |
| T23 | Sandbox + ZAP on staging | staging session: wipe → deploy → seed → sandbox client → ZAP authenticated baseline → fix → teardown | CI job or script | ZAP report, no HIGH | T21, T22; ZAP tooling approval | 1.5-2 | NEEDS-AWS + NEEDS-ANDRES (tool) |
| T24 | Staging end-to-end | real Cognito client-credentials; revoke → refused within 1 min; webhook to a receiver **we** run (staging Lambda URL) incl. `169.254.169.254` refusal; replay rejected; masked fields | evidence in phase report | the plan's Verify line, live | T21, T18/T19 | 1-1.5 | NEEDS-AWS |
| T25 | Partner mTLS (conditional) | API Gateway custom domain + truststore + origin-verify secret; `phi:read` in resource server; same-token-every-ingress test | new CDK stack, `onboard-partner.md` | `test_phi_requires_cert_subject.py` live | a signed partner BAA | 3-5 | NEEDS-ANDRES + NEEDS-AWS |
| T26 | Retire v2 | §3.13 step 4 | as listed | `test_v1_v2_retired.py` | T20 complete; **sign-off** | 1-1.5 | NEEDS-ANDRES |
| T27 | Health move, retire v1 | §3.13 steps 1 and 3 | `edge.py`, `observability.py`, `compute.py`, infra tests, `api/routers/health.py` | infra tests; staging health green before prod | T02 deployed; **sign-off** | 0.5-1 | NEEDS-AWS + NEEDS-ANDRES |
| T28 | Cleanup | §3.14: tracker drain, dead flags, two-issuer branch, READMEs, layout doc, CHANGELOG, control matrix | many | full suite; `grep` proofs per removal | all; legacy CLI deletion needs Andres | 2-4 | LOCAL-NOW mostly / NEEDS-ANDRES (CLI). **Local docs half done 2026-09-24:** tracker drained in place (every row an ID + CLOSED / DUPLICATE / OPEN with a stage; counts in its "Drain status"), READMEs (root "Running it", `scripts/`, `src/`, `tests/`, new `workers/`, `migrations/`, `lambda/`), `repo-layout.md` §1-§3 against the tree, control matrix §3 + new §4b, threat model §14, CHANGELOG (Phases 0-4 moved under Unreleased), five dead env names + `settings.NON_PRODUCTION_ENVS` removed (`tests/test_retired_env_names.py`). The post-parity schema revision is on `hold/post-parity-schema`. **Not done here:** the two-issuer branch and the dead CDK flags (T:122, after Phase 10), mypy over the legacy modules (T:42), the per-file ruff `S` baselines (the parallel cleanup wave), the legacy CLI deletion (T:106, Andres); the `auth-machine` placeholder already goes when `enableApiPlatform` is on (ADR 0037 decision 7). |
| T29 | Phase close | critic loop, Codex review, phase report, vault note | `docs/reports/phase-12-report.md`, `critic-log.md` | exit criteria §5 | all | 2-3 | LOCAL-NOW |

**LOCAL-NOW order:** T01 → T02 → T03 → T04 → T05 → T06 → T10 (parallel with T07) → T07 → T09 →
T08 → T11 → T12 → T14 → T13 → T15 → T16/T17 → T21 (synth only) → T22 (write only) → T20
(non-run families, only after cutover — before it, React must keep working against Render's v2).

---

## 5. Verification and exit criteria

**The plan's Verify line (plan:600), each mapped to evidence:**

| Verify item | Evidence |
|---|---|
| Every security test passes and each has a known-bad control that fails | `pytest tests/security -q` green; `pytest tests/security -q --known-bad` (fixture flips the overrides) all red; both outputs in the phase report |
| ZAP baseline: no HIGH | ZAP report from T23, filed with the evidence set |
| A client without `phi:read` gets masked fields | `test_phi_masked_without_scope.py` locally + T24 live |
| Another org's run → 404 | `test_object_level_authz.py` + T24 live with two orgs |
| Webhook to `169.254.169.254` refused | `test_webhook_ssrf_blocked.py` + T24 live (subscription refused, and delivery refused after a DNS change) |
| Replayed webhook rejected | `test_webhook_signature_replay.py` + the Python/TS verify helpers' own tests |
| Revoked client's token fails within one minute | T12 unit test (next request) + T24 live, timestamps in the report |
| Generated TS client type-checks against `web/` | `cd web && npm run typecheck` in CI |
| `docs/migration-tracker.md` empty | the file's Open items table has no rows |

**The prompt's loop (prompt:445-459):** features real (no dead admin buttons — each screen's
Playwright walk hits the real api and local Postgres); `pytest tests/` + `cd web && npm test` +
`cdk synth`/`diff` + conformance + security all green (LibreOffice in the CI image); Fable critic
and Codex review at zero unresolved critical/high (never sending PHI, secrets, `.env`); tidy check
(layout doc = `git ls-files`, ruff/mypy/tsc clean, resources tagged, no drift); control matrix
OWASP rows moved to "in place" with evidence paths; ADRs 0035-0043; runbooks; `CHANGELOG.md`; phase
report with the `needs-a-human` list; vault note under `NS_Proccess/`.

**Phase-12-specific extras:** `grep -rn "api/v1\|api/v2" web/ infra/ scripts/ api/ src/` returns
only history docs; `audit.api_request` has a row for every call in the T24 session; restore drill
repeated (quarterly cadence begins after Phase 12, plan §6).

---

## 6. Risks and open decisions (recommended defaults)

| # | Risk / decision | Default | Trigger to change |
|---|---|---|---|
| R1 | Rework if v3 runs are built before Phase 11 | Only Phase-11-independent work now (§4 order); T18-T19 wait | Phase 11 plan shows the run store/API contract unchanged — then T07's run reads can go further |
| R2 | LOCAL-NOW work competes with the cutover | Only while cutover waits on Andres; behind flags; not merged ahead of a cutover blocker | Andres unblocks Phase 9 — cutover work pre-empts |
| R3 | Cognito app clients created at runtime by the api, outside CDK | Yes: they are data like users; api role limited to `Create/Update/DeleteUserPoolClient` on the one pool ARN; CloudTrail records each; `api_clients` is the inventory | An auditor requires IaC-only clients → CDK-managed clients from a config table, redeploy per client |
| R4 | "Secret stored hashed" vs Cognito holding the secret | Fingerprint only; Cognito verifies; we never keep plaintext | — |
| R5 | Zero-downtime rotation depends on a Cognito feature not yet verified | Verify in T01; fallback: two app clients per row during overlap | Feature confirmed → simpler path. **Verified 2026-09-24: two secrets per app client (ADR 0037); fallback dropped.** |
| R6 | Rate limits wrong once `desiredCount > 1` (ADR 0010) | Postgres counters (`api_quota_window`) for v3; ElastiCache stays refused (cost) | Counter writes show up in RDS load (> ~5% CPU) → reconsider |
| R7 | Webhook sender in a Lambda vs a worker loop | VPC Lambda with its own SG/role (separation of "calls the internet" from "reads PHI") | Lambda packaging of psycopg2 fails on arm64 → second container in the worker task, own IAM via task role split |
| R8 | EventBridge adds a hop vs direct SQS | Keep EventBridge (plan; free; future consumers such as audit) | Latency or cost problem → direct SQS from the outbox publisher |
| R9 | Event lost or phantom | Outbox in the same transaction + sweep | — |
| R10 | Cursor tampering | Opaque, strictly parsed; the org predicate makes a forged cursor harmless | A cursor ever carries something sensitive → HMAC it |
| R11 | Publishing the OpenAPI document | Not served live; given at onboarding | A partner portal is wanted |
| R12 | Two upload paths (React multipart vs machine pre-signed) | One path: pre-signed POST for both (CSP `connect-src` + bucket CORS for the app origin on the upload prefix) | Browser direct-to-S3 breaks something measurable → keep multipart for React, tracker row |
| R13 | Tree-wide mypy by end of Phase 12 (~400 findings at baseline) | Keep the ratchet going per phase; whatever remains is a 2-4 day line in T28 | > 150 findings left entering Phase 12 → Andres decides extend-or-accept |
| R14 | Tracker "empty" (~140 rows today) | Every phase closes its own; T28 takes leftovers | Leftovers > 20 rows → re-estimate T28 |
| R15 | Cognito pricing (M2M) unverified here | Verify in T01 before any client exists | **Verified 2026-09-24: no per-client fee since 3 Nov 2025; $0.00225 per token (ADR 0037, cost estimate "Phase 12 — pending approval").** |
| R16 | Non-health `/api/v1` routes die with `web_app.py` in Phase 11 | Delete them there, with sign-off | Andres wants v1 alive → port to FastAPI in Phase 11 (+0.5 d) |
| R17 | Phase 11's queue message has a user-only actor | Ask Phase 11 to carry `actor.kind` (§3.9) | — |
| R18 | JSON log formatter still open (tracker line 52) | Phase 12 alarms depend on it; it must land by Phase 8 as tracked | Still missing at Phase 12 start → it becomes T00 (+1-1.5 d) |
| R19 | ZAP authenticated scan needs MFA'd user | Inject a bearer from a staging test user via ZAP's replacer; user deleted after | — |
| R20 | Human `phi:read` has no source today | `roles.can_read_phi`, default false, nobody granted | P-1/P-2 answer "yes" |

### Decisions only Andres can make

**Answered by Andres on 2026-09-22:**
- **Retire the 10 `/api/v1` Flask routes in Phase 11: yes.**
- **PHI-scoped partner: maybe.** Plan the mTLS surface (T25) in full, but build and deploy it only when a
  partner exists, since it adds monthly cost; that cost goes to Andres for approval at that point.
- **API-client approval: Andres approves, self-approval allowed for now** (two-person org). Trigger to
  revisit: a third workforce member or an auditor's request.
- **New tooling: yes to both** — `openapi-python-client` as a dev-only generator, and ZAP in CI.


1. **New dependencies:** (a) Python client generator — `openapi-python-client` (dev-only) or the
   no-dependency generator (default); (b) ZAP — the `zaproxy/action-baseline` GitHub Action or the
   ZAP Docker image in CI (third-party tooling; no runtime change). Nothing else in this plan adds a
   dependency (TS toolchain exists; SSRF/HMAC/TLS are stdlib).
2. **Retirement sign-off:** the 10 `/api/v1` Flask routes (in Phase 11), `/api/v1/health`, and
   `/api/v2` (each family as React moves, then the whole prefix).
3. **Cost approval:** §8's increase over the ≈ $239 approved total.
4. **Pen-test vendor, scope and date** — before any real partner reaches production (control
   matrix CC4.1; `needs-a-human` item 16).
5. **Partner BAAs:** does any PHI-scoped partner exist? No → T25 is not built. Yes → sign, record
   in `partner_baas`, and T25 (+3-5 days, +cost).
6. **Who approves API clients** — superadmin only (default), and whether self-approval is allowed
   in a two-person organization (default: allowed, reason required, flagged in the quarterly review).
7. **Deleting the legacy CLI** (`process_revenue.py`, `process_unposted.py`, `data/revenue.db`,
   `DatabaseSQLite`) — required to close tracker line 114.
8. **Sandbox audience:** outside parties, or our own scripts only (changes onboarding, not code).
9. **Which machine clients exist at all** in year one (each has a monthly price, §8).

---

## 7. Proposed ADRs (titles only)

**Numbering (T01, 2026-09-24).** The Phase 11 plan (§8) reserves **0027-0034** for its own ADRs, so
this phase's are written as **0035-0043**, in the same order as the table below (0027 → 0035,
0028 → 0036, … 0035 → 0043). The reservation is recorded in `docs/adr/README.md`; the table keeps
the original numbers in brackets so earlier references can be followed.

| ADR | Title | One line |
|---|---|---|
| 0035 (was 0027) | `/api/v3` surface and retirement of v1/v2 | v3 = re-homed v2 families + platform resources; family-by-family React move; health-check two-step. |
| 0036 (was 0028) | Scopes and the caller model | Humans derive scopes from Postgres permissions per request; machines get token ∩ row; one dependency enforces. |
| 0037 (was 0029) | Machine clients: lifecycle and secrets | Runtime Cognito app clients, superadmin approval, fingerprint not hash, `revoked_epoch`, rotation, 90-day disable. |
| 0038 (was 0030) | Webhooks | Outbox → EventBridge → SQS → VPC Lambda sender; pinned-IP SSRF guard; signature contract; tenant re-check per attempt. |
| 0039 (was 0031) | Shared rate limits in Postgres | Reopens ADR 0010 for multi-task: `api_quota_window` counters, still no Redis. |
| 0040 (was 0032) | API audit trail | `audit.api_request` append-only in Postgres; what is recorded, never PHI; retention via the audit export. |
| 0041 (was 0033) | Sandbox sessions and staging wipe | Wipe-before-sandbox, restore-refused-while-sandbox-active, mutual exclusion enforced by script. |
| 0042 (was 0034) | Partner mTLS ingress (only if triggered) | Activates ADR 0002's trigger: API Gateway custom domain, truststore, cert-subject binding. |
| 0043 (was 0035) | OpenAPI publication and generated clients | Checked-in v3 document from FastAPI, not served live; TS via existing tools; Python per decision 1. |

---

## 8. Effort and cost

### 8.1 Effort vs the plan's 28-44 days

| Group | Tasks | This plan | Plan's composition |
|---|---|---:|---:|
| Resource endpoints + scopes (+ skeleton, audit) | T02-T04, T06-T08 | 9.5-13 | 8-12 |
| Machine auth + admin screen | T05, T12, T13 | 6.5-8.5 | 5-8 |
| Webhooks | T10, T11, T19 | 5-6.5 | 4-6 |
| OpenAPI clients | T14 | 2-3 | 2-3 |
| Sandbox org | T22, T23 (sandbox half) | 2.5-3.5 | 3-5 |
| Security tests + dynamic scan | T15, T23 (ZAP half), T24 | 4.5-6.5 | 5-8 |
| Mobile readiness | T16 | 1-1.5 | 1-2 |
| Final cleanup (+ retirements) | T26-T28 | 3.5-6.5 | 1-2 |
| **Not priced in the plan** | T01 ADRs, T09 quotas (ADR 0010), T17 runbooks, T18 process endpoints¹, T20 React → v3, T21 CDK, T29 close loop | 14-20.5 | 0 |
| **Total** | | **~49-70** | **28-44** |
| Conditional | T25 mTLS | 3-5 | 3-5 |

¹ The plan folds process endpoints into "resource endpoints"; priced separately here because they
wait for Phase 11.

**Trim to ~42-55** without dropping a prompt requirement: re-home v2 models unchanged so T20 is
~2-3 days (already the default; the high end assumes model changes); build read resources first
and defer writes (T08) until a machine client needs them; skip the Python generator question by
taking option (b) only when a Python consumer exists. Confidence stays **LOW** (plan §7).

### 8.2 Cost impact (monthly, pre-tax; ×1.066 Texas tax as in the plan)

| Line | Estimate | Confidence | Note |
|---|---:|---|---|
| Cognito M2M: per active machine app client | ~$6 each | **LOW — verify in T01** | AWS pricing as I understand it: a monthly fee per M2M app client plus per token request. The **existing placeholder client** in `auth.py:636-663` may start this charge in each environment where the auth stack is deployed — T21 deletes it. |
| Cognito M2M: token requests (~$2.25 per 1,000) | ~$0-7 per client | LOW | 15-minute tokens cached → ≤ ~3,000/month for a client polling all day (~$6.75); a script run a few times a day ≈ $0.10. Token caching in both clients is the control. |
| EventBridge custom events | ~$0.00 | HIGH | $1 per million |
| SQS webhooks queue + DLQ | ~$0.00 | HIGH | free tier |
| Lambda webhook sender | ~$0.00 | HIGH | free tier; no NAT-hours change (NAT exists) |
| Secrets Manager, per webhook subscription | $0.40 each | HIGH | 1-3 subscriptions ≈ $0.40-1.20 |
| CloudWatch: ~5 alarms + ~4 metric filters that match | ~$0.50 + ~$1.20 | MEDIUM | |
| WAF: +1 rate rule (`/api/v3`) | $1.00 per running env | HIGH | staging only during sessions |
| RDS storage for audit/quota tables | ~$0 | MEDIUM | two users; revisit at one year |
| Staging sessions (sandbox, ZAP, E2E) | one-off ~$20-35 | MEDIUM | ~$4/day × 5-8 days |
| API Gateway + mTLS (only T25) | ~$1-3 + optional regional WAF ACL ~$8-10 | LOW | HTTP API requests, custom domain, ACM free |

**T01 pricing check (2026-09-24, public AWS documentation only — ADR 0037 has the sources).** The
first row above is **wrong**: AWS removed the per-M2M-app-client fee on 3 Nov 2025, and only
successful token requests are billed, at $0.00225 each (HIGH confidence). Multi-secret rotation
exists (two secrets per app client, `AddUserPoolClientSecret` / `DeleteUserPoolClientSecret`),
so R5's fallback is not needed. Re-priced, the steady state below falls to **≈ +$3.5-4 taxed
(≈ $239 → ≈ $243)** for a client that runs a few times a day, or **≈ +$10.6 taxed** if one client
holds a cached token around the clock. The re-priced lines are in
`docs/reports/phase-1-cost-estimate.md`, "Phase 12 — pending approval". The paragraph below is
kept as written for the record.

**Steady state after Phase 12 with one production machine client and 1-2 webhook subscriptions:
≈ +$9-12 pre-tax → ≈ +$10-13 taxed. ≈ $239 → ≈ $249-252**, i.e. at or just over the ~$250
ceiling, and **over it** if the unapproved Phase 6 ≈ $4 is also approved. Each further machine
client ≈ +$6-14; the partner mTLS surface ≈ +$2-13. **Every one of these is a rise above the
approved total and needs Andres's approval before it is created** (prompt stop rule 3). Levers if
needed: create machine clients only for real consumers, delete sandbox clients at session end, the
Compute Savings Plan after one measured month (≈ $13-20, cost estimate §3).

---

*Nothing in this plan was run against AWS, Supabase, or client data. Figures quoted from the repo
cite their file and line; pricing lines marked LOW were not re-verified in this session.*
