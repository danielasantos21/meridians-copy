# Phase 6 report — Observability (code complete; alarms unsubscribed until a human confirms the email)

**Date:** 2026-09-16 · **Branch:** `aws-migration` · **Plan:** `docs/aws-migration-plan.md` Phase 6 · **Critic:** round 1 FAIL (4 high), round 2 FAIL (2 high), **PASS at round 3** (`285d549`) with one medium (heartbeat metric choice) and two lows carried as tracker rows.

## What was built

- **`observability` stack per environment** (ADR 0024): 27 alarms in staging and 26 in production on ALB, ECS, RDS, CloudFront, WAF, the User Migration Lambda, backups, secret rotation, and the account-level GuardDuty, Security Hub and Config findings (production only, since findings are account-scoped); every alarm has both alarm and OK actions on the alerts topic, an argued missing-data policy, and a window that survives a rolling deploy (the api's deploy takes 3 to 6 minutes of zero hosts by design until Phase 11, so its host alarm waits 7 of 8 minutes).
- **Stop-schedule evidence** (ADR 0020 §7c closed): the dead-letter queue feeds an EventBridge Pipe into a per-environment event bus; unexpected error codes page, the expected "already stopped" refusal goes to a log group, and `staging_session.sh up` reads RDS `describe-events` for a real stop plus the log group for a refusal before it declares the schedule healthy.
- **Log metric filters and a dashboard** keyed on structured JSON fields with an `Environment` dimension. The application does not emit JSON logs yet, so these metrics are absent until the formatter lands (tracked with a Phase 8 deadline); a heartbeat alarm behind `-c structuredLogsLive=true` makes the blindness page once armed.
- **Synthetics canary** behind `-c enableCanary=true` (unapproved cost, ≈ $10/environment/month) with a scoped role and a per-environment artifacts bucket.
- **Topic and key policies** rewritten so CloudWatch and EventBridge can publish to the encrypted alerts topic: the guard is on the topic policy (source-account condition), not the KMS policy, which AWS does not support for EventBridge.
- **Log-group audit test**: every log group in every stack is on a CMK with 400-day retention, with a documented exception list.
- Runbook `docs/runbooks/alerts.md`; ADR 0024; control-matrix rows marked "in code, not deployed, no subscriber".

## Evidence

| Check | Result |
|---|---|
| Infra tests | 524 passed; synth clean for staging, production, and both context flags |
| CI | backend and web green at `285d549` |
| Alarm count | 27 staging / 26 production (28 / 27 with the canary) |

## Not yet run — needs staging

- Trip each alarm deliberately once and keep the SNS mail (plan verify list).
- One `phi` read producing exactly one audit pair and one pgaudit line with no identifier.
- Thresholds are reasoned, not measured; revisit after a month of production traffic.
- The `data` stack must be redeployed before any EventBridge-sourced alert can reach a mailbox.

## Accepted risk / deferred (tracker)

- Heartbeat alarm keys on the 5xx metric, so once armed a clean day pages at midnight (round-3 medium; switch to an all-requests filter with the formatter).
- Structured logging contract (`env`, `exception.type`, `artifact_download`) not emitted yet; export-volume alarm blind until then.
- Canary Lambda log group is outside the estate-wide encryption audit.

## Needs a human

- Confirm the SNS email subscription on both alerts topics (nothing pages anyone today).
- Approve Phase 6's ≈ $4/month over the approved total, and the canary's ≈ $10/environment if wanted.
- Redeploy `data` after cost approval so the topic policy takes effect.
