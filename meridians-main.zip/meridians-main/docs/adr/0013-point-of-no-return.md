# ADR 0013 — The point of no return is the first write on AWS

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §6, decision D-20

## Context

Cutover (Flip 2, Phase 9) moves production traffic, data and files to AWS in one window.
Before some moment, rolling back is a DNS change and nothing is lost. After it, rolling
back means finding every write that happened on AWS and re-applying it to Supabase by
hand.

Where that moment sits has to be defined **before** the window opens, not argued about
during it.

The tempting definition is "when the first journal entry is booked" — it sounds like the
moment that matters, and it buys a longer reversible period. But acting on it means
enumerating every writable table and every writable S3 prefix and proving none of them was
touched, in the middle of a cutover, under time pressure.

## Decision

**The point of no return is the first write of any kind on AWS.**

Consequently:

- **The Phase 9 smoke test is read-only**: sign in, `GET /me`, open a completed run,
  download an artifact, render an invoice PDF to a temp path (not stored), open config
  screens.
- **The runbook names the one deliberate write** — a `process_runs` heartbeat row — and
  states that it is re-applied by hand if we roll back.
- Before the point of no return, rollback is: DNS back to Render, ~5-10 minutes plus TTL,
  nothing lost. Render is left **running**, not suspended, and the Supabase project stays
  live and untouched.
- After it, rollback is: DNS back, then re-apply divergent writes from the runbook
  enumeration; for bookings, document the affected `import_batches.id` values and re-enter
  each. **Assume a day, and not during a close.**

This is point of no return #1 of three. #2 is `AUTH_BACKEND=cognito` in production
(Phase 4) — still reversible, because `auth.users` is never mutated and Cognito users are
copies. #3 is cancelling the Supabase project (Phase 10) — genuinely irreversible, and not
before two full close cycles on AWS.

## Alternatives considered

**Booking-based: "the point of no return is the first journal entry booked on AWS."** This
is genuinely attractive — it is the only write that reaches a customer's real books through
QBO, it is the write everyone actually fears, and it would extend the reversible window
across the whole smoke test and the first hours of live traffic. Under it the smoke test
could exercise write paths, which is a real loss under the strict definition.

It was rejected on operability, not principle. Acting on it means that, at the moment
someone asks "can we still roll back?", the answer requires enumerating every writable
table and every writable S3 prefix and proving none diverged — `process_runs`, `uploads`,
`import_batches`, `audit`, session rows, the artifacts bucket — under time pressure, at
night, by one person. A rollback criterion that has to be *computed* is a rollback criterion
that will be got wrong once.

**Reversal cost: effectively zero before the window, prohibitive inside it.** This is a
definition in a runbook, not an implementation: loosening it before cutover costs the
enumeration work (~1-2 days to list the writable surfaces and write the divergence queries)
plus a rehearsal that exercises them. Loosening it *during* a cutover is not a decision, it
is an argument, and is forbidden — the definition is fixed before the window opens.

**Concrete trigger to reverse:** a staging rehearsal in which the read-only smoke test
demonstrably fails to catch a defect that a write-path test would have caught. The default
response is a better read-only rehearsal; only a second such failure moves the line, and
only with the divergence queries written and tested beforehand.

## Consequences

- The rollback decision is binary and provable at any instant, with no enumeration needed
  under pressure.
- The reversible window is shorter than a booking-based definition would give. Accepted:
  a clean, trivially correct rollback beats a longer one that has to be reasoned about.
- The smoke test cannot exercise any write path. Write paths are proven in the two
  staging rehearsals instead — the second timed and following
  `docs/runbooks/cutover.md` literally, with no runbook edits.
- Cutover is never scheduled mid-close. Periods are 4-5 weeks; pick the widest gap, a
  low-activity day, with someone reachable by phone.

## Trigger to revisit

Nothing within this migration. The definition would only loosen if a rehearsal showed the
read-only smoke test cannot give enough confidence to flip DNS — in which case the answer
is a better rehearsal, not a later point of no return.
