# ADR 0044 — QuickBooks OAuth tokens: envelope encryption at the application layer

**Date:** 2026-09-24
**Status:** Accepted (built locally; not deployed). Asked for in the D18 note of
`docs/reports/local-first-plan-2026-09-24.md` ("QBO OAuth tokens sit in plaintext columns (disk
encryption only), so envelope-encrypt them with KMS/app key before cutover").
**Source:** `src/qbo_token_crypto.py`, `src/qbo_client.py`, Alembic `0023_qbo_token_envelope`,
`scripts/encrypt_qbo_tokens.py`, `infra/meridian/stacks/{data,compute,worker}.py`.

## Context

`public.qbo_connection` holds each organization's QuickBooks **access token** (an hour) and
**refresh token** (100 days, rotated on every use). Together they are a bearer credential to a
client's books: whoever holds the refresh token can post journal entries. Until now they sat in
two plaintext `text` columns. RDS encrypts its storage, but **storage encryption** only protects a
stolen disk: every snapshot restore, `pg_dump`, logical replica, support query and `SELECT *`
under the application role reads the tokens in the clear.

**Envelope encryption** means: encrypt the data with a fresh random **data key (DEK)**, then
encrypt ("wrap") that data key with a long-lived **key-encryption key (KEK)** that never leaves
KMS. The row stores the ciphertext and the wrapped DEK; reading it needs a KMS call that IAM,
CloudTrail and the key policy all see.

## Decision

1. **Sealed at the application layer, before the database.** `qbo_token_crypto.seal` makes a
   fresh 256-bit DEK per write, encrypts each token with **AES-256-GCM** (random 96-bit nonce),
   and binds each ciphertext with associated data `{purpose, org_id, realm_id, column}` — a
   ciphertext copied to another org, realm or column does not open. Layout:
   `0x01 || nonce(12) || ciphertext+tag`. The library is `cryptography` (already locked at
   50.0.1 in `requirements.lock.txt`, now also declared in `requirements.txt`; no new dependency).
2. **Two wrappers behind one port.**
   * `KmsKeyWrapper` (AWS): `GenerateDataKey` (`AES_256`) and `Decrypt`, both with the KMS
     **encryption context** `{purpose: "qbo-token", org_id, realm_id}`. Configured by
     `QBO_TOKEN_KMS_KEY_ARN`. Tested only through a botocore `Stubber` (exact requests).
   * `LocalKeyWrapper` (laptop): the DEK wrapped with AES-GCM under a 32-byte key from
     `MERIDIAN_DEV_QBO_TOKEN_KEY`. **Refused outside development** exactly like the other
     development fallbacks (`settings.dev_fallbacks_permitted()`): a deployed environment with it
     set raises rather than seals.
3. **Columns (revision 0023).** New `access_token_ct`, `refresh_token_ct`, `token_dek` (wrapped),
   `token_kek_id` (`kms:<arn>` or `local:<fingerprint>` — never a key). The plaintext columns
   become NULLable. `CHECK qbo_connection_token_form`: a row is **either** legacy plaintext **or**
   fully sealed, never both or neither. `CHECK qbo_connection_token_ct_shape`: a ciphertext
   starts with the format byte and is at least nonce+tag long. **Trigger
   `qbo_connection_no_new_plaintext`** refuses any INSERT with a plaintext token and any UPDATE
   that changes one — so a future writer that forgets to seal is stopped by the database.
4. **Dual read, write-new-only.** `QboClient._load_row` opens a sealed row and reads a legacy row
   as stored; `save_connection` and `_refresh` always write sealed (an upsert over a legacy row
   NULLs its plaintext). In memory `QboClient._row` keeps the plaintext shape, so nothing else in
   the QuickBooks code changes. **The Supabase path is unchanged** (no Alembic there).
5. **No backfill in the migration** — a migration must never hold a key.
   `scripts/encrypt_qbo_tokens.py --actor <superadmin> [--dry-run] [--rotate-data-keys]`
   re-saves plaintext rows through the application, per organization, through the audited
   `with_superadmin` scope (one `audit.superadmin_access` row per org, reason
   `qbo token encryption`), each org's rows locked `FOR UPDATE` so a concurrent refresh cannot be
   overwritten with a stale refresh token. Counts only on stdout. After cutover a later revision
   drops the plaintext columns (tracker row).
6. **Fail closed.** No key → nothing seals and no sealed row opens (`QboTokenKeyError`, a
   `QboError`). Wrong key, another key id, a tampered byte, a moved ciphertext → the same. A
   **disconnect never depends on the key**: the row is deleted, and a refresh token that does not
   open is simply not revoked at Intuit (it dies on its own within 100 days). Error messages are
   fixed sentences — never a token, key, ciphertext or KMS error text — and the log test has a
   known-bad control proving it would catch a leak.
7. **Rotation.** The DEK rotates on **every** write (connect, each hourly refresh) and on
   `--rotate-data-keys`. The KMS key rotates yearly (`enable_key_rotation`); KMS keeps old key
   material, so nothing is re-encrypted. Moving to a *different* CMK is not built: rows sealed
   under the old one fail closed and the org reconnects.
8. **Infrastructure (originally behind `-c worker_enabled=true`; see the 2026-10-12 amendment
   below).** A sixth CMK in
   the persistent `data` stack, `meridian-<env>-kms-tokens` (rotation on, `RETAIN`, the standard
   environment-scoped key policy). The api and worker task roles each get **one statement**:
   `kms:GenerateDataKey` + `kms:Decrypt` on that key only, conditioned on
   `kms:EncryptionContext:purpose = qbo-token` — not `kms:Encrypt`, which the code never calls.
   `QBO_TOKEN_KMS_KEY_ARN` goes into the api task's environment and the worker copies it. The
   `data` stack must be deployed with the flag before the first `compute` deploy with it
   (compute imports the key ARN).

**Amendment 2026-10-12 (T:186): the key and the api's half no longer depend on the worker.**
The api stores QuickBooks tokens on RDS whenever it runs on AWS, and the re-seal script must run
on staging and production before cutover — but the worker flag is a separate ≈ $15/month cost
approval nobody had passed, so the script refused (no key) on staging. Now `data` creates
`meridian-<env>-kms-tokens` in both environments, and `compute` always gives the api task role the
`SealQboTokensFromTheApi` statement and `QBO_TOKEN_KMS_KEY_ARN`. Only the worker's own
`SealQboTokens` statement stays behind `worker_enabled`. Deploy `data` before the first
`compute` deploy that carries it.

The QuickBooks OAuth client (M-10) is decoupled too, behind its own flag **`-c qboOAuth=true`**
(off by default; `worker_enabled` implies it). On, the api task gets `QBO_CLIENT_ID` /
`QBO_CLIENT_SECRET` from the hand-created `meridian-<env>/qbo-oauth` secret (execution-role read
on that one secret, by name, on the `logs` CMK), plus `QBO_ENVIRONMENT` and `QBO_REDIRECT_URI`.
Off by default because a task naming a missing secret does not start. **Operator:** create the
secret (`docs/runbooks/rotate-secrets.md` §6), then pass `-c qboOAuth=true` on **every**
production `compute` deploy from then on — Render's production connects QuickBooks today, and
without the flag the AWS api's "Connect QuickBooks" answers 503. Staging needs it only to
rehearse a sandbox connect.

## Alternatives considered

* **Postgres `pgcrypto` with a key in a session setting.** The key would travel to the database
  on every connection and could land in `pg_stat_activity` or a statement log; the database
  operator would hold both halves. Rejected.
* **Encrypt directly with KMS `Encrypt` per token.** Simpler, but a KMS call per token per
  refresh and a 4 KB limit; envelope encryption is the AWS-recommended shape and makes the DEK
  rotation free.
* **Reuse an existing CMK (`phi` or `artifacts`) with the purpose condition.** ≈ $0 instead of
  ≈ $1/month per environment. Rejected for separation: the tokens are credentials, not PHI or
  exports, and a key whose only direct (non-`ViaService`) user is this code keeps its CloudTrail
  trail readable. Trigger to revisit: KMS key count becomes a cost line that matters.
* **Keep the tokens in Secrets Manager, one secret per org+realm.** $0.40/secret/month and a
  secret write on every hourly refresh; the row would still need a pointer. Rejected on cost and
  write rate.
* **Backfill inside the migration.** Needs the key in the migration runner. Rejected (decision 5).

## Consequences

* **One AEAD in the application (amended 2026-09-25, critic Stage 1 L-1).** The AES-256-GCM
  layout lives in `src/aead.py` and is shared: this envelope and the parked sign-in challenge
  store (`src/api/v2/auth_routes.py`, which used to carry a hand-rolled HMAC-SHA256-CTR
  encrypt-then-MAC) both seal through it. A new at-rest seal uses it too.
* A snapshot, dump, replica or `SELECT *` of `qbo_connection` shows ciphertext only for every
  row written after the deploy, and for every row once the script has run.
* Every connect/refresh/load on AWS makes one KMS request: a few thousand a month, far below a
  cent. The key itself is ≈ $1/month per environment (both, since the 2026-10-12 amendment).
* Local development on RDS needs `MERIDIAN_DEV_QBO_TOKEN_KEY` (32 random bytes, url-safe base64)
  to connect QuickBooks; without it the connect fails closed with a message naming the variable.
* Tracker: run the script after the release with 0023 reaches each RDS environment; drop the
  plaintext columns after cutover (Phase 9+) in a new revision, once the script reports 0.
