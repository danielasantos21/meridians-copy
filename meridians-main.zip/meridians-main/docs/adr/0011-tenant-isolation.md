# ADR 0011 — Tenant isolation: explicit `org_id` predicate **and** row-level security

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §2.2, decision D-10

## Context

Meridian is multi-tenant: every tenant-scoped row carries an `org_id` and must never be
visible to another organization. About **50 tables** are tenant-scoped, and live Supabase
enforces isolation with **94 `CREATE POLICY` statements across 19 migration files** — which
the Supabase service key then bypasses, so in practice the policies protect much less than
they appear to.

Plan v2 proposed dropping row-level security on RDS and relying on a hand-written
`WHERE org_id = %s` on every statement, checked by a lint. That is discipline applied
**202** times (ADR 0005) by one developer. One forgotten predicate is a cross-tenant data
leak of PHI with nothing to catch it.

This is not hypothetical in this codebase: `web_app.py:2175, 2178, 2297, 2328, 2334, 2356`
and `src/api/v2/user_routes.py:411, 548, 637, 650, 664` write to `roles` /
`role_permissions` scoped only by `role_id`; the `roles.org_id` check existed **only** in
an RLS policy the service key bypassed. That is a live cross-org permission escalation,
fixed in Phase 0c.

## Decision

**Two layers. Neither is optional.**

**Layer (a) — the explicit predicate.** Every tenant-scoped statement carries
`org_id = %s` in its SQL text. `scripts/lint_org_scope.py` enforces it in CI, reading a
schema-generated `scripts/tenant_tables.txt` (~50 tables — plan v1's list of 6 was badly
short).

**Layer (b) — PostgreSQL row-level security.** `FORCE ROW LEVEL SECURITY` on every
tenant-scoped table **in `public` and in `phi`**, with policies
`USING (org_id = app.current_org_id()) WITH CHECK (org_id = app.current_org_id())`. The
application connects as **`meridian_app`**, which is **not** the table owner and has **no
`BYPASSRLS`** — so unlike Supabase's service key, it genuinely cannot step over the
policies. `phi.transaction_identity` is on the list for the same reason as every other
table, and for a sharper one: `phi_access` is the only role with any grant there, so
without a policy it read every organization's patient identifiers.

`organizations` and `superadmins` have no `org_id` and are not on that list. They get
RDS-era policies of their own in the same revision (`id = app.current_org_id()`,
`user_id = app.current_user_id()`), replacing the Supabase-era `auth.uid()` ones that
`meridian_app` could not satisfy at all — it could not read its own organization row. They
are `ENABLE`d but deliberately **not** `FORCE`d: creating an organization cannot be
authorised by an `app.org_id` naming an organization that does not exist yet, so INSERT
and DELETE have no policy, are denied to `meridian_app`, and stay with the owner and the
audited bypass.

**There are TWO session settings, not one.** `app.org_id` names the organization, and
**`app.user_id`** names the person. Both are set on connection checkout and both are
`RESET` unconditionally on return to the pool. `app.user_id` is not an optional extra:
the `auth.uid()` stub revision 0003 leaves behind reads it, and the RDS-era policy on
`superadmins` (`user_id = app.current_user_id()`) is the only way the application can see
its own superadmin row. A checkout that sets one and not the other leaves a session that
can read its tenant's rows but not the identity tables, which looks like a bug somewhere
else entirely.

Neither is read raw. Revision 0003 defines **`app.current_org_id()`** and
**`app.current_user_id()`**, both `STABLE`, both returning NULL unless the setting holds a
syntactically valid UUID, and every policy predicate is written against them. An unset
setting and a malformed one then behave the same way — no rows, no error — instead of the
malformed one raising `22P02` from inside a policy. Pool-side UUID validation still comes
in Phase 5a; this is the database-side half and does not depend on it.

**How the settings are applied matters.** The repository layer is autocommit by default,
and `SET LOCAL` only survives inside a transaction. So they are applied
**session-level on connection checkout** (`SET app.org_id = %s`, `SET app.user_id = %s`)
and **`RESET` unconditionally on return to the pool** — the same shape as `RESET ROLE` in
`src/phi.py`. A test checks out a connection after a scoped operation and asserts
`current_setting('app.org_id', true)` is empty.

**Superadmin and cross-org admin paths bypass through exactly one named function**, which
writes an audit row.

The policies live in Alembic revision **0004**. `tests/test_run_isolation.py` and
`tests/test_pnl_rls_live.py` are ported to the RDS fixture **in Phase 5a**, alongside
`src/phi.py` and the repository layer — what they assert about is the shape of that code,
so porting them earlier would mean writing them twice. Until then they cover Supabase, not
RDS, and the RDS-side proof is `tests/test_migrations.py` (tracked in
`docs/migration-tracker.md`).

### 2026-09-16 — the one audited function exists (revision 0010, Phase 5b)

"Superadmin and cross-org admin paths bypass through exactly one named function, which
writes an audit row" was a requirement with nothing behind it until this date. It is
`src/pg.with_superadmin(user_id, reason)`, and the shape it took is worth recording because
it is narrower than the sentence implies.

**It is not a bypass.** `meridian_app` is `NOBYPASSRLS` and owns no table, so there is no
connection it could be handed that sees more than one organization. `with_superadmin`
verifies the caller's own `superadmins` row under `with_user` and then iterates
`with_org(org_id, user_id)` once per organization — cross-organization reading spelled as
a loop of ordinary scoped reads, each with the predicate any member of that organization
gets. `src/phi.py`'s bypass really is a privilege change (`SET ROLE phi_access`); this one
is not, which is why a caller that forgets its `org_id = %s` reads one organization's rows
wrongly rather than every organization's rows at once.

**What the database had to gain.** Alembic revision `0010_superadmin_org_list` adds
`meridian_org_superadmin_select` on `public.organizations` —
`EXISTS (SELECT 1 FROM superadmins WHERE user_id = app.current_user_id())`. Without it a
superadmin who is a member of nothing matched neither the `id = app.current_org_id()`
policy this ADR describes nor revision 0009's membership policy, so the console listed
nothing. It is SELECT only and on `organizations` only: the tenant tables are untouched,
and `organizations` still has no INSERT or DELETE policy, so creating and destroying an
organization stays with the owner role and remains an open tracker row.

**The audit row.** `audit.superadmin_access` (user, organization, reason, timestamp,
database role), `audit.phi_access`'s sibling down to the grant: `meridian_app` has INSERT
and nothing else, so the audited party can append and can neither read back nor amend.
**One row per organization visited, written before the read**, not one per call — an
access review asks which organizations were reached, and one row per call cannot answer
that. A refusal writes no row at all and raises, and the HTTP layer answers 404, never
403.

**What moved onto it:** the four `web_app.py` reads this ADR's tracker row named
(`superadmin_orgs`, its per-organization member count, `_check_process_health`,
`_get_last_batch`), now one pass in `src/org_admin_store.superadmin_overview`.

**Every superadmin surface path is audited, including the WRITE** (amended 2026-09-16,
round-1 critic P5B-01). As first written, only the cross-organization list wrote rows. The
three surfaces that name ONE organization — `GET /superadmin/orgs/{id}`,
`GET /superadmin/orgs/{id}/batches` and `PUT /superadmin/orgs/{id}/modules` — went straight
to `with_org(that_org_id)` on the argument that a superadmin acting on a named organization
is an ordinary scoped checkout. That is true of the CONNECTION and beside the point for the
TRAIL: this table answers "which organizations did this superadmin reach into", and a
console where three of four surfaces (including the one that CHANGES a tenant's modules)
left no row answered it wrongly. A wrong answer is worse than no table.

All three now go through `src/org_admin_store.superadmin_reach(user_id, org_id, reason)`,
which enters `with_superadmin(user_id, reason).each_org([org_id])` — so the row is written
before the read or the write, with its own reason (`"org detail"`, `"org batches"`,
`"module toggle"`) — and then takes the same `with_org(org_id)` handle it always used. An id
that is not an organization the caller can see yields nothing, writes no row, and answers
the §8 404. A malformed body is refused BEFORE the reach, so a rejected write leaves no row
for an organization it never touched. The cost is one extra pooled checkout per named-org
request, held one statement long.

## Consequences

- Costs **+3-5 engineering days** over the v2 plan. That is the price of a backstop under
  202 hand-written predicates, and it is the right trade.
- A forgotten `WHERE org_id` returns no rows instead of another tenant's rows — a loud,
  safe failure.
- A leaked `app.org_id` (set but never reset) would let the next borrower of that
  connection read the wrong tenant. That is why the reset is unconditional and asserted by
  a test.
- Every connection checkout pays one extra round trip for `SET`.
- Some intentionally cross-org queries must go through the one audited bypass function, so
  they are visible rather than ambient.

## Trigger to revisit

RLS measurably harms query plans on the large tables (`transactions`,
`phi.source_transactions`), or connection pooling changes such that session-level settings
are no longer safe (for example introducing a transaction-mode pooler such as RDS Proxy or
PgBouncer).
