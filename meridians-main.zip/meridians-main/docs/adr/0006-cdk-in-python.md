# ADR 0006 — Infrastructure as code: AWS CDK written in Python

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §1, decisions D-07 and D-21

## Context

Infrastructure today is the Render dashboard plus a `render.yaml` that no longer matches
the live services. On AWS every resource has to be defined in code — clicking in the
console leaves no review trail, no diff, and nothing an auditor can read.

Three options: **Terraform** (what plan v2 assumed, and what someone else's unreadable
state in the same account already uses), **AWS CDK in TypeScript**, or **AWS CDK in
Python**. CDK is AWS's own tool: you write ordinary code that emits CloudFormation
templates.

The repo is Python on the backend with an existing venv, and TypeScript only in `web/`.

## Decision

**AWS CDK, written in Python. Nothing is clicked in the console.**

- One CDK app with stacks for foundation, network, data, auth, compute, api and
  observability; the environment (`staging` | `production`) is a stack parameter.
- No account id hard-coded anywhere (ADR 0001).
- A CDK **Aspect** applies the six mandatory tags to every resource, and CI fails on an
  untagged resource.
- `cdk diff` runs in CI as drift detection, alongside CloudTrail alerts on console
  `Create*` calls made by humans.
- `cdk bootstrap` creates its own state bucket. The other owner's pre-existing Terraform
  state bucket is never touched (ADR 0001).
- Load-bearing constraints are written into the CDK as comments — notably
  `desiredCount: 1`, `maximumPercent: 100`, `minimumHealthyPercent: 0` on the api service
  until Phase 11 (two api tasks mis-book journal entries silently), and
  `FLASK_ENV=production` in the task definition because `src/auth.py:224` keys the
  `Secure` cookie flag off it.

## Alternatives considered

**AWS CDK in TypeScript** is the serious alternative, and on its merits it is the better
CDK. Its type checking is stronger, every construct and most published examples are
TypeScript-first, and `web/` already carries a Node toolchain, so "we have no TypeScript
here" is not true. The reason it lost is narrow and practical: infrastructure would then be
the **only** thing a one-person backend team writes in a second language, and the venv that
already runs `pytest` and the migration scripts would not run `cdk`. Context-switching cost
beats construct ergonomics for a solo developer.

**Terraform** lost on a different axis. It is what plan v2 assumed and what the other owner
in this account already uses — which is itself the problem: a second, unreadable state file
in the same account, with no way to tell whose resource is whose from the state alone. CDK
bootstraps its own state and emits CloudFormation, which the console shows natively.

**Reversal cost: moderate but bounded, and it falls to near zero if done early.** CDK stacks
are CloudFormation either way, so a language switch is a rewrite of the *authoring* code, not
a teardown of the infrastructure: `cdk migrate`-style regeneration plus re-verifying that the
synthesized template is unchanged. At Phase 1-2 scope (foundation, network) that is 2-3 days.
After Phase 6, with data, auth, compute, api and observability stacks written, assume 1-2
weeks — and the switch must be proven by a `cdk diff` that reports **no changes**, because a
diff that touches RDS or KMS is a data risk, not a refactor.

**Concrete trigger to reverse:** a second engineer whose working language is TypeScript
joins, **or** a construct we need is TypeScript-only or materially broken in Python and the
workaround is significant raw CloudFormation. Deciding before Phase 2 ends is cheap;
deciding after Phase 6 is not, so this is re-examined once, explicitly, at the Phase 2 exit.

## Consequences

- One backend language and the existing venv; no second toolchain, no Node runtime needed
  for infrastructure.
- No Terraform state to manage, and no risk of colliding with the other owner's state.
- CDK's Python typing is weaker than its TypeScript typing, and some constructs are
  documented TypeScript-first. Accepted.
- Effort is comparable to Terraform for one environment; the second environment plus the
  tag Aspect add roughly 2-3 days.
- Because staging is destroyed and redeployed each session (ADR 0008), the CDK is
  re-proven from empty constantly — which is also the rehearsal for a future account
  split.

## Trigger to revisit

A CDK construct gap that forces significant raw CloudFormation, or a second engineer whose
working language is TypeScript.
