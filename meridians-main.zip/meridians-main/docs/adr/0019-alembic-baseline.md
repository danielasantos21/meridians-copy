# ADR 0019 — The Alembic baseline: a four-revision chain, a skip allowlist, and an `auth` shim

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §2.2, Phase 3 steps 1–5; ADR 0005, 0011, 0012

## Context

The migration plan asks for two things that turn out to conflict: *"import the
37 existing SQL migrations as the baseline — do not rewrite them"*, and *"the
result must be production's schema"*.

`supabase_migrations/` is a **description** of the live database, not its cause.
Most of the core tables were created ad hoc — originally by porting a SQLite
schema — and the migration file was written afterwards, from memory. Replaying
the 37 files verbatim produces something close to production and not equal to
it.

How far off was not known before this phase. The earlier inventory
(`docs/compliance/inventory-data-layer.md` §7) listed about a dozen suspected
drift items from reading files. A measured diff — revision 0001 replayed into a
scratch PostgreSQL, `pg_dump`ed, and compared against a `pg_dump --schema-only`
of live Supabase taken on 2026-09-15 — found **242 differing normalised
statements**, including two whole categories nobody had recorded: 21 money
columns that are `double precision` live and `numeric(15,2)` in the files, and
22 timestamp columns that are naive live and `timestamptz` in the files.

It also found that the replay **did not work at all**. Two statements fail on a
database built from empty. The aws-trial script that "proved" the replay
(`deploy/aws-trial/apply_migrations.py`) caught every exception, logged `WARN`
and carried on, so its success said nothing.

## Decision

**Four revisions, each with one job, in `migrations/` at the repo root.**

| Revision | Job |
|---|---|
| `0001_baseline_supabase` | Replays the 37 files **verbatim**, read from `supabase_migrations/migrations/` at runtime, in filename order. |
| `0002_reconcile_live_drift` | Closes the measured gap. After `0001 + 0002` the schema **equals** live Supabase. |
| `0003_rds_adaptations` | The first deliberate difference: strips Supabase, adds `phi` / `audit`, the roles and the grant matrix. |
| `0004_rls_app_org_id` | `FORCE ROW LEVEL SECURITY` and the `app.org_id` policies on all 62 tenant tables. |

Five choices inside that shape are worth recording, because each one is a place
where the obvious thing is wrong.

### 1. 0001 reads the SQL at runtime; it does not embed it

Copying 37 files of SQL into a Python revision creates a second source of truth
that drifts from the first the moment anyone touches either. The revision globs
the folder, asserts it still holds exactly 37 files, and executes each one's
text unchanged. `supabase_migrations/` stays the history; the revision is the
mechanism that replays it.

### 2. The skip allowlist is by file **and** by statement, and it is published

`migrations/baseline/SKIPPED.md` lists every skipped statement in full. Today
that is all of `003_storage_buckets.sql` (Supabase Storage), `011`'s 25-row
`INSERT` (tenant data whose `org_id` backfill moved to `seeds/` in Phase 0 —
without skipping it, `012`'s `SET NOT NULL` fails and the chain does not build),
and `014`'s eight statements on `clients` / `invoices` (which run before `015`
creates those tables; `015` re-creates the policies anyway, in the form live
actually has).

Four standing patterns — `CREATE EXTENSION`, grants and default privileges to
`anon` / `authenticated` / `service_role`, and anything touching `storage.*` —
match **nothing** in today's 37 files. They are kept so a future addition to a
folder that is supposed to be closed cannot smuggle a Supabase-only grant into
RDS unnoticed.

A file is executed byte-for-byte unless one of its own rules matches somewhere
in its text; only then is it split into statements and filtered. So 35 of the 37
files are genuinely verbatim, and the word means something.

### 3. The `auth` shim, and where it is narrowed

The files declare 14 `REFERENCES auth.users(id)` foreign keys and call
`auth.uid()` 22 times. 0001's preamble creates `auth.users(id uuid primary key)`
and a NULL-returning `auth.uid()` so those statements resolve.

0003 drops the **table** and the foreign keys. It keeps the `auth` **schema**
holding one stub `auth.uid()` that reads
`current_setting('app.user_id', true)`, because 20 live policies on
`organizations`, `org_members` and `superadmins` call it directly, and dropping
a function a policy depends on requires `CASCADE` — which would silently drop
those policies. "Drop the shim" is therefore narrowed to "drop the shim table",
deliberately.

`public.user_org_id()` keeps its **name** and loses its body: it now returns
`NULLIF(current_setting('app.org_id', true), '')::uuid`. 74 live policies call
it; renaming would mean rewriting all of them.

### 4. Column order is not compared; everything else about a column is

Live's ad-hoc tables put `org_id` last where the files declare it second.
Matching that byte-for-byte would mean dropping and rebuilding twenty tables to
move columns that behave identically. The comparison
(`scripts/diff_baseline_schema.py`) therefore explodes every `CREATE TABLE` into
one fact per column and sorts: names, types, defaults, nullability and
constraints must all match; position does not.

### 5. One helper function in every policy predicate, not a raw `current_setting`

The plan writes the predicate as
`org_id = current_setting('app.org_id', true)::uuid`. Taken literally that is a
**fail-open-shaped bug**: after a `RESET`, `current_setting(..., true)` is `''`,
and `''::uuid` raises `22P02 invalid input syntax` rather than matching nothing.
An error is not a safe default — the test that matters ("`app.org_id` unset,
`SELECT` returns zero rows") would blow up instead of passing, and an
application that swallows the error carries on.

`NULLIF(current_setting('app.org_id', true), '')::uuid` fixes the empty case and
only the empty case. `SET app.org_id = 'not-a-uuid'` — an unvalidated request
value reaching the pool — still raises 22P02 from inside every policy, and
pool-side UUID validation is Phase 5a work. So revision 0003 defines
**`app.current_org_id()`** (and `app.current_user_id()`): `STABLE`, returning
NULL unless the setting matches the UUID shape. Every predicate in 0004 is
written against it, `public.user_org_id()` and the `auth.uid()` stub delegate to
it, and a test sets four malformed values and asserts zero rows and no error.
One function is also one place to change when the pool starts validating.

### 6. `phi` is on the tenant list, and the list is schema-qualified

The first draft of 0004 read a list of bare `public` table names.
`phi.transaction_identity` carries an `org_id` and got no RLS at all, which
meant `phi_access` — the only role with any grant there — could read every
organization's patient identifiers. `scripts/tenant_tables.txt` is now
schema-qualified and generated from `public` **and** `phi`, and
`tests/test_migrations.py` checks both directions: everything on the list has
FORCE RLS and a policy, and every table at head with an `org_id` is either on
the list or in a documented `NOT_TENANT_SCOPED` set.

### 7. `organizations` and `superadmins`: ENABLE, not FORCE

Neither has an `org_id`, so neither is on the tenant list — but both carried
Supabase-era policies calling `auth.uid()`, which on RDS is a stub over
`app.user_id` resolving through `org_members`. `meridian_app` could not read its
own organization row or the superadmin list. 0004 replaces them with
`id = app.current_org_id()` and `user_id = app.current_user_id()`, `SELECT` (and
`UPDATE` for `organizations`) only.

They keep `ENABLE` **without** `FORCE`, unlike every tenant table, and that is
deliberate: creating an organization cannot be authorised by an `app.org_id`
naming an organization that does not exist yet. Under `FORCE` no principal at
all — including the migration role and the data load — could insert one.
`meridian_app` is not the owner, so it is still fully subject to the policies,
which is the property that matters; INSERT and DELETE have no policy and are
therefore denied to it outright, and go through the one audited bypass (ADR
0011).

### 8. The fixture migrates as a non-superuser, and that changed the load order

`tests/pg_fixture.py` creates `meridian_migrator` — `LOGIN CREATEDB CREATEROLE
NOSUPERUSER NOBYPASSRLS`, owner of the test database — and runs Alembic as it,
because that is the shape of the RDS master user. Migrating as a superuser hid
two things. First, `ALTER ROLE ... NOSUPERUSER` is refused to a CREATEROLE role
even when it changes nothing. Second, and much more important, **`FORCE ROW
LEVEL SECURITY` applies to the owner**, so at head PostgreSQL refuses
`COPY ... FROM` outright (`0A000`) and `pg_restore --data-only` cannot run at
all.

The data load therefore happens in the window between 0003 and 0004:
`upgrade 0003` → `pg_restore --data-only` + the PHI split → `upgrade head`. The
standing rule that follows is in `docs/runbooks/migrations.md`: a revision never
touches rows without a documented `SET app.org_id`.

## Consequences

- **The baseline is evidenced.** `migrations/baseline/` holds the live dump
  (`supabase_public_schema_2026-09-15.sql`, schema only, no owners, no
  privileges, no comments — scanned for UUIDs and names before committing), the
  242-statement drift it closed, and the 15-statement residue that remains.
- **Three objects differ from live on purpose** and nothing else may:
  `alembic_version` (ours), `trial_migrations` (the trial ledger, dropped at
  cutover) and `qgenda_workspaces` (**decision: not recreated** — no migration
  file, no established owner, rows excluded by P-4, and its three policies are
  granted `TO authenticated`, a role RDS does not have; it stays in the retained
  Supabase archive, so nothing is lost if it turns out to be Meridian's).
  `tests/test_migrations.py` asserts that set exactly, in both directions: an
  unexpected difference fails, and so does an allow-listed one that no longer
  exists.
- **0002 reproduces live's defects on purpose.** `employee_clinic_allocations`'s
  unique key is not org-scoped live, so two organizations cannot hold the same
  (employee, location) pair. Reproducing it is correct for a revision whose job
  is to equal production; *fixing* it is a later revision, flagged in 0002's
  docstring rather than smuggled in.
- **No downgrades for 0001–0003.** Undoing a baseline means dropping the schema.
  Staging is rebuilt from empty every session (D-15), which is a better
  guarantee than a downgrade path nobody exercises. 0004 *does* downgrade,
  because "turn RLS off to isolate a query plan" is a real operation.
- **Alembic pulls SQLAlchemy in transitively.** It is used by `migrations/env.py`
  to open one connection and by nothing else. There is no ORM (ADR 0005); every
  revision is hand-written SQL.
- **A `pg_dump` client ≥ 17.6 is required** to dump live. The one used was 18.3
  (Homebrew), which emits `\restrict` wrapper lines the comparison filters out.

## Trigger to revisit

The chain gains a revision that cannot be expressed as SQL (a data backfill that
needs application code — those belong in `scripts/`, invoked by a runbook step,
not in a revision); or `supabase_migrations/` is edited, which
`supabase_migrations/README.md` says is a bug and 0001's file-count assertion
turns into a failed migration.
