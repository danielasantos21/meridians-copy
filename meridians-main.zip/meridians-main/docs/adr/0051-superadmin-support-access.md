# ADR 0051 — Superadmin support access ("support mode"), the org switcher, and the two-person superadmin rule

**Date:** 2026-09-30
**Status:** Accepted (owner request, 2026-09-30: "the super admin should be more like to control
everything") and built in code. Branch `feat/superadmin-control`, Alembic revision
`0035_superadmin_control`. **Nothing is deployed.**
**Source:** Andres, 2026-09-30, and the approved plan for that request.
`src/support_access.py`, `src/org_selection.py`, `src/superadmin_admin.py`, `src/auth.py`
(`org_context`), `src/phi.py`, `src/api/v2/superadmin.py`, `api/routers/superadmin.py`,
`web/src/app/superadmin/`, `web/src/components/shell/support-banner.tsx`,
`scripts/add_superadmin.py`, `docs/runbooks/support-access.md`
**Related:** ADR 0011 (tenant isolation; "superadmin and cross-org paths bypass through exactly
one named function, which writes an audit row"), ADR 0012 (PHI quarantine), ADR 0021
(Cognito sessions, MFA `ON`), ADR 0022 (`with_org` / `with_user` / `with_superadmin`),
ADR 0037 (the two-person rule for API clients), revision 0010 (`audit.superadmin_access`),
revision 0033 (role preview)

## Context

Meridians staff (superadmins: rows in `public.superadmins`) could list organizations, toggle
modules, read an org's run history and approve API clients. They could not *do* anything inside
a customer organization: `src.auth.org_context` gave a superadmin full permissions only in the
organization they themselves belonged to, and `pg.with_org` refused anybody else. Helping a
customer meant asking them to share a screen, or quietly adding oneself as a member — a
membership nobody reviews and that never ends.

The owner wants superadmins able to go into any organization and act. That is the most
powerful capability in the product, so the decision is about how it stays visible.

## Decision

### 1. Support mode is a server-side session, not a membership

`POST /api/v2/superadmin/support-session {org_id, reason}` writes a row in
`public.support_sessions` (user, org, reason 10-500 characters, started, expires after **two
hours**, ended + how, PHI flag + PHI reason, plus a name/e-mail snapshot of the superadmin so the
org can read *who*). While an unexpired, unended row exists, `src.auth.org_context` answers
that user's requests with the target org's row in place of their membership row, role
`admin`, **and then runs its ordinary path**: the admin role's permissions masked by *that*
org's modules. There is no second permission implementation; the superadmin "every module"
widening is not applied in support mode, so the superadmin sees exactly what the org's admin
sees. Nothing travels in the browser: the server looks the row up by the signed-in user's id.

Who may start it: a **real** superadmin — the `superadmins` table, read per request — and not
while a role preview is running (a preview switches superadmin powers off; the gate answers
404). The session must have signed in with MFA: always true for Cognito (pool MFA is `ON`,
TOTP only, ADR 0021 — the ID token carries no per-session level, so Meridian records it as
`aal2`); a Supabase session needs `aal2` in its token. **The local-development auth bypass is
exempt** (it has no sign-in at all, and `_auth_disabled()` is False everywhere outside
`APP_ENV=development`).

`DELETE` ends it (any signed-in caller may end their own; Exit must always work, including
during a role preview inside the supported org, which ends with it). Expiry ends it the next
time the session is read (`end_reason='expired'`). Entering another org ends the previous
session (`replaced`). A role preview may be combined on top: it narrows, as everywhere.

### 2. Every support request is audited, and the org can see it

* **One `audit.superadmin_access` row per request** resolved in support mode (written in the
  same checkout as the session lookup, before the handler runs), with the session's reason
  and the new `support_session_id` column. One INSERT per request is cheap next to the
  request, and it answers "what did this superadmin reach for, and when" at request
  granularity rather than per session.
* **`audit.support_session`**: one append-only row per started / PHI granted / ended /
  expired / PHI refused, with the reason (and PHI reason) in the superadmin's own words.
* **Transparency:** `GET /api/v2/org/support-access` (admin only, org-scoped by RLS) is the
  org's "Meridians support access" log in Settings → Security: who, when, reason, PHI yes/no,
  duration. Another org's sessions are never listed.
* The console's named-org reads (`org detail` now with member names and e-mails, `org batches`,
  `org support log`, `support session start`, `org create`) each write their own
  `audit.superadmin_access` row through `with_superadmin(...).each_org([org])`.

### 3. PHI stays behind its own door

`src/phi.with_phi_access` — the only way into the `phi` schema — first asks
`support_access.refuses_phi(org, user)`: a user in support mode for that org without the
session's PHI grant is refused (`403 PERMISSION_DENIED`, `details.required:
support_phi_access`) before a connection is taken, and a `phi_refused` row is written. A
session started or upgraded (`POST …/support-session/phi`) with `phi_access` and its own
`phi_reason` passes, and every access is then audited by `audit.phi_access` as for anybody. The
grant cannot be taken back within the session (a trigger refuses it); end the session instead.

Consequence, accepted: in support mode without PHI, anything that writes or reads patient-level
data (uploading a revenue file, opening a PHI artifact) is refused. That is the point.

### 4. Superadmins are added and removed by two people

`public.superadmin_changes` holds requests; `app.decide_superadmin_change` (SECURITY DEFINER,
owned by the new NOLOGIN role `meridian_superadmin_keeper`) is the **only** writer of
`public.superadmins` reachable from the application, and it re-checks the rule in the database:
the caller is a superadmin, the request is pending and unexpired (7 days), the approver is not
the requester, and the last superadmin is never removed. `app.list_superadmins()` lists them for
a superadmin caller (a policy on `superadmins` that read `superadmins` would recurse).

`APP_ENV=development` allows self-approval (one person on a laptop), exactly as ADR 0037 does for
API clients. Elsewhere, with a single superadmin a request could never be approved, so the API
refuses it up front (`409 SECOND_APPROVER_REQUIRED`) and points at
`scripts/add_superadmin.py` — the audited bootstrap, run with the owner credential
(`audit.superadmin_change`, `bootstrap_added`/`bootstrap_removed`, with the reason and the
database login).

### 5. Creating an organization leaves no superadmin membership

`POST /api/v2/superadmin/orgs` reuses `src.auth.create_organization` (on RDS
`app.create_organization`, which makes the caller its admin and writes
`audit.organization_created`) and then **removes the creator's membership**. Meridians staff
reach a customer org through support mode, never through a membership; the org's first admin is
invited from inside support mode, through the ordinary invite flow.

### 6. People in several organizations can switch

`PUT /api/v2/me/org` stores the choice in `public.user_org_selection` (own-user RLS; the WITH
CHECK also requires a membership row in the chosen org). `get_user_org` only ever **reorders the
person's own membership rows**, so a stored choice that is not (or no longer) a membership
matches nothing and the earliest membership wins: validated on every request by construction.
`/me` carries `memberships` and the sidebar footer shows a picker when there are two or more.
RDS only; the Supabase backend (Render, frozen) keeps the earliest membership.

## Alternatives considered

* **Add the superadmin as a temporary member.** Rejected: a membership is invisible to the
  org's audit, survives the support need, and is exactly what `pg.with_org`'s membership check
  exists to make meaningful.
* **Impersonate a member** ("sign in as the customer's admin"). Rejected: the audit would name
  the wrong person, and it would need the customer's identity rather than the superadmin's.
* **A support header or cookie naming the org.** Rejected: forgeable, and authorization in
  this product is rows in Postgres read per request (ADR 0021), never something the browser says.
* **One audit row per session only.** Rejected for now: per request is cheap and answers more.
  Revisit if `audit.superadmin_access` volume becomes a cost (it is ids and a short reason).

## Consequences

* `audit.superadmin_access` gains a column (`support_session_id`, an id). Its "ids, a timestamp
  and a reason" rule still holds — the reason is now sometimes the superadmin's own words, which
  is what the org reads too.
* `scripts/lint_org_scope.py` gains a third identity predicate (`support_sessions.user_id`),
  backed by revision 0035's own-user policy, exactly like `org_members.user_id`.
* The superadmin console names people (member names and e-mails) for superadmins, on audited
  reads. ADR 0011's "the console is not a directory of every customer's staff" is superseded
  for the org detail page only; the cross-org list still shows organizations, not people.
* On the Supabase backend, support sessions live in the api process's memory (one worker; a
  restart ends support mode, the safe direction) and the audit fact is the `support_session`
  log event; superadmin changes there are made with the runbook script.
