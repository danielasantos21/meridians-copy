# ADR 0008 — Staging is torn down between phases

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §2.4, §5, decision D-15

## Context

The migration needs a staging environment that is a real copy of production — same CDK,
same shape — to rehearse the data load, the journal-entry diff, the Cognito flip and the
cutover itself.

A **standing** staging environment (always on) costs roughly what production costs.
Production steady state is about $225/month against an approximate **$250/month ceiling**.
A second always-on environment would blow that ceiling on its own.

But the work is intermittent: staging is used in bursts during a phase, then sits idle for
days or weeks.

## Decision

**Staging exists only while a staging session is running.**

- The **`data` stack persists** — buckets are kept, and the RDS instance is stopped on a
  schedule (EventBridge → `StopDBInstance`). RDS restarts itself after 7 days stopped, so
  the scheduled stop is part of the `data` stack, not a manual chore.
- The **`vpc` stack persists too**, and did not exist when this ADR was written. Phase 3
  split `meridian-<env>-network` into a persistent `vpc` stack (VPC, subnets, gateway
  endpoints, security groups — **all free**) and a transient `edge` stack (NAT, ALB,
  CloudFront, WAF, flow logs, ops instance — every hourly charge). The reason is this
  ADR's own rule: the `data` stack persists, an RDS instance needs subnets and a security
  group, and a CloudFormation stack cannot outlive the exports it consumes. **ADR 0020 §2**
  has the alternatives, including "just stop destroying `network`", which costs ~$37.50/mo
  per environment in idle NAT. The split changes no figure below: everything moved into
  `vpc` is free.
- The `edge`, `compute`, `api` and `observability` stacks are `cdk destroy`ed at the end
  of a session and `cdk deploy`ed at the start of the next — about **15 minutes**.
- Cost: about **$13/month idle**, about **$4/day** while a session runs.
- The **sandbox is a synthetic org inside staging**, not a third stack (D-18) — $0, and
  staging is already isolated from production.

## Consequences

- The ~$250/month ceiling holds with room for production.
- **Every staging session re-proves the CDK from empty.** That is a feature, not a chore:
  it is exactly the exercise a future account split (ADR 0001) needs, and it means the
  Alembic 0001→0004 chain is replayed from nothing every time rather than being `stamp`ed
  past (ADR 0005).
- ~15 minutes of setup at the start of each staging session.
- Anything left on a destroyed stack is gone, so nothing durable may live outside the
  `data` and `vpc` stacks. Session state belongs in the database or S3.
- Since Phase 3, **parts of the persistent half cannot be cleaned up on demand**: the
  backup vault is Vault Lock (compliance) and the `audit` bucket is Object Lock
  (compliance, seven years). Abandoning an environment now has a 35-day tail and a
  seven-year one. ADR 0020 §7.

## Trigger to revisit

The 15-minute redeploy becomes a real drag on phase throughput, or a persistent staging
URL is needed for someone outside the team. Either would mean re-checking the cost ceiling
first.
