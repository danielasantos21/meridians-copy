# ADR 0042 — Partner mTLS ingress (only when a PHI-scoped partner exists)

**Date:** 2026-09-24
**Status:** Proposed. Andres, 2026-09-22: a PHI-scoped partner is a **maybe** — plan the surface in
full, build and deploy it only when a partner exists, and bring its monthly cost to him for
approval at that point.
**Activates:** the trigger in ADR 0002 (ALB vs API Gateway), when it fires.
**Source:** `docs/reports/phase-12-plan.md` §3.6 step 4, T25, §8.2; ADR 0002;
`docs/compliance/baa-register.md` ("Future API partners")
**Numbering note:** planned as "0034" in the Phase 12 plan; renumbered (Phase 11 holds 0027-0034).

## Context

**mTLS (mutual TLS)** makes the *client* present a certificate as well as the server, so a stolen
token alone is useless. ADR 0002 decided the ALB serves the browser app and internal API, and an
API Gateway custom domain with mTLS arrives only when a PHI-scoped partner actually exists. The
`phi:read` scope is deliberately absent from the resource server until then
(`infra/meridian/stacks/auth.py:173-181`).

## Alternatives considered

**mTLS on the ALB now, for everyone.** The strongest case: one ingress, no second hostname, and the
control exists before anyone needs it. Rejected: it forces every machine client — including our
own scripts — to manage certificates for no PHI benefit, and it is built on a guess about a
partner nobody has signed. Reversing (moving to API Gateway later) costs a new stack either way.
Trigger: every machine client turns out to be a PHI partner.

**Never offer PHI over the API.** Simplest and safest; P-1/P-2 say nobody needs raw identifiers
today. Kept as the default state — this ADR only describes what happens if that changes.

## Decision (when triggered)

1. A regional API Gateway custom domain with an mTLS truststore; ACM certificate; optional
   regional WAF.
2. `phi:read` is added to the resource server, grantable only to an `api_clients` row with a
   recorded `partner_baas` row and an `mtls_subject` (a database CHECK).
3. The API accepts `X-Meridian-Client-Cert-Subject` **only** when the request also carries the
   API-Gateway origin-verify secret; a `phi:read` request without both answers 404 on every
   hostname, so the same token used through the ordinary ingress gets nothing.
4. `docs/runbooks/onboard-partner.md` covers the BAA, certificate exchange and first call.

## Consequences

- ≈ $1-3/month plus an optional regional WAF ACL ≈ $8-10 (plan §8.2, LOW confidence), and 3-5 days
  of work (T25) — both only once a partner exists.
- Until then, no PHI field is returned to any machine; masking (ADR 0036) returns `null`.

## Trigger to revisit

- A signed partner BAA → build T25, with its cost approved by Andres first.
- A second partner with different certificate authorities → one truststore per partner or a
  private CA.
