# ADR 0022 — The repository layer: a pooled psycopg2 session, scoped per request

**Date:** 2026-09-16
**Status:** Accepted
**Source:** migration plan v3.1 §2.2, §2.3, Phase 5a; ADR 0005 (psycopg2, no SQLAlchemy),
ADR 0011 (tenant isolation), ADR 0012 (PHI quarantine)

## Context

ADR 0005 decided *what* replaces `supabase-py`: raw SQL behind unchanged `Database`
method signatures, with `RealDictCursor`, `DEC2FLOAT`, autocommit by default and an
explicit `transaction()`. It did not decide *where that lives* or *how a connection
learns which organization it is serving* — and those two questions turn out to carry
most of the risk, because they are what makes 202 transcribed statements safe rather
than merely correct.

Three facts force the shape:

1. **Revision 0004 puts `FORCE ROW LEVEL SECURITY` on 62 tenant tables**, with the
   predicate `org_id = app.current_org_id()`, and `app.current_org_id()` reads
   `current_setting('app.org_id', true)`. Something has to set that value, exactly once
   per unit of work, and unset it afterwards. A connection returned to a pool still
   carrying the last request's organization is a cross-tenant read waiting for the next
   borrower who forgets a `WHERE`.
2. **`SET LOCAL` cannot be that something.** It lives only until the end of the current
   transaction, and this layer is autocommit by default, so every statement is its own
   transaction: a `SET LOCAL` would be gone before the next statement ran.
3. **Four places in the codebase swallow a database error and continue**
   (`src/process_runs.py:516`, `src/qb_export_artifacts.py:183`,
   `src/api/v2/user_routes.py:349`, `src/auth.py:788`). Under an implicit transaction the
   swallowed error leaves the connection in `InFailedSqlTransaction`, and the next
   statement — usually somewhere else on the same page — fails with "current transaction
   is aborted". A warning becomes a 500 in a place nobody was looking.

And one more, from ADR 0012: **`meridian_app` has zero grants on the `phi` schema.**
Every PHI touch is a `SET ROLE phi_access`, and a `SET ROLE` that is not undone travels
back into the pool with the connection.

## Alternatives considered

**A `Database` object that owns its own connection, opened per instance.** This is what
`DatabaseSupabase.connection()` does today: `psycopg2.connect(...)` per call, closed in a
`finally`. It is simpler, it has no pool to get wrong, and it would work. The case for it
is real: connection setup against RDS inside the VPC is a few milliseconds, and the api
task count is 1.

It was rejected on three grounds. A `db.t4g.micro` allows about 85 connections and a
`gunicorn --threads 8` process plus background threads can ask for more than that during a
close; per-call connections mean the `app.org_id` set-up round trip happens on every call
instead of once per request; and, decisively, there would be **no single place** that both
sets the scope and guarantees the `RESET` — which is the control ADR 0011 depends on.
Reversing this decision costs roughly a day: `with_org()` would keep its signature and
open a connection instead of borrowing one.

**Setting `app.org_id` inside each statement**, e.g. a `WITH` prefix or a
`set_config(..., true)` in the same round trip. This would remove the release problem
entirely — nothing persists, so nothing has to be reset. It was rejected because it makes
every statement in the codebase carry boilerplate that a transcription can omit, and an
omission fails *open*: the statement runs with no scope, and RLS then returns zero rows
rather than raising. Silent empty results are the hardest failure to notice.

**Granting the task role `phi_access` directly**, instead of `SET ROLE`. Rejected: the
grant matrix in revision 0003 makes `meridian_app` a `NOINHERIT` member of `phi_access`
precisely so that membership confers nothing until an explicit, auditable act. A second
connection pool as `phi_access` would be a second door, and the choke point would be a
convention rather than a boundary.

## Decision

**`src/pg.py` is the only way to the database, and `src/phi.py` is the only way to `phi`.**

- **A process-wide `psycopg2.pool.ThreadedConnectionPool`**, opened on first use from
  `POSTGRES_URL`/`DATABASE_URL` (or libpq's `PGHOST`/`PGUSER`/… , which is what the ECS
  task definition sets), sized by `PG_POOL_MIN`/`PG_POOL_MAX` (1/8). `Threaded`, not
  `Simple`: the api task runs eight gunicorn threads and the background workers are
  `threading.Thread` in the same process.
- **`sslmode=verify-full` is enforced outside development**, in `src/settings.postgres_dsn()`,
  along with the presence of a CA bundle (`PG_SSLROOTCERT`, baked into the image by
  `Dockerfile.api`). `require` is refused by name: it encrypts without authenticating the
  server, so it defends against nobody. On a laptop and under `pytest` nothing is
  enforced, because the ephemeral fixture speaks no TLS at all.
- **`with_org(org_id, user_id)` is the entry point.** It validates the ids as UUIDs
  *pool-side* (a malformed value would make `app.current_org_id()` return NULL and every
  predicate match nothing — an empty page and a 200), applies both settings with
  `set_config(..., false)` so they survive each autocommit statement, and on release
  issues `RESET ROLE; RESET app.org_id; RESET app.user_id` **unconditionally**, rolling
  back first if the connection is not idle and discarding it if it cannot be cleaned.
- **Autocommit by default**, with an explicit `transaction()` for the three genuine
  multi-statement units. Nested `transaction()` is a `SAVEPOINT`, so an inner failure does
  not discard the outer unit's work.
- **Six helpers:** `fetch_one`, `fetch_all`, `execute`, `execute_many`,
  `insert_returning` — the five the plan names — plus `copy_records`, because ADR 0012
  requires `COPY` rather than `execute_values` for anything carrying an identifier.
- **`DEC2FLOAT`, registered per connection**, so `numeric` arrives as `float` exactly as
  PostgREST's JSON did. Per connection and not globally: `DatabaseSupabase` is in the same
  process throughout the dual-maintenance window, and a global adapter would change the
  type of every `numeric` it reads too. **This adapter is a bridge and is scheduled for
  removal:** 21 money columns are `double precision` live and should be `numeric(15,2)`
  (`docs/migration-tracker.md`); when that migration lands, post-parity, the adapter comes
  out in the same commit and the arithmetic moves to `Decimal`.
- **`src/phi.py` is the choke point.** `with_phi_access(reason, org_id, user_id)` opens a
  scoped session, `SET ROLE phi_access`, yields, and in a `finally` writes one
  `audit.phi_access` row (who, which organization, what, which object, how many rows —
  never a value) and `RESET ROLE`. `token_for()` reproduces `scripts/split_phi.sql`'s
  `patient_ref` byte for byte, with `None` and `''` folding to one stable token.
- **`DatabasePostgres` exists as a skeleton**, selected by `DATABASE_BACKEND=postgres`,
  with every one of `DatabaseSupabase`'s 66 public methods raising `NotImplementedError`
  naming the sub-stage that owes it. The port works through `PORT_SUBSTAGES` in
  `src/database.py`, and `tests/test_database_postgres.py` compares that list against
  `DatabaseSupabase` in both directions.

**Dual maintenance starts the moment `DatabasePostgres` exists** (plan §7). From now until
Phase 10 both backends must be correct: the data-layer surface is frozen except to unblock
a close; every production bugfix lands in both backends in the same commit with a test
each; and the rollback is rehearsed monthly by flipping staging to
`DATABASE_BACKEND=supabase` and running one revenue run. The window is Phase 5a → Phase 9
and is budgeted at 8-13 engineering days of its own.

## Consequences

- **The `WHERE org_id = %s` predicate is still required on every tenant-scoped
  statement.** RLS is layer (b) and a backstop, never a substitute;
  `scripts/lint_org_scope.py` reads layer (a) and its count has to reach zero by the end
  of Phase 5a.
- **`copy_records` cannot copy straight into its target.** PostgreSQL refuses
  `COPY FROM` on a table with row-level security enabled for the caller
  (`FeatureNotSupported: COPY FROM not supported with row-level security`), and its hint —
  "use INSERT statements instead" — would put patient identifiers into statement text,
  which `pgaudit.log='ddl,role,write'` copies into a 400-day log group. So the values go
  into a temporary table (no RLS) by `COPY`, and across with one `INSERT … SELECT` whose
  text names only columns. Neither the plan nor ADR 0012 anticipated this.
- **A cross-tenant write that RLS cannot see exists, and `src/phi.py` guards it.**
  `phi.transaction_identity`'s policy tests the row's own `org_id` and its foreign key is
  `transaction_id REFERENCES public.transactions(id)` with no `org_id` in it, so one
  organization's transaction written under another's id satisfies both. The choke point
  checks that every transaction is visible under the current scope before it writes. The
  real fix is a composite foreign key onto `(id, org_id)`, which needs a unique constraint
  first — a migration, recorded in the tracker.
- **`meridian_app` cannot call `auth.uid()` directly** (no `USAGE` on the `auth` schema).
  The twenty inherited policies that call it still work, because a policy expression is
  evaluated with the table owner's access to the function. Nothing in the application
  calls it, so this is a property of the grant matrix rather than a defect — but a future
  diagnostic query that tries will get `permission denied for schema auth`.
- **`DEC2FLOAT` is technical debt with a named end.** See above.
- **An error swallowed by one of the four call sites stays local.** There is a test for
  exactly that shape (`tests/test_pg.py`).
- The pool is a process-wide singleton keyed on the DSN, so a rotated credential or a
  changed environment rebuilds it rather than being ignored for the life of the process.
- **A checkout WAITS for a connection; it does not fail instantly (2026-09-16, critic
  P5A-08).** `ThreadedConnectionPool.getconn` raises `PoolError("connection pool
  exhausted")` the moment `maxconn` connections are out — no queue, no timeout — and the
  api process admits up to **40** concurrent requests, because every Flask view under the
  WSGI mount runs in anyio's default worker thread pool, against a pool of **8**. So a
  burst that would have cleared in milliseconds produced 500s. `src/pg.py` now takes a
  permit from a `threading.BoundedSemaphore` sized to `PG_POOL_MAX` before asking
  psycopg2, waiting up to `PG_POOL_TIMEOUT` (default 5 s) and then raising **`PoolTimeout`**
  — a `PgError`, deliberately **not** a `psycopg2.Error`, because the four sites that
  swallow `psycopg2.Error` and carry on would otherwise render saturation as a page
  quietly missing a section. That permit is now the WHOLE of it: `Dockerfile.api`'s
  `--limit-concurrency`, written up here as "the other half", was dropped on 2026-09-16
  (critic P5AR2-08) because uvicorn counts it per connection and holds the count for the
  life of a keep-alive one — it refused idle browser tabs and did not see a burst arriving
  on connections it had already counted.
- **A connection returned to a REBUILT pool is closed, not leaked (2026-09-16, critic
  P5A-12).** The pool rebuilds itself when the DSN changes, and a connection that was
  already checked out then belongs to a pool that no longer exists — `putconn` refuses it
  with `PoolError`. That exception used to escape the `finally`, taking the borrower's own
  exception with it and leaving a live socket against RDS that nothing would ever close.
  It is caught and the connection is closed directly.
- **`with_user(user_id)` is the second, org-less scope (2026-09-16, critic P5A-10).**
  `app.user_id` set, `app.org_id` empty. It exists for the question every request has to
  answer *before* it knows an org id: who is this bearer, and is he a superadmin?
  `public.superadmins` carries revision 0004's `user_id = app.current_user_id()` policy,
  so it answers under this scope; all 62 tenant tables are filtered on
  `app.current_org_id()`, which is NULL here, so they read **zero rows** — not somebody
  else's rows. It is a different scope, not a wider one.

  **The superadmin path does not widen it.** Being a superadmin is a row in `superadmins`,
  read here; acting on another organization is still an ordinary `with_org(that_org_id)`
  entered deliberately afterwards, with the same RLS predicate as any member. There is no
  god-mode connection.

  **Known gap, and it is the obvious one.** `public.org_members` is listed in
  `scripts/tenant_tables.txt`, so revision 0004 gave it the org-scoped policy and dropped
  the inherited user-scoped one along with every other inherited policy on a tenant table.
  "Which organizations is this bearer a member of" therefore reads zero rows under
  `with_user` today, and the membership lookup stays on the audited owner-side path
  (ADR 0011) until a revision adds a `user_id = app.current_user_id()` SELECT policy to
  `org_members` beside the org-scoped one. `tests/test_pg.py` asserts the zero rows so the
  gap is recorded rather than discovered; `docs/migration-tracker.md` carries the row.
- **`src/database.py` should call `pg.with_user(user_id)`** for `get_user_org` and the
  superadmin check rather than `with_org` with an org it does not yet have — once the
  `org_members` policy above exists. Until then those two reads stay where they are.

### 2026-09-16 — decided while porting `DatabaseSupabase` to `DatabasePostgres`

Four questions the plan and this ADR did not answer, settled here because the port could
not proceed without an answer and the answers outlive it.

- **Rows leave the repository layer JSON-shaped, not psycopg2-shaped.** PostgREST answered
  with JSON, so a `timestamp` reached the application as the *string*
  `'2026-09-15T12:34:56'`, a `date` as `'2026-09-15'` and a `uuid` as a string. psycopg2
  returns `datetime`, `date` and `uuid.UUID`. `DatabasePostgres` converts them back
  (`_json_shape` in `src/database.py`), including `Decimal → float` as a second net under
  `DEC2FLOAT` for any value that arrives through a connection this layer did not register
  the adapter on. **The compatibility runs in this direction** because the alternative is
  editing every consumer: `src/auth.py:419` calls `.replace('Z', '+00:00')` on such a value
  — a `TypeError` against a `datetime` — and the templates, the v2 API responses and the
  JE exporters were all written against the strings. The conversion is one function in one
  place and it comes out when the consumers are ported, not before. It is asserted in
  `tests/test_database_pg_revenue.py` and `..._uploads.py`, where a `date` column is the
  only one in the surface.
- **`upsert` becomes `INSERT … ON CONFLICT (org_id, <key>) DO UPDATE SET <payload>`, with
  the payload written out twice rather than `EXCLUDED.*`.** PostgREST's `upsert` writes
  exactly the columns it was given; spelling them out says that, where `EXCLUDED.*` would
  silently acquire any column a later migration adds to the insert list. The conflict
  target is always `(org_id, …)` — never the bare key — and there is a test per config
  table that two organizations hold their own row under the same name.
- **A write states its own organization in SQL.** `INSERT INTO t (org_id, …) VALUES (…)`
  names `org_id` and restricts nothing, so it is not layer (a) and
  `scripts/lint_org_scope.py` is right to refuse it. Every insert in `DatabasePostgres` is
  therefore `WITH scope AS (SELECT %s::uuid AS org_id) INSERT … SELECT scope.org_id, …
  FROM scope WHERE scope.org_id = app.current_org_id()`, which writes nothing when the
  row's organization is not the session's. Under `with_org()` the two are always equal, so
  it never fires in practice — it is the statement *saying* which organization it writes,
  in a form a reader and a linter can both check. A zero-row insert raises `PgWriteRefused`
  rather than returning `None` into the caller's `['id']`.
- **`copy_records` keeps `''` and `None` apart.** It shipped with `NULL ''`, and
  `csv.writer` writes both an empty string and `None` as an empty unquoted field, so every
  empty string in a bulk write became SQL NULL — which `DatabaseSupabase`'s
  `execute_values` path did not do. The same period loaded through the two backends would
  have differed in exactly the columns a journal entry's description is built from, which
  is what the Phase 5a byte-diff gate compares. The NULL marker is now a token generated
  per call, so no value can collide with it (`tests/test_pg.py`).

One thing the port found that is **not** a decision but a missing migration:
`phi.transaction_identity.transaction_id REFERENCES public.transactions(id)` has no
`ON DELETE CASCADE`, and neither `meridian_app` nor `phi_access` holds `DELETE` anywhere in
`phi` (revision 0003 — the quarantine is append-only by grant). A batch whose transactions
have quarantined identifiers therefore cannot be deleted by the application at all.
`delete_batch` asks `phi.count_identities_for_batch` first and refuses with a sentence
rather than a foreign-key error naming a schema the caller may not read. Recorded in
`docs/migration-tracker.md`.

### 2026-09-16 — decided while porting `web_app.py` and `invoice_generator`

The `DatabaseSupabase` port answered how a *method* moves. This half of Phase 5a
is 47 statements that never lived in a method at all — they sat inline in Flask
routes — and four questions fell out of moving them.

- **A call site that already holds a `db` asks the OBJECT which backend it is,
  not the environment.** `use_postgres_database(org_id)` is the right question
  when a module is *creating* a handle; these modules are *handed* one. Asking
  the environment again would let a handle and a statement disagree — a
  `DatabaseSupabase` in hand and an RDS session opened beside it — and the
  symptom would be a page that read from one backend and wrote to the other.
  `src/backends.py` is the three lines that answer it: `sb` means PostgREST,
  `session()` means SQL, and anything else is a `TypeError` that names the type.
  `src/invoice_generator.py` is the exception that proves the rule: it takes an
  `org_id` and no handle, so it asks the environment, exactly as
  `get_database()` does.
- **An inline statement becomes a store module, not a `DatabasePostgres`
  method.** `src/database.py` is frozen for the dual-maintenance window (plan
  §7) and its surface is checked in both directions by
  `tests/test_database_postgres.py`; growing it per Flask route would make that
  contract a moving target for the four builders working against it. So the
  ported sites live in `src/uniform_store.py`,
  `src/qb_usa_payroll_store.py` and `src/org_admin_store.py` — one module per
  screen-family, each with both backends side by side, each with its own
  `org_id` predicate. Where a site DUPLICATED an existing method it calls the
  method instead: the QB USA payroll run's two end-of-run `import_batches`
  updates are now `update_batch_overview` / `update_batch_output_folder` /
  `update_batch_status`, which is three fewer statements to keep correct twice.
- **A join-scoped table carries its join in the statement, as a JOIN.**
  `role_permissions` has no `org_id` and the admin routes keyed it on `role_id`
  alone, with the organization checked only by an RLS policy the service key
  bypasses. The PostgreSQL half is now an inner join to `roles` with
  `r.org_id = %s` — which is both the honest statement of the rule and the form
  `scripts/lint_org_scope.py` can read. The PostgREST half cannot express the
  subquery, so it resolves the caller's role ids first and filters on them: one
  extra round trip, and two lint findings that are irreducible rather than
  unfixed.
- **A cross-organization read is not portable, and saying so is the deliverable.**
  Four `web_app.py` sites ask a question with no organization in it: list every
  organization, the most recent run of a process anywhere, and a health probe
  that reads one `organizations` row without saying which. Under `with_org` they
  read one organization and under `with_user` they read none, and ADR 0011 says
  the bypass is exactly one audited function — which does not exist. They stay
  on the Supabase service key with a comment at each site naming the tracker
  row. **A superadmin acting on a NAMED organization is not one of these**: that
  is an ordinary `with_org(that_org_id)`, and `/superadmin/org/<id>` is ported.

Two things the port found in the Supabase path, both silent, both now fixed on
both backends with a test each:

- **`db.client` has never existed.** Every frozen Wearbly read used it;
  `DatabaseSupabase` calls the client `db.sb`. The attribute came from the
  Wearbly test fakes, which had one because the production code asked for it, so
  the tests passed while every read raised `AttributeError` into a broad `except`
  and the process ran on its regex fallbacks. `src/uniform_store.py` accepts
  either name.
- **Two Wearbly column names do not exist either** —
  `uniform_column_mappings.source_header` and `uniform_size_mappings.
  input_pattern` are what the live schema has; the code said `file_header` and
  `raw_size`. The matching Wearbly WRITES are still broken and are deliberately
  left alone: repairing a frozen product's write path is a change to that
  product, not to this migration (tracker).

And one thing about the chain itself: **`0004` reads a LIVE file.**
`scripts/tenant_tables.txt` lists every org-scoped table at HEAD, so adding one
in a later revision made 0004 `ALTER` a table that does not exist when it runs,
and the chain broke itself from empty in a file nobody had edited. 0004 now
skips a name it cannot see; the revision that creates the table carries its own
`FORCE ROW LEVEL SECURITY` and policy, which is where that statement belongs.
### 2026-09-16 — decided while porting the fourteen small modules

The plan budgets "~40 sites across 12 modules" for everything outside
`src/database.py`, `src/auth.py`, `src/api/v2/` and `web_app.py`. There turned
out to be fourteen modules and 41 sites, and four questions the ADR had not
answered.

- **`src/db_backend.py` is the seam, and it asks about the OBJECT, not the
  environment.** Every one of these modules is handed a `db` that
  `get_database()` already chose. A module that re-read `DATABASE_BACKEND` for
  itself could disagree with the object in its hand — a `DatabaseSupabase`
  reached through a Postgres code path is an `AttributeError` at best and a
  write against the wrong database at worst. So `postgres_session(db)` returns a
  scoped session when `db` is a `DatabasePostgres` and `None` otherwise, and
  `None` means "take the path you have always taken". `src/process_runs.py` is
  the one module with no `db` to inspect — it is handed an org id — and it
  mirrors its existing `_supabase_configured()` with a `_postgres_configured()`
  built on `settings.use_postgres_database()`, which is the function
  `get_database()` itself calls. There is still one switch.

- **A statement whose table name is a variable is written out once per table.**
  Six of these modules take a `table` argument validated against an allow-list
  (`pnl_config_store.BATCH_TABLES`, `qb_mappings`'s three mapping tables,
  `qb_usa_payroll_roster`'s four). An f-string would be *safe* — the value is
  checked before it reaches a query — but it would not be *checkable*:
  `scripts/lint_org_scope.py` renders every substituted expression as `{}`, so
  an f-string statement is reported UNVERIFIABLE, which is the lint refusing to
  answer a question it cannot answer. So each is a dict of whole literal
  statements keyed by table. The same rule bites smaller elsewhere:
  `process_runs.find` writes `WHERE org_id = %s` into the literal and appends
  its optional predicates after it, and `qb_export_artifacts`'s upsert spells
  its ten columns out rather than joining them from a tuple, because the lint
  reads a `+` chain as several unrelated strings and the table name and the
  predicate would land in different ones.

- **`PgWriteRefused` is not a `PgError`, and the swallow sites need both.**
  ADR 0022 gave `PoolTimeout` a base class deliberately not derived from
  `psycopg2.Error` so that the four swallow-and-continue sites could not render
  saturation as a page quietly missing a section. `PgWriteRefused` — a scoped
  insert that wrote no row — wants exactly the same treatment for the same
  reason, and it is a plain `RuntimeError` defined in `src/database.py`. Rather
  than reach into another builder's file mid-phase, `db_backend.is_repository_refusal(exc)`
  matches both by `isinstance` and every swallow site asks it. **When the two
  share a base class every one of those sites collapses to one `except`
  clause**; the row is in `docs/migration-tracker.md`.

- **The `source` label says where the rows came from.** `load_payroll_maps`,
  `load_roster_tables` and `_load_overrides_supabase` each return a `source`
  field that the screen renders, and all three hard-coded `"supabase"` because
  that was the only possible answer when they were written. On RDS the honest
  answer is `"postgres"`. The field is a free `str` in `src/api/v2/schemas.py`,
  so saying so costs nothing, and a label that reads "supabase" while the rows
  came from RDS is the kind of small untruth that makes a cutover impossible to
  audit afterwards.

**Four unscoped reads found and closed, in both backends.** Not decisions, but
they belong next to them because the pattern is one mistake made five times.
`pnl_facts._provider_dates`, `qb_mappings._rows`, `qb_usa_payroll_roster._rows`,
`qb_usa_payroll_maps._load_overrides_supabase` and
`adp_booking_v5_processor.load_bkv5_location_remap` all took `org_id=None` and,
given one, **applied no filter at all**. The server holds a Supabase service
key, which bypasses row-level security, so that shape read every tenant's rows:
a journal entry coded from another organization's accounts, a roster built from
another organization's employees, a provider badged from another organization's
start dates. Nothing in the repository passes None today, so all five were
latent — but a control that holds only because no caller has exercised the hole
is not a control, which is layer (a)'s whole argument. All five now fall back to
the organization the `db` already belongs to and refuse when there is none; each
refusal lands in the function's existing `except`, which is what the
fallback-to-checked-in-defaults behaviour is for.

**The process_runs constraint is revision `0008_process_runs_unique`, not 0007.** It was
written as 0007 on a branch that did not yet have `0007_invoice_numbers`, and two revisions
sharing a `down_revision` is two Alembic heads and a chain that no longer replays from
empty. Renumbered on merge: `down_revision = "0007_invoice_numbers"`, `alembic heads` shows
one head, and `tests/test_migrations.py::HEAD_REVISION` names it. The rule this leaves
behind is the ordinary one — a revision's number is decided when it lands, not when it is
written.

**And one that was not latent.** `wearbly_processor.normalize_size` filtered
`uniform_size_mappings` on `raw_size`, a column that table has never had — it is
`input_pattern`, in the live dump and in the seed. PostgREST answered 42703
every time and a bare `except: pass` turned it into a silent fall through to the
regex, so no configured size mapping has ever applied. Fixed in both paths; the
`pass` now logs, because a swallow with no trace is what let a schema error live
for the life of the feature.
### 2026-09-16 — the identity scope, closed (revision 0009, the v2 API + `src/auth.py` port)

The KNOWN GAP recorded above — `with_user` reading zero rows from `public.org_members` —
is closed by Alembic revision `0009_org_members_user_policy`, and the reasoning is worth
keeping because the same question comes back for every table that belongs to a person
rather than to a tenant.

- **`meridian_member_self_select` on `public.org_members`** — `user_id =
  app.current_user_id()`, SELECT only, `TO meridian_app`, beside the org-scoped policy
  rather than instead of it. Permissive policies are OR-ed, so it can only make more rows
  visible, and the rows it makes visible are the session's own membership rows. It does
  not widen an org scope: all 62 tenant tables are still filtered on
  `app.current_org_id()`, which is NULL under `with_user`, and acting on an organization
  is still a deliberate `with_org()`. `src/auth.get_user_org` reads it; the assertion in
  `tests/test_pg.py` flipped from "cannot yet" to "does", as its docstring promised.
- **`meridian_org_member_select` on `public.organizations`** — the other half. 0004's only
  SELECT policy there is `id = app.current_org_id()`, which under `with_user` is NULL, so
  the org picker could read the ids and not the names. The new policy is an `EXISTS`
  through `org_members`, which carries RLS of its own — the same arrangement 0006 uses for
  the `superadmins` sub-select, and for the same reason: the only membership rows the
  sub-select can see are the session's, and those are exactly the ones that answer.
- **`meridian_invite_by_code_select` on `public.invite_codes`, and it is a new shape.**
  Redeeming an invite is the one authenticated operation with genuinely no organization:
  which org the code joins you to is the answer, not the question. The session states the
  code it is holding (`SET app.invite_code`) and the policy reveals the row that matches
  it — `code = nullif(current_setting('app.invite_code', true), '')`, which is NULL and
  therefore false when nothing is set. It is SELECT-only: joining the org and burning the
  code are writes, and both happen afterwards under an ordinary `with_org(invite.org_id)`.
  The setting is reset in a `finally` by `src/auth._validate_invite_code_pg`;
  `_release_scope` does not know about it yet and the tracker asks for that second net.

**What `src/auth.py` looks like now.** `get_user_org`, `is_superadmin`, `org_context`, the
invite lookup and redemption, the member list and the four `user_profiles` reads and writes
have twins over `src/pg.py`, chosen by `DATABASE_BACKEND`. Identity reads take
`with_user`, org-scoped reads take `with_org`, and every statement writes its own
predicate (`org_id = %s`, `user_id = %s`, `code = %s`) with the policy as the layer
underneath. **The service key is now the Supabase branch and only the Supabase branch**,
which is what the tracker row about `user_profiles` was waiting for.

Three things that did not port, each for a reason rather than for lack of time, and each
with a tracker row: creating an organization (no INSERT policy on `organizations`, by
design — it is the audited bypass's job); the members screen's view of *other* people's
display names (`user_profiles` is keyed on the reader, so an ordinary admin sees only
their own — a policy decision, not a transcription); and `settings_manager`'s
`AppSettings`, which belongs to the `src/app_settings.py` item.

**`load_user_permissions` kept its two arguments.** `role_permissions` has no `org_id` —
0004's policy joins through `roles` — so its Postgres twin needs a scoped session, and the
obvious third argument was not available: a dozen tests replace that function with a
two-argument lambda. The org travels beside the call in a `ContextVar` (`_org_scope`),
set by `org_context` and by `require_permission`'s defensive branch. A `ContextVar` and
not a module global, because the api process answers requests on several threads.

**The fourth swallow-and-continue site is fixed, and so is the third.**
`src/auth._fetch_permissions` and `src/api/v2/user_routes._store_invite_email` now re-raise
`pg.PgError` and swallow only `psycopg2.Error`. `PoolTimeout` is a `PgError` precisely so
that saturation cannot arrive wearing the class those handlers catch — a permission matrix
that renders empty during a load spike is a screen that lies, and an invite whose address
was silently not recorded because the pool was full is a support ticket nobody can
reconstruct. Autocommit is what makes the swallow safe in the first place; both are tested.

**`scripts/lint_org_scope.py` learned what "scoped" means for an identity table.** Two
raw statements in the codebase cannot name an organization because the organization is
what they are asking for. Each now has a revision-0009 policy written against the same
column it filters on, so `IDENTITY_PREDICATES` (`org_members` → `user_id`, `invite_codes`
→ `code`) makes those predicates layer (a) for those two tables, in raw SQL only — a
PostgREST chain runs as the service key where no policy is evaluated at all, and is still
reported. The violation count is unchanged by that change (101 on the merged tree, 58 of
them UNVERIFIABLE), which is the point: it is a definition, not an exemption list.

### 2026-09-16 — the third scope, and the last one (revision 0010, Phase 5b `/superadmin`)

`with_org` and `with_user` were described above as "the other, and there is no third".
There is now a third, and the sentence still holds in the way that matters: **it opens no
connection of its own.**

`pg.with_superadmin(user_id, reason)` verifies the caller's own `superadmins` row under
`with_user` — revision 0004's `meridian_superadmin_self_select`, the session's row and
nobody else's — and then hands back a `SuperadminScope` whose only power is to iterate
`with_org(org_id, user_id)` once per organization. Cross-organization reading is therefore
spelled as *a loop of ordinary scoped reads*, each with the same RLS predicate a member of
that organization gets. Compare `src/phi.py`, where the bypass genuinely is a role change
(`SET ROLE phi_access`): this one has no role change at all, so a caller that forgets its
`org_id = %s` reads ONE organization's rows wrongly instead of every organization's rows
at once.

- **Revision 0010 was necessary and was verified, not assumed.** A superadmin need not be
  a member of anything, and a member-less one matched neither 0004's
  `id = app.current_org_id()` (NULL under `with_user`) nor 0009's membership `EXISTS`. So
  `SELECT * FROM organizations` returned zero rows and the console was blank.
  `meridian_org_superadmin_select` is the fourth permissive SELECT policy on that table:
  `EXISTS (SELECT 1 FROM superadmins WHERE user_id = app.current_user_id())`. Policies are
  OR-ed, so it can only add rows, and `test_an_ordinary_member_gains_nothing_from_the_superadmin_policy`
  is the control that says so.
- **Listing organizations is not reading them.** The new policy is on `organizations`
  alone. The 62 tenant tables are still filtered on `app.current_org_id()`, which is empty
  under `with_user`, and `test_the_0010_policy_does_not_open_a_single_tenant_row` asserts
  it. Nothing about this revision makes any organization's data reachable without
  `with_org`.
- **`audit.superadmin_access` is `audit.phi_access`'s sibling, down to the grant.**
  `meridian_app` has INSERT and nothing else — no SELECT, no UPDATE, no DELETE — so the
  audited party can append to the trail and can neither read it back nor amend it. It
  holds `(user_id, org_id, reason, at, db_user)` and deliberately no free-text or JSON
  column; a test asserts the column list precisely so that adding a `details jsonb` to it
  has to be argued for rather than typed.
- **One row per organization VISITED, written BEFORE the caller's statement.** Not one row
  per call: "which organizations did this superadmin actually read?" is the question an
  access review asks, and one row per call cannot answer it. Writing it first is the same
  ordering `src/phi.py` uses for its "opened" row — the trail records what was reached
  for, not only what came back.
- **A refusal writes nothing.** `NotASuperadmin` is raised rather than an empty list
  returned, because an empty list is indistinguishable from "there are no organizations",
  which a caller could render as a page instead of a refusal; the HTTP layer turns it into
  404, never 403, exactly as `src/auth.require_superadmin` does. And the audit table stays
  silent on it, or it would stop answering the question it exists for.
- **`reason` is a fixed vocabulary word, not a free-text field.** It is written to the
  audit row, and a blank one is refused — an audit row that does not say why is not an
  audit row. It must never carry a name, an address or anything read out of the data.

**What moved onto it.** All four sites `docs/migration-tracker.md` listed —
`superadmin_orgs`, the per-organization member count inside its loop,
`_check_process_health` and `_get_last_batch` — are now one function,
`src/org_admin_store.superadmin_overview`, because they were always one question asked
four times. It is the one function in that module that takes no `db` handle, and that is
`src/backends.py`'s rule rather than an exception to it: the object decides *when there is
one*, and a handle is built for a single organization while this question is about all of
them. The Supabase branch is unchanged and stays the service key until Phase 10 — a second
audit trail for a bypass with no enforcement behind it would be a record of nothing.

**What did NOT move onto it, still.** Creating an organization. `organizations` has no
INSERT policy by design, and `with_superadmin` adds none: it reads. That tracker row is
open and wants an owner-side path, which is a different piece of work.

## Trigger to revisit

**Reopen the pooling decision** if a parity diff shows connection exhaustion or if the api
task count ever exceeds one before Phase 11 — at which point `with_org()` keeps its
signature and the pool is replaced by per-call connections, about a day's work.

**Reopen ADR 0005's "no SQLAlchemy"** — and with it this ADR's shape — if a parity diff
catches a mis-scoped transcription that the lint and RLS both missed. That is the one
condition under which the repository boundary becomes SQLAlchemy Core; every `Database`
signature is fixed precisely so that it stays cheap.

**Remove `DEC2FLOAT`** when the 21 money columns become `numeric(15,2)`, after the Phase 3
parity suite is clean. Not before: changing the type would change the numbers the parity
suite compares.
