# ADR 0028 — Generic worker: one `run_job`, two transports

**Date:** 2026-09-24
**Status:** Accepted (built: tasks D1, D3, D4; switched on per process at cutover, plan §5.1)
**Source:** `docs/reports/phase-11-plan.md` §3.3, §5.1-§5.2, tasks D1-D4; `workers/run_job.py`,
`workers/inprocess.py`, `workers/dispatch.py`, `src/api/v2/runs_common.start_job`,
`src/process_runs.begin_action`; revision `0022_redeliverable_jobs`
**Related:** ADR 0029 (job message), ADR 0030 (leases), ADR 0032 (idempotency)

## Context

The api ran every export on a `threading.Thread` inside the web process: one api task only, and a
deploy killed whatever run was in flight. Phase 11 moves the work to a worker that consumes a queue
(SQS on ECS). It must be switchable one process at a time (plan §5.1), roll back (§5.2), work on the
laptop without AWS, and never let two requests start the same run.

## Decision

1. **One implementation.** `workers.run_job` (authorize → claim → working state → handler → fenced
   settle) is the only code that runs a job, for both transports.
2. **Two transports, one switch.** `JOB_TRANSPORT=inprocess` (the default: a process-wide
   `Dispatcher`, one `InProcessQueue` with SQS's semantics, each delivery on a thread) or `sqs`
   (`SqsQueue.enqueue`; the ECS worker takes it). `workers/dispatch.enqueue` is the api's one door.
3. **Per-process cutover.** `WORKER_PROCESSES` lists the processes whose runs go through `enqueue`;
   empty (the default) is today's behaviour. RDS only — Supabase never routes.
4. **The api enqueues; the worker moves states.** The api's start is one compare-and-set on
   `process_runs` (`begin_action`): same `state`/`step`/`last_job_id` as the request's state check
   read, no job queued, no live lease → `step = processing` and the queued-job marker (`last_job_id`
   = the new job, `attempts` 0, an ownerless lapsed lease). The worker's claim turns the marker into
   attempt 1 and moves the run into its working state. Of two concurrent starts exactly one wins;
   the other is `409 RUN_STATE_CHANGED`. The legacy thread path uses the same compare-and-set, moving
   the state itself as it always did. A start no worker claimed is taken back (`abandon_action`).
5. **Redelivery on the in-process transport, as SQS would.** A delivery the dispatcher's queue did
   not see deleted (a thread that died) reappears after the visibility timeout. A killed PROCESS
   loses its queue, so each api process also asks `app.redeliverable_jobs` every minute (and at
   boot) for jobs no live worker holds — a working run whose lease lapsed after 1-2 claims, or a
   queued job unclaimed after 5 minutes — and delivers each again with the same `job_id`. After 3
   lapsed claims it is the sweeper's to fail. A CLAIMED job routed to SQS is SQS's to redeliver; a queued one whose message never left the api is sent again (ADR 0048 amendment 1, revision 0031).
6. **Rollback step 1.** `PROCESS_SUBMISSIONS_PAUSED` makes a process's create/execute/retry (and
   qb-usa's review) answer `503 PROCESS_PAUSED` and lists it disabled.

## Alternatives considered

**Keep the thread and add SQS beside it as a second implementation.** Two ways to book a period is
two places for a financial control to drift (the critic's "duplicate implementations"). Rejected.

**Let the api set `running` and the worker accept `running` as a start state.** Simpler, but the
worker could then not tell a resume from a fresh job, and a run the api marked `running` whose
message was lost would look like a live export. Rejected; the queued marker says exactly "queued, not
claimed".

**A durable local queue table for the in-process transport.** Survives a kill by construction, but is
a second queue beside SQS. The run row already records the job (`last_job_id`, `attempts`, the lease),
so the recovery reads that instead. Reversing costs a table and a poller (~1 day).

## Consequences

- A queued run is still `draft`/`blocked`/`ready` with `step = processing`; the envelope routes it to
  the processing screen and polls do not re-parse it.
- qb-usa's parse stays in the request even when routed (the create answers with the parse);
  tracked, with F3/T20.
- The api task needs the queue URLs and `sqs:SendMessage` on SQS (H1).
- A job refused by `authorize_job` (e.g. its creator left the org, D16) leaves the run queued until
  cancelled; each api process tries it once.

## Trigger to revisit

- A process whose jobs must run in order → FIFO (ADR 0030's trigger).
- More than one api task on the in-process transport in production → every task recovers; one wins
  each claim, the others' copies are acknowledged as duplicates, but the scan cost multiplies.
