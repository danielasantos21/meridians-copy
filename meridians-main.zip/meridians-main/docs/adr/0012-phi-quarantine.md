# ADR 0012 — PHI quarantine: a `phi` schema, the `phi_access` role, `patient_ref`, and `src/phi.py`

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §1 (PHI determination), §2.3

## Context

Meridian holds protected health information. `public.transactions` stores `patient_id`,
`claim_no`, `encounter_id`, `service_date`, `payment_date` and `billing_provider` —
76,132 live rows with 17,606 distinct patient identifiers. `public.source_transactions`
holds 167,290 verbatim billing rows. Exported workbooks carry a `Patient Acct No` column
(`src/exporters.py`), and the QuickBooks USA payroll channel carries employee dates of
birth and insurance member IDs (`src/qb_usa_payroll_processor.py:47-53`).

Account number + service date + provider + payer + amount is individually identifiable
health information under 45 CFR 164.514(b)(2). The journal-entry *output* is aggregate;
the storage underneath it is not. Design proceeds as **PHI-in-scope**.

Today all of this sits in one schema that the whole application can read. A single
mis-scoped query, a stray log line, or one over-broad grant exposes all of it.

## Decision

**Quarantine identifiers behind a schema boundary, a role boundary, and one code choke
point.**

```
public.transactions          -- everything EXCEPT the three identifiers
  + patient_ref TEXT          -- HMAC-SHA256(key from Secrets Manager, patient_id)
phi.transaction_identity     -- transaction_id PK → public.transactions, org_id,
                             --   patient_id, claim_no, encounter_id
phi.source_transactions      -- the 167,290 raw billing rows, moved as-is
audit.phi_access             -- who / what / when / how many rows, request_id, ip.
                             --   NEVER PHI values.
```

- **`meridian_app` has zero grants on `phi`.** `phi_access` holds SELECT/INSERT on
  `phi.*`. `meridian_app` gets INSERT-only on `audit.phi_access`.
- **Every PHI touch goes through `src/phi.py`** — the single choke point:
  `SET ROLE phi_access` → write the **opened** audit row → execute → write the **closed**
  audit row → `RESET ROLE` in a `finally`. Two rows, not one; see the dated note in
  Consequences for why the original one-row order could not be right.
- `pgaudit.log='ddl,role,write'` instance-wide, plus
  `ALTER ROLE phi_access SET pgaudit.log='read,write'` so reads are audited on the one
  role that can perform them.
- **The default export is tokenized.** The raw `Patient Acct No` column survives only in a
  permission-gated "detail export" written to the `phi` S3 bucket.
- **PHI is masked by default in every `/api/v3` response.** The `phi:read` scope unmasks,
  is never granted to an external client without a recorded partner BAA plus admin
  approval, and every unmasked read writes an `audit.phi_access` row.
- **GuardDuty Malware Protection scans every uploaded object**; nothing is processed until
  the object is tagged clean.

## Consequences

- **A keyed HMAC is not Safe Harbor de-identification.** Service dates remain identifiers.
  `patient_ref` shrinks exposure; it does not take anything out of HIPAA scope. Nothing in
  the design may assume otherwise.
- Nothing is lost by tokenizing: the only reachable use of `patient_id` is duplicate
  detection (`src/exporters.py:979-990`), which works identically on the hash. It was
  verified that raw `patient_id` reaches neither the API nor the UI.
- Every PHI read is slower (role switch plus an audit insert) and is visible in
  `audit.phi_access`. That is the deliverable.
- The HMAC key lives in Secrets Manager. **Losing or rotating it breaks the link between
  `patient_ref` and `phi.transaction_identity`** — the key is a backup-critical secret.
- **The RDS `postgresql` log group is itself a PHI store, and reading it is a PHI access.**
  `pgaudit.log` is `ddl,role,write` instance-wide (ADR 0020 §3d) and pgaudit logs the
  *statement text*; Meridian's writers interpolate literals client-side rather than binding
  parameters, so PHI values land in
  `/aws/rds/instance/meridian-<env>-rds-main/postgresql` in plain text. The quarantine is a
  `phi` schema and a `phi_access` role inside the database, and the log group is outside
  both — so it is classified `DataClassification=phi`, encrypted with the environment's
  `phi` CMK rather than the `logs` one, and treated as in scope for this ADR. A
  `GetLogEvents` against it is a person reading patient data and is not recorded in
  `audit.phi_access`, because nothing in the database saw it happen; **Phase 6 audits reads
  of that log group from the CloudTrail data event instead**, and that is the gap this
  paragraph exists to keep visible until it does.
- **`public.source_transactions` is still in `public`, and still holds identifiers
  (2026-09-16, critic M-4).** Plan P-3 has it moving into `phi` as-is
  (`ALTER TABLE ... SET SCHEMA phi`, not a 167k-row copy) and revision 0005 deliberately
  does not do it. Three things block the move and none of them is the move itself:
  `src/database.py` reads and writes that table as `meridian_app`, which has no grant of
  any kind on `phi`, so the move breaks upload the moment it lands;
  `scripts/tenant_tables.txt` is checked against both the committed Supabase dump (where
  the table is in `public` for ever) and a database at head, and those two cannot both
  pass across a relocation until `scripts/gen_tenant_tables.py` knows about it; and
  `scripts/lint_org_scope.py` resolves the same list. **Until then the quarantine is
  partial:** `public.transactions` is tokenised and `public.source_transactions` is not,
  so the raw spreadsheet rows behind every upload are still readable by `meridian_app`.
  It is carried in `docs/migration-tracker.md` against **Phase 5a**, with the repository
  layer that also gives `src/phi.py` a home.
- **The HMAC key has a fingerprint, so a silent re-key is impossible (2026-09-16, critic
  M-1).** `phi.hmac_key_fingerprint` holds one row — `sha256(key)` in hex, computed
  server-side — written by `scripts/split_phi.sql`. Running the split with a different key
  raises rather than rewriting every `patient_ref`, which is the one failure that produces
  a database that looks entirely correct and has lost the join to
  `phi.transaction_identity` for good. `--rotate` is the deliberate way past it and
  `docs/runbooks/rotate-secrets.md` §4 is the procedure.
- **The key is never in statement text (2026-09-16, critic C1).** The bullet above about
  the log group cuts both ways: a split script that interpolated the HMAC key into its
  `UPDATE` client-side filed the key next to the data it protects, in a 400-day PHI log
  group. The key is now a session setting passed in libpq's startup packet
  (`PGOPTIONS="-c meridian.phi_hmac_key=..."`) and read with `current_setting`, which
  `log_statement`, `log_min_error_statement` and pgaudit never see.
  `tests/test_split_phi.py` greps a real server log after a successful run and after a
  forced mid-statement failure.
- **The audit row is written twice: before the access and after it (2026-09-16, critic
  P5A-04).** The first implementation wrote a single row in the `finally`, i.e. *after* the
  identifiers had already been read. Anything that stopped the process in between — a
  SIGKILL, an OOM kill, an RDS failover, a `pg_terminate_backend`, a hard crash inside the
  block — therefore left **no record at all** of an access that had genuinely happened.
  That is the one failure an audit trail exists to survive, and it was the one it did not.
  `src/phi.with_phi_access` now writes an **opened** row before yielding and a **closed**
  row with the count on the way out. The two are told apart by `row_count`: **NULL means
  opened**. An opened row with no closed twin is the signal that an access began and its
  ending was never recorded, which is exactly what an auditor should see.

  Two INSERTs and not an INSERT plus an UPDATE, deliberately: revision 0003 grants
  `phi_access` and `meridian_app` **INSERT only** on `audit.phi_access`
  (`GRANT INSERT ON audit.phi_access`). An append-only table whose writer can also rewrite
  it is not append-only, and widening the grant to make the audit tidier would trade the
  property for the tidiness. The row count roughly doubles; at the volumes here that is
  noise against a table already retained for the full period.

  If the **opened** row cannot be written the block does not run: an unauditable PHI access
  is refused rather than performed quietly. If the **closed** row cannot be written while
  the block was already failing, the original exception still propagates and the audit
  failure is logged — the cause is more useful than the symptom.
  `tests/test_phi.py` covers all four paths.
- **The pair is matchable by `request_id`, and one is minted when the caller has none
  (2026-09-16, critic P5AR2-09).** The opened/closed pair above was distinguishable but not
  *pairable*: every other column on the two rows is identical by design, so with two
  accesses by the same user to the same object for the same reason in the same second — a
  batch load, i.e. the normal case — an auditor asking "which opened row has no closed
  twin?" has four rows and no way to say which NULL belongs to which count. The obvious
  fix is a shared access id column, and that is a migration; 0007 is taken and this is not
  worth a revision of its own. So `with_phi_access` now fills the column that already
  exists: `request_id` is the HTTP request id when a request supplied one, and otherwise a
  fresh uuid4 per access. Every pair therefore carries a value unique to itself, no schema
  moves, and the column keeps its meaning — an opaque id that ties rows of one event
  together and says nothing about a person. An HTTP request that opens two accesses still
  shares one id across both pairs; that is the correct reading of the column and the row
  counts keep the accesses apart.
- One database, not two. A separate RDS instance for PHI would double operational duty for
  one person; the schema plus non-owner role gives the grant boundary, and `pg_dump -n phi`
  makes a later split a one-day job.

## Trigger to revisit

A separate PHI database becomes necessary (a second engineer, an auditor requirement, or
a partner with PHI scopes); or someone needs raw patient identifiers in a screen, which is
a `phi:read`-gated detail view rather than a data-model change.
