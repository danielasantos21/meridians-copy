# ADR 0026 — Production readiness: what "ready" means, what gates it, and what stays a human decision

**Date:** 2026-09-16
**Status:** Accepted
**Phase:** 8 (`docs/aws-migration-plan.md`, "Phase 8 — Security hardening and compliance evidence")
**Supersedes nothing. Rewrites** (does not close) **two tracker rows** — both are still open,
for different reasons, and saying "closes" would have made the tracker read shorter than it
is (P8-10). The Phase 2 row "`cdk diff` does not run in CI" now says the role and the job are
built and waiting on a deploy and one repository variable; the Phase 3 row "Amazon Macie is
deferred" now says Macie is **decided off**, with the argument and the three triggers that
reverse it, and is reviewed again at the Phase 9 gate.
**Constrained by:** ADR 0001 (one shared account; no account id in code), ADR 0006 (nothing
is clicked in the console), ADR 0007 (RTO 8 business hours / RPO 1 hour), ADR 0011 (two
layers of tenant isolation), ADR 0020 (the locked backup vault and the cross-region copy),
ADR 0023 (Flask still mounted inside FastAPI), ADR 0024 (what we alarm on).

---

## 1. Context

Phase 8 is the last phase before anything real moves. Every earlier phase could be judged by
"does it work". Phase 8 cannot, because what it produces is mostly **evidence**: a dated
record that a control exists, that a person exercised it, and what came back.

That creates a problem the earlier phases did not have. "Ready" is a word everyone uses and
nobody defines, and without a definition it drifts in whichever direction the calendar
pushes. Two failure modes are both easy:

- **Declaring ready too early** — a control matrix full of rows pointing at runbooks nobody
  has run, which reads as complete and is a list of intentions.
- **Never declaring ready** — treating every open item as blocking, including the ones that
  need money or a lawyer, so the migration waits on things the engineering cannot move.

There is also an honesty problem specific to compliance. Meridian is **not** "HIPAA
certified" (no such certification exists) and **not** "SOC 2 certified" (that needs a CPA
firm, and none is engaged). The goal is *audit-ready controls with evidence*, and a document
set that says so plainly is worth more than one that implies more.

---

## 2. Alternatives considered

**A. "Ready when every control-matrix row says *in place*."** The strongest case for it: it
is unambiguous, and it is what an auditor would like. It fails on contact with reality —
about a third of the rows depend on a signature, an invoice or an attorney, and holding the
cutover behind an attorney engagement means the migration never happens. Reversing this
decision later costs nothing (it is a stricter gate), which is why it stays the *aspiration*
in §5 rather than the gate.

**B. "Ready when the engineering is done."** The strongest case: it is what the team
controls, and it is measurable. It is rejected because it is the definition that produced
the problem — a system can be entirely built and have no evidence that any of its controls
work, and the first restore drill after cutover is not the time to discover the backups were
never readable.

**C. A single "production readiness review" meeting.** The strongest case: it is the
industry-standard shape and it forces a moment of judgement. Rejected for a two-person
company: a review meeting with one attendee is a checklist wearing a costume. The checklist
is kept and the meeting is dropped.

**D. Chosen: ready is a set of named gates, each with an artifact, plus an explicit list of
what is deliberately *not* gated.** It is the only option that lets "not done" and "cannot
be done yet" and "will never be done by engineering" be three different answers.

---

## 3. Decision

### 3.1 "Production ready" means all eight gates below are green

Each gate names the artifact that proves it. No artifact, no gate.

| # | Gate | Artifact |
|---|---|---|
| 1 | **Security Hub**: zero unresolved CRITICAL or HIGH on FSBP and CIS v3; every suppression has a written reason | Exported finding list + the triage log |
| 2 | **Config**: every HIPAA conformance-pack rule `COMPLIANT`, or `NON_COMPLIANT` with an argued exception in the control matrix | The `NON_COMPLIANT` list + the exceptions |
| 3 | **GuardDuty / Inspector**: zero unresolved HIGH or CRITICAL; Inspector confirmed on **both** ECR and Lambda | Both finding lists + `batch-get-account-status` output |
| 4 | **Restore drill** from the 35-day locked vault against a production-shaped snapshot, **and** the cross-region DR test, both inside RTO 8 business hours / RPO 1 hour | The row in `restore-drill.md` §7 + the DR count comparison |
| 5 | **Every secret rotated once through its runbook** (the PHI HMAC key excepted, in writing — rotating it re-keys every `patient_ref`) | `rotate-secrets.md` §7's record + the written exception |
| 6 | **Backup vault lock verified by a refused delete**, with the changeable window closed | The refusal message + `describe-backup-vault` |
| 7 | **Production stacks deployed with synthetic data and smoke-tested**, and the bill inside the approved estimate | Smoke outputs + a Cost Explorer day |
| 8 | **The control matrix has no row whose evidence cell names an artifact that does not exist** | The matrix itself |

The procedure for every one of them is `docs/runbooks/production-readiness.md`. That runbook
is the operational form of this ADR; this ADR is why the runbook has the sections it has.

### 3.2 Two controls added in Phase 8, because a gate needs something to gate

- **A read-only `cdk diff` in CI.** `meridian-shared-iam-github-diff` may assume exactly one
  bootstrap role — `cdk-<qualifier>-lookup-role`, which `cdk bootstrap` creates with
  `ReadOnlyAccess` and a deny on `kms:Decrypt` — read `meridian-*` stack templates, and read
  the bootstrap version parameter. Nothing else, no `Resource: "*"`, no write action.
  `backend.yml`'s `infra-diff` job uses it on **pushes to the two branches**, posts nothing
  (the log is the artifact), and **skips cleanly** while the repository variable
  `AWS_DIFF_ROLE_ARN` is unset.

  Four sub-decisions worth recording.

  (a) **A third role, not a wider second one**: the deploy roles' whole power is assuming the
  `cdk-*` bootstrap roles, and one of those passes an `AdministratorAccess` execution role —
  not a thing to hand a CI job.

  (b) **`pull_request` is NOT trusted** (revised in round 1, P8-03; the first version of this
  ADR said it was, and excluded forks with a workflow condition). `cdk diff` renders the
  diffed branch's own Python on the runner, and the `cdk-…-lookup-role` it may assume is
  `ReadOnlyAccess` over an account that will hold PHI: CloudWatch Logs content,
  `cognito-idp:ListUsers`, `rds:Describe*`, secret names and metadata, every S3 object not
  under a CMK. That is not a thing to hand pre-review code. The job therefore runs on `push`
  to `main` and `aws-migration` — after review — and the trust policy's subject list is now
  exactly the deploy role's. **The cost is real and is accepted:** the diff appears after the
  merge rather than during the review, so it is a "what did we just change" signal, not a
  "should we merge this" one. The fork question disappears with it: a fork cannot push to
  those branches. Threat model §13.7.5 carries the reach and the residual.

  (c) **`--method=template`, not the default `auto`**: `cdk diff`'s default asks
  CloudFormation to compute the diff by creating a change set, which needs
  `cloudformation:CreateChangeSet` *and* assumes `cdk-…-deploy-role` — the one role this
  identity may not assume. Passing `template` computes the diff from the two templates, which
  is the only mode a read-only identity can serve and the only mode under which "only the
  lookup role is assumed" is a true sentence (P8-04).

  (d) **The diff's CONTENT is gated, not just printed** (P8-05). The job does not pass
  `cloudfrontPrefixListId` or `hostedZoneId` (identifiers, ADR 0001), so `meridian-staging-vpc`
  and `meridian-staging-edge` diff against their synth placeholders and show a change every
  single run. Two permanently-noisy stacks is how a real diff gets scrolled past, so a grep
  over the diff output fails the job on a removal (`[-]`) or replacement of
  `AWS::RDS::`, `AWS::KMS::`, `AWS::S3::Bucket`, `AWS::Cognito::UserPool` or
  `AWS::Backup::BackupVault` — the resources whose replacement destroys something this
  repository cannot recreate. It is a tripwire over text output, not a policy engine; a
  legitimate destructive change is *meant* to trip it, and the answer is a deliberate deploy
  by hand with the runbook open.

  (e) **Skip, not fail, when the variable is missing**: `continue-on-error: false` is kept so
  a real diff failure is red, and the tolerated absence is the job not running at all —
  because CI must stay green on the day this lands, when the role is not yet deployed.

- **`npm audit` as a build gate.** The backend has had `pip-audit --strict` since Phase 0 and
  the images have had Trivy since Phase 5a; the browser bundle — the half an attacker reaches
  without authenticating — had nothing. `web/scripts/audit-gate.mjs` fails the `web` job on
  any HIGH/CRITICAL advisory not accepted in `web/.npm-audit-allow.json`. The allowlist is
  the same shape as `.trivyignore`: an entry needs a package, a reason, an owner and a
  `review_by` date, and an **expired** entry fails the build too, which is what stops a
  temporary exception becoming permanent.

  `npm audit --audit-level=high` alone was rejected: it has no way to accept one advisory,
  so its only settings are "fail on everything" and "do not run", and a gate nobody can
  satisfy is a gate everybody reruns until it is green.

### 3.3 Security Hub gets CIS v3.0.0; Macie stays off

**CIS added, and the plan did not ask for it.** Round 1 caught the justification claiming
otherwise (P8-07): the plan's Phase 8 line says "Security Hub with the AWS Foundational and
HIPAA standards" and names **no benchmark at all**. FSBP and NIST 800-53 Rev 5 were enabled;
CIS `v3.0.0` is added here on its own merits, which are two. It is the benchmark a pen-test
report and a SOC 2 auditor ask for **by name**, so its absence is a question to answer rather
than a control to explain. And its ~60 controls are the cheapest way to be told about a
root-account or region-level lapse — the class of finding FSBP and NIST 800-53 report
unevenly, because neither is organised around the account itself. All three standards read
the same Config recorder, so the marginal cost is Security Hub's own per-check charge, inside
the Phase 1 estimate's $5-20 range for that line.

**Inspector widened to Lambda.** The earlier comment said Lambda scanning "is not in scope";
that stopped being true in Phase 4, when the User Migration Lambda started seeing a migrating
user's password in clear text. Standard Lambda scanning is about $0.30 per function per
month. `LAMBDA_CODE` — the dearer code-scanning tier — stays off, and so does EC2: no EC2
instance here runs application code.

**Macie stays off. Decided by Andres on 2026-09-16; this is the decision, not a deferral.**

Macie is the only control that would *measure* rather than assert "PHI is only in the `phi`
bucket": it classifies bucket contents, so it would catch PHI written into `artifacts` — where
`src/storage.py`'s `bucket_for` is supposed to send only de-identified exports — or into the
`audit` bucket.

**The argument rests on "nothing to find", not on the money** (P8-06 corrected this: round 1
said "real money", and the plan's own cost table at `docs/aws-migration-plan.md` §"Cost"
prices Macie at **≈ $2.00/month** for two buckets with automated discovery off, which is not
real money on a ≈ $239/month estate — it is 0.8 %). The honest statement is narrower and
stronger: **today Macie would have nothing to classify.** Production holds no data until
Phase 9 and staging holds synthetic data, so every dollar and every finding-review minute
buys a scan of files we wrote ourselves. Two smaller cost points stand, and neither is the
reason: the $2.00 is for monitoring with discovery **off**, and per-GB discovery — the part
that would actually look inside the objects — is not priced anywhere in the estimate; and the
estimate's Macie line is additive to the ≈ $239, not inside it.

**What stands in for it:** `bucket_for` and its tests, GuardDuty S3 data events on the `phi`
bucket, GuardDuty Malware Protection on uploads, and the PHI-logging lint — all assertions
about code except the GuardDuty pair, which is the honest statement of the residual risk.

**Enable it, with one automated discovery job scoped to `phi` and `artifacts`, at the FIRST
of these three** — they are written here so that the decision has an expiry the same way an
allowlist entry does:

1. production carries real data for one full period after Flip 2 (Phase 9);
2. the first PHI-scoped external partner exists;
3. any finding — from a pen test, an incident or a code review — that PHI reached a bucket
   other than `phi`.

**Decider:** Andres. **Reviewed again at:** the Phase 9 gate, not "some day".
`docs/runbooks/production-readiness.md` §14 and the `docs/migration-tracker.md` row carry the
same three triggers; if they ever disagree, this ADR is the one that decided.

### 3.4 What stays a human decision, permanently

These are **not** gates, and no amount of engineering closes them. They are listed so that
their absence is a known state rather than an oversight. The full table, consolidated from
every phase report, is `production-readiness.md` §13.

| Decision | Why it cannot be a gate |
|---|---|
| **Accepting the cost** | Money. Nothing billable exists without it, and it is Phase 1's exit criterion, not Phase 8's |
| **Buying the penetration test** | An engagement and an invoice. Phase 8 produces the scope, the accounts, the ASVS checklist and the diagram; the test is bought |
| **Engaging a SOC 2 auditor** | A CPA firm. Until one is engaged Meridian claims audit-ready controls and never "SOC 2 certified" |
| **The written policy set** (risk analysis, sanction, workforce, training, physical, evaluation) | An attorney reviews them; the security official signs them. **Amended 2026-09-16 (Codex PS-18): the incident-response and contingency policies are no longer in this row.** A PHI system cannot be cut over without a signed procedure for "something went wrong" and "the region is gone", so those two are Phase 9 precondition E in `runbooks/cutover.md` — attorney review can follow, a signed operating version cannot |
| **Partner BAAs** | A signature, per partner, before any `phi:read` scope is granted |
| **The in-transit position paper** for the ALB → task hop | 164.312(e)(2)(ii) is *addressable*: implement it, or write down why not and what you do instead. Writing it down is the work |
| **Approving each flip** | Judgement about whether a close is running and whether someone is reachable by phone |

### 3.5 What "ready" explicitly does not require

Stated so that nobody re-opens them at the gate: Multi-AZ RDS (ADR 0007 — RTO/RPO say
single-AZ is sufficient and the DR test is what proves it); a zero-finding NIST 800-53 Rev 5
score (the broadest standard; its MEDIUMs are a reading list); an empty
`docs/migration-tracker.md` (that is **Phase 12's** exit criterion, not Phase 8's); and
Amazon Macie (§3.3).

---

## 4. Consequences

- **Phase 9 has a checkable entry condition.** Its preconditions already say "production
  stacks deployed and smoke-tested, cost within estimate"; §3.1 is what makes that a thing
  somebody can verify rather than assert.
- **Six of the eight gates cannot be exercised until the account is deployed**, which means
  Phase 8 is genuinely two pieces of work separated by a human decision about money.
  `production-readiness.md` §12 lists exactly which, so that "not done" and "cannot be done
  yet" never look alike in a status report.
- **CI gained a job that needs account access.** It is read-only and it skips when
  unconfigured, but it is still the first time a pull-request workflow can reach AWS. The
  threat model's §13.7 rows 3-5 carry that, including the one that matters: `cdk diff` runs
  the pull request's own Python on a runner holding those credentials, which is why the
  ceiling is read-only rather than convenient.
- **The `web` job can now go red for a reason nobody in this repository controls** — a new
  advisory against a transitive dependency. That is the intended behaviour; the escape hatch
  is an argued allowlist entry with an expiry, not a flag.
- **Four postcss advisories are accepted today** because the only fix is a major upgrade to
  Next 16. That is written down with an owner and a review date rather than hidden behind
  `--audit-level=critical`.
- **The `needs-a-human` list is now one table with 41 rows**, consolidated from the eight
  phase reports in `docs/reports/` (0, 1, 2, 3, 4, 5a, 5b and 6) and the control matrix.
  Round 1 corrected both numbers: the count was 37 before Phase 5b's and Phase 6's own rows
  were merged in, and "six reports" was never right (P8-15/P8-17). **Phase 7's report is
  being written as this lands**; merging its section in is a step of the Phase 8 close, not
  an optional tidy-up.

---

## 5. Trigger to revisit

- **Any gate is missed and the answer is to lower it.** Lowering a gate is a new ADR, not an
  edit to this one.
- **A PHI-scoped external partner exists.** That is the event that turns three deferrals into
  requirements at once: Macie (§3.3), the penetration test (from "before production" to
  "done and closed"), and a partner BAA.
- **Every control-matrix row reaches *in place*.** Then alternative A above becomes the gate,
  and this ADR is superseded by one that says so.
- **The estate stops being one account** (ADR 0001 splits). Security Hub, Config, GuardDuty,
  Inspector and the OIDC provider are all account singletons, and every gate in §3.1 assumes
  exactly one of each.
