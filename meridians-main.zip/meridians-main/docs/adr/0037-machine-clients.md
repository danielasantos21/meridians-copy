# ADR 0037 — Machine clients: lifecycle, secrets and rotation

**Date:** 2026-09-24
**Status:** Accepted (design, and the approval rule answered by Andres on 2026-09-22). **Creating
any client in a deployed environment still needs the Phase 12 cost line approved**
(`docs/reports/phase-1-cost-estimate.md`, "Phase 12 — pending approval").
**Source:** `docs/reports/phase-12-plan.md` §3.6, R3-R5, R15, T05, T12, T21; ADR 0021 (15-minute
machine tokens); `infra/meridian/stacks/auth.py:636-663` (the placeholder client)
**Numbering note:** planned as "0029" in the Phase 12 plan; renumbered (Phase 11 holds 0027-0034).

## Context

A **machine client** is a program (our own script, a partner's system) that calls the API with
no person present. It signs in with OAuth **client credentials**: it sends a client id and secret
to Cognito's `/oauth2/token` and gets a 15-minute **access token**. Today nothing in Meridian
accepts such a token — `src/cognito.py:547` refuses any `token_use` other than `id` on purpose —
and the CDK creates one placeholder client, `meridian-<env>-auth-machine`
(`infra/meridian/stacks/auth.py:636-663`), that nothing uses.

Three facts shape the design: Cognito, not Meridian, checks the secret; a token stays
cryptographically valid until it expires, even after we decide to cut the client off; and each
client is a real Cognito object someone has to create, rotate and eventually delete.

## Alternatives considered

**CDK-managed clients** (one construct per client, redeploy to add one). The strongest case:
every client is in version control and reviewed like code; an auditor who wants "infrastructure
as code only" is satisfied. Rejected because clients are data like users: adding a partner would
mean a code change, a deploy and a secret passed through CloudFormation outputs. Reversing costs a
config table read by CDK plus moving the create/rotate flow into a runbook (~2 days). Trigger: an
auditor requires IaC-only clients (plan R3).

**Store a hash of the secret in Postgres** (the migration plan's wording). Rejected: Cognito
verifies the secret, so a hash in our database verifies nothing. The row keeps a **fingerprint**
(a short SHA-256 prefix) only so the screen can show which secret is live during a rotation.

**Rotate by creating a second app client** (the plan's fallback). Worked, but doubled the
objects to track. No longer needed — see the verified finding below.

## Verified in T01 (public AWS documentation, 2026-09-24; no AWS account call)

| Question | Finding | Confidence | Source |
|---|---|---|---|
| Is there a monthly fee per machine app client? | **No, not any more.** AWS removed the M2M app-client price dimension on 3 Nov 2025; only successful token requests are billed. The pricing page: "There is no additional charge for the number of app clients you have registered in your account." | HIGH | https://aws.amazon.com/about-aws/whats-new/2025/11/amazon-cognito-removes-machine-machine-app-client-price-dimension ; https://aws.amazon.com/cognito/pricing/ |
| Price per token | **$0.00225 per successful token response** ($2.25 per 1,000; $0.002925 with multi-Region replication, which we do not use). "There is no free tier for token requests when Cognito is used for the machine-to-machine use case." | HIGH | https://aws.amazon.com/cognito/pricing/ |
| Can one app client hold two secrets at once? | **Yes.** "Each app client can have up to two secrets at a time, enabling secret rotation without downtime." Added with `AddUserPoolClientSecret`, removed with `DeleteUserPoolClientSecret`; "You cannot delete the only secret associated with an app client." A caller-supplied secret must be 24-64 characters, and in that case the API does not echo it back. | HIGH | https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-settings-client-apps.html ; https://docs.aws.amazon.com/cognito-user-identity-pools/latest/APIReference/API_AddUserPoolClientSecret.html |
| When was it introduced? | February 2026 ("client secret rotation and custom secrets"), all Cognito regions, console/CLI/SDK/CloudFormation. | MEDIUM (announcement seen through search results, not fetched) | https://aws.amazon.com/about-aws/whats-new/2026/02/amazon-cognito-client-secret-lifecycle |
| Does deleting a secret kill tokens already issued with it? | **Not stated in the docs.** Assume no: a token lives until it expires (≤ 15 min). Our `revoked_epoch` check is what makes revocation immediate, so the answer does not change the design. | LOW (absence of documentation) | — |
| Exact IAM action names for the two calls | **Verified at T21 (2026-09-24):** `cognito-idp:AddUserPoolClientSecret`, `DeleteUserPoolClientSecret`, `ListUserPoolClientSecrets`, `CreateUserPoolClient`, `UpdateUserPoolClient`, `DeleteUserPoolClient` and `ListUserPoolClients` all exist under those names, and every one takes the `userpool` resource type, so one pool ARN scopes them. `ListUserPoolClientSecrets`' API page confirms it never returns the secret value. The policy is `infra/meridian/stacks/api.py` (`COGNITO_CLIENT_ADMIN_ACTIONS`). (Originally: expected to match the API names; the page could not be read in T01.) | HIGH | https://servicereference.us-east-1.amazonaws.com/v1/cognito-idp/cognito-idp.json (the Service Authorization Reference in machine-readable form) ; https://docs.aws.amazon.com/cognito-user-identity-pools/latest/APIReference/API_ListUserPoolClientSecrets.html |

## Decision

1. **Clients are runtime rows** in `public.api_clients` (plan §3.5), each backed by a Cognito app
   client the api creates through a `CognitoClientAdmin` port (client-credentials only, generated
   secret, 15-minute access token, allowed scopes = the granted set). The api's IAM permission is
   limited to create/update/delete app clients and add/delete their secrets **on the one user
   pool ARN**, with no `DescribeUserPoolClient` (which returns the secret). CloudTrail records
   each call; the `api_clients` table is the inventory.
2. **Request → approve.** An org admin requests (status `pending_approval`); a superadmin
   approves with a reason, inside `with_superadmin` so the approval is audited. **Andres approves.**
   *Amended 2026-09-25 (critic Stage 1 M-6, provisional):* the requester may approve their own
   client **only in development**; in staging and production a second superadmin must
   (`src.api_clients.self_approval_allowed`). The 2026-09-22 "self-approval allowed for now"
   default is superseded; pinning `SELF_APPROVAL_ALLOWED = True` is a reviewed override, and the
   quarterly access review still flags any self-approval. The secret is shown once to the approver and never stored or
   logged; the row keeps its fingerprint.
3. **Every request re-checks the row** (`src/cognito.validate_machine_token`, a sibling of
   `validate_token`, T05): signature, issuer, expiry, `token_use == "access"`, then
   `app.api_client_for_token(client_id)`; refused with a plain `401` if there is no row, status is
   not `active`, the token was issued before `revoked_epoch`, or the caller's IP is outside the
   allowlist. The tenant is the **row's** `org_id`, never anything in the token.
4. **Revoke:** `status='revoked'`, `revoked_epoch=now()` — effective on the next request — then
   delete the Cognito app client so no new token can be minted.
5. **Rotate: two secrets on the same app client** (`AddUserPoolClientSecret`), hand the new one
   over once, delete the old one (`DeleteUserPoolClientSecret`) when the partner confirms. The
   second-app-client fallback is dropped.
6. **Lifecycle:** a daily job disables clients unused for 90 days; `scripts/api_access_review.py`
   writes the quarterly review (clients, scopes, approver, last use, BAA) to the audit evidence
   location, not the repository.
7. **The placeholder CDK client is deleted in T21** — for tidiness now, not cost: with the
   per-client fee gone it costs nothing unless it requests tokens.
8. **Both generated clients cache the token until 60 seconds before expiry.** Tokens are the only
   remaining cost, so caching is the cost control.

## Consequences

- Monthly cost per client is only its token volume: a script run a few times a day ≈ 90 tokens ≈
  $0.20; a service that keeps a cached token all day, every day ≈ 2,880 tokens ≈ $6.48. The plan's
  "~$6 per client" line is obsolete.
- A revoked client's *already-issued* token is refused by us at once, but Cognito would still
  honour it elsewhere for up to 15 minutes — nothing else trusts these tokens, so this is moot.
- Cognito objects exist outside CDK. Drift between `api_clients` and the pool is checked by the
  access-review script (list clients in the pool vs rows).

## Trigger to revisit

- An auditor requires IaC-only clients → CDK clients from a config table (R3).
- Andres rules that a one-person approval is acceptable in production until a second superadmin
  exists → pin `SELF_APPROVAL_ALLOWED = True` in a reviewed commit and record it here.
- AWS reintroduces a per-client fee, or token volume passes ~5,000/month per client → re-price and
  review the caching.
