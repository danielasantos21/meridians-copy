# ADR 0047 — Starting a run is a compare-and-set; a dead request's key expires after 15 minutes

**Date:** 2026-09-25 (written; built 2026-09-24, Phase 11 D4 wave)
**Status:** Accepted and built, **RDS only** (the Supabase and in-memory stores keep their
unconditional writes).
**Amends:** ADR 0032, Consequences bullet 2 ("a process killed between `begin` and an execute's first
write leaves that key `pending` for good") — for `run.execute` it now expires. **Details:** ADR 0028
decision 4, which states the compare-and-set in one paragraph.
**Source:** `docs/reports/local-first-plan-2026-09-24.md` progress log (E3 "queued (correctness)"
entry and the D4 merge entry); `src/process_runs.py`, `src/api/v2/runs_common.py`,
`src/api/v2/execute_idempotency.py`, `src/idempotency.py`

## Context

Two gaps were left after E3 put `Idempotency-Key` on execute/retry (ADR 0032):

1. **Double start.** Two requests that both passed the state check against the same read of a run
   both went on to start it. With different keys, or none, the idempotency ledger cannot tell them
   apart — each started an export, which can mean **two journal entries for one period**.
2. **A key stuck forever.** A request killed between the ledger's `begin` and its first write left
   its `run.execute` row `pending` with no effect; every retry with that key answered
   `409 IDEMPOTENCY_CONFLICT` (`in_progress`) indefinitely.

## Alternatives considered

**Rely on the idempotency key alone.** Rejected by gap 1: a key only groups requests that chose to
share it (`process_runs.begin_action`'s docstring). The run row already carries
the state and the lease (ADR 0030), so the row itself decides.

**Keep ADR 0032's rule: the key stays `pending`, the client sends a new key.** Replaced for
`run.execute` only: whether the dead request's effect happened is visible on the run, so the ledger
can decide by itself; a `qbo.journal` key is still reconciled by re-query, never by age (decision 6).

## Decision

1. **One conditional UPDATE decides who starts the run** (`begin_action`,
   `src/process_runs.py`: `PostgresRunStore.begin_action` and the module-level `begin_action`). It matches only if the run is still exactly as the request
   read it — same `state`, `step` and `last_job_id` — no job is queued on it (`attempts = 0 AND
   last_job_id IS NOT NULL`) and no live lease is held. The winner's write takes the action: the job
   path sets `step = processing` and the queued-job marker; the legacy thread path also sets the
   state (`src/api/v2/oneshot_runs.py`, its `process_runs.begin_action` call). The row lock makes exactly one winner.
2. **The loser gets `409 RUN_STATE_CHANGED`** (`src/api/v2/errors.py` `RUN_STATE_CHANGED` and its `STATUS_FOR_CODE` entry;
   `src/api/v2/runs_common.state_changed`): "reload it before trying again".
3. **A start no worker claimed is taken back** (`process_runs.abandon_action`), only
   while the marker is still that job's with no owner.
4. **A lost queued job can be replaced** (`lost_after`, E2 follow-up): a queued job never claimed and
   marked longer ago than `lost_after` seconds, by the database clock, may be overwritten — still in
   the same one UPDATE. Used only by the qb-usa QuickBooks push (`PUSH_LOST_SECONDS`,
   `src/api/v2/qb_usa_runs.py`, and its `lost_after=` use there).
5. **A `pending` `run.execute` key expires after 15 minutes** (`STALE_PENDING_SECONDS = 15 * 60`,
   `src/api/v2/execute_idempotency.py`). `idempotency.begin(..., stale_after_seconds=N)` re-arms a
   `pending` row older than N seconds **by the database's clock** and answers `stale`, inside the
   same locked transaction (`_REARM_STALE` and `begin`'s stale branch, `src/idempotency.py`), so of two retries
   exactly one takes it over. On `stale`, if the run shows the action took effect the key settles
   `completed` and replays; otherwise the action runs again (`execute_idempotency.run_once`).
6. **Never for a journal.** `stale_after_seconds` is refused for `qbo.journal` (`idempotency.begin`'s argument checks):
   a pending journal may have reached Intuit and is reconciled by re-query, never by age (ADR 0032).

## Consequences

- Two concurrent executes of one run can no longer both start it on RDS, whatever keys they send;
  and if a "dead" request was alive after all, the compare-and-set still lets only one start.
- A client whose request died can reuse its key after 15 minutes instead of inventing a new one.
  The ledger row stays as evidence; `attempts` counts the take-overs.
- **Supabase is not covered:** `begin_action` returns None there and the old unconditional write
  stands, so production on Render keeps the gap-1 exposure until cutover.

## Trigger to revisit

- A legitimate execute measured over 15 minutes before its first write → raise the window.
