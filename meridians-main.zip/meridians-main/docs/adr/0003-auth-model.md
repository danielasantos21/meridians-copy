# ADR 0003 — Auth model: Cognito, `custom:app_uid`, dual-token acceptance

**Date:** 2026-09-15
**Status:** Accepted. **Refined by ADR 0021** (`0021-auth-cognito-sessions.md`), which fixes the session mechanics and revises the refresh-token lifetime below from 12 hours to 30 days.
**Supersedes:** `docs/api-v2-contract.md` §0 and §6 **once Phase 4 begins.** Until then the
contract's cookie-session description is still what production does.
**Source:** migration plan v3.1 §2.1, decisions D-06 and D-13

## Context

Identity today is Supabase Auth: 14 `auth.users` rows, email plus Google and Microsoft
sign-in, HS256 JWTs (JSON Web Tokens — signed bearer credentials) verified with a shared
secret, and HttpOnly cookie sessions with CSRF protection described in contract §6.
Authorization — roles, permissions, org modules, superadmins — lives in Postgres tables.

Moving identity to **Amazon Cognito** raises three problems:

1. **The user id changes.** Application rows across ~30 tables carry the Supabase UUID,
   with no foreign keys to catch a mistake. A rewrite is the single most dangerous work
   item in the whole migration.
2. **Passwords cannot be exported.** Supabase will not hand over password hashes, so a
   naive move forces every user to reset.
3. **Timing.** If auth moves at the same moment as data and compute, one rollback has to
   undo three things at once.

There is also a forward requirement: a future React Native mobile client and machine
clients must work against the same endpoints, and today's endpoints only understand
cookies.

## Decision

- **Amazon Cognito user pool** `meridian-<env>-auth-users`, MFA required (TOTP), Google
  and Microsoft kept as federated identity providers, `PreventUserExistenceErrors` on.
- **One custom attribute `custom:app_uid`** (String, 36, immutable) holds the legacy
  Supabase UUID for migrated users and the Cognito `sub` for new ones. Token verification
  returns `claims.get('custom:app_uid') or claims['sub']`, so **no application row is ever
  rewritten.**
- **Dual-token acceptance during the transition.** `require_auth` accepts *either* a
  Supabase JWT (HS256, as today) *or* a Cognito ID token (RS256, verified locally against
  the pool's cached JWKS with PyJWT — no network call). The issuer claim decides which
  path runs; both resolve to the same application user id.
- **Cookie sessions stay for the browser; `Authorization: Bearer` is accepted on the same
  endpoints for mobile and machine clients.** Browser ID token 60 minutes with a 12-hour
  refresh (down from Supabase's 7 days); machine access tokens ≤ 15 minutes.
- **A User Migration Lambda, with no forced reset.** It handles both the
  `UserMigration_Authentication` and `UserMigration_ForgotPassword` triggers, verifies the
  password against Supabase Auth at first sign-in, creates the Cognito user silently with
  `custom:app_uid` set, never logs passwords, **fails closed** if Supabase is down, runs
  outside the VPC with a **5-second timeout** (Cognito abandons the trigger at ~5s).
- **Federated-only users are pre-created by hand** with `AdminCreateUser`
  (`MessageAction='SUPPRESS'`) and `AdminLinkProviderForUser` **before the IdPs are
  enabled** — enabling an IdP first auto-creates duplicate empty accounts, and the single
  superadmin is Microsoft-only.
- **Authorization stays in Postgres**, read on every request. Never a token claim, never a
  Cognito group.
- **Cut-off: cutover + 60 days.** After that the trigger is detached, the Lambda deleted,
  and any straggler is `AdminCreateUser`'d and sent a password reset.
- Cognito goes live at the end of **Phase 4 (Flip 1)**, before the data cutover (Flip 2,
  Phase 9). Two screens are built in React first: password reset and the MFA challenge.

## Consequences

- The 30-table UUID rewrite is deleted from the plan entirely.
- Auth can flip in production while data is still on Supabase, and the flip is reversible
  with a config change — `auth.users` is never mutated; Cognito users are copies. That
  reversibility ends at the Phase 10 cut-off.
- Supabase Auth stays live and paid until the cut-off date.
- Two Cognito gotchas are written into the implementation: refresh computes `SECRET_HASH`
  from the username/sub, not the email; and the refresh response carries **no new refresh
  token** — hand the old one back or everyone is logged out at 60 minutes.
- The token and org/permission/module/superadmin caches in `src/auth.py` are deleted
  (1-2 ms lookups against in-VPC RDS; the caches are a documented staleness bug), but the
  seam function names stay — 62 monkeypatch sites depend on them.
- Contract §0/§6 no longer describes the system once Phase 4 starts; this ADR does.

## Note, 2026-09-16 — "pre-link the federated users" means the federated-ONLY users

This ADR's procedure ("every federated identity is pre-created and pre-linked before its IdP
is enabled") was implemented, reviewed, and narrowed. `AdminCreateUser` for somebody who has
a password **removes** their migration path: Cognito never invokes the User Migration trigger
for a user that already exists, so a pre-created password user sits in
`FORCE_CHANGE_PASSWORD` — the forced reset this ADR chose the Lambda to avoid. So
`scripts/preprovision_cognito_users.py` pre-creates and links **only** the federated-only
identities. A user with both a password and a provider migrates through the Lambda on their
first sign-in and is linked afterwards (`--link-only`). Enabling a provider on the pool and
offering it as a sign-in button are also now two separate deploys, because a link cannot be
made until the provider exists. Details and the residual risks: ADR 0021 § Residual risks,
and `docs/runbooks/cognito-user-migration.md` §2-§3.

## Trigger to revisit

The User Migration Lambda's p99 measured on staging exceeds the 5-second Cognito trigger
budget; or migration stalls well short of 100% as the cut-off approaches; or a real need
for self-serve signup appears (today invite-only, P-6).
