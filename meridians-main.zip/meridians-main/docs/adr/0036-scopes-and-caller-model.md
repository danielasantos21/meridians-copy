# ADR 0036 — Scopes and the caller model

**Date:** 2026-09-24
**Status:** Accepted (built for humans in T03, commit `c6b8fde`; the machine branch lands in T05)
**Source:** `docs/reports/phase-12-plan.md` §3.4, T03, T05; ADR 0003 and ADR 0021 ("no roles in
any claim")
**Numbering note:** planned as "0028" in the Phase 12 plan; renumbered (Phase 11 holds 0027-0034).

## Context

A **scope** is a named permission such as `runs:read`; an endpoint declares the scope it needs
and a caller without it is refused. `/api/v2` has no scopes: it checks a human's permission rows
(`require_permission`, `api/deps.py:220-249`) and the org role (`require_admin`, `:252-266`).
Phase 12 adds machine callers, which have no permission rows and no role, and their tokens do
carry a `scope` claim. Without one model for both, every handler would need a human branch and a
machine branch, and the first handler that forgot one would be a hole.

ADR 0021 already fixed one rule this must keep: authorization lives in Postgres and is read on
every request; no claim in any token decides what a *human* may do.

## Alternatives considered

**Put human scopes in the token** (a Cognito group or a pre-token-generation Lambda that writes
`scope`). The strongest case: one code path — every caller is "token scopes", checking is a set
lookup, and it is the textbook OAuth shape. Rejected because it breaks ADR 0021: a permission
change would take up to 60 minutes (the ID-token life) to bite, and a claim becomes the thing that
grants access. Reversing would cost a Lambda trigger, a migration of every permission row into
groups and new staleness tests (~3 days). Trigger: none foreseen — this would need ADR 0021
superseded first.

**Trust machine tokens' `scope` claim alone** (no database row). Simpler, but then revoking or
narrowing a client means deleting it in Cognito and waiting up to 15 minutes. Rejected: the row
lets a revocation bite on the next request (ADR 0037).

**Scope checks inside handlers.** Rejected: the route-matrix test can only prove "every route
declares a scope" if the declaration is structural.

## Decision

1. One `Caller` (`api/v3/deps.py:45-70`): `kind` human or machine, `org_id` **always from a
   database row** (membership for a human, the `api_clients` row for a machine), exactly one of
   `user_id` / `client_id`.
2. **Humans:** scopes are derived on every request from the rows `require_org` already read, by
   `src/api_scopes.scopes_for_human` (`human_caller`, `api/v3/deps.py:72-85`) — never cached,
   never a claim. The mapping is plan §3.4's table (e.g. a process's `results` permission gives
   `runs:read`, `artifacts:download`, `journal-entries:read`, `processes:execute`; the org
   `admin` role gives the admin scopes; `phi:read` comes only from a new `roles.can_read_phi`,
   default false).
3. **Machines:** effective scopes = the token's `scope` claim ∩ `api_clients.granted_scopes`,
   narrowed per process by `allowed_processes`.
4. **Human-only scopes** (`org:admin`, `clients:manage`, `audit:read`, `settings:admin`,
   `superadmin`, `profile:self`, `dashboard:self`) can never be held by a machine: refused in
   `Caller.allows` and by a CHECK on `api_clients`.
5. **One enforcement point:** `require_scope(...)` (`api/v3/deps.py:98-130`) is the only place a
   scope is compared; handlers never read scopes. A failure is `403 SCOPE_INSUFFICIENT`, checked
   before any object is loaded, so it reveals nothing about whether the object exists.
6. The Cognito resource server's scopes become the machine-grantable catalogue. `runs:write` is
   renamed `processes:run` (nothing has used it). `phi:read` is added to the resource server only
   when the first partner BAA is recorded — a scope nothing checks must not exist.

## Consequences

- Handlers are identical for humans and machines; the difference is entirely in `resolve_caller`.
- Adding a permission to the React admin screen changes a human's scopes on their next request.
- Every new scope is a catalogue edit plus, for machines, a resource-server change in CDK.

## Trigger to revisit

- A permission model change (per-location permissions, say) that the per-process mapping cannot
  express → extend `scopes_for_human`, not the token.
- A partner needs a scope narrower than one process → add a resource qualifier to the grant row.
