# ADR 0025 — Sending through SES: the switch, the one-email rule, and the `From` condition

**Date:** 2026-09-16
**Status:** Accepted
**Source:** migration plan v3.1 §3 Phase 7, `docs/aws-migration-prompt.md` step 7
**Builds on:** [ADR 0014](0014-email-ses.md), which decided *that* SES replaces Resend. This
one records *how*, and the four decisions the plan did not answer.

## Context

Phase 1 verified `meridiansgrp.com` in SES, created the custom MAIL FROM subdomain
(`mail.meridiansgrp.com`), published DMARC, and opened the production-access request
(`infra/meridian/stacks/dns.py`, ADR 0017). Phase 7 is the other half: the application has
to actually send through it, and Resend has to stop.

`src/email_service.py` sends two messages — an invite with a one-time code, and a
"processing complete" notice with a period, a record count and an aggregate dollar total.
Neither carries PHI today (`docs/compliance/inventory-config-and-external-calls.md` §2.2),
and neither may start to.

## Decision

### 1. A fourth backend switch, `EMAIL_BACKEND ∈ {resend, ses, disabled}`

The same shape as `DATABASE_BACKEND`, `STORAGE_BACKEND` and `AUTH_BACKEND`, including the
fail-loud rule: in any named environment an **unset** switch raises at startup.

That last part is deliberate and it has a cost — Render must have `EMAIL_BACKEND` set in
the dashboard before this reaches `main`, exactly like the three Phase 0c switches
(`docs/migration-tracker.md`). The reason it is worth the cost: after the flip, an unset
switch would fall back to `resend`, and Meridian would quietly keep sending through a
vendor with **no BAA** (`docs/compliance/baa-register.md`) while every dashboard and
document said SES. A silent, invisible regression to the exact state Phase 7 exists to end
is worth a loud startup failure.

`disabled` is the third value because a laptop and a demo environment need a way to render
the templates without mailing anybody, and "no API key configured" was doing that job by
accident.

### 2. One email per event. There is no dual-send mode.

The obvious cutover trick — send through both providers for a week and compare — is
refused. An invite is not telemetry: two transports means two emails, with two different
copies of a one-time code, to a person who was invited once. The cutover is the switch and
the rollback is the switch (`docs/runbooks/email-cutover.md`). `EMAIL_BACKEND` has three
values and none of them is `both`; `tests/test_email_ses.py` asserts that.

### 3. The `From` is configuration, IAM conditions on it — and the flip waits for ECS

**Provisional decision (critic round 1, 2026-09-16): the flip happens only after Phase 9,
on ECS. No IAM user is created for Render.**

SES authenticates a request with an AWS signature, not an API key. On ECS that signature
comes from the task role, which rotates itself and is already written. On Render there is no
AWS identity at all, so flipping there means creating a long-lived IAM user with
`ses:SendEmail`, pasting its access key into a Render dashboard, and then remembering to
delete the user and the key at cutover. That is a static, non-rotating AWS credential living
outside AWS, in the dashboard of the platform the migration is leaving, bought for the few
weeks between Phase 7 and Phase 9 — and the failure it invites (a key left behind) is
exactly the class of thing Phase 10's decommission list is for. Resend keeps sending until
the application is on ECS.

The consequence to keep hold of: **Render's dashboards must still read
`EMAIL_BACKEND=resend`** before this branch reaches `main`, because an unset switch raises at
startup (§1). That row is in `docs/migration-tracker.md` and it does not go away.

The display name in front of the address (`EMAIL_FROM_DISPLAY_NAME`, default `Meridian`) is
one setting read by **both** transports, so the flip does not change what an inbox shows.
The `ses:FromAddress` condition compares the address only — RFC 5322's display phrase is not
part of the condition key — so the name needs no IAM change. The display name is governed by a
separate key, `ses:FromDisplayName`, which this grant deliberately does not condition on; both
keys are defined in the Service Authorization Reference for Amazon SES v2
(<https://docs.aws.amazon.com/service-authorization/latest/reference/list_amazonsimpleemailservicev2.html>,
"Condition keys for Amazon Simple Email Service v2").

`MERIDIAN_SES_FROM_EMAIL` (`no-reply@meridiansgrp.com`, written once in
`infra/meridian/stacks/dns.py` and imported by both `auth.py` and `compute.py`) — never a
literal in application code. The api task role's grant is:

```
ses:SendEmail, ses:SendRawEmail
  on  arn:…:identity/meridiansgrp.com
  and arn:…:configuration-set/meridian-shared-ses-default
  if  ses:FromAddress = no-reply@meridiansgrp.com
```

Two resources and a condition, because the interesting failure is not "the task cannot
send" — it is a compromised api task sending a perfectly DKIM-signed message from
`billing@meridiansgrp.com`. Naming the configuration set as a resource has a second effect:
a send that omits it, and therefore escapes bounce publishing and the TLS-required policy,
is denied by IAM rather than delivered quietly.

### 4. Event handling: four event types, one topic, and a suppression-list policy

The configuration set publishes `BOUNCE`, `COMPLAINT`, `REJECT` and — added here —
`RENDERING_FAILURE` to `meridian-shared-sns-email-events`. Rendering failure is the only
one of the four that produces no bounce and no delivery: the message never exists, so a
broken template looks exactly like an invite nobody has opened. `DELIVERY`, `OPEN` and
`CLICK` are deliberately excluded: they are marketing telemetry, and they would bury the
four events that mean something is wrong.

Suppression is `BOUNCES_AND_COMPLAINTS` at the configuration set, with a written policy in
`dns.py` and the runbook: the list is empty before the flip, an entry comes off only after
the address is confirmed with its owner by another channel, and a suppressed recipient is a
*silent* non-delivery to the application — which is why the SNS topic, not an application
log, is where non-delivery is noticed.

**Retries are botocore's**, configured once (`standard` mode, five attempts), never a loop.
A loop cannot tell a throttle from a rejected address, so it would re-send a message SES
had already accepted — which is rule 2 broken by accident.

**`ListManagementOptions` is not used.** It is SES's subscribe/unsubscribe feature for
marketing lists. Every message here is transactional, and a person who has been invited to
an organization cannot unsubscribe from being invited.

### 5. Nothing about the templates changes

Both transports inherit the same two template methods; `tests/test_email_ses.py` renders
each one through both and compares the HTML byte for byte. The flip changes the envelope,
never the letter.

### 6. What Resend keeps until the flip

Everything. `EMAIL_BACKEND` defaults to `resend`, `render.yaml` sets it to `resend`, the
`resend` dependency stays in `requirements.txt`, and the API key is not deleted. The
removal — dependency, env vars, key, account — is the *end* of the phase, after the flip is
accepted, and it is a row in `docs/migration-tracker.md` with Andres's name on the account
closure.

## Alternatives considered

**`ses` v1 rather than `sesv2`.** v1's `SendEmail` has no message tags and no per-message
configuration-set field of the same shape, and AWS's own guidance is that v2 is where new
features land (the suppression-list and account-level APIs are v2-only). Nothing in v1 is
needed. Chosen: `sesv2`.

**Sending raw MIME (`SendRawEmail`) so attachments are possible.** Nothing attaches
anything today, and a JE workbook on an email is a PHI decision, not a transport one. The
IAM grant includes the action so that the day it is wanted it is a code change and not an
IAM change, but the code sends `Simple` content only.

**A per-environment configuration set.** Rejected: there is one domain identity and one
sending reputation for the whole account, and splitting the event stream in two would mean
two topics and two subscriptions for one mailbox. The environment is carried as a **message
tag** (`env`) instead, which is what the CloudWatch metrics dimension on.

**Encrypting the email-events SNS topic with a customer-managed key.** Not done, and this
is a deliberate departure from the "everything on a CMK" default. The `dns` stack has no
dependency on `foundation` (where the shared CMK lives) and gaining one would reorder the
deploy; the payload is a bounce type and a recipient address, classified `internal`, the
same as the foundation stack's own alerts topic; and the email subscription that actually
delivers the notification is not protected by a topic CMK anyway. Revisit if a topic ever
carries anything beyond a delivery event.

## Consequences

- One environment variable is now the difference between two email providers, in both
  directions, which is what makes the cutover and the rollback the same two-minute action.
- A deployment that forgets `EMAIL_BACKEND` does not start. That is a real operational
  edge, listed in the tracker with the Render dashboard step.
- The application can no longer hand a botocore error message back to a caller: the error
  string quotes the recipient, so the response carries the SES error **code** instead.
  Anyone diagnosing a delivery problem reads the SNS events, not the API response.
- `src/email_service.py` is still untyped, pre-migration code. Typing it (and adding it to
  `[tool.mypy] files`) is a tracker row, not a change smuggled into the commit that also
  changed what it sends.

## Trigger to revisit

A second `From` address is genuinely needed (a reply-to mailbox people answer, a billing
sender), or a message has to carry an attachment. Either one reopens the IAM condition and
the `Simple`-content decision together.
