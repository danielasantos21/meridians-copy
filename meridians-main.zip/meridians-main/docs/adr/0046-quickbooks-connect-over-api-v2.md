# ADR 0046 — Connecting QuickBooks over `/api/v2/qbo/connection`

**Date:** 2026-09-25 (written; decided and built 2026-09-24)
**Status:** Accepted (provisional — Andres to confirm, see local-first plan D18). Built and merged;
the production redirect URI and `QBO_*` settings are still Andres's (tracker T:160).
**Source:** `docs/reports/local-first-plan-2026-09-24.md` progress log (D18 entries);
`docs/migration-tracker.md` T:158, T:160; `docs/reports/phase-11-plan.md` §2.6.1;
`src/api/v2/qbo_connection.py`, `api/routers/qbo.py`, `src/qbo_client.py`,
`web/src/app/settings/quickbooks-section.tsx`, Alembic `0021_qbo_connection_audit`
**Related:** ADR 0034 (retiring Flask), ADR 0044 (the tokens are sealed), ADR 0021 (sessions, CSRF)

## Context

The only writer of `public.qbo_connection` — the tokens the qb-usa push uses — was the Flask
`/qbo/connect` + `/qbo/callback` pair. It sat outside every proxied prefix, so it was unreachable on
meridiansgrp.com; no screen linked to it; its `state` lived in the Flask session cookie; and its
registered redirect URI was a laptop's (`http://localhost:5050/qbo/callback`). G2 could not simply
translate it: it needed a decision on where QuickBooks gets connected (tracker T:158):
(a) port it to FastAPI at `/qbo/*` and open that prefix at the edge, (b) put it under `/api/v2` with
a React button, or (c) keep it a laptop step through a script.

## Alternatives considered

The progress log records the choice of (b), not a written argument against the others. What each
would have needed, from T:158:

**(a) `/qbo/*` on FastAPI.** The smallest code diff, but `/qbo` added to `PROXIED_PREFIXES` and the
ALB for two routes, `https://<host>/qbo/callback` registered at Intuit, and still no screen linking
to it. Reversing (b) into (a) moves the router; the service module stays.

**(c) A laptop script that writes the table.** No UI at all; but every connect — and every
re-connect after Intuit's 100-day refresh token lapses — needs someone at a terminal holding
production database access.

## Decision (option (b), called "option 2" in the progress log)

1. **A React card on `/settings`** (`quickbooks-section.tsx`) over three admin-only JSON endpoints:
   `GET`/`DELETE /api/v2/qbo/connection` and `POST /api/v2/qbo/connection/connect`
   (`api/routers/qbo.py` `qbo_connection_status` / `qbo_connection_connect` / `qbo_connection_disconnect`; CSRF on the writes). Admin, as `require_role('admin')` was.
2. **The callback is `GET /api/v2/qbo/connection/callback`** — under `/api/`, which the edge already
   proxies (`DEFAULT_CALLBACK_PATH`, `src/qbo_client.py`). `QBO_CALLBACK_PATH` may move it, but
   only under `/api/` (`qbo_client.callback_path`). It always answers a 302 to `/settings?qbo=<outcome>`, never JSON.
3. **Redirect URI = `QBO_REDIRECT_URI`, else `SITE_URL` + the callback path** (`qbo_client.redirect_uri`); never
   hard-coded. `qbo_client.config_problems()` lists a missing client id or secret, or a redirect
   URI whose path is not the served callback (the old `:5050/qbo/callback` value); `start` then
   answers `503 INTEGRATION_NOT_CONFIGURED` before anything is parked.
4. **The OAuth `state` is parked server-side, single-use, bound to org and user, 600 s.** `start`
   stashes `{kind: "qbo_connect", org_id, user_id}` in the store half-finished sign-ins use (revision
   0017's `auth_pending_challenge` on RDS), sealed, with `STATE_TTL_SECONDS = 600`
   (`src/api/v2/qbo_connection.py`: `STATE_TTL_SECONDS`, `start`). The callback takes it in one step, so a replayed
   URL finds nothing (`_spend_state`), and refuses it unless the signed-in caller is the same user in the
   same org (`_bound_to`). No PKCE: Intuit's server-side flow authenticates the exchange with the
   client secret.
5. **Audited.** Every connect and disconnect writes `audit.qbo_connection_change` (revision 0021,
   append-only, ids and realm only, never a token) in the transaction that changes the connection,
   plus a `qbo_connection_change` log event on both backends.
6. **Flask `/qbo/*` deleted** in the same commit (a comment in `web_app.py` records it).

## Consequences

- **Amended by ADR 0050 (2026-09-29):** on AWS the callback is on the app host —
  `https://app.meridiansgrp.com/...` in production, `https://staging-app.meridiansgrp.com/...`
  in staging; the `www` URI below is Render's, kept only until the Phase 9 cutover.
- Andres must register `https://www.meridiansgrp.com/api/v2/qbo/connection/callback` and
  `http://localhost:3000/api/v2/qbo/connection/callback` at Intuit, set `QBO_CLIENT_ID`,
  `QBO_CLIENT_SECRET`, `QBO_ENVIRONMENT`, and change `.env.example`'s old redirect line (T:160).
- The environment now comes from `QBO_ENVIRONMENT`; the Flask callback always stored `sandbox`.
- On AWS the api task definition does not yet carry the `QBO_*` values (critic Stage 1 r1, M-10), so
  the card answers `503 INTEGRATION_NOT_CONFIGURED` there until they are added as secrets.

## Trigger to revisit

- Andres prefers (a) or (c) → the service module stays; only the route and screen move.
- A second QuickBooks-connected integration appears → generalize the parked-state kind.
