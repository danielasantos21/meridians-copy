# ADR 0031 — Worker state: every key classified, JSON only, stored by class

**Date:** 2026-09-25 (written; built 2026-09-24, tasks C2, C3, C5)
**Status:** Accepted and built, **on RDS only** (`DATABASE_BACKEND=postgres`); the Supabase path on
Render keeps today's behaviour until cutover.
**Source:** `docs/reports/phase-11-plan.md` §3.6 (Codex PS-2, PS-15), §7.1, tasks C2, C3, C5;
`src/process_runs.py`, `src/run_store.py`, `src/process_state.py`, `src/phi.py`
**Related:** ADR 0012 (PHI quarantine), ADR 0027 (the manifest declares the keys), ADR 0030 (leases
fence the writes)
**Numbering note:** reserved 2026-09-24 in the Phase 11 plan §8; written late (critic Stage 1 r1, L-14).

## Context

When the api and the worker are separate containers, nothing a later step needs may live in one
program's memory. But run state today mixes public facts, payroll figures (names, pay) and, for
qb-usa, group-health-plan data (subscriber ids, premiums). Moving it all into `process_runs.run_state`
unexamined would put PHI into a plain `public` column. Pickling it would put code into storage that
another container later runs.

## Alternatives considered

**Persist every key as JSON in `run_state`.** Simplest. Rejected: PHI would sit outside the `phi`
schema and bucket, bypassing `src/phi.py` and its audit rows (ADR 0012).

**Pickle the in-memory objects (qb-usa's `RunResult`).** Zero rewrite of the wizard. Rejected: a
pickle is executable, and `RunResult` carries DOB, member ids and net pay that were deliberately
never stored.

**Parquet for large frames.** Compact. Deferred: needs `pyarrow`, which Andres has not approved; the
trigger is below.

## Decision

1. **Four classes, declared per key** in `manifest.state_fields` (`StateClass`,
   `src/processes/manifest.py:33`): `public`, `personnel`, `phi`, `never`.
2. **An undeclared key raises.** `check_run_state_keys` (`src/process_runs.py:135`) refuses an
   undeclared key, a `phi` key and a platform key (`state_objects`, `run_overrides`,
   `superseded_by_run_id`) with `RunStateRefused` before anything is written; `never` keys are
   neither persisted nor cached (`:1187`). Gated by `run_state_classes_enforced()` (`:126`).
3. **Where each class lives.** `public` and small `personnel` values → `run_state`. Larger
   `personnel` and all `phi` objects → `src/process_state.py`: JSON under
   `{org}/{run}/state/{name}.json` in the **`phi` bucket** (`bucket_for("state")` fails closed to
   `phi`, `:98`), capped at 50 MiB (`:92`). `never` → recomputed from the uploads.
4. **Pinned to a version.** The writer records `{key, version_id, sha256, class, job_id}` in
   `run_state.state_objects` through one UPDATE fenced on the lease (revision 0011); the reader
   loads exactly that version and checks the hash. A version nobody recorded is never read.
5. **PHI reads and writes are audited.** A `phi`-class object goes through `phi.open_state`
   (`src/phi.py:550`), which writes the opened/closed `audit.phi_access` pair. `personnel` objects
   land in the `phi` bucket but are not PHI accesses.
6. **JSON only, never pickle**; a non-JSON value is refused by its type name, never its value.
7. **Prefix separation (PS-15):** the api writes only `*/uploads/*`, the worker only `*/state/*` and
   output folders (IAM on AWS).

## Consequences

- qb-usa's `RunResult`, `prompts` and `alerts` are `never` (`src/processes/qb_usa_payroll/manifest.py:164-166`);
  the `parse` job leaves `review_snapshot`/`preview_snapshot` (`personnel`) and `gate_offenders`
  (`phi`, `:173`) instead.
- Classes were chosen fail-closed: exception text (`error`) and pay aggregates are `personnel`.
- On Supabase, `volatile=` keys still go to the process-local `_volatile` cache
  (`src/run_store.py:30-47`); it disappears with the Supabase path.

## Trigger to revisit

- Andres approves `pyarrow` **and** a state object approaches 50 MB → parquet for frames.
- A compliance reviewer classifies payroll data differently → move `personnel` rows accordingly.
