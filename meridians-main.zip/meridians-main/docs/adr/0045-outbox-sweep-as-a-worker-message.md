# ADR 0045 — The webhook outbox sweep is a message the worker handles

**Date:** 2026-09-25 (written; decided and built 2026-09-24)
**Status:** Accepted (provisional — Andres to confirm, see local-first plan D17). Built locally
behind `worker_enabled` and `enableApiPlatform`; not deployed.
**Amends:** ADR 0038 decision 1 ("a five-minute sweep republishes rows still unpublished") — the
sweep's schedule and code are unchanged; where it runs is.
**Source:** `docs/reports/local-first-plan-2026-09-24.md` progress log (D17 entries of 2026-09-24);
`docs/migration-tracker.md` T:177, T:189; `workers/outbox_sweep.py`, `workers/contract.py`,
`workers/run_job.py`, `infra/meridian/stacks/worker.py`, `infra/meridian/stacks/api.py`
**Related:** ADR 0028 (the worker and its queue), ADR 0029 (the `v:1` message), ADR 0038 (webhooks)

## Context

ADR 0038's outbox publishes each webhook event after its transaction commits; if that publish fails
the `api_events` row stays unpublished, and a sweep every five minutes re-publishes it (revision
0019's `app.unpublished_api_events`). T19 first built that sweep as its own EventBridge Scheduler →
ECS `RunTask` of the api task definition, every 5 minutes: ~8 640 one-minute tasks a month at the
api's 1 vCPU / 2 GB, **≈ $6/month per environment** (tracker T:177). Meanwhile the worker (ADR 0028)
is always on and already receives a scheduled tick: the 15-minute `sweep`.

## Alternatives considered

**A separate scheduled task (the T19 shape).** Its strongest case: it runs even when the worker is
off, and it is isolated from job traffic. Rejected for now: ≈ $6/env/month for a pass that usually
finds nothing, plus its own IAM role (`meridian-<env>-iam-outbox-sweep`). Reversing costs one
schedule and one role in `ApiStack` (the code is the same CLI). This is the one alternative the
record names: the progress log queued the move "unless Andres prefers the separate task".

## Decision

1. **A tick kind on the existing queue.** `OutboxSweepMessage` (`workers/contract.py`) is
   `{"v": 1, "job_id": <uuid>, "kind": "outbox_sweep"}` — no run, no org, no actor — added inside
   `v:1` exactly as `sweep` was.
2. **The worker handles it** (`workers/run_job.run_job`'s `outbox_sweep` branch → `run_outbox_sweep_job`,
   `workers/outbox_sweep.py`): one pass of `src.webhooks.outbox.sweep`, the same code as the CLI
   `python -m workers.outbox_sweep`. A database error leaves the tick for redelivery; a failed
   per-org publish still deletes the tick (the next one finds the rows). Off RDS the tick is
   dead-lettered as `outbox_sweep_not_enabled` (`workers/outbox_sweep.NOT_ENABLED`).
3. **Scheduled from the worker's group** with the TTL sweep's role: `rate(5 minutes)`, a fixed
   `job_id`, two retries within four minutes so a retry never overlaps the next tick
   (`infra/meridian/stacks/worker.py`: `OUTBOX_SWEEP_SCHEDULE` / `OUTBOX_SWEEP_JOB_ID` / `OUTBOX_SWEEP_MAX_EVENT_AGE`, `WorkerStack._outbox_sweep_schedule`). It exists only when **both**
   `worker_enabled` and `enableApiPlatform` are on (the `api_platform_enabled(compute)` test in `WorkerStack.__init__`).
4. **`ApiStack` no longer runs it.** With the api platform on and the worker off, synth warns
   `meridian:outbox-sweep-needs-worker` and nothing is scheduled (`ApiStack._outbox_sweep_needs_the_worker`, `infra/meridian/stacks/api.py`).

## Consequences

- ≈ $0 extra per environment (it rides the always-on worker), instead of ≈ $6.
- **Rollback past D17:** an older image has no `outbox_sweep` kind and dead-letters every tick as
  `malformed_message`. Disable `meridian-<env>-schedule-outbox-sweep` first and run the CLI by hand
  (`docs/runbooks/alerts.md`, Job DLQ triage).
- A dropped tick trips the group-wide `sweep-dropped` alarm, shared with the TTL sweep.
- Webhooks on without the worker means no automatic re-publish; run the CLI by hand.

## Trigger to revisit

- Andres prefers the separate task (≈ $6/env/month) → restore the `ApiStack` schedule and role.
- The worker is scaled to zero or removed while webhooks stay on → the sweep needs its own home.
