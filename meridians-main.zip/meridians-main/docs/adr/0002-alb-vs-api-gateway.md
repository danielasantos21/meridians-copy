# ADR 0002 — ALB for the browser and internal API; API Gateway only for PHI-scoped partners

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §2.5; prompt "AWS-ONLY" service map ("settle this in a Phase 0 ADR")

## Context

Two AWS front doors could serve Meridian's HTTP traffic. An **Application Load Balancer
(ALB)** is a long-lived load balancer in front of our ECS Fargate containers. **API
Gateway** is a managed API front end that adds per-route configuration, usage plans,
request throttling and — the one thing an ALB cannot do — **mTLS** (mutual TLS: the
client must present its own certificate, not just the server).

Today all traffic is one browser application plus `/api/v1` and `/api/v2` called by that
same application. There are no external machine clients and no partner integrations. A
`/api/v3` platform with machine clients is planned for Phase 12, and PHI-scoped partner
access is a possibility, not a commitment.

Running both front doors from the start means two sets of routes, two sets of logs, two
places a security control can be missed, and a second monthly bill for traffic we do not
have.

## Decision

**All traffic goes through CloudFront → WAF → ALB → ECS.** The ALB serves the browser
application, the internal API, and our own scripts. The ALB security group admits only
CloudFront's managed prefix list and an origin-verify header rejects direct hits
(see ADR 0015).

**A separate API Gateway custom domain with an mTLS truststore is added only when a real
partner holding PHI scopes exists** — a named organization with a signed partner BAA.
At that point the partner gets its own hostname and its own mTLS-protected surface; the
browser and internal traffic stay on the ALB.

## Consequences

- One front door to secure, log, alarm on and reason about until a partner appears.
- No API Gateway cost and no duplicated route configuration.
- Per-route throttling and usage plans are not available; rate limiting stays in the
  application (and in WAF at the edge), which is adequate at `desiredCount: 1`.
- When the partner surface is added it is additive — a new stack in the CDK app, not a
  migration of existing routes. Partner onboarding gets its own runbook
  (`docs/runbooks/onboard-partner.md`).

## Trigger to revisit

A named external organization with a signed BAA needs PHI-scoped API access; or an
internal client genuinely needs per-consumer usage plans and throttling that the
application cannot provide.
