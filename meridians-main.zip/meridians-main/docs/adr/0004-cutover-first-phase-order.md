# ADR 0004 — Cutover first, platform second

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §3, decision D-16. The prompt (`docs/aws-migration-prompt.md`, PHASES) already carries this order
as of v3.1 (2026-09-15).

## Context

The first draft of the migration prompt ordered the work with the process framework (Phase 7)
and the `/api/v3` API platform (Phase 8) **before** cutover (Phase 11). Those two phases
are the reason to be on AWS rather than anywhere else — and they are also the two least
certain estimates in the plan, together roughly 55-84 engineering days.

Building them first means every one of those days is spent while **two database backends
must both be kept correct** (Supabase in production, RDS in staging) and while the Render
and Supabase bills keep running. It also pushes the first AWS-booked journal entry out to
roughly 16-24 months at three focused days a week.

Nothing in either platform phase is actually required to leave Render and Supabase: the
api container can run today's in-process background threads at `desiredCount: 1` exactly
as Render does now, and `/api/v2` already serves the React app.

## Decision

**Cut over first.** Phases 0-10 get Meridian off Render and Supabase by the shortest safe
path; the process framework (Phase 11) and the API platform (Phase 12) are built
afterwards, on AWS, with no second backend to keep alive.

Phase 5 is also split so each critic loop stays under roughly 50 days of work:
**5a** = data-layer port, FastAPI beside Flask, containers, CI/CD to staging;
**5b** = the remaining Jinja screens rebuilt in React.

Resulting order: 0 inventory/sweep/ADRs/harden-in-place · 1 AWS foundation · 2 network
and IaC · 3 data tier (staging) · 4 auth + Flip 1 · 5a data port + FastAPI + containers ·
5b Jinja → React · 6 observability and audit · 7 SES · 8 security hardening and
compliance evidence · 9 cutover (Flip 2) · 10 decommission Supabase and Render ·
11 process framework · 12 API platform and final cleanup.

## Alternatives considered

**Platform-first (the original prompt order): build the process framework and `/api/v3`
before cutover.** Its real argument is not sequencing vanity — it is that porting Flask
routes twice is waste. Build the framework first and the Jinja wizards are rewritten once,
straight into `src/processes/` and the worker, instead of being lifted to FastAPI in
Phase 5a and moved again in Phase 11. That duplicated work is roughly 8-12 days, and this
decision deliberately pays it.

It was rejected because of what it costs meanwhile: 55-84 engineering days spent while
**two database backends must both be kept correct** — production on Supabase, staging on
RDS — with every schema change applied twice and every divergence a silent wrong number in
a journal entry. It also keeps the Render and Supabase bills running ~6 months longer and
pushes the first AWS-booked entry to 16-24 months.

**Reversal cost: low, and it falls with time.** Nothing in Phases 0-10 forecloses the
framework: the process registry that Phase 11 replaces already half-exists
(`src/process_runs.PROCESSES`, `src/api/v2/state_machine.py`) and is untouched by cutover.
Switching to platform-first before Phase 5a costs only the re-planning. Switching after
Phase 5a means the FastAPI `/api/v2` port is already paid for and cannot be un-paid — but
it is not wasted either, since Phase 11 builds on it. There is no point at which reversing
this order destroys work; it only changes when the bills stop.

**Concrete trigger to reverse:** a signed partner or customer commitment that requires
`/api/v3` (machine clients, scopes, webhooks) on a date earlier than the projected Phase 12
— or a cutover blocker in Phases 5-9 that stalls for more than one full close cycle, at
which point the platform work is the only thing that can proceed and should.

## Consequences

- Cutover lands at roughly 127-180 engineering days (10-14 months at 3 days/week) instead
  of 190-280 (16-24 months).
- The dual-maintenance window shrinks by roughly 55-84 days of work, and with it the
  chance of the two backends silently diverging.
- The Render and Supabase bills stop ~6 months earlier.
- **`desiredCount: 1` persists until Phase 11**, because the five in-memory wizards in
  `web_app.py` are not yet serialized. That is the same shape Render runs today (one
  worker), so cutover-first does not regress it — but it costs 3-6 minutes of hard
  downtime per api deploy until Phase 11 lifts it.
- Phase 10 (decommission) and Phase 11 (process framework) run in parallel: Phase 10 is
  gated on two close cycles, and Phase 11 does not wait for it.
- `docs/aws-migration-prompt.md`'s PHASES section was rewritten to this order in v3.1.

## Trigger to revisit

A hard external deadline for the API platform or a partner integration that cannot wait
for cutover; or a cutover blocker that stalls Phases 5-9 long enough that platform work
would otherwise sit idle.
