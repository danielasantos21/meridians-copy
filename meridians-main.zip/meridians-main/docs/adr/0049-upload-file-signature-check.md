# ADR 0049 — Uploads are checked by their bytes, not their name (`FILE_TYPE_INVALID`)

**Date:** 2026-09-25 (written; built 2026-09-24, Phase 11 D4 wave)
**Status:** Accepted and built, on **both** backends.
**Source:** `docs/reports/local-first-plan-2026-09-24.md` progress log (B1-B3 entry: "queued: a
magic-byte file signature check … the error becomes `FILE_TYPE_INVALID`"; D4 merge entry: "tolerant
across Excel containers"); critic Stage 1 r1, L-3; `src/file_signature.py`, `api/uploads.py`,
`src/storage.py`, `src/processes/manifest.py`
**Related:** ADR 0027 (the manifest's input validators), api-v2-contract §4.2 (error codes)

## Context

An upload's type was decided by its extension and the browser's `Content-Type`, which is picked from
the file NAME. Task A1 recorded that "there is no separate magic-byte check (none exists in the
repo)": the only gate on content was whichever parser opened the file. A web page, a PDF or a program
renamed `.xlsx` reached pandas, and a Word document (also a ZIP) looked like a workbook until parsed.

## Alternatives considered

**Strict: each extension must hold its own container** (`.xlsx` = OOXML ZIP, `.xls` = OLE2). Rejected
2026-09-24: pandas opens a workbook by its content, so a newer workbook saved as `.xls` (or an old one
renamed `.xlsx`) has always been read, and billing systems produce both. Strictness would refuse
files that work today.

**Leave it to the parsers** (the state before this ADR). Replaced because a parser's failure does not
say "wrong kind of file", and the contract already had a code for that (§4.2 `FILE_TYPE_INVALID`).

## Decision

1. **`src/file_signature.check(filename, data)`** raises `FileSignatureRejected(reason)` when the
   bytes are not what the extension claims (`src/file_signature.check`). Other extensions pass;
   the allow-list stays `storage.content_type_for`'s job.
2. **Excel, tolerant across containers** (`_check_excel`, `_check_ooxml`): any of `.xlsx`/`.xlsm`/`.xls` passes as an
   OLE2 document (`D0 CF 11 E0 A1 B1 1A E1`) or as an OOXML ZIP (`PK\x03\x04`) holding
   `[Content_Types].xml` and a SpreadsheetML workbook part. The ZIP is read by its central directory;
   the one member ever decompressed is `[Content_Types].xml`, only if it declares ≤ 1 MiB.
3. **CSV** (`_check_text`): no NUL byte (`csv_binary`), and decodes as UTF-8 (BOM allowed) or cp1252
   (`csv_not_text`).
4. **Reasons are fixed codes** (`not_excel`, `ooxml_corrupt`, `ooxml_parts_missing`, `csv_binary`,
   `csv_not_text`; `file_signature.REASONS`), never text from the file.
5. **Three places, the same check:** the upload ingress every ported route shares
   (`api/uploads.check_workbook_parts`, answering `415 FILE_TYPE_INVALID` with
   `details.reason`); `src.storage.vet_upload`, the one gate before storage; and the
   manifests' input validators (`src/processes/manifest.refuse_wrong_signature`), which the
   worker runs on the file it materialized. The zip-bomb bound (`src/storage.check_workbook_container`) runs first everywhere; at the ingress it answers `422 FILE_UNREADABLE`.

## Consequences

- **The CSV text test is weak (critic L-3), a side effect of accepting cp1252.** cp1252 assigns a character to every byte
  except five (`0x81 0x8D 0x8F 0x90 0x9D`), so almost any NUL-free file decodes. In practice a
  binary file is caught by `csv_binary` (the NUL test), and `csv_not_text` fires only for a file that
  is not UTF-8 **and** contains one of those five bytes. The check stops obvious binaries named
  `.csv`; each process's own input validator (for qb-usa, `identify_csv`) is still what decides a
  file is a valid export. Verified: `a,b\n\x81…` → `csv_not_text`; `a,b\n\xe9` (Latin-1 é) passes.
- qb-usa's converter still picks its reader by extension and answers its own `FILE_TYPE_INVALID`
  for a mismatch.
- `api/uploads.check_workbook_parts`'s docstring still describes the strict per-extension rule; the code
  calls the tolerant check.

## Trigger to revisit

- A non-UTF-8, non-cp1252 export (for example UTF-16) must be accepted → it contains NULs and is
  refused today; add its BOM as an allowed case.
