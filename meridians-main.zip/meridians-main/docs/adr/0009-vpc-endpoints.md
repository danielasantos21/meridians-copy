# ADR 0009 — VPC endpoints: free gateway endpoints only, no interface endpoints

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §2.4, decision D-19

## Context

Containers in private subnets reach AWS services either over the public internet through a
**NAT gateway** (a managed box that lets private subnets make outbound connections), or
privately through a **VPC endpoint**.

There are two kinds of endpoint:

- **Gateway endpoints** (S3 and DynamoDB only) — **free**.
- **Interface endpoints** (Secrets Manager, KMS, CloudWatch Logs, ECR, and so on) —
  **$7.30/month per availability zone** plus $0.01/GB.

A NAT gateway costs $32.85/month in hours plus $0.045/GB. The usual argument for interface
endpoints is that enough of them let you delete the NAT.

**That argument does not apply here.** The NAT cannot be removed: Intuit QuickBooks,
Google and Microsoft sign-in, and the User Migration Lambda's Supabase target have no VPC
endpoint. The NAT stays regardless.

So an interface endpoint can only ever *add* cost. The data-transfer saving is mostly ECR
image pulls — a few GB a month, **under $1**.

## Decision

**Gateway endpoints for S3 and DynamoDB (free) in both environments. No interface
endpoints.**

## Consequences

- Saves roughly $22/month per environment against the "endpoints everywhere" alternative,
  with no functional loss.
- Traffic to Secrets Manager, KMS, CloudWatch Logs and ECR leaves the VPC through the NAT
  to AWS public endpoints. It is TLS-encrypted and stays on the AWS network, but it is not
  a *private path* in the sense a control matrix may want to claim.
- S3 traffic — including every PHI object — does take the free private gateway path.

## Trigger to revisit

An auditor asks for private-path assurance. The answer then is to add Secrets Manager,
KMS and CloudWatch Logs interface endpoints in one availability zone in production
(~$22/month) and record it as a **control**, not as a cost decision.
