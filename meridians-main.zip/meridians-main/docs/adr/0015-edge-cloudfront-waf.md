# ADR 0015 — Edge: CloudFront + WAF + Shield Standard in front of the ALB

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §2.4, §2.5, decision D-12

## Context

Today Render terminates TLS and serves traffic directly. On AWS the application sits
behind an ALB, and the question is whether anything goes in front of it.

A public ALB is directly reachable, has no managed rule sets, no bot or IP-reputation
filtering, and no edge caching. For a system holding PHI on a two-person team with no SOC,
managed protection at the edge is worth more than it costs.

**Shield Advanced** exists and is explicitly out of scope: **$3,000/month**.

There is also a specific known bug here. Commit `71decf2` fixed rate limiting that keyed on
the wrong client IP. Putting CloudFront in front of the ALB means **two** proxies between
the browser and the application, and `ProxyFix(x_for=1)` would re-create exactly that bug.

## Decision

**CloudFront → AWS WAF → ALB → ECS, with Shield Standard (free, automatic with
CloudFront).**

- **WAF** managed rule sets: core rule set, IP reputation, and rate-based rules. ACM
  certificate in `us-east-1` (CloudFront's requirement), TLS 1.2+.
- **The ALB security group admits only CloudFront's managed prefix list**, and an
  **origin-verify header** rule rejects anything that reaches the ALB by another route.
  Both, not either.
- **`ProxyFix(x_for=2)` in Flask and FastAPI** — two proxies, so two hops of
  `X-Forwarded-For` are trusted. This is recorded as correctness, not tuning.
- HTTP:80 redirects 301 to HTTPS; ALB access logs on.
- Both `www.meridiansgrp.com` and the apex resolve through CloudFront. Most external DNS
  hosts cannot alias an apex to a CloudFront distribution, so a Route 53 zone is the likely
  answer — a Phase 0 lead-time item with a TTL tail.
- **Never Shield Advanced without asking.**

## Consequences

- Managed DDoS, bot and IP-reputation protection with no operational work.
- Two proxies in the request path — so `x_for=2` is load-bearing. Getting it wrong
  silently breaks rate limiting and every IP recorded in an audit row.
- Direct-to-ALB access is closed by two independent mechanisms, so one being misconfigured
  is not an exposure.
- The apex must be aliasable, which likely forces a Route 53 migration for
  `meridiansgrp.com` before cutover. **Deleting Render with a stale apex would take the
  bare domain dark** — that precondition is checked in Phase 10.
- WAF managed rules can produce false positives; they are tuned on staging before
  production.

## Trigger to revisit

A sustained attack that Shield Standard does not absorb (then price Shield Advanced
against the actual loss); or WAF false positives that cannot be tuned away without
weakening the rule set.
