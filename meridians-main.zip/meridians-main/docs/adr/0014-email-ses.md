# ADR 0014 — Email: Amazon SES replaces Resend

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §1, decisions D-11 and the AWS-only rule

## Context

Meridian sends two kinds of mail today: invitation emails through **Resend** (a third-party
email API) and authentication mail — password resets, confirmations — through **Supabase**.

Supabase is being shut down entirely, so its auth mail has to move regardless. That leaves
Resend as the only non-AWS provider in the hosting, database, auth, storage, logging or
email path — and the AWS-only rule says there is none after cutover.

Email is also a PHI-adjacent channel: a message body or a subject line can carry an
identifier by accident, and a third-party sender would need its own BAA and its own entry
in the data-flow diagram.

## Decision

**Amazon SES for all outbound email. Resend is removed in Phase 7.**

- The `meridiansgrp.com` domain is verified in SES (DKIM, SPF, DMARC) and **production
  access is requested in Phase 1** — leaving the SES sandbox needs AWS approval and has
  real lead time, long before Phase 7 needs it.
- **The existing HTML email templates are kept.** This is a transport change, not a
  redesign.
- Cognito's own mail (password reset codes, MFA) is sent through SES from the same
  verified domain.
- SES events go to EventBridge → SQS for webhook delivery with a dead-letter queue
  (Phase 12).

## Alternatives considered

**Keep Resend and bring it under a BAA.** This would have been the cheapest option by a
wide margin: the transport already works, the templates already render through it, and
Phase 7 would disappear entirely. It fails on two counts, one contractual and one
structural.

Contractually, **Resend offers no BAA on the plan Meridian is on.** A business associate
may not pass PHI — or anything PHI-adjacent — to a subcontractor without one
(45 CFR 164.308(b)(1)), and invite and run-notification mail is exactly the channel where an
identifier leaks by accident: a subject line, a filename, a bounce body quoting the original
message. Without a signed BAA the honest options are "never let an identifier near email"
(unenforceable) or "do not use Resend".

Structurally, it would leave **one non-AWS provider holding invite emails** after cutover —
the single exception to the AWS-only rule, with its own vendor entry in the data-flow
diagram, its own access review, its own breach-notification path, and its own row in the
control matrix, for one feature. The bookkeeping costs more than the migration.

**Reversal cost: low.** Both are HTTP APIs behind `src/email_service.py`; going back to
Resend is re-pointing one module and restoring two environment variables, roughly a day,
plus re-verifying deliverability. The irreversible part is not the code — it is that a
return to Resend requires a signed BAA first, which is a commercial negotiation with a lead
time nobody controls.

**Concrete trigger to reverse:** SES production access is refused outright, **or** SES
deliverability into Stella Mattina's Proofpoint/Microsoft 365 path stays unacceptable after
DKIM, SPF, DMARC and a custom MAIL FROM subdomain are all correct and warmed — **and**
Resend (or another provider) will sign a BAA. All three conditions, not one.

## Consequences

- No non-AWS provider in the email path, so no additional vendor BAA and no extra
  data-flow entry.
- Deliverability now depends on our own SES reputation rather than Resend's shared
  reputation. DKIM/SPF/DMARC must be correct, and bounce and complaint rates are ours to
  watch.
- **Sandbox exit is a lead-time dependency.** If it is left until Phase 7 it blocks the
  phase, which is why it starts in Phase 1.
- The Resend dependency, API key and env var are deleted in Phase 7 with a test proving
  nothing still calls it.

## Trigger to revisit

SES production access is refused, or deliverability to Stella Mattina's mail provider
proves unacceptable after DKIM/SPF/DMARC are correct.
