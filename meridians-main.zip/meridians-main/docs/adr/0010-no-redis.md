# ADR 0010 — No Redis / ElastiCache; Postgres advisory locks and an idempotency table

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §1 ("What we are explicitly NOT doing"), prompt TECH STACK

## Context

The tech stack allows **Redis (ElastiCache)** for caching, distributed locks and rate
limiting — explicitly as a cache and never as a source of truth — and says to add it only
if something actually needs it.

So: does anything need it?

- **Rate limiting.** There is exactly one api task (`desiredCount: 1`, see ADR 0004),
  so per-process counters are already global. AWS WAF also rate-limits at the edge.
- **Caching.** The token, org, permission, module and superadmin caches in `src/auth.py`
  are being **deleted**, not moved (ADR 0003) — against in-VPC RDS they are 1-2 ms lookups
  and the caches are a documented staleness bug.
- **Distributed locks.** PostgreSQL has advisory locks, which are exactly this.
- **Idempotency.** A table with a unique key does the job durably, which Redis does not.

Adding ElastiCache would mean a new service to secure, encrypt, patch, back up, include in
the control matrix, and pay for — for no current requirement.

## Decision

**No Redis, no ElastiCache.**

- Rate limiting stays per-task in the application, with WAF rate rules at the edge.
- Distributed locks use **PostgreSQL advisory locks**.
- Idempotency uses an **idempotency table** in Postgres.
- No application-level cache replaces the ones being deleted.

## Consequences

- One fewer managed service in the architecture, the bill, and the compliance evidence.
- Locks and idempotency are durable and transactional — they survive a task restart, which
  a Redis-backed lock would not by default.
- Rate-limit counters are per-task, which is correct only while there is one api task.
  That is guaranteed by the `desiredCount: 1` constraint until Phase 11.
- Every auth lookup is a database round trip. Measured at 1-2 ms in-VPC; if that stops
  being true it will show up in the Phase 6 observability work.

## Trigger to revisit

The api service scales past one task — which is Phase 11's job, when the five in-memory
wizards are serialized and `desiredCount` can rise. At that moment per-task rate-limit
counters stop being global and start being wrong by a factor of the task count, and this ADR
is reopened.

**What the replacement would be, named now so the reopening is a purchase and not a design
exercise:** **Amazon ElastiCache for Redis** — it is on the AWS HIPAA Eligible Services list,
so it may sit inside the PHI boundary, encrypted at rest with a customer-managed key and in
transit, in the private subnets, reachable only from the api and worker security groups. A
single-node `cache.t4g.micro` is roughly **$12/month**; that is the whole cost of reversing
this decision, plus the CDK stack and its control-matrix rows.

**What moves to it, and what does not:**

- **Moves: rate-limit counters.** The per-user and per-client limits in contract §9 must be
  counted once across all tasks, not once per task.
- **Moves: short-lived distributed locks** where a Postgres advisory lock would hold a
  connection open for the duration — a long-running export, for example. Advisory locks stay
  the default; Redis takes only the cases where connection-holding is the problem.
- **Does not move: idempotency.** The idempotency table stays in Postgres. It must be durable
  and transactional with the write it guards, and an ElastiCache node is neither.
- **Does not move: the auth caches.** They are deleted (ADR 0003) because they are a
  staleness bug, not because they were in the wrong store. Reinstating them in Redis would
  reinstate the bug.
