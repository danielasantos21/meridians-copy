# ADR 0034 — Retiring Flask

**Date:** 2026-09-25 (written)
**Status:** Proposed — **partly carried out.** G1 (dead payroll families) and G2 (the reachable Flask
routes: deleted or ported) are done; G3 is done; **G4 and G5 — the actual removal of Flask,
`web_app.py` and `templates/` — are not built** and follow I4.
**Source:** `docs/reports/phase-11-plan.md` §2.6.1, §5.3, §7.2, tasks G1-G6; `CLAUDE.md` "Front End"
**Related:** ADR 0023 (FastAPI beside Flask, the one-commit rule), ADR 0035 (the fate of
`/api/v1/health`), ADR 0046 (the QuickBooks connect port)
**Numbering note:** reserved 2026-09-24 in the Phase 11 plan §8. Written now so the number is not a
gap (critic Stage 1 r1, L-14); it records the plan and what has happened, not a new decision.

## Context

Since ADR 0023 the process is FastAPI with the Flask app mounted under it through `a2wsgi`
(`api/main.py:33`). `web_app.py` still hosts the Flask routes and background workers the React app
proxies into; `CLAUDE.md` says it may not be deleted until Phase 11 retires the last Flask path.
Phase 11's end state is "no Flask": `grep -ril flask src api workers` empty.

## Decision (the order, as planned and so far followed)

1. **Delete what nobody calls; port what someone does** — one route at a time, under ADR 0023's
   one-commit rule (a path leaves Flask in the same commit it lands in FastAPI).
2. **G1, done 2026-09-24:** the five dead payroll families (49 routes, their dicts, thread sites and
   templates), approved by Andres 2026-09-22.
3. **G2, done 2026-09-24:** 23 routes deleted — including `/api/v1`'s ten non-health routes (Andres,
   2026-09-22), `/api/mso/*`, `/api/process`, `/api/fiscal-calendar/import` — and
   `/auth/google|microsoft|callback` ported to `api/routers/oauth.py`. The evidence was a grep of
   every caller location, not 30 days of ALB logs (Andres's yes superseded that). `/qbo/*` followed
   under decision D18 (ADR 0046). 82 Flask rules remain, each tied to I2/I3/G4/G5.
4. **`/api/v1/health` stays** until ADR 0035's two-commit move (add v3 health everywhere first).
5. **G4 (not built):** take Flask out of `src/auth.py`, `run_store`, `api/v2/limits.py`,
   `errors.py`; decide multipart parsing (plan §7.2 item 5); remove the WSGI mount and `a2wsgi`.
6. **G5 (not built), last and in one commit:** move `templates/{invoice,agreement}` and
   `wearbly/receipt.html` to `src/pdf_templates/` with byte-identical HTML tests; delete
   `web_app.py` and the rest of `templates/`; update `CLAUDE.md`, `README.md` and
   `docs/architecture/repo-layout.md`. Andres confirms that delete at the time.

## Consequences

- Until G5, `web_app.py` is load-bearing and `CLAUDE.md`'s "never archive it" rule stands.
- The Render merge must carry G2's deletions with their evidence (critic Stage 1 r1, M-11).
- The invoice and agreement PDFs depend on templates under `templates/`; G5 must move them first
  or they break.

## Trigger to revisit

- I4 complete (every process on the worker, its Flask wizard deleted) → build G4, then G5.
- A caller of a deleted route turns up after merge → port that route, do not restore Flask.
