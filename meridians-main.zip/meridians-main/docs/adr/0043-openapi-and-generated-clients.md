# ADR 0043 — OpenAPI publication and generated clients

**Date:** 2026-09-24
**Status:** Accepted (Andres, 2026-09-22: yes to `openapi-python-client` as a dev-only generator,
and yes to ZAP in CI)
**Source:** `docs/reports/phase-12-plan.md` §3.10, R11, T14, T23; ADR 0023 (one contract in the
repository)
**Numbering note:** planned as "0035" in the Phase 12 plan; renumbered to 0043 (Phase 11 holds
0027-0034, and this range starts at 0035).

## Context

**OpenAPI** is a machine-readable description of every endpoint; tools read it to generate client
code so nobody hand-writes the calling code. Today `openapi/meridian-v2.json` is produced from a
hand-maintained `ROUTES` registry by `scripts/generate_openapi.py`, FastAPI's own `/openapi.json`
is disabled (`api/main.py:238-240`), and `scripts/check_api_drift.sh` fails the build when the
document and `web/src/lib/api/schema.d.ts` drift. The TypeScript tools (`openapi-typescript`,
`openapi-fetch`) are already installed in `web/package.json`. There is no Python client.

## Alternatives considered

**Serve `/api/v3/openapi.json` live.** The strongest case: partners always see the current
contract, and tools can point straight at it. Rejected: it publishes the full inventory of the
API, including admin routes, to anyone who finds the URL. Reversing is a one-line router change.
Trigger: a partner portal is wanted (R11).

**No-dependency Python generator in `scripts/`** (the plan's default if no answer). Avoids a new
tool but costs ~1 extra day and is ours to maintain. Superseded by Andres's answer.

**Keep the hand `ROUTES` registry for v3.** Rejected: v3's document is generated from the FastAPI
app itself, so the registry and the routes can no longer disagree.

## Decision

1. `openapi/meridian-v3.json` is generated offline from a v3-only FastAPI app
   (`scripts/generate_openapi.py --v3`), checked in, **not served live**; partners receive it at
   onboarding. `check_api_drift.sh` covers both documents until v2 retires; the `ROUTES` registry
   retires with v2.
2. **TypeScript:** `openapi-typescript` → `web/src/lib/api/v3/schema.d.ts`, `openapi-fetch` client —
   no new dependency; the webhook verifier uses Web Crypto.
3. **Python:** `openapi-python-client`, pinned, **dev-only**, generating
   `clients/python/meridian_client/` (a new top-level folder → `repo-layout.md`). The generated
   package needs `httpx` and `attrs` in the *consumer's* environment, not the server's. The webhook
   verifier uses stdlib `hmac`.
4. Both clients cache the 15-minute machine token until 60 seconds before expiry — the cost control
   for Cognito token requests (ADR 0037).
5. **ZAP** (OWASP's free web scanner): an authenticated baseline scan runs against staging during
   T23; target no HIGH findings, MEDIUMs to the tracker.

## Consequences

- One new dev-only Python dependency and one CI tool; no runtime dependency on the server.
- Every API change regenerates two documents (until v2 retires) and two clients; the drift gate
  makes forgetting one a build failure.

## Trigger to revisit

- A partner portal → serve the document behind authentication.
- `openapi-python-client` output needs heavy hand edits → switch to the in-repo generator.
