# ADR 0024 — Observability: what we alarm on, what we refuse to alarm on, and the log-format debt

**Date:** 2026-09-16 (critic round 1 applied the same day)
**Status:** Accepted
**Phase:** 6 (`docs/aws-migration-plan.md`, "Phase 6 — Observability and audit")
**Supersedes nothing. Closes:** ADR 0020 §7c (the stop-schedule DLQ's "durable fix").
**Constrained by:** ADR 0001 (one shared account, no account id in code), ADR 0008 / D-15
(staging is destroyed between phases), ADR 0020 (which stack owns what), ADR 0022
(`api` runs one task by design), `docs/compliance/phi-classification.md` §5 (400-day
retention means a name written once is a name retained for 400 days).

## 1. Context

Phase 6 comes **before** anything serves production traffic, because the prompt is
unambiguous about it: "never run a PHI system unmonitored". So this is not a phase about
dashboards. It is the phase that decides what we will be told, when, and by what.

The estate already had four alarms — all account-level, all in `foundation.py`, all about
somebody doing something in the console. It had no alarm about the application at all. It
also had, since the Phase 3 critic round, a per-environment SNS topic with no publisher and
no subscriber, kept alive specifically so that this phase would find a working topic rather
than have to build one (ADR 0020 §7c).

Three things made this harder than "add alarms":

1. **The application does not emit structured logs.** `api/main.py` and `web_app.py` call
   `logging.getLogger(__name__)` and nothing ever installs a formatter, so what reaches
   CloudWatch is uvicorn's plain text. Half of what Phase 6 owes — 5xx counts, pool
   timeouts, auth-failure spikes — is a log-derived metric, and a log-derived metric needs
   a field to match on.
2. **The account is shared.** GuardDuty, Security Hub and Config are account-scoped, and
   their findings are not "a staging finding" or "a production finding".
3. **Cost headroom is about $11/month** against a ~$250 ceiling
   (`docs/reports/phase-1-cost-estimate.md` §3). A Synthetics canary at five-minute
   intervals costs more than that headroom, per environment.

## 2. The alarm philosophy

Four rules, applied to every one of the **27 alarms in staging and 26 in production**
(28 and 27 with the canary switched on), because an alarm estate is only worth what its
worst alarm is worth. The counts differ by one because staging has the stop-DLQ age alarm
and production has the three account-scoped finding *rules*, which are rules and not
alarms. `CfnOutput AlarmCount` prints the number the deployed environment actually has, and
`infra/tests/test_observability.py` synthesizes both. One untrustworthy alarm teaches the reader to skim.

### 2a. Every alarm has `ok_actions`, not just `alarm_actions`

> **Reversed 2026-10-07 (Andres): alarms notify on ALARM only; no `ok_actions`.** Staging's
> database stops every night and starts on demand, and each start moved every RDS alarm from
> INSUFFICIENT_DATA to OK, which emailed once per alarm. The flood of "OK" mail was the
> trained-to-ignore failure this section was written against. The recovery is read on the
> dashboard or the alarm's console page. `infra/tests/test_observability.py` now fails any
> alarm that HAS `OKActions`. The original reasoning follows.

The recovery notification is the half that gets left out. Leaving it out means the only way
to learn the thing came back is to go and look — so after a few weeks nobody looks, and the
alarm has become a thing that is silenced rather than read. `infra/tests/test_observability.py`
fails any alarm missing either.

### 2b. `treat_missing_data` is chosen and argued, never defaulted

CDK's default is `missing`, which is sometimes right and is never *argued*. Three rules:

| Shape of metric | Value | Why |
|---|---|---|
| Published only when something happens — 5xx counts, WAF blocks, Lambda errors, log-filter counts | `NOT_BREACHING` | No data means nothing happened. |
| Published continuously while the thing is alive — `HealthyHostCount`, `RunningTaskCount` | `BREACHING` | Silence *is* the outage. An alarm that clears when the target group empties is an alarm that reports health during a total failure. |
| On a resource that is deliberately stopped some of the time — staging's RDS instance, D-15 | `MISSING` | Carries the last known state forward. `BREACHING` pages nightly for a cost control working as designed; `NOT_BREACHING` silently *clears* a real alarm the moment the instance becomes unreachable, which is the dangerous one. |

**The RDS alarms differ by environment, and that is a correction from the first build**,
which made all six `MISSING` everywhere. `MISSING` is right in staging, where the instance
is stopped nightly. It is wrong in production, where the instance is **never** stopped:
there, silence is not a cost control, it is the database being unreachable, and `MISSING`
would hold the last *healthy* state forward for ever and report green through a total
outage — which is the second row of this table, applied to the wrong environment. So: six
RDS alarms `MISSING` in staging and `BREACHING` in production, keyed on
`destroyed_between_phases`, and nothing else in the stack is `MISSING` at all.

### 2c. A rolling deploy must not page

An ECS rolling deployment with the circuit breaker (ADR 0022) briefly halves capacity and
can produce a 502. Every alarm's `evaluation_periods × period` window is therefore longer
than a rollout, and the spiky signals use `datapoints_to_alarm` below `evaluation_periods`.
Four alarms are deliberately immediate, because waiting is itself the fault: RDS free
storage (it does not recover on its own), a User Migration error (each one is a person who
was refused sign-in), a pool timeout, and a failed `audit.phi_access` write.

**`api-no-healthy-host` is 7 of 8 one-minute datapoints, and it is a correction.** At the
first build's 3 of 5 it would have paged on **every single api deploy**: `compute.py` pins
the api service to `min_healthy_percent=0` / `max_healthy_percent=100` (one task by design
until Phase 11, ADR 0022), so ECS stops the old task before it starts the new one and there
are **3-6 minutes of zero healthy hosts, by design, every time**. An alarm that fires on
every deploy is an alarm that is muted within a month, which is strictly worse than not
having it — and widening `evaluation_periods` alone does not fix it, because 3 of 5 fires
after three minutes however long the window is. `datapoints_to_alarm` is what had to move.
`web` runs at `min_healthy_percent=100`, never drops to zero during a rollout, and keeps the
fast 3 of 5. The asymmetry disappears in Phase 11, when `api` stops being one task.

The slowest alarm in the estate is `api-scaled-beyond-one` at **thirty minutes**, and that
is not laziness — see §3.

### 2d. The alarm name is the message

`meridian-<env>-alarm-<purpose>` is often the only identifier the reader gets at 3am, and
every alarm's description is the first line of its runbook entry. A test enforces both.

## 3. Thresholds, and the one that is not a capacity alarm

The numbers are in `infra/meridian/stacks/observability.py` as named constants with the
arithmetic in the comment; the two worth restating here are the ones a reader would
otherwise "fix".

**`HealthyHostCount > 1` on the api target group.** The plan's wording reads oddly until
you know that `API_DESIRED_COUNT` is 1 **by design** until Phase 11 (ADR 0022): two api
tasks can each pick up the same revenue run and book the same journal entry twice. So this
is a **data-integrity alarm wearing a capacity alarm's clothes**, and it is why the api
service is pinned at one task. It is also why it is the slowest alarm in the estate: a
rolling deploy legitimately shows two healthy tasks while the new one drains the old, so
half an hour of two tasks is what separates "somebody set `desiredCount` to 2" from "a
deploy is running". The `< 1` outage alarm on the same metric is a separate alarm; the two
are not redundant.

**RDS connections.** PostgreSQL on RDS defaults `max_connections` to
`LEAST({DBInstanceClassMemory/9531392}, 5000)` — 112 on `t4g.micro`, 225 on `t4g.small`.
The alarm is 80% of that, worked out per instance class rather than chosen, because a
threshold that is not a fraction of the real ceiling gives an alarm that is either
permanently quiet or permanently loud and both read as "monitored". A third instance class
must add a row to `MAX_CONNECTIONS`; the code raises rather than guessing.

## 4. The log-format contract, and why the filters are silent on purpose

This is the decision in this ADR most likely to be read as a mistake.

The metric filters on the api and web log groups match **JSON fields only**:
`{ $.http.status >= 500 }`, `{ $.exception.type = "PoolTimeout" }`,
`{ $.error.code = "AUTH_REQUIRED" }`. The application does not emit JSON, so **every one of
them matches zero records today**.

### Alternatives considered

1. **Free-text substring patterns, which would work today.** The only greppable token for a
   pool timeout in the current output is the class name inside a Python traceback, so the
   pattern would be a substring match against the log *text*. Rejected, and not narrowly: a
   filter pattern is stored in the filter's own definition and is readable by anyone with
   `logs:DescribeMetricFilters`, for as long as the filter exists. A substring pattern
   against free text will eventually match — and thereby advertise — a line that quoted a
   spreadsheet cell. The retention is 400 days. The estate already bans this at the
   application end (`scripts/lint_no_phi_logging.py`); banning it at one end and doing it at
   the other is not a control.
2. **Ship the JSON formatter in Phase 6 as part of this work.** Tempting, and rejected only
   on scope: the formatter is application code in `api/` and `web_app.py`, it interacts with
   uvicorn's own `--log-config`, and it needs the PHI lint run against it. It is a tracked
   item with an owner, not an omission.
3. **No filters at all until the formatter lands.** Rejected because it loses the thing that
   makes the debt visible: an absent filter is an absence nobody notices, where a filter
   that is there and flat is a question somebody eventually asks. **The original form of
   this argument leaned on `default_value=0`** — "the 5xx count is permanently zero" as a
   checkable falsehood on the dashboard — and that half of it did not survive the
   `Environment` dimension, which CloudWatch will not accept alongside a default value. See
   "`env` is a dimension, not decoration" below: the metrics are now *absent* rather than
   zero, and what carries the claim is the dashboard header, the alarm descriptions and the
   runbook, in words, with tests asserting each says so.

### The contract

One JSON object per line, from the api and web containers:

| Field | Meaning |
|---|---|
| `env` | `staging` or `production`. **The dimension every filter publishes on.** |
| `event` | A fixed, enumerated event name, including `artifact_download` (one per object handed to a caller). Never interpolated text. |
| `level` | `INFO`, `WARNING`, `ERROR`. |
| `request_id` | `req_<32 hex>`, minted by `api/main.py`'s middleware. |
| `http.method`, `http.path`, `http.status` | The route **as matched**, never the raw URL — a path parameter can be an id. |
| `error.code` | The envelope code from `src/api/v2/errors.py`. |
| `exception.type` | The bare class name of an unhandled exception. |
| `duration_ms` | Integer. |

### `env` is a dimension, not decoration — and it costs the flat zero

`Meridian/App` is one namespace in one account, and both environments write into it
(ADR 0001). Without a dimension staging's 5xx count and production's are **literally the
same metric**: a staging load test raises the production alarm, and a production incident
is averaged away by staging's zeroes. So every filter carries
`dimensions={"Environment": "$.env"}` and every alarm and dashboard metric that reads one
pins `Environment=<this env>`. That is the critic's P6-02 and it was a real defect, not a
polish item — the alarms would have been wrong from the first day both environments ran.

It has a consequence worth stating, because it walks back a decision made three paragraphs
above. **CloudWatch Logs will not accept `defaultValue` on a metric transformation that has
dimensions** — a default would have to invent a dimension value for a record that did not
match — so the `default_value=0` that made alternative 3's argument work is gone. These
metrics now have *no datapoints* until the formatter lands, rather than a flat zero. The
argument survives in weakened form: the filters still exist, the dashboard header still
says in words that an empty graph is not evidence, the alarm descriptions still carry
"NOTE: silent until the app emits JSON logs", and every alarm on them is `NOT_BREACHING` so
absence reads as OK rather than as a permanent INSUFFICIENT_DATA. Given the choice between
a visibly-false zero and a correct dimension, the dimension wins: a wrong number is worse
than a missing one.

### `artifact_download`, and the control-matrix row that was not true

CC6.7 claimed an unusual-export-volume alarm was "built but silent". It was not built at
all. It is now: a field filter on `{ $.event = "artifact_download" }` over the api log
group, dimensioned like the rest, with an alarm at **100 downloads in each of three
consecutive five-minute windows** — roughly three hundred files in a quarter of an hour. It
is deliberately a *sustained* threshold rather than a spike: a period close pulls a burst
and stops, and a bulk extraction does not. The filter counts events and never the object
key, because a key is a filename and a filename in this estate can carry a person's name.
It is silent until the formatter lands like everything else here, and the control matrix
now says so in those words rather than implying a working control.

Note `exception.type` and why it exists. `PoolTimeout`, `PgWriteRefused` and
`CompensatingDeleteIncomplete` are **exception classes** in `src/pg.py` and
`src/database.py`, not envelope codes — on the wire all three surface as `INTERNAL_ERROR`
— so the envelope cannot distinguish a pool timeout from any other 500. The field is what
makes the distinction expressible at all.

### `audit.phi_access` gaps are not expressible from logs

`src/phi.py` writes two rows to a Postgres table and logs nothing on the happy path —
"Nothing is logged here, not even the count." The auditor's question (an opened row with no
matching closed row) is a SQL query against `audit.phi_access`, not a log pattern. No
metric filter can answer it, and pretending otherwise would put a green tick next to a
control that does not exist.

What *is* expressible, and is built, is the audit write **failing** — which `src/phi.py`
does log, and which is the one PHI-audit fault that reaches CloudWatch. It has its own
alarm, at one occurrence, described as an incident rather than a bug: PHI was accessed and
the audit trail for it does not exist (45 CFR 164.312(b)). The periodic gap query belongs
with Phase 6 step 5's monthly activity review and is tracked.

## 5. A Pipe, a bus and two rules for the stop-schedule DLQ

ADR 0020 §7c withdrew the depth alarm on `meridian-staging-sqs-rds-stop-dlq` and named an
EventBridge Pipe as the Phase 6 fix. This builds it — and the first build of it got the
shape wrong in a way that is worth recording, because the wrong shape is the obvious one.

The reasoning behind withdrawing the depth alarm stands and is worth restating, because the
obvious move is to put it back. Most nights staging's instance is already stopped,
`StopDBInstance` answers `InvalidDBInstanceState`, and one expected message lands. **A night
whose only message is a real failure has exactly the same depth as an ordinary night**, so
no threshold on depth can separate them — the alarm cannot fire for the single most likely
fault it exists to catch. Something that reads the *error code* can.

### What was wrong: a Pipe source filter does not route, it discards

The first build put an `anything-but` filter on the **Pipe source**. That reads like
routing. It is not. A message a source filter does not match is dropped **and acknowledged
off the queue** — Pipes polls, evaluates and deletes either way. So the expected
`InvalidDBInstanceState` messages were consumed and thrown away, and
`scripts/staging_session.sh up` — which drained the same queue precisely in order to print
`ok: InvalidDBInstanceState — the instance was already stopped`, the confirmation that a
stop had been attempted and refused — found an empty queue every time. A schedule that had been silently disabled looked exactly like a schedule that was
working, which is the precise failure §7c exists to prevent, reintroduced by its own fix.
The ADR text asserted that the duplication was deliberate and a test asserted it too; both
were describing a design that could not work.

### What replaces it

**No source filter at all.** Every dead letter is delivered, and the routing happens
downstream, where it can copy instead of consume:

* **`meridian-<env>-events-alerts`** — a *custom* event bus. Not the default bus: the
  default carries every AWS-service event in an account we share (ADR 0001), so a rule
  there is a rule evaluated against somebody else's traffic and a `source` prefix is a
  convention rather than a boundary. A bus of our own costs nothing and is a boundary.
  The Pipe stamps `source: meridian.stop-schedule` (not `aws.*`, which EventBridge
  reserves and refuses) and `detail-type: Stop schedule dead letter`.
* **`meridian-<env>-rule-stop-dlq-unexpected`** → the alerts topic **and** the log group.
  This is the latency the Pipe was for: an unexpected failure is emailed within a minute
  instead of at the next session. It also writes to the log group so that the operator
  reads one place rather than correlating a mailbox with a console.
* **`meridian-<env>-rule-stop-dlq-expected`** → the log group only, never the topic. An
  email every night for a cost control working as designed is how a mailbox filter gets
  written, and a filtered mailbox is how the real failure is missed.
* **`meridian-<env>-logs-stop-schedule`** — on the `logs` CMK with the estate's 400-day
  retention *setting*, `DESTROY` in staging because the stack is destroyed every session
  and a retained log group blocks the next deploy on a name collision. So what it actually
  holds is last night and every night while this stack has been up, not thirteen months.
  The DLQ's own one-day retention means last night survives the gap: the Pipe drains it
  into the fresh log group within seconds of `up`.

A log group is the right shape for this in a way a queue never was. It is a **history**, so
a session can ask "did this happen last night, and every night while the stack was up"; a
drained queue could answer once and then had forgotten. (The 400 days is the estate's
retention floor rather than a window this group fills: in staging it is destroyed with the
stack at the end of every session, so its history is the current session's, not thirteen
months.) `staging_session.sh up` therefore reads it with `aws logs filter-log-events` over
the last 36 hours and consumes nothing, and it reports both halves — the count of expected
refusals and any line that is not one — from that single source. It no longer touches SQS
at all, and a test asserts that it does not.

### The log group confirms the REFUSAL case only (round 2, 2026-09-16)

The first build of this made the log group the sole test of "did the nightly stop run", and
that reading is wrong in the one direction that matters. **A dead letter exists only when a
stop was attempted and refused.** On the ordinary night the staging instance is already
stopped, `StopDBInstance` answers `InvalidDBInstanceState`, and there is a message to read.
On the night *after a session that left the database running* — the night the schedule did
the actual work this cost control exists for — the stop **succeeds, and dead-letters
nothing**. The script then found an empty log group and warned that the schedule had not
fired, about a schedule that had just saved the day's spend. Silence meant two opposite
things and the script picked the wrong one.

So `up` reads the successful case from the only place it is recorded, RDS's own event
stream:

```
aws rds describe-events --source-identifier meridian-staging-rds-main \
  --source-type db-instance --duration 2160 --event-categories availability
```

`"DB instance stopped"` inside the last 36 hours (`--duration` is in minutes) is the
positive confirmation. CloudTrail `lookup-events` on `StopDBInstance` would answer the same
question and was **not** chosen: it needs a permission the operator does not otherwise
have, where `rds:DescribeEvents` sits beside the `rds:StartDBInstance` /
`rds:StopDBInstance` the script already requires. The permission is listed in the script's
header.

The rule is therefore: **either** an RDS "DB instance stopped" event **or** an expected
refusal in the log group is a pass, and `up` warns only when neither exists — which is the
only state that really does mean the schedule did not run. `up` also waits for the Pipe to
report `CurrentState = RUNNING` (capped at about three minutes) before reading the log
group, because the deploy immediately above recreated it and a Pipe that has not polled the
queue yet produces an empty log group for a reason that has nothing to do with the
schedule.

### The `$or`, and why `anything-but` alone was not enough

`anything-but` does **not** match a record where the field is absent. The first build's ADR
text claimed the opposite ("`anything-but` also matches a message with no `ERROR_CODE` at
all"), and that claim was simply wrong: a dead-lettered invocation with no error code — a
malformed target, a Scheduler failure before the API call is made — would have matched
neither the old filter nor the new unexpected rule, and would have vanished. The unexpected
rule's pattern is therefore an `$or` of `anything-but` **and** `{"exists": false}` on the
same leaf, so that "no code" is treated as unexpected, which is the safe reading.

### What is left for an alarm

The thing none of the above can report about itself: a message that **nobody consumed**.
`ApproximateAgeOfOldestMessage > 6 hours` on a queue with one-day retention means the Pipe
is not running. That is an age alarm, not a depth alarm, and the distinction is the whole of
§7c. The script's own "no result in 36 hours" warning is the second half of the same
question, asked from the other end.

## 6. Where the alarms and rules live, and why some exist only once

**One topic per environment, `meridian-<env>-sns-alerts`, in the `data` stack.** ADR 0020
§7c left open whether the environment topics fan into the shared security topic. They do
not: a fan-in adds a hop that can fail silently for no benefit at this size, and it would
make the never-destroyed `data` stack depend on a shared stack deployed on a different
cadence. The topic **moved above the staging-only guard** in `data.py` as part of this
phase — it used to exist in staging and nowhere else, which meant a production-only outage
had nowhere to page. It stays in `data` rather than moving into `observability` because an
SNS subscription is confirmed once, by a human, and `observability` is destroyed at the end
of every staging session (ADR 0008 / D-15); a topic re-created by a teardown comes back
with that subscription unconfirmed and the only symptom is silence.

**The alerts topic's resource policy is written out in full, in `data.py`.** Any explicit
`AWS::SNS::TopicPolicy` **replaces** the topic's default policy, and the default is what
lets everything in the owning account publish — so the moment one construct appends one
statement, the default is gone and every principal not named in the new document is
refused, silently, with the alarm still showing ALARM in the console. The document
therefore names three things: the owner (restoring what the default was),
`cloudwatch.amazonaws.com` for alarm actions, and `events.amazonaws.com` for the rule
targets, the last two conditioned on `aws:SourceAccount`. The `logs` CMK carries the
matching `kms:GenerateDataKey*`/`kms:Decrypt` grant for both principals; ADR 0020 §7c
already had the CloudWatch half and EventBridge's was missing, which would have made every
rule-based notification fail inside SNS.

**The KMS statements carry no condition, and the topic statements do (round 2,
2026-09-16).** Both key statements were written with `aws:SourceAccount` by symmetry with
the topic policy, and for EventBridge that is documented not to work: AWS's SNS key
management guide says in terms that "adding the `aws:SourceAccount`, `aws:SourceArn`, and
`aws:SourceOrgID` to a AWS KMS policy is **not supported** for EventBridge-to-encrypted
topics" ([sns-key-management](https://docs.aws.amazon.com/sns/latest/dg/sns-key-management.html)).
A condition the evaluating service never populates is not a narrower grant, it is a deny —
and the deny lands inside SNS, where the rule still reports itself matched and invoked and
nobody is told. The same page offers no service-specific conditioned form for CloudWatch
either (CloudWatch is not in its list of event sources with documented confused-deputy
details), and the documented key policy for a CloudWatch alarm publishing to an encrypted
topic is the bare `Allow_CloudWatch_for_CMK` statement with no `Condition`
([re:Post](https://repost.aws/knowledge-center/cloudwatch-configure-alarm-sns)), so that
condition came off as well rather than being kept on a guess whose failure mode is silence.
The confused-deputy guard lives where it is actually evaluated: `aws:SourceAccount` on
`sns:Publish` in the **topic** policy, which SNS does enforce. `observability.py` uses a plain
ARN rule target rather than `events_targets.SnsTopic`, because that construct appends an
**unconditioned** `sns:Publish` for `events.amazonaws.com` — and an unconditioned Allow
beside a conditioned one is not a confused-deputy guard, it is a decoration. Nothing needs
a grant for `pipes.amazonaws.com`: the Pipe delivers to a bus, not to the topic.

**GuardDuty, Security Hub and Config finding rules exist in production only.** Not thrift:
those three services are enabled once for the whole account, and their findings are
account-scoped. A rule in each environment sends two emails for one finding; a rule that
lives only in staging disappears with the next teardown. One rule, in the environment that
is never destroyed, is the shape that matches the facts. This also reconciles the
control-matrix row that read as if each environment had its own detection.

**Backup failures arrive by EventBridge, not by metric.** `NumberOfBackupJobsFailed` is
account-wide with no vault dimension, and the account is shared (ADR 0001), so an alarm on
it cannot tell a failed Meridian job from a failed job belonging to the other owner. The
`Backup Job State Change` event carries the vault and the resource ARN. `COMPLETED` is
deliberately not in the pattern: a success notification per resource per day is how a
mailbox filter gets written, and a filtered mailbox is how the failure is missed.

**Secrets Manager rotation failures likewise.** Secrets Manager emits no CloudWatch metric
for a failed rotation, only a CloudTrail event; the rule is scoped by the
`meridian-<env>/` name prefix, because the shared account means an ARN-less wildcard would
page us for the other owner's secrets.

## 7. What was considered and deferred

| Thing | Decision | Why |
|---|---|---|
| **CloudWatch anomaly detection** on latency and request count | Deferred, tracker row | Billed per anomaly-detection *alarm* per month. On a service with no traffic history the band is meaningless for the first fortnight, and the cost lands immediately. Revisit after one measured month of production traffic. |
| **Contributor Insights** rules | Deferred, tracker row | Priced per rule per month plus per million log events matched, and its natural use here — "which client is causing the 5xx" — needs the structured logs that do not exist yet. It is the *second* thing to do after the formatter, not the first. |
| **Amazon Macie** | Still open, ADR 0020's tracker row stands | Phase 6 was asked to decide it with the rest of the detection story. It is a spend decision against ~$11 of headroom and it belongs to the same approval conversation as the canary. Not decided here. |
| **Shield Advanced** | Refused | $3,000/month; the prompt forbids it without asking. |
| **Phase 6's own ≈ $4/month** | **Awaiting Andres's approval**, tracker row | It fits inside the ≈ $11 of headroom, and the first draft of the cost estimate therefore said it "needs no decision". That was the stack deciding a spend, which is the thing §8 says a stack does not get to do — the rule is any rise above the approved total, not any rise that cannot be absorbed. ≈ $239 → ≈ $243. |
| **Log subscription to the Object-Locked audit bucket** (plan step 1) | Deferred, tracker row | The 7-year glacier-lifecycle export is real work and it depends on knowing which log groups carry audit-grade records — which, until the structured API audit stream exists, is none of them. Sequenced after the formatter. |

## 8. The canary, and the cost it is not authorised to spend

A Synthetics canary on `https://<env hostname>/api/v1/health` every five minutes buys what
the ALB health check cannot: the ALB checks from *inside* the VPC, so it is green when
CloudFront is broken, when the certificate has expired, when DNS is wrong, and when the
origin-verify header has been half-rotated. The canary checks the path a person would,
from outside, through all of it.

It costs ≈ **$10.40 per environment per month** (8,640 runs at ≈ $0.0012), against ≈ $11 of
headroom. **A stack does not get to make a spend decision**, so it is behind
`-c enableCanary=true` and is off by default in both environments, with a row in the cost
estimate's steady-state table and a tracker row naming Andres as the approver. Production
only is ≈ $10.40; both is ≈ $20.80 and needs the ceiling re-approved.

Its artifacts go to a bucket on the `logs` CMK with a **30-day** lifecycle, not the estate's
400 days: there is no reason to keep four hundred days of screenshots of `{"status":"ok"}`.
The bucket has a fixed name in a stack staging destroys every session, so it is
`DESTROY` + `auto_delete_objects` in staging and `RETAIN` in production — `RETAIN` in
staging would leave the bucket behind and fail the next `up` on a name collision, over
thirty-day-old screenshots of a health endpoint.

**The canary is the one resource in the estate that does not follow
`meridian-<env>-<component>-<purpose>`**, and the reason is a hard AWS limit: Synthetics
caps a canary name at **21 characters** and prefixes it with `cwsyn-`, while
`meridian-staging-canary-health` is 30. The convention is *abandoned* here, not truncated by
AWS as an earlier comment claimed. The name is built once into a variable and every
reference derives from it, including the role's own-log-group ARN — those two had already
drifted apart, scoping the role to a log group the canary would never write to, which is a
canary that runs, fails, and has nothing to read afterwards.
Its role is scoped by hand rather than taking `CloudWatchSyntheticsFullAccess`, which is
`s3:*` on every bucket in an account shared with another owner. Two statements say
`Resource: "*"` — `s3:ListAllMyBuckets` and `cloudwatch:PutMetricData` have no
resource-level permission in IAM at all, so a narrower statement is not possible, only a
wrong one; the second is confined with a namespace condition and both are named in a test.

The canary script logs the status code and never the response body. `/api/v1/health`
returns no identifier today, but a canary artifact is a file in S3 for thirty days and the
endpoint's contract can change without anyone thinking about this script.

## 9. Consequences

- **Nothing pages anybody until a human confirms an SNS subscription.** That is one manual
  step, it cannot be automated (AWS requires the confirmation click), and until it is done
  every alarm in this ADR fires into an empty topic. It has a tracker row and it is the
  single most important thing in this phase.
- **The estate now has 27 alarms in staging and 26 in production** (28 and 27 with the
  canary) where it had four account-level ones.
  The plan's verify list asks for each to be tripped deliberately once on staging with the
  SNS mail kept as evidence; none has been, so none of this is evidence yet.
- **Roughly a third of the alarms are silent by construction** until the JSON formatter
  lands, and they are now silent as *absent data* rather than as a flat zero, because a
  dimensioned metric filter cannot carry a default value (§4). This is written on the
  dashboard, in the alarm descriptions, in the runbook and in the tracker, in that order of
  visibility.
- **The dashboard lost two security widgets and neither was a loss.** There is no
  `AWS/SecurityHub` CloudWatch namespace at all — Security Hub publishes to EventBridge —
  so that widget rendered an empty graph under a security heading for ever, which reads as
  "no findings". GuardDuty's `FindingCount` is per-detector and returns nothing without a
  `DetectorId`, which is an account-level identifier this stack will not import from
  `foundation`; it is passed with `-c guardDutyDetectorId=` and the widget is **omitted**
  without it. An absent widget is honest; an empty one is not.
- **`meridian-<env>-observability` now imports from `data`, `edge` and `compute`.** It
  exports nothing, which is what lets a staging teardown destroy it first — CloudFormation
  refuses to delete a stack whose exports are in use, so the ordering is a guarantee rather
  than a convention (ADR 0020).
- **An estate-wide test now walks every `AWS::Logs::LogGroup` in every stack** and fails one
  without a CMK or without 400 days. The exception list is empty today. It cannot reach the
  log groups CDK's helper Lambdas create implicitly, which keep their own tracker row.

## 10. Trigger to revisit

- **The JSON formatter lands.** Re-check every filter pattern against real output, turn the
  silent-by-construction note off in the dashboard header, and reconsider Contributor
  Insights.
- **Phase 11 adds the worker and the job queue.** `api` stops being one task by design, at
  which point `api-scaled-beyond-one` becomes wrong rather than clever and must be replaced
  by a leader-election or idempotency control, not deleted.
- **One measured month of production traffic.** Revisit anomaly detection, and revisit every
  threshold in §3 against what normal actually looks like — they are all reasoned, and none
  of them is measured.
- **A second environment or a second region.** The `Region: Global` dimension on the WAF and
  CloudFront metrics, and the account-scoped finding rules living only in production, both
  assume one account and one region.
