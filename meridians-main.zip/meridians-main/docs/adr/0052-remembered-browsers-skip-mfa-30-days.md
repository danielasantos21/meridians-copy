# ADR 0052 — A remembered browser skips the MFA code for 30 days

**Date:** 2026-10-15
**Status:** Accepted (owner request, 2026-10-15: "change the aws thing where it asks for
verification to every 30 days per computer; right now it is every time"). Built, **not deployed**.
**Source:** Andres, 2026-10-15. `infra/meridian/stacks/auth.py` (`device_tracking`),
`infra/meridian/stacks/compute.py` (`COGNITO_SIGN_IN_ACTIONS`), `src/cognito.py`
(remembered devices), `src/auth.py` (`DEVICE_COOKIE`), `src/api/v2/auth_routes.py`,
`api/routers/auth.py`, `tests/test_cognito_devices.py`
**Related:** ADR 0003 and ADR 0021 (Cognito, MFA `ON`, TOTP only, 30-day refresh token)

## Context

The pool runs MFA `REQUIRED`, so every password sign-in asked for the authenticator code,
even on the same browser an hour later after a logout. The owner wants the code asked once
per 30 days per computer.

## Decision

- **Cognito device tracking**, not an app-side bypass: `ChallengeRequiredOnNewDevice=true`,
  `DeviceOnlyRememberedOnUserPrompt=false`. A remembered device answers Cognito's
  `DEVICE_SRP_AUTH` challenge in place of the TOTP code. The password is always required, and
  MFA stays `ON` for the pool.
- After a correct code the backend confirms the device Cognito issued (`ConfirmDevice`, SRP
  verifier over a random device password) and sets `ns_device`: HttpOnly, `Secure` when
  deployed, `SameSite=Lax`, `Path=/api/v2/auth`, 30-day `Max-Age`. Logout does not clear it.
- **30 days is enforced on the server too.** Cognito never expires a remembered device, so
  each sign-in reads the device (`AdminGetDevice`, by the email being signed in) and forgets
  it (`AdminForgetDevice`) once its creation date is 30 days old. A copied cookie dies with it.
  Because the lookup is by the user signing in, one person's cookie never skips another
  person's code on a shared computer.
- Any device problem (unknown, expired, wrong proof) falls back to the ordinary code prompt.
  A wrong password is not retried without the device, so it counts once toward lockout.
- SRP is hand-rolled with the standard library (ported from amazon-cognito-identity-js v5),
  not a new dependency.

## Consequences

- It is per **browser profile**, not per machine: another browser, a private window or cleared
  cookies ask for the code once more.
- Deploy order: `meridian-<env>-auth` (device tracking) and `meridian-<env>-compute` (two IAM
  actions) before the app image; the old image ignores the setting harmlessly.
- The SRP proof is tested against a simulated server (`tests/test_cognito_devices.py`); the first
  staging sign-in after deploy is what proves real Cognito agrees.
