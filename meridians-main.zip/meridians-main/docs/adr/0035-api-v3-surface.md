# ADR 0035 — `/api/v3` is the one API surface; `/api/v1` and `/api/v2` retire

**Date:** 2026-09-24
**Status:** Accepted (the shape, and the Phase 11 retirement of the ten Flask `/api/v1` routes,
answered by Andres on 2026-09-22). Each later retirement commit — every `/api/v2` family, the
`/api/v1/health` move, the whole `/api/v2` prefix — still needs his written sign-off at the time
it lands (plan §6 decision 2).
**Source:** `docs/reports/phase-12-plan.md` §3.1, §3.2, §3.13, T02, T20, T26, T27; migration plan
D-25; ADR 0023 (FastAPI beside Flask)
**Numbering note:** planned as "0027" in the Phase 12 plan; renumbered because the Phase 11 plan
reserves 0027-0034 (see the README).

## Context

Meridian answers on three prefixes today. `/api/v1` is ten old Flask routes nobody calls
(`web_app.py:8056-8184`; a search of `web/src`, `src`, `scripts` and `tests` finds only comments —
plan §2.1) plus the health check `api/routers/health.py:47-51`, which the load balancer, the
container health check and the alarms all point at. `/api/v2` is the React app's contract: 82
paths / 109 operations in `openapi/meridian-v2.json`. Phase 12 has to add machine callers, scopes,
webhooks and partner access. Adding them to `/api/v2` would change a contract the running React
app depends on; adding them to a new surface without retiring the old ones would leave three
surfaces to secure and test for ever (the critic's "inventory" risk, OWASP API9).

## Alternatives considered

**Extend `/api/v2` in place.** The strongest case: no React move at all, no second OpenAPI
document, no family-by-family switch (T20, 4-6 days). It is rejected because v2's rules are the
browser's rules — a cookie, a permission row, no scope — and making every v2 route also accept
scopes, masking and machine callers changes the behaviour of routes the live app already uses,
with no clean line to test "old behaviour" against "new". Reversing costs about the T20 effort in
reverse (point React back at v2) plus deleting `api/v3/`. Trigger: if v3 ends up with *no*
machine caller and no partner a year after Phase 12, v3 was only a rename and the next surface
should extend in place.

**Design v3 from scratch (new models, new names).** Cleaner long-term naming, but it turns the
React move into a rewrite. Rejected: re-homing v2's pydantic models keeps "one implementation" —
a v2 route and its v3 twin call the same `src/` function until the v2 decorator is deleted.

**Keep `/api/v1/health` for ever.** It is harmless, but it is the one reason `/api/v1` would still
exist; D-25 retires it. The move is two steps so nothing breaks (below).

## Decision

1. **v3 = the already-ported v2 families re-homed under `/api/v3`, unchanged in request/response
   models where they fit, plus the new platform resources** (plan §3.2). Built so far: the
   skeleton, `/api/v3/health`, 405 handling and the empty CORS policy (`api/v3/`, commit
   `c6b8fde`).
2. **v3-wide rules, each enforced by a test:** every route declares a scope or `PUBLIC`
   (`tests/security/test_route_authz_matrix.py`); every id in a path is resolved with
   `org_id = %s` and under RLS, and a miss is `404`; request models forbid unknown fields;
   response fields carry a classification and `phi` fields are masked without `phi:read`; no PHI
   or internal ids in URLs; wrong method is `405`; no CORS headers (same-origin through the
   Next.js proxy). v3 is mounted only when `DATABASE_BACKEND=postgres` **and** `MERIDIAN_API_V3`
   is on.
3. **Retirement order.** The ten non-health `/api/v1` Flask routes are deleted in Phase 11 with
   `web_app.py` (Andres: yes, 2026-09-22). `/api/v1/health` moves in two commits: first add
   `/api/v3/health` and deploy it everywhere; only then change the ALB, container and alarm paths
   and delete the old one (plan §3.13 step 3). Doing it the other way round deploys a health path
   the old tasks do not answer, which is an outage. `/api/v2` retires family by family as React
   moves (session → config → users → invoices → pnl → dashboard → superadmin → runs), then the
   prefix goes and `src/api/v2/` is renamed `src/api/services/`.
4. `test_v1_v2_retired.py` proves `/api/v1/*` and `/api/v2/*` answer the 404 envelope and nothing
   in `web/`, `infra/`, `scripts/` or `docs/runbooks/` still names them.

## Consequences

- While a family exists in both surfaces, both are live and share one implementation; the tracker
  carries a row per family until its v2 decorators are deleted.
- `/auth/*` (Flask OAuth callbacks) is not API and is not covered here; Phase 11 ports or keeps it.
- React keeps working against Render's `/api/v2` until cutover: v3 is Postgres-only, so no React
  family moves to v3 before the cutover (plan §4 "LOCAL-NOW order").
- One more OpenAPI document exists until v2 retires (ADR 0043).

## Trigger to revisit

- A real external caller of `/api/v1` or `/api/v2` shows up in 30 days of ALB access logs after
  cutover → port that route to v3 before its prefix is removed, not after.
- Andres declines a family's retirement sign-off → that family stays dual until he agrees; the
  prefix cannot go.
