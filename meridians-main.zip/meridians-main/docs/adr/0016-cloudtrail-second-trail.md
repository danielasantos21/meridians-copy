# ADR 0016 — A second CloudTrail trail, rather than changing the existing one

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §3 Phase 1 step 5; ADR 0001 (shared account)

## Context

**CloudTrail** is AWS's audit log: it records who called which AWS API, when, from
where, and what happened. A **trail** is a configured delivery of those records to
S3 and optionally to CloudWatch Logs. An account can have several.

The AWS account is shared (ADR 0001). It already contains a **pre-existing Terraform-managed trail**
(named in plan §1) that belongs to the **other owner's** application and is managed
by **their Terraform**, whose state we cannot see. Meridian's Phase 1 needs an
audit trail that meets three requirements the existing one does not:

1. **S3 data events.** Today `DataResources: []` on the existing trail — meaning
   *no object access is logged anywhere in the account*. Once PHI lands in
   `meridian-<env>-s3-phi`, "who read which object" is the single most important
   audit question there is, and nothing would answer it.
2. **A CloudWatch Logs copy**, which is what metric filters and alarms read. The
   drift tripwire (console `Create*`/`Delete*` by a human), root-account usage,
   break-glass assumption and IAM policy changes are all metric filters over that
   copy. Without it there are no alarms — and the prompt rules out hand-rolling a
   Lambda for this.
3. **An Object-Locked destination.** Compliance-mode Object Lock with a 7-year
   retention means that for seven years nobody — not an admin, not the account
   root, not AWS Support — can delete or overwrite an audit record. Without it the
   same credential that can delete the database can delete the evidence.

Three ways to get there.

## Alternatives considered

**Modify the pre-existing trail in place.** The strongest case for it: one trail is
cheaper, and a single trail is simpler to reason about — an auditor reads one
configuration, not two. It is also the only option where nobody pays twice for a
copy of the same management event.

It loses on ownership, not on merit. The trail is Terraform-managed by someone
else. A console or CLI change to it would be reverted by their next `terraform
apply` — silently, and with no notice to us — which is the worst possible failure
mode for an audit control: one that is *believed* to be in place. It is also the
resource class ADR 0001 declared off-limits: we do not deploy onto, modify,
import, or delete anything we did not create. Changing it would additionally make
*their* trail's behaviour depend on *our* compliance requirements, which is not a
relationship either party agreed to.

**Import the pre-existing trail into our CDK stack.** Cheaper still and technically
possible (`cdk import`). But it would take a resource out from under their
Terraform, breaking their plan the next time it runs, and leaves two tools
believing they own the same object. Rejected outright.

**Reversal cost: near zero, and it stays near zero.** If the other owner's
application leaves the account, or a single consolidated trail becomes the right
answer, deleting ours is one `cdk destroy` of the trail construct. The Object-Lock
bucket and its records survive deletion by design and by policy
(`RemovalPolicy.RETAIN`), so no evidence is lost. Nothing else in the estate reads
the trail directly — the alarms read the CloudWatch log group, which is ours.

## Decision

**Meridian creates its own second trail, `meridian-shared-cloudtrail-audit`, in the
`meridian-shared-foundation` stack. The pre-existing Terraform-managed trail
(plan §1) is left exactly as it is.**

Ours is multi-region, has log-file validation on, and uses **advanced event
selectors** (not basic ones) for two categories:

- all **management events**; and
- **S3 data events** matched by `resources.ARN` `StartsWith`
  `arn:aws:s3:::meridian-` — which covers the future `meridian-<env>-s3-*` buckets
  *before they exist*, without naming any of them and without ever catching the
  other owner's buckets.

It delivers to `meridian-shared-s3-audit` (Object Lock, compliance mode, 7-year
default retention, SSE-KMS with the foundation CMK, public access blocked,
TLS-only bucket policy, Glacier after 90 days) **and** to a KMS-encrypted
CloudWatch log group kept for 400 days, which is what the four security alarms
read.

## Consequences

**Cost — small, and worth naming precisely.** The *first* copy of management
events in an account is free; every additional trail's copy is charged. At AWS's
published rate of about **$2.00 per 100,000 management events**, and at Meridian's
volume (a handful of CDK deploys and a single-digit number of human sessions per
week, plus AWS's own service calls), the duplicate management copy is well under
**$1/month**. S3 data events are billed separately at about **$0.10 per 100,000
events** and only for our own buckets. Plan §5 carries "CloudTrail + S3 data
events" at **$0.30/month** (confidence MEDIUM); this decision is inside that line,
not on top of it. Storage is the other half: Object Lock does not itself cost
extra, but nothing can be deleted for seven years, so the audit bucket only grows
— the 90-day Glacier transition is what keeps that at cents rather than dollars.

- Two trails means two copies of every management event in the account. That is
  the price of not touching someone else's resource, and it is the right trade.
- An auditor sees two trails and has to be told why. That is what this ADR is for.
- Our alarms are ours: they cannot be silently removed by the other owner's
  Terraform, and their trail cannot be broken by our CDK.
- The Object-Lock bucket is genuinely undeletable for seven years. That is a
  feature, and it is also a commitment — a misconfiguration written into it (a
  runaway log, an accidental data-event firehose) cannot be cleaned up, only paid
  for. The ARN-prefix scoping on data events is the guard against that.

## Trigger to revisit

The other owner's application leaves the account (then consolidate to one trail),
or AWS Organizations is adopted and an organization trail becomes the right shape
(then this one folds into it). Also revisit if S3 data-event volume ever makes the
CloudTrail line material against the ~$250/month ceiling — the fix is to narrow
the prefix to the `phi` bucket alone, not to turn data events off.
