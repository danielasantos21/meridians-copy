# ADR 0007 — Availability target: RPO ≈ 1 hour, RTO ≈ 8 business hours, single-AZ RDS

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §2.4, §6, decision D-14

## Context

Two numbers decide how much a database costs and how it is built.

- **RPO** (recovery point objective) — how much recent data we can afford to lose.
- **RTO** (recovery time objective) — how long we can afford to be down.

Andres's stated constraint: *"we don't want to lose data but some is acceptable."*

Meridian is used by two people, books journal entries against fiscal periods that are 4-5
weeks long, and has no real-time or customer-facing component. **Multi-AZ** RDS (a hot
standby in a second availability zone, with automatic failover) costs about **$28/month**
more, roughly 12% of the whole ~$238/month steady-state budget, and buys failover in
minutes rather than hours.

## Decision

**RPO ≈ 1 hour. RTO ≈ 8 business hours. Single-AZ RDS. No Multi-AZ, no standby.**

Met by:

- **RDS automated backups with point-in-time recovery**, 7 days — restores to any 5-minute
  mark, so the real RPO is ~5 minutes, well inside the 1-hour target. **That number is for
  the loss of an instance or an availability zone in `us-east-1`.**
- **Region loss is a different number, and this ADR now says so (Codex PS-12/G-H1,
  2026-09-16).** The cross-region copy is taken from the *daily* AWS Backup recovery point
  (05:00 UTC, six-hour completion window), so after a `us-east-1` region loss the newest
  data in `us-west-2` is up to ~30 hours old. **Regional RPO ≈ 24-30 h; RTO ≈ 8 business
  hours** (the DR test measures it). Nothing in this estate replicates the database
  continuously across regions, and the ~$25-40/month a cross-region read replica would cost
  is not in the approved estimate. The choice — accept the regional RPO in writing, or fund
  the replica — is Andres's and is recorded in `production-readiness.md` §13. Until it is
  made, every document that says "RPO ≤ 1 hour" means the in-region figure.
- **AWS Backup, 35-day locked vault (Vault Lock) with a cross-region copy** — covers loss
  of an availability zone or a whole region, and means the credential that can delete the
  database cannot delete every recovery point.
- **A restore drill every phase from Phase 3 onward**, timed and written down, so the RTO
  is always evidenced against the current schema and data size — not asserted.
- **A DR test in Phase 8**: deploy the `data` stack from the cross-region copy into the
  second region and verify row counts. That measured number is what goes in the
  contingency plan, and it must come in under 8 business hours.

These two figures are stated explicitly in the contingency plan.

## Consequences

- Saves ~$28/month, which is most of the plan's thin cost headroom.
- This is deliberately **not** five-nines. An availability-zone failure means a restore,
  measured in hours, done by one person during business hours.
- The restore drill becomes routine work in every phase rather than an annual event —
  which is the only way an 8-hour RTO is credible.
- Compliance evidence for the availability criteria comes from the drill records.

## Trigger to revisit

A real outage that costs more than ~$28/month of value; or Stella Mattina Health stating a
tighter recovery target in writing. Either one buys Multi-AZ; nothing else in the design
changes.
