# ADR 0040 — API audit trail in Postgres

**Date:** 2026-09-24
**Status:** Proposed (a plan default; T04 creates the tables, T06 writes them)
**Source:** `docs/reports/phase-12-plan.md` §3.5 (`audit.api_request`, `audit.api_client_change`),
T04, T06; the append-only pattern of `audit.superadmin_access`
(`migrations/versions/0010_superadmin_org_list.py:107`) and `audit.phi_access` (ADR 0012)
**Numbering note:** planned as "0032" in the Phase 12 plan; renumbered (Phase 11 holds 0027-0034).

## Context

Once outside systems call the API, "who read or changed what, and with which permission" has to
be answerable per request — HIPAA's audit-control rule and the quarterly access review both need
it, and the admin "Usage" screen shows it. ALB access logs record the URL and IP but not the
caller, the scope used or the org; application logs are not queryable per client and must never
carry PHI.

## Alternatives considered

**CloudWatch Logs only (structured JSON lines, Logs Insights queries).** The strongest case: no
write on the request path, no table growth, retention set on the log group, and the JSON
formatter is needed anyway. Rejected as the *only* record because logs are not append-only in the
way an audit table with `INSERT`-only grants is, the admin screen would need Logs Insights
permissions and query costs, and the formatter itself is still open (tracker line 52). Reversing
is cheap — drop the table and query logs (~1 day). Trigger: the table grows past what RDS storage
comfortably holds (see below) or the per-request write shows in latency.

**CloudTrail data events.** Records AWS API calls, not our API's.

## Decision

1. `audit.api_request`: time, request id, org id, user id **or** client id, method, **the matched
   route template** (never the raw URL), the public record id acted on, scope used, status, IP.
   No bodies, no query strings, no PHI.
2. `audit.api_client_change`: every request, approval, grant, rotation, revocation and disable,
   with actor, scopes before/after and reason.
3. Both tables are append-only: `meridian_app` gets `INSERT` only; a test proves `UPDATE` and
   `DELETE` fail. Written by middleware (`api/v3/audit.py`) so no handler can forget.
4. Retention follows the HIPAA six-year rule through the existing audit export to the
   Object-Locked audit bucket, not by keeping rows in RDS for ever.
   *Implemented 2026-09-25 (critic Stage 1 L-9, revision 0027):* rows stay in RDS **400 days**
   (the CloudWatch log retention) and leave only once the export has recorded that it holds them
   (`audit.api_request_export.exported_through`). `app.prune_api_request_audit` — a definer owned
   by `meridian_job_control`, called by the worker's sweep tick, bounded — deletes rows past both
   lines; the table's trigger enforces the same rule for everyone, the owner included. Until the
   export exists (tracker T:57 (c), Stage 3) there is no watermark and nothing is deleted.

## Consequences

- One insert per v3 request; storage is ~0 at two users (plan §8.2) and is revisited at one year.
- `test_api_audit_row.py` and `test_no_phi_in_api_logs.py` guard the two properties that matter:
  a row per call, and nothing sensitive in it.

## Trigger to revisit

- Table size or insert latency becomes measurable → partition by month, or move to logs.
- An auditor asks for request bodies → a separate, PHI-classified store; never this table.
