# ADR 0041 — Sandbox sessions and the staging wipe

**Date:** 2026-09-24
**Status:** Proposed (the sandbox's audience — outside parties or our own scripts — is still an
open question for Andres, plan §6 decision 8)
**Source:** `docs/reports/phase-12-plan.md` §3.11, T22, T23; migration plan D-18; ADR 0008 (staging
torn down between phases)
**Numbering note:** planned as "0033" in the Phase 12 plan; renumbered (Phase 11 holds 0027-0034).

## Context

A **sandbox org** is a fake organization, filled with generated data, where a partner (or our own
scripts) can practise against the API. It lives in staging. But staging's database is also where
the Phase 9 rehearsal restores **real** data. If a sandbox session and a restored copy of real
data ever share the database, a partner's sandbox credentials sit one org id away from PHI.

## Alternatives considered

**A separate sandbox environment** (its own VPC, database and pool). The strongest case: physical
separation, so no procedure can fail open. Rejected on cost: another RDS instance and NAT is tens
of dollars a month against a ~$11 headroom, for something used a few days a year. Reversing costs
a third CDK environment (~2-3 days) and a monthly line. Trigger: an outside party needs the
sandbox continuously rather than in sessions.

**Sandbox org inside production.** Rejected outright: a partner practising next to real tenants
is exactly what tenant isolation exists to prevent, and a bug there is a breach.

## Decision

1. `scripts/staging_wipe.py` (`--dry-run`, `--confirm-env staging`, refuses production by account
   and stack name) drops and recreates the staging database from Alembic, empties both buckets
   including all object versions, and writes a wipe record to the Object-Locked audit bucket.
2. `scripts/seed_sandbox_org.py` creates the "Sandbox" org and its mappings from
   `config/mappings.example.xlsx` and makes synthetic runs **through the v3 API** as a sandbox
   client — no database back door. Sample workbooks come from `make_sample_revenue.py`, harvested
   from the `aws-trial` branch into `scripts/`, writing to a temp directory, never committed.
3. **Mutual exclusion, enforced by script:** a sandbox session opens only if the newest wipe record
   is newer than the newest restore record; the restore procedure (`docs/runbooks/data-load.md`)
   refuses while any `api_clients` row with `kind='sandbox' AND status='active'` exists.
4. Sandbox Cognito app clients are deleted at session end.

## Consequences

- Staging holds either sandbox data or restored data, never both; each switch costs a wipe.
- Sessions are cheap one-offs (≈ $4/day of staging, plan §8.2).

## Trigger to revisit

- Andres answers "outside parties" for the sandbox audience → onboarding text and the session
  cadence change; if they need it continuously, a separate environment (above).
