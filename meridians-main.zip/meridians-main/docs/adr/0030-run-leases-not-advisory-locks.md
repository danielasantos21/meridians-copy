# ADR 0030 — Run leases instead of advisory locks

**Date:** 2026-09-24
**Status:** Accepted (built: tasks D2, D3, D5; the post-completion claim with the E2 prerequisite)
**Source:** `docs/reports/phase-11-plan.md` §3.5, §7.1 ("Lease vs advisory lock"), tasks D2-D5;
revisions `0011_process_runs_worker` and `0018_push_claim_and_input_digest`; `workers/run_job.py`,
`workers/sweep.py`
**Related:** ADR 0010 (no Redis), ADR 0029 (job message), ADR 0032 (idempotency)

## Context

SQS standard queues deliver at least once, and a message whose worker dies reappears after its
visibility timeout. Two workers must never run the same job of the same run at once, a killed
worker's run must be resumable, and a run nobody will ever finish must end somewhere. One run passes
through several jobs (qb-usa: parse, execute, then `qbo_push` on the finished run).

## Alternatives considered

**Postgres advisory locks.** The strongest case: they are built in, exact, released automatically when
the session ends, and ADR 0010 already names them. Rejected because a session lock pins one pool
connection (`PG_POOL_MAX` 8) for a whole run, which can take many minutes, and it leaves nothing in the
row for the sweeper or a person to see. Reversing costs a lock helper and the loss of the sweeper's
view (~1 day).

**A FIFO queue with the run as the message group.** Serializes one run's messages, but still needs
resume-after-kill and costs ordering guarantees nothing here requires. Trigger: ordering between jobs
of one run becomes a requirement.

**Let `app.claim_run` lease terminal runs too, for `qbo_push`.** One function instead of two. Rejected
because "no terminal run is ever leased" is what stops a redelivered export from re-running on a
finished run; widening it for every kind to serve one would remove that guarantee.

## Decision

1. **Lease columns on `process_runs`** (no new table): `lease_owner`, `lease_expires_at`, `attempts`,
   `last_job_id`.
2. **`app.claim_run(run, org, owner, lease_seconds, job_id)`** (definer, ADR 0029's owner) is one
   `UPDATE … WHERE lease free AND state not terminal … RETURNING`: two claimers race to exactly one
   winner; no row back means "not yours", and the message is left for later. `attempts` counts claims
   **of the current job** (`last_job_id`), so a run's parse, execute and push do not add up.
3. **`app.claim_post_completion(run, org, owner, lease_seconds, job_id, job_kind)`** (revision 0018) is
   the only way to lease a finished run: only the allowlisted pair `(qbo_push, completed)`; any other
   kind raises, a listed kind on any other state gets zero rows. It does not change the run's state.
   `workers/run_job.POST_COMPLETION_KINDS` must equal its allowlist (a test compares them). A
   post-completion job that fails **releases** its lease and leaves the message (redelivery, then the
   DLQ alarm); it never turns a booked run `failed`.
4. **Heartbeat** every 120 s under a 900 s visibility and a `JobSpec.timeout_s` lease: it extends both.
   Every write after the claim is fenced on `lease_owner` + `last_job_id` (and the settle on the state
   the job ran in), so a worker that lost its lease writes nothing.
5. **Release** on SIGTERM sets `lease_expires_at = now()` (claimable at once, still visible to the
   sweeper) and the message visibility to 0.
6. **Sweeper** (`app.expire_stale_runs`, every 15 min): `draft`/`needs_input` past `expires_at` →
   `expired` (roster overrides dropped); `parsing`/`running` with a lapsed lease after **3** attempts
   (= `maxReceiveCount`) → `failed`. The DLQ and the run agree on when a job is dead.
7. **Redelivery without SQS** (task D4, revision `0022_redeliverable_jobs`, ADR 0028): the in-process
   transport's queue dies with its process, so each api process asks `app.redeliverable_jobs` for runs
   whose lease lapsed after 1-2 claims (or whose queued job nobody claimed) and delivers the same job
   again; the third lapsed claim is still the sweeper's.

## Consequences

- A lease is a row a person can read; the sweeper and the alarms work from it.
- Handlers must be re-runnable: a resume re-enters the same job (task C7).
- A `completed` run can carry a live lease while a push runs; nothing but the push's own claim reads
  it, and the sweeper ignores finished runs.

## Trigger to revisit

- A measured need for sub-second mutual exclusion → advisory locks for that path only.
- A run measured over 60 minutes → raise the visibility and recheck the Fargate stop timeout.
- A second post-completion job kind → add its `(kind, state)` pair to 0018's allowlist in a new
  revision, with its tests.
