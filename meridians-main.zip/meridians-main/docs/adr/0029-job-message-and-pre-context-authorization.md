# ADR 0029 — Job message contract and pre-context authorization

**Date:** 2026-09-24
**Status:** Accepted (built: tasks D1, D2, D3)
**Source:** `docs/reports/phase-11-plan.md` §3.3-§3.4 (Codex PS-5), tasks D1-D3; revision
`0011_process_runs_worker`; `workers/contract.py`, `workers/run_job.py`
**Related:** ADR 0011 (tenant isolation), ADR 0030 (leases), ADR 0036 (the caller model)

## Context

Phase 11 moves process work off the api's threads onto a worker that reads jobs from SQS. A queue
message says "run job X of run R in org O for actor A". Anything that can put a message on the queue
could, if the worker believed it, act inside any organization: `with_org(O)` on the message's word
alone is a cross-tenant door. But the worker cannot simply re-read the run first, because
`process_runs` is `FORCE ROW LEVEL SECURITY` and `meridian_app` sees no row of it until `app.org_id`
is set, which is exactly the decision it has not made yet. Phase 12 also starts runs from machine
clients, so the actor is not always a user.

## Alternatives considered

**Trust the message and enter `with_org` directly.** The strongest case: the queue is private (KMS,
TLS-only policy, only the api role may `SendMessage`), so a forged message needs a compromised api
role, and at that point the attacker already has the database secret. Rejected because it makes the
queue policy a tenant-isolation control, it does not catch a legitimate message that went stale (the
actor left the org, the run moved on, the inputs changed), and ADR 0011 says neither isolation layer
is optional. Reversing it would delete one function call; nothing depends on its absence.

**Sign messages (HMAC) instead of re-reading.** A signature proves the api wrote the message; it
does not prove the actor is still a member, the run is still in a state the job may start from, or the
input versions are the ones recorded. The database check subsumes it. Trigger to add one anyway: a
producer other than the api (a partner enqueuing directly).

**A worker database role with `BYPASSRLS`, or a service key.** The loophole the migration prompt
forbids ("the new setup must not have an equivalent loophole in the app path").

## Decision

1. **The message** (`workers/contract.JobMessage`, `v: 1`) is a pydantic model with
   `extra='forbid'`, parsed as strict JSON, carrying **ids only**: `job_id`, `kind`, `run_id`,
   `org_id`, `process_id`, `actor = {actor_type: user|client, actor_id}`, and
   `input_object_versions[] = {bucket_role, key, version_id, sha256}` with every key under this run's
   `{org}/{run}/uploads/`. No amounts, names or file contents. `SweepMessage` shares the version.
2. **`app.authorize_job(run, org, actor_type, actor_id, process, from_states, versions)`** is a
   `SECURITY DEFINER` function, `search_path` pinned, owned by the NOLOGIN, NOBYPASSRLS role
   `meridian_job_control` (column grants plus `USING (true)` policies for that role only; the migrator
   holds it `INHERIT FALSE`, a chain-wide test enforces that), EXECUTE for `meridian_app` only. It is
   called **before** any tenant context and answers one row `(authorized, reason, current_state)`:
   the run exists in that org (a run in another org is `run_not_found`, the same answer as a missing
   one, so it cannot probe tenants); the user actor created it and is **still a member**, or the
   client actor created it and is still `active`; the process matches; the state is one of the job's
   start states; the recorded `inputs.object_versions` equal the message's as a multiset.
3. **A refusal** goes to the DLQ with the reason **code** as an attribute (never a value) and the
   message is deleted. `with_org()` is entered only after `authorized = true`, or, for the duplicate
   check, after a `state_not_allowed` answer (which 0011 gives only once org, actor and process have
   matched).

## Consequences

- One definer function is a privileged door; it returns ids and codes only, and every refusal has a
  pg test with a known-good control (`tests/test_worker_authorization_pg.py`).
- Phase 12's machine clients need no new message shape.
- The api must record `inputs.object_versions` before it enqueues (task C1 does).

## Trigger to revisit

- A producer other than the api → add a message signature on top of this check.
- A separate worker database role (today the worker runs the api image as `meridian_app`) → grant
  EXECUTE to it and revoke from the api role.
