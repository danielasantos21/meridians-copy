# ADR 0054 — The slimmed Cobalt snapshot lives in `mart` and is read through the audited door

**Date:** 2026-10-18
**Status:** Accepted (owner decisions 2026-10-18: manual copy now, schema `mart` behind the audited door, every Operations read audited, payment check and ERA ids dropped). Clinician NPIs: kept by default, owner confirmation pending.
**Source:** `.planning/quick/261018-cob-cobalt-on-aws/`, `scripts/cobalt_slim.py`, `scripts/copy_cobalt_to_aws.sh`
**Related:** ADR 0053, migration tracker T:251

## Decision

- Operations reads five Cobalt endpoints (appointments, claims, locations, providers, visit-types). A key-whitelist copy
  of their latest rows (about 67k rows, about 54 MB) is loaded by `scripts/copy_cobalt_to_aws.sh` from the Mac's scrubbed
  copy into `mart.cobalt_rows` (view `mart.cobalt_latest`) as `meridian_mart_owner`. Tables only; no new schema, role,
  Alembic revision or env var. The raw vault copy (port 5433) is never a source.
- The analytics views 020..060 are applied on RDS with `public.cobalt_*` rewritten to `mart.cobalt_*`; skipped while the copy is empty.
- Operations reads through `src/mart_source.py` (login `meridian_mart_reader`, no grant on `mart`): one opened and one closed
  `ecw_mart_read` audit row per uncached request, `object_name` `mart:operations.kpis|claims|portfolio`. Support sessions without PHI are refused.
- Dropped at copy time: payment check numbers and ERA ids, billing logs, submission history, notes, ids not read by a view.
  ICD descriptions are kept only by the `analytics.icd_pick` rule (most frequent, on 10 or more claims, 80 characters or fewer, no stray digit).
- Other string fields: the CPT line `description` (free eCW text, 492 distinct values over 478 codes, at most 3 per code, 98 contain digits,
  longest 72) follows the same release rule as ICD descriptions, keyed by `cpt_code`; anything else becomes null. `appointment_type` (42 distinct,
  longest 10 characters, a visit code) and `claim_status_description` (21 distinct, longest 28) are short controlled vocabularies and pass as
  is; `visit-types.description` (73 distinct, longest 44) and `locations.name` (73 distinct, longest 53) are catalogue tables. `provider_name` is a clinician name and is kept.
  Counts measured on the local scrubbed copy, 2026-10-19; no values recorded.
- Source guard: the slimmer refuses `hostaddr`/`service`/`passfile` in the DSN and `PGHOST`/`PGHOSTADDR`/`PGPORT`/`PGSERVICE` in the environment, and after
  connecting checks database `meridians_ecw`, a local server and a port other than 5433. The copy script builds the SQL in a mode-600 temp file and runs psql only if the slimmer exited 0.
- `KEEP_CLINICIAN_NPI = True` (one constant in `scripts/cobalt_slim.py`): clinician NPIs are public registry data. False drops them and `dim_provider.npi` reads NULL.

## Precomputed analytics (2026-10-19)

Measured locally (184k Cobalt rows): `analytics.fct_claim` 1.4 s, `fct_claim_line` 0.9 s, `fct_appointment` 0.5 s per request, because each re-parses
the large claim JSON; on staging `/operations/kpis` took about 12 s and the api's reader login stops statements at 60 s. Cobalt data only changes
when `scripts/copy_cobalt_to_aws.sh` runs, so the heavy part is computed once per load:

- `analytics.fct_claim_base`, `fct_claim_line_base`, `fct_appointment_base` are MATERIALIZED VIEWs (unique index on `id`, plus date / claim / ultrasound-date
  indexes). `fct_claim`, `fct_claim_line`, `fct_appointment` stay plain owner-run views over them, same names, same columns and order, so the Operations SQL,
  `fct_payment`, `icd_descriptions()`, `--check` and the BI catalog (which reads `information_schema.columns`, where materialized views do not appear) are unchanged.
- The thin views add what must not be frozen: `org_id` (`analytics.tenant` is seeded after the SQL files run, so a materialized `org_id` would be empty on a first apply),
  `aging_bucket` and `is_past` / `is_counted` (they depend on `now()`).
- Re-apply: a materialized view cannot be `CREATE OR REPLACE`d, so each file does `DROP MATERIALIZED VIEW IF EXISTS ... CASCADE` then recreates the base and the thin
  view (and 045 recreates `fct_payment`) in the same transaction. Anyone else who built a view on `fct_claim` / `fct_appointment` loses it on re-apply.
- Refresh: `scripts/refresh_cobalt_matviews.sql` (REFRESH of the three bases in one transaction, skipping any not built yet). `copy_cobalt_to_aws.sh` runs it as
  `meridian_mart_owner` right after `analyze`, and `apply_analytics_views.py --refresh [--target rds]` runs it on demand. The nightly mart-sync task does NOT touch the
  views or Cobalt, so nothing else refreshes them. Data is as fresh as the last copy, as before.
- Privileges: no new grants. The owner owns the schema and needs no database CREATE; the reader reads the thin views (owner-run), and default privileges from 0048 cover
  every object the owner creates. Not done: `analytics.icd_descriptions()` still re-reads `cobalt_latest` (about 0.7 s locally); precomputing it would put description text in a
  table the reader can select.

## Consequences

- Kept and limited-data-set class (dates, appointment and claim keys, CPT/ICD codes, money): same exposure class as the ADR 0053 copy; no `org_id`/RLS (single tenant, rebuildable).
- BI also gets `fct_appointment`, `fct_claim`, `fct_claim_line`, `fct_claim_dx` and `dim_provider` once the views are applied (`src/bi_catalog.py`), audited as `bi.*`. BI permission for these is intended.
- Freshness is the last manual copy. A nightly ECS pull from the Cobalt API is a separate follow-up.
- Reopens only with a second tenant.
