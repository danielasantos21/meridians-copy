# ADR 0048 — In-process redelivery: the database stands in for SQS's visibility timeout

**Date:** 2026-09-25 (written; built 2026-09-24, task D4 and the E2 open items)
**Status:** Accepted and built, **RDS only**; applies to `JOB_TRANSPORT=inprocess` (the default).
**Details and extends:** ADR 0028 decision 5 and ADR 0030 decision 7, which state the 0022 half in a
paragraph each. This ADR adds revision 0024 (post-completion jobs, settled-job history) and the
parameters.
**Source:** `docs/reports/phase-11-plan.md` §3.3, §3.5, tasks D4, E2 (deviations 8, 9); Alembic
`0022_redeliverable_jobs`, `0024_job_redelivery_history`; `workers/inprocess.py`,
`workers/run_job.py`, `api/main.py`

## Context

On SQS a job whose worker died reappears when its visibility timeout lapses; after three receives it
goes to the DLQ, and the sweeper (`app.expire_stale_runs`) fails the run at the same count. The
in-process transport keeps its queue in the api process's memory. A thread that dies is covered —
the `InProcessQueue` has the same 900 s visibility and three receives — but a **killed process**
takes its queue with it: the run sits leased at attempt 1 and the sweeper, waiting for attempt 3,
never touches it. E2 then showed two more holes: a `qbo_push` on a `completed` run killed with its
process was nobody's to redeliver, and a late copy of an execute message, after a push had moved
`last_job_id` on, was dead-lettered as `state_not_allowed` — booking nothing but paging someone.

## Alternatives considered

**A durable local queue table** (ADR 0028). Survives a kill by construction, but it is a second
queue beside SQS; the run row already records the job (`last_job_id`, `attempts`, the lease), so the
recovery reads that. Reversing costs a table and a poller (~1 day).

**Accept the DLQ entry for a late duplicate.** Nothing is booked. Rejected in 0024: it books nothing
but pages someone through the DLQ alarm.

## Decision

1. **Ask the database which jobs no live worker holds.** `app.redeliverable_jobs` (0022, replaced in
   place by 0024), a definer owned by `meridian_job_control`, EXECUTE for `meridian_app` only,
   answering ids, process, state and attempts — no `run_state`, `params` or `inputs`. It returns:
   - a working run (`parsing`/`running`) whose lease lapsed after **1-2** claims;
   - a job queued by `begin_action` and never claimed, older than the grace;
   - (0024) the same two cases on a `completed` run, which only a post-completion job (`qbo_push`)
     can produce, because `claim_run` refuses terminal runs and every settle clears the lease.
2. **`Dispatcher.recover()`** (`workers/inprocess.py`) calls it with `QUEUED_GRACE_SECONDS = 300`
   and `RECOVER_BATCH = 100`, re-reads each run under its own org, skips a job its own
   queue still holds or already dead-lettered, a process routed to SQS, and a run whose
   `last_job_id` moved on; rebuilds the message with the **same `job_id`** and delivers it, so
   `run_job` resumes rather than starts afresh. `authorize_job` checks it like any other message.
3. **When:** every `RECOVER_SECONDS = 60` on the dispatcher's background thread (`Dispatcher.tick`), and at
   api boot (`workers.inprocess.start_if_rds`, called from `api.main`'s module `__getattr__`), so a restarted process picks up
   what the killed one left before anything new is enqueued.
4. **Three strikes stays the sweeper's.** A third lapsed claim is not redelivered; the sweeper fails
   the run, as `maxReceiveCount 3` hands a message to the DLQ.
5. **Settled jobs are remembered** (0024): `process_runs.settled_job_ids`, the last 20 job ids that
   settled the run (`MAX_SETTLED_JOB_IDS`), appended in the worker's fenced settle. A delivery whose
   id is in it is acknowledged as a duplicate (`workers/run_job._settled_by`).
6. **Fail safe on bad settings:** a malformed `JOB_TRANSPORT`/`WORKER_PROCESSES` makes `recover`
   deliver nothing, because guessing which runs SQS owns could deliver a job twice.

## Consequences

- A job a killed api process held is delivered again once its lease lapses (a queued one after the
  5-minute grace), within a minute of the next recovery pass, instead of being stranded.
- Every api process recovers: with more than one task on this transport, each scans and one wins
  each claim (the others' copies are acknowledged as duplicates) — ADR 0028's trigger.
- The api must hold EXECUTE on this cross-org read, because on this transport the api process is the
  worker. Today api and worker share `meridian_app` for every worker definer (critic Stage 1 r1,
  M-9; tracker T:175).

## Trigger to revisit

- Every process routed to SQS (`WORKER_PROCESSES` full) → the in-process path is dev and tests only.
- A `meridian_worker` login role lands (M-9) → decide which role keeps `redeliverable_jobs`: the api
  needs it only while it runs the in-process transport.

## Amendment 1 — 2026-09-25: a queued job whose message never left is sent again, on SQS too

**Gap.** The api's start is two steps that are not one transaction: `begin_action` commits the
queued marker, then `dispatch.enqueue` sends. An api task killed between them left, on
`JOB_TRANSPORT=sqs`, a run marked queued with no message anywhere. Decision 2 skipped every
process routed to SQS, SQS had nothing to redeliver, and `begin_action` refuses every new start
while a job is queued: the run sat on the processing screen until cancelled
(`tests/test_job_start_crash_windows_pg.py`, the known-bad control).

**Decision.** The marker is the outbox row (no second queue, as the Alternatives above chose):

1. `Dispatcher.recover` sends a **queued, never-claimed** job past `QUEUED_GRACE_SECONDS` again on
   whichever transport its process is routed to — SQS through `workers/dispatch.sqs_queue` — with
   the same `job_id`. A **claimed** job of an SQS process is still SQS's (its message was never
   deleted; the visibility timeout redelivers it).
2. Only after winning `process_runs.claim_resend`: one conditional UPDATE (still that job's marker,
   attempts 0, no owner, older than the grace by the database clock, a send left) that increments
   `process_runs.job_sends` and re-arms the marker's clock. So at most one api task sends it per
   grace, and at most `MAX_JOB_SENDS = 3` sends in all (the api's own is the first;
   `begin_action` sets 1). Revision `0031_queued_job_resend` adds the column with a CHECK and makes
   `app.redeliverable_jobs`' queued branch answer only jobs with a send left, so exhausted rows do
   not crowd its oldest-first `LIMIT`. This applies to the in-process transport too.
3. A failed re-send is logged by class name and tried after the next grace.

**Why a copy is harmless.** If the original message did arrive (a worker backlog past the grace),
two messages carry one `job_id`: the lease lets one delivery claim it; the other answers `busy`
while it runs and `duplicate` once it has settled (`run_job._settled_by`). Two copies at most.

**Left as is (verdicts, same test file).** Killed after the send: the job runs once and a second
start is `409 RUN_STATE_CHANGED`. Worker killed between its settle and DeleteMessage: the
redelivery is acknowledged as a duplicate. SendMessage answered an error but SQS kept the message:
the start is given back (`abandon_action`), and if the user starts again the two jobs book once —
whichever claims first runs, the other is refused `state_not_allowed` (one DLQ entry). A job whose
three sends were all refused (e.g. its creator left the org) stays queued until cancelled, as
ADR 0028's consequences already say; each refused copy raised the DLQ alarm.
