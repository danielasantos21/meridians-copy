# ADR 0027 — The process manifest is the single registry

**Date:** 2026-09-25 (written; built 2026-09-24, tasks A1-A3, F1-F2)
**Status:** Accepted and built.
**Source:** `docs/reports/phase-11-plan.md` §3.1-§3.2, §8, tasks A1-A3, F1, F2;
`src/processes/__init__.py`, `src/processes/manifest.py`, `src/processes/*/manifest.py`
**Related:** ADR 0028 (the jobs a manifest declares), ADR 0031 (the `state_fields` it declares),
ADR 0019 (the Alembic chain whose CHECKs it must match)
**Numbering note:** reserved 2026-09-24 in the Phase 11 plan §8; written late (critic Stage 1 r1, L-14).

## Context

Before Phase 11 "which processes exist" was answered by five hand-kept lists
(`process_runs.PROCESSES`, `routes.PROCESS_CATALOGUE`, `auth.ALL_PROCESSES`/`PROCESS_LABELS`,
`state_machine.RETRY_PROCESSES`, `qb_export_artifacts.PROCESSES`) plus two database CHECK
constraints (`process_runs.process`, `role_permissions.process`). Adding a process meant editing all
of them and hoping none was missed. Phase 11's goal is that a new process is a folder, not a hunt.

## Alternatives considered

**Drop the database CHECKs and trust the registry.** One less thing to widen per process. Rejected:
the CHECK is the database's own integrity guard, and it is what stops a stray write naming a process
that does not exist. Reversing it would cost one Alembic revision per constraint.

**Read the CHECK values from `migrations/` at import time** (A1's first cut). Rejected after the A1
review: the running app would depend on files under `migrations/`, which the image need not carry.

## Decision

1. **One manifest per process.** `src/processes/<pkg>/manifest.py` exports a frozen
   `ProcessManifest` (`src/processes/manifest.py:308`): id, permission, label, colour, params model,
   inputs, steps, jobs, `state_fields`, `touches_phi`, `supports_retry`, `artifact_persistence`,
   `readiness`, `scopes`.
2. **One registry.** `REGISTRY` (`src/processes/__init__.py:220`) loads the three shipped manifests
   plus an optional machine-local `local_plugins.EXTRA_MANIFESTS` (`:206-217`, absent is normal).
3. **The old lists are derived**, never kept by hand: `process_runs.PROCESSES = frozenset(REGISTRY)`
   (`src/process_runs.py:84`), the v2 catalogue (`src/api/v2/routes.py:91`), `auth.ALL_PROCESSES` /
   `PROCESS_LABELS` (`src/auth.py:1623-1629`), `state_machine.retry_processes()`
   (`src/api/v2/state_machine.py:67`), `qb_export_artifacts.PROCESSES`
   (`src/qb_export_artifacts.py:53`).
4. **A bad manifest stops the app.** `manifest_problems` (`src/processes/__init__.py:115`) refuses an
   unknown step, a job starting from an unreachable state, a permission or id the CHECKs do not allow,
   an input with no validator or no content type, a `phi` state field on a `touches_phi=False`
   process, a platform `run_state` key, duplicates, and an envelope that is not the process's.
   `build_registry` raises `ManifestRefused` at import (`:179`).
5. **The CHECKs stay.** Their allowed values are stated in code (`PROCESS_RUNS_CHECK_VALUES`,
   `ROLE_PERMISSIONS_CHECK_VALUES`, `:82-83`); `tests/test_registry_conformance.py` holds them equal
   to both the Alembic chain and the Supabase migrations. Widening one is an Alembic revision plus
   that edit, in one commit.
6. **The dynamic checks run in CI, not at import:** `tests/conformance/` is parametrized over
   `REGISTRY`; `scripts/new_process.py` scaffolds a process (folder, manifest, stub, tests, CHECK
   revision) and `docs/adding-a-process.md` describes it.

## Consequences

- Adding a process touches its own folder, one Alembic revision and the two CHECK-value sets.
- `schemas.ProcessKey` stays a hand-written `Literal` (the OpenAPI and TS client need it
  statically); the conformance test holds it equal to the registry.
- A malformed plugin manifest on a laptop stops that laptop's app from starting, by design.

## Trigger to revisit

- Processes are added often enough that the CHECK-widening revision is friction (plan §7.1) →
  consider a lookup table instead of a CHECK.
