# ADR 0033 — Lifting the single-task api

**Date:** 2026-09-25 (written)
**Status:** Proposed — **not built.** Part of it is decided (Andres, 2026-09-22: no second api task);
the change itself is task H5, which needs AWS and follows I4 (every process on the worker).
**Source:** `docs/reports/phase-11-plan.md` §3.9, §7.2 item 2 and Andres's 2026-09-22 answers,
task H5; `infra/meridian/stacks/compute.py`, `infra/meridian/stacks/observability.py`
**Related:** ADR 0022 and ADR 0024 (why the api is pinned at one task and the
`HealthyHostCount > 1` alarm), ADR 0028 (the worker that makes lifting it safe), ADR 0039 (rate
limits once there is more than one task)
**Numbering note:** reserved 2026-09-24 in the Phase 11 plan §8. Written now so the number is not a
gap (critic Stage 1 r1, L-14); it records the plan and the answer, not a new decision.

## Context

The api service runs exactly one task, deployed stop-then-start: `desiredCount 1`,
`minimumHealthyPercent 0`, `maximumPercent 100` (`compute.py:1108-1126`, `API_DESIRED_COUNT = 1` at
`:158`). The reason is correctness, not cost: wizards kept run state in process memory, so two api
tasks could each pick up the same revenue run and book the same journal entry twice
(`compute.py:7-17`). The `HealthyHostCount > 1` alarm on the api target group is the tripwire that
the pin was undone (`observability.py:593-599`). The price is **3-6 minutes of hard downtime per api
deploy**.

Phase 11 moves the state out of memory (ADR 0031) and the work onto the worker (ADR 0028), which
is what makes a second task safe.

## What is decided

- **No second api task** (Andres, 2026-09-22): "Keep one task and right-size once heavy work moves
  to the worker; no +$29/month." `API_DESIRED_COUNT = 2` would add about $28.83/month before tax and
  pass the approved ceiling.

## What the plan proposes (H5, not built)

1. **Always:** remove the `single_task` pin so the api deploys rolling (min 100 / max 200), ending
   the deploy downtime. In the **same commit**, retire the `HealthyHostCount > 1` alarm or repurpose
   it as `< desired`, and correct the `compute.py` docstring.
2. **Then measure:** once the pandas work lives in the worker, measure api memory. If the api fits
   0.5 vCPU / 1 GB, two small tasks cost about what one large one does — a new decision for Andres
   at that point, not this ADR's.
3. **Evidence:** a deploy with zero 5xx, and the plan's timed `desiredCount = 2` end-to-end test.

## Why it waits

The plan makes H5 depend on I4. The reason is in `compute.py:7-17`: during a rolling deploy two
api tasks overlap for minutes, and until I4 has moved every process onto the worker (and G4/G5 have
removed the Flask wizards) that overlap is the double-booking the pin exists to prevent. The compare-and-set on execute (ADR 0047) closes the double start on RDS, but
not on the Supabase path that production still runs.

## Consequences

- Until H5, every api deploy is 3-6 minutes of downtime: deploy outside business hours, never during
  a close.
- Per-task rate limits (ADR 0010) stay correct while there is one task; ADR 0039 is the answer once
  there are two.

## Trigger to revisit

- I4 done on staging → build H5.
- Measured api memory fits 0.5 vCPU / 1 GB → put the two-small-tasks option to Andres.
