# ADR 0020 — The data tier, and the `vpc` / `edge` split it forced

**Date:** 2026-09-16
**Status:** Accepted
**Source:** migration plan v3.1 §2.4, §6, §3 Phase 3 steps 6-9; decisions D-14, D-15; ADR
0007 (availability), ADR 0008 (staging torn down), ADR 0009 (VPC endpoints), ADR 0012
(PHI quarantine), ADR 0018 (network and edge)

## Context

Phase 3 puts the data tier in CDK: an RDS PostgreSQL instance, three S3 buckets, the
application secrets, and an AWS Backup vault with a cross-region copy. Everything about
its *shape* was already decided — single-AZ (D-14), the instance classes, the 7-day PITR
window, the 35-day locked vault (ADR 0007), the PHI boundary (ADR 0012).

What was not decided is where the RDS instance **lives**, and that turned out to be the
whole of this ADR. Nine of the eleven sections below are ordinary "we picked X, here is
the number" records. Section 2 is the one that changes the shape of the estate.

---

## 1. The problem: an RDS instance needs a VPC, and D-15 says the database persists

D-15 (ADR 0008) is precise about what survives a staging teardown:

> The **`data` stack persists** — buckets are kept, and the RDS instance is stopped on a
> schedule. The `network`, `compute`, `api` and `observability` stacks are `cdk destroy`ed
> at the end of a session and `cdk deploy`ed at the start of the next.

An RDS instance needs a subnet group and a security group. Both lived in
`meridian-<env>-network`, which is on the destroy list. And a CloudFormation stack cannot
outlive the exports it consumes: if `data` imported a subnet id from `network`,
CloudFormation would **refuse to destroy `network`** while `data` existed — the teardown
would fail every session with "Export … cannot be deleted as it is in use".

So there were exactly three ways forward, and no fourth.

---

## 2. The decision: split `network` into `vpc` (persistent) and `edge` (transient)

### Alternative A — put RDS in a third stack, `meridian-<env>-database`

It reads well: `database` depends on `data` for the keys and on `network` for the VPC.
It does not work. `database` would import from `network`, so `cdk destroy network` would
be blocked by exactly the same export — the problem has been moved, not solved. Making
`database` transient instead would destroy the database every session, which is the thing
D-15 exists to prevent.

**Rejected: it does not solve the problem it appears to solve.**

### Alternative B — stop destroying `network`

Keep everything as it is and simply take `meridian-staging-network` off the teardown list.
One line in a runbook, no code.

**What it costs: ~$37.50/month, for ever, per environment, for nothing.** The NAT gateway
is billed by the hour whether or not a packet crosses it. ADR 0008 budgets staging at
**~$13/month idle**; this would take it to ~$51, and the ~$250/month ceiling has about $11
of headroom (plan §5). It also leaves the ALB ($24.73) and the ops instance ($3.10) up,
which pushes idle staging past $75 — its entire budget — before anyone has run anything.

It has a second cost that is not money. ADR 0008's real argument for the teardown is that
**every staging session re-proves the CDK from empty**, which is exactly the exercise a
future account split (ADR 0001) needs. Keeping the network standing removes two thirds of
that rehearsal.

**Rejected: $450/year per environment, and it blunts the rehearsal that justifies D-15.**

### Alternative C — split `network` by *lifetime* ✅ **chosen**

The network stack is two things with nothing in common except the word "network":

| Free, and must persist | Billed by the hour, and should not |
|---|---|
| VPC, 6 subnets, internet gateway | NAT gateway — $37.50/mo |
| 2 gateway endpoints (ADR 0009 — free) | ALB — $24.73/mo |
| 4 security groups | WAF web ACL — $11.60/mo |
| | CloudFront, flow-log ingestion |
| | ops instance `t4g.nano` — $3.10/mo |

So: **`meridian-<env>-vpc`** holds the left column and is never destroyed;
**`meridian-<env>-edge`** holds the right column and is destroyed at the end of every
staging session. The dependency graph becomes

```
vpc  ←  data   (keys, secrets, RDS, buckets, backup vault)
 ↑        ↑
 └────  edge   (NAT, ALB, CloudFront, WAF, flow logs, ops)
```

`edge` is the only stack anyone ever destroys, and it is a **consumer of both** the others.
Nothing imports from `edge`. CloudFormation's export rule, which was the obstacle in
Alternative A, now works *for* us: a stack whose exports are in use cannot be deleted, and
`edge` has none in use, so its destroy is unconditionally safe and the VPC and the database
are structurally out of its reach. `tests/test_vpc.py` asserts both halves of that — no
`Fn::ImportValue` in the `vpc` template, and no VPC, subnet, security group, key, secret,
database or vault declared in `edge`.

**Cost: $0.** Everything left in `vpc` is free, so persisting it changes no bill. Staging
idle stays at ~$13/month.

### The one awkward consequence, stated plainly

CDK's `Vpc` construct creates the NAT gateway **and** the private subnets' default routes
as one indivisible unit, and it refuses `nat_gateways=0` when any tier is
`PRIVATE_WITH_EGRESS`. So the persistent VPC declares `private-app` as `PRIVATE_ISOLATED`
— which is precisely "a subnet with a route table and nothing in it" — and `edge` adds the
`CfnNatGateway` plus one `CfnRoute` per `private-app` route table on top.

Two L1 resources and a comment is the whole of the workaround. The alternative would have
been to drive the NAT from the persistent stack and pay for it, which is Alternative B.

What a reader has to know, and what the code says in three places: **select subnets by
`subnet_group_name`, never by `SubnetType`.** `private-app` is typed isolated and behaves
routable; the tier *names* are the contract between the stacks.

`private-data` is isolated in both stacks and gets a route in neither. The database's lack
of an internet path is therefore a property of the code rather than of which stacks happen
to be deployed.

### What this costs in churn

`meridian-<env>-network` no longer exists. A staging session now names **four** transient
stacks (`edge`, `compute`, `api`, `observability`) instead of four including `network`, and
one extra persistent stack exists per environment. `docs/runbooks/staging-teardown.md`,
`scripts/staging_session.sh`, `infra/README.md` and ADR 0018 §2 are updated. The first
deploy after this change **replaces** the staging VPC, because a resource cannot move
between stacks without an import dance that is not worth doing for an environment that is
destroyed every session anyway. Production has never been deployed, so it pays nothing.

---

## 3. RDS: the shape, and the one deviation from the Phase 3 brief

PostgreSQL **17** — the major only, see 3b — `db.t4g.small` (production) / `db.t4g.micro` (staging), gp3 20 GB growing
to 100 by itself, single-AZ (D-14), `StorageEncrypted` with the `rds` CMK,
`PubliclyAccessible=false`, isolated subnets, `DeletionProtection` in production only,
7-day automated backups with PITR, `CopyTagsToSnapshot`, log exports to CMK-encrypted
400-day groups. All of that is the plan, implemented.

One thing is **not** what the brief asked for, and it is recorded here because a deviation
nobody wrote down is a bug waiting to be re-introduced. (There were two. The second —
"Performance Insights cannot be enabled on these instance classes" — was simply wrong, and
3b is now the correction rather than the deviation.)

### 3a. The master credential is RDS-managed, so it is not named `…-secret-db-master`

The brief asked for a Secrets Manager secret called `meridian-<env>-secret-db-master` with
a 30-day rotation.

A rotation schedule on a secret **we** own means a Secrets Manager rotation Lambda. That
Lambda has to reach the database, which is in an isolated subnet, so it has to be in the
VPC — and in the VPC it reaches Secrets Manager only through the NAT gateway, which is in
`edge`, which is destroyed for most of a staging month (§2). ADR 0009 declined to buy the
interface endpoint that would be the alternative, and buying one here (~$7.30/month per AZ)
to support a rotation would re-open that decision for a reason ADR 0009 did not consider.

`manage_master_user_password=True` gives rotation with **no Lambda, no VPC egress and no
dependency on `edge`**: RDS rotates the password internally. The cost is that RDS also
*names* the secret (`rds!db-…`), so the name in the brief cannot be used. The ARN is a
stack output instead.

**A managed rotation that always works beats a conventionally-named one that works only
during a staging session.** The secret is encrypted with the `rds` CMK rather than
`aws/secretsmanager` (a one-line L1 escape hatch), so it stays inside the same environment
boundary as everything it protects.

### 3b. Performance Insights is ON, and the engine version pins the major only

**This section used to say Performance Insights could not be enabled on `db.t4g.micro` or
`db.t4g.small`. That was wrong (critic H-3), and the error is worth naming: the "not
supported on burstable classes" rule is a MySQL and MariaDB rule, and it was applied to
PostgreSQL from memory rather than from the API.** The authority is the API itself:

```bash
aws rds describe-orderable-db-instance-options --engine postgres --engine-version 17 \
  --query "OrderableDBInstanceOptions[?SupportsPerformanceInsights==\`true\`].DBInstanceClass"
```

returns both classes. So Performance Insights is **on in both environments**, with the
free-tier settings — 7 days of retention, the default metric set — which cost **$0.00/month**
and are what the cost estimate's line already assumed. The dashboard is encrypted with the
environment's `rds` CMK rather than the AWS-managed key, because it shows SQL text and SQL
text here can contain PHI (§4). `pg_stat_statements` stays: it answers the cumulative
question, Performance Insights answers "what is happening right now", and the second one is
the question asked during an incident.

**And `EngineVersion` is `"17"`, not `"17.6"` (critic L-1).** `auto_minor_version_upgrade`
is on — minor releases carry the security fixes and there is no argument for deferring
them — and a pinned *minor* contradicts that: RDS applies the upgrade in the maintenance
window, the template still says 17.6, and the next `cdk deploy` either drifts silently or
tries to push the instance back down. `PostgresEngineVersion.of("17", "17")` renders
`EngineVersion: "17"`, which RDS reads as "any 17.x". The major is still pinned and
`allow_major_version_upgrade=False` keeps 18 a migration rather than a Sunday morning.

### 3c. `statement_timeout = 300000` (5 minutes)

The obvious value is 60 seconds, which is right for a web request and wrong for this
application. Meridian's real work is batch: a period's revenue run enriches ~76 000
transactions, a payroll booking joins several ADP exports, the Phase 3 parity suite counts
every row of 57 tables. Those are single statements that legitimately run for minutes, and
a 60-second limit would fail them depending on load — the worst kind of failure, because it
looks like a data bug.

Five minutes is long enough for everything the application issues and short enough that a
runaway query cannot hold a connection for the rest of the day. It is a **backstop, not a
budget**: anything approaching it is a bug, and `pg_stat_statements` is how it gets found.

`idle_in_transaction_session_timeout` is one minute, twenty times stricter, because an idle
transaction is not work — it is a connection holding locks and pinning the vacuum horizon
because something forgot to commit.

---

## 3d. The RDS postgresql log group is a PHI store (critic M-4)

`pgaudit.log` is `ddl,role,write`, instance-wide. That is the HIPAA write trail and it
stays. But **pgaudit logs the statement text**, and Meridian's writers interpolate literals
client-side rather than binding parameters — so an `INSERT` into a PHI table arrives in
`/aws/rds/instance/meridian-<env>-rds-main/postgresql` with the patient account number in
it, in plain text, in CloudWatch Logs.

The choice was:

* **drop `write` from `pgaudit.log`** — which trades the write trail, the thing the control
  exists for, for a classification; or
* **classify the log group honestly**, which costs nothing.

We classify it honestly. Both RDS log groups are `DataClassification=phi` and are encrypted
with the environment's **`phi` CMK**, not the `logs` CMK. Three consequences, and all three
are the point:

1. The group sits inside the §2.4 key boundary: nothing in staging can decrypt it, and the
   `phi` key's policy is the one that says so.
2. The tag is what any tag-driven control in the account reads, so the group is
   classified as PHI wherever classification is asked for.

   **Correction (2026-09-16, critic).** An earlier draft of this section said the `phi`
   tag "puts the group in the `phi` AWS Backup selection". **It does not, and it could
   not.** The selections scope their `Resources` to `rds:*:*:db:*` and `s3:::*` (§7, the
   H-1 fix), so no log group is a candidate whatever it is tagged; and CloudWatch Logs is
   not a supported AWS Backup resource type in the first place. The RDS PostgreSQL log
   group's retention is its own — **400 days**, set on the log group — and that is the
   whole of its durability story. If a longer-lived copy of the write trail is ever
   wanted, it is an export to the `audit` bucket (Object Lock, 7 years), not a backup
   selection.
3. **Reading this log group is a PHI access.** ADR 0012 records it, and Phase 6 audits
   reads of it the same way it audits `audit.phi_access` — a `GetLogEvents` on this group
   is a person reading patient data, and the CloudTrail data event is the evidence.

The Performance Insights dashboard (§3b) carries the same argument in miniature: it shows
SQL text, so it is encrypted with a CMK of ours rather than the AWS-managed key.

---

## 4. The VPC flow log is in `edge`, not `vpc`

The flow log watches a persistent VPC, so `vpc` is the intuitive home. It is in `edge` for
a concrete reason: the log group is encrypted with the `logs` CMK, the CMK is in `data`,
and `data` depends on `vpc`. A `vpc` that also consumed the key would close the cycle.

CloudWatch ingestion is also metered, so the group is not free, which is the tie-break.

**What it costs:** while `edge` is destroyed there are no flow logs. Nothing is running to
generate traffic — the database is stopped and there are no tasks — so the gap is a gap in
a record of silence. Production's `edge` is never destroyed, so production's flow logs are
continuous.

The key-policy statement CloudWatch Logs requires moved from `edge` to `data` with this
change, because the RDS log groups need it while `edge` does not exist. A test asserts it
is in exactly one of the two: added from both places it would be two statements with the
same `Sid`, which is not a valid policy.

---

## 5. The buckets: three, all RETAIN, one Object-Locked

`artifacts` (artifacts CMK), `phi` (phi CMK), `audit` (logs CMK — see §6). All versioned,
`BlockPublicAccess.BLOCK_ALL`, `BucketOwnerEnforced`, with three deny statements each:
non-TLS, non-`aws:kms`, and wrong-KMS-key. The third is the one that matters — S3 accepts a
put with SSE-S3 or with *another environment's* key and encrypts it, just not under the key
whose policy draws the boundary.

**Removal policy is RETAIN on all three, in both environments**, against the brief's
suggestion of `DESTROY` + auto-delete for staging's `artifacts`. Staging's idle S3 cost is
cents, so `DESTROY` saves nothing; `auto_delete_objects` would add a Lambda custom resource
with another implicit, unencrypted log group (the M-2 exception); and the `audit` bucket
could not be destroyed anyway, because compliance-mode Object Lock refuses to delete a
locked object before its retention expires. A test asserts there is no Lambda in the stack.

**The `audit` bucket is Object Lock, compliance mode, seven years.** Nobody can delete or
overwrite an object for that period — not an administrator, not the account root, not AWS
Support. Seven years is HIPAA's six-year documentation retention (45 CFR 164.316(b)(2))
plus slack; plan §7 item 13 names the Object-Locked bucket as what satisfies it, and says
400-day log groups do not. Object Lock can only be enabled at bucket creation: adding it
later means a new bucket and a copy.

### 5b. **2026-09-16 — a fourth bucket: `archive`, Object-Locked, on the `phi` CMK**

*Added during the Phase 9/10 runbook review. The heading above still says "three"; it now
reads three-plus-one, and the reason the fourth is separate rather than folded into `audit`
is the whole point of this note.*

`docs/runbooks/decommission-supabase-render.md` step 2 takes the final Supabase `pg_dump` —
`public` + `auth` + `storage`, 17,606 patient identifiers — and puts it under a seven-year
compliance lock. Its first draft put it in the `audit` bucket. **That is wrong.** `audit` is
`DataClassification=internal` and is encrypted with the `logs` CMK, deliberately kept away
from PHI (§3d, §6) so that *who may read the record of what happened* and *who may read the
data* are two different grants. A PHI dump in `audit` collapses that distinction
**irreversibly**, because compliance-mode Object Lock means the object cannot be deleted for
seven years by anyone — not an administrator, not the account root, not AWS Support. There is
no version of "we'll move it later".

So `data.py` creates `meridian-<env>-s3-archive`: Object Lock, compliance mode, seven years,
versioned, TLS-only and KMS-only, **`phi` CMK**, `DataClassification=phi`, no expiry lifecycle
(a lifecycle expiry on a locked object is a rule that cannot fire), `RemovalPolicy.RETAIN`. It
is created in both environments and stays empty until Phase 10, because Object Lock can only
be enabled at bucket creation — the bucket has to exist before the dump does.

**Cost:** one compressed dump is a few tens of MB, so at $0.023/GB-month it is **under
$0.01/month** — call it $0.01, and an empty versioned bucket is $0.00. It is the smallest line
in `docs/reports/phase-1-cost-estimate.md` and it is there so that nobody has to wonder.

### 5a. The 30-day raw-upload lifecycle is a **tag** filter, and it matches nothing yet

`src/storage.py` writes `{org_id}/{batch_id}/{subfolder}/{filename}`, so raw uploads are at
`<org>/<batch>/uploads/<file>` — `uploads/` is in the *middle* of the key, and an S3
lifecycle prefix matches only from the start, with no wildcards. A prefix filter therefore
cannot express "raw uploads"; a tag filter can.

The rule selects `meridian:content=raw-upload`, and **`S3StorageManager` does not yet set
that tag**, so today the rule matches nothing. That is a Phase 5a code change (plan §3
Phase 3 step 10) and it is recorded here, in `data.py` and in the tracker rather than left
to be discovered as a bill. Until it lands, raw uploads are kept indefinitely, which is the
safe direction to be wrong in.

### 5b. Raw uploads are kept 7 years, not 30 days (amended 2026-09-28)

Andres decided to keep every original uploaded billing and payroll file for **7 years**
(`RAW_UPLOAD_RETENTION_DAYS = 2557` in `data.py`), so any past journal entry can be re-run
from its exact source file and compared byte for byte, and so a period can be re-proved in an
audit. The trade-off is more PHI held for longer: the files stay in the `phi` bucket (its CMK,
GuardDuty malware gate, access logging) and the 90-day noncurrent-version rule is unchanged,
which is safe because each run pins the object version it read. Cost stays pennies (a period's
exports are a few MB). The earlier 30-day figure ("least useful to keep") is superseded; the
retention policy (Company/Compliance 01) must say 7 years.

---

## 6. The `audit` bucket reuses the `logs` CMK — there is no sixth key

The brief left this open. The `audit` bucket holds exported `audit.phi_access` rows — who
read what, when, how many rows — which ADR 0012 is explicit **never contain PHI values**.
That is the same class of content as the CloudWatch log groups the `logs` key already
encrypts, read by the same people for the same reason.

A sixth CMK would be $1/month for a boundary that the Object Lock and the bucket policy
already draw. Five keys per environment also keeps plan §2.4's isolation table true as
written.

**Trigger to revisit:** anything with PHI *values* in it is ever written to that bucket, at
which point it needs the `phi` key and a different conversation.

---

## 7. AWS Backup: locked vault, tag selection, cross-region copy

Daily at 05:00 UTC — after the RDS backup window and before maintenance — 35-day retention,
copied to a second locked vault in `us-west-2`.

**Vault Lock in compliance mode is the point.** Without it the credential that can drop the
database can delete every recovery point, and the backup is a copy rather than a control.
Bounds are [35, 400] days with a 3-day cooling-off window; after that the lock cannot be
removed by anyone, including AWS Support.

**Read that consequence twice before deploying staging.** A compliance-locked vault cannot
be deleted while it holds a recovery point, so a staging vault holds its last backups for
up to 35 days after anyone stops caring, and cannot go until they expire. That is the
control working as designed, and it is also a real constraint on abandoning an environment.
`docs/runbooks/staging-teardown.md` §2c now says so.

**`Resources` and `Conditions`, not `Conditions` alone (critic H-1).** The first version of
these selections carried the three tag conditions and nothing else, and it would have
backed up **nothing**. AWS Backup reads `Resources` as the candidate set and `Conditions`
as a filter over it; an empty candidate set filtered by anything is empty. The plan
deploys clean, the console shows two selections, and no job ever runs — the worst shape a
backup control can take, because it is indistinguishable from a working one until the day
somebody needs a restore. The candidate set is written by **type**:
`arn:${AWS::Partition}:rds:*:*:db:*` and `arn:${AWS::Partition}:s3:::*`, with no account id
(ADR 0001) and no pinned region.

**That scoping is also the answer to critic M-3.** The `edge` stack's `t4g.nano` ops
instance carries `Project`, `Environment` and `DataClassification=internal`, so a
tags-only selection would have taken a nightly EBS snapshot of a disposable jump box whose
entire content is `cdk deploy` output. Restricting the candidate set to RDS instances and
buckets excludes every EC2 and EBS ARN by construction, rather than by an exclusion list
somebody has to remember to maintain.

**Selection is by tag, in two selections rather than one.** AWS Backup ANDs the conditions
of a single selection, and the rule wanted is
`Project=meridian AND Environment=<env> AND DataClassification ∈ {phi, internal}` — an OR
inside an AND, which one selection cannot express. Two selections, one per classification,
is the same set. Selecting by tag is also what makes this robust: a resource added later
with the right tags is backed up without anyone editing the plan, and a resource without
them is not — which is the other half of why `RequiredTagsAspect` fails the build.

### 7a. Two things AWS Backup needs that are not in the template

1. **The S3 opt-in.** AWS Backup will not back up S3 until the account's region settings
   opt in (`aws backup update-region-settings --resource-type-opt-in-preference S3=true`),
   and no CloudFormation resource sets it. Without it the RDS backups run and the S3 ones
   **silently do not**. It is in `infra/README.md` → "Pre-deploy checks".
2. **`meridian-<env>-dr` is deployed first.** See §8.

### 7c. The stop schedule has a dead-letter queue, and deliberately no alarm on it

Critic M-1 argued the schedule's universal-target input should say `DBInstanceIdentifier`
(the RDS API reference spelling) rather than `DbInstanceIdentifier`, and that a wrong key
would fail at every invocation, in silence. **The first real deploy (2026-10-03) proved
the opposite:** Scheduler refused `DBInstanceIdentifier` at create time ("missing the
following field(s): DbInstanceIdentifier"), so the key is back to `DbInstanceIdentifier`.
The lasting point stands: a schedule's failures are invisible unless something catches them. So the schedule has a
dead-letter SQS queue, KMS-encrypted with the `logs` key, one day of retention.

**The CloudWatch alarm that used to sit on its depth has been withdrawn (2026-09-16,
critic, data tier medium b), and the withdrawal is the interesting part.**

The alarm fired above one message, on one day of retention. The arithmetic was: most
nights the instance is already stopped, `StopDBInstance` answers `InvalidDBInstanceState`,
one expected message lands and expires before the next; so *two* inside a day can only be
a second, different failure. That is true and it is not sufficient. **A night whose only
message is a real failure has depth 1** — the schedule ran once, it failed once, for
`AccessDenied` or a renamed instance or a throttle — and is indistinguishable at the queue
from every ordinary night. The alarm cannot fire for the single most likely real fault it
exists to catch. An alarm that is read as coverage and is not is worse than none.

The right shape is a filter on the error code, not a threshold on the depth: an
**EventBridge Pipe, SQS → SNS, with a filter pattern on the message attribute `ERROR_CODE`
≠ `InvalidDBInstanceState`.** That is a pipe, a role, a filter and an enrichment-free
target — real surface, in the stack that is never destroyed, for one nightly job in an
environment that holds no production data. It belongs with the rest of the alerting story
in **Phase 6**, where it can be decided alongside whether the per-environment topics fan
into the shared one at all.

**The interim, which is what is deployed:** the queue stays, as evidence, and
`scripts/staging_session.sh up` reads it. On every session start the script receives up to
thirty messages with `--message-attribute-names All`, prints one line per message, deletes
each as it reads it, and says loudly when an `ERROR_CODE` is not
`InvalidDBInstanceState`. The read happens at the one moment a human is definitely looking
at staging, and it can distinguish the cases a depth threshold cannot. What it gives up is
latency: a failure is noticed at the next session rather than the next morning. For a
nightly cost-control stop on staging, that is the right trade; for anything in production
it would not be.

`STOP_DLQ_ERROR_ATTRIBUTE` and `STOP_DLQ_EXPECTED_ERROR` live in
`infra/meridian/stacks/data.py`, and `infra/tests/test_data.py` asserts the script uses
both — so the script and the infrastructure cannot drift apart quietly.

> **Note, 2026-09-16 (Phase 6, ADR 0024 §5).** The Pipe named above is built, and the shape
> proposed here — *SQS → SNS with the filter on the Pipe source* — turned out to be wrong,
> so this paragraph describes a design that was not shipped. **A Pipes source filter does
> not route; it discards**: a message it does not match is dropped *and deleted from the
> queue*. Filtering there would have consumed the expected `InvalidDBInstanceState`
> messages before anyone could read them, which is exactly the evidence the interim above
> exists to preserve. What shipped instead is an **unfiltered** Pipe onto a custom event
> bus, with two rules splitting expected from unexpected: unexpected pages the topic and is
> logged, expected is logged only. The interim's manual drain is therefore **retired**, not
> kept — `scripts/staging_session.sh up` now reads `meridian-staging-logs-stop-schedule`
> with `aws logs filter-log-events` and consumes nothing, so the same question can be asked
> again next session. The age (not depth) alarm on the queue stays. Also corrected: the
> claim made here and in ADR 0024's first draft that `anything-but` matches a message with
> no `ERROR_CODE` at all. It does not — an absent field matches no `anything-but` — so the
> unexpected rule's pattern is an `$or` with `{"exists": false}` beside it. See ADR 0024 §5.

The per-environment topic, `meridian-<env>-sns-alerts`, is kept although it now has
neither a subscriber nor a publisher. Two reasons: Phase 6 attaches the alarms, and its
key grant is the thing that would otherwise be missing when the first one matters —
CloudWatch publishes as `cloudwatch.amazonaws.com`, not as a `meridian-<env>-*` role, so
the `logs` CMK policy names that service principal explicitly with `kms:Decrypt` and
`kms:GenerateDataKey*` under an `aws:SourceAccount` condition (critic, data tier medium
a). Without it the publish fails *inside SNS*: the alarm still goes to ALARM, the console
still shows an action, and nobody is told.

> **2026-09-16 — the `aws:SourceAccount` condition on that key statement has been
> removed** (Phase 6 critic round 2, P6R2-01). It was added here by analogy with the trust
> policies in §12a, and a key policy is not a trust policy. AWS's SNS key-management guide
> states that `aws:SourceAccount`, `aws:SourceArn` and `aws:SourceOrgID` on a KMS policy
> are **not supported** for EventBridge-to-encrypted-topics, and documents no conditioned
> form for CloudWatch either — the published key policy for a CloudWatch alarm publishing
> to an encrypted topic is `Allow_CloudWatch_for_CMK` with no `Condition` at all. A
> condition the evaluating service never populates produces exactly the failure this
> paragraph warns about, silently. The guard moved to the place SNS actually evaluates:
> `aws:SourceAccount` on `sns:Publish` in the topic policy, which `data.py` writes out in
> full. See ADR 0024 §6.

### 7b. The scheduled plan is PRODUCTION only; staging backs up on demand (critic M-2)

A daily 05:00 UTC backup job against the staging instance would fail **every night**. The
02:00 America/Chicago stop schedule (D-15) turned the instance off three hours earlier, and
AWS Backup does not skip a stopped RDS instance — it fails the job. A job that is *expected*
to fail is worse than no job at all: it fills the AWS Backup console and any future
job-failure alarm with noise, and the one night it fails for a real reason reads exactly
like the other three hundred.

The alternatives were considered and rejected:

* **Start the instance for the backup and stop it again.** Two more schedules, a start that
  costs money on every day nobody works, and a race with the stop schedule — to protect an
  environment that holds no production data.
* **Move the plan's window inside working hours.** The instance is only reliably up during
  a session, and sessions are not on a timetable.
* **Give staging a shorter retention so the vault expires faster.** The lock bounds are
  [35, 400] days and a locked vault refuses anything outside them; shortening retention
  means a second, unlocked vault, which is the control we are here to have.

**So:** staging keeps the vault, the compliance lock, the CMK and the backup role, and has
no `AWS::Backup::BackupPlan` and no selections. Its recovery story is

1. **PITR, 7 days.** Unaffected by the instance being stopped — RDS keeps the automated
   backups and the transaction logs either way. This is the recovery anyone actually uses.
2. **One on-demand job per session.** `scripts/staging_session.sh down` runs
   `aws backup start-backup-job` against the instance *before* it stops it, into the same
   locked vault. That is what gives `docs/runbooks/restore-drill.md` a real recovery point
   to exercise, against the same lock production has.

Production is unchanged: the daily plan, the two selections and the cross-region copy.

---

## 8. The DR vault is a separate, always-present stack

A CloudFormation stack lives in one region, so a `us-west-2` vault cannot be a resource of
a `us-east-1` stack. But this app is deliberately **region-agnostic** (`infra/app.py`):
account and region come from `CDK_DEFAULT_*`, and with neither set the templates are
written with pseudo-parameters, which is what lets `cdk synth` run in CI with no
credentials. A region-pinned stack needs a concrete region.

**`meridian-<env>-dr` is always in the app (critic M-5).** It used to be added only when
`CDK_DEFAULT_REGION` was set, on the theory that a pinned stack needs a concrete *account*
as well as a concrete region. It does not — only the region has to be concrete — and the
CDK CLI sets `CDK_DEFAULT_REGION` from whatever credentials are in use anyway. So under the
CLI the stack was always there, and the conditional's only real effect was to hide it from
the in-process tests, which is precisely where a missing DR vault goes unnoticed. The
region comes from `-c drRegion` (default `us-west-2`); the account stays unresolved, so
`cdk synth` still needs no credentials; and a test now asserts the stack is **present** in
both environments.

The `data` stack does **not** import the DR vault. It **composes the ARN** from
pseudo-parameters (`arn:${AWS::Partition}:backup:<drRegion>:${AWS::AccountId}:backup-vault:
meridian-<env>-backup-dr`), because there is no cross-region export and CDK's cross-region
reference support works by putting a custom-resource Lambda in the path of the backup
configuration. A composed ARN needs no Lambda and writes down no account id (ADR 0001).

**The price is an ordering rule rather than a CloudFormation dependency:** deploy
`meridian-<env>-dr` before `meridian-<env>-data`, or the first copy job fails with "vault
does not exist". It is in the stack description, in `data.py`, and in
`docs/runbooks/restore-drill.md` §1. `-c drRegion=…` moves it.

---

## 9. Secrets: four, and one of them must never be rotated

**`meridian-<env>/app-env` is not one of them and is not a Phase 3 resource (critic L-2).**
The plan mentions it as the bundle of non-secret application settings the ECS task
definition reads. It belongs with the thing that reads it, so it is created in **Phase 5a**
with the task definition, not here. Phase 3 creates exactly the four secrets below.

| Secret | Value | Rotation |
|---|---|---|
| `meridian-<env>-secret-origin-verify` | 64 chars, generated (Phase 1) | Two-deploy runbook (ADR 0018 §7) |
| `meridian-<env>-secret-db-app` | `meridian_app` password | Runbook, quarterly |
| `meridian-<env>-secret-db-phi` | `phi_access` password | Runbook, quarterly |
| `meridian-<env>-secret-phi-hmac-key` | 64 chars ≈ 380 bits | **Never, without a re-keying plan** |
| (RDS-managed) | `meridian_migrator` password | RDS, internally (§3a) |

**The two database credentials are not RDS credentials in the CloudFormation sense.** The
roles are created by Alembic revision `0003_rds_adaptations`, which reads
`MERIDIAN_APP_DB_PASSWORD` and `MERIDIAN_PHI_DB_PASSWORD`; CloudFormation has no idea they
exist. What the stack creates is the *value*, in the right shape, under the right name; the
migration installs it. Rotation is `docs/runbooks/rotate-secrets.md` for the same
Lambda-needs-the-NAT reason as §3a, and Phase 5a can automate it from an ECS task, which is
already in the VPC with egress.

**Every generated password excludes the URL-breaking characters.** `MERIDIAN_DATABASE_URL`
is a URL; a password containing `/`, `@`, `:`, `%`, `?` or `#` either terminates a component
early or must be percent-encoded by every consumer that builds one — psycopg2, Alembic,
`psql` in a runbook, the task definition's dynamic reference — and the one that forgets
fails as a wrong password. It costs about four bits out of ~280.

**The PHI HMAC key is the one that must not be rotated.** `patient_ref = HMAC(key,
patient_id)` is stored on every row of `public.transactions` and is the link to
`phi.transaction_identity` (ADR 0012). Rotating it does not invalidate anything visibly; it
silently makes every stored `patient_ref` stop matching a freshly computed one, and
duplicate detection — the only consumer — starts returning nothing while continuing to look
like it works. `rotate-secrets.md` §4 carries the re-keying procedure and the instruction
not to start without it.

---

## 10. `MERIDIAN_DATABASE_URL` is not a stack output, and never will be

A CloudFormation output is readable by anyone who can call `DescribeStacks`. The connection
string contains a password, so it is assembled in the Phase 5a task definition from a
`secretsmanager` dynamic reference, which CloudFormation resolves at deploy time into the
task's secret configuration and never prints:

```
postgresql://meridian_app:{{resolve:secretsmanager:<db-app arn>:SecretString:password}}
  @<DatabaseEndpoint>:5432/meridian?sslmode=verify-full&sslrootcert=/opt/rds-ca.pem
```

`sslmode=verify-full`, never `require` — `require` encrypts without authenticating the
server, which is not a defence against anything that can answer on the address. The RDS CA
bundle is baked into the image (plan §3 Phase 3 step 6).

The four `S3_REQUIRED_ENV` variables (`src/settings.py`) map to ordinary outputs, exported
as `meridian-<env>-data-<Name>` so the compute stack can import them:
`MERIDIAN_S3_ARTIFACTS_BUCKET`, `MERIDIAN_S3_PHI_BUCKET`, `MERIDIAN_S3_KMS_KEY_ARN`
(artifacts CMK), `MERIDIAN_S3_PHI_KMS_KEY_ARN`. `AWS_REGION` comes from the ECS agent.

Task-role `GetSecretValue` grants are Phase 5a, scoped to exactly those ARNs.

---

## 11. GuardDuty Malware Protection, on the `phi` bucket only

Every file Meridian ingests is an untrusted upload from a billing system, and `phi` is
where they land (`src/storage.py` maps `uploads` — and every unclassified subfolder —
there). Scanning is per-GB, and the other two buckets hold what this application itself
wrote, so one plan on one bucket.

`Tagging: ENABLED` is the whole point: GuardDuty writes `GuardDutyMalwareScanStatus` onto
each object, and ADR 0012 says nothing is processed until the object is tagged clean. **The
reader of that tag is Phase 5a** — implementing the scan first is the right order, because
a scan with no reader still quarantines nothing while a reader with no scan reads malware.

**Macie is not here.** `AWS::Macie::Session` is account-level, and the foundation stack is
not this phase's to change. A tracker row carries it; it stays deferred because Macie is
billed per GB classified and there is nothing to classify until the Phase 3 step 11 load.

---

## Consequences

- Staging idle stays at **~$13/month**; the split costs $0 because everything persisted is
  free. The data tier adds ~$3 (staging, stopped) / ~$29 (production) — see
  `docs/reports/phase-1-cost-estimate.md`.
- `cdk destroy` of `edge` is structurally unable to reach the VPC or the database, and two
  tests assert the property rather than the intention.
- A staging session now names `edge compute api observability`. Anyone following the old
  runbook from memory and typing `meridian-staging-network` gets "stack does not exist",
  which is the harmless failure.
- **A compliance-locked vault and an Object-Locked bucket cannot be cleaned up on demand.**
  Abandoning an environment now has a 35-day tail (vault) and a seven-year one (audit
  bucket). That is the control, and it is the first thing in this design that cannot be
  undone with a `cdk destroy`.
- The first `cdk deploy` after this change replaces staging's VPC. Production is unaffected
  because it has never been deployed.

## Trigger to revisit

- **The split:** staging stops being torn down (which would mean revisiting ADR 0008
  first), or the estate moves to one stack per environment. Merging `vpc` and `edge` back
  together is a stack refactor, not a flag.
- **Single-AZ and the instance class** move together, and the trigger is ADR 0007's — a
  real outage that costs more than ~$28/month of value. Performance Insights is no longer
  part of that bundle: it is already on, and free.
- **The staging backup schedule** returns the day staging stops being stopped nightly
  (§7b). If D-15 goes, the production-only plan goes with it.
- **The `logs` CMK on the audit bucket:** anything with PHI values is written there.
- **Rotation by runbook:** Phase 5a gives us an ECS task in the VPC with egress, which is
  the moment the two database credentials can rotate on a schedule.

---

## 12. Three small hardenings from the Phase 3 critic round (2026-09-16)

Recorded here rather than left as comments, because each is the kind of thing a later
reader would otherwise "clean up".

**a. `aws:SourceAccount` on two trust policies.** `meridian-<env>-iam-rds-stop`
(EventBridge Scheduler) and `meridian-<env>-iam-backup` (AWS Backup) are assumed by
service principals. Without a source-account condition on the **trust** policy, any
schedule or backup plan in any account that learns the role's ARN can have the service
assume it — and both ARNs are derived from the resource-naming convention, so they are
guessable. This is AWS's documented confused-deputy guard; the GuardDuty malware role
already carried it, and now these two do.

**b. The origin-verify secret is on the `logs` CMK.** It was on the AWS-managed
`aws/secretsmanager` key. It is not PHI — putting it on the `phi` key would draw a
boundary around the wrong thing — but it is not public either, and what a CMK of ours buys
is a key policy we control and a CloudTrail `Decrypt` event naming a key we own on every
read of it.

**c. `AWS::Scheduler::Schedule` cannot be tagged.** The resource type has no `Tags`
property, so `RequiredTagsAspect` cannot reach the stop schedule and `Tags.of(...)` on it
is silently a no-op. Nothing is lost — it holds no data and costs nothing — but it means a
tag-based inventory of the account is not complete, and that is worth knowing before
somebody reads one as if it were.
