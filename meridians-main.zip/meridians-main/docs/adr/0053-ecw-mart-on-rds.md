# ADR 0053 — The eCW data-mart copy lives in our own RDS (`mart` + `analytics`)

**Date:** 2026-10-18
**Status:** Accepted (owner decision O-1, 2026-10-18: "mart first, Cobalt next").
Container built by Alembic 0048; **not deployed**.
**Source:** `migrations/versions/0048_ecw_mart.py`, `tests/test_migration_0048_ecw_mart_pg.py`,
plan `.planning/quick/261018-ecw-mart-on-aws/`
**Related:** ADR 0005/0011/0012 (RDS, tenant isolation), migration tracker T:251, T:253, T:256

## Context

On AWS, Reports & dashboards (BI) and Ask a question answer 503 "eCW data isn't connected"
(T:253): the Operations gate refuses on the Postgres backend (T:251), the job that copies the
eCW data mart only runs on Andres's Mac (T:256), and nothing in `infra/` copies it. Nothing
like a patient-stripped copy of the mart exists in RDS yet, despite what an old docstring says.
The owner wants BI, Ask and (through BI) the Executive Report to show eCW numbers on AWS
before cutover, without an unaudited read of patient data. The Cobalt snapshot for Operations
is a later, separate plan and must not be blocked by this one.

## Decision

- **Where.** The RDS app database `meridian`, two new schemas: `mart` (the copied tables) and
  `analytics` (views, snapshot tables, functions). Not a second database: one Alembic revision
  owns roles, schemas and grants, and there is one backup and restore story.
- **Who owns it.** A new LOGIN role `meridian_mart_owner` owns both schemas; the nightly
  loader logs in as it, so every object it creates is its own.
- **Who reads it.** A second LOGIN role `meridian_mart_reader`: USAGE on `analytics`, SELECT
  and EXECUTE there through default privileges (which survive the loader's nightly
  drop/create), a read-only session and a 60 s statement timeout, and nothing at all on
  `mart`, `public`, `phi`, `audit` or `app`. It reaches `mart` only through owner-run views
  (`security_invoker = false`) and `SECURITY DEFINER` functions. `meridian_app` and
  `phi_access` can read neither schema. Tests hold every one of these.
- **What is copied.** Only the 11 mart tables the BI views read, patient columns dropped at
  copy time with the existing strip lists (about 0.8 GB of a 3.9 GB mart).
- **Load.** A nightly ECS task runs `scripts/sync_data_mart.py --target rds` (05:00 America/Chicago),
  read-only against the external mart, TLS verified, into `mart`, then the daily snapshots.
- **Audit.** Every eCW read on AWS goes through one door that writes an `ecw_mart_read` opened
  row before the read and a closed row (row count, no values) after, in `audit.phi_access`,
  two rows per request, none for a request served from cache. A read outside an audit scope is
  refused before it connects. The door holds no pooled app connection while the read runs.
- **Native SQL** stays refused on the Postgres backend; **Operations** and the **P&L run** are
  unchanged (P&L keeps reading the external mart through `ECW_DB_*`).

## Why `mart` and `analytics` have no `org_id` and no RLS

ADR 0011 requires the `org_id` predicate plus RLS on tenant data a role can read. These
schemas are not that: a single-tenant staging copy whose shape follows the source and is
dropped and rewritten nightly (RLS policies and `org_id` columns would be recreated on every
load and would not protect anything), that **no application role can read** (zero grants, proven
by test), and that is reached only through owner-run views. Every BI query still binds the org as
a parameter on `analytics.*`, the gate returns 404 for any org but the configured one, and
`analytics.tenant` is checked on each request: together the single-tenant guard that stands in for
the second layer. Like `audit`, neither schema is in `gen_tenant_tables.SCHEMAS`, so the tenant
list and `lint_org_scope` are unchanged.

## What reopens this decision

- A **second eCW tenant** (the copy would need `org_id` and RLS, or one copy per tenant).
- **P&L moving** onto the copy (its driver SQL reads the source's `public` schema).
- **Cobalt / Operations** landing in RDS (needs its own tables and grants; nothing here blocks it).

## Consequences

- A nightly rewrite of about 0.8 GB on the app instance at 05:00. The loader truncates and
  copies each table in one transaction (ACCESS EXCLUSIVE for the biggest, 389 MB), so a BI query
  that hits the window can fail on its lock timeout; a changed source column list makes the
  loader's `DROP TABLE` fail while the 090 views depend on the table (no CASCADE). Both are
  existing laptop behaviour; the runbook lists them as nightly failure modes.
- Audit volume: two `audit.phi_access` rows per BI request that reads the copy. The row's
  `db_user` reads `meridian_app` (the writer), not the reader login; `action` and `object_name`
  identify the read.
- `mart` and `analytics` are rebuildable: leave them out of database dumps and restore drills,
  and refill with the loader after any restore. Downgrading 0048 drops both schemas without
  CASCADE (it fails loudly if populated) and leaves the two cluster-wide roles in place.
- The role passwords come from `MERIDIAN_MART_OWNER_DB_PASSWORD` / `MERIDIAN_MART_READER_DB_PASSWORD`
  (Secrets Manager); a re-run of the migration's role step re-passwords them.
