# ADR 0021 — Cognito sessions: cookies for the browser, Bearer for everything else

**Date:** 2026-09-16
**Status:** Accepted
**Supersedes:** `docs/api-v2-contract.md` §0 (the "httpOnly Supabase JWT cookies kept" premise)
and §6 (CSRF and auth-failure semantics). Those sections describe a system with exactly one
issuer and no non-browser client; from Phase 4 neither is true.
**Refines:** ADR 0003 (auth model). ADR 0003 decided *what* — Cognito, `custom:app_uid`, dual
tokens, a User Migration Lambda. This one decides *how a request proves who it is*, and
revises one number in ADR 0003 (the refresh-token lifetime; see "Token lifetimes").
**Source:** migration plan v3.1 §2.1, Phase 4 step 2, decisions D-06 and D-13

## Context

Contract §0 and §6 were written for one shape of client: a Next.js SPA on the same origin as
Flask, holding an HttpOnly Supabase JWT cookie, with global `CSRFProtect` in front of every
unsafe method. That shape is correct today and stops being a complete description on the day
Phase 4 lands, for three reasons at once:

1. **There are two issuers.** A Supabase HS256 JWT and a Cognito RS256 ID token are both
   valid credentials between Flip 1 (Phase 4) and the cut-off (Phase 10). Something has to
   say which is tried first, and what "the user id" means when they disagree.
2. **There are non-browser clients.** A React Native app cannot use a cookie set on
   `meridiansgrp.com`, and a machine client has no cookie jar at all. The same endpoints have
   to answer both.
3. **CSRF protection is a property of the cookie, not of the endpoint.** A request
   authenticated by an `Authorization` header is not vulnerable to CSRF — the browser will
   not attach that header for a third-party site — so applying a cookie-shaped defence to it
   is cost with no benefit, and worse, it invites someone to weaken the defence for the
   requests that do need it.

There is also a standing requirement neither section covers: **verification must not cost a
network round trip.** The deleted token cache in `src/auth.py` existed because Supabase's
`get_user` did, and it bought ~100 ms at the price of a revoked session staying usable for a
minute.

## Alternatives considered

**Bearer tokens for the browser too, dropping cookies entirely.** This is the strongest
rejected option and it is genuinely tidy: one credential type, one code path, no CSRF story at
all. It is rejected because the SPA would then have to *hold* the token, which means
`localStorage` or a JavaScript variable, which means any XSS in any dependency reads a
credential that opens PHI. An HttpOnly cookie is unreadable to script by construction.
Reversing this decision costs a rewrite of the login screen and the token plumbing, perhaps
two days; the event that would trigger it is the browser app moving to a different origin
from the API, where a cookie stops being first-party.

**Cookies for everyone, including mobile, via a native cookie jar.** Rejected: it works, and
it makes every future non-browser caller — a scheduled job, a partner integration — either
impersonate a browser or get a second authentication scheme bolted on later. The Bearer path
is needed eventually; adding it now costs one branch.

**Cognito's hosted UI for the whole sign-in flow.** Rejected for the browser: the MFA and
password-reset screens are part of the product and a redirect to an Amazon-branded page in the
middle of them is a support call. It IS used for the two federated redirects, where the user
is leaving for Google or Microsoft anyway.

**Enforced threat protection rather than audit.** Rejected for now: enforcement blocks
sign-ins on a risk score nobody has calibrated, and a two-person workforce on a new network is
indistinguishable from what it would block. Revisit after Phase 8 has a month of audit data.

## Decision

**Browsers use a cookie session; everything else uses `Authorization: Bearer`.**

- The Cognito **ID token** goes into an HttpOnly, `Secure`, `SameSite=Lax` cookie, exactly as
  the Supabase token does today. `Secure` is unconditional in any deployed environment. The
  SPA never sees a token and learns its auth state from `GET /api/v2/me`.
- **CSRF stays a double-submit token for cookie-authenticated requests**, unchanged from
  contract §6.1: `GET /api/v2/csrf`, a non-HttpOnly `XSRF-TOKEN` cookie, `X-CSRFToken` on
  every unsafe method, `403 CSRF_INVALID` with `retryable: true`. A request carrying a valid
  `Authorization: Bearer` header is **exempt**, because a browser will not attach that header
  cross-origin and there is nothing to forge.
- `SameSite=Lax` is defence in depth, not the defence. It is sufficient only because the
  Next.js rewrites make everything same-origin.
- **The federated round trip carries an OAuth `state`.** `/auth/google` and `/auth/microsoft`
  mint `secrets.token_urlsafe(32)`, put it in a short-lived (600 s) HttpOnly, `SameSite=Lax`
  cookie beside the parked `next`, and pass it to the hosted authorize URL; `/auth/callback`
  compares it with `hmac.compare_digest` **before** the code exchange and refuses — generic
  flash, redirect to `/login`, no cookies set, both round-trip cookies cleared — on a
  mismatch, a missing parameter or a missing cookie. Without it the callback accepts any
  authorization code anybody can make a signed-out browser follow, which is login CSRF: the
  victim ends up holding a session belonging to the attacker's account, and everything they
  do next is recorded where the attacker can read it. `SameSite=Lax` does not cover this —
  the callback is a top-level GET, which is exactly what `Lax` allows. The value is spent on
  first use, so a captured code cannot be replayed against it.

**Both issuers are accepted, Cognito first.**

- `AUTH_BACKEND ∈ {supabase, cognito, disabled}`. `supabase` is today. `disabled` is a
  local-development convenience and raises outside development. **Dual acceptance is a
  property of `cognito` mode**, not a fourth value: in `cognito` mode a token is verified
  against Cognito first and, only if that fails, against Supabase Auth.
- The order is not cosmetic. After Flip 1 almost every token is a Cognito token and Cognito
  verification costs no network at all; trying Supabase first would put a round trip in front
  of the common case to serve the rare one.
- Dual acceptance ends at the **Phase 10 cut-off** (cutover + 60 days), when the Supabase
  branch, the trigger and the Lambda are deleted together.
- **It has an off switch before then: `AUTH_ACCEPT_SUPABASE_TOKENS`** (default `true`;
  `false` makes `cognito` mode mean Cognito only). Phase 10's first step is to set it to
  `false`, confirm nothing breaks, and only then delete the branch — deleting code and
  discovering the consequence in the same deploy is not a step, it is a gamble. It is also
  the lever for anything that cannot wait for the cut-off: see the termination note below.
- Rolling back is `AUTH_BACKEND=supabase` and a redeploy. `auth.users` is never mutated.
- **A terminated user is not fully revoked by `AdminDisableUser` while the window is open.**
  Disabling someone in Cognito stops them getting a *new* Cognito token; it says nothing
  about a Supabase session they already hold, and `_fetch_user` will accept that session
  until it expires on its own. So for as long as dual acceptance is on, the termination
  checklist (164.308(a)(3)(ii)(C)) disables or signs the user out **in Supabase Auth too** —
  or closes the fallback entirely with `AUTH_ACCEPT_SUPABASE_TOKENS=false`. This is the cost
  of two live issuers, written down rather than discovered.

**The application user id is `claims.get('custom:app_uid') or claims['sub']`.**

Both issuers resolve to the same id, so no application row is ever rewritten. The fallback is
load-bearing and not a nicety: a user created directly in Cognito has no `custom:app_uid`, and
without it the first Cognito-native sign-in is a `KeyError` in production.

**And `sub` is carried separately, because it is a different string.** The pool has
`UsernameAttributes=['email']`, so Cognito *generates* the username and it is the `sub`; a
migrated user's `custom:app_uid` is their old Supabase UUID, which Cognito has never heard of.
On `InitiateAuth` the `SECRET_HASH` is over what the user typed (the email alias); on the
**MFA** and **refresh** calls it is over the pool's username — and never, anywhere, over the
application id. So `validate_token` returns both, the MFA step uses the username Cognito named
in `ChallengeParameters.USER_ID_FOR_SRP`, and the refresh path reads `cognito:username`/`sub`
out of the expiring ID token **unverified**: the value is a lookup key handed straight back to
Cognito, which verifies the refresh token and the hash and refuses the exchange if either is
wrong. Getting this wrong does not fail at sign-in; it fails 60 minutes later, for everyone,
at once.

**Token lifetimes.**

| Token | Life | Why |
|---|---|---|
| ID / access (browser, mobile) | **60 minutes** | Bounds how long a revoked session stays usable. It is the only staleness window left after the caches were deleted. |
| Refresh | **30 days** | **Revises ADR 0003's 12 hours.** With MFA `ON` and token revocation enabled, a 12-hour refresh means a TOTP challenge every morning — the kind of friction that ends with MFA being switched off. Revocation, not expiry, is the control that ends a session here. |
| Machine (client credentials) | **15 minutes** | Nothing renews it interactively and nobody notices when one leaks, so the lifetime is the whole control. |

**Verification is local, always.** RS256 against the pool's JWKS, fetched once over HTTPS and
cached in-process with a TTL, keyed by `kid`; an unknown `kid` buys exactly one refetch per
minute, so a rotation needs no restart and a forged-token generator cannot aim the process at
Cognito. A `kid` already in the cache keeps verifying through a failed refetch — the TTL
lapsing is a prompt to re-check, not evidence the keys changed, and treating an unreachable
Cognito as "no keys" would sign out a healthy application for the length of the outage. An
unknown `kid` still fails closed. Checked on every request: signature, `iss`, `aud`, `exp`
(with 30 seconds of clock leeway, or a host a second behind refuses tokens it was just
handed), and `token_use == 'id'`.
An **access** token is refused by the session path — a client-credentials token has no human
behind it, and accepting one would let a machine act as whoever `sub` names.

**MFA is `ON`, TOTP only.** SMS is off: a phone number can be ported to somebody else's
handset, and every message costs money. Threat protection is `AUDIT`, which requires the
Cognito **Plus** feature plan (~$0.02 per monthly active user — under $1/month for a
two-person workforce).

**No roles, no permissions, no org in any claim.** Authorization is rows in Postgres, read on
every request, for both issuers. A token says who you are and nothing about what you may do.

## Consequences

- Contract §0's "httpOnly Supabase JWT cookies kept" premise and §6's implicit
  "every request is a cookie request" are no longer complete. Both sections carry a pointer
  here; neither is rewritten, because the contract is a record of what was specified and this
  is the record of what changed.
- `src/auth.py` gains exactly two branches that know there are two issuers: `_fetch_user`,
  which verifies, and `try_refresh_token`, which renews. The second is not optional — without
  it, every expiring session after Flip 1 POSTs a **Cognito** refresh token to Supabase's
  `/auth/v1/token`, which hands one system's credential to another. Nothing else in the
  codebase knows.
- Per-user metadata (name, avatar, language, dashboard layout) leaves Supabase Auth for
  `public.user_profiles` (Alembic revision 0006), because Cognito custom attributes cap at
  2,048 characters and 50 attributes and cannot be deleted.
- The five caches in `src/auth.py` are deleted. The token cache is unnecessary (local
  verification), and the four authorization caches were a documented staleness bug bought for
  ~400 ms that Phase 5a removes anyway by putting Postgres inside the VPC.
- Three things become deployment configuration rather than code: `COGNITO_*` in the
  environment, `AUTH_ACCEPT_SUPABASE_TOKENS` (the dual-acceptance off switch, the Phase 10
  config step), and the OAuth callback URLs, which differ per environment and default to that
  environment's own origin at synth.
- A machine client exists but nothing authorizes it yet. The resource server carries
  `runs:read` and `runs:write` and deliberately **no** `phi:read`; the PHI scope arrives with
  the partner API in Phase 12 (ADR 0002).

## Trigger to revisit

The browser app moves to an origin different from the API's, which ends `SameSite=Lax` as a
usable defence and makes the cookie third-party; or a measured need for sessions longer than
30 days without re-authentication; or Phase 8's audit data shows threat protection would have
caught something, which moves it to `ENFORCED`; or the Phase 10 cut-off passes, at which point
dual acceptance is deleted and this ADR's "two issuers" half is history.

## Residual risks

Recorded 2026-09-16, from the Phase 4 round-2 critic pass. Each one is accepted, not
solved; the first two carry a named verification step in
`docs/runbooks/cognito-user-migration.md`.

**1. The Entra subject is pairwise, so the pre-linked Microsoft identity may not match.**
An OIDC `sub` issued by Microsoft Entra is different per *application registration*. Every
Microsoft subject in `legacy_users.json` was issued to **Supabase's** registration, so
`AdminLinkProviderForUser` only links the right person if Cognito's OIDC provider is
configured with that same registration. **Provisional decision: reuse it**, and have the
tenant admin add Cognito's redirect URI (`https://<hosted-domain>/oauth2/idpresponse`) to
it — which needs an external tenant admin (P-8), so it is on the tracker as a human step.
The snapshot also captures Entra's `oid` (the tenant-wide object id, the same across
registrations) whenever Supabase recorded it, so if a new registration has to be used
instead, the fallback is an attribute mapping onto `oid` rather than a snapshot of a system
that no longer exists. The residual is that nothing in this repository can prove which
registration a deployed provider points at: **one Microsoft sign-in verified on staging, on
every environment, before production** is the whole control (runbook §0 and §4 item 3).

**2. `ForgotPassword` may still be an existence oracle at the API level.** The Lambda
answers the two `UserMigration_*` triggers identically — same message, and now the same
Supabase round-trip whether or not the address is in the snapshot (see 3). The symmetry is
enforced at the Lambda level across **all three** branches, including the one that had
nothing to verify: a known password user asking for a reset used to answer straight out of
the snapshot dictionary while a stranger paid for a Supabase call, which INVERTED the oracle
the decoy exists to close — the fast answer was the one that meant "this address is real".
That branch now makes the same decoy `_check_password` call and throws the result away, so
every path through the handler costs exactly one round trip. But Cognito's
own `ForgotPassword` API sits above it: for a stranger the trigger raises and the call
fails, while for a known user the account is created in `RESET_REQUIRED` and a real code is
sent. Those two API responses may differ in status, body shape or latency, and nothing here
can measure that without a real pool. Runbook §4 item 8 compares all three on staging, three
runs each; a difference in status or shape is a Flip 1 blocker, a difference in latency
alone is recorded here with its numbers.

**3. Equalising the refusal latency costs a Supabase request per refused sign-in.** "Not in
the snapshot" and "federated-only" were dictionary lookups returning in under a millisecond,
while a wrong password cost a round-trip — a timing oracle for "is this address real?" that
needs no error message. Both branches now make the same request with a fixed decoy password.
The chosen option is the request rather than an artificial sleep, because a sleep has to
guess the round-trip it is imitating and drifts away from it as Supabase's latency changes.
Accepted costs: one extra outbound call per refused sign-in (a workforce of two, and the
window closes at the Phase 10 cut-off); GoTrue's IP rate limiting could in principle be
tripped by a flood of refusals from the Lambda's egress address, which would then fail
sign-ins closed for everybody — the same direction as every other failure here, and visible
as `outcome=refused status=4xx` in CloudWatch. **Supabase's password grant applies no
account lockout by default**, so a decoy attempt cannot lock a real person out; if that ever
changes, this decision has to be revisited before the change lands.

**4. A dual-identity user has an unlinked window.** Password users are never pre-created —
Cognito does not invoke the migration trigger for a user that already exists, so creating
one would leave them in `FORCE_CHANGE_PASSWORD`, the forced reset ADR 0003 forbids. A user
with *both* a password and a provider therefore migrates through the Lambda first and is
linked afterwards, with `preprovision_cognito_users.py --link-only`. Between their first
password sign-in and that run, a federated sign-in would create a duplicate empty account.
Mitigated by procedure only: the weekly report shows them the week they migrate, and the
runbook says to run `--link-only` then rather than at the cut-off.

**5. The Lambda's deadline is enforced against the clock, not against the socket.** The
outbound call now has an overall 3-second budget — connect capped at 1 second, the read
bounded by what is left, clipped further by `context.get_remaining_time_in_millis()` — and
an exhausted budget refuses without calling. The residual is that the budget is a constant
chosen against a measured 100-250 ms Secrets Manager cold start and an unmeasured Supabase
latency; the p99 check in runbook §4 item 9 is what says whether 3 seconds was right.

**6. The Supabase federated callback has no `state` check.** The `state` cookie is minted for
every federated start, but only the Cognito branch of `/auth/callback` compares it. Supabase's
`/auth/v1/authorize` manages its own state and does not reliably echo a caller-supplied one, and
that branch is production until Flip 1, so gating it would be a change to the live sign-in
path with no way to test it here. The login-CSRF window on the Supabase path is accepted and
retires with the path (Phase 10). Tracker row.

**7. The forgot-password decoy leaves a failed sign-in in Supabase's auth log.** Every reset
request for a known user now sends a fixed decoy password for that real address, which GoTrue
records as a failed password grant. It is not an attack; anyone reading the Supabase auth log
during the window should expect one failed grant per reset request.
