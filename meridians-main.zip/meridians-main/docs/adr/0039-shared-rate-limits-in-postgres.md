# ADR 0039 — Shared rate limits and quotas in Postgres

**Date:** 2026-09-24
**Status:** Proposed (a plan default Andres has not been asked about; T09 builds it)
**Refines:** ADR 0010 (no Redis). ADR 0010 stands — still no ElastiCache — but its "rate limiting
stays per-task while there is one api task" no longer covers `/api/v3`.
**Source:** `docs/reports/phase-12-plan.md` §3.5 (`api_quota_window`), R6, T09; Phase 11 plan §7.1
("Per-task rate limits at N=2") and Andres's 2026-09-22 answer ("Second api task: no")
**Numbering note:** planned as "0031" in the Phase 12 plan; renumbered (Phase 11 holds 0027-0034).

## Context

Today's limits are an in-process fixed window (`api/deps.py:575-584`, strings in
`src/api/v2/limits.py`, e.g. `LIMIT_LOGIN = "5/minute"`). A counter held in one process is only
correct while exactly one process serves traffic. Andres decided on 2026-09-22 to keep **one api
task**, but a rolling deploy briefly runs two, Phase 11 moves heavy work to a worker, and v3 adds
machine clients whose quotas are part of the contract (`429 QUOTA_EXCEEDED` with `Retry-After`)
and progressive lockout on repeated 401s. A quota a client can double by being routed to the
other task is not a quota. The WAF's per-IP rules (`RateLimitPerIp` 2000, `RateLimitAuthPerIp`
100 per 5 minutes) sit in front but cannot see a user or a client id.

## Alternatives considered

**ElastiCache (Redis).** The strongest case: it is the standard tool, atomic `INCR` with expiry,
no write load on the database, and it scales to many tasks. Rejected for cost and surface: the
smallest node is a fixed monthly line against a ~$11 headroom (cost estimate §3), plus a new
service to patch, encrypt and monitor, for a two-person workforce and a handful of clients.
Reversing costs a cache cluster in CDK and swapping one module's storage (~1-2 days). Trigger:
counter writes become a measurable share of RDS load (> ~5% CPU) (plan R6).

**Keep per-task counters and rely on WAF.** Zero work. Rejected for v3: the WAF cannot key on a
client id or user, and lockout keyed on an account needs a shared count.

**DynamoDB counters.** Serverless and cheap, but adds a second data store and IAM surface for one
table; Postgres is already in every request.

## Decision

1. `public.api_quota_window (bucket, window_start, hits)` with a fixed-window upsert
   (`INSERT … ON CONFLICT DO UPDATE SET hits = hits + 1 RETURNING hits`) in `api/v3/quotas.py`.
   Buckets: per machine client, per user, per IP on the auth endpoints.
2. Progressive lockout: repeated `401`s from one IP or one client id grow a delay, then answer
   `429 QUOTA_EXCEEDED`.
3. `/api/v2` keeps its per-task limiter until it retires; the WAF rules stay as the outer layer.
4. Old windows are deleted by the same daily job that disables idle clients.
5. **Store outage (amended 2026-09-25, critic Stage 1 M-5).** Nothing switches itself off when
   the quota store is unreachable: the lockout gate (`auth_gate`) fails CLOSED with
   `503 PERSISTENCE_UNAVAILABLE`; failure counting and the caps (`record_auth_failure`, `cap`)
   fall back to per-task in-process windows (`quotas.FALLBACK`), the same rule `PgRateLimiter`
   uses for `/api/v2` — a weaker limit per task, never no limit. Tested in
   `tests/security/test_quota_store_outage.py` with known-bad controls.
6. **Shared egress (amended 2026-09-25, critic Stage 1 L-4).** Forged-token `401`s from any source
   count against the ADDRESS, so an attacker behind the same NAT as a partner could lock the
   partner out. A locked address is now refused after the caller is resolved rather than before:
   invalid tokens still get `429`, every human and every machine client without an IP allowlist
   is still refused, and a verified machine client whose own `ip_allowlist` admits the address is
   let through. Partners behind shared egress are told to register their egress range
   (`docs/runbooks/onboard-partner.md`). The client-id lockout (verified failures only) is
   unchanged and still refuses before authentication.
7. **Business-flow spacing (amended 2026-09-25, Andres: "1 every 30 seconds").** On top of the
   per-caller allowance, `quotas.cap` holds three 30-second windows: a v3 job start per org and
   process (`JOB_START_SPACING_*`; the 30-an-hour `JOB_START_LIMIT` stays as the ceiling on the
   hour's total, since spacing alone would allow 120), a webhook `/test` ping per subscription
   (the 60-per-org-per-hour cap stays) and a webhook redrive per subscription (the 3-per-delivery
   and 7-day bounds stay). They replace "10 pings / 20 redrives per subscription per hour". The
   windows are fixed and clock-aligned, as every bucket here: one call per window, `Retry-After`
   = seconds left in it (rounded up, in Postgres and in the in-process fallback alike), and two
   calls a moment apart across a window edge can both pass. The spacing is checked before the
   hourly cap, so a start it refuses does not spend the hour. A bucket name carries one window
   size only (the row key is `(bucket, window_start)`), hence the `-30s` bucket names.

## Consequences

- One small write per v3 request; at today's volume this is negligible, and it is measured, not
  assumed (the trigger below).
- The test uses two app instances against one database (`test_rate_limits.py`) — that is the
  property that matters.

## Trigger to revisit

- Counter writes > ~5% of RDS CPU → ElastiCache or DynamoDB, with a cost line for Andres.
- A security test shows lockout bypass by alternating tasks on `/api/v2` → move v2 onto the
  shared counter before v2 retires.
