# ADR 0017 — DNS: a Route 53 hosted zone, with the registrar left at GoDaddy

**Date:** 2026-09-15
**Status:** Accepted
**Source:** `docs/architecture/dns.md` (the provisional decision recorded in Phase 0),
migration plan Phase 1 step 3 and Phase 9; implemented as
`infra/meridian/stacks/dns.py`.

## Context

`meridiansgrp.com` is registered at GoDaddy and served by GoDaddy's own nameservers
(`ns25`/`ns26.domaincontrol.com`). The zone carries **sixteen record sets**, and every one
of them has to keep answering after the switch:

- the three Proofpoint **MX** records that receive the company's mail;
- the apex **TXT** set — an SPF policy and a Microsoft 365 tenant verification string;
- the **`_dmarc` TXT** policy;
- nine **CNAMEs**: `autodiscover` (Outlook client configuration), `selector1` and
  `selector2._domainkey` (Microsoft 365's own DKIM), `lyncdiscover`, `sip` and `msoid`
  (Teams / Skype for Business and Microsoft Online sign-in), `email` (GoDaddy webmail),
  `_domainconnect` (GoDaddy's Domain Connect discovery record, inert after the switch),
  and **`ai`** — which is **not ours**: it is the other account owner's production
  application (ADR 0001), pointed at their own CloudFront distribution. It is in the zone
  because it is live at GoDaddy, and the switch must not take somebody else's product
  down. We never repoint or remove it, and `docs/runbooks/dns-nameserver-switch.md` §5
  makes "confirm `ai.meridiansgrp.com` still serves" a post-switch check;
- two **SRV** records, `_sipfederationtls._tcp` and `_sip._tls`, for Skype federation;
- the apex **A** record and the **`www` CNAME** that point the website at Render.

*An earlier version of this ADR said "five things that matter" and listed only the mail
records and the two Render ones. That was the Phase 0 inventory, and it was wrong: eleven
live records were missing from it, and therefore from the stack. They would have gone dark
at the switch — `autodiscover` and the two DKIM selectors being the expensive ones, because
neither failure looks like a DNS failure. The zone is now exported with `dig` into
`infra/dns/meridiansgrp.com.zone.json` and compared against the synthesized template by a
test, so "the inventory is stale" is a failing build rather than an outage.*

*A second correction, 2026-09-15: the `dig` export itself found only fourteen. Two more —
`ai` and `_domainconnect` — were found by a **candidate-name sweep** against the GoDaddy
nameservers, now §3a of the runbook alongside a GoDaddy zone-file export diffed by
`scripts/dns_zone_diff.py`. An export lists the records someone chose to export; a sweep
asks about names nobody wrote down. The check needs both directions, and the one it was
missing is the one that found the other owner's hostname.*

Phase 9 puts CloudFront in front of the application (ADR 0015). CloudFront has no fixed IP
address — it is reached by a DNS name that resolves differently per client and changes over
time. Pointing a **bare domain** ("apex") at a name rather than an IP is not something plain
DNS can do: the apex must also carry the zone's `SOA` and `NS` records, and a `CNAME` may
not coexist with other records at the same name. Every DNS provider that solves this does so
with a proprietary extension. **Route 53 has one (ALIAS records). GoDaddy DNS does not** — it
offers only an `A` record with a literal IP.

SES also needs to write into the zone: three Easy DKIM CNAMEs, and an MX plus SPF record for
the custom MAIL FROM subdomain `mail.meridiansgrp.com` (ADR 0014). At GoDaddy those are five
records typed by hand, from a console, with no diff and no test.

So the question is where authoritative DNS lives from Phase 9 onward.

## Alternatives considered

**Keep DNS at GoDaddy and use its domain forwarding for the apex.** This is the genuinely
attractive option and it deserves its strongest statement: it changes nothing. No nameserver
switch, no 48-hour propagation tail, no chance of taking inbound mail down, no new
$0.50/month line item, and Andres keeps DNS in the same account as the registration — one
place, one login, one thing to remember. `www.meridiansgrp.com` would be a `CNAME` to the
CloudFront distribution (GoDaddy can do that; it is only the apex that is the problem), and
`meridiansgrp.com` would use GoDaddy's "forwarding" feature to redirect visitors to `www`.

It fails on the first hop. GoDaddy forwarding is implemented by GoDaddy's own web servers
answering the bare domain and returning a redirect — and that first request is **plain
HTTP**, on infrastructure we do not control, outside CloudFront and outside the WAF, before
HSTS can apply. For a HIPAA-scoped application whose login page lives at that domain, a
redirect hop that can be intercepted is not a detail. It also makes the bare domain's
availability depend on a GoDaddy feature with no SLA we have read, and it leaves the SES
DNS records as hand-typed console entries that nothing tests and `cdk diff` cannot see.

The cost of that option is a rounding error; the cost of ours is $0.50/month. This was not
decided on price.

**A third option — move the registration to Route 53 Domains as well** — was rejected as
unnecessary risk for no benefit. A registrar transfer is a 5-to-7-day process with its own
failure modes, it has no effect on what CloudFront needs, and it can be done later if we
ever want it.

## Decision

**Create a Route 53 public hosted zone for `meridiansgrp.com` in Phase 1 and switch the
nameservers to it before Phase 9. The registrar stays GoDaddy.**

Three properties make this safe rather than merely possible:

1. **The zone is a byte-for-byte copy of the GoDaddy zone before the switch.** All sixteen
   record sets are defined in `infra/meridian/stacks/dns.py`, and the list they must match
   is not a comment or a memory — it is `infra/dns/meridiansgrp.com.zone.json`, a `dig`
   export of the live zone, checked in. `infra/tests/test_dns.py` asserts, entry by entry,
   that every record in that file appears in the synthesized template with the same type,
   TTL and values, and that the zone contains nothing the export does not explain. The
   nameserver switch is therefore a change of *who answers*, not *what is answered* — and
   that claim is now testable rather than asserted.
2. **Verification precedes the switch, in both directions.**
   `docs/runbooks/dns-nameserver-switch.md` §3 iterates over that same export file,
   querying each record directly on the Route 53 nameservers with `dig @<ns>` while
   GoDaddy is still authoritative. §3a then sweeps the other way: a fresh GoDaddy
   zone-file export diffed against the checked-in one by `scripts/dns_zone_diff.py`,
   **and** a list of candidate names dug straight at the GoDaddy nameservers. A hit that
   is in neither file fails the check. That second direction is what found `ai` and
   `_domainconnect`.
3. **The Render records stay exactly as they are** until Phase 9 replaces them with
   CloudFront ALIAS records. The nameserver switch and the cutover are two separate events
   with a gap between them, so neither is debugged while the other is in flight.

The SES domain identity is defined in the same stack and handed the hosted zone, so CDK
writes the DKIM CNAMEs and the MAIL FROM records itself. Nobody transcribes a DKIM token.

**Two ACM certificates write validation records into this one zone, and they do not
collide.** Staging's edge certificate (ADR 0018, M-1) covers `staging.meridiansgrp.com`
and `origin-staging.meridiansgrp.com`; production's covers `meridiansgrp.com`,
`www.meridiansgrp.com` and `origin-production.meridiansgrp.com`. ACM DNS validation
creates one CNAME **per distinct domain name**, at
`_<hash-of-that-name>.<that-name>` — the label is derived from the name being validated,
so two certificates covering *different* names produce records at different owner names
and cannot overwrite each other. The only case where two certificates share a validation
record is when they cover the **same** name, and then ACM writes the *same* value, so the
record is idempotent rather than contested. That is why no name appears in both
certificates after M-1: the split is not only about what each environment needs, it also
removes the one situation where a staging `cdk destroy` could delete a record production
depends on. (Route 53 records created by ACM validation are owned by the CDK stack that
requested the certificate, which is precisely why staging must not request
`meridiansgrp.com`.)

## Consequences

- **The apex can point at CloudFront in Phase 9**, which is the entire point. The zone id is
  a stack output for exactly that.
- **DNS becomes reviewable.** A DNS change is a pull request with a `cdk diff`, and the tests
  fail if a record's value changes without the export changing. Adding a record at GoDaddy
  and not here is now a failing build rather than a discovery made at 2 a.m. Conversely, **DNS changes made
  in the Route 53 console are silently reverted by the next deploy** — the zone is now code,
  and hand-edits are a bug.
- **Cost:** $0.50/month for the zone plus per-query charges of a few cents at this volume.
- **Two logins for one domain.** The registrar (nameservers, renewal, WHOIS) is at GoDaddy;
  the records are in AWS. `docs/architecture/dns.md` says which is which so that a future
  session does not go looking for an A record in the wrong place.
- **Inbound mail is unaffected and stays at Proofpoint.** SES only ever sends. This is the
  consequence most worth restating, because it is the one a reader assumes wrongly.
- **A 48-hour propagation tail** during which both zones answer. Harmless precisely because
  of property (1), and the reason the runbook lowers TTLs a day in advance.

## Trigger to revisit

**Reversal is cheap and stays cheap:** switch the nameservers back to
`ns25`/`ns26.domaincontrol.com` at GoDaddy. The GoDaddy zone is never modified or deleted by
this decision, so it resumes serving the same records it serves today; the cost is the
registry NS TTL, typically about an hour. The runbook's §6 is the procedure.

Revisit if:

- **Andres decides DNS should live at GoDaddy after all.** Then Phase 9 uses the
  `www`-only CloudFront alias plus GoDaddy apex forwarding described above, and accepts the
  plain-HTTP first hop on the bare domain. This is the documented fallback, not a failure.
- **The apex stops needing to point at CloudFront** — for instance if the product moves to a
  subdomain entirely. The zone would then be optional, though the SES records are still
  easier to manage here.
- **A future account split (ADR 0001)** puts production in its own account. The zone is
  account-level and would move or be delegated; that is a change to this decision's scope,
  not to the decision.
