# ADR 0023 — FastAPI beside Flask: one process, one origin, one path at a time

**Date:** 2026-09-16
**Status:** Accepted
**Phase:** 5a (`docs/aws-migration-plan.md`, "FastAPI beside Flask")
**Supersedes nothing. Constrained by:** ADR 0010 (no Redis), ADR 0021 (cookie + Bearer auth,
double-submit CSRF), `docs/api-v2-contract.md` §4, §6, §9, §10.1.

## Context

The target stack is FastAPI. What exists is an 11,500-line Flask application: 78
`render_template` routes, the `/api/v2` blueprint (~90 handlers across seven modules), global
`CSRFProtect`, flask-limiter, and `src/auth.py`'s decorators writing `g.user`, `g.org` and
`g.permissions`. Production runs it on Render today and will run it until Phase 9.

Three ways to get from here to there:

1. **Rewrite `/api/v2` in FastAPI and run two services.** Two origins, two deployments, two
   sets of cookies, and a Next.js rewrite table that has to know which half owns each path.
   Every one of those is a place a session can be lost.
2. **Rewrite it all at once.** Ten to fifteen days during which nothing ships and the only
   way to know whether it works is to deploy it. The plan budgets this phase at 10-15 days
   for the API alone; a flag day at the end of it is not a rollback plan.
3. **Mount Flask under FastAPI and move paths one at a time.** One process, one origin, one
   cookie jar. Each commit is small enough to review and small enough to revert.

## Decision

**A FastAPI application (`api/`) is the process. The Flask application is mounted underneath
it at `/`.**

- `api/main.py` builds the app, includes the routers for the paths that have been ported, and
  mounts `web_app.app` last, at the root, through Starlette's `WSGIMiddleware`. Starlette
  matches routes in order, so anything a router does not claim falls through to Flask.
- `uvicorn api.main:app` is the entry point — `render.yaml`, `scripts/serve_api.sh` and
  `python -m api` all run the same thing. `python web_app.py` still serves Flask alone and is
  still the quickest loop for Jinja work; it does not serve the ported paths.
- **Ported in this ADR's commit:** `GET /api/v1/health` and `GET /health` (D-25), and the
  seven `/api/v2/auth/*` endpoints.

### The one-commit rule

**A path is removed from the Flask side in the same commit that lands it in FastAPI.** Never
both, never neither. Two implementations of one URL is a bug that hides until the two
disagree, and which one answers is then decided by routing order rather than by anyone's
intent. `tests/test_fastapi_app.py` asserts both halves for every path moved so far: absent
from the Flask `url_map`, present here.

### Dependency injection replaces `g`

`src/auth.py` grew two extracted functions, `local_dev_user()` and `org_context(user_id)`,
which are now the single definition of "who is this" and "what may they do". `require_auth`
and `require_org` call them and write the answer onto `g`; `api/deps.py` calls them and hands
the answer to the endpoint as an `Identity` argument. There is one resolution, not two — and
a FastAPI handler cannot read an identity it did not ask for, which is the property `g` never
had.

Three dependencies, declared in the order Flask runs the same checks in today:

1. `check_csrf` — double-submit on every unsafe method, exempt for `Authorization: Bearer`
   (ADR 0021). **It compares the `X-CSRFToken` header with the `XSRF-TOKEN` cookie rather
   than verifying flask-wtf's signature**, because that signature is tied to the Flask
   *session* cookie, which this surface does not have. Both checks reject the same attacker:
   an origin that cannot read the cookie cannot produce the header. `WTF_CSRF_ENABLED` on the
   mounted Flask app is the single switch for both surfaces, so a deployment cannot end up
   protecting half of its own API.
2. `limit(spec)` — the class limits and the key function from `src/api/v2/limits.py`, applied
   by an in-process fixed-window counter (`api.deps.RateLimiter`). In process for the same
   reason flask-limiter's `memory://` is: ADR 0010 rules out Redis and the service runs one
   worker. Like flask-limiter it runs ahead of the auth dependency, so the credential
   endpoints key on the caller's address — which is what §9 asks of them anyway.
3. `require_user` / `require_org` — the identity, then the org. 401 stays distinguishable
   from 403 (§6.2).

### The error envelope

`api/errors.py` installs one handler per exception class, all answering §4.1. The **code
catalogue is imported, not copied**, from `src/api/v2/errors.py`: one definition of what a
code means, which status it carries and whether it is retryable. `RequestValidationError`
becomes a 422 with `field_errors` in the contract's shape, with FastAPI's leading `body`
segment stripped so a field reads `params.accrual_days`. An unhandled exception becomes a 500
carrying a request id and a sentence; the traceback is logged and never sent, because in this
codebase a traceback can carry the contents of a spreadsheet cell.

### OpenAPI stays a generated artefact — generated from the models, not from the framework

`openapi/meridian-v2.json` is still produced by `scripts/generate_openapi.py` walking the
`ROUTES` registry and `model_json_schema()` (contract §10.2, the "lighter option"). FastAPI's
own `/openapi.json` is **disabled** (`openapi_url=None`).

Letting FastAPI serve a second, partial document would give the repository two contracts, one
of which nobody regenerates — and the partial one would lose the curated per-operation error
tables and descriptions the checked-in document carries, taking the generated TypeScript
client with it. So the document did not change at all in this commit; the TypeScript client
needed no regeneration.

What did change is the honesty check. `check_registry_covers_flask()` is now
`check_registry_covers_app()` and compares `ROUTES` against the union of **both** frameworks'
`/api/v2` surfaces, asking FastAPI through `app.openapi()` rather than walking its private
route objects. Under the one-commit rule neither half alone is the answer; the union is, and
a route with no contract still fails the drift gate.

## Consequences

- **Production's server changes with this commit.** `render.yaml` runs `uvicorn api.main:app`
  instead of `gunicorn web_app:app`. It is forced by the one-commit rule: `/api/v1/health` is
  Render's `healthCheckPath` and it now lives in FastAPI. Auto-Deploy is off on both services
  and the deploy is manual, so this is a human step, not a surprise.
- **`WSGIMiddleware` is deprecated upstream** in favour of `a2wsgi`, which is not a dependency
  here. It works today; the swap is one import, and it disappears entirely in Phase 11 when
  the last Flask path goes. `docs/migration-tracker.md` carries the row.
- **`WSGIMiddleware` also BUFFERS the whole request body, and the buffering is bounded
  rather than fixed (2026-09-16, critic P5A-09).** WSGI hands the application a synchronous
  `wsgi.input`, so the adapter has to read the request fully into memory before it can call
  Flask; there is nothing else it could do, and `a2wsgi` is the adapter that streams
  instead. Every upload that reaches a Flask view — a billing export, an ADP file — is
  therefore resident in the api task's 2 GB before the view sees a byte, and nothing bounded
  it. uvicorn 0.53 has no `--limit-max-request-size` flag (checked: `--limit-concurrency`,
  `--limit-max-requests`, `--ws-max-size`, and none of them bounds an HTTP body), so
  `api.main.MaxBodySizeMiddleware` does it: a `Content-Length` above
  `MERIDIAN_MAX_UPLOAD_BYTES` plus a megabyte of multipart headroom is refused with a §4
  `FILE_TOO_LARGE` envelope before the mount is reached. A **chunked** request declares no
  length and is not covered — the honest answer for one is streaming, which is `a2wsgi`.
  **That is a dependency decision for Andres**, and `docs/migration-tracker.md` carries it
  as one rather than as a task.
- **500 envelopes carry the security headers (2026-09-16, critic P5A-05).** An unhandled
  exception is turned into a response by Starlette's `ServerErrorMiddleware`, which sits
  *outside* every `@app.middleware("http")` this app adds — so the one response a browser is
  most likely to try to render was leaving without `nosniff`, `DENY` or HSTS. They are set
  in `error_response()` itself, which covers every failure path regardless of where in the
  stack it was minted.
- **uvicorn is told which peers to believe about `X-Forwarded-For` (2026-09-16, critic
  P5A-03).** It honours the header for nobody by default, so `request.client.host` was the
  ALB for every caller and `api.deps.rate_limit_key` put the whole firm in one bucket on the
  credential endpoints — the same bug commit `71decf2` fixed on the Flask side.
  `ProxyHeadersMiddleware` is applied **in `api/main.py`** with the list from
  `FORWARDED_ALLOW_IPS`, not left to the CLI flag alone, so a `TestClient` exercises the code
  the server runs. The flag reads the same variable. ECS sets it to the VPC CIDR; Render
  sets `*`, which is sound there and only there, because the service is unreachable except
  through Render's own router.
- **A wrong HTTP method on a ported path answers 404, not 405.** Starlette scores a method
  mismatch as a partial match and keeps looking; the mount at `/` is a full match and wins.
  The client still gets the §4 envelope (from `web_app`'s app-level 404 handler), just
  `NOT_FOUND` where §4.2 would say `METHOD_NOT_ALLOWED`. It resolves itself as the mount
  shrinks. Tracker row.
- **Security headers are set by both surfaces from one definition** (`src/http_headers.py`).
  A response can now leave the process without meeting Flask's `after_request`, and
  `nosniff` / `DENY` / HSTS are controls, not decoration.
- **Two frameworks to hold in your head until Phase 11.** That is the cost the alternatives
  each traded for something worse.

## Note — 2026-09-16, porting `config_routes` and `user_routes`

Two things the decision above did not settle, decided here rather than twice.

**There are five dependencies, not three.** `check_csrf`, `limit(spec)` and
`require_user` / `require_org` were the ones auth needed. Every other module gates on
more than "is there an org": `api.deps.require_permission(process, level)` is
`src.auth.require_permission` plus the `details.required` a §4.2 403 must carry (what
`routes.v2_permission` added on the Flask side), and `api.deps.require_admin` is
`require_role("admin")` without the flash-and-redirect half. They are kept apart because
the two gates are genuinely different: `config:access` is what an accountant is granted
so they can clear a blocked run, and it must not also hand them the file-naming patterns
or the ability to change who else is in the org.

**A `limit(spec)` dependency says which limit it is.** flask-limiter was introspectable
by handing `create_api_v2_blueprint` a recording stand-in, which is how the §9 limits
were asserted without sending the requests. A dependency is a plain callable, so
`api.deps.limit` tags it with `rate_limit = spec` and `tests/fastapi_support.rate_limits`
reads it back off the route. The alternative — proving a limit exists by tripping it — is
a slow test that passes for the wrong reason when the limiter is absent.

**A Flask-bound helper is split, never copied.** `routes.py` grew `org_db_for`,
`body_of`, `collection_of` and `module_enabled_for`; `_org_db`, `_body`, `_collection`
and `module_enabled` are now three-line wrappers that read `g` and call them, and they
stay only until the last module that uses them moves. This is the same move
`local_dev_user()` and `org_context()` made in the commit above, for the same reason:
two implementations of one rule disagree eventually, and the one that is wrong is
whichever one nobody was looking at.

## Note — 2026-09-16, porting `pnl_routes` (the first module with uploads)

**A multipart body is parsed by werkzeug, not by `UploadFile`.** FastAPI's own form
support is `python-multipart`, which is not installed and is not in
`requirements.txt`; adding it would spend this phase's dependency budget
(`fastapi` + `uvicorn`) on a parser the process already has. werkzeug is here
because Flask is, it stays until Phase 11 deletes the mount, and — this is the
part that matters — it is the parser that has been reading these workbooks in
production. `api/uploads.py` spools the ASGI body to a temporary file and hands
it to `werkzeug.formparser.parse_form_data`, which yields exactly the
`MultiDict` of `FileStorage` the Flask handlers took. So the shared helpers
(`oneshot_runs.select_upload`, and `file.save(path)` inside the service
functions) are one implementation serving both surfaces rather than two, and a
file accepted yesterday is accepted today because it is the same code deciding.

The cost is one more thing to remove in Phase 11 and one more reason
`a2wsgi` cannot simply replace the werkzeug dependency; the alternative — a
new package, or a hand-rolled multipart parser at the edge of a system that
uploads payroll — is worse on both counts. `docs/migration-tracker.md` carries
the row.

`MAX_CONTENT_LENGTH` keeps its meaning through this: it is read off the
mounted Flask app, so one number caps both surfaces, and exceeding it is the
§4.2 `FILE_TOO_LARGE` envelope rather than werkzeug's HTML 413.

**A workbook download is a `StreamingResponse` with `send_file`'s header.**
`Content-Disposition: attachment; filename=…` verbatim, because the SPA reads
the filename out of that header and a path crossing the mount must not change
what it finds there.

## Note — 2026-09-16, porting `oneshot_runs`

**A runs handler takes a `Caller`, not five arguments.** `config_routes` and
`user_routes` needed the org and the user id, and passing those two explicitly
was clearer than a container. A runs resource needs five things — the org, the
user, the permissions (§12.11's `viewer` is a per-process permission split, not
a role), and, for a signed-URL mint, the caller's address and user agent,
because §7.2 says the mint is audited and an audit row with no requester is
half a record. So `runs_common.Caller` is the argument that replaced `g.org`,
`g.user` and `g.permissions` for these modules: a frozen value a test builds in
one line, and — the property `g` never had — a set of facts a function five
frames down cannot reach for if it was not handed them. `org_id_or_403`,
`current_user` and `viewer_for` stay as the `g`-reading wrappers `qb_usa_runs`
still uses, over the same `org_id_of` / `viewer_from` the `Caller` uses.

**The request id is passed, not looked up.** A run envelope quotes one in
`error.request_id`, and `src/api/v2/errors.request_id()` reads `flask.g`. The
`Caller` carries the id `api/errors.py` already minted on `request.state`, so
the envelope quotes the SAME id a §4 error would have quoted for that request
rather than a second, unrelated one. `errors.request_id()` also grew a guard on
the READ (it only guarded the write): a missing request id must never be the
thing that fails a response, and the catalogue is imported by modules that now
have no `g` at all.

**The background work did not move, and was not asked to.** `create_run`,
`execute_run` and `retry_run` hand the run to the same `web_app` worker on the
same `threading.Thread` the Jinja wizard starts. Making those `async` or moving
them to a task queue is Phase 11's question, and answering it in the same
commit as a framework port would have made a change to how money is booked
indistinguishable from a change to how a URL is routed.

## Note — 2026-09-16, porting `routes.py` (the cross-cutting endpoints)

**`GET /api/v2/csrf` mints a RANDOM token, not a flask-wtf signed one.** This is the
second half of the decision above: `check_csrf` compares the `X-CSRFToken` header with
the `XSRF-TOKEN` cookie rather than verifying flask-wtf's signature, because that
signature is tied to the Flask *session* cookie. The mint had stayed on the Flask side
until now, so the token happened to be both — signed, and echoed. It cannot be both any
more. Minting one through the mount would mean pushing a Flask request context per call
and carrying a Flask session cookie this surface otherwise has no use for, to satisfy a
check nothing performs. So `routes.mint_csrf` is `secrets.token_urlsafe(32)`, and the
control is exactly the one ADR 0021 describes: an origin that cannot read the cookie
cannot produce the header.

Two consequences, both deliberate. The Jinja forms are unaffected — they have always
taken their token from `{{ csrf_token() }}` against the Flask session, not from this
endpoint, and `CSRFProtect` still guards them. And **`/me` now SETS the cookie it
reports**, which the Flask version did not have to: when both were flask-wtf tokens any
one of them validated, and now only the one in the cookie does. A `/me` that handed back
a token it had not also set would have refused the caller's next write with a control
that was working perfectly.

**`WTF_CSRF_TIME_LIMIT` and the cookie's `Secure` / `SameSite` are still read off the
mounted Flask app**, for the reason `csrf_enabled` is: one switch per setting, not two,
so the two halves cannot disagree about how long a token lives.

## Note — 2026-09-16, porting `qb_usa_runs` (the last runs resource)

**A pydantic `ValidationError` raised inside a handler is a 500 on this surface, so every
body is parsed through `routes.body_of`.** The blueprint had a `ValidationError`
errorhandler, and three of this module's handlers relied on it: they constructed
`DeclarationsIn` and `ExecuteIn` directly and let the framework turn a bad body into
§4.1's `VALIDATION_ERROR`. `api/errors.py` installs handlers for `ApiError`,
`RequestValidationError`, `StarletteHTTPException` and `Exception` — and a raw pydantic
error is none of the first three, so it would have come back as an opaque 500 the day
somebody posted `{"declared_gates": "PAYROLL_TIE"}`. `body_of` raises the `ApiError`
that answers the same 422, with the same message and the same `field_errors` keys, which
is what the SPA already parses. The handler that catches `ValidationError` itself —
`submit_review`, which answers `ROSTER_ANSWER_INVALID` rather than the generic code — was
left exactly as it was.

**`retry` is registered for a process that can never use it.** It answers 409 for every
qb-usa run, because this process has no `blocked` state, and it is never advertised in
`available_actions` (§12.8). The route is kept anyway — the contract lists the path, and
a 404 on a documented operation reads to the SPA as a deployment problem rather than as
an answer. That is the opposite of the mx-payroll case, where `retry` is *not* registered:
there the SPA is told the sub-resource does not exist at all, which is true.

**The blueprint is down to `/api/v2/dashboard`,** and `tests/test_fastapi_app.py` now
asserts that exactly — the remaining `/api/v2` surface is named, not bounded, so a route
added back by a revert or a merge fails loudly rather than quietly becoming a second
implementation of a URL FastAPI already serves. `/dashboard` is not this ADR's to move:
it lives with `web_app.py`'s own surface and goes with it. `docs/migration-tracker.md`
carries both that row and the one for deleting the now-nearly-empty blueprint
registration from `web_app.py`.

## Note — 2026-09-16, the second critic round (P5AR2)

Four findings in this round were about the edge of the process rather than about any
route, and the decisions behind their fixes belong here.

**The rate-limit key does not use `request.client`, and `--forwarded-allow-ips '*'` is why
(P5AR2-03).** The bullet above ends "Render sets `*`, which is sound there and only there,
because the service is unreachable except through Render's own router". The first half of
that is still true and the conclusion was wrong. uvicorn's `*` is
`_TrustedHosts.always_trust`, and that branch does **not** walk the forwarded chain looking
for the first untrusted hop the way the CIDR branch does — it takes `X-Forwarded-For`'s
**leftmost** entry unconditionally. The leftmost entry is written by the client. So
`request.client.host` on Render is a value the caller chooses, and a caller who chooses its
own rate-limit bucket has no rate limit: a new value in that header on every
`/api/v2/auth/login` request is an unlimited password-guessing budget, which is precisely
the control §9 exists to be.

Render publishes outbound addresses for a service, not an inbound router range, so there is
no CIDR to name and `*` stays — it is still right for `--proxy-headers`' own job, which is
resolving a client host for logs and for the address on an audited `Caller`. What changed is
that the rate limit stopped reading it. `api.deps.client_address` reads `X-Forwarded-For`
itself and takes the **rightmost** entry, and the reason it is the rightmost is structural:
each hop *appends*, so entries to the left of the one our own edge wrote came from the hop
before it, and the first of all came from the client. The rightmost entry is the one the
nearest proxy wrote about a peer it genuinely had a socket to — the last one nobody
downstream could forge. `web/src/lib/proxy.ts` closes it a second time, independently, by
dropping every inbound entry but that one before the request leaves the web container.

**The body-size guard counts bytes, because the proxy sends none of them with a length
(P5AR2-02).** `MaxBodySizeMiddleware` shipped as a `Content-Length` check, on the stated
reasoning that a chunked request is honestly bounded only by streaming and that every
browser upload declares a length. Browsers do. The Next.js route handler in front of them
does not: it forwards `request.body` as a stream, and the fetch runtime frames a stream as
`Transfer-Encoding: chunked`. So in the only deployment that exists, every upload arrived
chunked and the check never fired once. The middleware now wraps `receive` and adds up what
it passes through, which bounds a body by what it is rather than by what it says; the
proxy also forwards an inbound `Content-Length` so the cheap check can still refuse a
request before it is read. `a2wsgi` remains the fix for the buffering itself.

**`--limit-concurrency` is gone from all three start commands (P5AR2-08).** It was
described as "the server refuses at the door rather than queueing invisibly", sized at
twice `PG_POOL_MAX`. uvicorn's counter is per **connection** and is held for the whole life
of a keep-alive connection, not per request in flight — so it refused the seventeenth idle
browser tab while a hundred requests on the sixteen connections it had already counted went
through untouched. A bound that fires when there is no load and not when there is, is worse
than none. The permit in `src/pg.py`, sized to `PG_POOL_MAX` and waited on for
`PG_POOL_TIMEOUT` (ADR 0022), is what actually bounds database pressure, and `PoolTimeout`
names the real constraint when it is reached.

**`ORG_REQUIRED` is enforced in `require_org`, not in each service function (P5AR2-01).**
`src.auth.org_context` hands a superadmin with no membership row a system context whose
`org_id` is `None`; on the Flask side the first line of every v2 service function is
`org_id_or_403()`, which refuses it. The FastAPI routers pass `identity.org_id` straight
into the same services and `oneshot_runs` passed `identity.org_id or ""`, so that caller
reached writes with an org id no organization has. `api.deps._attach_org` now calls the
same `runs_common.org_id_of` on the row it just resolved, so there is one gate, it is on
the dependency every tenant-scoped route already declares, and it answers the sentence
Flask answered.

## Note — 2026-09-16, porting `/dashboard` and deleting the blueprint

**`/api/v2/dashboard` was the last path, so the blueprint is deleted rather than left
empty.** The one-commit rule says a path leaves Flask in the commit that lands it in
FastAPI; it says nothing about the factory that registered them, and the honest reading
of "never both, never neither" is that a `create_api_v2_blueprint` which builds an empty
blueprint is a place a route can be added back without anybody having to decide which
framework owns it. So it went, together with its registration and import in `web_app.py`,
its `_register_error_handlers`, `errors.translate_auth_error` and `ApiError.to_response`
— all of which had exactly one caller each, and that caller was the factory.
`api/errors.py` is now the only §4.1 handler there is. `tests/test_fastapi_app.py`
asserts the Flask `url_map` holds **zero** `/api/v2` rules, which is a stronger statement
than the named set it held before and the one that stays true from here.

**The drift gate stopped asking Flask.** `live_v2_operations()` was described above as
the union of both frameworks' `/api/v2` surfaces, on the reasoning that neither half
alone was the answer under the one-commit rule. There is no Flask half any more, so the
union is FastAPI's set and the Flask branch was a stand-in app built to be walked for
nothing. It asks `app.openapi()` alone now. Nothing escapes the gate by this: the
registry is still compared to what the process serves, and the zero-rule assertion in
`tests/test_fastapi_app.py` is what would catch a route re-added to Flask — loudly, in a
test, rather than silently by being excluded from a comparison. `openapi/meridian-v2.json`
is byte-identical, as it has been for every port in this phase.

**The last three `g`-reading wrappers went with the route they existed for.** The note on
`config_routes` above said a Flask-bound helper is split, never copied, and that the
wrappers "stay only until the last module that uses them moves". This is that moment:
`routes.module_enabled`, `routes._permissions_map`, `routes.v2_permission`,
`runs_common.org_id_or_403` and `runs_common.current_user` are deleted, and
`src/api/v2/` no longer imports `flask` anywhere except `errors.py`, which still mints
and reads a request id off `g` for the Jinja surface's own 404 and 405 handlers.
`auth_routes.dashboard()` takes the org, the user, the permissions and the modules as
arguments, like every other service function in the package.

**`ORG_REQUIRED` still comes from one place.** The router passes
`identity.required_org_id`, which is `runs_common.org_id_of` — the same rule and the same
sentence `org_id_or_403` produced, on the dependency rather than in the handler
(P5AR2-01). A superadmin with no membership row is refused, not served with
`org_id=None`.

## Note — 2026-09-16, the third critic round (P5AR3)

**The rate-limit address is the first UNTRUSTED entry from the right, not the rightmost
one (P5AR3-02). This replaces the round-2 paragraph above.** That paragraph's reasoning —
each hop appends, so the rightmost entry is the one nobody downstream could forge — is
still true and still not sufficient, because it assumed the process sits behind exactly one
proxy. On AWS it sits behind three. `MERIDIAN_API_ORIGIN` is the environment's own public
hostname (ADR 0020 and the tracker row on the doubled CloudFront hop), so a request the
`web` task proxies reaches the api having been through CloudFront twice, and
`X-Forwarded-For` reads `cfEdge1, natEIP, cfEdge2`. The rightmost entry is a CloudFront edge
node shared by every request on that path: one rate-limit bucket for the estate, which is
the failure §9 exists to prevent arrived at from the opposite direction. On Render the same
rule lands on the proxy's egress address with the same effect.

So `api.deps.client_address` now does what the header was designed for and what uvicorn's
own CIDR branch does: it walks `X-Forwarded-For` from the right, skips every entry inside
`FORWARDED_ALLOW_IPS`, and takes the first one that is not. `*` — which `render.yaml` must
use — means "trust the immediate peer and nothing else", so exactly one rightmost entry is
skipped. Anything left of the first untrusted entry is never read, which is what makes a
forged leftmost entry worthless. `web/src/lib/proxy.ts` stopped collapsing the chain to one
entry and passes it through intact: the API is the hop that holds the trust list, so it is
the hop that gets to decide which entries are infrastructure, and throwing entries away in
front of it destroyed the evidence rather than protecting anything.

Three residuals, written down because none of them is fixed by the above:

* **The precise answer is `CloudFront-Viewer-Address`, and it is not forwarded today.**
  ~~Until the origin request policy changes the AWS answer is `cfEdge2`.~~ **Superseded by
  the round-4 note below**, which forwards the header — and by the round-5 note, which
  corrects what the chain in front of it is: browser → CloudFront → ALB → api, one pass,
  with no `web` hop in it.
* **The app cannot verify that a request came through CloudFront.** Every ALB listener rule
  requires `X-Origin-Verify` (`edge.py`), so on AWS an ALB request has come through the edge
  by construction — but the secret lives in Secrets Manager and the api task is given the
  database password and nothing else, so there is no expected value in the process to
  compare against. The stand-in is `FORWARDED_ALLOW_IPS` being a CIDR, which is true of the
  ECS task definition and of no other deployment (Render `*`, development `127.0.0.1`). The
  assumption is therefore *a deployment that names a CIDR is the origin-verified ECS one*,
  and it is recorded here rather than left implicit in the code.
* **The `web` task appends nothing to the chain.** A proxy is supposed to append the peer it
  saw; a Next.js Route Handler is handed a web `Request` and nothing else (Next 15 removed
  `NextRequest.ip`, and the standalone server exposes no peer address), and this deployment
  has no platform header naming one. Inventing the container's own address would be worse
  than sending none, because a fabricated address is a bucket everybody shares. The
  consequence is that the API sees the hop *before* the web container rather than the web
  container itself, which on AWS is the CloudFront edge in front of it.

**The rate-limit bucket now includes the endpoint (P5AR3-04).** `RateLimiter` keyed on
`(spec, key)`, and `5/minute` is the spelling on `/auth/login`, `/auth/mfa`,
`/auth/forgot-password`, `/auth/reset-password` and three more — so one caller's five login
attempts spent the allowance for password reset as well, and a legitimate user locked
themselves out of recovery by mistyping a password. flask-limiter's decorator is per view
function and §9 lists the limits per operation; the key is now `(spec, route path, caller)`,
which is that. The route TEMPLATE path, so `/runs/{run_id}` is one bucket rather than one
per run.

**The two qb-usa write limits are this surface's own, not flask-limiter's (P5AR3-08).** The
module said "the same strings flask-limiter was given". `LIMIT_READ` is; `10/minute` on
create/execute and `30/minute` on the steps are new, because the Jinja wizard's POSTs carried
no per-view limit at all. They are a judgement about what a person doing a payroll run can
produce, and the docstring says so rather than claiming a parity that does not exist.

**`__Host-XSRF-TOKEN` where the cookie is `Secure` (P5AR3-10).** The readable CSRF cookie was
`XSRF-TOKEN` at every origin. Without the `__Host-` prefix any host under the registrable
domain can set that cookie for the parent, and a double-submit check then compares an
attacker-chosen cookie with an attacker-chosen header and passes. The prefix is refused by
browsers without TLS, so the name follows `SESSION_COOKIE_SECURE`: prefixed in deployment,
bare in development. `check_csrf` and the SPA's `readCsrfToken` read whichever arrived,
preferring the prefixed one, so a browser holding the old cookie across a deploy is not
locked out of its next write.

**The CI deploy boundary was overstated, in five places (P5AR3-03).** Round 2 recorded that
`meridian-shared-iam-github-deploy` "has CloudFormation permission on the compute stack
alone", so `auth` and `data` were unreachable from CI "by two independent mechanisms". The
statement exists, but it is not the path a deploy takes: `cdk deploy` assumes
`cdk-hnb659fds-deploy-role`, created account-wide by `cdk bootstrap` and passing an
`AdministratorAccess` execution role. The real boundary is `--exclusively` on the deploy
command plus a trust policy naming two branches of one repository, and the workflow,
runbook, control matrix, module docstring and test now say that. The tracker row that makes
the IAM half true — a staging-only bootstrap qualifier with scoped
`--cloudformation-execution-policies` — is owned by Andres and due before the first dispatch.

## Note — 2026-09-16, the fourth critic round (P5AR4)

**The rate-limit address is the viewer's, because the SPA path crosses CloudFront exactly
once now (P5AR4-02). This closes the first round-3 residual and rewrites the tracker rows
behind it.**

The round-3 residual said the fix was one line: flip `edge.py`'s origin request policy from
`ALL_VIEWER` to `ALL_VIEWER_AND_CLOUDFRONT_2022` and `CloudFront-Viewer-Address` would
arrive. That was wrong, and wrong in the dangerous direction. The path was
browser → CF → ALB → web → **CF** → ALB → api, because `MERIDIAN_API_ORIGIN` was the
environment's own public hostname: the ALB cannot be dialled directly by a caller with no
origin-verify header. **CloudFront rewrites `CloudFront-Viewer-Address` on every pass**, so
the second pass would have replaced the viewer's address with the NAT gateway's, and the
api would have read one address for every SPA request in the estate. Flipping the policy on
its own would have turned a coarse bucket (a CloudFront edge, shared by many viewers) into
a single bucket (one NAT, shared by all of them) — the §9 failure, delivered by the change
meant to fix it.

So the fix was taken to be the hop, and the policy second:

1. ~~**`MERIDIAN_API_ORIGIN` is `https://origin-<env>.meridiansgrp.com`** — the ALB dialled
   directly, with the origin-verify header injected into the `web` task as a third consumer
   of the secret, and a `/32` ALB ingress rule for this VPC's NAT address to make that hop
   reachable.~~ **Superseded by the round-5 note below: the hop this describes does not
   exist on ECS, so the secret entry, its grant and the `/32` rule were deleted.**
2. **`ALL_VIEWER_AND_CLOUDFRONT_2022`**, which forwards the `CloudFront-*` family. This
   stands. With one pass in front, the header the api reads is the edge's statement about
   the VIEWER's own socket, and `api.deps.client_address` already prefers it over walking
   the chain.

**The real chain is browser → CloudFront → ALB → api, one pass, and always was.** The ALB
forwards `/api/*` to the `api` target group itself; the SPA's calls never touch the `web`
container in either direction. What round 4 got right is the conclusion — one CloudFront
pass, so `CloudFront-Viewer-Address` is the viewer's — and what it got wrong is the reason,
which it took to be a proxy hop it had just re-pointed.

**Why the header can be believed** (the second round-3 residual, narrowed rather than
closed): the api still cannot check the origin-verify secret itself, and the stand-in is
still `FORWARDED_ALLOW_IPS` being a real CIDR. Behind that: the ALB admits CloudFront's
managed prefix list and nothing else, every listener rule demands a secret only CloudFront
holds, and CloudFront replaces any `CloudFront-*` header a viewer sends. That last one is
AWS's documented behaviour rather than something this repository can test, so it is
verified by hand on staging — `docs/runbooks/deploy-staging.md` §7.2 (P5AR5-04).

**What is still true from round 3:** the `web` task appends nothing to `X-Forwarded-For`,
so where that proxy does run — development and Render — the chain the api walks names the
hop before the container rather than the container. On ECS it is moot: the api's callers
do not come through it.

## Note — 2026-09-16, the fifth critic round (P5AR5)

**The `web`→api proxy hop does not exist on ECS, so the third origin-verify consumer is
deleted (P5AR5-01).**

`web/src/lib/proxy.ts` is a set of Next.js route handlers under `/api`, `/auth` and
`/static`. On ECS the ALB's listener rules forward exactly those prefixes
(`PINNED_API_PATH_PATTERNS`, generated from `next.config.mjs` by
`infra/meridian/edge_paths.py`) to the `api` target group, at priorities ahead of the `/*`
rule that reaches the `web` task. **The request is answered before Next.js is asked**, so
the hop round 4 re-pointed at `origin-<env>` never happens there, and everything built to
support it was serving a path nothing takes. Deleted:

* the `MERIDIAN_ORIGIN_VERIFY` `secrets:` entry on the `web` task definition, and the
  execution role's grant to read that secret (`compute.py`);
* the `/32` NAT ingress rule on the ALB security group (`edge.py`'s
  `_alb_ingress_from_nat`), so the security group is back to CloudFront's managed prefix
  list alone;
* step 3a of `docs/runbooks/rotate-origin-verify-secret.md` and its third-consumer table
  row — a rotation is two deploys of one stack again;
* ADR 0018 §7's third-consumer paragraph;
* `X-Origin-Verify` sending in `proxy.ts`. There is no value to send; an inbound one is
  stripped, because only CloudFront's may travel upstream.

**Where the route handlers ARE live: development and Render.** Locally nothing sits in
front of Next.js, and on Render there is no ALB with rules of its own, so those handlers
are what makes `/api/*` reach Flask at all — which is why they stay rather than being
deleted with the rest. `MERIDIAN_API_ORIGIN` is the api's public hostname there. On ECS
the variable is still set, to the environment's public hostname, because an unset value
falls back to `http://localhost:5050`; it is documented in `compute.py` as unused.

**The claim is enforced, not asserted.**
`test_the_alb_claims_every_proxy_handler_prefix` in `infra/tests/test_edge.py` reads
every route handler that imports
`@/lib/proxy` and fails unless an ALB api rule pattern covers its prefix. A new
`web/src/app/<x>/[...path]/route.ts` with no matching rule would be live on AWS — sending
a request back out through the edge and re-writing `CloudFront-Viewer-Address` on the way,
which is the P5AR4-02 failure arrived at from the other end.

**What did NOT change:** `ALL_VIEWER_AND_CLOUDFRONT_2022` and `client_address`'s
preference for `CloudFront-Viewer-Address`. They were right for a reason round 4 stated
imprecisely — the chain is browser → CloudFront → ALB → api, one pass — and they are right
on the one-pass chain that actually exists.

**The WAF is not bypassed for `/api/*`.** The web ACL is `CLOUDFRONT`-scoped and every
`/api/*` request reaches the api *from* CloudFront, inspected like any other. The
in-app limiter (`api.deps.RateLimiter`, §9) is the layer that would still cover a
web-originated call if a future `/bff/*` prefix ever created one.

## What stays Flask, and until when

| Surface | Moves in |
|---|---|
| ~~`/api/v2`~~ — `routes`, `config_routes`, `user_routes`, `oneshot_runs`, `qb_usa_runs`, `pnl_routes`, `/dashboard` | **5a, done.** One module per commit; the blueprint was deleted with the last of them. |
| The Jinja screens still in `next.config.mjs`'s rewrite allowlist | **5b** (React screens), then the routes are deleted |
| The three process wizards and the rest of the `render_template` surface | **11** (process framework) |
| `web_app.py`, `templates/`, the mount itself | **11** — deleted in the commit that retires the last Flask path |
| `/api/v1` | **12**, when `/api/v3` covers it (D-25) |

`docs/migration-tracker.md` holds a row per unported module with its owning phase.
