# ADR 0038 — Webhooks: outbox, EventBridge, SQS, a separate sender, and a pinned-IP SSRF guard

**Date:** 2026-09-24
**Status:** Accepted (the SSRF guard, pinned sender and signing are built — T10, commit
`6086741`; the engine, subscriptions API and sender Lambda adapter are T11 —
`src/webhooks/{engine,ports,subscriptions}.py`, `api/v3/routers/webhooks.py`,
`lambda/webhook_sender/handler.py`; the worker's outbox write and the
infrastructure follow in T19, T21)
**Source:** `docs/reports/phase-12-plan.md` §3.7, R7-R9, T10, T11, T19, T21; ADR 0015 (edge),
ADR 0024 (alarms)
**Numbering note:** planned as "0030" in the Phase 12 plan; renumbered (Phase 11 holds 0027-0034).

## Context

A **webhook** is Meridian calling a partner's URL when something happens (`run.completed`),
instead of the partner polling. It has three hard problems:

1. **SSRF (server-side request forgery).** The partner chooses the URL, so the partner can aim our
   server at an address only our server can reach — the AWS metadata address `169.254.169.254`
   hands out credentials. **DNS rebinding** makes it worse: a hostname can resolve to a public
   address when we check it and a private one a moment later when we connect.
2. **Events must match what really happened.** An event announced for a change that rolled back,
   or lost for one that committed, is a wrong message to a partner's accounting system.
3. **Tenancy can change between enqueue and delivery.** A subscription paused or a client revoked
   an hour ago must not still receive the retry.

## Alternatives considered

**Send from the Phase 11 worker instead of a separate Lambda.** The strongest case: one fewer
deployable, no Lambda packaging of psycopg2 for arm64, and the worker already reads the run. It is
rejected because the worker reads PHI and posts to QuickBooks; the webhook sender calls arbitrary
internet URLs. Putting both in one process gives one IAM role and one security group to "reads
PHI" and "talks to anyone". Reversing costs a second container in the worker task with its own
task-role split (~1-2 days). Trigger: Lambda packaging of psycopg2 fails on arm64 (plan R7).

**Direct SQS from the outbox publisher, no EventBridge.** One hop fewer. Kept EventBridge because
it is effectively free ($1 per million events) and lets a later consumer (an audit sink) subscribe
without touching the publisher. Trigger: latency or cost problem (R8).

**Validate the URL once at subscribe time only.** Rejected: that is exactly what DNS rebinding
defeats.

## Decision

1. **Outbox.** The worker writes an `api_events` row in the same transaction as the run's state
   change; after commit it calls `PutEvents`; a five-minute sweep republishes rows still unpublished.
   Payloads carry ids only (`run_id`, `process`, `state`) — no org id, no PHI.
2. **Path:** EventBridge bus `meridian-<env>-events` → rule → SQS `meridian-<env>-sqs-webhooks`
   (KMS-encrypted, DLQ after 8 receives) → Lambda `meridian-<env>-lambda-webhook-sender` in the VPC
   with its own security group (443 out, 5432 to RDS) and role; reserved concurrency 2.
3. **Tenant re-check on every attempt.** The sender re-reads the delivery, subscription, client and
   run under `with_org(delivery.org_id)`; if the orgs disagree, the subscription is not active, or
   the client is not active with `webhooks:manage`, the delivery is marked `dropped` with a reason
   code and nothing is sent.
4. **SSRF guard, at subscribe time and at every attempt** (`src/webhooks/ssrf.py`): `https`, port
   443, no IP-literal host, every resolved A/AAAA answer public (private, loopback, link-local
   including `169.254.0.0/16` and `fd00:ec2::254`, CGNAT, reserved, IPv4-mapped forms unwrapped,
   plus configured blocked CIDRs). Then **connect to the IP that was checked** and verify the
   certificate against the hostname (`src/webhooks/sender.py`), never following redirects; 3 s
   connect, 10 s total, response body capped at 4 KB (`sender.py:42-44`). A refused URL answers
   one generic `WEBHOOK_URL_REJECTED` so the endpoint cannot be used to probe our DNS.
5. **Signature contract** (`src/webhooks/signing.py`): `Meridian-Event-Id` and
   `Meridian-Signature: t=<unix>,v1=<HMAC-SHA256(secret, "<t>.<event_id>.<body>")>`; receivers
   reject `|now − t| > 300 s` and de-duplicate on event id; during a 24-hour rotation overlap two
   `v1=` values are sent. The event id is unique per subscription (amendment 12).
6. **Secrets:** one Secrets Manager secret per subscription (`{current, previous,
   previous_expires_at}`), on the artifacts CMK; the sender reads only `meridian-<env>-webhook-*`.
7. **Retries:** immediate, then ≈ 1 m, 5 m, 30 m, 2 h, 6 h, 12 h, 12 h → DLQ; a subscription
   auto-pauses after 5 consecutive dead deliveries; redrive re-enqueues the delivery id and the
   tenant re-check runs again. A DLQ-depth alarm goes to `alerts.md`.

### Amendments (Stage 1 critic fixes, 2026-09-25)

Recorded here so the decision and its bounds live in one place (critic Stage 1 round 2 L19);
the detail is in each module's docstring.

8. **No mock persistence outside development** (critic r1 H-2): `src/webhooks/ports.adapters_from_env`
   raises `WebhookConfigError` unless the whole AWS set is present; `api.main.create_app` checks it
   whenever `/api/v3` is mounted, and (round 2 M1) `workers.main` checks the worker's half — the
   bus and the queue — before its first receive (`ports.check_worker_configuration`). CDK sets
   `MERIDIAN_API_V3` only with `enableApiPlatform` and copies it to the worker.
9. **Local development is real, not faked** (H-2): `src/webhooks/local.py` — signing secrets sealed
   in `public.webhook_local_secrets` (revision 0025; AES-GCM, AAD = purpose + org + ref, the
   development key), and a drainer thread started and stopped by the api's lifespan (round 2
   L1/L2). Refused wherever `settings.dev_fallbacks_permitted()` is false.
10. **A database-side sweep for lost messages** (r1 M-8): revision 0025's
    `app.due_webhook_deliveries(grace, limit)` (definer, ids only, bounded, partial index on
    `COALESCE(next_attempt_at, created_at)`) lists open deliveries past due; the worker's 5-minute
    outbox tick (ADR 0045) and the local drainer re-enqueue them. The claim stays the engine's
    conditional UPDATE. A redrive sets `next_attempt_at` to now (round 2 L6), so the sweep's grace
    runs from the redrive.
11. **Bounded third-party traffic** (r1 M-7, round 2 M2; spacing per Andres 2026-09-25): redrive
    at most 3 times per delivery, never for an event older than 7 days, and at most 1 per
    subscription per 30-second window; `/test` at most 1 per subscription per 30-second window and
    60 per org per hour — all through `api/v3/quotas.cap` (fixed windows on the database clock:
    a refusal is `429 QUOTA_EXCEEDED` with `Retry-After` = seconds left in the window), all
    audited. The 30-second windows replaced "20 redrives / 10 pings per subscription per hour".

### Amendment (Stage 2 N7, 2026-09-25)

12. **One event id per subscription.** An event fans out to every subscription that wants it,
    and each delivery carries its OWN `Meridian-Event-Id` (and payload `id`): the
    `webhook_deliveries` row id. Before this, every subscription got the `api_events` id, so a
    receiver serving two subscriptions that followed decision 5 ("de-duplicate on event id")
    dropped the second copy as a replay. Chosen over a new `Meridian-Delivery-Id` header because
    the id is already inside the signed string `"<t>.<event_id>.<body>"` — a separate header would
    need a new signature scheme (breaking every verifier) or it could be swapped to dodge a replay
    cache — and because receivers following the documented rule are correct with no change. It
    is stable across retries and redrives (both reuse the row). A receiver that wants one action
    per run, whichever subscription told it, keys on `data.run_id` + `type`. The delivery log's
    `event_id` is the internal id grouping one event's deliveries; the id a receiver saw is the
    delivery's `id`.

## Consequences

- About $0.40/month per subscription (Secrets Manager); EventBridge, SQS and Lambda sit in their
  free tiers at this volume (plan §8.2).
- Receivers must implement the verify step; the generated TypeScript and Python clients ship a
  helper (ADR 0043).
- The worker's state-change transaction gains one insert.

## Trigger to revisit

- psycopg2 on arm64 Lambda proves unworkable → sender as a second worker container (R7).
- A receiver needs ordering between events of one run → FIFO queue per subscription.
- Delivery volume outgrows reserved concurrency 2 (sustained queue age > 5 minutes).
