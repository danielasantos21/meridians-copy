# ADR 0032 — Idempotency table and the QuickBooks posting algorithm

**Date:** 2026-09-24
**Status:** Accepted and built: the ledger, the `Idempotency-Key` header and the requestid rule (E1,
E3), and the `qbo_push` job and `scripts/qbo_post_je.py` that post through it (E2, 2026-09-24:
`src/qbo_posting.post_journal_once`). Amended 2026-09-25 (Stage 1 critic H-3/H-4): on RDS EVERY push
posts through it — the request path too while qb-usa is not routed — and an attempt in flight is
never resent (decision 7). Amended 2026-09-25 (CODEX-1): an attempt settles a failure only on the
row it still holds (decision 7, last bullet). Supabase keeps its request path (tracker T:195).
**Source:** `docs/reports/phase-11-plan.md` §3.7 (Codex PS-11), §7.3 ("Intuit's `requestid` replay
window is unknown"), tasks E1-E3; api-v2-contract §12.9; revisions `0012_job_idempotency` and
`0018_push_claim_and_input_digest`; `src/idempotency.py`, `src/api/v2/execute_idempotency.py`
**Related:** ADR 0010 (an idempotency table instead of Redis), ADR 0030 (leases)

## Context

The migration prompt's hardest rule: jobs are safe to retry and must **never double-post a journal
entry to QuickBooks**; persist an idempotency record before the QBO call, use Intuit's `requestid`,
and follow contract §12.9 (`Idempotency-Key` header, duplicate input a warning, not a block). Today
the protection is a DocNumber pre-check plus a *derived* `requestid`
(`qbo_client.journal_request_id(org, batch, DocNumber, TxnDate)`); nothing is written before the
call. Intuit replays the stored response for a `requestid` it has seen, for a window nobody here can
pin down, and it may do so for a failed request too.

## Alternatives considered

**Intuit's `requestid` alone.** Its strongest case: it is Intuit's own control and it closes the
lost-response window without any table. Rejected as the only layer: the window is undocumented here,
it cannot see an entry keyed into QuickBooks by hand, and nothing records what was sent.

**Reuse the same `requestid` on every retry.** The strongest case: a retry can then never book twice,
whatever happened. Rejected for *definite* failures: after Intuit answered a 4xx (nothing created),
the same id may be answered with the cached failure for the whole window, so a journal whose cause
was fixed (a missing account, a closed period) could not be posted again. A new id there cannot
double-post, because nothing was created.

**A new `requestid` on every retry.** Rejected for *ambiguous* failures (timeout, 5xx, lost response):
the first request may have booked the journal, and a new id would book it again.

**Store the remote response body.** Rejected: size, and a JE response carries amounts and names.
Ids only.

## Decision

1. **`public.job_idempotency`** (0012): `(org_id, scope, idempotency_key)` primary key, scopes
   `run.execute` and `qbo.journal`, a sha256 request fingerprint, `state pending|completed|failed`,
   `remote_result` (remote ids only), FORCE RLS on `app.org_id`, no DELETE or TRUNCATE for
   `meridian_app`, a run reference that cannot cross orgs. The create step keeps its own
   `process_runs.idempotency_key`; it is not duplicated.
2. **`begin` → remote call → `settle`** (`src/idempotency.py`): `begin` answers `new`, `completed`
   (return the stored ids), `pending` (an earlier attempt never settled: reconcile first) or `retry`
   (an earlier attempt definitely failed). The same key with another fingerprint is a conflict.
3. **QBO posting (task E2)**, per journal, key = the journal's first `requestid`: `completed` → done;
   `pending` → re-query QuickBooks by DocNumber; found → `completed`; not found → resend with the
   **same** `requestid`; `new`/`retry` → post with `claim.record["qbo_request_id"]`. As built
   (`src/qbo_posting.post_journal_once`), `new`/`retry` also ask QuickBooks for the DocNumber first
   — the pre-check the push always had, which catches an entry keyed in by hand — and the job settles
   the run back into `completed` whatever came of the journals, with a per-journal code in
   `run_state.quickbooks_push`; pressing "Send to QuickBooks" again is a new job the ledger makes safe.
4. **Which `requestid` a retry sends** (this ADR's open question, decided): classify every failed call
   with `failure_kind(status)`. **Ambiguous** (no response, 5xx, 408) → leave the row `pending`; the
   resend reuses the same `requestid`. **Definite** (any other 4xx) → `settle('failed')`; the next
   `begin` rotates to `attempt_request_id(first, n)` — sha256 of the first id and the generation,
   truncated to 50 — and appends the superseded id to `qbo_request_id_history` (0018, at most 20;
   the 21st definite failure is refused as "needs a person"). The ledger therefore records every
   `requestid` ever sent for a journal. If a pending resend with the reused id is answered by a
   replayed definite failure, that answer is itself definite and the next attempt rotates.
5. **`Idempotency-Key` on `execute`/`retry`** (E3, contract §3.2): the `run.execute` scope, key
   `"<process>:<header>"`, fingerprint `{process, run_id, action, body}`. A repeat replays the run; a
   different request is `409 IDEMPOTENCY_CONFLICT` (`payload_mismatch`); a request still in flight is
   `409` (`in_progress`) and never runs twice; a refusal before the effect is settled `failed` and not
   cached.
6. **`DUPLICATE_INPUT`** is a warning on the run (`details.previous_run_id`), never a block, found
   through `app.input_digest(inputs)` (0018) over the recorded input sha256s.
7. **An attempt in flight is never resent** (2026-09-25, Stage 1 critic H-4). `pending` is also what a
   LIVE attempt looks like, and a second attempt that resent it would put two identical creates in
   front of Intuit at once — whose requestid cache is not documented to deduplicate concurrent
   requests. So, per journal:
   * `begin(..., in_flight_seconds=IN_FLIGHT_SECONDS)` answers `in_flight` for a `pending` row whose
     `updated_at` (when the attempt holding it began, by the database clock) is younger than the
     window — nothing is looked up or sent (`QBO_IN_FLIGHT`); an older row is TAKEN by re-stamping
     `updated_at` in the same locked transaction, so of two attempts exactly one reconciles it. `new`
     and `retry` stamp it too.
   * `renew()` re-stamps the row just before the create, only if the stamp is still the one this
     attempt took; otherwise `QBO_IN_FLIGHT`. The window then covers the create itself.
   * The window is the push job's lease (600 s, `qbo_posting.IN_FLIGHT_SECONDS`, pinned equal to the
     `qbo_push` JobSpec by a test), far longer than one create (90 s timeout). A retry right after an
     ambiguous failure waits it out: the timed-out create may still be running at Intuit.
   * **A failure is settled only by the attempt that holds the row** (2026-09-25, CODEX-1). The
     stamp is also the fence on `failed`: `idempotency.fail_held(db, scope, key, stamp)` is ONE
     conditional UPDATE (`state = 'pending' AND updated_at = stamp`). A build failure settles with
     the stamp `begin` handed the attempt (no renew first); a definite create failure with the
     stamp `renew` returned. Before, `settle(..., 'failed')` matched any `pending` row, so an
     attempt that paused past the window between its renew and its settle could fail the row a
     second attempt had taken and was creating under; a third attempt then rotated the requestid,
     found nothing yet, and created the journal again. `tests/test_qbo_fail_fence_pg.py` holds the
     interleaving (one journal) with a known-bad control (two).
   * The job re-checks before EACH journal: `shared.keep_alive` (a lost lease, or a heartbeat the
     database did not record, stops it with `LEASE_LOST`, which the worker releases for redelivery
     instead of settling) and `quickbooks_push.job_id` (a newer push stops it). The worker's writes
     are fenced on a LIVE lease (owner, job, `lease_expires_at > now()`), the same predicate as the
     state-object writes.

## Consequences

- Every remote effect is written down before it is attempted, and every `requestid` sent is recorded.
- A process killed between `begin` and an execute's first write leaves that key `pending` for good;
  the client sends a new key. The row stays as evidence.
- `scripts/qbo_post_je.py` goes through the same helper on RDS (plan §7.1's default, E2) and writes
  the requestid it used to `qb_export_tie_out.qbo_request_id`.
- One posting implementation on RDS: the `qbo_push` job and the unrouted request both call
  `push_batch_once`; a push that cannot start answers a code (`QBO_PUSH_REFUSED` +
  `details.reason`), never QuickBooks' wording.
- A journal whose attempt ended without an answer (or whose worker was killed mid-create) is held for
  the in-flight window before anyone may resend it; the screen says `QBO_IN_FLIGHT` and pressing
  again after the window is safe.

## Trigger to revisit

- Intuit documents its replay window and its behaviour for failed requests → drop the rotation if a
  failed request is never replayed, or bound `pending` by the window.
- The QBO sandbox (task I4) shows a replayed failure for a reused id after an ambiguous error → have
  the reconciler settle `failed` once the DocNumber re-query proves absence, so the next attempt
  rotates.
- `pending` rows older than a day appear in production → a reconciliation report for a person.
- Intuit documents that concurrent requests with one `requestid` create one entry → decision 7's
  window can shrink to the create timeout.
