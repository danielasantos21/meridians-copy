# ADR 0005 — Data layer: psycopg2 repository layer, no SQLAlchemy, three-revision Alembic baseline

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §2.2, decisions D-21 and D-08

## Context

Data access today is `supabase-py`, which speaks to Supabase's PostgREST HTTP layer —
**202 `.table(...)` call sites** — 194 in `src/` + `web_app.py` (`src/database.py` 63,
`web_app.py` 47, `src/api/v2/*` 26, `src/auth.py` 11, the rest across small modules) and 8
in `scripts/`. The plan's older figure of 188 was a running subtotal;
`docs/compliance/inventory-data-layer.md` is the authoritative count. On top of those there
are 8 places already using raw `psycopg2`. Moving to RDS means every one of those call sites becomes SQL.

Three choices had to be settled:

1. **A compatibility shim** that re-implements `.table()` over psycopg was rejected in
   plan v2 and stays rejected: it would keep ~7,600 lines of fake-Supabase tests green
   while they verify nothing real.
2. **SQLAlchemy** (an ORM/query builder) would generate SQL for us — but it hides the
   `org_id` predicate that our CI lint reads, and it is a large new dependency for one
   developer still learning.
3. **The migration folder is not the source of truth.** `fiscal_calendar` (6,209 rows) and
   `qgenda_workspaces` have no migration file; **`027_invite_codes_email.sql` *was*
   applied** — `invite_codes.email` is live, and the claim that it never ran was wrong
   here, in the plan and in both READMEs until the 2026-09-15 dump settled it;
   ~12 declared `REFERENCES auth.users(id)` foreign keys do not exist live; six
   `updated_by`/`changed_by` columns are `TEXT` live but `UUID` in the file; two files
   share the prefix `013`. Replaying the 37 files verbatim produces a schema that is **not**
   production's. But the prompt also (rightly) says not to rewrite them.

## Decision

**A thin psycopg2 repository layer. No SQLAlchemy. No shim. No async.**

- Raw SQL behind unchanged `Database` method signatures, `RealDictCursor`, and adapters
  that reproduce PostgREST's JSON shapes exactly: `DEC2FLOAT` so `numeric` matches across
  the 18 numeric columns, `uuid → str`, `jsonb → dict`.
- Autocommit-by-default connections with an explicit `transaction()` for the three genuine
  multi-statement units (`delete_batch`, `create_batch_superseding`, `redeem_invite_code`).
- `COPY` — never `execute_values` — for every `phi.*` bulk write, because psycopg2
  interpolates literals client-side and they would land in Postgres logs.
- `INSERT … ON CONFLICT DO UPDATE SET <payload columns>` (never `EXCLUDED.*`) for the
  7 upserts; parameterized `ILIKE` for the 4 `.or_()` filters (this also fixes a live
  injection bug); `RETURNING` wherever `result.data` is read back.
- psycopg2 rather than psycopg 3: it is the installed dependency, already proven here, and
  its adapters already match PostgREST. Zero new technology.
- Sync, not async: the workload is batch and the api task count is 1.

**Schema managed by Alembic, baselined in three revisions** so the 37 files stay
unrewritten *and* the result matches production:

- **0001 `baseline_supabase`** — replays the 37 SQL files verbatim in filename order
  (exactly what `deploy/aws-trial/apply_migrations.py` proved works from an empty
  PostgreSQL 17). Nothing rewritten.
- **0002 `reconcile_live_drift`** — the diff between the replayed schema and a
  `pg_dump --schema-only` of live Supabase, committed together with the dump it came from.
- **0003 `rds_adaptations`** — strip `REFERENCES auth.users(...)`; replace
  `public.user_org_id()` (which read Supabase JWT claims) with
  `current_setting('app.org_id', true)::uuid`; drop the `anon`/`authenticated`/
  `service_role` grants; skip `003_storage_buckets.sql`'s effects; create the `phi` and
  `audit` schemas, the `meridian_app` (non-owner) and `phi_access` roles, and the grant
  matrix.
- **0004 `rls`** carries the row-level-security policies (see ADR 0011).

`alembic stamp` is never used to skip 0001-0003 on staging. Staging is built from empty
every time, so the chain is proven on every session — which torn-down staging (ADR 0008)
makes routine.

## Consequences

- The `org_id` predicate stays visible in the SQL text, so `scripts/lint_org_scope.py` can
  read it. That is the point.
- Every `Database` method signature is unchanged, so callers do not move and the
  byte-for-byte journal-entry diff is a valid gate after each port sub-stage.
- Safety rests on discipline plus a lint, applied **202** times, by a solo developer. RLS
  (ADR 0011) exists as the backstop for exactly that reason.
- Moving to psycopg 3 later is a contained change, because every statement lives behind
  the repository boundary.
- 0002 must be regenerated if live Supabase changes before the dump is taken.

## Trigger to revisit

A parity diff catches a mis-scoped or mis-transcribed statement. That is the one condition
under which "no SQLAlchemy" reopens: reverse into SQLAlchemy Core at the repository
boundary, with every `Database` signature held fixed so the change stays cheap.
