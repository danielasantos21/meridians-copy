# ADR 0001 — Account topology: one AWS account, two isolated environments

**Date:** 2026-09-15
**Status:** Accepted
**Source:** migration plan v3.1 §1, §2.4, decision D-02

## Context

Meridian is moving onto AWS under a Business Associate Addendum (BAA — the contract
under which AWS may hold protected health information). We already have access to one AWS
account (its id is recorded once, in `docs/aws-migration-plan.md` §1, and deliberately
nowhere else in `docs/`). The alternatives were: open a second account (or an AWS
Organization with separate production and non-production accounts), or reuse the one
we have and separate environments inside it.

The account is not empty and not all of it is ours. A separate **LLM-assistant
application** — or an unknown owner — already runs in it: an ECS service and its load
balancer, a CloudFront distribution with its own subdomain and WAF, a frontend S3 bucket,
**the assistant app's Cognito user pool**, an RDS PostgreSQL 16 instance, and a Terraform
state bucket. Someone else's Terraform state we cannot see may also drift. The exact
resource names are not written down here on purpose: they are another owner's identifiers,
and this repository is pushed.

Against that: an account is the strongest blast-radius boundary AWS offers, but every
account costs setup — the BAA, SES domain verification, Identity Center, GuardDuty,
Config and CloudTrail all have to be done again — and this is a one-person team.

## Decision

**Reuse the existing account. Run staging and production inside it, isolated by
separate VPCs, IAM roles, KMS customer-managed keys (encryption keys we control), and
tags.** Each environment is the same AWS CDK app deployed with a different `env`
parameter: its own VPC with no peering and no shared NAT, its own RDS instance, buckets,
Cognito pool, secrets and budgets. Nothing in staging can read a production ARN.

The CDK is written **split-ready**: no account id is hard-coded anywhere, environment is
a stack parameter, and no state is shared between environments. Splitting production
into its own account later is `cdk deploy` against a different account plus a data move
— not a redesign.

Every resource is named `meridian-<env>-<component>-<purpose>` and tagged `Project`,
`Environment`, `Owner`, `DataClassification`, `CostCenter`, `ManagedBy=cdk`.

The pre-existing resources described above are **off-limits**: do not deploy onto, modify,
restore, inspect, or delete any of them. `cdk bootstrap` creates its own state bucket; the
other owner's Terraform state bucket is never touched. Identifying which resources those
are is done by reading the console or `docs/aws-migration-plan.md` §1 — not by copying
their names into tracked files.

## Consequences

- **Shared blast radius is accepted.** An account-wide admin principal can reach both
  Meridian's PHI and the assistant application. The IAM triage in Phase 1 is therefore a
  hard precondition of any PHI landing in the account, not hygiene.
- **Shared quotas and one bill.** The six tags are load-bearing: cost allocation,
  IAM conditions (`aws:ResourceTag/Environment`) and CI's untagged-resource check all
  read them.
- BAA, SES verification, Identity Center, GuardDuty, Config and CloudTrail are
  configured once instead of twice.
- Staging is torn down between phases (ADR 0008), so the CDK is re-proven from empty
  every session — which is exactly the rehearsal a future account split needs.

## Trigger to revisit

A second workload, a second person with admin rights, or an auditor requiring account-level
separation of production PHI. Also revisit if the assistant application's owner makes
changes that reach our resources. The split is a redeploy, so the cost of revisiting is
low by design.
