# Wilke, Fundamentals of Data Visualization: Part I notes

Source: https://clauswilke.com/dataviz/ (chapters 2-16 fetched per page; text is a summarized
extraction, not verbatim. Check exact wording against the source before quoting.)
Use case: "Ask a question" BI app (bar, line, combo bar+line, single number, table, pie, pivot).

## Gaps
- Dual y-axes: NOT covered in Part I (Ch 3, Ch 13 both silent). Wilke's only related
  guidance is that stretching one axis relative to another changes how differences look.
  Treat dual-axis advice as our own design call, not Wilke's.
- Zero baseline rule: stated for bars (Ch 6), histogram bars (Ch 7), and filled areas under
  lines (Ch 13). Not a standalone chapter.
- Confidence bands (Ch 16) and overlapping points (Ch 12): summary gave no specific rules.

## Ch 2 Mapping data to aesthetics
- Each scale one-to-one: one data value maps to one visual value, and back.
- Position is the most flexible channel for continuous numbers; size, color, line width are less precise.
- Shape and line type suit discrete categories only.
- Space discrete levels evenly; keep ordered factors (good/fair/poor, age groups) in order.
- Unordered factors: pick an order deliberately (sort by value).
- Large colored areas when color carries the key variable; small patches convey little.
- Use multiple scales only for distinct variables.

## Ch 3 Coordinate systems and axes
- Set explicit limits on every axis; data outside limits are dropped.
- Ratios and anything made by multiplication/division: log scale. Never plot ratios on linear scale.
- Use log when values span very different magnitudes.
- Log axes: state the base; label with the variable name, not "log(x)". Zero cannot appear on log.
- Square-root scale handles zeros but tick steps are not intuitive.
- Same units on both axes: equal grid spacing.
- Aspect ratio: tall emphasizes y change, wide emphasizes x change. Pick the one that shows the story.

## Ch 4 Color scales
- Qualitative: discrete unordered groups; colors distinct but none dominant; no implied order; finite set.
- Sequential: ordered values; single-hue or multi-hue; steps must look uniform.
- Diverging: deviation from a meaningful midpoint (zero, 50%); balanced light-to-dark on both sides.
- Default qualitative palette in the book: Okabe-Ito (colorblind-friendly).

## Ch 5 Directory of visualizations (suits / avoid)
- Bars: amounts across categories.
- Dot plots: amounts across categories, alternative to bars.
- Grouped bars: moderate number of conditions. Stacked bars: many conditions or several proportion sets.
- Heatmap: two category axes, amount as color.
- Histogram / density: single distribution; density for overlapping comparisons.
- Boxplots / violins / strip charts: many distributions at once.
- Pie: whole split into parts, simple fractions. Avoid for many sets or over time.
- Side-by-side bars: comparing individual pieces of one proportion set.
- Treemap: nested proportions. Mosaic: two grouping variables (subdivisions must match).
- Scatter: y vs x, one dot per observation. Bubble: third variable as size, use with caution.
- Line graph: x is time or strictly increasing quantity.
- Smooth trend lines: larger datasets.
- Choropleth: values by region (density, not totals). Cartogram: distort by another quantity.
- Error bars: range of likely values around an estimate.

## Ch 6 Visualizing amounts
- Bars when magnitude vs zero matters; bars must start at zero.
- Narrow range far from zero: dots on a restricted axis (long similar bars pull eye to middles).
- Long category labels: horizontal bars (horizontal text easier to read than rotated).
- Unordered categories: sort by value, ascending or descending. Avoid alphabetical for readability.
- Ordered categories (age groups): keep natural order, do not sort by height.
- Grouped bars: hard beyond a few groups. Put the most-compared variable on x; avoid color-as-second-variable with legend; use small panels.
- Stacked bars: only when the segment sum is meaningful (sales, passenger counts), not medians or incomes.
- Few values: print numbers on bars, drop the y-axis.
- Heatmaps: broad trends over large category x time grids; exact values hard.

## Ch 7-8 Distributions (histograms, density, ECDF, Q-Q)
- Histogram: equal bin widths; bars start at zero; test several widths (Titanic ages: 3-5 yr bins good).
- Density: bandwidth like bin width; test several; curves may extend into impossible values.
- Density or overlapping curves for comparing groups; overlapping histograms get confusing.
- Avoid stacked histograms.
- ECDF: no tuning parameters; read median/percentiles directly; good for skewed data. Less intuitive for general audiences.
- Q-Q: check fit to a reference distribution (often normal).

## Ch 9 Many distributions at once
- Boxplot: median, middle 50%, whiskers (max 1.5 box heights), outliers as dots. Can hide bimodality.
- Violin: only with enough points per group; sparse data: plot raw points.
- Response on one axis, groups on the other.
- Avoid one point + error bars per group to show spread (error bars show estimate uncertainty).
- Ridgeline: dozens of groups or change over time; chronological order for time groups.

## Ch 10 Proportions
- Pie: simple fractions (1/2, 1/3, 1/4); very small datasets; one message (a majority). Avoid many slices, multiple sets, or change over time.
- Stacked bars: a few conditions or proportions over time; two segments per stack works well, especially with a 50% reference line. Avoid a single stacked column. Avoid many categories (middle segments hard to compare).
- Side-by-side bars: compare individual fractions directly; good when whole is many pieces (drawback: bar-to-total relation not obvious).
- Stacked densities: proportions changing along a continuous variable (age); few categories.
- Separate panels: each part vs the whole (gray background) when size and share both matter.

## Ch 11 Nested proportions
- Mosaic: two combined categorical variables covering all observations; hard to compare.
- Treemap: categories that can't combine cleanly (states in regions); deep nesting gets confusing. Preferred over nested pies.
- Never one combined pie for overlapping categories (sums can exceed 100%).
- Overlapping categories: side-by-side bars avoid the 100% issue but hide overlap.
- More than two variables: parallel sets.
- Show counts or percentages as labels.

## Ch 12 Associations
- Scatter: response on y; color by category to check trend within groups.
- Bubble size: hard to judge; prefer position. Many variables: scatterplot matrix over bubbles, up to ~3-4.
- Correlogram: r as colored tiles; show raw points when possible.
- Paired data (same units): x = y diagonal line; slopegraph for few cases or >2 time points.

## Ch 13 Time series
- Connect time-ordered points with lines. Lines only when series is dense; dots when sparse or unevenly spaced.
- Caption note that lines are a guide to the eye.
- Do not plain-scatter several time courses; they run together.
- Fill under a line only with zero baseline.
- Label lines directly rather than with a legend.
- Two response variables over time: connected scatter (with direction shown by arrows or shading), or separate stacked line graphs.

## Ch 14 Trends
- Smoothing shows overall trend, hides short-term noise. Moving-average window sets detail kept.
- Centered average: no lag. End-of-window average lags.
- LOESS: smooth, tunable; slow on large data. Splines: sensitive to knots.
- Try several smoothing choices; results depend on defaults. Be careful near data edges.
- Linear relationships: straight trend line over raw points.
- Exponential: log y-axis so trend is straight. Power law: log-log. Better to fit a line to transformed data than a curve to raw data.
- Decompose into trend, seasonality, remainder when components matter.

## Ch 15 Geospatial
- Maps only when location matters; include scale bar/north arrow for real maps.
- Choropleth works for density (per area or per capita); raw totals let big empty regions dominate.
- Bin continuous values into ~4-6 color groups.
- Alternatives: cartogram (area by population), tile/square cartogram, small multiples for time trends.

## Ch 16 Uncertainty
- Always state what the bar means: SD (spread of observations) vs SE (precision of estimate). SE ~ SD / sqrt(n); 95% CI ~ mean +/- 2 SE.
- Larger n gives narrower intervals.
- Graded error bars for several confidence levels.
- Do not judge difference by overlap of error bars; compute CI of the difference and check if it excludes zero.
- Caps emphasize endpoints; omit caps in dense charts.
- Lay audiences: frequency framing (grids of squares, ~10 dots, quantile dot plots); HOPs if animated.
- Avoid confidence strips and confidence distributions (hard to read specific levels).
