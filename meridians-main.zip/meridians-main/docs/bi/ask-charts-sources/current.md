# Ask a question: how results are visualized today (as of branch merge/main-into-aws-2026-10-16)

Base path: web/src/app/bi/question/ (abbrev. Q/), web/src/components/charts/ (C/), web/src/app/tokens.css, src/bi_ask.py.

## 1. Default chart and chart types

- Ask opens on the chart whenever the answer is not a plain list: question-page.tsx:472 (gate uses `defaultDisplay(toQuery(asked), [])`, so it passes no columns and cannot see temporal roles; it only decides table vs chart).
- Result default: `defaultDisplay` (Q/viz/default-display.ts:11-27), last stage only:
  - no stage or no aggs and no breakouts -> table (13, 16)
  - 1 agg, 0 breakouts -> number (17)
  - 0 aggs -> table (18)
  - 1 breakout + money and count measures (`isMoneyAndCount`, columns.ts:37-43) -> combo (24)
  - 1 breakout -> line if temporal, else bar (25)
  - 2 breakouts + 1 agg -> line if any temporal, else bar (26)
  - anything else -> table (27)
- Horizontal bars ("row") and pie, area, funnel, pivot, etc. are never auto-picked.
- Picker "Best for this result" (choose.ts:18-55) uses `fits` rules: bar/row/line/area need n>1, dims>=1, metrics>=1; trend needs one temporal dim and one metric; number/gauge need one cell; progress needs one cell with no dims; combo needs metrics>=2 or (1 metric and 2 dims); pie needs 2..`MAX_PIE_SLICES`=12 rows, one dim, one metric (choose.ts:11, 39); funnel exactly 2 cols; scatter 2+ numeric; box, treemap, sankey, waterfall, pivot as coded (choose.ts:40-46). Anything else is under "More charts"; table is always offered.
- 18 display types (settings.ts:18-37): table, number, trend, progress, gauge, bar, row, line, area, combo, pie, funnel, pivot, waterfall, scatter, box, treemap, sankey.
- Picker UI: picker.tsx (3-column tiles, radio group); the chosen type resets settings (result-view.tsx:225).

## 2. Ordering, top-N, direction, labels

- No client-side sort of categories. Bars and lines keep server row order (chart-data.ts:161-172). Order comes from the query's `order-by` (bi_ask.py examples ~178-247 use asc on time). Prompt never asks for sort-by-value.
- Split series (seriesBy) ordered by category rank for known names, unknown alphabetically (chart-data.ts:113-116; category-colors.ts:34-83).
- No top-N and no "Other" for bars/lines. "Other" exists only for pie: slices under `minSlicePct` (default 2%, settings.ts:565) roll into "Other" (pie-chart.tsx:55-79; render.tsx:234).
- Max categories: none for bars (rows capped to 100 per table page only). Pie capped at 12 (choose.ts:11).
- Direction: "bar" = vertical columns, "row" = horizontal (series-bar-chart.tsx:55-58, row height 30px, scrolls; ROW_PX line 27). Row labels truncated at 22 chars with "…" (LABEL_MAX line 32, ellipsize format.ts:17). Vertical x labels are not truncated; recharts auto interval (`preserveStartEnd`, chart-data/print-chart.ts), print caps label count (print-chart.ts:13-20). Pie labels ellipsized at 18 (pie-chart.tsx:139).

## 3. Axes

- Zero baseline: not forced. Bars use recharts auto domain; `yScaleProps` (series.tsx:101-108) only adds domain when a manual y range is set (settings.ts:118; render.tsx:170). A manual min above zero on bars is allowed without warning. Log scale option exists (settings.ts:119).
- Dual axis: automatic split (axis-split.ts:16-60): a series whose max is under 10% of the biggest goes to a right axis; never when stacked; user can pin left/right (settings-panel.tsx:283-294, 410-415). Combo default: money = bars on left, count = line on right (settings.ts:543-547).
- Axis titles: auto only when split, using series names (series.tsx:115 `axisTitle`; series-bar-chart.tsx:115,129; combo-chart.tsx:~50 `titled`). Manual x/y title text fields exist (settings-panel.tsx:350-351). No default titles.
- Tick format: money ticks compact `$1.2K` (chart-data.ts:43, format.ts:81-100); percent ticks 0 decimals (chart-data.ts:44); counts compact (chart-data.ts:45). Week/day ticks read "Week of Sep 28" / "Sep 28" (date-label.ts:28-46; render.tsx:127,134); year added only when data spans years or is not the current year (date-label.ts:38-46).
- Bar horizontal value axis and category axis styling: AXIS_TICK 12px tertiary grey, no axis lines, no tick marks (theme.ts:29; series-bar-chart.tsx:77-106).

## 4. Colors

- Palette: 8 tokens `--chart-series-1..8` (tokens.css:158-165): #0072b2, #cf7a00, #6a3d9a, #2a9d6f, #c0392b, #3a9ad9, #b0508c, #1fa3b0; neutral `--chart-neutral` #b4becd (tokens.css:167). Comment says "Okabe-Ito based, color-blind safe" (tokens.css:152): only #0072b2 matches Okabe-Ito; #cf7a00 vs #E69F00, #c0392b vs #D55E00, #2a9d6f vs #009E73 differ. Series 4 (green) and 5 (red) form a red/green pair; lines get dash patterns only from the 5th series (theme.ts:27).
- Contrast: each series >=3:1 on card; adjacent luminance check asserted in contrast.test.ts (web/src/lib/contrast.test.ts).
- No dark-mode block for chart tokens in tokens.css (no "dark" match in file). DESIGN.md R11 says dark mode out of scope (web/DESIGN.md:175).
- Assignment (chart-data.ts:90-107): user override (1..8 palette index, settings) > category's own color > stable hash. A single metric with no split is accent blue (`var(--accent)`). Multiple measures take palette in order, skipping colors already used.
- Category map: category-colors.ts:8-32 (e.g. completed=series-1, no_show=series-2, rescheduled=series-5, cancelled=neutral; payer names medicaid/medicare/etc.). Unknown names hashed onto 6,7,8 then 5 (category-colors.ts:85-117). Note: "rescheduled" is red (series-5), a status with an alarm color.
- Overrides UI: series-colors.tsx: swatch plus text "Color N" (never color alone).
- Highlighting: none. No single-bar emphasis, no dimming of other series. Goal line is grey dashed (series.tsx:110, `GOAL_STYLE`).
- "Other" / cancelled neutral: #b4becd with slate-400 outline (series-bar-chart.tsx:28-31; pie-chart.tsx:158). Pie "Other" slice uses text-tertiary grey (pie-chart.tsx:156).
- Table colour rules (conditional formatting): 8 max (swatches.ts:33), single rule tint 65% cell or 20% row, range rule up to 75% (table-rules.ts:53-55); palette limited to 11 fixed swatches (swatches.ts:16-28), not chart series.

## 5. Labels, legend, titles, numbers

- Legend: multi-series bar/line/area/combo use custom top-left legend (series-bar-chart.tsx:136-152; combo uses recharts legend, combo-chart.tsx:~75). Pie: bottom legend, circle icons (pie-chart.tsx:162). Single series: no legend.
- Direct labels: value labels off by default for bar/line/combo (settings.ts:514, 525; `labels: bool(st.labels,false)`); pie labels on by default showing name and % (settings.ts:562; pie-chart.tsx:136-141), only for slices >= 3% (pie-chart.tsx:82). Bar value label text rotates -90 when too narrow (value-label.tsx:39-49); skipped when bar thinner than 6px (value-label.tsx:11, 35). Print: value labels only when <=12 points (print-chart.ts:20, 46-47).
- Card title: `card?.name || suggested.name` (question-page.tsx:562); suggested name is the AI title from `_clean_title` (ask-meridian.tsx:99; bi_ask.py:747-760), max 60 characters, no trailing period, question's language (bi_ask.py:318-319). Ask note appears as a banner above the result, "You asked" (question-page.tsx:545-549), not on the chart. The note's text rules: one sentence, periods in words (bi_ask.py:275).
- Chart tooltip: full number, percent of total for pie (pie-chart.tsx:167); masked as `<11`.
- Number formats (format.ts, chart-data.ts:36-62, run-table.tsx:91-103):
  - money in charts: whole dollars without cents ($69,840), cents when present ($1,234.50) (chart-data.ts:37); in tables always 2 decimals (run-table.tsx:96)
  - money ticks: `$1.2K`
  - counts/other numbers: en-US grouping, max 2 decimals (format.ts:40-57); values under 1 keep 2 significant digits (format.ts:51-52)
  - percent: columns typed Percentage/Percent shown as 25.0% (1 decimal, format.ts:70-72)
  - compact K/M/B under 1000 falls back to full (format.ts:81-100)
  - custom per-column formats (prefix, suffix, decimals, style) in settings (chart-data.ts:48-62)
  - Number formatting is en-US always (result-view.tsx:12 comment; run-table.tsx:6-7) - known gap.
- Dates: table uses medium date ("Dec 28, 2025") and month "Sep 2026" (run-table.tsx:78-89); charts use week/day shorthand above (date-label.ts). Fiscal labels come from the query as text (`fiscal_*_label`, year-qualified, bi_ask.py:245-247, 292-294), so they appear as plain category text, not as date axes.

## 6. Tables

- Alignment: numeric base types right-aligned with tabular numerals; everything else left (run-table.tsx:129-137; data-table.tsx:281-302). Column headers align with cell (data-table.tsx:363).
- Header names: `display_name`; model-style snake_case names are humanized ("total_visits" -> "Total visits") (run-table.tsx:133; chart-data.ts:24-34). Provider and location names in ALL CAPS are shown in Title Case, display only (format.ts:102-125).
- Totals: none. RunTable does not pass a totals row (run-table.tsx:213-231); the DataTable supports one (data-table.tsx:56, 445-451) but its docs say never auto-sum rates. Pivot has row/column totals (render-b, settings.ts:615-616).
- Sorting: click header asc/desc/none (data-table.tsx:31-32, 354-362); masked values sort last.
- Paging: 100 rows per page (result-view.tsx:39, pageSize). Footer "Showing N rows · ms" (run-table.tsx:70-76).
- Striping: none found in data-table.tsx (no zebra), matching web/DESIGN.md §3.9 (line 539).
- Masked cells: `<11`, never 0 (run-table.tsx:59 for CSV; data-table.tsx:409).
- Mini bars and row/cell tints: optional per column (run-table.tsx:175-176; table-rules.ts).

## 7. Single number

- Number tile (render.tsx:282-310; C/number-tile.tsx): big figure, optional prefix, suffix, decimals, multiplier, compact. Money tiles use currency; empty money says "Not posted yet", other empty says "No data yet" (render.tsx:306; strings in bi-dash-grid.ts:32-33). Date results shown as date (render.tsx:287-288). Masked figure keeps the drill target (chart-data.ts:242-249).
- Trend tile (render.tsx:312-344): last value vs previous row in date order, with "versus" comparison; lower-is-better flag. Only chosen manually (never default).
- Progress bar (render.tsx:346-365) and gauge (375-381) are manual only.

## 8. What the AI prompt says about presentation (src/bi_ask.py)

- Output: JSON with `query`, `note` (one short sentence, periods in words), `title` (<=60 chars, plain words, no quotes, no trailing period, question's language) (bi_ask.py:275, 318-319).
- "Keep it chartable: one or two group-bys, and one summary unless the user asks for several." (bi_ask.py:300)
- "Group by and show readable columns (a name or description), never id or key columns unless asked." (bi_ask.py:298-299); code also swaps ids for names where possible (bi_ask.py:760-830).
- Visits and money cannot be summed together except in fct_provider_day (bi_ask.py:308-312).
- Fiscal words map to *_label columns so they sort in time order (bi_ask.py:292-294).
- Nothing about chart type, colors, sort order, top-N, number formats, axis, or labels. The prompt does not ask for a chart type at all; the chart is picked by code (default-display.ts).

## 9. UI rules docs

- "UI rule 21" is cited in code (chart-data.ts:20, series.tsx:40: compact axis ticks). No numbered UI rules file exists in this repo or its .planning folder; grep found no "UI rule" anywhere else. The CLAUDE.md "New Process UI Requirements" concern Jinja-era process pages, not charts.
- Other cited specs not found in repo: "UI-SPEC 2.2" (chart-data.ts:85, category-colors.ts:2), "spec sections 1.5, 2.5, 4" (default-display.ts:2, choose.ts:2), "behavior spec section 7" (table-rules.ts:1), "behavior notes section 11 in 261012-ily quick-task folder" (format.ts:4). None exist here.
- The only design doc present is web/DESIGN.md. Chart-specific guidance is thin; relevant lines:
  - §3.9 DataTable: "No outer border, no vertical rules, no zebra" (line 539); "Text left. Numbers right, tabular." (549); body text never heavier than 500 (228).
  - Line 605: "never a sparkline with no axis".
  - Line 718: "A tooltip is never the only place a rule, unit, or definition appears."
  - Line 175 (R11): dark mode out of scope.

## Gaps vs typical data-viz practice (observations, not recommendations)

- No value sort or top-N for many categories; long category lists stay as-is.
- Bars can start above zero if the user sets a manual min; no warning.
- Only pie uses an "Other" group.
- Palette claimed Okabe-Ito but only partly; red/green pair at series 4/5; dashes only from series 5.
- No highlight/focus state.
- Number format is always en-US.
- Totals row not shown on result tables.
