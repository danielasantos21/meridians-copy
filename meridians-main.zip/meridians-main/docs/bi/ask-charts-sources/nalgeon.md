# nalgeon/dataviz - rule notes (for "Ask a question" chart picker)

Source: https://github.com/nalgeon/dataviz (README + docs/01,02,04,05,06,07,09 .md). Based on IBCS 1.1 (CC BY-SA 4.0), adapted by Anton Zhiyanov. Chapters 03 and 08 are not linked in the repo. Chapter 01 (SAY) and 02 (STRUCTURE) have no chart-selection rules; 05 and 06 mostly cover clutter and density.

## Chart selection (EX = 04-express.md)
- EX 1: Tables are for looking things up; charts convey a message. Charts are biased by data selection, chart type, and highlighting. (EX 1)
- EX 1.1: Time on horizontal axis: columns, lines. Structure (categories) on vertical axis: bars. Avoid lines for categories, since they imply a trend that does not exist. (EX 1.1, chart families)
- EX 1.1: Lines only for series with many points. Few values imply continuity that is not there. (EX 1.1, Line charts)
- EX 1.1: More than 3-4 intersecting lines (spaghetti) -> small multiples, unless exact point comparison is needed. (EX 2)
- EX 1.1: Stacked columns/bars only if all values are positive or all negative. Max ~5 segments, and only if values vary little. (EX 1.1, Stacked)
- EX 1.1: Pie/ring charts are one-dimensional and rarely insightful; use bars or stacked columns. (EX 2)
- EX 2: Gauges, speedometers, radar charts, 3D shapes, funnels: replace with bars/columns. Traffic lights only for yes/no. (EX 2)
- EX 1.2: Tables for lookup and for multiple measures per row; column types: time columns chronological left-to-right, variance columns, totals right of group. (EX 1.2)
- EX 3: Prefer quantitative visuals over text bullets on screen; avoid text slides. (EX 3)
- EX 4: Add a comparison reference (plan, prior year) whenever one exists; add variances to scenario comparisons. (EX 4)
- EX 5: Show causes/interrelations with tree structures or correlations, not decoration. (EX 5)

## Counts and grouping
- Stacked: max ~5 series. (EX 1.1)
- Small multiples: up to ~25 charts; beyond that, collapse the remainder into an "Others" chart. (CO 5.1)
- Remainder bar: sort descending, roll the smallest items into a "rest of..." bar with a wider gap; exclude it from ranking/averaging/selecting. (EX 1.1, Remainder bar; EX 1.2 remainder rows)
- Selecting for ranking: show top ten / last ten / quartiles (UN 4.3, Selecting).

## Sorting
- Ranking indicated by an arrow in the label, e.g. "country names↓" (UN 4.3, Ranking). Sort is part of the page title line: "sorted by net sales (↓)" (UN 2.2 line 2).
- Time periods: ascending, left to right / top to bottom (UN 4.1, Ordering).
- Same period in scenario comparisons: keep order identical across all charts and tables (UN 4.1, Ordering).
- Vertical bar order "follows the intended analysis" (EX 1.1, Single bars).
- Structures always displayed vertically (UN 3.4).

## Axes
- Value axes should generally start at zero. Exception: indexed data with small variance, zoom in and put category labels at the 100% line (CH 1.1).
- No log scales for business comparisons (CH 1.2).
- Equal-width class bins only for histograms (CH 1.3).
- Don't clip bars/columns (CH 2.1). For order-of-magnitude differences, use a size or creative solution, or outlier indicator (CH 2.2, UN 5.3).
- Same unit on one page -> identical scale; if impossible, mark the difference with a scaling line (CH 4.1, CH 4.3, UN 5.2).
- Two value axes (overlay chart): allowed only for "a few chart combinations." Labeling both series is hard; if space allows use multi-tier (stacked sections, each with its own axis) instead (CO 4.1 Use limits, Recommendation).
- Multi-tier: each tier has its own value axis; axes in the same currency/unit scaled identically (CO 4.2).
- Overlay with same measure (sales vs industry average) on same value axis is fine (CO 4.1).
- Do not use two axes to imply a relation when units differ and no chart mapping is clear; the guide's default is separate tiers (CO 4.1, CO 4.2). [Inference from CO 4.1 "use limits"]
- Axis ticks/gridlines: replace with data labels; keep gridlines only when there are many series/points or the chart is small (SI 3.1).

## Bar vs line / columns vs bars
- Bars (vertical categories): column/bar width = 2/3 of the category width for basic measures; ratios 1/3 (UN 3.1).
- Line charts: thick lines for basic measures, thin for ratios (UN 3.1).
- Variance pins: thin bars, green positive, red negative (EX 1.1, Horizontal pins; UN 4.1).

## Single number / KPI
- No dedicated single-number rule in chapters 01-09. Closest: comparison references (EX 4), highlight message (SA 4.3), and "one clear message per page" (SA 3.2). Note: the guide has no gauge or meter guidance; gauges are an anti-pattern (EX 2).

## Labels and titles
- Put the message as two lines above the title, upper left (UN 2.1).
- Title identifies content, no interpretation (UN 2.2 principle). Line 1 reporting unit / entity; line 2 measure name in bold + unit; line 3 time, then scenario (UN 2.2).
- Data labels: keep to at most three digits in charts, four in tables; label only extreme or special values (SI 5.2, SI 5.3, UN 2.3).
- Omit labels on small elements; use assisting lines if they must be labeled (SI 5.1).
- Label positions: horizontal category axes -> labels above/below; bars -> right of positive, left of negative (UN 2.3, EX 1.1).
- Line charts: legend at line end or the title for one series; label peaks above, valleys below, not every point (EX 1.1).
- Legends: integrate into chart; single series -> legend in title; stacked -> at the ends. Write horizontally (UN 2.3).
- Drop obvious words in labels: "total", "sum", "table", "chart", "trend", "statistics" (SI 4.1, SI 4.2). Don't repeat shared words in each label (SI 4.3, e.g. "Q1 2017", "Q2 2017" -> put year once).
- Message first, then the proof (SA 3.2). Use precise words, not "significant"/"relevant" (SA 4.2).
- Name sources in written reports; slide may omit (SA 4.4).
- Footnotes at bottom for definitions, sources, abbreviations (UN 2.5).

## Numbers
- One format for the whole report. Thousands separator a blank (SI-style "1 234") or the locale's. Negatives: one style (-123 or (123)). No plus sign except variances (UN 1.2). Note: for a US clinic, use comma thousands; the guide says pick one and be consistent.
- Currency: ISO codes (USD), avoid symbols when mixing currencies; prefixes lowercase k, m, b (UN 1.2).
- Dates: ISO 8601 YYYY-MM-DD; "Q2 2017" or "W07 2017" acceptable if consistent (UN 3.3).
- Period boundary notation: "Jan..Mar" for spans (UN 3.3).
- Percent differences are "percentage points" (UN 4.1).
- Variance notation: "Δ" prefix; "+13" for variance vs "13" for a value (UN 4.1).

## Colors
- Color only to convey meaning; no decorative color (SI 2.2).
- Black on white for numbers and labels; no colored or filled backgrounds (SI 1.2).
- Variance: green = positive impact, red = negative, medium gray = neutral (UN 4.1 Colors).
- No color available: red -> dark gray, green -> light gray (UN 4.1).
- Color-deficient readers: green -> blue-green (UN 4.1). Do not rely on red/green alone; the guide does not give a categorical palette.
- Don't confuse variance colors with red/green traffic lights (UN 4.1).
- Highlighting: blue ellipse for values the message refers to; black for additional values (UN 5.1). Light green / light red highlighting in tables (UN 5.1, variance highlighting).
- Use the same color/notation for the same meaning on every page (UN intro, "what looks the same should also mean the same").
- Scenario fills: actuals = solid dark; prior-period actuals = light gray; plan = outlined; forecast = hatched (UN 3.2).

## Comparisons and scenarios
- Variance absolute = primary - reference; relative = variance / reference. Show "n.a." when reference is negative (UN 4.1).
- Variance columns share the base chart's width and scale (UN 4.1).
- Variance labels outside the element in the direction of change (UN 4.1).
- Grouped bars: reference sits behind primary; third scenario as reference triangle (EX 1.1, Grouped).
- Multi-tier: grouped actual-vs-plan bars + absolute variance tier + relative variance pins (CO 4.2 example).

## Part-to-whole
- Pie charts discouraged (EX 2). Use a stacked column/bar (<= ~5 segments, all same sign, totals labeled) or a 100% bar with the rest-of remainder (ST 3.2, EX 1.1). Tables must add to 100% (ST 3.2).

## Small multiples
- Same chart type, same scale, one per entity; ~25 max; "Others" beyond (CO 5.1).
- Don't scale one small multiple differently; enlarge it instead (CO 5.1 common mistake).
- Gridlines kept in small multiples (SI 3.1).

## Time series
- YTD/moving markers: "_Jun 2015" for YTD, "~" prefix for moving annual totals (UN 4.2).
- Index to 100% with an arrowhead reference (UN 4.2, UN 4.3).
- Trend arrows: start at first period, end at last; label with result e.g. "CAGR: 10.8%" (UN 5.1).
- Show inflation/currency effects when a long series could mislead (CH 5.1, CH 5.2).
- Time axis: chronological, left to right (UN 3.3, EX 1.2).

## Annotation
- Highlight the message (SA 4.3). Use difference markers for gaps; reference arrowheads for benchmarks (UN 5.1).
- Comment references linked in pairs to values (UN 5.1). Embed explanations next to visuals in written reports (CO 4.5).

## Density / clutter
- Remove decoration, backgrounds, 3D, shading, borders, animation (SI 1, SI 2).
- Right-align numbers; drop vertical table lines (SI 3.2). Light horizontal lines help in tables (EX 1.2).
- Chart/table combo: table repeating chart numbers is superfluous (CO 5.3).
- Sparklines: only with proper scaling, not individually scaled (CO 4.4).

## Common mistakes (named in the guide)
- Truncated axes on non-indexed bars (CH 1.1).
- Clipped bars (CH 2.1).
- Area/volume scaling of icons or spheres (CH 3.1, CH 3.2).
- Colored areas used for non-area data on maps (CH 3.3).
- Pie charts for one-dimensional data (EX 2).
- Different scale on one small multiple (CO 5.1).
- Chart and table repeating the same numbers (CO 5.3).
- Overlapping categories and non-exhaustive lists (ST 2, ST 3).
- Long numbers, too many labels (SI 5.2, SI 5.3).
- Lines for categories (EX 1.1).
- Traffic-light sets with more than three states (CO 4.4).
- Dual axes overused: labeling both is hard (CO 4.1).

## Gaps for our use case (not in the guide)
- No single-KPI tile rule, no categorical palette with N colors, no "how many bars before scrolling" rule, no top-N default, no dual-axis-combo chart spec beyond CO 4.1 and CO 4.2, no guidance on time-of-day or week-of-year, and no tooltip/interaction rules. Those must come from another source.
- Chapter 03 and 08 are not in the repo links; the guide's chapter list skips them.
