# Wilke, Fundamentals of Data Visualization: Parts II and III (notes)
Source: https://clauswilke.com/dataviz/ (chapters 17-29 read via WebFetch)

## Proportional ink (Ch 17)
- Bars on a linear scale always start at 0. A non-zero baseline exaggerates differences.
- Log scale bars represent ratios and start at 1. Amounts on a log scale: use dots, not bars.
- Humans judge lengths better than areas, so bars beat pie charts and treemaps for precise comparison.

## Overlapping points (Ch 18)
- Rounded data causes overplotting even in small sets. Fixes: transparency, small jitter (too much is misleading), 2D bins/hex bins for very large data, contour lines for density.
- Use colored contour sets only for 2-3 groups; more groups = facet them.

## Color pitfalls (Ch 19)
- Qualitative color is fine for about 3-5 categories, workable to about 8. Past that use direct labels.
- Do not color for decoration (rainbow bars add no insight). Avoid large, saturated color fills.
- Rainbow scale is non-monotonic and circular: never use it for continuous data. Use a sequential scale that rises monotonically in lightness.
- About 8% of men and 0.5% of women have color-vision deficiency (mostly red-green). Test with a CVD simulator. Use Okabe-Ito for qualitative palettes.
- Small or thin colored elements are hardest to tell apart. Use larger color areas.

## Redundant coding and legends (Ch 20)
- Do not rely on color alone: add shape, position, or labels as a second cue.
- Direct labeling beats legends: label line ends and groups in place. Design so no legend is needed when possible.
- If a legend is needed, match its order to the visual order of the data. Do not sort it alphabetically.
- Light fill, darker same-hue outline and text. Light-colored text is hard to read.

## Small multiples and compound figures (Ch 21)
- Use identical axis ranges and scales across panels. Free y-axes make differences look flat.
- Order panels logically (rank, time, size). Keep colors and order consistent across panels.
- Label panels with lowercase letters only in compound figures. Facet labels replace letters in small multiples.
- Align panels.

## Titles, captions, tables (Ch 22)
- Every figure has one title stating the point (an assertion, not "This figure shows..."). Figure captions go below; table captions go above.
- Label every axis with variable and units. Skip redundant titles (e.g., "Company" on a legend of company names).
- Tables: no vertical lines, no horizontal lines between data rows; a rule under the header is fine. Text left-aligned, numbers right-aligned, same decimals in each column, headers aligned with their data. Alternating light shading instead of row lines is acceptable.

## Balance data and context (Ch 23)
- Data ink should dominate; non-data ink (axes, grid, labels, legend) gives context. Keep only the grid lines that help.
- No outer frame, no heavy dark grid. Light gray or thin horizontal grid lines. Perpendicular to the key value: horizontal bars get vertical gridlines.
- Diagonal reference line for actual-vs-expected plots, not a grid on top of it.
- Do not move labels outside bars to fit them; keep the bars honest.

## Label size (Ch 24)
- Default library text is usually too small. Check at print size (about 3-5 inches wide on screen, or 1-2 inches printed). Labels should match the data marks in weight.

## Line drawings (Ch 25)
- Fill bars and histograms. Use filled, semi-transparent density areas. Solid lines, not dashed. Solid points, not open circles. Lightly shade boxplot boxes.

## No 3D (Ch 26)
- No 3D bars, pies, or perspective. Perspective and 3D bars distort size. Use a second 2D plot or small multiples instead.

## File formats (Ch 27)
- Save figures as PDF (vector) or high-resolution PNG (lossless bitmap). SVG for web. JPEG only for photos, never for charts or text.

## Software (Ch 28)
- Script the figure from raw data so it can be regenerated. Record random seeds for jitter. Separate content (data, mapping, scale, plot type) from design (colors, fonts, legend placement, theme).

## Telling a story (Ch 29)
- State the takeaway in the title or caption (example in chapter: "American and Delta have the lowest mean arrival delays...").
- Simplify for the reader who sees the chart once: strip anything that does not carry the point.
- Show an easy subset first, then the complex grid.
- Use a different plot type per distinct analysis; avoid sets of near-identical charts.
- Keep to about 3-6 figures per storyline. One figure for a blog post or tweet.
- Start with raw data, then move to derived quantities (percent change, averages).

## Mapping to the Ask a question feature (our use case)
- Bar charts for per-provider / per-clinic / per-period comparisons: start at 0. A line chart's y-axis may skip 0 (not covered here; Ch 13-14 apply).
- Combo chart with two y-axes: pick an axis per series; the two axes must be clearly labeled with units (Ch 22). Prefer two small charts over dual axes if the scales differ wildly (Ch 21 logic).
- More than about 8 providers or clinics in one color legend: use direct labels or a table, not color.
- Pie charts: only for a few parts of a whole; prefer bars (Ch 17).
- Pivot: follow the table rules (Ch 22).
- Title = the takeaway; the one-sentence note = the context, units and period (Ch 22, Ch 29).
- Single-number tiles: label the unit and period; the number needs to be larger than its label (Ch 24).
- Gridlines light; no 3D; no chart junk (Ch 23, Ch 26).
- Export: PNG or PDF; never JPEG (Ch 27).
