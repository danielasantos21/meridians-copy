# Storytelling with Data (Knaflic, 2015) - lesson notes

## Book identity
- Title: Storytelling with Data: A Data Visualization Guide for Business Professionals
- Author: Cole Nussbaumer Knaflic
- Publisher: Wiley, 2015 (DOI 10.1002/9781119055259 is the Wiley record for this title)
- Wiley product page returned HTTP 403 to our fetch, so the official TOC could not be read directly.
- Chapter titles below come from secondary listings (library catalog TOC, O'Reilly listing snippets).
  Chapters 1-4 are confirmed by more than one source. Chapters 5-8 are from memory and not verified.
- Sequel: Let's Practice! (2019), same author.
- Caveat: the lesson text below is paraphrased from general knowledge of the book's content. I could not read the book itself, so check any wording against the physical copy or Wiley preview before quoting it.

## Chapter map
- Ch 1 Understanding context (audience, purpose, narrative, visual) - title not verified
- Ch 2 Choosing an effective visual - verified
- Ch 3 Clutter is your enemy! - verified
- Ch 4 Focus your audience's attention - verified
- Ch 5 Thinking like a designer - recalled, unverified
- Ch 6 Telling a story - recalled, unverified
- Ch 7 Focus attention where you want it - recalled, unverified
- Ch 8 Putting it all together (makeover case) - partly verified (sources say ch 8 is the worked before/after example)
- Ch 9 Case studies - partly verified

## The 20 lessons for our Ask-a-question charts

1. Start from audience and the decision they need to make (Ch 1). Our audience is clinic leaders and billing staff, not analysts.
2. Decide the one takeaway before choosing a chart (Ch 1). The chart title should be that takeaway.
3. Pick the chart type by the question's job: comparison, composition, distribution, relationship, change over time (Ch 2).
4. Use lines for change over time (week, period, quarter) and bars for comparing categories (provider, clinic) (Ch 2).
5. Avoid pie charts when there are many slices or close values; a sorted bar reads better (Ch 2).
6. Avoid 3D and exploding effects; they distort size perception (Ch 2, the "exploding 3D pie" line is the book's signature example).
7. Treat dual-axis charts with suspicion; if the combo bar+line is used, label both axes clearly and keep each axis on one unit (Ch 2 and Ch 4 clarity).
8. Use a table when the user needs exact values for few items; the chart is for patterns (Ch 2).
9. A single number answer is the clearest form when the question asks for one figure; add one line of context (Ch 2).
10. Strip clutter: gridlines, borders, heavy legends, redundant labels, decorative elements (Ch 3, decluttering steps).
11. Label lines and bars directly instead of using a legend when there are few series (Ch 3).
12. Use gray for context and one accent color for the thing the note is about (Ch 3 and Ch 4 on color for emphasis).
13. Reserve color for meaning; do not use many bright colors for decoration (Ch 4).
14. Use preattentive attributes (position, size, color, orientation) to show where to look first (Ch 4).
15. Sort bars by value so the ranking is visible; keep time on the x-axis in order (Ch 3 order, general practice).
16. Align elements and keep a consistent grid and reading direction (Ch 3 order and Ch 5 design).
17. Give the title a takeaway sentence ("Denials rose 12% in P08 at Galloway") not a topic label ("Denials by clinic") (Ch 6, storytelling).
18. Annotate the key point directly on the chart (a callout at the spike) instead of making the reader hunt (Ch 6 and Ch 8 makeover).
19. Design for color blindness and low contrast: do not rely on color alone; use labels, patterns, or shapes (Ch 5).
20. Use white space and one font family; do not let the chart fill edges. Build the default version first, then remove what the story does not need (Ch 5 and Ch 8, the makeover method).

## Use in our app
- Map the questions to chart types in a small table: rank = sorted bar; trend = line; mix = stacked bar (avoid pie); two measures on different scales = combo with labeled axes; one value = single number; exact numbers = table.
- The note should state the takeaway in one sentence. The chart title should match it.
- Keep Ask's default output minimal: no decorative grid, one accent color, direct labels.
