# Ask a question — how we show answers (charts knowledge base)

Owner: Andres · Written 2026-10-20 · Applies to every answer Ask a question draws, and to saved questions and report cards (they share the same chart code).

This is the rulebook for turning a query result into a picture people understand at a glance. Each rule names its source so it can be checked. Part 4 compares the rules with what the app does today. Part 5 is the order we'll fix things in.

## Sources

| Short name | What it is | How it was read |
|---|---|---|
| **Wilke** | Claus O. Wilke, *Fundamentals of Data Visualization* (O'Reilly 2019), free at clauswilke.com/dataviz | Chapters 2–29, page by page |
| **IBCS** | nalgeon/dataviz on GitHub, a plain-language guide to the International Business Communication Standards 1.1 | README and chapters 01, 02, 04–07, 09 (03 and 08 are not in the repo) |
| **SWD** | Cole Nussbaumer Knaflic, *Storytelling with Data* (Wiley 2015, doi 10.1002/9781119055259) | Public table of contents, the author's site and summaries only. **Lessons are paraphrased and unverified**; check against the book before quoting |
| **Meridian** | Our own standards: `web/DESIGN.md`, `CLAUDE.md` (Excel table style), `web/src/app/tokens.css` | Code |

Full reading notes, kept for reference: `docs/bi/ask-charts-sources/` (copied from the research run).

---

## Part 1 — The five principles

1. **One answer, one message.** Decide what the person asked (a ranking, a trend, a total, a mix, an exact lookup) before choosing the picture. (SWD ch 1–2, IBCS EX 1)
2. **Position beats everything.** Show the main number as a length or a position on a shared axis (bars, lines). Use color only to point at something. Avoid angles, areas and 3-D. (Wilke ch 2, 17, 26; IBCS EX 2)
3. **Honest scales.** Bars start at zero. The same unit on one screen uses the same scale. No log scales for business numbers. (Wilke ch 6, 17; IBCS CH 1–4)
4. **Less ink, more data.** No frames, dark grids or decoration. Use light horizontal gridlines only, and label values directly instead of making people hunt through a legend. (Wilke ch 20, 23; SWD ch 3; IBCS SI)
5. **Words do the explaining.** The title names what is shown. The note says what it means. Every axis and number carries its unit and period. (Wilke ch 22; IBCS UN 2; SWD ch 6)

---

## Part 2 — Which picture for which question

The chart is picked by code (`web/src/app/bi/question/viz/default-display.ts`), not by the AI. This table is the target for that code.

| The question is about… | Data shape | Show | Why |
|---|---|---|---|
| One figure ("how many visits did Bescos have last week") | 1 measure, no grouping | **Single number**, with unit and period, and when available the comparison ("vs 64 the week before") | SWD ch 2; IBCS EX 4 |
| A few figures together ("charges, collections and denials for Bescos") | 2–5 measures, no grouping | **Row of single numbers** (a small KPI strip), not a one-row table | SWD ch 2; Wilke ch 6 ("few values: print the numbers") |
| A ranking ("which provider had the highest…") | 1 measure × category | **Horizontal bars, sorted largest first**; top 10 plus a grey "All others" bar | Wilke ch 6; IBCS EX 1.1 remainder bar |
| A comparison across clinics/providers (no ranking asked) | 1 measure × category | Bars sorted by value; horizontal when names are long or there are more than 8 | Wilke ch 6; IBCS EX 1.1 |
| A trend over time ("by week", "by period", "by quarter") | 1 measure × time | **Line** for 8 or more points, **columns** for fewer; time left to right, oldest first | Wilke ch 13; IBCS EX 1.1, UN 4.1 |
| Two measures over time or by category ("charges and visits by week") | 2 measures with different units × 1 grouping | **Combo**: columns for money (left axis, $), line for counts (right axis); **both axes titled with units** | IBCS CO 4.1; our rule for dual axes, below |
| A ratio ("collection per visit", "denials per visit") | rate × category or time | Bars or line of the **ratio alone**, not the ratio next to its parts | Wilke ch 6 ("never stack rates") |
| Trend for several groups ("visits by week for each clinic") | 1 measure × time × category | Up to 4 lines with **labels at the line ends**; more than 4 → **small multiples** (one mini chart per group, same scale) | IBCS EX 2; Wilke ch 13, 21 |
| Part of a whole ("share of visits by type") | 1 measure × ≤ 5 parts | **Stacked bar or 100% bar**; pie only for 2–3 parts and one message ("most visits are follow-ups") | Wilke ch 10; IBCS EX 2 |
| Exact lookup or many columns ("list the claims denied this week") | raw rows or 2+ groupings × 2+ measures | **Table** (Meridian table style) | IBCS EX 1; Wilke ch 22 |
| A grid of category × time where the pattern matters ("visits by clinic by week") | 1 measure × 2 groupings, many cells | **Heat-map table** (cell shading, sequential color) | Wilke ch 5–6 |

**Never auto-pick:** 3-D charts, radar, gauge, funnel, donut/ring, or area charts without a zero baseline (IBCS EX 2; Wilke ch 26). The picker may still offer some of these by hand, but they're never the default.

### Our rule for two y-axes (the combo chart)
The sources disagree. SWD and Wilke are wary of dual axes; IBCS allows them "for a few combinations". We keep the combo because "money and visits together" is our most common question. It comes with conditions:
- One axis is money and the other is a count. Never two of the same unit on different scales.
- Both axes get a title with the unit ("Charges ($)", "Visits"), and each series is colored like its axis.
- The money series is columns starting at zero; the count series is a line.
- With 3 or more measures, show **small multiples on one shared x-axis** (stacked tiers) instead.

---

## Part 3 — The rules by topic

### 3.1 Sorting and how many things to show
- Unordered categories (providers, clinics, payers) are sorted by value, largest first. (Wilke ch 6; IBCS EX 1.1)
- Ordered categories keep their natural order: weeks, fiscal periods (`Y26 P08` before `Y26 P09`), quarters, age bands, aging buckets. (Wilke ch 2; IBCS UN 4.1)
- When the sort is by value, say so in the subtitle: "sorted by collections ↓". (IBCS UN 4.3)
- More than **10–12 bars**: show the top 10 and fold the rest into one grey **"All others (n)"** bar. It is not ranked and is left out of averages. (IBCS EX 1.1)
- More than **4 lines**: use small multiples instead. More than **25 small panels**: top 24 plus "Others". (IBCS EX 2, CO 5.1)

### 3.2 Axes and scales
- Bars, columns and areas **always** start at zero; a manual minimum is refused for them. (Wilke ch 17; IBCS CH 1.1)
- Values crowded far from zero (e.g. wait times of 31–36 min) use dots or a line on a trimmed axis, not bars. (Wilke ch 6)
- No log scales for business comparisons. (IBCS CH 1.2)
- Charts side by side with the same unit share one scale. (IBCS CH 4.1; Wilke ch 21)
- Titles on the value axis only when the unit isn't obvious from the numbers ($ on money is obvious; "Visits" or "Claims" on counts is not). Always on both axes of a combo. (Wilke ch 22)

### 3.3 Color
- **One series = one color** (the accent blue). No rainbow bars. (Wilke ch 19; SWD ch 4)
- Color is for **meaning**:
  - Up to 8 categories get the categorical palette. Beyond 8, don't color by category; use position and labels instead. (Wilke ch 19)
  - **Highlight:** when the question names one thing ("Bescos", "Bishop"), draw it in the accent color and everything else in grey. (SWD ch 3–4; IBCS UN 5.1)
  - Good and bad: red is reserved for bad (denials, over target) and green for good. Never put red and green next to each other as the only difference. (IBCS SI 2.2; Wilke ch 19)
- **Color is never the only cue.** Add a label, a position or a dash pattern. (Wilke ch 20; SWD ch 5; already in `tokens.css`)
- Heat maps use a **sequential** scale (one hue, light → dark). A **diverging** scale is only for values around a real midpoint, such as 100% of target. (Wilke ch 4)
- The palette must pass a color-blindness simulator. See gap G7: `tokens.css` says "Okabe-Ito based" but only the blue matches, and series 4 (green) and 5 (red) form a red-green pair.

### 3.4 Labels, legends and titles
- **Label directly:** values on the bars when there are 12 or fewer bars, names at the line ends. Use a legend only when direct labels don't fit, and order it like the data, not alphabetically. (Wilke ch 20; SWD ch 3; IBCS UN 2.3)
- When values are printed on the bars, drop the value axis and gridlines. (IBCS SI 3.1; Wilke ch 6)
- Leave out obvious words: no "Total", "Chart" or "Count of" in titles and labels. (IBCS SI 4)
- **Title vs message.** The sources differ here: SWD and Wilke want the takeaway in the title, while IBCS wants the title to name the content and the message to sit separately. We follow IBCS for the title, because saved questions re-run on new data and a takeaway title would go stale.
  - **Card title** names what is shown, with its period: "Collections per visit by provider · Bishop · last 15 days". The AI writes it, at 60 characters or fewer.
  - **The note** (in the "You asked" box) carries the **message** for this run, one sentence: "Venegas had the highest collections per visit ($160)". It's written per answer and never saved as the title.
- Single numbers always show the unit and the period ("71 visits · Oct 14–20").

### 3.5 Numbers
- One format everywhere (IBCS UN 1.2):
  - **Chart axes and labels:** compact, at most 3 significant digits ($1.2M, 3.4K, 12.5%). (IBCS SI 5.3)
  - **Tables:** full numbers. Money has 2 decimals, counts have none, percents have 1 decimal, and every row in a column has the same number of decimals. (Wilke ch 22; Meridian Excel style)
  - **Single numbers:** whole dollars when at least $1,000, otherwise cents.
- Differences (vs last period or target) carry a sign, "+12" or "−3%", and only differences do. (IBCS UN 4.1)
- Dates: weeks read "Week of Sep 28"; fiscal periods read "Y26 P08"; quarters read "Y26 Q3". The year is always included once more than one year is shown.

### 3.6 Tables
- Same as our Excel standard: header bold with one thin rule under it, no vertical lines, no lines between rows, text left, numbers right with tabular figures. (Wilke ch 22; Meridian `CLAUDE.md`, `web/DESIGN.md` §3.9)
- A **totals row** when the measure can be added up (counts, money), never for rates or averages. (Wilke ch 6)
- Headers are words: `total_visits` becomes "Total visits". Already done, see `run-table.tsx`.

### 3.7 Comparisons
- Wherever a reference exists, show it (IBCS EX 4):
  - a target, from the Daily Report targets;
  - last period or last year, from the fiscal calendar.
  The difference is primary minus reference, and the percent difference is that divided by the reference. Show "n/a" when the reference is zero or negative.

---

## Part 4 — Where the app stands today (2026-10-20)

From the code read (`web/src/app/bi/question/viz/*`, `web/src/components/charts/*`, `src/bi_ask.py`).

| # | Rule | Today | Gap |
|---|---|---|---|
| G1 | Rankings sorted largest first; top 10 + "All others" | Bars keep the query's order. No top-N; "Other" only on pie (`settings.ts:565`) | **Big.** This is the 35-clinic chart with tiny bars |
| G2 | Long names / many bars → horizontal bars | Horizontal ("row") bars only when picked by hand (`series-bar-chart.tsx:32`) | Big |
| G3 | Bars start at zero | Not enforced; a manual minimum lifts it with no warning (`series.tsx:101`) | Medium |
| G4 | A few figures → row of single numbers | 2–5 totals with no grouping show as a one-row table (`default-display.ts:16`) | Medium (the Bescos "billings, visits and denials" answer) |
| G5 | Both combo axes titled with units | Axis titles only appear when the axes split, using series names (`axis-split.ts`) | Medium |
| G6 | Direct value labels when there are 12 or fewer bars; highlight the asked-about item | Value labels off by default (`settings.ts:514`); no highlight state | Medium |
| G7 | Palette safe for color-blindness | Only the blue is Okabe-Ito; series 4 and 5 are a green/red pair (`tokens.css:158-165`) | Medium, needs a simulator check |
| G8 | Title names the content; the note gives the message | Title is the AI's; the note is in the "You asked" box, which matches. The prompt asks for a note that says what was built, not what it shows | Small: change the note rule to "say the result in one sentence" |
| G9 | Totals row for additive measures | The table supports totals but result tables don't use them (`run-table.tsx:213`) | Small |
| G10 | Single number shows unit, period and comparison | Shows the number only (`render.tsx:282`) | Medium |
| G11 | More than 4 lines → small multiples | Not available | Later |
| G12 | Heat-map table for category × time | Not available | Later |
| G13 | Same unit side by side → same scale | Only matters on reports, which have several cards | Later |

Already in line: a single number for one figure, combo with money left and counts right, lines for time, compact ticks ($1.2K), "Week of" labels, tabular right-aligned table numbers, Title Case names, readable headers, fiscal labels in time order, color never the only cue (dashes after the 4th line), masked "<11" cells.

---

## Part 5 — How we'll do it (order of work)

**Step 1 — the picture fits the question (G1, G2, G3, G4).** Code only, no AI cost.
- `default-display.ts`: 2–5 totals with no grouping → KPI strip. One category grouping with more than 8 items or long names → horizontal bars.
- Category bars sort by value, largest first, unless the AI's query already has an `order-by` or the categories are ordered (time, fiscal labels, buckets).
- Top 10 + "All others" for bars, computed in the chart from the result rows. It's display only, so the query and Excel export keep every row.
- Bars and columns are always drawn from zero.

**Step 2 — words and labels (G5, G6, G8, G10).**
- Combo axes titled with units. Value labels on when there are 12 or fewer bars, and the axis drops.
- Highlight the item the question named. The AI already filters on it, so a "compare to peers" answer can grey the others.
- The prompt asks for a note that **states the result** ("Venegas had the highest collections per visit, $160"). The card title names the content plus its period.
- Single numbers carry the unit, the period and, when the fiscal calendar allows, "vs last period".

**Step 3 — color and tables (G7, G9).**
- Run the palette through a color-blindness simulator and swap the green/red neighbours for true Okabe-Ito hues. Keep the contrast tests in `contrast.test.ts` passing.
- Totals row on result tables for counts and money.

**Step 4 — later (G11–G13):** small multiples, heat-map table, shared scales on reports.

**How each step is checked:** the same loop as the Ask UX work. Browser critique agents with the AI answer faked ($0) run the standard question set below until no high or medium issue is left. Then a fresh verify agent runs, and finally a short real-AI pass.

### Standard question set (use for every chart change)
1. how many visits did bescos have last week (single number)
2. billings, visits and denials of doctor becos the last 30 days (a few figures)
3. which provider in bishop had the highest collection per visit in the last 15 days (ranking)
4. visits by clinic last month (comparison, many categories)
5. charges and visits by week for the last 8 weeks (combo over time)
6. collections by quarter this fiscal year (fiscal order)
7. visits by week for each clinic last 8 weeks (several lines)
8. list the claims denied this week (table)
9. share of visits by visit type this period (part of a whole)

---

## Part 6 — Rules for the AI (what goes in the prompt)

The AI builds the query; the code draws it. The AI only needs rules that change the **query** or the **words**:
- Ranking questions ("highest", "top", "most") → `order-by` the measure descending, and a `limit` only when the user names a number ("top 5").
- Time questions → group by the time column or the fiscal `*_label` column, never by a bare `fiscal_period`.
- One message per answer: at most 2 groupings and, unless asked, one measure, or money plus a count for a combo.
- **Title:** what is shown and its period, at most 60 characters, no interpretation.
- **Note:** one sentence stating the result or the caveat, with periods in words.

Display choice, colors, sorting of unordered categories, top-N and formats stay in code, so they're the same for saved questions and reports.
