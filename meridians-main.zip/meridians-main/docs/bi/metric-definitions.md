# Operations metric definitions

Every number on the Operations page, in plain words first, then the SQL that
produces it from the `analytics` views (`sql/analytics/`). The Python code in
`src/operations_kpis.py` and `src/operations_claims.py` does the same counting
and is pinned by tests; this file is the single readable copy of the rules.
It will also be the reference when these metrics are rebuilt as Metabase questions.

## How to read this file

- **Source.** Only the `analytics.*` views. Nothing here reads the raw eCW
  tables. Views: `fct_appointment`, `fct_claim`, `fct_claim_line`,
  `fct_claim_dx`, `dim_location`, `dim_provider`, `dim_visit_type`,
  `sync_status` (column lists in `metabase-metadata.md`).
- **Placeholders.** The SQL uses two psql variables, `:from_date` and
  `:to_date` (inclusive, local America/Chicago dates), and optional filters
  written as comments. In Metabase these become `{{from_date}}` and
  `{{to_date}}`. Region, facility and provider filters add
  `AND region = ...`, `AND location_id = ...`, `AND provider_id = ...`.
- **Verified.** Each SQL block below was run once against the live local
  database (`meridians_ecw`) and executed without error. Result values are
  deliberately not written here.
- **"Counted" appointments.** An appointment counts toward rates only when it
  has already started AND its date is before the day of the last eCW sync
  (`is_counted`). Visits after the last pull still carry pre-visit statuses and
  would make the no-show rate look better than it is. Everything called "past"
  below means `is_counted`.
- **Small samples.** A group with fewer than 20 scheduled appointments (or fewer
  than 20 claims) gets no rate, only a dash. An ICD description is shown only if
  it appears on at least 10 claims.
- **Zero denominators.** A rate with a denominator of 0 is NULL (a dash), never 0.
- **Void claims** are excluded from every claim number.

Status groups (`fct_appointment.status_group`): `completed` = chk, arr, chk h;
`no_show` = n/s; `cancelled` = cancelled, canc; `rescheduled` = r/s; `open` =
still a pre-visit status (pen, conf, insv, insv+conf, n/a, action req, sp,
sp+conf, ina, rsphone, mfm info, pen_chkin, pen_pay, confphone, ksc); anything
else is `other`.

---

## Appointments

### Scheduled (the base for rates)

Counted appointments that were not cancelled and not rescheduled. Grain: one
row per appointment.

```sql
SELECT count(*) AS scheduled
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date
  AND status_group NOT IN ('cancelled', 'rescheduled');
  -- optional: AND region = ... / AND location_id = ... / AND provider_id = ...
```

### Booked (all past)

Every counted appointment, whatever its status. Used as the denominator for
cancel rate, reschedule rate and completion rate.

```sql
SELECT count(*) AS booked
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### No-show rate

Patients who did not come, as a share of scheduled visits. No-show = status
`n/s`. Facility colour band uses the unrounded rate: Meets under 10%, Watch
10-20% inclusive, Miss over 20%. Target 10%. Under 20 scheduled: no rate.

```sql
SELECT count(*) FILTER (WHERE status_group = 'no_show')::numeric
       / NULLIF(count(*) FILTER (WHERE status_group NOT IN ('cancelled', 'rescheduled')), 0)
       AS no_show_rate
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### Cancel rate

Cancelled appointments as a share of all past appointments.

```sql
SELECT count(*) FILTER (WHERE status_group = 'cancelled')::numeric
       / NULLIF(count(*), 0) AS cancel_rate
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### Reschedule rate

Rescheduled (`r/s`) appointments as a share of all past appointments.

```sql
SELECT count(*) FILTER (WHERE status_group = 'rescheduled')::numeric
       / NULLIF(count(*), 0) AS reschedule_rate
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### Show rate (API name `completion_rate`)

Of the visits that were kept on the calendar (scheduled), the share where the
patient arrived or was checked out. Formula: completed / scheduled. The API
kept the v1 name `completion_rate` for this number.

```sql
SELECT count(*) FILTER (WHERE status_group = 'completed')::numeric
       / NULLIF(count(*) FILTER (WHERE status_group NOT IN ('cancelled', 'rescheduled')), 0)
       AS show_rate
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### Completion rate (API name `completed_of_booked`)

Of everything booked, the share that was completed. Formula: completed / all
past. A different formula from Show rate, so the two have different labels.

```sql
SELECT count(*) FILTER (WHERE status_group = 'completed')::numeric
       / NULLIF(count(*), 0) AS completion_rate
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### Incomplete

Scheduled visits that are neither completed nor no-show (still carrying a
pre-visit or other status). `incomplete_rate` = incomplete / all past.

```sql
SELECT count(*) FILTER (WHERE status_group NOT IN ('cancelled', 'rescheduled', 'completed', 'no_show')) AS incomplete,
       count(*) FILTER (WHERE status_group NOT IN ('cancelled', 'rescheduled', 'completed', 'no_show'))::numeric
         / NULLIF(count(*), 0) AS incomplete_rate
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### Unresolved past

A data-quality figure: counted appointments whose status is still a pre-visit
status (`open`). They stay inside Scheduled.

```sql
SELECT count(*) AS unresolved_past
FROM analytics.fct_appointment
WHERE is_counted
  AND status_group = 'open'
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### Awaiting sync

Appointments that already started but fall on or after the last sync day, so
their final status is not known yet. Shown so a range made only of those days
says "not synced yet" instead of "no appointments".

```sql
SELECT count(*) AS awaiting_sync
FROM analytics.fct_appointment
WHERE is_past AND NOT is_counted
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### Upcoming booked

Appointments that have not started yet. Never part of any rate.

```sql
SELECT count(*) AS upcoming_booked
FROM analytics.fct_appointment
WHERE NOT is_past
  AND appointment_date BETWEEN :from_date AND :to_date;
```

### Lead time (average, median, buckets)

Days between when the visit was booked and the visit date, in Chicago local
dates, never below 0 (`lead_time_days`). Averages and medians use past rows that
are not cancelled or rescheduled and have a `created_at`. Buckets: Same-day,
1-2, 3-7, 8-14, 15-30, over 30; each bucket shows the scheduled count and its
no-show rate.

```sql
SELECT avg(lead_time_days)                                        AS lead_avg_days,
       percentile_cont(0.5) WITHIN GROUP (ORDER BY lead_time_days) AS lead_median_days
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date
  AND status_group NOT IN ('cancelled', 'rescheduled')
  AND lead_time_days IS NOT NULL;
```

```sql
SELECT CASE WHEN lead_time_days = 0 THEN 'Same-day'
            WHEN lead_time_days <= 2 THEN '1-2'
            WHEN lead_time_days <= 7 THEN '3-7'
            WHEN lead_time_days <= 14 THEN '8-14'
            WHEN lead_time_days <= 30 THEN '15-30'
            ELSE '>30' END AS lead_bucket,
       count(*) AS scheduled,
       count(*) FILTER (WHERE status_group = 'no_show')::numeric / NULLIF(count(*), 0) AS no_show_rate
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date
  AND status_group NOT IN ('cancelled', 'rescheduled')
  AND lead_time_days IS NOT NULL
GROUP BY 1
ORDER BY min(lead_time_days);
```

### Scheduling mix

How each past appointment got on the calendar. First match wins: Walk-in (visit
type code `W IN`), Unclassified (no created_at), Late-entered (created after the
visit began), Same-day (created on the visit's local date), Pre-scheduled
(created before that date). Cancelled and rescheduled rows are classified too,
so the counts add up to the past total. Rule lives in
`analytics.scheduling_mix_of()`.

```sql
SELECT scheduling_mix, count(*) AS appointments
FROM analytics.fct_appointment
WHERE is_counted
  AND appointment_date BETWEEN :from_date AND :to_date
GROUP BY 1
ORDER BY 1;
```

### Funnel: booked, kept, arrived, billed

Four steps over the filtered past set. Booked = all past. Kept = scheduled.
Arrived = completed. Billed = completed appointments that have at least one
non-void claim pointing at them. Step rates: kept/booked, arrived/kept (Show
rate), billed/arrived, arrived/booked (Completion rate), and pre-scheduled/booked.

```sql
WITH billed AS (
  -- one pass over claims, not one lookup per appointment (much faster)
  SELECT DISTINCT appointment_id FROM analytics.fct_claim
  WHERE NOT is_void AND appointment_id IS NOT NULL
)
SELECT count(*)                                                            AS booked,
       count(*) FILTER (WHERE a.status_group NOT IN ('cancelled', 'rescheduled')) AS kept,
       count(*) FILTER (WHERE a.status_group = 'completed')                AS arrived,
       count(*) FILTER (WHERE a.status_group = 'completed'
                          AND b.appointment_id IS NOT NULL)                AS billed
FROM analytics.fct_appointment a
LEFT JOIN billed b ON b.appointment_id = a.id
WHERE a.is_counted
  AND a.appointment_date BETWEEN :from_date AND :to_date;
```

### Visits per working day

Completed visits divided by the number of distinct local dates on which that
provider (or facility) had at least one completed visit.

```sql
SELECT provider_id,
       count(*)::numeric / count(DISTINCT appointment_date) AS visits_per_working_day
FROM analytics.fct_appointment
WHERE is_counted AND status_group = 'completed'
  AND appointment_date BETWEEN :from_date AND :to_date
GROUP BY provider_id;
```

### Share of total

A group's completed visits divided by all completed visits in the filtered set.

```sql
SELECT location_id,
       count(*)::numeric / sum(count(*)) OVER () AS share_of_total
FROM analytics.fct_appointment
WHERE is_counted AND status_group = 'completed'
  AND appointment_date BETWEEN :from_date AND :to_date
GROUP BY location_id;
```

### Core vs follow-up

Completed visits only. Follow-up when the visit type's text contains `est`,
`established`, `return`, `follow-up` or `f/u` as a whole word
(`analytics.is_follow_up_of`), otherwise Core.

```sql
SELECT CASE WHEN is_follow_up THEN 'Follow-up' ELSE 'Core' END AS visit_class,
       count(*) AS completed_visits
FROM analytics.fct_appointment
WHERE is_counted AND status_group = 'completed'
  AND appointment_date BETWEEN :from_date AND :to_date
GROUP BY 1;
```

### New vs established

Completed visits by patient type, from the visit-type text, whole words only:
`new` is New, `est` or `established` is Established, everything else Other
("Gestational", "Pregnancy Test", "Renewal" are Other). Share = n / completed.
Rule: `analytics.patient_type_of`.

```sql
SELECT patient_type,
       count(*) AS completed_visits,
       count(*)::numeric / sum(count(*)) OVER () AS share
FROM analytics.fct_appointment
WHERE is_counted AND status_group = 'completed'
  AND appointment_date BETWEEN :from_date AND :to_date
GROUP BY 1;
```

### Weekly comparison

This week against last week, same weekdays, by facility and provider. E = the
earlier of the range end and the day before the last sync day. This week runs
from the Monday of E's week to E; last week is the same weekdays one week
earlier. If E falls before the Monday of the range end's week, `this_week_empty`
is true, current-week blocks are zero and last week is the full previous
Monday-Sunday week. Arrows are green when no-show or cancel rates fall. The
under-20-scheduled rule is applied on the page.

```sql
WITH e AS (
  SELECT least(:to_date::date,
               (SELECT (max(last_synced_at) AT TIME ZONE 'America/Chicago')::date - 1
                FROM analytics.sync_status WHERE endpoint = 'appointments')) AS e
)
SELECT location_id,
       count(*) FILTER (WHERE a.appointment_date BETWEEN date_trunc('week', e.e)::date AND e.e
                         AND a.status_group NOT IN ('cancelled', 'rescheduled')) AS scheduled_this_week,
       count(*) FILTER (WHERE a.appointment_date BETWEEN date_trunc('week', e.e)::date - 7 AND e.e - 7
                         AND a.status_group NOT IN ('cancelled', 'rescheduled')) AS scheduled_last_week,
       count(*) FILTER (WHERE a.appointment_date BETWEEN date_trunc('week', e.e)::date AND e.e
                         AND a.status_group = 'no_show') AS no_show_this_week,
       count(*) FILTER (WHERE a.appointment_date BETWEEN date_trunc('week', e.e)::date - 7 AND e.e - 7
                         AND a.status_group = 'no_show') AS no_show_last_week
FROM analytics.fct_appointment a CROSS JOIN e
WHERE a.is_counted
  AND a.appointment_date BETWEEN date_trunc('week', e.e)::date - 7 AND e.e
GROUP BY location_id;
```

### Facility bands

Each facility's no-show rate is tagged Meets (under 10%), Watch (10-20%
inclusive) or Miss (over 20%). The band uses the unrounded rate.

```sql
SELECT l.name AS facility,
       CASE WHEN r.rate < 0.10 THEN 'Meets' WHEN r.rate <= 0.20 THEN 'Watch' ELSE 'Miss' END AS band
FROM (
  SELECT location_id,
         count(*) FILTER (WHERE status_group = 'no_show')::numeric
           / NULLIF(count(*) FILTER (WHERE status_group NOT IN ('cancelled', 'rescheduled')), 0) AS rate,
         count(*) FILTER (WHERE status_group NOT IN ('cancelled', 'rescheduled')) AS scheduled
  FROM analytics.fct_appointment
  WHERE is_counted AND appointment_date BETWEEN :from_date AND :to_date
  GROUP BY location_id
) r
JOIN analytics.dim_location l ON l.id = r.location_id
WHERE r.scheduled >= 20 AND r.rate IS NOT NULL;
```

---

## Claims: Ultrasound tab

Ultrasound line = CPT code (spaces removed) matching `768` plus two digits.
E&M line = 99202 to 99499. Both flags are computed in
`analytics.fct_claim_line` (`is_ultrasound`, `is_em`) and rolled up on
`fct_claim` (`has_ultrasound`, `has_em`, `has_non_us_line`). A line with no CPT
code counts as non-ultrasound. A claim reaches a facility only through its
appointment; claims with no matching appointment are "unassigned" and are
excluded whenever a region or facility filter is on.

### Ultrasound lines, claims and billed amount

```sql
SELECT count(*)                          AS ultrasound_lines,
       count(DISTINCT l.claim_id)        AS ultrasound_claims,
       sum(l.billed_amount)              AS ultrasound_billed
FROM analytics.fct_claim_line l
JOIN analytics.fct_claim c ON c.id = l.claim_id
WHERE l.is_ultrasound AND NOT c.is_void AND c.is_readable
  AND c.service_date BETWEEN :from_date AND :to_date;
```

An unreadable line amount counts as 0. Claims whose service date or claim-level
money cannot be read are skipped and counted (`skipped` = not void and not
readable).

```sql
SELECT count(*) AS skipped_claims
FROM analytics.fct_claim
WHERE NOT is_void AND NOT is_readable
  AND service_date BETWEEN :from_date AND :to_date;
```

### Ultrasound indications

Each ultrasound line's diagnosis pointers (a number, or a letter A to L) are
resolved against the claim's diagnosis list. Distinct claims are counted per
ICD-10 code and the top 15 are shown. Pointers that do not land on a diagnosis
with a code are counted as `unresolved_pointers` and skipped. The ICD text
leaves the database only through `analytics.icd_descriptions(from, to)`: the
most frequent description per code, on at least 10 claims, at most 80
characters, with no digit that is not in the code itself.

```sql
SELECT code AS icd_code, count(DISTINCT l.claim_id) AS claims
FROM analytics.fct_claim_line l
JOIN analytics.fct_claim c ON c.id = l.claim_id
CROSS JOIN LATERAL unnest(l.icd_codes) AS code
WHERE l.is_ultrasound AND NOT c.is_void AND c.is_readable
  AND c.service_date BETWEEN :from_date AND :to_date
GROUP BY code
ORDER BY claims DESC, code
LIMIT 15;
```

```sql
SELECT icd_code, description
FROM analytics.icd_descriptions(:from_date, :to_date)
ORDER BY icd_code
LIMIT 15;
```

### Claims without E&M

Non-void claims with at least one line, at least one non-ultrasound line and
no E&M line, as a share of the eligible set (same definition without the E&M
test). Denominator 0 gives NULL.

```sql
SELECT count(*) FILTER (WHERE NOT has_em)::numeric / NULLIF(count(*), 0) AS pct_without_em,
       count(*) FILTER (WHERE NOT has_em) AS claims_without_em,
       count(*) AS eligible
FROM analytics.fct_claim
WHERE NOT is_void AND is_readable
  AND line_count >= 1 AND has_non_us_line
  AND service_date BETWEEN :from_date AND :to_date;
```

---

## Claims: Billing tab

### Pending: awaiting billing

Claims whose status description is Pending, Charge Entry or Claim Created
(not yet sent to a payer). The set can be adjusted by the owner; the full
status table is always shown.

```sql
SELECT count(*) AS pending_claims, sum(total_charge) AS pending_charges
FROM analytics.fct_claim
WHERE NOT is_void AND is_readable
  AND claim_status_description IN ('Pending', 'Charge Entry', 'Claim Created')
  AND service_date BETWEEN :from_date AND :to_date;
```

### Denied and denial rate

Denied = claim status contains "denied" (any case). Denial rate = denied /
claims. By provider, a provider with fewer than 20 claims has no rate.

```sql
SELECT provider_name,
       count(*) FILTER (WHERE claim_status ILIKE '%denied%') AS denied,
       count(*) AS claims,
       CASE WHEN count(*) >= 20
            THEN count(*) FILTER (WHERE claim_status ILIKE '%denied%')::numeric / count(*) END AS denial_rate
FROM analytics.fct_claim
WHERE NOT is_void AND is_readable
  AND service_date BETWEEN :from_date AND :to_date
GROUP BY provider_name;
```

### Status table

Status (blank is "Unknown"), claim count, charges, payments and balance.

```sql
SELECT claim_status, count(*) AS claims,
       sum(total_charge) AS charges, sum(total_payment) AS payments, sum(balance) AS balance
FROM analytics.fct_claim
WHERE NOT is_void AND is_readable
  AND service_date BETWEEN :from_date AND :to_date
GROUP BY claim_status
ORDER BY claims DESC;
```

### Balance and aging

Balance = sum of `balance` over non-void claims. Aging buckets 0-30, 31-60,
61-90 and 90+ days by (today in Chicago minus service date), over claims with a
balance above 0. A future service date counts as 0-30. Each bucket shows the
sum and the claim count. Bucket rule: `fct_claim.aging_bucket`.

```sql
SELECT aging_bucket, count(*) AS claims, sum(balance) AS balance
FROM analytics.fct_claim
WHERE NOT is_void AND is_readable AND aging_bucket IS NOT NULL
  AND service_date BETWEEN :from_date AND :to_date
GROUP BY aging_bucket
ORDER BY min(CASE aging_bucket WHEN '0-30' THEN 1 WHEN '31-60' THEN 2 WHEN '61-90' THEN 3 ELSE 4 END);
```

### Charges and payments per location

By service date, from `total_charge` and `total_payment`. Claims with no
location are the "Unassigned" row.

```sql
SELECT l.name AS facility,
       sum(c.total_charge) AS charges, sum(c.total_payment) AS payments
FROM analytics.fct_claim c
LEFT JOIN analytics.dim_location l ON l.id = c.location_id
WHERE NOT c.is_void AND c.is_readable
  AND c.service_date BETWEEN :from_date AND :to_date
GROUP BY l.name;
```

---

## Portfolio tab

### Revenue per visit

Payments divided by completed visits, per facility and month. Visits come from
`fct_appointment` (completed, counted); payments from `fct_claim` by service
date. A facility with no completed visits has no value.

```sql
WITH visits AS (
  SELECT location_id, count(*) AS completed
  FROM analytics.fct_appointment
  WHERE is_counted AND status_group = 'completed'
    AND appointment_date BETWEEN :from_date AND :to_date
  GROUP BY location_id
), pay AS (
  SELECT location_id, sum(total_payment) AS payments
  FROM analytics.fct_claim
  WHERE NOT is_void AND is_readable
    AND service_date BETWEEN :from_date AND :to_date
  GROUP BY location_id
)
SELECT l.name AS facility, p.payments, v.completed,
       p.payments / NULLIF(v.completed, 0) AS revenue_per_visit
FROM visits v
LEFT JOIN pay p ON p.location_id = v.location_id
JOIN analytics.dim_location l ON l.id = v.location_id;
```

---

## Not available

The eCW feed does not carry these, so the dashboard does not show them and no
view has a column for them: capacity, open slots, fill rate, and patient
demographics.
