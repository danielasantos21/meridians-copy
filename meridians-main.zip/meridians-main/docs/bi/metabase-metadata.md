# Metabase metadata and connection recipe

How to point Metabase (open source edition) at the `analytics` schema later,
and how each column should be tagged. Nothing here is set up yet. For the
meaning of each metric see `metric-definitions.md`.

## 1. Connection recipe

1. The owner creates a read-only database role (cannot log in yet):
   `./venv/bin/python scripts/apply_analytics_views.py --create-reader-role <name>`
   (the name is lower-case letters, digits and underscores). The script grants
   only: USAGE on schema `analytics`, SELECT on its tables and views, EXECUTE
   on its functions, and the same SELECT on tables created later.
2. Separately, the owner gives that role `LOGIN` and a password
   (`ALTER ROLE <name> LOGIN PASSWORD '...'`), or does both steps at once with
   `ECW_READER_PASSWORD=... ./venv/bin/python scripts/apply_analytics_views.py
   --create-reader-role <name> --login` (password from the environment, never
   a flag). The password goes in the password manager and Metabase, never in a
   file in this repo.
   **The same login serves BI native SQL.** The Meridian server connects the
   `/api/v2/bi/native` endpoint as this login: set `ECW_READER_USER=<name>` and
   `ECW_READER_PASSWORD` in the server environment (host and database come
   from `ECW_DB_*`). Because that login can read `analytics` and nothing else,
   native SQL does not depend on filtering the SQL text or on `SET ROLE`. If
   `ECW_READER_USER` is unset, native SQL answers 503. Do not give this login
   any other privilege: the server refuses to run native SQL if it is a
   superuser/role creator or can read `public.cobalt_rows` / `cobalt_latest`.
3. In Metabase: Admin > Databases > Add database > PostgreSQL, host and database
   name of the eCW snapshot, user = the reader role. Set **Schemas** to
   "Only these..." and enter `analytics`. Never `public`, never `phi`.
4. Sync schedule: hourly metadata sync. Field values scan: daily.
5. Open source Metabase has no per-tenant row security, so use **one connection
   (and one reader role) per tenant**. The current snapshot is one tenant.

## 2. Security model

- **Views are owner-run** (`security_invoker = false`). A view runs with the
  rights of its owner, who can read the raw eCW tables. The reader role
  therefore needs the `analytics` schema only and **cannot** read
  `public.cobalt_latest` or `public.cobalt_rows`. A live test proves this
  (`tests/test_analytics_sql_live.py`, rolled back).
- **Tenant isolation today** is the one-row table `analytics.tenant`: every view
  carries its `org_id`. It is seeded by the apply script from the environment,
  never stored in a file.
- **Later:** row-level security and `security_invoker` views arrive when the
  data moves to RDS (spec rule 8). Until then, one connection per tenant.
- **Where it lives:** the `analytics` schema is on the eCW snapshot database and
  is applied by `scripts/apply_analytics_views.py` (idempotent, one transaction,
  only touches objects named `analytics.*`). Alembic manages Meridian's own
  database, not this one.
- **No patient identifiers.** No view exposes patient names, dates of birth,
  contact details or any `emr_*` key. Provider and clinic ids are clinician and
  clinic ids. ICD descriptions (typed free text) are available only through the
  function `analytics.icd_descriptions(from_date, to_date)`, which applies the
  10-claim minimum. CPT descriptions are standard billing text and are shown.

## 3. Tables, views and columns

Foreign-key tags to set in the Metabase data model:

| From | To |
|---|---|
| `fct_appointment.location_id` | `dim_location.id` |
| `fct_appointment.provider_id` | `dim_provider.id` |
| `fct_appointment.visit_type_id` | `dim_visit_type.id` |
| `fct_claim.appointment_id` | `fct_appointment.id` |
| `fct_claim.location_id` | `dim_location.id` |
| `fct_claim.provider_id` | `dim_provider.id` |
| `fct_claim_line.claim_id` | `fct_claim.id` |
| `fct_claim_dx.claim_id` | `fct_claim.id` |

Semantic type rules used in the tables below: money columns are Currency;
`*_rate` columns would be Percentage; `status`, `status_group`,
`scheduling_mix`, `aging_bucket`, `region`, `*_type` are Category; `created_at`
is Creation date; `id` is the entity key. Raw eCW ids (`*_ehr_id`),
`visit_code`, `provider_name_raw`, `claim_status_code` and `org_id` are hidden:
they are plumbing, not for questions. Week and month starts are for grouping.

Column tables below were generated from `information_schema.columns` (schema `analytics`).

### analytics.dim_location

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `id` | text | Id | Entity key | Visible |
| `ehr_id` | text | Ehr id | No semantic type | Hidden in Metabase |
| `name` | text | Name | Name | Visible |
| `region` | text | Region | Category | Visible |
| `is_hospital` | boolean | Is hospital | Category (true/false) | Visible |
| `org_id` | uuid | Org id | No semantic type (hidden) | Hidden in Metabase |

### analytics.dim_provider

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `id` | text | Id | Entity key | Visible |
| `ehr_id` | text | Ehr id | No semantic type | Hidden in Metabase |
| `name` | text | Name | Name | Visible |
| `npi` | text | NPI | No semantic type | Visible |
| `specialty` | text | Specialty | Category | Visible |
| `org_id` | uuid | Org id | No semantic type (hidden) | Hidden in Metabase |

### analytics.dim_visit_type

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `id` | text | Id | Entity key | Visible |
| `code` | text | Code | No semantic type | Visible |
| `description` | text | Description | No semantic type | Visible |
| `patient_type` | text | Patient type | Category | Visible |
| `is_follow_up` | boolean | Is follow up | Category (true/false) | Visible |
| `org_id` | uuid | Org id | No semantic type (hidden) | Hidden in Metabase |

### analytics.fct_appointment

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `id` | text | Id | Entity key | Visible |
| `org_id` | uuid | Org id | No semantic type (hidden) | Hidden in Metabase |
| `location_id` | text | Location id | Foreign key -> dim_location.id | Visible |
| `provider_id` | text | Provider id | Foreign key -> dim_provider.id | Visible |
| `visit_type_id` | text | Visit type id | Foreign key -> dim_visit_type.id | Visible |
| `appointment_at` | timestamp with time zone | Appointment at | Temporal | Visible |
| `appointment_date` | date | Appointment date | Temporal | Visible |
| `hour` | integer | Hour | Quantity | Visible |
| `weekday` | integer | Weekday | Quantity | Visible |
| `week_start` | date | Week start | Temporal | Visible |
| `month_start` | date | Month start | Temporal | Visible |
| `created_at` | timestamp with time zone | Created at | Creation date | Visible |
| `lead_time_days` | integer | Lead time days | Quantity | Visible |
| `status` | text | Status | Category | Visible |
| `status_group` | text | Status group | Category | Visible |
| `scheduling_mix` | text | Scheduling mix | Category | Visible |
| `is_past` | boolean | Is past | Category (true/false) | Visible |
| `is_counted` | boolean | Is counted | Category (true/false) | Visible |
| `duration_min` | numeric | Duration min | Quantity | Visible |
| `region` | text | Region | Category | Visible |
| `patient_type` | text | Patient type | Category | Visible |
| `is_follow_up` | boolean | Is follow up | Category (true/false) | Visible |
| `location_ehr_id` | text | Location ehr id | No semantic type | Hidden in Metabase |
| `provider_ehr_id` | text | Provider ehr id | No semantic type | Hidden in Metabase |
| `visit_code` | text | Visit code | No semantic type | Hidden in Metabase |
| `provider_name_raw` | text | Provider name raw | No semantic type | Hidden in Metabase |

### analytics.fct_claim

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `id` | text | Id | Entity key | Visible |
| `org_id` | uuid | Org id | No semantic type (hidden) | Hidden in Metabase |
| `appointment_id` | text | Appointment id | Foreign key -> fct_appointment.id | Visible |
| `provider_id` | text | Provider id | Foreign key -> dim_provider.id | Visible |
| `provider_ehr_id` | text | Provider ehr id | No semantic type | Hidden in Metabase |
| `provider_name` | text | Provider name | No semantic type | Visible |
| `location_id` | text | Location id | Foreign key -> dim_location.id | Visible |
| `location_ehr_id` | text | Location ehr id | No semantic type | Hidden in Metabase |
| `service_date` | date | Service date | Temporal | Visible |
| `claim_date` | date | Claim date | Temporal | Visible |
| `claim_status` | text | Claim status | Category | Visible |
| `claim_status_code` | text | Claim status code | No semantic type | Hidden in Metabase |
| `claim_status_description` | text | Claim status description | Category | Visible |
| `total_charge` | numeric | Total charge | Currency | Visible |
| `total_payment` | numeric | Total payment | Currency | Visible |
| `net_payment` | numeric | Net payment | Currency | Visible |
| `net_adjustment` | numeric | Net adjustment | Currency | Visible |
| `patient_responsibility` | numeric | Patient responsibility | Currency | Visible |
| `balance` | numeric | Balance | Currency | Visible |
| `is_void` | boolean | Is void | Category (true/false) | Visible |
| `is_readable` | boolean | Is readable | Category (true/false) | Visible |
| `has_em` | boolean | Has em | Category (true/false) | Visible |
| `has_ultrasound` | boolean | Has ultrasound | Category (true/false) | Visible |
| `has_non_us_line` | boolean | Has non us line | Category (true/false) | Visible |
| `line_count` | integer | Line count | Quantity | Visible |
| `aging_bucket` | text | Aging bucket | Category | Visible |

### analytics.fct_claim_line

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `id` | text | Id | Entity key | Visible |
| `claim_id` | text | Claim id | Foreign key -> fct_claim.id | Visible |
| `org_id` | uuid | Org id | No semantic type (hidden) | Hidden in Metabase |
| `line_number` | integer | Line number | Quantity | Visible |
| `cpt_code` | text | CPT code | No semantic type | Visible |
| `cpt_description` | text | CPT description | No semantic type | Visible |
| `billed_amount` | numeric | Billed amount | Currency | Visible |
| `allowed_amount` | numeric | Allowed amount | Currency | Visible |
| `units` | numeric | Units | Quantity | Visible |
| `place_of_service` | text | Place of service | Category | Visible |
| `is_ultrasound` | boolean | Is ultrasound | Category (true/false) | Visible |
| `is_em` | boolean | Is em | Category (true/false) | Visible |
| `service_date` | date | Service date | Temporal | Visible |
| `icd_positions` | ARRAY | ICD positions | No semantic type | Visible |
| `unresolved_pointer_count` | integer | Unresolved pointer count | Quantity | Visible |
| `icd_codes` | ARRAY | ICD codes | No semantic type | Visible |

### analytics.fct_claim_dx

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `id` | text | Id | Entity key | Visible |
| `claim_id` | text | Claim id | Foreign key -> fct_claim.id | Visible |
| `org_id` | uuid | Org id | No semantic type (hidden) | Hidden in Metabase |
| `position` | integer | Position | Quantity | Visible |
| `icd_code` | text | ICD code | No semantic type | Visible |
| `is_primary` | boolean | Is primary | Category (true/false) | Visible |

### analytics.sync_status

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `id` | text | Id | Entity key | Visible |
| `endpoint` | text | Endpoint | No semantic type | Visible |
| `row_count` | integer | Row count | Quantity | Visible |
| `last_synced_at` | timestamp with time zone | Last synced at | Temporal | Visible |
| `org_id` | uuid | Org id | No semantic type (hidden) | Hidden in Metabase |

### analytics.tenant

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `org_id` | uuid | Org id | No semantic type (hidden) | Hidden in Metabase |

### analytics.region_map

| Column | Type | Display name | Semantic type | Visibility |
|---|---|---|---|---|
| `kind` | text | Kind | No semantic type | Visible |
| `match_key` | text | Match key | No semantic type | Visible |
| `region` | text | Region | Category | Visible |

### Functions

`safe_date`, `safe_ts`, `safe_num`, `safe_bool`, `money_ok`, `cpt_clean`
(parsing helpers, bad input gives NULL), `region_of`, `status_group_of`,
`scheduling_mix_of`, `patient_type_of`, `is_follow_up_of`, `icd_entries`,
`resolve_icd_pointers`, `resolve_icd_codes`, `icd_pick`, and
`icd_descriptions(from_date, to_date)`. Metabase does not list functions; they
exist so the rules are written once and tested.

### Re-apply checklist

After any change to `sql/analytics/*.sql`:

1. `./venv/bin/python scripts/apply_analytics_views.py --dry-run` (prints the SQL, opens no connection).
2. `./venv/bin/python scripts/apply_analytics_views.py` (twice is safe).
3. `./venv/bin/python scripts/apply_analytics_views.py --check` (every object must say PASS).
4. `./venv/bin/python -m pytest tests/test_apply_analytics_views.py tests/test_analytics_sql_live.py`.
5. In Metabase: Admin > Databases > Sync database schema now, then re-scan field values; check the FK tags above are still set.
6. If a column was added, add its row to the tables above (regenerate from `information_schema.columns`).

## 4. Never rename a view in place

Metabase saves questions against a view's name and columns. Renaming or
dropping a column breaks them silently. Add a new `_v2` view (or column) next
to the old one, move the questions over, then retire the old one.
