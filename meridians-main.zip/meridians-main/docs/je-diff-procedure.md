# The journal-entry diff procedure

**Phase:** 3, step 12 (`docs/aws-migration-plan.md`), re-run at Flip 2 (Phase 9)
**Script:** `scripts/diff_je_output.py`
**Status:** the script and its tests exist; the rehearsal periods are named (payroll only —
see "Rehearsal periods" below); no rehearsal diff has been run yet.

## What this is for

Before the new system may book a period, it has to produce the same journal entries as the
old one for a period whose numbers are already known to be right. Not "close enough" —
the same. This procedure is that check, and its exit code is the gate.

## The exact command

```bash
venv/bin/python scripts/diff_je_output.py OLD_DIR NEW_DIR
venv/bin/python scripts/diff_je_output.py OLD_DIR NEW_DIR --json > diff.json   # for a report
venv/bin/python scripts/diff_je_output.py --help                              # the column lists
```

`OLD_DIR` is the output folder the old system produced for the rehearsal period; `NEW_DIR`
is the folder the new system produced from the same input workbook. Both are read-only to
the script: it writes nothing, opens no network connection, and makes no AWS call.

**Exit 0 only when every matched file is identical and nothing is missing on either side.**
Exit 1 means at least one file differs, is absent, or could not be read. Exit 2 is a usage
error.

Both folder paths are printed **relative to the working directory, or as a basename** if the
folder sits outside it — an absolute output path on the laptop names the operator and often
the client, in a report whose whole point is that it can be pasted somewhere.

## What is compared

| | |
|---|---|
| **CSV content** | Every `.csv` under either folder. These are the files that are imported into NetSuite and QuickBooks. |
| **Presence of everything else** | An `.xlsx` workbook is a ZIP whose member timestamps change on every write, so a byte comparison of one is meaningless. The workbooks are checked for presence and reported as `not compared`; their numbers are checked through the CSVs they summarise. |

Within a CSV:

- **The header must match exactly.** A renamed or reordered column is a difference.
- **Rows are compared as a multiset, sorted on the whole row, and matched BY POSITION** —
  every compared column, left to right, after ids are dropped and amounts are normalised. A
  journal entry imports as a set of lines, so the same lines in a different order are the
  same entry; a line that appears twice on one side only is a real difference and is
  reported as one.
- **Amounts are compared exactly, quantized to the cent. There is no tolerance.**
  `1,234.50`, `1234.5` and `1234.500` are the same amount (the old exporters write
  `{:,.2f}`, the QuickBooks ones `{:.2f}`); `1234.00` and `1234.01` are not. `(1,234.00)` is
  accounting negative, and `-0.00` is normalised to `0.00` so a signed zero never reads as a
  difference.
- **Everything that is not an amount column is compared as an exact string**, with
  surrounding whitespace stripped. `001` is not `1` in a Class, a location code, an account
  or a journal number — the leading zeros are part of the code.

### Which columns are amounts

Numeric normalisation is opt-in, by header name. Applying it to every cell that looked like
a number is what made `001` and `1` the same Class. The list is:

| Rule | Columns |
|---|---|
| Exact name (a leading `*` is stripped, case is ignored) | `Debit`, `Credit`, `Debits`, `Credits`, `Amount`, `Total`, `Net`, `Gross` |
| Any header ending in `Amount` | `Line Amount`, `Tax Amount`, … |
| Any header ending in `Total` | `Period Total`, `Grand Total`, … |

Everything else — `Class`, `Account`, `Location`, `Department`, `*JournalNo`, `Date` — is a
string.

### Files that cannot be compared

Two shapes FAIL the file rather than being compared, because comparing them would pass a
file that should not pass:

| Status | When |
|---|---|
| `malformed` | a **duplicate header name** (rows used to be `{header[i]: cell}`, so `Date,Debit,Debit` kept one `Debit` and a differing first one compared **equal**), or a **row whose field count differs from the header's** (a short row used to be padded with blanks). |
| `unreadable` | the bytes are not valid UTF-8. Reported as a failing file with the byte offset, never as a traceback. |

Both exit 1. A wholly blank line is still skipped: a trailing newline is not a row.

## How filenames are matched

A file's identity is its path inside the output folder with any run timestamp stripped from
the filename: a `_YYYYMMDD` or `_YYYYMMDD_HHMMSS` **token, wherever in the stem it sits** —
a configurable pattern is free to put `{date}` in the middle, and a timestamp that is not
the last token is still a timestamp. It must be a whole token (delimited by `_` or the end
of the stem), so an 8-digit run inside a longer word is left alone.
`src/exporters.py` glues `datetime.now()` onto the workbook name (`:1421`) and offers a
`{date}` placeholder to every configurable pattern (`:684`, `:759`, `:802`); that says when
the file was written, never what is in it.

So `data/Revenue_Workbook_P08_FY25_20250824_101500.xlsx` and
`data/Revenue_Workbook_P08_FY25_20260915_083000.xlsx` are the same file, and so are
`JE_Revenue_20250824_101500_Bishop.csv` and `JE_Revenue_Bishop.csv`.

The identity patterns a rehearsal is actually about:

| Pattern | Channel |
|---|---|
| `JE_Revenue_{Location}_{Period}_{FY}.csv` | NetSuite revenue JE — one per location, 15 of them |
| `JE_Revenue_*_QB.csv` | the QuickBooks twin (`src/qb_export_artifacts.py`) |
| `JE_Payroll_Main_{Period}_{FY}.csv`, `JE_Payroll_Provision_{Period}_{FY}.csv` | MX payroll (`src/payroll_exporter.py`) |
| `JE_Payroll_*_QB.csv` | the QuickBooks twin (`src/payroll_qb_exporter.py`) |
| `JE_ADP_*_P{nn}_FY{yy}.csv` | ADP/MSO booking — historical only; `src/adp_je_generator.py` was deleted 2026-09-22 with the Jinja `/adp_payroll` wizard (CX-API-03) |
| `{journal_no}_QB.csv` | QB USA payroll, one file per journal (`src/qb_usa_payroll_exporter.py`) |

## Columns that are normalised away

These identify the *run*, not the accounting. Two correct runs of the same period disagree
on every one of them by construction, so comparing them would guarantee a false difference.
None of them reaches NetSuite or QuickBooks as an amount, an account, a date or a
description.

`run_id`, `batch_id`, `artifact_id`, `export_id`, `id`, `uuid`, `storage_path`,
`created_at`, `generated_at`, `exported_at`, `run_timestamp`

`*JournalNo` is deliberately **not** on that list: the journal number is accounting identity
and a change in it is a real difference.

## Columns that are redacted in the report

These are **compared in full** — a difference in one still fails the diff — but what the
report prints is a six-character digest of the value, so equal values show equal digests and
no name or identifier leaves the process. That is what makes the output safe to paste into a
phase report.

**The digest is salted, with a fresh random salt per run.** An unsalted `sha256(value)[:6]`
is a dictionary lookup for anyone holding the employee roster, which is everyone who could
be reading the report. The salt is printed in the report header (and in `--json`, as
`redaction_salt`):

```
redaction-salt: 4f7a91c0  (digests are comparable within this report only)
```

Equal values share a digest **within one report and nowhere else**: the same employee
redacts differently in yesterday's run, so never carry a digest from one report to another.

| Column | Why |
|---|---|
| `Name`, `Employee`, `Employee Name`, `Provider`, `Billing Provider`, `Vendor` | a person; QuickBooks' `Name` column is the employee being paid |
| `Patient Acct No`, `Patient`, `patient_id`, `Claim No`, `Encounter Id`, `Member Id`, `DOB`, `SSN`, `File Number` | identifiers — PHI under 45 CFR 164.514(b)(2) (ADR 0012) |
| `Description`, `Line Description`, `Memo` | free text; the revenue JE's description is formulaic, but a QB USA payroll line description can name the employee it pays |

At most the first 20 differing rows per file are printed, per side.

## There is no allowlist

The plan requires a match, not a reviewed list of exceptions. `--ignore` is accepted by the
argument parser **only so it can be refused by name**: passing it exits 2 with a message
saying so. A difference between the old and the new journal entries is either understood and
fixed, or the cutover does not happen.

## Rehearsal periods

Named 2026-10-12. The only periods with **both** a stored input and a stored old output are:

| Period | Process | Batch | Stored input (Supabase `uploads` bucket) | Also usable |
|---|---|---|---|---|
| FY26-P09 | MX payroll | **91** | one workbook under `{org_id}/mx-payroll/{run day}/` | 87, 88, 90 (superseded, same period; each has input and output) |
| FY26-P09 | QB USA payroll | **89** | 8 CSVs under `{org_id}/qb-usa-payroll/{run day}/{run_id}/` | — |

The input filenames are not recorded here: they are read from `import_batches.input_file` on
the day of the fetch and written in the rehearsal log (cutover.md § "Payroll JE comparison
(rehearsal)", step a).

**The comparison is same-day, not against the stored output.** `main`'s payroll code changed
after both runs — MX books by department since 2026-10-05; QB USA books negatives as credits and
splits leftover UNUM/BCBS charges across everyone paid — so the September output is no longer
what a correct run produces, and this diff has no allowlist. Instead, on one day:

1. fetch the stored inputs onto the PHI volume (the commands are in `cutover.md`; the
   `uploads` bucket is **not** empty — `persist_to_storage` has written every Render-era upload
   there since v1.2.0; `scripts/mirror_supabase_storage.py` copies it whole at cutover, not per run);
2. **OLD:** run each input on production (`www`, Render) **without booking** — an unbooked
   run expires — and download its JE CSVs;
3. **NEW:** run the same inputs, with the same parameters, on staging right after the
   rehearsal data load, so both sides read the same roster and config;
4. `venv/bin/python scripts/diff_je_output.py OLD_DIR NEW_DIR` per process. **Pass = exit 0.**

*QB USA roster:* 29 `qb_usa_employee` rows changed 2026-10-02 20:35 UTC, after batch 89. That
rules out the stored batch-89 output as the OLD side; it does not affect a same-day run, where
both sides read today's roster.

*Revenue:* no revenue input was ever stored, so there is **no revenue rehearsal period**. One
exists only if Andres supplies the original billing exports for a closed period; the same
same-day procedure then applies on the `qb-revenue` screen.

Record each run here:

| Date | Process / batch | Input filename (name only) | Exit code |
|---|---|---|---|
| | MX payroll FY26-P09 / 91 | | |
| | QB USA payroll FY26-P09 / 89 | | |

**Never** a client path or a patient or employee identifier in this tracked file. Until both
rows show exit 0, Phase 3 step 12 is **not** complete, however green the script's own tests
are: the tests prove the comparison is correct, not that the two systems agree on a real
period.
