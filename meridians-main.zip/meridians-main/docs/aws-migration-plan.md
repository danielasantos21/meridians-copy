# Meridian → AWS Migration Plan (v3)

**Repo:** `NS_Proccess_QB` — this copy is the `aws-migration` worktree (`NS_Proccess_QB-aws`)
**Supersedes:** v2 (2026-09-01, on the `aws-trial` branch) and v1 (2026-08-29)
**Date:** 2026-09-15 (v3.1: decisions recorded, cutover-first order)
**Status:** decided. Phase 0 is safe to start today. §8 records every decision; the short "confirm when convenient" list at its end never blocks a phase.
**Drives:** `docs/aws-migration-prompt.md` — the instructions pasted into the session that executes this. The prompt wins on architecture; this plan wins on effort, cost, sequencing detail, data safety and decisions — **including phase order, which this plan changes (D-16) and the prompt must be edited to match.**

> **Plain-language note.** This plan defines each technical term the first time it appears. If a term is unfamiliar and not defined nearby, it was defined earlier — search the document for it.

---

## 0. What changed, in one paragraph

v2 planned a *lift*: keep Flask, move Postgres to RDS, move files to S3, move login to Cognito late, script it with Terraform, two cutovers. The prompt asks for a *rebuild on the way over*: the same destination (RDS, S3, Cognito, ECS) but with FastAPI beside Flask, an Alembic-managed schema with row-level security reinstated, AWS CDK instead of Terraform, a staging/production split inside one account, Cognito early with both token types accepted, SES replacing Resend, a process framework with a separate worker, a `/api/v3` platform with machine clients and webhooks, and a full API-security test programme. Everything in v2 that was about *safety* — the byte-for-byte journal-entry diff, the points of no return, the `phi` schema, `custom:app_uid`, the dual-maintenance rule, Track C — survives unchanged. **v3.1 decides the order: cutover first.** Meridian leaves Render and Supabase after Phase 9; the process framework (Phase 11) and the API platform (Phase 12) are built on AWS afterwards. That puts the first AWS-booked journal entry at roughly month 10-14 at three focused days a week instead of 16-24, with a shorter window in which two database backends must both be kept correct. Steady-state cost is ~$238/month with staging torn down between phases and no Multi-AZ. §8 records every decision and the reasoning; §9 lists every change from v2.

---

## 1. Decision summary

### What we are doing

Moving Meridian's revenue/payroll automation entirely onto AWS under an AWS **Business Associate Addendum** (BAA — the HIPAA contract under which a vendor may hold protected health information), and shutting down both Render and Supabase.

| Layer | From (today) | To (v3) | v2 said |
|---|---|---|---|
| Compute | Render web service (gunicorn, one worker) + Render Next.js service | **ECS Fargate** (serverless containers) — `api` (FastAPI, with Flask inside the same container during transition) and `web` (Next.js) at cutover; a `worker` service (generic process worker fed by SQS) added in Phase 11 — behind an ALB, behind CloudFront | one API task + one web task, ALB only |
| Database | Supabase Postgres 17.6 via PostgREST + some raw `psycopg2` | **Amazon RDS for PostgreSQL 17.x**, single-AZ (D-14); schema managed by **Alembic** (a Python migration tool) baselined from the existing SQL migrations; data access through a thin **psycopg2** repository layer with explicit `org_id` on every query **and** row-level security (RLS) reinstated via `app.org_id` | raw SQL via `src/pg.py`, RLS dropped |
| Object storage | Supabase Storage (3 buckets, ~50 objects) | Two S3 buckets (`artifacts`, `phi`), SSE-KMS with customer-managed keys, versioning; Object Lock on audit-log buckets | same, no Object Lock |
| Identity | Supabase Auth (email + Google + Microsoft) | **Amazon Cognito** user pool, MFA, Google/Microsoft as federated IdPs, **User Migration Lambda** (no forced reset), **both Supabase and Cognito tokens accepted during transition** | same pool design, but staged after the data cutover |
| Authorization | Postgres tables (`roles`, `role_permissions`, `org_modules`, `superadmins`, `role_permission_processes`) | **unchanged — stays in Postgres**, never in Cognito groups or token claims | same |
| Email | Resend (invites), Supabase (auth mail) | **Amazon SES** for everything; Resend removed in Phase 7 | SES for auth mail only; Resend kept |
| Background work | `threading.Thread` inside the Flask process | Unchanged at cutover (one api task, as on Render today); then a generic **worker** container consuming **SQS** (a managed queue) with a dead-letter queue, results serialized to S3/Postgres (Phase 11) | not in scope (deferred) |
| API surface | `/api/v1` (legacy Flask), `/api/v2` (contract in `docs/api-v2-contract.md`) | `/api/v2` ported to FastAPI before cutover; new **`/api/v3`** for humans, our own scripts, and outside machines with scopes, machine auth, webhooks (Phase 12) | `/api/v2` only |
| Infrastructure as code | Render dashboard + `render.yaml` | **AWS CDK in Python** (infrastructure written in code; D-21) — nothing clicked in the console | Terraform |
| Environments | one (production on Render) | **staging + production in one AWS account**, isolated by separate VPCs, IAM roles, KMS keys and tags; staging is **torn down between phases** (D-15); built so production can later be split into its own account by redeploying the same CDK stacks | one environment, staging = the pre-cutover instance |

### The three structural decisions that still shape everything

1. **One AWS account (<account-id>), isolated by VPC, IAM and KMS — with two environments in it.** Decided (D-02, reconfirmed by the prompt). Every resource is named `meridian-<env>-<component>-<purpose>` and tagged `Project`, `Environment`, `Owner`, `DataClassification`, `CostCenter`, `ManagedBy=cdk`. No account id is hard-coded anywhere in CDK; environment is a stack parameter; no state is shared between environments. §2.4 records what the shared account costs us.
2. **PHI is quarantined in a `phi` schema** with its own database role and grant boundary, plus a keyed-HMAC token (`patient_ref`) for the only reachable use of patient identifiers. Unchanged from v2 (§2.3).
3. **Cutover first, platform second (D-16).** Flip 1 (auth → Cognito) happens at the end of Phase 4, while data is still on Supabase, and stays reversible until the Phase 10 cut-off. Flip 2 (compute + data + storage → AWS) is Phase 9 and carries the first hard point of no return. The process framework and the API platform are Phases 11-12, built on AWS with no second backend to keep alive.

### The most important correction, carried from v2

**The existing AWS resources in account <account-id> do not belong to this repo.** The ECS service `meridian-backend`, ALB `meridian-alb`, CloudFront distribution for `ai.meridiansgrp.com` and its WAF, S3 bucket `meridian-frontend`, Cognito pool `<assistant-pool-id>`, the `meridian/assistant-db-app` and `meridian/business-db-app` secrets, RDS `meridian-postgres` (PostgreSQL 16.13 — unusable for us regardless) and the bucket `meridian-terraform-state-<account-id>` all belong to a separate LLM-assistant application or to unknown owners. **Off-limits: do not deploy onto, modify, restore, or delete any of them** (P-10 in §8 drops v2's "inspect the snapshot" step for the same reason). The `mergio/qbo-tokens` secret is Mergio-owned and read-only from here.

**One new item on that list:** the **trial stack** from the `aws-trial` branch (`deploy/aws-trial/**`, EC2 `meridian-trial`, tag `project=meridian-trial`, budget $60/mo). It is ours, but it is a rehearsal artifact, not a production target — §2.6 says what it is still good for and when it is torn down.

### PHI: resolved as YES (unchanged)

`public.transactions` stores `patient_id`, `claim_no`, `encounter_id`, `service_date`, `payment_date`, `billing_provider` (live: 76,132 rows, 17,606 distinct patient IDs); `public.source_transactions` holds 167,290 verbatim billing rows; exported workbooks carry a `Patient Acct No` column (`src/exporters.py`); the QB USA payroll channel carries employee DOB and insurance member IDs (`src/qb_usa_payroll_processor.py:47-53`). Account number + service date + provider + payer + amount is individually identifiable health information under 45 CFR 164.514(b)(2). The JE *output* is aggregate; the storage underneath it is not. Design proceeds as PHI-in-scope.

### What we are explicitly NOT doing, and why

| Not doing | Why |
|---|---|
| A second AWS account or an AWS Organization now | D-02. The CDK is written so production can be redeployed into a new account later; that is the whole of the "prepare for a split" requirement. |
| Multi-AZ RDS | D-14: the availability target (RTO ~8 business hours, RPO ~1 hour) is met by single-AZ plus point-in-time recovery and AWS Backup. Saves ~$28/mo. Revisited only if a real outage costs more than that. |
| A standing staging environment | D-15: torn down between phases. The only mode inside the ~$250/mo ceiling. |
| Static export of the Next.js frontend to S3 | `web/next.config.mjs` is a 21-rule reverse proxy; `output: 'export'` does not support rewrites. Unchanged from v2. |
| A `.table()` compatibility shim over psycopg | Rejected outright in v2 (§2.2) and still rejected: it would keep ~7,600 lines of fake-Supabase tests green while they verify nothing real. The prompt's "thin psycopg repository layer" is what v2 called `src/pg.py`; the name changes, the reasoning does not. |
| SQLAlchemy, psycopg 3, a TypeScript CDK | D-21: no SQLAlchemy; psycopg2 (already proven here, 8 live call sites, adapters match PostgREST); CDK in Python (one backend language, the existing venv). Escape hatch for SQLAlchemy in §2.2. |
| A separate RDS instance for PHI | Doubles operational duty for one person; the `phi` schema + non-owner role gives the grant boundary; `pg_dump -n phi` makes a later split a one-day job. Unchanged. |
| Redis / ElastiCache | Prompt: only if something needs it. Nothing does: rate limiting stays per-task (one API task), idempotency and locks use Postgres (an idempotency table plus advisory locks). Recorded as an ADR in Phase 0; revisit if the API scales past one task. |
| Shield Advanced | $3,000/month. Shield Standard is free and automatic with CloudFront. |
| Interface VPC endpoints (by default) | D-19: none of them removes the NAT, so none beats its cost. Free gateway endpoints only; §2.4 has the comparison. |
| A third "sandbox" stack | D-18: the sandbox is a synthetic org inside staging. $0. |
| RDS Proxy, Amplify Hosting | Unchanged from v2: RDS Proxy solves a problem this workload does not have; Amplify's HIPAA position is unverified. |
| Migrating the Wearbly UI | P-5: the four `uniform_*` tables travel with the data (nothing lost); the Jinja screen and the never-worked receipts upload are retired, not rebuilt. |
| Public `/signup` | P-6: invite-only via `AdminCreateUser`; deletes a code path and a screen. |

### The `CLAUDE.md` rule — answered (D-01), delivery changed

`CLAUDE.md` still says "All data and configuration must live in Supabase — no exceptions." That rule will silently steer a future session back toward Supabase. D-01 approved replacing it with the text below. **What changed:** `CLAUDE.md` is gitignored in this repo (`.gitignore:31`), so "the first commit of Stage 1" cannot carry it. Instead, per the prompt's tidiness rules: update `CLAUDE.md` locally in Phase 0 **and** record the same rule in tracked docs (`README.md` and `docs/architecture/repo-layout.md`), so the rule survives a fresh clone.

```markdown
## Database & Config Storage

**All data and configuration live in AWS RDS PostgreSQL — no exceptions.**
- Application data, config, mappings, allocations: `public` schema on RDS,
  managed by Alembic (`migrations/`). Never edit the schema by hand.
- Patient identifiers and raw billing rows: `phi` schema, reachable ONLY through
  `src/phi.py`, which sets the `phi_access` role and writes an audit row.
- Identity (who is this bearer) lives in AWS Cognito. Authorization (roles,
  permissions, org modules, superadmins) lives in Postgres and is read on every
  request. Never put roles or permissions in a token claim or a Cognito group.
- Object storage: S3. Artifacts in the `artifacts` bucket, raw uploads and
  identifier-bearing exports in the `phi` bucket.
- Tenant isolation is two layers: the explicit `org_id = %s` predicate on every
  tenant-scoped statement (CI lint: scripts/lint_org_scope.py) AND Postgres RLS
  keyed on `app.org_id`, set per connection by the repository layer under a
  non-superuser role. Neither layer is optional.
- SQLite (`data/revenue.db`) is retained ONLY for the legacy CLI
  (`process_revenue.py`) and is frozen — do not extend it.
```

Also to change locally and record in tracked docs: the `/gsd` workflow rule (the prompt's phase loop supersedes it for this migration) and "never archive or delete `web_app.py`" (true until Phase 11 retires the last Flask path; the tracked note must say so).

---

## 2. Architecture, reconciled

### 2.1 Identity — Cognito, `custom:app_uid`, dual-token acceptance, User Migration Lambda

**Adopted in full from v2, moved earlier, with two additions from the prompt.**

- New pool `meridian-<env>-auth-users`. `ADMIN_USER_PASSWORD_AUTH` (the server-side password flow — the User Migration trigger only receives a plaintext password under this family). One custom attribute **`custom:app_uid`** (String, 36, immutable) holding the legacy Supabase UUID for migrated users and the Cognito `sub` for new ones. `verify()` returns `claims.get('custom:app_uid') or claims['sub']`, so **no application row is ever rewritten** — this deletes the single most dangerous work item in the survey (a 30-column UUID rewrite across 30 tables with no foreign keys to catch a mistake). Profile fields (`full_name`, `avatar_url`, `language`, `dashboard_preferences`) go to a `user_profiles` table (v2 Stage 2, now a Phase 4 prerequisite).
- **Dual-token acceptance (from the prompt).** During the transition `require_auth` verifies a bearer as *either* a Supabase JWT (HS256 with `SUPABASE_JWT_SECRET`, as today) *or* a Cognito ID token (RS256 against the pool's JWKS, verified locally with PyJWT — no network call). The issuer claim decides which path runs. Both resolve to the same app user id via `custom:app_uid`. This is what lets Cognito go live in production **before** the data cutover, and it is what makes the auth flip reversible with a config change.
- **Cookie sessions stay for the browser; bearer tokens are accepted for mobile and machine clients** on the same endpoints. An ADR superseding contract §0/§6 is written before any auth code changes (prompt requirement). Access tokens ≤15 minutes for machine clients; the browser ID token stays 60 minutes with a 12-hour refresh (down from Supabase's 7 days).
- **User Migration Lambda (decided, D-06).** It handles both the `UserMigration_Authentication` and `UserMigration_ForgotPassword` triggers, verifies the password against Supabase Auth at first login, creates the Cognito user silently with `custom:app_uid` set, never logs passwords, **fails closed on a Supabase outage** with a clear error, and reports a migration percentage (`ListUsers` diffed against `legacy_users.json`, weekly). **5-second Lambda timeout** (Cognito abandons the trigger at ~5s), kept outside the VPC, dependency set `urllib3`/stdlib, p99 measured on staging before the production flip. Supabase Auth stays live and paid until Phase 10's cut-off date, after which unmigrated users get a password reset instead.
- **The Lambda cannot reach federated-only users** (Google-only, Microsoft-only) — the trigger never fires for federated sign-in. Live data (2026-08-29): one google-only member, one azure-only member, and the **single superadmin is azure-only**. Those are pre-created with `AdminCreateUser` (with the right `custom:app_uid`, `MessageAction='SUPPRESS'`) and linked with `AdminLinkProviderForUser` **before the IdPs are enabled** on the pool. Enabling an IdP first auto-creates a duplicate empty account, and the cleanup is delete-and-relink with the superadmin in the blast radius. Both IdPs stay (P-8).
- MFA `ON` (required) with TOTP for both workforce members, enrolled on staging first; SMS never configured; Cognito threat protection `AUDIT` → `ENFORCED` after one clean week. `PreventUserExistenceErrors=ENABLED`.
- **Two gotchas that cost a day each if missed:** refresh computes `SECRET_HASH` from the username/sub, not the email; and Cognito's refresh response carries **no new refresh token** — hand the old one back or everyone is logged out at the 60-minute mark.
- **Delete the token cache and the org/permission/module/superadmin caches** in `src/auth.py`; against RDS in-VPC they are 1-2 ms lookups and the caches are the documented staleness bug. **Keep the seam function names** (`validate_token`, `get_user_org`, `load_user_permissions`, `get_org_modules`, `is_superadmin`) — 62 monkeypatch sites depend on them.
- Build the two missing screens in React (`web/`), not Jinja: password reset (`ForgotPassword` → code → `ConfirmForgotPassword`; today's "reset" magic link logs the user in without resetting anything) and the MFA challenge step. Flipping the pool to `ON` without a challenge UI locks everyone out. Signup is invite-only (P-6), so no signup screen is built.
- Machine clients (Phase 12): Cognito OAuth2 **client-credentials** (a machine presents a client id + secret and gets a short-lived token), one app client per external system, scopes as Cognito resource-server scopes, secrets in Secrets Manager, shown once, rotatable, revocable.

### 2.2 Data layer — psycopg2 repository layer, Alembic, and RLS reinstated

**What survives from v2:** raw SQL behind unchanged `Database` method signatures; no shim; `RealDictCursor`; `DEC2FLOAT` adapter so `numeric` matches PostgREST's JSON floats across the 18 numeric columns; `uuid → str`, `jsonb → dict` adapters kept identical to PostgREST's shapes; autocommit-by-default connections with an explicit `transaction()` for the three genuine multi-statement units (`delete_batch`, `create_batch_superseding`, `redeem_invite_code`); `COPY` (never `execute_values`) for every `phi.*` bulk write because psycopg2 interpolates literals client-side and they would land in Postgres logs; `INSERT … ON CONFLICT DO UPDATE SET <payload columns>` (never `EXCLUDED.*`) for the 7 upserts; parameterized `ILIKE` for the 4 `.or_()` filters (fixing an injection bug); `RETURNING` where `result.data` is read back; the JE byte-diff as a gate after each port sub-stage.

**Live counts on this branch (v2 said 172 / 37 / 65):** `.table(` call sites: **188** (`src/database.py` 63, `web_app.py` 47, `src/api/v2/*` 26, `src/auth.py` 11, the rest across 12 small modules); backend test files: **48**; `CREATE POLICY` statements: **94 across 19 migration files**. The prompt's "~40 call sites" undercounts by a factor of four.

**Three changes from the prompt:**

1. **psycopg2, decided (D-21).** The prompt says "psycopg" and "sync is acceptable"; `psycopg2-binary` is the installed dependency with 8 live call sites and its adapters already match PostgREST. Zero new technology. Moving to psycopg 3 later is a contained change because every statement lives behind the repository layer (§4). **No async database access**: the workload is batch and the API task count is 1.
2. **Alembic, baselined honestly.** The prompt says "import the 37 existing SQL migrations as the baseline — do not rewrite them." v2 found the migration folder is **not** the source of truth: `fiscal_calendar` (6,209 rows) and `qgenda_workspaces` have no migration file; **`027_invite_codes_email.sql` *was* applied** (`invite_codes.email` is live — this line, ADR 0005 and both READMEs said otherwise until the 2026-09-15 dump settled it); ~12 declared `REFERENCES auth.users(id)` foreign keys do not exist live; six `updated_by`/`changed_by` columns are `TEXT` live but `UUID` in the file; two files share prefix `013`. Replaying the 37 files verbatim produces a schema that differs from production. Both requirements are met like this:
   - **Alembic revision 0001 `baseline_supabase`:** runs the 37 files verbatim, in filename order (exactly what `deploy/aws-trial/apply_migrations.py` proved works from an empty Postgres 17). Nothing rewritten.
   - **Revision 0002 `reconcile_live_drift`:** the diff between the replayed schema and a `pg_dump --schema-only` of live Supabase (v2 Stage 3.2's enumeration), so the result *is* production's schema. Committed with the dump it was derived from.
   - **Revision 0003 `rds_adaptations`:** strip `REFERENCES auth.users(...)`; replace `public.user_org_id()` (which read Supabase JWT claims) with `current_setting('app.org_id', true)::uuid`; drop the `anon`/`authenticated`/`service_role` grants; skip `003_storage_buckets.sql`'s effects; create the `phi` and `audit` schemas, `meridian_app` (non-owner) and `phi_access` roles, and the grant matrix.
   - `alembic stamp` is never used to skip 0001-0003 on staging; staging is built from empty every time so the chain is proven — which the torn-down staging mode (D-15) makes routine.
3. **RLS reinstated (prompt requirement, D-10; v2 had dropped it).** Layer (a) is the explicit `org_id` predicate on every statement, enforced by `scripts/lint_org_scope.py` reading a schema-generated `scripts/tenant_tables.txt` (~50 tables, not the 6 v1 listed). Layer (b) is Postgres RLS with `FORCE ROW LEVEL SECURITY`, policies `USING (org_id = current_setting('app.org_id', true)::uuid)`, under `meridian_app`, which is **not** the table owner and has no `BYPASSRLS`. **How `app.org_id` is set matters:** the repository layer is autocommit-by-default, and `SET LOCAL` only lives inside a transaction, so the setting is applied **session-level on checkout** (`SET app.org_id = %s`) and **`RESET app.org_id` unconditionally on return to the pool** — the same pattern as `RESET ROLE` in `src/phi.py`. A test checks out a connection after a scoped operation and asserts `current_setting('app.org_id', true)` is empty. Superadmin and cross-org admin paths get a bypass **only through one named function** that writes an audit row. Cost: +3-5 engineering days over v2 (§7). Port `tests/test_run_isolation.py` and `tests/test_pnl_rls_live.py` to the RDS fixture; they are the proof the prompt asks for.

**Honest note, carried forward.** Raw SQL's safety model is discipline plus a lint, applied ~188 times, by a solo developer still learning. RLS now backstops a dropped `WHERE org_id`, which is exactly the risk v2 accepted without a backstop — that is the real reason to pay the 3-5 days. If a parity diff still catches a mis-scoped transcription, reverse into SQLAlchemy Core at the repository boundary; every `Database` signature stays fixed so it is cheap. That is the one condition under which D-21's "no SQLAlchemy" is reopened.

### 2.3 PHI — `phi` schema, `patient_ref`, `src/phi.py` (unchanged from v2)

```
public.transactions          -- everything EXCEPT the three identifiers
  + patient_ref TEXT          -- HMAC-SHA256(key from Secrets Manager, patient_id)
phi.transaction_identity     -- transaction_id PK → public.transactions, org_id,
                             --   patient_id, claim_no, encounter_id
phi.source_transactions      -- the 167,290 raw billing rows, moved as-is (P-3)
audit.phi_access             -- who/what/when/how many rows, request_id, ip. NEVER PHI values.
```

`meridian_app` has zero grants on `phi`; `phi_access` holds SELECT/INSERT on `phi.*`; every PHI touch goes through `src/phi.py` (`SET ROLE phi_access` → audit row → execute → `RESET ROLE` in a `finally`). `meridian_app` gets INSERT-only on `audit.phi_access`. `pgaudit.log='ddl,role,write'` instance-wide, `ALTER ROLE phi_access SET pgaudit.log='read,write'` so reads are audited on the one role that can perform them. **A keyed HMAC is not Safe Harbor de-identification** — service dates remain an identifier; `patient_ref` shrinks exposure, it does not exit HIPAA scope. Verified: `patient_id` reaches neither the API nor the UI; the only reachable use is duplicate detection (`src/exporters.py:979-990`), which works identically on the hash (P-1). The `Patient Acct No` workbook column becomes a permission-gated detail export landing in the `phi` bucket; the default export is tokenized (P-2).

**Addition from the prompt:** PHI is **masked by default** in every `/api/v3` response; the `phi:read` scope unmasks, is never granted to an external client without a recorded partner BAA + admin approval, and every unmasked read writes an `audit.phi_access` row. GuardDuty Malware Protection scans every uploaded object; nothing is processed until tagged clean.

### 2.4 Account topology — one account, two environments

D-02 stands. Reuse buys: BAA accepted once, SES verified once, Identity Center/GuardDuty/Config/CloudTrail configured once. Reuse costs: **shared blast radius** — an account-wide admin principal can reach both Meridian's PHI and the assistant app; the IAM triage (Phase 1) is therefore a hard precondition of any PHI landing, not hygiene. **Shared quotas and a shared bill** — the tags are load-bearing. **Terraform we cannot see** — someone else's state may drift into our resources; the mitigation is naming + tags + our own CDK bootstrap (`cdk bootstrap` creates its own state bucket; do not touch `meridian-terraform-state-*`).

**Staging and production in the same account.** Each environment is a full copy of the CDK app deployed with a different `env` parameter: its own VPC (no peering, no shared NAT), its own KMS customer-managed keys (CMKs — encryption keys we control), its own IAM roles scoped by `aws:ResourceTag/Environment`, its own RDS, buckets, Cognito pool, secrets and budgets. Nothing in staging can read a production ARN. **This is also what "structured so a second account can be split off later" means in practice:** the production stacks are the same code, so moving them is `cdk deploy` with a different account/region target plus a data move — no redesign.

**Staging is torn down between phases (D-15).** The `data` stack (RDS stopped, buckets kept) persists; `network`, `compute`, `api`, `observability` are `cdk destroy`ed at the end of a staging session and redeployed at the start of the next (~15 minutes). RDS restarts itself after 7 days stopped, so a scheduled stop (EventBridge → `StopDBInstance`) is part of the `data` stack. Cost ~$13/mo idle (§5). Consequence: every staging session re-proves the CDK from scratch — a feature, not a chore, because it is exactly what a future account split needs.

**VPC endpoints — the comparison behind D-19.** A NAT gateway costs $32.85/mo in hours plus $0.045/GB. An interface endpoint costs $7.30/mo per AZ plus $0.01/GB. The NAT cannot be removed: Intuit QuickBooks, Google and Microsoft sign-in, and the User Migration Lambda's target have no VPC endpoint. So interface endpoints only ever *add* cost; the data-transfer saving (mainly ECR image pulls, a few GB per month) is under $1. Decision: **gateway endpoints for S3 and DynamoDB (free) in both environments; no interface endpoints.** The only argument left for them is private-path assurance in the control matrix; if an auditor asks, add Secrets Manager + KMS + CloudWatch Logs in one AZ to production (~$22/mo) and record it as a control, not a cost decision.

**Isolation, concretely (per environment)**

| Boundary | Mechanism |
|---|---|
| Network | Own VPC, 2 AZs, public + private-app + private-data subnets, one NAT gateway; gateway endpoints for S3 and DynamoDB |
| Ingress | CloudFront → WAF → ALB. The ALB security group admits only CloudFront's managed prefix list; an origin-verify header rule rejects direct hits. `ProxyFix(x_for=2)` in Flask/FastAPI (CloudFront + ALB are two proxies — `x_for=1` re-creates the rate-limit-keys-on-edge-IP bug commit `71decf2` fixed) |
| Compute identity | Task roles `meridian-<env>-ecs-api-task`, `-worker-task`, `-web-task`, `-execution`; no wildcard actions; conditioned on `aws:ResourceTag/Environment` |
| Data at rest | One CMK each for RDS, `artifacts`, `phi`, logs, backups. Key policies name only that environment's roles |
| Database | RDS PG 17.x single-AZ in private data subnets, `PubliclyAccessible=false`, `rds.force_ssl=1`, `meridian_app` non-owner + `phi_access`; 7-day automated backups with point-in-time recovery; AWS Backup 35-day locked vault with cross-region copy |
| Admin DB access | **No inbound ports anywhere.** `psql` via SSM Session Manager port-forwarding to an SSM-managed `t4g.nano` with **zero** security-group ingress (or ECS Exec into a one-off ops task). The prompt's "no bastion" is read as "no open ports", which this satisfies; there is no other path from a laptop to a private RDS |
| Cost | `Environment` + `Project` cost-allocation tags; AWS Budgets and Cost Anomaly Detection per environment |

### 2.5 Target architecture (production; staging is the same shape)

```
     meridiansgrp.com (apex → 301 www) · www. (public website) · app. (Meridian) · api. (/v3)
                  (staging: staging-app. · staging-api. — ADR 0050)
                                   │
                    ┌──────────────┴──────────────┐
                    │ CloudFront + WAF (managed    │  Shield Standard (free)
                    │ core + IP reputation + rate) │  ACM cert (us-east-1)
                    └──────────────┬──────────────┘
                                   │ origin-verify header
                    ┌──────────────┴──────────────┐
                    │ ALB (SG: CloudFront prefix   │  access logs on
                    │ list only)                   │  HTTP:80 → 301
                    └───┬───────────────────────┬──┘
          default       │                       │  /api/*, /auth/*, remaining Jinja paths
   ┌────────────────────┴─────┐      ┌──────────┴──────────────────────────┐
   │ ECS Fargate  web         │      │ ECS Fargate  api                    │
   │ Next.js standalone, ARM  │      │ FastAPI (+ Flask mounted during     │
   │ 0.25 vCPU / 0.5 GB       │      │ transition), ARM, 1 vCPU / 2 GB     │
   └──────────────────────────┘      │ desiredCount=1 until Phase 11 lands │
                                     └───┬──────────┬──────────┬───────────┘
                                         │          │          │  SQS job queue (+ DLQ)  ── Phase 11
                                         │          │     ┌────┴──────────────────┐
                                         │          │     │ ECS Fargate  worker   │  Phase 11
                                         │          │     │ generic process runner│
                                         │          │     │ 0.5 vCPU / 1 GB, ARM  │
                                         │          │     └────┬──────────┬───────┘
                                    ┌────┴────┐ ┌───┴────┐     │          │
                                    │ RDS PG  │ │  S3    │◄────┘          │
                                    │ 17.x    │ │ artif. │                │
                                    │ t4g.sm  │ │ phi    │      NAT → Intuit QBO, Google/
                                    │ 1 AZ    │ └────────┘      Microsoft IdPs, Cognito, SES
                                    └─────────┘
Identity:  Cognito pool; ID token 60 min in HttpOnly cookie (browser) or Bearer (mobile/machine);
           verified LOCALLY via PyJWT + cached JWKS. Machine clients: client-credentials, ≤15 min.
Authz:     Postgres tables, unchanged. RLS on app.org_id + explicit predicate.
Email:     SES (domain verified Phase 1). Events: EventBridge → SQS webhooks with DLQ (Phase 12).
Partners:  API Gateway custom domain + mTLS truststore ONLY if a PHI-scoped partner exists (Phase 0 ADR).
```

**Load-bearing constraints (write them into the CDK as comments):**

- `desiredCount: 1`, `maximumPercent: 100`, `minimumHealthyPercent: 0` on the `api` service **until Phase 11 serializes the five in-memory wizards** (`web_app.py:7013, 8648, 9807, 10348, 10892`). Two tasks mis-book journal entries silently (`src/run_store.py:5-9`). A `HealthyHostCount > 1` alarm on the api target group (no Container Insights needed). Cost of the setting: **3-6 minutes of hard downtime per api deploy** until Phase 11 lifts it — deploy outside business hours, never during a close. This is the same shape Render runs today (one worker), so cutover-first does not regress it.
- `--workers 1 --worker-class gthread --threads 8` for Flask is correctness, not tuning, for the same reason. FastAPI under uvicorn: one process.
- `FLASK_ENV=production` in the task definition — `src/auth.py:224` keys the `Secure` cookie flag off it.
- No plaintext credentials in `environment:`; everything credential-bearing via `secrets:` from Secrets Manager.

### 2.6 What the trial stack is, and what it is still good for

`deploy/aws-trial/**` (on the `aws-trial` branch) is **self-hosted Supabase on one EC2 instance**: the upstream Supabase docker-compose (Postgres 17, GoTrue auth, PostgREST, Storage, Envoy gateway, Studio) plus the Flask `api` and Next.js `web` containers behind Caddy, on a `t4g.large` in the **default VPC** with a public Elastic IP and SSH open, tagged `project=meridian-trial`, $60/mo budget, migrations applied by `deploy/aws-trial/apply_migrations.py`, one seeded trial org.

**Verdict (D-09): a rehearsal artifact, not the production target, and not on the path to it.** The prompt requires RDS as the system of record, Cognito for identity, S3 for files and CDK for everything; the trial has none of those. It is also not a place PHI may go: default VPC, public IP, self-managed database with no managed backup, no KMS, no audit trail.

**Still useful, and to be harvested in Phase 0:**

| Trial artifact | Reuse |
|---|---|
| `Dockerfile.api`, `.dockerignore`, `web/Dockerfile`, `web/.dockerignore` | The Phase 5a container images start from these — the WeasyPrint apt list, ARM64 build, Next.js standalone output are already proven. Move them to the repo layout the prompt defines. |
| `apply_migrations.py` | Proves the 37 files replay from empty on PG 17 → it *is* Alembic revision 0001's content. Its `trial_migrations` ledger pattern is the shape `scripts/run_migrations.py` lacks. |
| `smoke.sh`, `make_sample_revenue.py`, `sample_revenue_export.xlsx` | Smoke-check shape and a synthetic revenue file for the Phase 12 sandbox org and the Phase 9 rehearsal. |
| The instance itself | A disposable place to rehearse the Supabase → Postgres data load and the JE byte-diff **before RDS staging exists** (Phase 3), using synthetic data only. |

**Tear-down:** at the end of Phase 3 (RDS staging exists) at the latest — Andres confirms first (prompt: ask before deleting resources). `deploy/aws-trial/.trial-env` is instance-identifying and is moved out of the repo in the Phase 0 safety sweep; the `meridian-trial.pem` key is deleted with the key pair.

---

## 3. Phases 0-12 — cutover-first order (D-16)

**The prompt lists its phases as 0-12 with the process framework (7) and the API platform (8) before cutover (11). This plan supersedes that order.** Nothing in either platform phase is needed to leave Render and Supabase: the api container can run today's in-process threads at `desiredCount=1` exactly as Render does now, and `/api/v2` serves the React app. Building them *after* cutover removes the dual-maintenance tax and the Render + Supabase bill from ~55-84 engineering days of work, and brings the first AWS-booked close forward by roughly six months (§7). The prompt must be edited to match (hand-off report).

| v3.1 phase | Content | Prompt phase |
|---|---|---|
| 0 | Inventory, safety sweep, threat model, ADRs, harden in place | 0 |
| 1 | AWS foundation | 1 |
| 2 | Network and IaC | 2 |
| 3 | Data tier (staging only) | 3 |
| 4 | Auth (Cognito) + Flip 1 | 4 |
| **5a** | Data layer port, FastAPI beside Flask, containers, CI/CD to staging | 5 (first half) |
| **5b** | Jinja → React screens | 5 (second half) |
| 6 | Observability and audit | 6 |
| **7** | Email: Resend → SES | 9 |
| **8** | Security hardening and compliance evidence | 10 |
| **9** | Cutover (Flip 2) | 11 |
| **10** | Decommission Supabase and Render | 12 (the platform-independent half) |
| **11** | Process framework (on AWS) | 7 |
| **12** | API platform and API security; final cleanup (Flask gone, tracker empty) | 8 + the rest of 12 |

**How v2's stages landed**

| v2 | v3.1 phase |
|---|---|
| Stage 0 no-regret actions | Phase 0 (inventory, PHI determination, DNS host, vendor quotes, commit `017`) and Phase 1 (BAA, IAM triage, SES, budgets) |
| Stage 1 harden in place | **Phase 0c** — still first, still on Render + Supabase, because every item is a bug the migration would otherwise carry |
| Stage 2 `user_profiles` | Phase 4 prerequisite (first commit of Phase 4) |
| Stage 3 schema truth + PHI split + test fixture | Phase 3 |
| Stage 4 landing zone | split: Phase 1 (account-level security services, KMS, budgets), Phase 2 (VPC, WAF, CloudFront), Phase 3 (RDS, S3, Backup) |
| Stage 5 data layer port | Phase 5a |
| Stage 6 storage → S3 | Phase 3 (buckets + `S3StorageManager`) |
| Stage 7 containerize + ECS staging | Phase 5a |
| Stage 8 dry runs + JE diff procedure | Phase 9 (rehearsals) and Phase 8 (restore drill, DR test); the diff procedure is written in Phase 3 because Phase 5a needs it |
| Stage 9 Cutover A | Phase 9 (Flip 2) |
| Stage 10 Cognito | Phase 4 |
| Stage 11 Cutover B | Phase 4 exit (Flip 1) |
| Stage 12 decommission | Phase 10 (Supabase, Render) and Phase 12 (Flask, tracker) |
| Stage 13 deferred | §4 — two items are no longer deferred (wizards → worker state in Phase 11, Resend → SES in Phase 7); one is decided (RLS) |
| Track C | unchanged, parallel; its evidence feeds Phase 8 and the prompt's control matrix |

Every phase is one or more git commits, independently shippable and revertible. **Phases 0-8 ship behind `DATABASE_BACKEND` / `STORAGE_BACKEND` / `AUTH_BACKEND` switches while production stays on Render + Supabase** (auth flips to Cognito at the end of Phase 4). Every phase ends with the prompt's completion loop: tests green, Fable critic and Codex review clean, tidy check, control matrix/ADRs/runbooks/`CHANGELOG.md` updated, phase report with the `needs-a-human` list, Obsidian note under `NS_Proccess/`.

---

### Phase 0 — Inventory, safety sweep, threat model, baseline, and harden-in-place

**Goal:** know exactly what exists, get client data and other products out of the repo, write the founding ADRs, and fix the bugs that must be fixed while the current system is still live and verifiable.
**Effort:** 14-21 days (v2 Stages 0+1 were 9-13; +5-8 for the inventory, threat model, ADRs and safety sweep the prompt adds). Some of it is waiting on other people.

**0a — Safety sweep and git reconcile (1-2 days)**

1. **Branch base (D-23), first:** commit or stash the in-flight QBO changes on `andres-try` (`scripts/qbo_post_je.py`, `src/qbo_client.py`, `src/qbo_je_adapter.py`, `tests/test_qbo_je_adapter.py`), merge `andres-try` into `main` (20 commits: `src/qbo_client.py`, `src/qbo_je_adapter.py`, migrations `030` and `035`, the LibreOffice-aware `tests/conftest.py`), then **rebase `aws-migration` onto `main`**. This branch was cut from `main` and has **35** migration files, not the 37 the prompt describes. Migration work proceeds from `main`.
2. `git status --porcelain --ignored` in the main worktree. Anything that is client data or PHI (`code_grader/uploads`, `code_grader/output`, root `*.xlsx` reports, the ~125 entries under `output/`), instance-identifying (`deploy/**/.trial-env`), or another product (`schdualer/`, `qgenda/`, `code_grader/`) is **moved** to its `~/Business/...` data folder — never committed, never sent to Codex. Add the paths to `.gitignore`. `idk.md` in the working tree gets a decision too.
3. Commit the `017_qb_mapping_tables.sql` working-tree edit (v2 0.9): the live `qb_other_code_map` already holds the edited values; replaying the unedited file would silently rewrite accounting codes back.

**0b — Inventory and founding documents (4-6 days)**

4. Inventory, as tracked docs under `docs/compliance/` and `docs/architecture/`: every Supabase table (57 live), every RLS policy (94), auth flow, storage bucket, env var (`render.yaml` + `.env.example`), external call (Intuit QBO, Google, Microsoft, Resend, NetSuite where wired); the full `next.config.mjs` Jinja route list (9 path families × sub-paths + `/auth/*`); the existing process registry (`src/process_runs.PROCESSES` = `qb-revenue`, `mx-payroll`, `qb-usa-payroll`; `role_permission_processes` from migrations 029/030; `src/api/v2/state_machine.py`; contract §2). `local_plugins.EXTRA_PROCESSES` is unverified-local — it is in no tracked branch; if it exists on the laptop, fold it into the manifest in Phase 11, otherwise ignore it (D-24).
5. PHI classification and data-flow diagram covering both channels (billing exports; UNUM/BCBS payroll carrier files), including what leaves AWS (a journal entry to QBO/NetSuite, identity claims to Google/Microsoft).
6. **PHI determination in writing** and the BAA between Stella Mattina Health and Meridians Logic Automation collected and filed (D-03: it exists; obtain the signed copy).
7. Identify the registrar and DNS host for `meridiansgrp.com` (the apex resolves to Render; `www` is a CNAME to Render's Next.js service; there is no Route 53 zone) and **decide the zone now**. Most external DNS hosts cannot alias an apex to a CloudFront distribution, so a Route 53 zone is the likely answer — a lead-time item with a TTL tail.
8. Inventory the two QuickBooks credential paths (`mergio/qbo-tokens` in Secrets Manager vs. `QBO_*` in `.env` per migration 035) and write down which the containerized app uses.
9. Request the Render HIPAA-tier and Supabase Team + HIPAA quotes in writing (P-9: the plan proceeds without them; they only sharpen the savings claim in §5).
10. Confirm who owns the `ai.meridiansgrp.com` stack, by asking — **do not restore or inspect `meridian-postgres`'s snapshot** (P-10).
11. Threat model (STRIDE-style, one page per trust boundary: browser→CloudFront, CloudFront→ALB, api→RDS, worker→S3, Lambda→Supabase Auth, api→QBO).
12. **ADRs** (Architecture Decision Records — short dated notes: context, decision, consequences) in `docs/adr/`: account topology (D-02), ALB vs API Gateway (ALB for browser + internal; API Gateway + mTLS only when a PHI-scoped partner exists), auth model (D-06, D-13), cutover-first order (D-16), data layer (D-21: psycopg2, no SQLAlchemy, Alembic chain), CDK in Python (D-21), availability target (D-14), staging mode (D-15), VPC endpoints (D-19), no Redis. Each is one page; most are transcriptions of §8.
13. Target repo layout written to `docs/architecture/repo-layout.md` (the prompt's tree: `infra/`, `src/`, `src/processes/`, `api/`, `workers/`, `web/`, `migrations/`, `tests/`, `docs/`, `scripts/`), every folder with a README.
14. Update `CLAUDE.md` locally per §1 and record the change in `README.md`.

**0c — Harden in place (6-8 days; v2 Stage 1, unchanged in substance)**

15. **Take manual control of Render deploys first.** Both services auto-deploy every commit to `main` regardless of CI. Set Auto-Deploy = No on both; deploy manually after CI is green. Without this, step 19's fail-loud sentinel crash-loops production on merge.
16. **Fix the cross-org permission escalation.** `web_app.py:2175, 2178, 2297, 2328, 2334, 2356` and `src/api/v2/user_routes.py:411, 548, 637, 650, 664` write to `roles` / `role_permissions` scoped only by `role_id`; the `roles.org_id` check exists only in an RLS policy the service key bypasses. Add an explicit "role belongs to `g.org_id`" check + regression test per site. Verifiable on the current system; do it there.
17. Add explicit `org_id` to the `qb_usa_payroll_journal` / `qb_usa_payroll_gate` statements that scope by `batch_id` alone (`web_app.py:4487-4497` region).
18. **Fix the PHI logging leaks.** `src/qb_usa_payroll_processor.py:311, 550, 628, 636, 723, 734` log employee names/IDs. Flip `RAW_WITHHELD_HEADERS` (`src/qb_usa_payroll_workbook.py:203-208`) from blocklist to allowlist. Wrap ingest parse errors so exception text carrying cell contents cannot reach the `exc_info=True` handlers (`web_app.py:392, 412, 471, 519, 534`). Encode "NEVER log a `RunResult`" as a CI lint (`scripts/lint_no_phi_logging.py`).
19. **Replace the `SUPABASE_URL`-presence sentinel** with explicit `DATABASE_BACKEND` / `STORAGE_BACKEND` / `AUTH_BACKEND` switches across all 22 branch sites, fail-loud on missing config (`_qb_usa_require_supabase` at `web_app.py:4397` is the model). **Order, non-negotiable:** Auto-Deploy off → set the three vars to `supabase` in both Render dashboards → merge → deploy manually. Today an unset `SUPABASE_URL` silently books journal entries into SQLite on an ephemeral disk.
20. **Delete the `wearbly-receipts` upload path** (P-5): `web_app.py:11541-11543` swallows a failed upload to a bucket that never existed and records a path as though it succeeded. The `uniform_*` tables and the rest of the Wearbly code are frozen, not deleted.
21. **Pin dependencies** (`pip-compile` → `requirements.lock.txt`, Python pinned); pin Node in `web/`. Two builds a week apart currently ship different pandas/openpyxl/weasyprint — libraries that determine numbers in a journal entry.
22. De-duplicate `SIGNED_URL_TTL` / `BUNDLE_URL_TTL` (import from `src/storage.py`). Delete the 6 unreachable storage methods (`uploads`/`templates` buckets hold 0 objects).
23. **Wire `pytest tests/` into CI** — `.github/workflows/web.yml` runs only the Next.js checks today; the 48 backend test files are run by nothing. The CI image must include LibreOffice, or `tests/conftest.py` skips the workbook tests silently. Add pre-commit with one formatter/linter per language and type checking.

**Verify:** the working tree holds no client data, PHI, or other product; `aws-migration` is rebased on a `main` that contains the QBO work; full `pytest` green in CI; one real revenue run and one real payroll run on Render produce byte-identical JE CSVs vs. the previous run of the same period; an attempt to write another org's `role_permissions` returns 404 (not 403 — contract §8: never confirm a cross-org id exists); a commit to `main` produces no Render deploy; the ADRs and the inventory exist.

**Roll back:** `git revert` per commit; nothing outside the repo changed except files moved out of it (which are moved, not deleted).

---

### Phase 1 — AWS foundation

**Goal:** the account is safe to hold PHI, the long-lead items are started, and no billable environment resource exists until Andres approves the cost estimate.
**Effort:** 6-8 days (v2 Stage 0.1/0.2/0.6/0.7 + the account-level half of Stage 4, + ~2 days for a first CDK project). Calendar time > typing time (SES approval, Identity Center sign-in verification).

**Steps**

1. **Accept the AWS BAA** in AWS Artifact (free, self-service, minutes). Check whether it is already accepted on <account-id>. **Stop and ask Andres to confirm before any PHI lands** (prompt requirement). Record the date in Track C's BAA register.
2. **IAM triage — a hard precondition of Phase 3.** In this order: (a) IAM Identity Center with an admin permission set, and **verify sign-in works**; (b) MFA on `andres-cli` and `meridian-app`; (c) replace `AdministratorAccess` on `andres-cli` with an assumed role; (d) only then deactivate the long-lived access key on `andres-cli`. Killing the key first strands you on root-only recovery. Then a **break-glass role** with an alarm + SNS on every `AssumeRole` and a written procedure (164.312(a)(2)(ii) emergency access is *required*). No long-lived access keys remain anywhere; CI uses GitHub OIDC (step 8).
3. **SES long lead, now.** Verify `meridiansgrp.com` in SES us-east-1 (DKIM CNAMEs at the DNS host from Phase 0), custom MAIL FROM `mail.meridiansgrp.com` (MX + SPF), DMARC, and **request production access** (sandbox = 200 mails/day to verified addresses only; approval 1-2 business days). Cognito (Phase 4) and the Resend replacement (Phase 7) both wait on this. Keep the existing HTML templates in `src/email_service.py`.
4. **CDK app skeleton** in `infra/` — **Python** (D-21), same venv, `aws-cdk-lib` pinned. `cdk bootstrap` once per account/region (this creates CDK's own state bucket; **never** reuse `meridian-terraform-state-*`). Stacks: `foundation` (account-level, deployed once), then per environment `network`, `data`, `auth`, `compute`, `api`, `observability`. `env` is a context parameter; **no account id in code**; `cdk synth` and `cdk diff` run in CI; a CI check fails on any resource missing the six tags (a CDK Aspect enforces them).
5. **Account-level security services** (`foundation` stack): CloudTrail trail with log-file validation and **S3 data events on the future buckets** (today `DataResources: []` — no object access is logged anywhere); AWS Config with the Operational Best Practices for HIPAA conformance pack (recorder scoped to relevant types); GuardDuty (with Malware Protection for S3 scoped to the `phi` upload bucket only — it is billed per GB); **Security Hub** with the AWS Foundational and HIPAA standards; **Inspector** for ECR images; **IAM Access Analyzer**; **Macie** on the two data buckets only. CloudTrail → CloudWatch Logs (for alarms) and → an S3 bucket with **Object Lock** (compliance mode) and a 7-year lifecycle for the 6-year 164.316 retention. Alarms on console `Create*`/`Delete*` calls by humans (the drift tripwire — CloudTrail metric filter, not a hand-rolled Lambda).
6. **KMS CMKs** per environment (RDS, artifacts, phi, logs, backups) with key policies naming only that environment's roles; automatic annual rotation.
7. **Tagging and cost.** Activate `Project`/`Environment` as cost-allocation tags (24h to appear). AWS Budgets per environment ($150/$250 production, $30/$75 staging — it is torn down between phases) + one account-wide, and Cost Anomaly Detection, all to SNS → Andres. Split the assistant app's Bedrock spend out of "Meridian" in the reports.
8. **GitHub Actions OIDC** provider + one deploy role `meridian-shared-iam-github-deploy`, trust-scoped to the `staging` GitHub Environment of `andressbj45/meridians` (the per-environment branch-trusted roles this line originally described were removed on 2026-09-17, Codex CX-INF-02 follow-up). No stored AWS keys. CI adds dependency, container and secret scanning (`pip-audit`, Trivy on the image, gitleaks).
9. **Cost estimate per environment, approved by Andres — the exit criterion.** §5 is the draft (production single-AZ ~$225/mo taxed; staging ~$13 idle / ~$129 while a session runs); Phase 1 refines it with the CDK's actual resource list.

**Verify:** BAA date recorded; `aws iam list-mfa-devices` shows devices; Identity Center sign-in works; the long-lived key is inactive; SES shows `Verified` and the production-access case is open; `cdk synth` and `cdk diff` are clean in CI and the tag Aspect fails a deliberately untagged test resource; Security Hub shows both standards enabled; budgets exist; **Andres has approved the cost estimate in writing.**

**Roll back:** everything here is additive or a security improvement. The `foundation` stack can be destroyed; the security services are account-wide and should stay regardless.

---

### Phase 2 — Network and IaC

**Goal:** an empty, tagged, CDK-managed network for each environment, sharing nothing with the assistant app.
**Effort:** 4-6 days (v2 priced the VPC inside Stage 4's 3.5-5.5; the second environment and CloudFront add ~2).

**Steps**

1. `network` stack per environment: VPC, 2 AZs, public + private-app + private-data subnets, one NAT gateway, VPC flow logs to a KMS-encrypted 400-day log group. **Do not peer with or route through the assistant app's VPC or the default VPC** (where the trial instance lives).
2. **VPC endpoints (D-19):** gateway endpoints for S3 and DynamoDB (free). No interface endpoints — §2.4 has the comparison.
3. Security groups: ALB admits only the CloudFront managed prefix list on 443; api/worker/web admit only the ALB; RDS admits only api/worker and the SSM ops instance; **no security group anywhere has 0.0.0.0/0 ingress on 22 or 5432.**
4. **CloudFront distribution + WAF** (global Web ACL: managed Core rule set, IP reputation, per-IP rate rule; **AWS Shield Standard is automatic, never Shield Advanced**), ACM certificate in us-east-1 covering each environment's own names only — production `meridiansgrp.com`, `www`, `app`, `api`; staging `staging-app`, `staging-api` (ADR 0050, which replaced the single `staging.` name) — plus `origin-<env>`. The origin-verify header secret lives in Secrets Manager and is rotated by a runbook. CloudFront forwards all headers/cookies/query strings for `/api/*` and `/auth/*` (no caching); static Next.js assets are cached.
5. ALB per environment: idle timeout 120s, HTTP:80 → 301, access logs on, `drop_invalid_header_fields=true`; target groups `web` (default) and `api` (`/api/*`, `/auth/*`, and the Jinja paths still proxied — **generated from `next.config.mjs`, not retyped**; one omission is a hard 404 on a production screen).
6. SSM-managed ops instance (`t4g.nano`, private subnet, no ingress) or an ECS Exec ops task definition — §2.4.
7. Staging's `network` stack is **destroyed at the end of this phase's session** and redeployed at the start of Phase 3 — the first rehearsal of D-15.

**Verify:** `cdk diff` clean on a second run; `aws resourcegroupstaggingapi get-resources --tag-filters Key=Environment,Values=staging` returns exactly the stack's resources; a `curl` to the ALB's DNS name directly is rejected; the CloudFront hostname returns the ALB's 503 (no targets yet); SSM session to the ops instance works with zero inbound rules; a destroy + redeploy of staging's network stack takes under 20 minutes and produces an identical `cdk diff`.

**Roll back:** `cdk destroy` of the environment's stacks — which now only ever touch that environment's VPC. Confirm `ai.meridiansgrp.com` still serves afterwards.

---

### Phase 3 — Data tier (staging only)

**Goal:** RDS staging holding a restored copy of production's schema and data, the Alembic chain proven from empty, RLS working under a non-superuser role, S3 buckets, backups with a tested restore, and the ephemeral-Postgres test fixture that every later phase depends on. **Nothing in production writes to RDS.**
**Effort:** 14-20 days (v2 Stage 3's 5-7 + the RDS/S3/Backup half of Stage 4 ≈ 2-3 + Stage 6's buckets and `S3StorageManager` 3 + RLS 3-5 + the rehearsal load with checksums 2-3, which v2 had in Stage 8). **The pytest fixture is still the schedule risk** — build it first.

**Steps**

1. `pg_dump --schema-only --no-owner --no-privileges -n public $SUPABASE_DB_URL` with a **pg_dump client ≥ 17.6**; commit it under `migrations/baseline/` as the reference for revision 0002. Diff it against the replayed 37 files and enumerate every drift item (the v2 list in §2.2 is a start, not the end).
2. **Alembic** in `migrations/`: revisions 0001 (`baseline_supabase`: the 37 files verbatim), 0002 (`reconcile_live_drift`), 0003 (`rds_adaptations` + `phi`/`audit` schemas + roles + grants + `ALTER DEFAULT PRIVILEGES`), 0004 (`rls_app_org_id`: `FORCE ROW LEVEL SECURITY` and the `app.org_id` policies on every table in `scripts/tenant_tables.txt`; `role_permissions` via the `roles.org_id` join). `supabase_migrations/` is archived with a README saying it is history. `scripts/run_migrations.py` (which hardcodes three files and records nothing — the mechanism that produced today's drift) is deleted.
3. **`qgenda_workspaces` is excluded from the dump; `fiscal_calendar` comes** (P-4). `fiscal_calendar` (6,209 rows, periods to 2036) is load-bearing for JE dates. `qgenda_workspaces` stays in the retained Supabase archive (§6), so nothing is lost if it turns out to be Meridian's.
4. **Generate `scripts/tenant_tables.txt` from the schema** (`information_schema.columns WHERE column_name='org_id'` plus join-scoped tables) and make `scripts/lint_org_scope.py` read it. Adding an org-scoped table without listing it is a CI failure.
5. **`tests/conftest.py` ephemeral-Postgres fixture**: a Docker PG 17 container per session, `alembic upgrade head`, roles created, connected as `meridian_app` (so RLS is *on* in tests). Port `test_run_isolation.py` and `test_pnl_rls_live.py` onto it; add the "`app.org_id` is empty after checkout" and "`current_user` is `meridian_app` after a `phi` operation" tests.
6. `data` stack: RDS PostgreSQL 17.x, `db.t4g.small` (staging: `t4g.micro`), gp3 20 GB, **single-AZ (D-14)**, `StorageEncrypted` with the RDS CMK, `PubliclyAccessible=false`, `DeletionProtection=true` (production), automated backups 7 days with point-in-time recovery (5-minute granularity — comfortably inside the ~1-hour RPO), Performance Insights, parameter group `rds.force_ssl=1`, `shared_preload_libraries=pg_stat_statements,pgaudit`, `pgaudit.log='ddl,role,write'`, `log_connections`, `log_disconnections`, `statement_timeout`, `idle_in_transaction_session_timeout`. Staging: an EventBridge schedule that stops the instance nightly (D-15). The app connects with `sslmode=verify-full` and the RDS CA bundle baked into the image (**not** `sslmode=require`, which does not authenticate the server).
7. S3 buckets `meridian-<env>-s3-artifacts` and `meridian-<env>-s3-phi`, each with its own CMK, versioning, public-access block, `BucketOwnerEnforced`, TLS-only and encryption-enforcing policies, 7-year lifecycle on raw uploads (was 30 days; ADR 0020 §5b, 2026-09-28), GuardDuty Malware Protection on the `phi` bucket; an `audit` bucket with **Object Lock** for exported audit data.
8. Secrets Manager: `meridian-<env>/app-env`, `/db-app`, `/db-phi-access`, `/phi-hmac-key`, `/origin-verify`; rotation for the two DB credentials (RDS-managed rotation). Task roles get `GetSecretValue` on exactly those ARNs.
9. **AWS Backup in CDK, in this phase:** a vault with its own CMK, daily RDS + S3 backups, **35-day retention**, cross-region copy, **Vault Lock in compliance mode** with a minimum retention exceeding the RDS window. Until this exists, the same credential that can delete the database can delete every recovery point. With single-AZ RDS (D-14) this vault *is* the disaster-recovery story: an AZ loss is recovered by restoring into the other AZ (or the other region) inside the 8-business-hour RTO.
10. **`S3StorageManager` in `src/storage.py`**, selected by `STORAGE_BACKEND=s3`: same five methods, same `assert_org_path` choke point, `ServerSideEncryption='aws:kms'` + `SSEKMSKeyId` on every put (the bucket policy 403s without them — **raise, don't warn**; today `src/qb_export_artifacts.py:158-162` swallows this and records `storage_path = None`), `list` reshaped to Supabase's `{'name', 'metadata': {'size','mimetype'}}` dict shape (`src/api/v2/qb_usa_runs.py:1438-1448` and `web_app.py:548` read it), `ResponseContentDisposition='attachment'` on presigned GETs (a bare S3 presigned GET renders the CSV in the tab), TTLs unchanged (120s/300s), no bucket CORS (both consumers are top-level navigations — tripwire if the SPA ever switches to `fetch()` + blob), key layout byte-identical `{org_id}/{batch_id}/{subfolder}/{filename}` because `artifact_id = 'a_' + sha256(path)[:12]`.
11. **Rehearsal data load on staging**, in this order and no other: **`alembic upgrade 0003_rds_adaptations` → the data load → `alembic upgrade head`.** Revision 0004's `FORCE ROW LEVEL SECURITY` applies to the table *owner*, and the RDS master user is `NOBYPASSRLS`, so at head PostgreSQL refuses `COPY ... FROM` outright (`0A000 COPY FROM not supported with row-level security`) and `pg_restore --data-only` cannot run at all — setting `app.org_id` does not help, because the dump holds every organization's rows. Between 0003 and 0004 is the load window; two tests in `tests/test_migrations.py` prove both halves, and `docs/runbooks/migrations.md` carries the procedure and the standing rule that follows (a revision never touches rows without a documented `SET app.org_id`). The load itself: `pg_dump --data-only -Fc` from Supabase, `pg_restore --disable-triggers` (self-referencing FKs `process_runs.superseded_by_run_id`, `import_batches.superseded_by` need it or a second UPDATE pass), the PHI split script (`scripts/split_phi.sql`: move the three identifier columns to `phi.transaction_identity`, populate `patient_ref`, move `source_transactions` to `phi` — P-3), then **`scripts/verify_parity.sql`** run against both sides: per-table `count(*)` for all 57 tables; `sum(debit), sum(credit), count(*) FROM journal_entries WHERE NOT is_test` and by `batch_id` (**these are the numbers posted to NetSuite/QuickBooks — to the cent**); `transactions` by batch; `qb_usa_payroll_gate.variance` (a generated column — any mismatch is a numeric coercion bug); `qb_export_tie_out`; **all 45 sequences `last_value >= max(id)`**; constraint diff; `patient_ref IS NULL` = 0; `phi.transaction_identity` = 76,132. Time every step. Checksums per table (`md5` over ordered rows) recorded.
12. **Write `docs/je-diff-procedure.md` and `scripts/diff_je_output.py` now** (v2 Stage 8.1) — Phase 5a invokes the gate repeatedly. Outputs are not byte-stable by construction (filenames embed `datetime.now()` at `src/exporters.py:654, 729, 782`; the validation report embeds a timestamp; re-runs mint new ids), so the procedure states what is compared (JE CSV *content*, sorted, ids normalized), how filenames are matched (`JE_Revenue_{Location}_{Period}_{FY}.csv` is the identity), that **no allowlist of differences exists**, the exact command, and **which two closed periods are the rehearsal periods and where their input workbooks are** — the `uploads` bucket holds 0 objects, so they exist only on the laptop; if they cannot be found the gate does not exist.
13. Copy the ~50 storage objects to staging's buckets under identical keys and `head_object` every non-null `storage_path` in `qb_export_tie_out` and `qb_usa_payroll_journal`.
14. **Documented restore drill** on staging: restore a snapshot to a scratch instance, verify counts, tie out one journal entry, **write down the elapsed time** — the first evidenced RTO (164.308(a)(7)(ii)(D), unmet today). **Repeated every phase from here on** (D-14).
15. Tear down the trial instance (ask first). Tear down staging's `network`/`compute` stacks at the end of the session; the `data` stack stays with RDS stopped.

**Verify:** `alembic upgrade head` from an empty PG 17 container yields a schema whose `pg_dump --schema-only` diffs against the Supabase original with only the intended deletions; `pytest` green on the fixture with RLS on; a cross-org read as `meridian_app` returns zero rows even with the `WHERE org_id` deliberately removed in a test; `SHOW shared_preload_libraries` includes `pgaudit`; a `put-object` without the KMS headers fails; the parity suite is clean; the restore drill has a recorded time under 8 business hours; `aws backup list-recovery-points` shows a locked vault.

**Roll back:** `cdk destroy` the staging `data` stack (deletion protection off on staging). Nothing production-facing changed.

---

### Phase 4 — Auth (Cognito), and Flip 1

**Goal:** identity on Cognito, both token types accepted, no forced password reset, federated users pre-linked, MFA on — proven on staging and then **flipped in production while data is still on Supabase**.
**Effort:** 18-21 days (v2 Stage 2's 2 + Stage 10's 13-15 + Stage 11's 0.5 + 2-3 for dual-token acceptance, migration-percentage reporting, fail-closed behaviour and the cut-off machinery).

**Steps**

1. **`user_profiles` first** (v2 Stage 2): migration + backfill of the 14 `auth.users` rows' metadata **while Supabase is still readable**; repoint `update_user_metadata` (`src/auth.py:186-209`) and `_fetch_user` (`:290-308`); the member list's per-user `AdminGetUser` becomes a join. Never reproduce these as Cognito custom attributes (2048-char cap, 50 max, undeletable).
2. **The auth ADR** superseding contract §0/§6: cookie session + CSRF for the browser, `Authorization: Bearer` for mobile/machine, dual issuer acceptance, `custom:app_uid`, token lifetimes.
3. `auth` stack: pool per §2.1; confidential app client; `custom:app_uid`; email via SES (`DEVELOPER` mode, the Phase 1 identity); MFA `ON`, TOTP only; threat protection `AUDIT`; `DeletionProtection=ACTIVE`. Google as a social IdP; Microsoft Entra ID as an OIDC IdP (**~1 day of registration friction that waits on an external tenant admin**; both stay, P-8).
4. `src/cognito.py` (sign-in, refresh, `SECRET_HASH`, `ForgotPassword`/`ConfirmForgotPassword`, MFA challenge) and the dual-token `validate_token`. Delete the token cache and the four authz caches; keep the seam names.
5. React screens in `web/`: login MFA step, password reset (`/forgot-password`, `/reset-password` leave the Jinja proxy list). No signup screen (P-6): `/signup` is removed from `next.config.mjs` and the Flask route deleted; membership is by invite code + `AdminCreateUser`. `/auth/google` and `/auth/microsoft` become redirects to the Cognito hosted domain; `/auth/callback` does one code→token exchange. **Delete** the `token_hash`/`verify_otp` branch, the implicit-tokens-in-query branch, the hash-fragment fallback, `/auth/set-session` (`@csrf.exempt`, accepts caller-supplied tokens) and `templates/auth/callback.html`; SEC-04 in `tests/test_security.py` retires with it.
6. **User Migration Lambda** (`lambda/user_migration/`, Python 3.12, 5s timeout, outside the VPC): both triggers, `legacy_users.json` bundled (`{email → supabase_uuid, has_password, providers}` — **all 14 users**, P-7), logs email *domain* and status only, fails closed on any non-200 from Supabase with a message that says "sign-in temporarily unavailable" rather than "invalid credentials". Migration-percentage report: a weekly script diffing `ListUsers` against `legacy_users.json`, posted to the phase report and the Obsidian note.
7. **Pre-provision every identity the Lambda cannot reach** (`AdminCreateUser` + `AdminLinkProviderForUser`) **before enabling either IdP** — §2.1.
8. Startup guard: `web_app.py:111-121` hard-fails in non-dev without `SUPABASE_URL`; require the Cognito vars instead. `_auth_disabled()` must still return `False` in non-dev regardless of provider config (SEC-03).
9. **Staging verification:** a Supabase-era password signs in and appears in Cognito with the right `custom:app_uid`; permissions resolve identically; a Google sign-in for a dual-identity user lands in the *same* account; password reset completes; MFA enrol + challenge; the 17 pending invite codes still redeem; the Lambda's p99 fits inside 5s; both workforce members have enrolled MFA on staging.
10. **Flip 1 (production): `AUTH_BACKEND=cognito` with dual acceptance on, on Render.** Preconditions: not during a close; `legacy_users.json` re-snapshotted **that day**; both users told the first sign-in may be slower. Both sign in (one password, one federated), confirm `GET /me` returns their real org/role/permissions; one real password reset; watch Lambda invocations/errors/duration and 5xx for an hour; an invite still redeems. **Leave Supabase Auth live and the trigger attached** — Phase 10 ends reversibility.

**Files touched:** `src/cognito.py` (new), `src/auth.py`, `web_app.py:1758-1935, 2130-2142`, `web/src/app/(auth)/*`, `web/next.config.mjs`, `lambda/user_migration/`, `infra/stacks/auth_stack.py`, `tests/test_security.py`, `tests/test_api_v2_auth_dashboard.py` (note `:309-321` asserts on the literal source text of `web_app.login`), `tests/test_api_v2_users.py`, `tests/test_auth_cache.py` (delete), `templates/auth/callback.html` (delete), `templates/auth/signup.html` (delete).

**Roll back:** `AUTH_BACKEND=supabase` + redeploy. `auth.users` is never mutated; Cognito users are copies. Anyone created in Cognito during the window is re-created in Supabase by hand (with two users, minutes).

---

### Phase 5a — Data layer port, FastAPI beside Flask, containers, CI/CD to staging

**Goal:** `/api/v2` and the data layer served by FastAPI running beside Flask in the same container, `src/` logic unchanged; api and web images built and deployed to **staging** ECS by CI with image scanning. **Production stays on Render + Supabase.**
**Effort:** 37-49 days — **the long pole.** Composition: data-layer port 21-26 (v2 Stage 5, unchanged in scope); FastAPI port of `/api/v2` (~90 route handlers across 7 modules, pydantic schemas already exist in `src/api/v2/schemas.py`) 10-15; containerize + ECS staging + CI/CD 6-8 (v2 Stage 7's 8.5-11 minus the IaC work now in Phase 2, plus reuse of the trial Dockerfiles). Reviewed as its own phase (D-16) so the critic loop stays tractable.

**Data layer port (v2 Stage 5, verbatim in substance)**

- `src/pg.py` (2 days): pooled psycopg2 connections, `app.org_id` set on checkout / `RESET` on return, autocommit default, explicit `transaction()`, five helpers, `DEC2FLOAT`. **Autocommit-by-default is not style:** four places swallow a DB error and continue (`src/process_runs.py:516`, `src/qb_export_artifacts.py:183`, `src/api/v2/user_routes.py:349`, `src/auth.py:788`); under an implicit transaction a swallowed error leaves the connection in `InFailedSqlTransaction` and turns a warning into a 500 elsewhere on the page. Test it.
- `src/phi.py` (1.5 days): the choke point; `COPY` for bulk writes.
- **The dual-maintenance rule** (0 days to write, **8-13 days to live with** — §7; the window is Phase 5a → Phase 9, about the same span v2 budgeted): from the moment `DatabasePostgres` exists until Phase 10, both backends must be correct. Feature freeze on the data-layer surface except to unblock a close; every production bugfix lands in both backends in the same commit with a test each; **rehearse the rollback monthly** by flipping staging to `DATABASE_BACKEND=supabase` and running one revenue run.
- `DatabaseSupabase` → `DatabasePostgres` (5-6 days, 63 sites in `src/database.py`), reading **both** the SQLite twin (`DatabaseSQLite:447`) and the Supabase twin each time — they have drifted. Delete `_all_rows`, `_PAGE`, `pnl_facts._paged`.
- Small modules (1.5 days, ~40 sites across 12 modules); `src/process_runs.py` (0.5 day — real `INSERT … ON CONFLICT (run_id, org_id)` closes an existing race); v2 API + `src/auth.py` sites (3 days, 37 sites; **fix `src/auth.py:419`**, where `.replace('Z', '+00:00')` on a `datetime` raises `TypeError` and breaks invite redemption); `web_app.py` + `invoice_generator` + the frozen Wearbly tables (3 days, 47+ sites; replace the read-max-then-increment invoice numbering with a sequence — it races).
- Test conversion (7-9 days): convert each fake-Supabase test file **immediately after** the module it covers, never in a batch; keep a `tests/legacy_supabase/` smoke subset (`@pytest.mark.legacy_backend`) alive until Phase 10 so a `DatabaseSupabase` bugfix can still fail a test.
- **Gate, not final check:** after `database.py` and again after `web_app.py`, restore production into the fixture, re-run a booked period, and run `scripts/diff_je_output.py`. Byte-identical or the port is wrong.

**FastAPI beside Flask**

- `api/` package: FastAPI app with the `/api/v2` routers ported one module at a time (`routes`, `auth_routes`, `config_routes`, `user_routes`, `oneshot_runs`, `qb_usa_runs`, `pnl_routes`, `runs_common`), pydantic request/response models (contract §10.1 says where pydantic must *not* be used — respect it), the error envelope from contract §4, rate limits from `src/api/v2/limits.py`, CSRF semantics from contract §6. **Flask is mounted under the FastAPI app** (`WSGIMiddleware`) so unported paths keep working at the same origin; a path is removed from the Flask side in the same commit that lands it in FastAPI (no half-migrated paths). OpenAPI is generated from the code and replaces `openapi/meridian-v2.json`; the TypeScript client in `web/src/lib/api/` is regenerated from it. `/api/v1/health` keeps working (D-25) as a thin FastAPI route.
- **Containers.** `Dockerfile.api` (from the trial: `python:3.11-slim-bookworm`, the WeasyPrint apt list, ARM64, non-root, RDS CA baked in; **`data/Calendar/Calendar.xlsx` is tracked and read at `web_app.py:783` — un-ignore it explicitly and assert it exists in the image**), `web/Dockerfile` (Next.js standalone). `.dockerignore` excludes `venv/`, `node_modules/`, `output/`, `data/input/`, `archive/`, `temp/`, `.git/`, root `*.xlsx`/`*.png` — without it the build context sweeps in client data. **Verify how production supplies `config/mappings.xlsx` before building an S3-fetch-at-boot mechanism** — it is gitignored, Render deploys from git with no disk, and periods still close, so the file may already be unused (`src/config.py:368-400`).
- `compute` stack: ECR repos (immutable tags, scan on push), task definitions (api 1 vCPU/2 GB ARM64, 40 GiB ephemeral, `stopTimeout` 120, health check `/api/v1/health`; web 0.25/0.5), services with the §2.5 constraints, deployment circuit breaker with rollback. Workflow `deploy.yml`: `pytest tests/` → buildx `linux/arm64` → Trivy → push `${{ github.sha }}` → `cdk deploy` staging → wait for stable.
- Staging hostnames `staging-app.meridiansgrp.com` (the app, marketing pages included) and `staging-api.meridiansgrp.com` (`/v3`) → CloudFront → ALB (ADR 0050). **Terminate the apex too** in production — it 301s to `www` — and test `curl -I https://meridiansgrp.com`: nobody types the `www`.

**Verify — a health 200 proves nothing.** On staging against the Phase 3 data: a full revenue run and a full QB USA payroll run end to end with byte-matching JE CSVs; an invoice PDF rendered in-container **byte-compared against one rendered on the Mac** (`scripts/build_meridians_invoices.py` is deterministic; a missing `fontconfig` produces wrong fonts, not a crash); an upload readable on the next request; a download arrives as a file; the `HealthyHostCount > 1` alarm fires when scaled to 2; `Calendar.xlsx` present in the running task; **force a task replacement mid-run** (`update-service --force-new-deployment`) and confirm every artifact on the results page still downloads — anything that 404s was never uploaded; every OpenAPI path in `meridian-v2.json` is served by FastAPI or has a dated retirement entry in `docs/migration-tracker.md`.

**Roll back:** `DATABASE_BACKEND=supabase` / `STORAGE_BACKEND=supabase`; `cdk destroy` the staging compute stack. Production is still on Render.

---

### Phase 5b — The Jinja gap: React screens

**Goal:** every path in the `jinja` rewrite list in `next.config.mjs` has a React screen or a recorded drop; the corresponding Flask routes and templates are deleted with tests proving nothing depends on them. An exit criterion for cutover.
**Effort:** 8-14 days (v2 had none of this; the prompt's 10-18 shrinks because Wearbly is frozen (P-5) and signup is invite-only (P-6)).

**Steps.** The 9 proxied path families: `/logout` (trivial), `/signup` (dropped in Phase 4), `/forgot-password` + `/reset-password` (built in Phase 4), **`/invoice`** (a multi-step wizard: items → preview → generate; the biggest), `/superadmin`, `/profile`, `/wearbly` (**dropped** — the four `uniform_*` tables stay readable through `/api/v3` later; the screen is not rebuilt), `/config/mx-employees`. `/auth/*` moved in Phase 4. Each retired Jinja template and its `render_template` route are deleted with a test proving nothing depends on them; the `jinja` array in `next.config.mjs` shrinks to empty. **78 `render_template()` calls exist today**; the families above are the *reachable* ones — the rest are the old wizard surface, retired as Phase 11 migrates each process.

**Verify:** the `jinja` array is empty; every remaining Flask `render_template` route is one of the three process wizards (owned by Phase 11) or has an entry in `docs/migration-tracker.md`; accessibility tests (`web/src/__a11y__/`) cover the new screens; an invoice generated through the React wizard byte-matches one generated through the old Jinja path — **done 2026-09-16, byte-identical HTML** (the old path was deleted in `b1beb08`, so it was reconstructed from `git archive b1beb08^`; the HTML is compared and not the PDF, which embeds a WeasyPrint timestamp. Command, method and the verbatim result: `docs/reports/phase-5b-report.md` §Evidence. Kept as a one-off, not a test: it cannot run without the archived files).

**Roll back:** per screen — the Jinja route is deleted only after its React replacement is verified, so reverting the deletion commit restores it.

---

### Phase 6 — Observability and audit

**Goal:** logs, metrics, alarms, dashboards and the PHI-access trail exist **before anything new serves traffic**.
**Effort:** 4-6 days (v2 had this scattered across Stage 4.13 and Track C; the dashboards and the API audit stream are new).

**Steps**

1. `observability` stack: KMS-encrypted log groups (`/ecs/meridian-<env>-api|web`, later `worker`; 400 days), a subscription to the Object-Locked audit bucket with a 7-year glacier lifecycle; RDS log export (postgresql, upgrade) to CloudWatch.
2. Alarms → SNS → Andres: `HealthyHostCount > 1` (api), ALB 5xx rate, target response time p95, ECS task stopped-with-error, RDS `FreeStorageSpace`/`CPUUtilization`/`DatabaseConnections`, Lambda errors (User Migration), every break-glass `AssumeRole`, auth-failure spike, unusual export volume (`artifact_downloads` per hour), GuardDuty/Security Hub high findings, budget thresholds. (SQS DLQ depth, new API client IP and scope escalation are added in Phases 11-12 with the things they watch.)
3. **`audit.phi_access`** written by `src/phi.py`; **API audit stream** (client, user, scope, endpoint, record id, result, IP — never PHI) as structured JSON logs, with a CI lint that no log line can carry a `RunResult`, a DataFrame, or a raw request body.
4. One CloudWatch dashboard per environment: request rate, errors, latency, task counts, RDS health, audit-event counts.
5. Track C step 6's **monthly activity review** becomes a recurring calendar entry with a query pack (`audit.phi_access`, the pgaudit group, CloudTrail S3 data events, break-glass assumes).

**Verify:** each alarm has been tripped deliberately once on staging and the SNS mail arrived; a `phi` read on staging produces exactly one `audit.phi_access` row and one pgaudit line, and neither contains an identifier value; the dashboard renders.

**Roll back:** none needed; additive.

---

### Phase 7 — Email: Resend → SES

**Goal:** no non-AWS email provider after this phase.
**Effort:** 1-2 days (SES verification and production access were done in Phase 1).

**Steps:** `src/email_service.py` sends via `boto3` SES (`SendEmail` with the existing HTML templates); configuration set with event publishing (bounces/complaints → SNS); `RESEND_API_KEY`/`RESEND_FROM_EMAIL` removed from `render.yaml`, `.env.example`, secrets; `resend` removed from requirements and re-locked; Track C's "does Resend ever carry PHI" trace closes as moot with a note.

**Verify:** an invite email arrives from `mail.meridiansgrp.com` with DKIM pass; a deliberate bounce shows in the configuration-set metrics; grep for `resend` returns nothing.

**Roll back:** `git revert`; Resend's API key is not deleted until the phase is accepted.

---

### Phase 8 — Security hardening and compliance evidence

**Goal:** the control matrix is complete with evidence locations, scans are clean, the restore and DR drills are measured, and a pen-test prep package exists. **Production stacks are deployed (empty) in this phase** so Phase 9 rehearses against the real target.
**Effort:** 6-10 days of engineering, overlapping Track C's 20-25 days of documentation (§4).

**Steps:** control matrix (control → implementation → evidence) covering HIPAA Security Rule safeguards and SOC 2 Security/Availability/Confidentiality criteria, in `docs/compliance/`; Security Hub, Inspector, Config and GuardDuty at zero unresolved high findings; ZAP dynamic scan against staging clean; **restore drill against a production-shaped snapshot with elapsed time recorded**; **DR test**: deploy the `data` stack from the cross-region backup copy into the second region and verify counts (this is the number in the contingency plan — it must be under 8 business hours, D-14); rotate every secret once via runbook; the in-transit encryption position paper (the ALB → task hop is plaintext HTTP inside the VPC — an *addressable* specification, so it is documented, not skipped); pen-test prep package (scope, accounts, sandbox creds, architecture diagram) and the `needs-a-human` list (partner BAAs, written policies, auditor, pen test). Deploy production `vpc`, `edge`, `data`, `auth`, `compute`, `api`, `observability` with synthetic smoke data; confirm the bill matches the Phase 1 estimate.

**Verify:** every control in the matrix points at an artifact that exists; the DR test's RTO/RPO are written in the contingency plan and are ≤ 8 business hours / ≤ 1 hour **in-region**; the regional RPO is the age of the newest cross-region copy (≈ 24-30 h, ADR 0007 as amended 2026-09-16) unless Andres funds a cross-region replica — the contingency plan states whichever is true.

---

### Phase 9 — Cutover (Flip 2). **Point of no return #1.**

**Goal:** production traffic on ECS, data on RDS, artifacts on S3, in the production environment. Auth is already on Cognito (Phase 4).
**Effort:** 5-7 days (v2 Stage 8's 4-6 for two rehearsals + Stage 9's 1 day; the diff procedure was written in Phase 3). **Ask Andres before cutover.**

**Preconditions — all true:**
- Production stacks deployed (Phase 8) and smoke-tested; production cost within the approved estimate.
- **Rehearsal 1** (full dress, on staging, from a fresh dump) and **Rehearsal 2** (timed, from a clean RDS, following `docs/runbooks/cutover.md` literally, with no runbook edits) both clean on `scripts/verify_parity.sql` and `scripts/diff_je_output.py` for the two rehearsal periods.
- The Phase 8 restore drill re-run against production RDS.
- DNS TTL on `www` and the apex at 300s for ≥24h; the apex and `staging` already resolve through CloudFront.
- The `jinja` array in `next.config.mjs` is **empty** — not "empty except the three process wizards", which was never true of that file. Its only entries are the two behind the `MERIDIAN_JINJA_AUTH=1` rollback hatch, which a normal build does not set. The process wizards are React screens over `/api/v2`; the Jinja URLs have no ALB path pattern and 404 after the flip (Phase 5b exit criterion re-checked).
- **Not during a close.** Periods are 4-5 weeks; pick the widest gap; someone reachable by phone.
- **Point of no return: strict (D-20)** — PoNR = the first write of any kind on AWS. Rollback is a clean DNS flip. The smoke test in step 5 is therefore **read-only**, and the runbook lists the deliberate writes it makes: the `public.artifact_downloads` audit rows minted by the artifact downloads (migration 022), which are **deleted from RDS on rollback and never re-applied to Supabase** — they record the operator pressing download, not anything a user did. (There is no `process_runs` heartbeat row; earlier drafts named one and it does not exist.) The smoke list also excludes every QuickBooks-connected screen, because a QBO call refreshes the token and writes `qbo_connection`.

**Steps**

1. **Write freeze, and prove it.** Render in maintenance; **two** queries — `process_runs WHERE state IN ('parsing','ready','running','blocked')` (the column is `state`, migration 022) and `import_batches WHERE status='processing'` (that one *is* `status`, migration 002) — **and** a phone call, **and** suspending `meridian-api` (maintenance mode stops requests, not the threads already running). `process_runs` is blind to the **three** run families still held as module-level dicts in the api process (`adp_payroll_*`, `booking_payroll_*`, `adp_v3_job_status`), not five: the other four are `RunStore` instances and are in `process_runs` already.
2. Final `pg_dump -Fc` from Supabase to the **retained** encrypted archive (§6). Restore into production RDS; run the PHI split; run the parity suite with checksums. **Abort on any difference.**
3. Copy storage objects created since the last sync, **preserving `{org_id}/{batch_id}/…` prefixes**; `head_object` every persisted `storage_path`.
4. Deploy production with `DATABASE_BACKEND=postgres`, `STORAGE_BACKEND=s3`, `AUTH_BACKEND=cognito`.
5. Smoke, read-only: sign in; `GET /me`; open a completed run; download an artifact; render an invoice PDF (to a temp path, not stored); open config screens.
6. Flip DNS: `www` and apex → CloudFront. Watch the dashboard for an hour.
7. **Leave Render running (not suspended) and the Supabase project live and untouched.**

**Roll back (before the PoNR):** DNS back to Render, ~5-10 minutes plus TTL; nothing is lost. **After:** DNS back, then re-apply divergent writes from the runbook enumeration — for bookings, document the affected `import_batches.id` values and re-enter each. Assume a day, and not during a close.

---

### Phase 10 — Decommission Supabase and Render. **Point of no return #3 (irreversible).**

**Goal:** Supabase and Render are gone; the User Migration Lambda is retired; every `SUPABASE_*`/Render env var and doc is removed. **Ask Andres before deleting anything.** Flask, the Jinja wizards and `web_app.py` are *not* removed here — Phase 11 owns them.
**Effort:** 1.5-2.5 days spread over the exit checks. Calendar: gated by two close cycles (~2-3 months after Phase 9); **Phase 11 starts in parallel** — it does not wait.

**Preconditions:**
- **Two full close cycles completed on AWS** since Flip 2.
- **Cognito completion criterion met:** every `auth.users` row with an org membership exists in Cognito with a matching `custom:app_uid`; the migration percentage is 100% of active users, **or the cut-off date has passed** (set at Phase 9 + 60 days) — after which the trigger is detached, the Lambda deleted, and any straggler is `AdminCreateUser`'d and sent a password reset (D-06).
- Both `meridiansgrp.com` and `www` resolve through CloudFront; nothing in DNS or the repo points at Render (the apex pointed at Render until cutover step 7a in Phase 9 removed those records — deleting Render with a stale apex takes the bare domain dark).
- The restore drill has been re-run against production RDS with its time recorded.

**Steps**

1. Final `pg_dump -Fc` of Supabase (including `qgenda_workspaces` and the `auth` schema) to the retained archive (named custodian: Andres; retention and disposal per Track C — **never write "delete after verification"**, that sentence and this step cannot both be true).
2. Verify the archive restores into a scratch PG 17 container with matching counts **before** cancelling anything.
3. Cancel Supabase. **Irreversible.** Users created post-cutover cannot recover old passwords; the archive is the only record of the pre-migration database.
4. Suspend both Render services; wait one full week suspended-not-deleted; delete. Delete `render.yaml` (it already describes services that never matched the live ones).
5. Delete `DatabaseSupabase`, the Supabase branches of `src/storage.py`, the `.sb` aliases, `tests/legacy_supabase/`, the `supabase` dependency, every `SUPABASE_*` env var, the User Migration Lambda and its Supabase anon key, `deploy/aws-trial/` (if not already).
6. `CLAUDE.md` (local) + `README.md` + `docs/architecture/` updated; `docs/migration-tracker.md` lists only Phase 11/12 items.

**Roll back:** steps 1-2 and 4-6 are reversible or repeatable. Step 3 is not; after it the archive is the rollback, and rolling back means standing a database up from it — hours to days.

---

### Phase 11 — Process framework (on AWS)

**Goal:** adding a process = one folder plus business logic. The three existing processes migrated one at a time onto a generic worker, with output comparison, every worker result serialized out of process memory, the Flask wizards and `web_app.py` retired, and `desiredCount=1` lifted.
**Effort:** 27-40 days. **This absorbs v2's largest excluded item** — "migrate the 5 in-memory wizards to `RunStore` (multi-week)" — required because the api and worker become separate containers. Composition: manifest + registry extension 3-4; generic worker + SQS + idempotency 5-7; worker-state serialization 10-15; scaffold + conformance suite 4-6; migrate three processes with comparison 5-8. **Built against production RDS/S3 with no second backend to keep alive** — the cutover-first dividend.

**Steps**

1. **Extend the registry, never duplicate it.** The manifest (`src/processes/<id>/manifest.py`) is the single source that *populates* `src/process_runs.PROCESSES`, the `role_permission_processes` rows (migrations 029/030), `/api/v2/processes`, and the state machine's per-process transitions (`src/api/v2/state_machine.py`, contract §2). Fields: id, name, color, input types + validation, wizard steps (with **custom steps** allowed — contract §12.1-12.11 explains why one uniform wizard cannot fit: two processes have no human step, `blocked` is reached from `running`, permissions split within one wizard), outputs, required permissions/scopes, `touches_phi`.
2. **Generic worker** (`workers/`, its own Dockerfile from the api base): consumes `meridian-<env>-sqs-jobs` (long-polling, visibility timeout > the longest run, DLQ after 3 receives, DLQ-depth alarm); loads the manifest; calls the processor in `src/` (pure business logic, no AWS or web imports — a lint enforces it); inputs from S3, outputs to S3; run history and audit **extend** `process_runs` and `artifact_downloads` (migration 022) — no parallel tables.
3. **Serialize worker state.** Inventory the volatile keys in `src/run_store.py` (parsed `RunResult`s, DataFrame-backed results, `_RUN_OVERRIDES` at `src/qb_usa_payroll_roster.py:142`). Every result the worker produces is written to S3 (**parquet or JSON — never pickle**: a deserialised object the worker did not write is code execution, and no upload path may share a prefix with worker state; Codex PS-15) or `process_runs.run_state`; the api reads them back; nothing lives in a module-level dict. **Classification follows the data, not the store (Codex PS-2):** `run_state` and the `artifacts` bucket hold identifiers and non-PHI results only; any state that carries an identifier or a raw billing row is written to the `phi` bucket under `{org_id}/{run_id}/state/` through `src/phi.py`, which audits the open, and the conformance suite (step 6) fails a process whose `touches_phi` manifest flag is false but whose state contains a `phi`-classified column. **The queue message is a contract (Codex PS-5):** `{run_id, org_id, actor_user_id, process_id, input_object_versions[]}`, signed by nothing but authorised by the worker re-reading the `process_runs` row **before** it sets `app.org_id`: the row must exist, belong to `org_id`, be in a runnable state, name the same actor, and reference the same object *versions* — otherwise the message is dropped to the DLQ with a reason, and no tenant context is ever set from the message alone. **This is what lifts `desiredCount=1`** (§2.5) — remove the constraint and the alarm's "correctness" role in the same commit; rolling deploys return.
4. **Idempotency:** a `job_idempotency` table keyed on the contract §12.9 `Idempotency-Key`; the record is written **before** the QBO call with Intuit's `RequestId` and a `pending` state; on completion the same row is updated to `completed` with the per-entry remote result; a retry that finds `completed` returns it, a retry that finds `pending` **re-queries QuickBooks by the persisted `RequestId`** and settles the row from what Intuit says (posted → `completed`; unknown → the call is made again with the same `RequestId`, which Intuit de-duplicates) — never "return the prior result" of a call that may not have happened (Codex PS-11); duplicate *input* is a warning (`DUPLICATE_INPUT` with `previous_run_id`), not a block. A test proves a job redelivered by SQS cannot post a JE twice.
5. `scripts/new-process <id>`: generates the folder, manifest, processor stub, tests. `docs/adding-a-process.md`.
6. **Conformance suite** (`tests/conformance/`): file validation, permissions, audit logging, idempotency, error handling, no PHI in logs. A process that fails is not registered (the registry loader refuses it).
7. Migrate `qb-revenue`, then `mx-payroll`, then `qb-usa-payroll`, each with `scripts/diff_je_output.py` against the previous implementation's output for the two rehearsal periods before its Flask wizard route and Jinja templates are deleted. The old `threading.Thread` sites (15 on this branch) go with them. When the last Flask route is gone, `web_app.py`, `templates/`, `flask*` dependencies and the `WSGIMiddleware` mount are deleted — with the tracked note from §1 updated in the same commit.

**Verify:** `new-process demo` produces a registered, conformance-passing process with zero infrastructure edits; each migrated process byte-matches; a killed worker mid-run leaves a resumable `process_runs` row and no orphaned state; `desiredCount=2` in production runs a qb-usa-payroll wizard end-to-end with the export on a different task than the review; `grep -r flask` returns nothing.

**Roll back:** per process — the Flask wizard route is deleted only after the diff is clean, so reverting the deletion commit restores it. **The revert is not the whole rollback (Codex PS-14):** in order, (1) stop submissions (`/api/v2/processes` returns 503 for that process), (2) let the worker drain or purge the queue for that process and confirm zero in-flight, (3) put `desiredCount=1` and the single-task alarm back in the same deploy that restores the in-process thread — two execution paths for one process, or two api tasks with in-process state, is the race this phase exists to remove, (4) confirm the restored Flask path reads the last serialised `process_runs` row rather than a module dict. Rehearse it once on staging before the first process is migrated.

---

### Phase 12 — API platform, API security, and final cleanup

**Goal:** `/api/v3` for humans, our scripts, and outside machines, with scopes, machine auth, process endpoints, webhooks, generated clients, an admin screen, a sandbox org, and the full security test programme; `/api/v1` and `/api/v2` retired; the migration tracker empty; the repo layout matches `docs/architecture/repo-layout.md`.
**Effort:** 28-44 days (+3-5 if a PHI-scoped partner exists and API Gateway + mTLS is built). Composition: resource endpoints + scopes 8-12; machine auth + admin screen 5-8; webhooks 4-6; OpenAPI clients (TypeScript for `web/` and future React Native, Python for scripts/partners) 2-3; sandbox org 3-5; security tests + dynamic scan 5-8; `docs/plans/mobile-readiness.md` 1-2; final cleanup 1-2. **Entirely new relative to v2.**

**Steps**

1. `/api/v3` routers: resource-based REST for runs, journal entries, mappings, employees, allocations; cursor pagination and filtering (contract §11 as the model); consistent error envelope; **object-level authorization on every request** (this caller, this record, this org — `404`, never `403`, on cross-org per contract §8); property-level authorization (strict pydantic schemas, `extra='forbid'`, PHI masked unless `phi:read`); process endpoints generated from manifests (pre-signed upload URL with size/type limits → start run → status → list → download).
2. Scopes (`processes:run`, `runs:read`, `revenue:read`, `phi:read`, …) as Cognito resource-server scopes for machines and as a permissions-derived set for humans; enforced server-side by one dependency, never per-handler ad hoc.
3. Machine auth: one Cognito app client per external system; secrets shown once, stored hashed in Postgres, rotatable without downtime, revocable instantly; optional IP allowlist; tokens ≤15 minutes; admin approval to create; auto-disable after 90 idle days; quarterly access-review report. Alarms: new client IP, scope escalation. **Authorization is never the token (Codex PS-3):** an `api_clients` row (`client_id`, `org_id`, granted scopes, `disabled_at`, `revoked_epoch`, BAA reference) is read on every request; the tenant is the row's `org_id` and nothing in the token; effective scopes are the token's scopes ∩ the row's current grants; a token minted before `revoked_epoch` is refused. That lookup is what makes "revoked within one minute" true with 15-minute tokens.
4. **PHI scope gate:** no client receives `phi:read` until a signed partner BAA is recorded (a `partner_baas` table with document reference and dates), admin-approved, and logged. **mTLS (mutual TLS — the client presents a certificate too) via API Gateway custom domain + truststore for any PHI-scoped partner** — built only when the first such partner exists (Phase 0 ADR). **The shared CloudFront/ALB ingress refuses PHI-scoped machine tokens (Codex PS-4):** the api trusts an `X-Meridian-Client-Cert-Subject` header only when it arrives from the API Gateway origin (its own origin-verify secret), binds that subject to the `api_clients` row, and a `phi:read` machine token with no verified subject is a 404 whichever hostname it arrived on — a stolen bearer token is worth nothing without the partner's certificate. A security test sends the same token to every ingress.
5. Webhooks: subscriptions on `run.completed`, `run.failed`, …; EventBridge → SQS delivery with retries and DLQ; HTTPS only; **SSRF guard** (block private, link-local and metadata IP ranges at subscription time and at delivery time after DNS resolution — and the delivery **connects to the address it validated**, every A/AAAA answer checked, TLS verified against the hostname, redirects disabled; a re-resolving client defeats a DNS-rebinding test that only checked the metadata IP, Codex PS-7); **signature contract (Codex M):** `Meridian-Signature: t=<unix>,v1=HMAC-SHA256(secret, "<t>.<event_id>.<body>")`, one secret per subscription in Secrets Manager with a 24-hour rotation overlap, receivers reject `|now − t| > 300 s` and de-duplicate on `event_id`, and a verification helper ships in both generated clients; **tenant binding at delivery, not only at subscription (Codex PS-6):** the delivery record carries `org_id`, and the sender re-reads the subscription and the `api_clients` row at send *and* at every retry/redrive — event org, run org, subscription org and client org must all match or the delivery is dropped with a reason; ids only in payloads, never PHI; delivery history visible in the admin screen.
6. Admin screen in `web/`: create/revoke clients, set scopes, rotate secrets, view usage and delivery logs.
7. **Sandbox (D-18)**: a synthetic org inside the staging environment with generated data (`deploy/aws-trial/make_sample_revenue.py` is the seed), separate API clients, never real PHI. Staging is deployed for sandbox sessions and torn down after, like any other staging session. **Never on stores that have held a production dump (Codex PS-8):** ADR 0008 keeps staging's RDS and buckets between sessions and Phase 9 rehearses on fresh production dumps, so a sandbox session opens only after `scripts/staging_wipe.py` has dropped and recreated the database from migrations and emptied both buckets (versions included) and written that to the log; no production restore may run into staging while any sandbox client is enabled — the two are mutually exclusive session types.
8. **Security tests in CI** (`tests/security/`): auth, object-level access with ID swapping and cross-org attempts, scopes, injection, rate limits, SSRF, replay, oversized payloads, unknown fields; OWASP API Security Top 10 mapped in the control matrix. A dynamic scan (OWASP ZAP baseline) against staging. WAF rate-based rules + per-client quotas + progressive lockout on auth failures. Security headers and a strict CORS allowlist on every response. Errors never leak stack traces, SQL, internal ids or cross-org existence.
9. `docs/plans/mobile-readiness.md`: what a React Native client needs (bearer flow, refresh, MFA challenge, pre-signed uploads) and what it must never do (no `custom:app_uid` reliance, no PHI caching).
10. **Retire `/api/v1` and `/api/v2` (D-25)** once `/api/v3` covers each, with Andres's sign-off; the health-check path moves to `/api/v3/health` and the ALB/CloudFront health checks are updated in the same commit. `docs/migration-tracker.md` empty; every folder README true; repo layout matches the doc.

**Verify:** every security test passes and each has a known-bad control test that fails; ZAP baseline shows no high findings; a client without `phi:read` receives masked fields and an attempt to read another org's run returns 404; a webhook to `169.254.169.254` is refused; a replayed webhook is rejected; a revoked client's token fails within one minute; generated TypeScript client type-checks against `web/`; `docs/migration-tracker.md` is empty.

**Roll back:** `/api/v3` is additive; disable the routers. No data model changes are irreversible.

---

## 4. Deferred items and Track C

### Deferred, explicitly (with triggers)

| Item | Status vs v2 | Trigger / estimate |
|---|---|---|
| Stop persisting `source_transactions.raw_data` (132 MB of 183 MB, ~85% of stored PHI; `get_source_transactions` has no callers) | still deferred; the rows move to `phi.source_transactions` meanwhile (P-3) | Andres confirms nobody reads it. ~1 day. Traceability = `(upload_id, row_number)` + the original workbook in the `phi` bucket. |
| Migrate the 5 in-memory wizards / serialize worker state | **no longer deferred — Phase 11** | — |
| RLS via `app.org_id` | **no longer deferred — Phase 3** (D-10) | — |
| Resend → SES | **no longer deferred — Phase 7** (D-11) | — |
| Multi-AZ RDS | deferred by decision (D-14) | a real outage whose cost exceeds ~$28/mo, or Stella Mattina states an RTO under 8 business hours. Flip one CDK flag; re-run the restore drill. |
| Compute Savings Plan / RDS Reserved Instance | still deferred | one full month of measured production load. ~$13-20/mo saving. |
| Second AWS account for production | deferred by design | when a second workforce member needs admin, or an auditor asks. The CDK is split-ready; the cost is a data move and a BAA re-acceptance. |
| API Gateway + mTLS for partners | conditional | the first PHI-scoped external partner. 3-5 days. |
| Interface VPC endpoints | deferred (D-19) | an auditor asks for private-path assurance. ~$22/mo for three in one AZ. |
| psycopg 3 | deferred (D-21) | any time after Phase 5a; contained behind the repository layer. 1-2 days plus shape re-checks. |
| Wearbly as a framework process | deferred (P-5) | Andres wants Wearbly active again. Build it as a `new-process` in Phase 11's framework; the data is intact. |

### Track C — Compliance programme (parallel, unchanged from v2 in content)

**Not optional, and the part most likely to be skipped.** Nothing in `docs/` today is about HIPAA, BAAs, risk analysis or PHI handling. Two workforce members (D-04): every artifact is written for two named people — short, not optional. **20-25 days**, of which the risk analysis and policy set are ~8; partly waiting on an attorney. Its outputs are the evidence the prompt's control matrix points at, and the `needs-a-human` list is where its human-only items live.

1. Collect the executed Stella Mattina BAA (D-03) — Phase 0. 2. Accept and register the AWS BAA — Phase 1. 3. Resend PHI trace — closes with Phase 7. 4. Name the security official in writing (Andres) — first. 5. **Risk analysis** (NIST SP 800-66r2 structure; 3-4 days, the item most likely to double) — start in Phase 3 when the inventory is fresh, revise after Flip 2. 6. Risk management plan, sanction policy, **information system activity review** (monthly, 30 minutes, initialled) — Phase 6 makes it a calendar entry. 7. Workforce security, access management, training, termination checklist (Cognito disabled, Identity Center removed, break-glass rotated, laptop returned). 8. Incident procedures and breach-notification runbook (business associate → covered entity, ≤60 days) with the phone number in it. 9. Contingency plan: backup, DR, emergency mode — **RTO 8 business hours / RPO 1 hour (D-14)**, evidenced by the per-phase restore drills and the Phase 8 DR test. 10. Evaluation — annual, first due one year after Flip 2. 11. Physical safeguards including the MacBook (which holds PHI today: `SM - P07-2026 Payroll Booking Report….xlsx`, `SM P&L Provider Prototype3.xlsx`, ~125 entries under `output/`) — the Phase 0 sweep is the first action. 12. In-transit encryption position paper — Phase 8. 13. Policy retention six years — the Object-Locked CloudTrail/audit bucket satisfies it; 400-day log groups do not. 14. **Texas HB 300** (training within 90 days of hire, refreshed every two years; 60-day breach notice) — **confirm the current statutory text with counsel**. 15. Attorney engagement for the policy set and the BAA review.

**Verify:** every artifact exists as a dated, signed file in the evidence set; the monthly review has at least two dated entries before Phase 10; the RTO in the contingency plan matches a measured drill.

---

## 5. Cost model

All figures **monthly, 730 hours, pre-tax**, with a taxed column at **×1.066** (Texas taxes data-processing services at 8.25% × 80% = 6.6%; no AWS calculator includes it; verified against this account's own bill). Rates are the ones v2 pulled from this account's bill and the Pricing API; new lines are marked with their confidence. **Re-estimated in Phase 1 from the CDK's actual resource list and approved by Andres before any environment resource is created.**

### Today

| Line | Pre-tax | Confidence |
|---|---:|---|
| Render `Meridian` (standard) | $25.00 | HIGH |
| Render `meridian-web` (starter) | $7.00 | HIGH |
| Supabase (tier unread) | ~$25.00 | **LOW — unverified** |
| Trial stack (`t4g.large` + EIP + EBS, budget $60) | ~$55-60 | MEDIUM — **stops at Phase 3** |
| **Meridian total today** | **~$112-117** | |
| *(memo)* the assistant app's AWS stack + Bedrock tokens | ~$162 | not Meridian's |

### Production, steady state (single-AZ, D-14)

| Line | v2 | v3 | Confidence / why |
|---|---:|---:|---|
| Fargate `api`, ARM64, 1 vCPU / 2 GB | $28.83 | $28.83 | HIGH |
| Fargate `worker`, ARM64, 0.5 vCPU / 1 GB (from Phase 11) | — | $14.42 | HIGH |
| Fargate `web`, ARM64, 0.25 vCPU / 0.5 GB | (+$7.21 deferred) | $7.21 | HIGH (now in scope) |
| ALB hours + ~1 LCU + 2 public IPv4 | $24.73 | $24.73 | HIGH/MEDIUM |
| NAT gateway + EIP + ~20 GB | $37.50 | $37.50 | hours HIGH, data LOW |
| VPC endpoints (gateway only, D-19) | — | $0.00 | HIGH |
| CloudFront (+ Shield Standard) | $0.00 | ~$1.00 | MEDIUM — free tier covers 1 TB |
| WAF (on CloudFront; 1 ACL + 3 rules + requests) | $8.60 | $8.60 | HIGH |
| RDS `db.t4g.small` single-AZ + gp3 20 GB | $25.66 | $25.66 | HIGH |
| RDS PITR backups + AWS Backup 35-day vault (cross-region copy, ~1 GB) | $0.00 | ~$1.00 | HIGH |
| S3 (artifacts + phi + audit Object Lock) | $0.50 | ~$1.00 | HIGH |
| SQS + EventBridge (from Phase 11) | — | ~$0.00 | HIGH (free tier) |
| Cognito Essentials + threat protection (2 MAU) | $0.10 | $0.10 | MEDIUM-HIGH |
| Secrets Manager (6 → ~10 secrets) | $2.40 | $4.00 | HIGH |
| KMS (4 → ~6 CMKs + requests) | $4.30 | $6.30 | HIGH |
| ECR (~3 images) | $0.20 | $0.40 | HIGH |
| CloudTrail + S3 data events | $0.15 | $0.30 | MEDIUM |
| AWS Config + HIPAA conformance pack | $9.00 | $9.00 | **LOW — real range $5-25** |
| GuardDuty (+ Malware Protection on the `phi` bucket) | $8.84 | $9.50 | MEDIUM |
| **Security Hub** (2 standards, 1 account) | — | ~$10.00 | **LOW — $5-20** |
| **Inspector** (ECR scans) | — | ~$2.00 | MEDIUM |
| **Macie** (2 buckets, automated discovery off) | — | ~$2.00 | LOW |
| **IAM Access Analyzer** (unused-access, ~10 roles) | — | ~$2.00 | HIGH |
| CloudWatch logs + metrics + alarms + dashboard | $9.00 | $13.00 | MEDIUM |
| SES | $0.01 | $0.10 | HIGH |
| SSM ops instance `t4g.nano` (or $0 with ECS Exec) | (bastion, in v2 total) | $3.10 | HIGH |
| **Subtotal, single-AZ** | **$159.82** | **~$211** | |
| **× 1.066 Texas** | **$170.37** | **~$225** | |
| *(not bought — D-14)* RDS Multi-AZ | +$26.39 | (+$28 taxed) | the price of the availability we chose not to buy |

Before Phase 11 (no worker, no SQS) production is ~$196 pre-tax / ~$209 taxed.

**Why production went up ~$55/mo over v2:** the worker and web services (~$22), the four extra security services the prompt requires (~$16), more secrets/keys/logs (~$8), CloudFront/backup/ops (~$5). None of it is optional under the prompt.

### Staging — torn down between phases (D-15)

| State | What runs | Pre-tax | Taxed |
|---|---|---:|---:|
| **Idle (the default)** | `data` stack only: RDS `t4g.micro` stopped (storage $2.30 + backup ~$0.50), buckets, 5 CMKs ($5), secrets ($4) | ~$12 | ~$13 |
| **During a staging session** (pro-rated by the hour) | + `network` (NAT $37.50), `compute` (ALB $24.73, `api` 0.5/1 $14.42, `web` $7.21), WAF ACL $8.60, logs ~$4, RDS running +$12.41 | ~$121 | ~$129 |

A typical phase uses staging for 3-10 working days; at ~$4/day that is **$12-40 per phase on top of the ~$13 idle**, not a standing bill. The sandbox (D-18) is a staging org and adds nothing.

### Steady state, all in

| Configuration | Taxed / month | vs the ~$250 ceiling |
|---|---:|---|
| **Production single-AZ + staging idle (the decided configuration)** | **~$238** | fits, ~$12 headroom |
| Production single-AZ + staging idle, before Phase 11 (no worker) | ~$222 | fits |
| *(not chosen)* + Multi-AZ | ~$266 | over |
| *(not chosen)* + staging always on | ~$354 | over |

**The headroom is thin.** Config and Security Hub are the two LOW-confidence lines ($5-25 and $5-20); if both land high, production alone is ~$250. The Phase 1 estimate is where that gets pinned down, and the Savings Plan (§4) is the lever if it does.

### During migration (overlap)

Render ($32) + Supabase (~$25) run until Phase 10. Staging exists from Phase 2 at ~$13 idle plus session time; production stacks exist from Phase 8 (deployed for rehearsal). At 3 focused days/week the Phase 2 → Phase 10 window is roughly **9-13 months** (§7). Overlap: ~$57 × 9-13 months ($510-740) + staging idle + sessions (~$200-450) + production for the last ~2-3 months before cutover (~$420-630) ≈ **$1,100-1,800 of one-time overlap spend across the migration**, against v2's ~$700-1,400 and the platform-first order's ~$1,500-3,500. Plus one-offs (~$5 per restore drill, ~$10 per DR test).

### Against the quoted alternative (premise unchanged, still unverified — P-9)

Render HIPAA tier (~$400) + Supabase Team + HIPAA add-on (~$800) ≈ $1,200/mo. Both are quotes for tiers Meridian is not on and neither is in writing. If they hold, AWS at ~$238 saves ~$960/mo. **The honest counter-case stands:** if PHI were not in scope, AWS is 3-4× the cost of today's ~$57. This migration pays for itself only because of the HIPAA tier — and, with Phases 11-12, because of what Meridian can offer (an API, partners, a mobile client) that Render + Supabase at this tier cannot.

---

## 6. Data safety

This system books real payroll and generates journal entries that go to NetSuite and QuickBooks. A wrong number that still cross-foots is worse than a crash.

### Availability target (D-14)

Andres's constraint: "we don't want to lose data but some is acceptable." Recorded as **RPO ≈ 1 hour, RTO ≈ 8 business hours.** RDS point-in-time recovery restores to any 5-minute mark in the last 7 days, so the RPO is met with room; AWS Backup's 35-day locked vault with cross-region copy covers the RTO for an AZ or region loss. This is deliberately not five-nines: no Multi-AZ, no standby. Every phase from 3 onward re-runs the restore drill and records the time, so the RTO is always evidenced against the current schema and size.

### Backups

**Before Flip 2 (Phase 9):** `pg_dump --data-only -Fc` of the Supabase `public` schema on an encrypted volume, **never inside this repo** — 17,606 patient identifiers. **This dump is a working copy, not the archive.** It feeds `pg_restore` into RDS and makes the load re-runnable if it aborts; it is **shredded after the first close on AWS**, with the date in the log. It carries no custody table — two files with two different obligations were being described as one, and that is what made "the long-term archive" and "delete after verification" both look true.

**The long-term archive is the Phase 10 dump** (`docs/runbooks/decommission-supabase-render.md` step 2): the full `public` + `auth` + `storage` schemas, taken at decommissioning, uploaded to the Object-Locked `meridian-production-s3-archive` bucket on the **`phi`** CMK under a seven-year compliance lock. *That* is the only record of the gitignored seed data (`supabase_migrations/seeds/017_qb_provider_map.sql` exists on one laptop with real provider names), of `qgenda_workspaces` (P-4), of `auth.users`, and of the pre-migration database. Retained, not deleted: named custodian (Andres), written retention period, disposal procedure, all in Track C. It does **not** hold the storage objects' bytes — those live in the versioned `artifacts` and `phi` buckets, and the archive carries `storage.objects` as their index. Also archived: `config/mappings.xlsx`, the seeds, `legacy_users.json`. The Supabase project stays live and untouched for two full close cycles.

**After Flip 2:** RDS automated backups (7 days, PITR) + AWS Backup (35 days, cross-region copy, Vault Lock — built in Phase 3; the same credential that can delete the database must not be able to delete every recovery point); a restore drill every phase, quarterly after Phase 12, dated and written down; Object-Locked audit bucket.

### Dry runs and gates

- Two full rehearsals of Flip 2 on staging, the second timed and following the runbook literally.
- **The byte-for-byte JE diff is a gate, not a final check**: after the `database.py` port, after the `web_app.py` port, on staging in Phase 5a, per process in Phase 11, and in both Phase 9 rehearsals.
- The container-rendered invoice PDF is byte-compared against a Mac-rendered one.
- A forced task replacement mid-run (Phase 5a) and a killed worker mid-run (Phase 11) both leave nothing the results page needs unrecoverable.

### Parallel run and reconciliation

**Not a dual-write.** Two sources of truth for `import_batches.id` during a close is exactly the ambiguity migrations 024/026/028 were written to eliminate. Instead, **retrospective parallel verification**: re-run the last two *closed* periods on RDS and diff every artifact. Closed periods are immutable, so it is pure comparison. **First close on AWS:** before booking, `sum(debit), sum(credit)` for the new batch balance and match the run's tie-out; after booking, QuickBooks/NetSuite import totals match to the cent; all 45 sequences advanced; three JE lines spot-checked back to source transactions through `phi.transaction_identity`.

### The points of no return

| # | Moment | Before it | After it |
|---|---|---|---|
| **1** | **The first write on AWS** (Phase 9; strict, D-20) | DNS back to Render, ~5-10 min + TTL. Supabase holds every row. | Manual re-application of every divergent write per the runbook enumeration; for bookings, the affected `import_batches.id` values. |
| **2** | **`AUTH_BACKEND=cognito` in production** (Phase 4, Flip 1) | Config flip + redeploy. | **Still reversible** — `auth.users` is never mutated; Cognito users are copies. Reversibility ends at Phase 10's cut-off. |
| **3** | **Cancelling the Supabase project** (Phase 10) | Full rollback remains possible. | **Genuinely irreversible.** Not before two full close cycles on AWS. |

**Never cut over mid-close.** Periods are 4-5 weeks; pick the widest gap, a low-activity day, someone reachable by phone.

---

## 7. Calendar estimate

### Engineering days (cutover-first order, D-16)

| Phase | v2 equivalent | v2 | **v3.1** | Why it moved |
|---|---|---:|---:|---|
| 0 — Inventory, sweep, ADRs, harden in place | Stages 0 + 1 | 9-13 | **14-21** | +5-8: threat model, ADRs, data-flow diagram, repo layout, safety sweep, git reconcile |
| 1 — AWS foundation | Stage 0.1/0.2/0.6/0.7 + half of 4 | ~2-3 | **6-8** | +Security Hub/Inspector/Macie/Access Analyzer, OIDC CI with scanning, first CDK project |
| 2 — Network and IaC | rest of Stage 4 | ~1.5-2.5 | **4-6** | +second environment, CloudFront, prefix-list SGs |
| 3 — Data tier (staging) | Stage 3 + RDS/S3/Backup + Stage 6 + part of Stage 8 | 5-7 (+~5) | **14-20** | +RLS 3-5, +rehearsal load and checksums, +restore drill. **The pytest fixture is still the schedule risk** |
| 4 — Auth + Flip 1 | Stages 2 + 10 + 11 | 15.5-17.5 | **18-21** | +2-3: dual-token acceptance, migration % reporting, fail-closed, cut-off machinery |
| 5a — Data port, FastAPI beside Flask, containers, CI/CD | Stages 5 + 7 (minus IaC) | 29.5-37 | **37-49** | +10-15 FastAPI port of `/api/v2`; reuse of trial Dockerfiles |
| 5b — Jinja → React screens | — | 0 | **8-14** | new; smaller than the prompt's 10-18 because Wearbly is frozen (P-5) and signup dropped (P-6) |
| 6 — Observability and audit | scattered | ~1 | **4-6** | +alarms/dashboards/audit stream as a phase |
| 7 — Email | Stage 13.4 (deferred) | 0 | **1-2** | |
| 8 — Hardening, evidence, production deploy | Stage 8.6 + Track C overlap | ~1 | **6-10** | +control matrix, scans, DR test, pen-test prep |
| 9 — Cutover | Stages 8 + 9 | 5-7 | **5-7** | unchanged (diff procedure moved to Phase 3) |
| 10 — Decommission Supabase + Render | Stage 12 | 1-1.5 | **1.5-2.5** | +cut-off handling |
| **Dual maintenance, production support, decision latency** | | 8-13 | **8-13** | the two-backend window is Phase 5a → Phase 9, about v2's span; the platform-first order would have doubled it |
| **To cutover (0-10 + dual)** | | — | **~127-180** | |
| 11 — Process framework (on AWS) | Stage 13.2 (excluded, "multi-week") | 0 | **27-40** | new required work; LOW confidence |
| 12 — API platform, security, final cleanup | — | 0 | **28-44** (+3-5 mTLS if a partner exists) | new; LOW confidence |
| **Engineering subtotal** | | **80-105** | **~182-264** | |
| Track C — Compliance | | 20-25 | **20-25** | unchanged; fair *only* with a policy template set and an attorney review |
| **Total** | | **100-130** | **~200-290 working days** | |

**Confidence.** Phases 0-10 are re-priced from v2's surveyed numbers and are MEDIUM-HIGH. **Phases 11 and 12 are LOW-confidence**: nothing in the codebase was surveyed for them, they are greenfield, and the prompt's exit criteria (conformance suite, security suite, dynamic scan, two independent reviewers clean) are strict. Treat 27-40 and 28-44 as floors until the Phase 0 inventory refines them. The cutover-first order means those two uncertain phases no longer sit in front of the date that matters.

### Calendar

| Cadence | v2 (100-130 days) | **v3.1 to cutover (~127-180)** | **v3.1 whole programme (~200-290)** |
|---|---|---|---|
| Full-time, 5 focused days/week | 5-6 months | **6-8 months** | **9-13 months** |
| 3 focused days/week (running the business alongside) | 9-11 months | **10-14 months** | **15-22 months** |
| 2 focused days/week | do not attempt | do not attempt | do not attempt |

**Realistic answer at the most likely cadence: the first production journal entry booked on AWS around month 10-14, Supabase and Render gone around month 12-17, the platform complete around month 15-22.** Against v2's 9-11 months to the same cutover, the extra 1-3 months are the FastAPI port, RLS, the second environment, the security services and the React screens — all things the prompt requires before cutover. Against the prompt's own platform-first order (16-24 months to cutover), this is roughly six months sooner to leave Render and Supabase.

### Assumptions behind the number

1. Solo developer, still learning, macOS. No second pair of eyes on the SQL transcription — hence the JE diff as a repeated gate and RLS as the backstop.
2. The ephemeral-Postgres pytest fixture is the pivot; build it in Phase 3 before anything needs it.
3. **CDK in Python is new, as Terraform was.** Priced for a first CDK project.
4. **FastAPI is new to this codebase.** The port is priced as transcription of working Flask handlers into equivalent FastAPI ones with the same pydantic models, not a redesign.
5. No cutover during a close; budget one wasted close cycle.
6. The risk analysis is the single Track C item most likely to double.
7. **Excluded:** anything in §4's deferred table; a React Native client (designed for, not built).
8. **Recurring burden after cutover: 3-5 days per quarter** (up from v2's 2-4): patching three images, Postgres upgrades, Cognito policies, access reviews, log review, restore tests, risk-analysis updates, API client reviews, webhook DLQ triage.
9. **Nothing in §8's "confirm when convenient" list gates a phase** — every one has a provisional decision that is safe to act on.

---

## 8. Decisions

### Decided — premises of this plan

| # | Question | Decision | Reasoning | Consequence |
|---|---|---|---|---|
| D-01 | Replace the `CLAUDE.md` "all data in Supabase" rule? | **Yes** — text in §1. | A future session would silently steer work back to Supabase. | Applied locally in Phase 0 and recorded in tracked docs (`CLAUDE.md` is gitignored). |
| D-02 | New account or reuse <account-id>? | **Reuse, one account**, staging/prod split by VPC/IAM/KMS/tags, CDK split-ready. | BAA/SES/Identity Center once; the CDK makes a later split a redeploy. | Shared blast radius accepted; IAM triage is a Phase 3 precondition; tags are load-bearing. |
| D-03 | Signed BAA with Stella Mattina? | **Exists** — collect and file. | | Phase 0, Track C. |
| D-04 | Who accesses the system? | **Two people.** | | Track C written for two; MFA for both. |
| D-06 | Password migration | **Cognito User Migration Lambda; no forced reset; Supabase Auth stays until users migrate; cut-off at Phase 9 + 60 days.** | Nobody is forced to reset; the cost is one Lambda and a paid Supabase month or two. | Federated-only users pre-linked by hand; fail-closed on Supabase outage; migration % reported weekly. |
| D-07 | Infrastructure as code | **AWS CDK**, nothing clicked. | Prompt. | `cdk diff` in CI; tag Aspect. |
| D-08 | Backend | **FastAPI alongside Flask**, psycopg2 repository layer, Alembic. | Prompt. | Phase 5a; Flask removed in Phase 11. |
| D-09 | Database hosting | **RDS for PostgreSQL** is the system of record; the trial's self-hosted Supabase is a rehearsal artifact only. | Prompt; the trial has no managed backup, KMS or audit. | §2.6 harvest list; trial torn down by Phase 3. |
| D-10 | Tenant isolation | **Two layers**: explicit `org_id` + RLS via `app.org_id` under a non-superuser role. | Prompt; RLS backstops the one transcription risk v2 accepted bare. | +3-5 days; set on checkout / reset on return. |
| D-11 | Email | **SES replaces Resend** (Phase 7); verification starts Phase 1. | Prompt. | |
| D-12 | Edge | **CloudFront + WAF + Shield Standard** in front of the ALB; never Shield Advanced. | Prompt. | `ProxyFix(x_for=2)`, origin-verify header, prefix-list SG. |
| D-13 | Cognito timing | **Phase 4, before the data cutover**, with dual-token acceptance. | Prompt; `custom:app_uid` makes identity independent of where data lives. | Flip 1 precedes Flip 2; both stay independently reversible. |
| **D-14** | **RTO/RPO and Multi-AZ** | **RPO ≈ 1 hour, RTO ≈ 8 business hours. No Multi-AZ.** Single-AZ + 7-day PITR + 35-day locked AWS Backup with cross-region copy; restore drill every phase. | Andres: "we don't want to lose data but some is acceptable." PITR gives ~5-minute RPO, well inside 1 hour; a restore into another AZ fits 8 business hours. Not five-nines by design. | Saves ~$28/mo. Revisit if a real outage costs more than that, or if Stella Mattina states a tighter number. The contingency plan states these figures. |
| **D-15** | **Staging mode** | **Torn down between phases** (~$13/mo idle; ~$4/day while a session runs). | The only mode inside the ~$250/mo ceiling; also re-proves the CDK from scratch every session. | `data` stack persists with RDS stopped on a schedule; `network`/`compute` are destroyed and redeployed per session (~15 min). |
| **D-16** | **Phase order** | **Cutover first.** Process framework and API platform move after cutover (Phases 11-12). Phase 5 split into 5a (data port + FastAPI + containers) and 5b (Jinja → React). **This supersedes the prompt's phase order.** | Neither platform phase is needed to leave Render/Supabase; building them after cutover removes ~55-84 days from the dual-maintenance window and ~6 months from time-to-cutover. Splitting Phase 5 keeps each critic loop under ~50 days of work. | Cutover at ~127-180 engineering days (10-14 months at 3 d/wk) instead of ~190-280 (16-24). `desiredCount=1` persists until Phase 11 — the same shape as Render today. The prompt's PHASES section must be edited. |
| **D-18** | **Sandbox** | **A synthetic org inside staging. No third stack.** | $0 vs ~$125/mo; staging is already isolated from production. | Sandbox sessions are staging sessions; synthetic data seeded from the trial's generator. |
| **D-19** | **VPC endpoints** | **Free gateway endpoints (S3, DynamoDB) only. No interface endpoints.** | The NAT cannot be removed (Intuit, Google/Microsoft, the Lambda's target have no endpoint), so no interface endpoint beats NAT cost; the data-transfer saving is under $1/mo. Comparison in §2.4. | If an auditor asks for private-path assurance, add Secrets Manager + KMS + Logs in one AZ to production (~$22/mo) as a control. |
| **D-20** | **Point of no return for Flip 2** | **Strict: the first write of any kind on AWS.** | Rollback is then a clean DNS flip, trivially correct. Booking-based would require enumerating every writable table and prefix. | The Phase 9 smoke test is read-only; the runbook names its one deliberate write. |
| **D-21** | **Data-layer and IaC languages** | **No SQLAlchemy. psycopg2. CDK in Python.** | psycopg2 is already proven here with adapters that match PostgREST; one backend language and the existing venv for CDK; SQLAlchemy would hide the `org_id` predicate the lint reads. | Reopened only if a parity diff catches a mis-scoped transcription (§2.2). psycopg 3 deferred (§4). |
| **D-23** | **Branch base** | **Merge `andres-try` into `main`, then rebase `aws-migration` onto `main`.** Phase 0 step 1. | This branch lacks the QBO work and two migrations the prompt describes. | Everything after Phase 0 assumes 37 migrations and `src/qbo_client.py` present. |
| **D-24** | `local_plugins.EXTRA_PROCESSES` | **Unverified-local; not a dependency.** Already removed from the prompt. | It is in no tracked branch. | If it exists on the laptop, fold it into the Phase 11 manifest; otherwise ignore. |
| **D-25** | `/api/v1` retirement | **Phase 12, once `/api/v3` covers it.** `/api/v1/health` keeps working until then. | It is the live health-check path for Render, the ALB and CloudFront. | The health check moves to `/api/v3/health` in the same Phase 12 commit that retires v1. |

### Provisional decisions — safe defaults for business facts nobody has confirmed

Each is the conservative choice that loses nothing and needs no answer to act on. The **trigger** is what would change it. **None of these blocks a phase.**

| # | Question | Provisional decision | Why it is safe | Trigger to change it |
|---|---|---|---|---|
| **P-1** | Is raw `patient_id` needed anywhere? | **No — `patient_ref` (the keyed hash) is what the application uses; raw values live only in `phi.transaction_identity`.** Nothing is dropped. | The only reachable use is duplicate detection, which works on the hash; the raw value is retained and audited. | Someone needs the raw id in a screen → a `phi:read`-gated detail view, no data change. |
| **P-2** | Does anyone use the `Patient Acct No` workbook column? | **Default export is tokenized; the raw column exists only in a permission-gated "detail export" written to the `phi` bucket.** | The column still exists for whoever needs it; the default stops spreading identifiers into every workbook. | An accountant reports needing it → grant the permission to that role; no code change. |
| **P-3** | Does anyone read `source_transactions`? | **Keep it; move it to `phi.source_transactions` as planned.** Do not stop persisting yet. | Nothing lost; exposure reduced by the schema boundary. | Confirmation that nobody reads it → the §4 deferred item (stop persisting, ~1 day, ~85% less stored PHI). |
| **P-4** | Does `qgenda_workspaces` belong to Meridian? | **Excluded from the RDS load; kept in the retained Supabase archive.** | The prompt lists `qgenda/` as another product; its policies are fully open, so carrying it is a liability; the archive means it is recoverable. | Someone in Meridian needs it → restore from the archive as a new Alembic revision. |
| **P-5** | Wearbly: move, stay, or retire? | **Freeze.** The four `uniform_*` tables travel with the data; the Jinja screen and the never-worked receipts upload are retired; no React screen is built. | No data lost (1 row in `uniform_orders`); the broken upload path stops lying about where PDFs are. | Andres wants Wearbly active → build it as a framework process in Phase 11 (§4). |
| **P-6** | Public `/signup` or invite-only? | **Invite-only** via invite codes + `AdminCreateUser`. | All 17 pending invites already gate membership at `org_members`; a public signup on a PHI system is exposure with no current user. | A real need for self-serve signup → a Cognito `SignUp` flow behind an org-level flag, one screen. |
| **P-7** | Which of the 14 `auth.users` are real? | **Treat all 14 as real.** All go into `legacy_users.json`; the Lambda migrates whoever signs in; the 9 org-less users cost nothing if they never do. | No account is dropped by assumption. | Andres names disposable accounts → they are simply not pre-created and lapse at the cut-off. |
| **P-8** | Are Google and Microsoft sign-in needed? | **Both stay.** | The only superadmin is Microsoft-only and one member is Google-only; dropping either locks a real person out. | P-7's answer shows the Google-only member is disposable → drop the Google IdP (saves nothing material). |
| **P-9** | Render / Supabase HIPAA quotes in writing | **Proceed without them; request them in Phase 0.** | The migration is forced by PHI-in-scope and by the platform goals, not by the size of the saving; the quotes only sharpen §5's comparison. | Quotes arrive → update §5. Nothing else changes. |
| **P-10** | What is in RDS `meridian-postgres`? | **Do not touch it, do not restore its snapshot, do not inspect it.** Treat it as another owner's. | It is PG 16.13 and unusable for us anyway; restoring another owner's snapshot is exactly the kind of cross-app action §1 forbids. Saves a day. | The owner is identified and says it is Meridian's → inspect then. |

### Confirm when convenient — never blocking

For Andres, in one sitting, whenever there is time. Each maps to a provisional decision above.

1. Does anyone need raw patient account numbers in a screen or export? (P-1, P-2)
2. Does anyone read the raw billing rows (`source_transactions`)? (P-3)
3. Is `qgenda_workspaces` Meridian's? (P-4)
4. Is Wearbly coming back? (P-5)
5. Will anyone ever need to sign up without an invite? (P-6)
6. Which of the 14 accounts can lapse, and does anyone real sign in with Google? (P-7, P-8)
7. The Render and Supabase HIPAA quotes, in writing. (P-9)
8. Who owns `meridian-postgres` and the `ai.meridiansgrp.com` stack? (P-10)
9. Does Stella Mattina want a tighter recovery target than 8 business hours / 1 hour? (D-14 — the only one that changes cost: +$28/mo)

---

## 9. Changed from v2

| Change | Why |
|---|---|
| **Phase numbering 0-12 replaces Stages 0-13 + Track C; cutover-first order (D-16)** | The prompt's phases are what the executing session follows; the mapping tables in §3 show where each v2 stage and each prompt phase went. Track C stays parallel and feeds Phase 8. |
| **Terraform → AWS CDK in Python** | Prompt requirement (D-07, D-21). Effort comparable for one environment; the second environment and the tag Aspect add ~2-3 days. |
| **One environment → staging + production in one account, staging torn down between phases** | Prompt requirement + D-15. ~$13/mo idle; the only mode inside the ceiling. |
| **Flask + `src/pg.py` → FastAPI alongside Flask, psycopg2 repository layer, Alembic** | Prompt requirement (D-08). The port's *content* is v2's Stage 5 unchanged; the FastAPI layer adds 10-15 days; Alembic replaces v2's hand-edited baseline with a three-revision chain that keeps the 37 files unrewritten **and** reconciles the drift v2 found. |
| **RLS dropped → RLS reinstated via `app.org_id`** | Prompt requirement (D-10). +3-5 days. Set on checkout / reset on return. |
| **Cognito at Cutover B (late) → Phase 4 (early), dual-token; flips reordered** | Prompt requirement (D-13). Flip 1 = auth, Flip 2 = data. Lambda caveats unchanged and now decided (D-06). |
| **ALB-only → CloudFront + WAF + Shield Standard** | Prompt requirement (D-12). `ProxyFix(x_for=2)` mandatory. |
| **Resend kept → SES replaces Resend (Phase 7)** | Prompt requirement (D-11). |
| **Single-AZ decided, RTO/RPO decided** | D-14. v2 carried these as an assumption flagged for Stella Mattina; now a recorded target with a trigger. |
| **Wizards → `RunStore` excluded ("multi-week") → required (Phase 11, after cutover)** | The prompt separates api and worker containers. Largest single scope addition (+10-15 days inside Phase 11's 27-40) — now built on AWS with no second backend. |
| **New: process framework, `/api/v3`, API security programme, observability phase, tidiness rules, control matrix, ADRs, runbooks, migration tracker, phase completion loop with two reviewers** | Prompt requirements absent from v2. +60-100 days, after cutover. |
| **Self-hosted Supabase trial stack: classified as a rehearsal artifact with a harvest list and a Phase 3 tear-down** | D-09. |
| **`CLAUDE.md` rule delivery** | `CLAUDE.md` is gitignored → updated locally and recorded in tracked docs. |
| **"No bastion" reconciled; VPC endpoints decided (gateway only)** | D-19 with the NAT comparison. |
| **v2's ten open questions → ten provisional decisions with triggers (P-1..P-10) and a non-blocking confirm list** | Andres wants defaults, not a questionnaire. Each default keeps the data and takes the safer option. |
| **Live counts refreshed** | 188 `.table(` sites (v2: 172), 48 test files (37), 94 policies in 19 files (65), 35 migrations on `main` / 37 on `andres-try` (29). |
| **Engineering days 80-105 → ~182-264 (to cutover ~127-180); total 100-130 → ~200-290; calendar at 3 days/week to cutover 9-11 → 10-14 months, whole programme 15-22** | The sum of the above, with the cutover-first order keeping the uncertain phases off the cutover path. |
| **Monthly cost $170-206 → ~$238 (production ~$225 single-AZ + staging ~$13 idle)** | Worker + web services, four extra security services, second environment; Multi-AZ not bought. |
| **Sequences, PoNRs, JE-diff gate, dual-maintenance rule, `phi` schema, `custom:app_uid`, off-limits inventory, Track C** | **Unchanged** — they survived two reviews and nothing in the prompt contradicts them. |

---

## One last honest note

v2 ended with a warning that the compliance track would be deferred because it is less satisfying than engineering. That warning stands. v3 adds a second one: **the prompt describes a platform, and a platform is two to three times the work of a migration.** The cutover-first order (D-16) is the answer to that: Phases 0-10 get Meridian off Render and Supabase in the shortest safe path, and Phases 11-12 — the reason to be on AWS rather than anywhere else, and the least certain estimates in this document — are built afterwards on solid ground. The cost headroom is thin (~$12/mo) and the two LOW-confidence security-service lines could eat it; Phase 1's estimate is where that gets settled. Run Track C in parallel, keep staging torn down, re-run the restore drill every phase — or do not start.
