# Pending Questions — what this folder is

Some things the payroll system does can't be decided by code alone. They need a
person to answer a question first — usually the accountant, sometimes ADP.

Each file in this folder is **one question**, written so anyone can read it
without knowing the code. A question stays here until it's answered. When it's
answered, the answer gets written into the file and the code gets changed to
match, and then the file can be archived.

**Why bother writing them down?** Because these questions come back every month.
If the answer only lives in someone's head, we re-decide it every time — and
sooner or later we decide it differently.

## Open questions right now

| Question | Why it matters | Deadline |
|---|---|---|
| [Benefit overrides — why are they changed by hand?](benefit-overrides-why-changed-by-hand.md) | 7 premiums a month get corrected by hand. Until we know why, we can't automate it. | None, but it repeats monthly |
| [October 2026 — three paydays breaks the payroll run](october-2026-three-paydays.md) | The October close will stop with an error. | October 2026 |

## How to write a new one

Keep it to five parts:

1. **What's happening** — in plain words, no code
2. **Why it matters** — what goes wrong if nobody answers
3. **The question** — one sentence, ending in a question mark
4. **What changes based on the answer** — the possible answers and what each one
   means we'd do
5. **Where to look** — the file or screen someone would check

**This folder is in GitHub.** Never put employee names, bank details, or dollar
amounts tied to a person in these files. Say "seven people", not who.
