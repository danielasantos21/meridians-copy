# Benefit overrides — why are they changed by hand?

Found 2026-08-24. No deadline, but it comes back every single month.

## What's happening

Every month, UNUM and BCBS send a bill for employee benefits. The system reads
that bill and works out how much of it belongs to each employee.

Then someone opens a file on their laptop and changes some of the numbers.

For July 2026 there were **17 changes**:

- **10 of them set a premium to zero.** These are people who left the company
  but the carrier is still billing for them.
- **7 of them replace one dollar amount with a different dollar amount.**

Nobody has written down why those 7 were changed.

## Why it matters

Three reasons.

**1. It's the reason a check keeps failing.** The system has a check (we call it
"G5") that adds up all the individual premiums and compares them to the
carrier's own total. It's supposed to come out to zero. It doesn't, and these
hand-changes are the biggest reason. So every month someone has to look at a red
warning and decide it's fine — which means the warning has stopped being useful.

**2. It only works on one laptop.** The changes live in a file
(`config/ts_benefit_overrides.local.json`) on one computer. It isn't backed up
and it isn't in the app. If that laptop dies, the July close can't be reproduced.

**3. We can't automate it until we know the reason.** If the 7 changes are
fixing a mistake the system is making, we should fix the system and the changes
disappear forever. If they're new information from the carrier, the system needs
somewhere to put that information. We can't tell which without asking.

## The question

**For the 7 premiums you correct by hand each month — what are you correcting?**

## What changes based on the answer

| If the answer is… | Then we… |
|---|---|
| "The system picked the wrong premium for that person" | Fix how it matches people to the bill. The hand-changes stop entirely. |
| "The carrier changed someone's coverage mid-month and it's on the bill" | Teach the system to read that part of the bill. Hand-changes stop. |
| "I agreed a correction with the carrier over the phone" | Can't be automated — but it should be typed into a screen in the app, not a file. The system would then know it was deliberate and stop flagging it. |
| "I honestly don't remember, it's just how we've always done it" | Worth pausing the practice for one month and seeing what breaks. |

It may be a mix. That's fine — we just need to know which is which.

## A separate, easier one

The same file has a list of people whose premiums get spread across everyone
else when they've left. **That list exists for BCBS but was never filled in for
UNUM.** That looks like something someone simply forgot, not a decision — but
worth confirming before adding it, because it moves real money between the two
companies.

## Where to look

- The file: `config/ts_benefit_overrides.local.json` — **not in GitHub.** It has
  real employee names in it and is deliberately gitignored.
- The explanation of the failing check:
  [`docs/processes/qb-usa-payroll-gates-explained.md`](../processes/qb-usa-payroll-gates-explained.md),
  the section on G5.
