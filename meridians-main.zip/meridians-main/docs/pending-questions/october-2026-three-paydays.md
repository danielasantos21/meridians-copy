# October 2026 — three paydays will stop the run

**Deadline: the October 2026 close.** Found 2026-08-24.

## What's happening

Pay goes out every two weeks. That's 26 paychecks a year spread over 12 months —
so **twice a year, a month contains three paydays instead of two.**

The payroll process refuses to run any month that doesn't have exactly two. Give
it three and it stops with an error and produces no journal entries at all.

| Month | Paydays |
|---|---|
| **Oct 2026** | Oct 2, 16, **30** |
| Apr 2027 | Apr 2, 16, **30** |
| Oct 2027 | Oct 1, 15, **29** |
| Mar 2028 | Mar 3, 17, **31** |
| Sep 2028 | Sep 1, 15, **29** |

## Why it refuses instead of coping

This isn't a bug — it's an unanswered business question.

Benefit bills are tied to the pay run **number**. UNUM bills two coverage months
at once and gets booked entirely on run 1. BCBS books its own coverage month on
run 2. With a third run, there's no defined answer for what happens — so the
code stops rather than quietly booking a premium twice or dropping one.

Refusing beats guessing. But it still means the close stops.

## The question

**In a month with three paydays, does the third pay run carry any benefit bill?**

## What changes based on the answer

| If the answer is… | Then we… |
|---|---|
| "No — the carriers bill monthly, not per payday" (most likely) | Change the rule to "UNUM on run 1, BCBS on run 2, no carrier premiums on any later run." Small fix, error goes away. |
| "Yes, sometimes" | Need to know how it's decided before writing any code. |

Confirm with the accountant before changing it.

## Check in the same pass

- **Accrual dating.** The accrual is currently dated the day *after* the last
  payday, not the last day of the month. April 2027's last payday is the 30th,
  so that month's accrual would land in **May** — wrong month on both sides. It
  should be the calendar month end.
- The carrier-per-run lookup itself. An unmapped run number is currently a hard
  error by design.

## Where to look

- `src/qb_usa_payroll_processor.py` — `RUN_CARRIERS`, `EXPECTED_RUNS`,
  `pay_dates_in_month`, `PAY_DATE_ANCHOR`
- `PAY_DATE_ANCHOR` (= 2026-07-24) is what generates the table above. Changing
  payroll provider or pay frequency means changing that anchor; nothing else
  reads it.
