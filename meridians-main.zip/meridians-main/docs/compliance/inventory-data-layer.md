# Data-layer inventory — Meridian → AWS migration (Phase 0)

What this is: a fact-check of the database layer as the repository actually
describes it today, written so Phase 3 (the Alembic baseline) has something to
diff against. Every number below comes from a file in this repo on branch
`aws-migration`, cited as `path:line`. Where the migration plan
(`docs/aws-migration-plan.md`) states a different number, both are shown.

Jargon, defined once:

- **Migration file** — a `.sql` script that changes the database's shape. The
  set of them, replayed in order, is supposed to reproduce the database.
- **RLS (row-level security)** — a Postgres feature that filters the rows a
  query can see, inside the database, regardless of what the application asks
  for. A **policy** is one such filter rule.
- **Predicate** — the boolean condition in a policy (`USING (...)`). `USING`
  controls which existing rows you can see; `WITH CHECK` controls which rows
  you are allowed to write.
- **Drift** — the live database and the migration files disagreeing.
- **Sequence** — the hidden counter behind a `SERIAL` / `BIGSERIAL` id column.
- **Generated column** — a column Postgres computes from other columns; you
  cannot write to it.

Scope note: this inventory reads files only. Nothing here was checked against
the live Supabase database, so every "live" statement is repeated from the plan
and marked as unverified.

---

## 1. Tables

37 files in `supabase_migrations/migrations/`. They declare **63 distinct
tables** in `public`, all created by 18 of the 37 files; the other 19 files are
`ALTER`s, constraint fixes and seed data.

Two files share the prefix `013` — `013_not_null_org_id_unique_constraints.sql`
and `013_wearbly_uniforms.sql`. Filename order (what both migration runners
use) puts `013_not_null...` before `013_wearbly...`, and neither depends on the
other, so today the ambiguity is harmless. It is still a numbering collision an
Alembic chain must resolve explicitly.

**PHI classification** uses the definition given for this task: PHI = patient
identifiers, service dates, claim numbers, employee DOB/SSN/insurance ids, or
raw billing rows. Nothing else is PHI. No table in the migrations is readable
without authentication, so nothing is classified `public`.

| Table | Created by | `org_id`? | `auth.users` FK? | Class |
|---|---|---|---|---|
| `organizations` | `001_organizations.sql:2` | n/a (is the org) | no | internal |
| `org_members` | `001_organizations.sql:12` | yes | yes (`user_id`, `invited_by`) | internal |
| `import_batches` | `002_processing_tables.sql:10` | yes | yes (`created_by`) | internal |
| `transactions` | `002_processing_tables.sql:34` | yes | no | **phi** |
| `journal_entries` | `002_processing_tables.sql:68` | yes | no | internal |
| `unmapped_items` | `002_processing_tables.sql:91` | yes | no | internal |
| `payroll_employees` | `002_processing_tables.sql:107` | yes | no | internal (named employees + wage amounts) |
| `employee_clinic_allocations` | `002_processing_tables.sql:135` | yes | no | internal (named employees) |
| `uploads` | `002_processing_tables.sql:155` | yes | yes (`created_by`) | internal |
| `source_transactions` | `002_processing_tables.sql:177` | yes | no | **phi** (`raw_data` = raw billing rows) |
| `processing_runs` | `002_processing_tables.sql:196` | yes | no | internal |
| `processed_entries` | `002_processing_tables.sql:217` | yes | no | internal |
| `config_providers` | `002_processing_tables.sql:242` (re-declared `023_config_mappings.sql:29`) | yes | yes (`updated_by`) in 002; **no** in 023 | internal |
| `config_locations` | `002_processing_tables.sql:259` (re-declared `023_config_mappings.sql:64`) | yes | yes in 002; **no** in 023 | internal |
| `config_payers` | `002_processing_tables.sql:277` (re-declared `023_config_mappings.sql:100`) | yes | yes in 002; **no** in 023 | internal |
| `config_employees` | `002_processing_tables.sql:295` | yes | yes (`updated_by`) | internal (named employees) |
| `config_history` | `002_processing_tables.sql:314` | yes | yes (`changed_by`) | internal |
| `config_mso_mappings` | `002_processing_tables.sql:330` | yes | no | internal |
| `config_fiscal_calendar` | `002_processing_tables.sql:346` | yes | no | internal |
| `config_clinic_groups` | `002_processing_tables.sql:360` | yes | no | internal |
| `config_settings` | `002_processing_tables.sql:373` | yes | no | internal |
| `config_account_codes` | `002_processing_tables.sql:385` | yes | no | internal |
| `roles` | `004_roles_permissions.sql:2` | yes | no | internal |
| `role_permissions` | `004_roles_permissions.sql:14` | **no** (joins via `roles.org_id`) | no | internal |
| `config_mx_employees` | `005_mx_employees.sql:4` | yes | yes (`updated_by`) | internal (named employees) |
| `payroll_column_account_map` | `007_payroll_column_account_map.sql:1` | yes | no | internal |
| `mx_payroll_column_map` | `008_mx_payroll_column_map.sql:5` | yes | no | internal |
| `bkv5_location_remap` | `011_bkv5_location_remap.sql:17`; `org_id` added by `012_bkv5_location_remap_rls.sql:23` | yes (only after 012) | no | internal |
| `uniform_catalog` | `013_wearbly_uniforms.sql:16` | yes | no | internal (Wearbly, not Meridian) |
| `uniform_size_mappings` | `013_wearbly_uniforms.sql:48` | yes | no | internal (Wearbly) |
| `uniform_orders` | `013_wearbly_uniforms.sql:82` | yes | no | internal (Wearbly) |
| `uniform_order_items` | `013_wearbly_uniforms.sql:115` | yes | no | internal (Wearbly; `employee_name`) |
| `uniform_column_mappings` | `013_wearbly_uniforms.sql:152` | yes | no | internal (Wearbly) |
| `invite_codes` | `015_document_unmigrated_tables.sql:16` | yes (nullable) | yes (`created_by`, `used_by`) | internal |
| `org_modules` | `015_document_unmigrated_tables.sql:50` | yes | no | internal |
| `superadmins` | `015_document_unmigrated_tables.sql:76` | **no** | yes (`user_id` PK) | internal |
| `clients` | `015_document_unmigrated_tables.sql:109`; `org_id` also added by `014_...:11` | yes (nullable) | no | internal |
| `invoices` | `015_document_unmigrated_tables.sql:140` | yes (nullable) | yes (`created_by`) | internal |
| `qb_account_map` | `017_qb_mapping_tables.sql:8` | yes | no | internal |
| `qb_department_map` | `017_qb_mapping_tables.sql:30` | yes | no | internal |
| `qb_location_map` | `017_qb_mapping_tables.sql:49` | yes | no | internal |
| `qb_clinic_map` | `017_qb_mapping_tables.sql:68` | yes | no | internal |
| `qb_provider_map` | `017_qb_mapping_tables.sql:88` (+ `start_date`/`end_date` in `034_pnl_provider_dates.sql:35`) | yes | no | internal (named clinicians + employment dates) |
| `qb_other_code_map` | `017_qb_mapping_tables.sql:107` | yes | no | internal |
| `qb_payer_label_map` | `017_qb_mapping_tables.sql:126` | yes | no | internal |
| `ts_benefit_override` | `019_totalsource_benefit_overrides.sql:38` (+ `036_...:20`) | yes | no | internal — **review** (named employees against carrier benefit amounts) |
| `qb_usa_location_rule` | `020_qb_usa_payroll_roster.sql:30` | yes | no | internal |
| `qb_usa_department_rule` | `020_qb_usa_payroll_roster.sql:52` | yes | no | internal |
| `qb_usa_coding_exception` | `020_qb_usa_payroll_roster.sql:79` | yes | no | internal |
| `qb_usa_employee` | `020_qb_usa_payroll_roster.sql:120` | yes | no | internal (named employees) |
| `qb_usa_payroll_journal` | `021_qb_usa_payroll_runs.sql:40` | yes | no | internal |
| `qb_usa_payroll_gate` | `021_qb_usa_payroll_runs.sql:72` | yes | no | internal |
| `process_runs` | `022_process_runs.sql:56` | yes | no (`created_by UUID`, no FK) | internal |
| `artifact_downloads` | `022_process_runs.sql:107` | yes | no (`user_id UUID`, no FK) | internal |
| `config_departments` | `023_config_mappings.sql:129` | yes | no | internal |
| `qb_export_tie_out` | `025_qb_export_tie_out.sql:32` | yes | no | internal |
| `pnl_configs` | `031_pnl_provider_schema.sql:56` | yes | no | internal |
| `pnl_cost_batches` | `031_pnl_provider_schema.sql:78` | yes | no | internal |
| `pnl_cost_lines` | `031_pnl_provider_schema.sql:102` | yes | no | internal |
| `pnl_driver_batches` | `031_pnl_provider_schema.sql:134` | yes | no | internal |
| `pnl_driver_values` | `031_pnl_provider_schema.sql:157` | yes | no | internal |
| `pnl_account_drivers` | `031_pnl_provider_schema.sql:183` | yes | no | internal |
| `qbo_connection` | `035_qbo_connection.sql:25` | yes | no (`connected_by UUID`, no FK) | internal — holds live OAuth access/refresh tokens |

Three tables have no `org_id` column: `organizations` (it *is* the org),
`role_permissions` (scoped through `roles.org_id`) and `superadmins`
(deliberately global; `015_...:81` records that it has no RLS either, because
it is only ever read with the service-role key).

### Live-only tables (no migration file creates them)

Verified by `grep -rn <name> supabase_migrations/`:

| Table | Result |
|---|---|
| `fiscal_calendar` | **Confirmed live-only.** The only occurrence is a *commented-out* `CREATE TABLE` at `015_document_unmigrated_tables.sql:93-101`, whose prose says "This table does NOT exist in Supabase". The plan says it does exist live with 6,209 rows and is load-bearing for JE dates — so the comment in 015 is itself wrong and must not be trusted as the record. |
| `qgenda_workspaces` | **Confirmed live-only.** Zero occurrences anywhere in `supabase_migrations/`. |
| `trial_migrations` | **Confirmed not created by any migration file**, but not un-owned: `deploy/aws-trial/apply_migrations.py` creates it as its own bookkeeping ledger (see §6). It is an artifact of the trial stack, not of Meridian's schema. |
| `payroll_column_account_map` | **Not live-only — the plan is right to ask, and the answer is no.** `007_payroll_column_account_map.sql:1` creates it, indexes it (`:13`), enables RLS (`:16`) and adds a policy (`:18`). |

### Table-count discrepancy

The plan's Phase 3 step 11 says the parity suite covers "all 57 tables". The
migration files declare **63**. One of three things is true and Phase 3 must
say which: some declared tables were never applied live (the Wearbly `uniform_*`
five and `config_departments` are the obvious candidates), the 57 is stale, or
the 57 excluded something. Unverified here — no live access.

---

## 2. RLS policies and functions

### Counts

`CREATE POLICY` appears **95 times across 20 files**. The plan says "94 across
19 migration files"; both numbers are off by one. The likely cause of the
file-count difference is `003_storage_buckets.sql`, whose 2 policies are on
`storage.objects` (a Supabase-managed table), not on a `public` table:

- **93 policies across 19 files** on `public.*` tables.
- **2 policies in 1 file** (`003_storage_buckets.sql`) on `storage.objects`.
- **95 / 20 total.**

| File | Policies |
|---|---|
| `001_organizations.sql` | 6 |
| `002_processing_tables.sql` | 20 |
| `003_storage_buckets.sql` | 2 (on `storage.objects`) |
| `004_roles_permissions.sql` | 4 |
| `005_mx_employees.sql` | 1 |
| `007_payroll_column_account_map.sql` | 1 |
| `008_mx_payroll_column_map.sql` | 1 |
| `012_bkv5_location_remap_rls.sql` | 1 |
| `013_wearbly_uniforms.sql` | 5 |
| `014_rls_with_check_user_org_id_fix.sql` | 22 |
| `015_document_unmigrated_tables.sql` | 4 |
| `017_qb_mapping_tables.sql` | 7 |
| `019_totalsource_benefit_overrides.sql` | 1 |
| `020_qb_usa_payroll_roster.sql` | 4 |
| `021_qb_usa_payroll_runs.sql` | 2 |
| `022_process_runs.sql` | 2 |
| `023_config_mappings.sql` | 4 |
| `025_qb_export_tie_out.sql` | 1 |
| `031_pnl_provider_schema.sql` | 6 |
| `035_qbo_connection.sql` | 1 |

**95 is not the live policy count.** `014` drops and re-creates 20 of `002`'s
policies (to add the missing `WITH CHECK`) and creates 2 new ones; `015`
re-creates `clients`/`invoices` policies that `014` already made; `023`
re-creates `config_providers`/`config_locations`/`config_payers`. Counting
distinct `(table, policy name)` pairs gives roughly **68** live policies. Phase 3
should take the real number from `pg_policies`, not from this file count.

### Policy table

Grouped, because the pattern repeats verbatim. "Function used" names the thing
the predicate depends on, which is what revision 0003 has to replace.

| Policy name | Table(s) | Command | Predicate (one line) | Function used |
|---|---|---|---|---|
| `Members can view their organization` | `organizations` | SELECT | `id IN (SELECT org_id FROM org_members WHERE user_id = auth.uid())` | `auth.uid()` |
| `Admins can update their organization` | `organizations` | UPDATE | same, `AND role = 'admin'` | `auth.uid()` |
| `Authenticated users can create organizations` | `organizations` | INSERT | `WITH CHECK (auth.uid() IS NOT NULL)` | `auth.uid()` |
| `Members can view org members` | `org_members` | SELECT | `org_id IN (SELECT org_id FROM org_members WHERE user_id = auth.uid())` | `auth.uid()` |
| `Admins can manage org members` | `org_members` | ALL | same, `AND role = 'admin'` | `auth.uid()` |
| `Users can join organizations` | `org_members` | INSERT | `WITH CHECK (user_id = auth.uid())` | `auth.uid()` |
| `org_isolation` (×20) | the 20 tables of `002` | ALL | `USING (org_id = public.user_org_id())` — **no `WITH CHECK`** | `user_org_id()` |
| `Org members can access their uploads` | `storage.objects` | ALL | `bucket_id IN ('uploads','outputs') AND (storage.foldername(name))[1] IN (SELECT org_id::TEXT FROM org_members WHERE user_id = auth.uid())` | `auth.uid()` |
| `Authenticated users can read templates` | `storage.objects` | SELECT | `bucket_id = 'templates' AND auth.uid() IS NOT NULL` | `auth.uid()` |
| `Members can view roles` | `roles` | SELECT | `org_id IN (SELECT org_id FROM org_members WHERE user_id = auth.uid())` | `auth.uid()` |
| `Admins can manage roles` | `roles` | ALL | same, `AND role = 'admin'` | `auth.uid()` |
| `Members can view role permissions` | `role_permissions` | SELECT | `role_id IN (SELECT id FROM roles WHERE org_id IN (SELECT org_id FROM org_members WHERE user_id = auth.uid()))` | `auth.uid()` |
| `Admins can manage role permissions` | `role_permissions` | ALL | same, `AND role = 'admin'` | `auth.uid()` |
| `org_isolation_mx_employees` | `config_mx_employees` | ALL (default) | `USING (org_id = (SELECT org_id FROM org_members WHERE user_id = auth.uid() LIMIT 1))` — inlines `user_org_id()`'s body instead of calling it, and is the one policy that is **not** deterministic (no `ORDER BY`) | `auth.uid()` |
| `org_isolation` | `payroll_column_account_map` | ALL | `USING (org_id = public.user_org_id())`, no `WITH CHECK` | `user_org_id()` |
| `org_isolation` | `mx_payroll_column_map` | ALL | `USING (org_id = public.user_org_id())`, no `WITH CHECK` | `user_org_id()` |
| `bkv5_location_remap_org_isolation` | `bkv5_location_remap` | ALL | `USING / WITH CHECK (org_id = user_org_id())` | `user_org_id()` |
| `uniform_*_org_isolation` (×5) | the 5 `uniform_*` tables | ALL | `USING / WITH CHECK (org_id = user_org_id())` | `user_org_id()` |
| `org_isolation` (×22) | `clients`, `invoices` + the 20 tables of `002`, re-created | ALL | `USING / WITH CHECK (org_id = public.user_org_id())` | `user_org_id()` |
| `Admins can manage invite codes` | `invite_codes` | ALL | `org_id IN (SELECT org_id FROM org_members WHERE user_id = auth.uid() AND role = 'admin')`, both clauses | `auth.uid()` |
| `Members can view org modules` | `org_modules` | SELECT | `org_id IN (SELECT org_id FROM org_members WHERE user_id = auth.uid())` | `auth.uid()` |
| `org_isolation` (×2) | `clients`, `invoices` (again, in `015`) | ALL | `org_id IN (SELECT org_id FROM org_members WHERE user_id = auth.uid())`, both clauses | `auth.uid()` |
| `qb_*_map_org_isolation` (×7) | the 7 `qb_*_map` tables | ALL | `USING / WITH CHECK (org_id = user_org_id())` | `user_org_id()` |
| `ts_benefit_override_org_isolation` | `ts_benefit_override` | ALL | `USING / WITH CHECK (org_id = user_org_id())` | `user_org_id()` |
| `qb_usa_*_org_isolation` (×4) | the 4 `qb_usa_*` roster tables | ALL | `USING / WITH CHECK (org_id = user_org_id())` | `user_org_id()` |
| `qb_usa_payroll_journal_org_isolation`, `qb_usa_payroll_gate_org_isolation` | those 2 tables | ALL | `USING / WITH CHECK (org_id = user_org_id())` | `user_org_id()` |
| `process_runs_org_isolation`, `artifact_downloads_org_isolation` | those 2 tables | ALL | `USING / WITH CHECK (org_id = user_org_id())` | `user_org_id()` |
| `org_isolation` (×4) | `config_providers`, `config_locations`, `config_payers`, `config_departments` | ALL | `USING / WITH CHECK (org_id = user_org_id())` | `user_org_id()` |
| `qb_export_tie_out_org_isolation` | `qb_export_tie_out` | ALL | `USING / WITH CHECK (org_id = user_org_id())` | `user_org_id()` |
| `org_isolation` (×6) | the 6 `pnl_*` tables | ALL | `USING / WITH CHECK (org_id = public.user_org_id())` | `user_org_id()` |
| `qbo_connection_org_isolation` | `qbo_connection` | ALL | `USING / WITH CHECK (org_id = public.user_org_id())` | `user_org_id()` |

No policy in any migration file contains a superadmin check.

### Functions defined in the migrations

Exactly **one function**, defined twice:

| Function | Defined at | Body | Reads |
|---|---|---|---|
| `public.user_org_id()` → `UUID` | `002_processing_tables.sql:424` | `SELECT org_id FROM public.org_members WHERE user_id = auth.uid() LIMIT 1` | `auth.uid()` |
| `public.user_org_id()` → `UUID` (replacement) | `014_rls_with_check_user_org_id_fix.sql:189` | same + `ORDER BY joined_at ASC NULLS LAST` before `LIMIT 1` | `auth.uid()` |

Both are `LANGUAGE sql SECURITY DEFINER STABLE`. Neither reads a JWT claim
directly: they read `auth.uid()`, which is Supabase's own function returning the
`sub` claim of the request's JWT (JSON Web Token — the signed blob the browser
sends as proof of who it is). So the JWT dependency is real but one level
removed, through `auth.uid()`, and `auth.uid()` appears in **24 policies**
directly plus inside `user_org_id()`. Revision 0003 must replace both.

**`is_superadmin()` does not exist in SQL.** It is a Python function,
`src/auth.py:838`, which queries `public.superadmins` with the service-role key
(which bypasses RLS entirely). There is no database-side superadmin bypass to
port — there is an application-side one to *replace*, which matters more: under
RDS there is no service-role key, so `is_superadmin` needs a named,
audit-writing bypass function of its own (the plan's §2.2 requirement).

---

## 3. Sequences and generated columns

### Sequences

Every sequence is implicit — created by a `SERIAL` / `BIGSERIAL` column. There
is no explicit `CREATE SEQUENCE` and no `GENERATED … AS IDENTITY` column
anywhere in the 37 files (verified by grep).

**55 `SERIAL`/`BIGSERIAL` columns are declared**, all named `id`, all the
primary key of their table:

| File | Count | Type |
|---|---|---|
| `002_processing_tables.sql` | 20 | `SERIAL` (one per table) |
| `005_mx_employees.sql:5` | 1 | `SERIAL` |
| `007_payroll_column_account_map.sql:2` | 1 | `SERIAL` |
| `008_mx_payroll_column_map.sql:6` | 1 | `SERIAL` |
| `013_wearbly_uniforms.sql` (17, 49, 83, 116, 153) | 5 | `BIGSERIAL` |
| `017_qb_mapping_tables.sql` | 7 | `SERIAL` |
| `019_totalsource_benefit_overrides.sql:39` | 1 | `SERIAL` |
| `020_qb_usa_payroll_roster.sql` | 4 | `SERIAL` |
| `021_qb_usa_payroll_runs.sql` (41, 73) | 2 | `SERIAL` |
| `022_process_runs.sql:108` | 1 | `SERIAL` (`artifact_downloads` only) |
| `023_config_mappings.sql` | 4 | `SERIAL` (3 are re-declarations of `002`'s) |
| `025_qb_export_tie_out.sql:33` | 1 | `SERIAL` |
| `031_pnl_provider_schema.sql` | 6 | `bigserial` |
| `035_qbo_connection.sql:26` | 1 | `SERIAL` |

Because `023`'s `config_providers` / `config_locations` / `config_payers` are
`CREATE TABLE IF NOT EXISTS` over tables `002` already made, **52 distinct
sequences** would exist on a replay from empty. The plan's Phase 3 step 11 says
"all 45 sequences". 45 ≠ 52, by the same gap as the 57-vs-63 table count —
almost certainly the same unapplied tables. Resolve both together.

Tables with **no** sequence (UUID or composite/natural primary keys):
`organizations`, `org_members`, `roles`, `role_permissions`, `invite_codes`,
`org_modules`, `superadmins`, `clients`, `invoices`, `process_runs`,
`bkv5_location_remap`.

### Generated columns

Two, both `GENERATED ALWAYS AS (…) STORED`, both rounding money to 2 decimals:

| Column | Definition | Source |
|---|---|---|
| `qb_usa_payroll_gate.variance` | `NUMERIC(15,2) GENERATED ALWAYS AS (round(actual - expected, 2)) STORED` | `021_qb_usa_payroll_runs.sql:80` |
| `qb_export_tie_out.balanced` | `BOOLEAN GENERATED ALWAYS AS (round(credits - debits, 2) = 0) STORED` | `025_qb_export_tie_out.sql:43` |

Both are recomputed by Postgres on restore, so a data-only `pg_restore` will
regenerate rather than copy them. That is exactly why the plan makes
`variance` a parity check: a mismatch after restore means the *inputs* were
coerced differently, not that the column moved.

---

## 4. Data access call sites

### PostgREST calls (`.table(`)

**202 call sites** across `src/`, `web_app.py` and `scripts/` — one per matching
line, no line has two. The plan says 188. 188 is the running subtotal through
`src/api/v2/qb_usa_runs.py` in the table below; the remaining 14 sites, in nine
small modules and five scripts, were missed.

| File | Sites |
|---|---|
| `src/database.py` | 63 |
| `web_app.py` | 47 |
| `src/auth.py` | 11 |
| `src/api/v2/user_routes.py` | 11 |
| `src/api/v2/config_routes.py` | 9 |
| `src/process_runs.py` | 6 |
| `src/pnl_config_store.py` | 6 |
| `src/wearbly_processor.py` | 4 |
| `src/invoice_generator.py` | 4 |
| `src/qbo_client.py` | 3 |
| `src/qb_usa_payroll_roster.py` | 3 |
| `src/qb_usa_payroll_quickbooks.py` | 3 |
| `src/qb_export_artifacts.py` | 3 |
| `src/pnl_facts.py` | 3 |
| `src/pnl_driver_values.py` | 3 |
| `src/pnl_cost_ledger.py` | 3 |
| `src/app_settings.py` | 3 |
| `src/api/v2/qb_usa_runs.py` | 3 |
| `src/api/v2/runs_common.py` | 2 |
| `scripts/import_pnl_catalogue.py` | 2 |
| `scripts/generate_wearbly_order_2026_06_04.py` | 2 |
| `scripts/backfill_config_mappings.py` | 2 |
| `src/qb_usa_payroll_maps.py` | 1 |
| `src/qb_mappings.py` | 1 |
| `src/api/v2/routes.py` | 1 |
| `src/adp_booking_v5_processor.py` | 1 |
| `scripts/seed_qb_usa_payroll_roster.py` | 1 |
| `scripts/qbo_post_je.py` | 1 |
| **Total** | **202** (194 in `src/` + `web_app.py`, 8 in `scripts/`) |

### Raw psycopg2 use

`psycopg2-binary>=2.9.0` at `requirements.txt:15`. **8 connection sites**, which
matches the plan's "8 live call sites":

| Site | What it does |
|---|---|
| `src/database.py:2035` | `_bulk_insert` via `execute_values` |
| `src/database.py:2248` | raw query |
| `src/database.py:2278` | raw query |
| `src/database.py:2561` | raw query |
| `src/database.py:2582` | raw query |
| `src/database.py:3379` | `org_connection()` — hands out a `RealDictCursor` connection scoped to one org; a `?`→`%s` wrapper class follows at `:3396` |
| `scripts/run_migrations.py:85` | the migration runner (§6) |
| `scripts/migrate_sqlite_to_supabase.py:55` | one-off SQLite→Supabase import |

The connection string comes from `src/database.py:2026`:
`SUPABASE_DB_URL` falling back to `DATABASE_URL`. Other `SUPABASE_DB_URL`
readers: `scripts/run_migrations.py:72`, `scripts/migrate_sqlite_to_supabase.py:51`,
`tests/test_pnl_rls_live.py:31` (which skips when unset), plus `render.yaml:31`
and `.env.example:6` as declarations. No value appears in any tracked file.

`src/database.py:2033-2041` is also the one `execute_values` site — the plan's
"`COPY`, never `execute_values`" rule applies here, and note it currently
carries `source_transactions` rows, which this inventory classifies as PHI.

### `.or_()` filters — 4, as the plan says

All four are `ILIKE` searches built by f-string interpolation of a
caller-supplied `search` term into a PostgREST filter expression:

- `src/database.py:2814` — `config_providers` (`name`, `department_name`)
- `src/database.py:2838` — `config_locations` (`code`, `name`, `clinic_group`)
- `src/database.py:2871` — `config_payers` (`name`, `payer_type`)
- `src/database.py:2916` — `config_employees` (`employee_id`, `name`, `primary_location`)

The plan calls this an injection bug to fix during the port. Worth noting it is
a *live* bug, not only a porting concern.

### Upserts — the plan's "7" is `src/database.py` only

There are **15 PostgREST `.upsert(` call sites** repo-wide. Seven of them are in
`src/database.py`, which is what the plan counted:

`src/database.py:2821` (`config_providers`), `:2862` (`config_locations`),
`:2879` (`config_payers`), `:2902` (`config_departments`), `:2923`
(`config_employees`), `:3197` (`on_conflict='org_id,employee_id'`), `:3317`
(`on_conflict='org_id,column_header'`).

The other eight are outside it and need the same
`INSERT … ON CONFLICT DO UPDATE` treatment:
`src/qbo_client.py:311` (`qbo_connection`, `on_conflict="org_id,realm_id"`),
`src/qb_export_artifacts.py:183`,
`src/qb_usa_payroll_roster.py:660` (`on_conflict="org_id,employee_key"`),
`web_app.py:2456` (`role_permissions`), `web_app.py:7691` (`org_modules`),
`web_app.py:11272` (`uniform_column_mappings`),
`scripts/seed_qb_usa_payroll_roster.py:366`,
`scripts/backfill_config_mappings.py:185`.

(`src/process_runs.py` has eight more `store.upsert(...)` calls, but that is the
run-store's own method, not a PostgREST call. Not counted.)

---

## 5. Storage — `src/storage.py`

### Buckets

Three, all private, created by `003_storage_buckets.sql:5-7`:
`uploads`, `outputs`, `templates`. Their two RLS policies are on
`storage.objects` (§2). The plan reports `uploads` and `templates` hold 0
objects live; not verifiable from files.

### Path layout

`{org_id}/{batch_id}/{subfolder}/{filename}`, built by the single private
helper `StorageManager._path` (`src/storage.py:64-66`). Enforced by
`assert_org_path` (`:36-52`), which compares the first path segment to the
caller's `org_id` and raises `StoragePathError` — *before* any byte is read or
any URL is signed, because a signed URL is already authenticated for whoever
holds it. Callers map the error to 404, never 403.

### TTL constants

- `SIGNED_URL_TTL = 120` seconds — `src/storage.py`
- `BUNDLE_URL_TTL = 300` seconds — `src/storage.py`

**Phase 0c step 22 — done.** They used to be re-declared, not imported, in
`src/api/v2/oneshot_runs.py` and `src/api/v2/qb_usa_runs.py`; three
definitions of one policy number. Both modules now import them from
`src/storage.py`, which is where `web_app.py` always got them.

### The five public methods

| Method | Example callers |
|---|---|
| `upload_output_file` | `src/qb_export_artifacts.py`, `src/api/v2/oneshot_runs.py`, `src/api/v2/qb_usa_runs.py`, `web_app.py` |
| `list_output_files` | `src/api/v2/qb_usa_runs.py`, `web_app.py` |
| `download_file` | `src/qb_usa_payroll_quickbooks.py`, `web_app.py` |
| `get_signed_url` | `src/api/v2/oneshot_runs.py`, `src/api/v2/qb_usa_runs.py`, `web_app.py` |
| `download_all_outputs_as_zip` | `src/api/v2/oneshot_runs.py`, `src/api/v2/qb_usa_runs.py`, `web_app.py` |

### The six unreachable methods — deleted

**Phase 0c step 22 — done.** `upload_input_file`, `upload_bank_file`,
`upload_output_files`, `download_input_file`, `download_output_file` and
`download_template` had zero callers outside `src/storage.py` (no application
code, no tests, no templates; re-verified by grep before deletion). They are
gone from both `StorageManager` and `LocalStorageManager`, which leaves the
eleven public methods at five. Nothing addresses the `uploads` or `templates`
buckets any more — both were empty — so those two buckets are retired and do
not travel to S3 in Phase 3.

### Backend selection

`get_storage(org_id)` is chosen by **`STORAGE_BACKEND`** (`src/settings.py`),
not by the presence of `SUPABASE_URL` — Phase 0c step 19. In production a
`supabase` backend with no credentials, or with no org id, raises; outside
production it still falls back to `LocalStorageManager`.

---

## 6. Migration runners

### `scripts/run_migrations.py` — the drift mechanism

The plan's characterisation is accurate. Reading the file:

1. **It hardcodes three files.** `MIGRATIONS` at `:25-29` lists only
   `002_processing_tables.sql`, `003_storage_buckets.sql`,
   `005_mx_employees.sql`. Its docstring says "Applies migrations 002 and 003
   (001 and 004 are already applied)" — already out of date with its own list,
   and 32 files behind the folder. Everything from `006` onward was applied by
   some other means, unrecorded.
2. **It records nothing.** No ledger table, no `schema_migrations`. "Safe to run
   multiple times" is achieved by catching errors, not by knowing what ran.
3. **It swallows failures.** `:113-129` catch `DuplicateTable`,
   `DuplicateObject` and `UniqueViolation` as `SKIP`, and `:130` catches *every
   other exception* as a `WARN`, rolls back that one statement and continues.
   A run that fails 40 statements exits 0 and prints "Done".
4. It splits files into statements itself (`split_sql`, `:32-70`), handling
   `$$`-quoted blocks by counting `$$` per line; `conn.autocommit = True`
   (`:90`) means each statement commits on its own.

Together: a partially-applied file leaves no trace, and nothing can later tell
you which of the 37 files a given database has seen. That is the drift.

### `deploy/aws-trial/apply_migrations.py` (branch `aws-trial`) — the better one

Read via `git show aws-trial:deploy/aws-trial/apply_migrations.py`. It exists on
`aws-trial` only, not on `aws-migration`. What it does:

- **Globs every `.sql` under `supabase_migrations/migrations/` and sorts by
  filename**, so a brand-new empty Postgres gets 001 through the newest file.
  This is the behaviour Phase 3's Alembic revision 0001 inherits.
- **Keeps a ledger.** It creates `public.trial_migrations (name text PRIMARY
  KEY, applied_at timestamptz DEFAULT now())` and skips any file already
  recorded — the thing `run_migrations.py` lacks. This is also why
  `trial_migrations` exists in a database with no migration file for it.
- **Refuses to touch production.** It snapshots `SUPABASE_DB_URL` *before*
  importing `run_migrations` (whose top-level `load_dotenv()` would otherwise
  silently repopulate it from the repo `.env`), and then rejects any URL
  containing `supabase.co` or `pooler.supabase.com`.
- **Reuses, does not reimplement**, `split_sql` from `scripts/run_migrations.py`.
- **Inherits the same error swallowing.** Same three `SKIP` cases, same
  catch-all `WARN`, and it still records the file as applied afterwards. So a
  file that half-failed is marked done. Alembic must not copy this part.
- Documents that the self-hosted `auth` and `storage` schemas must exist first,
  or every `REFERENCES auth.users` fails.

Note the ledger records per *file*, not per statement, and the insert happens
unconditionally after the loop — no exit code reflects warnings.

---

## 7. Drift candidates — checklist for Alembic revision 0002

> **Settled, 2026-09-15 (Phase 3 steps 1–2).** The `pg_dump --schema-only` was
> taken (`migrations/baseline/supabase_public_schema_2026-09-15.sql`), revision
> 0001 was replayed into a scratch PostgreSQL, and the two were diffed
> (`migrations/baseline/drift_2026-09-15.diff`). **§7.1 below records what the
> diff actually found.** The checklist that follows it is left as written — it
> is the file-side evidence, and the places where it guessed wrong are worth
> keeping visible.

### 7.1 What the measured diff found

**242 differing normalised statements**, in these categories:

| # | Category | Count | Note |
|---|---|---|---|
| 1 | `double precision` live, `numeric(15,2)` in the files | 21 columns | **Unrecorded before now.** `import_batches`, `journal_entries`, `payroll_employees` (10), `processed_entries`, `processing_runs`, `source_transactions`, `transactions`, `unmapped_items`, `uploads`. Confirms the plan's need for a `DEC2FLOAT` adapter. |
| 2 | `timestamp without time zone DEFAULT CURRENT_TIMESTAMP` live, `timestamptz DEFAULT now()` in the files | 22 columns | **Unrecorded before now.** |
| 3 | `ON DELETE CASCADE` in the files, absent live | 20 foreign keys | A `DELETE FROM organizations` behaves completely differently on the two schemas. |
| 4 | `REFERENCES auth.users(id)` | 14 declared, **3 live** | Live keeps `org_members.user_id`, `org_members.invited_by`, `config_mx_employees.updated_by`. 11 are phantom. The checklist below says "~12 do not exist" and worries about `superadmins.user_id` being a PK — live, that column is a plain PK with **no** foreign key, so the worry is moot. |
| 5 | `updated_by` / `changed_by` `TEXT` live, `UUID` in the files | **5**, not 6 | `config_mx_employees.updated_by` genuinely is `uuid` live. The `023`-over-`002` hybrid is real and is exactly as predicted. |
| 6 | Tables live with no migration file | 3 | `fiscal_calendar` (created by 0002 — so `015`'s comment claiming it does not exist was wrong), `qgenda_workspaces` (**not** recreated), `trial_migrations` (**not** recreated). |
| 7 | Per-table column/constraint drift | 9 tables | `clients` (+email, +phone, org_id NOT NULL, −updated_at, no org FK at all), `config_employees` (−job_category, `active` integer), `import_batches` (`user_id` not `created_by`, `overview_data` text), `invite_codes` (4 NOT NULLs + a `role_id → roles` FK **no file declares**), `invoices` (−updated_at, 4 NOT NULLs, `total numeric(10,2)`), `org_modules` (PK `(org_id, module)`, no `id`, +updated_at/updated_by), `unmapped_items` (`resolved` integer), `uploads` (org_id nullable, no `created_by`), `employee_clinic_allocations` (unique key **not** org-scoped). |
| 8 | RLS live and missing from the replay | 2 objects | `superadmins` (ENABLE + `superadmins_self_only`), `org_modules` (`org_isolation` — no file creates it). |
| 9 | `027_invite_codes_email.sql` | **applied** | `invite_codes.email` is live. The plan and both READMEs said it never was. Corrected. |
| 10 | `payroll_column_account_map` | no drift | `007` creates it and live agrees. |

Open questions from the end of this section, answered:

1. **The six extra tables are live.** The five Wearbly `uniform_*` tables and
   `config_departments` are all in the dump. Live `public` holds **66** tables
   — the exact count, reconciled with §8 below, is the 66 `CREATE TABLE
   public.*` statements in
   `migrations/baseline/supabase_public_schema_2026-09-15.sql`, which is the
   authority. It does **not** include `alembic_version` (live has no such
   table; the chain creates it) and it **does** include the three tables with no
   migration file (`fiscal_calendar`, `qgenda_workspaces`, `trial_migrations`).
   62 of them are tenant-scoped: 61 with an `org_id` column, plus
   `role_permissions`, which inherits its org through `roles`
   (`scripts/tenant_tables.txt`). The remaining four are
   `organizations`, `superadmins`, `qgenda_workspaces` and `trial_migrations`,
   each listed with its reason in `NOT_TENANT_SCOPED`.

   After the chain runs, a migrated database holds those 66 minus
   `qgenda_workspaces` and `trial_migrations` (deliberately not recreated),
   plus `alembic_version`, plus `phi.transaction_identity` and
   `audit.phi_access` in their own schemas. `scripts/tenant_tables.txt`
   therefore lists **63** entries: the 62 above with `public.` prefixes, plus
   `phi.transaction_identity`.
2. **`config_providers` / `config_locations` / `config_payers` live have
   `023`'s shape** — `updated_by text`, no FK, plus `location_code` /
   `facility_raw`. A replay from empty produces `002`'s UUID column patched by
   `023`'s `ALTER`s, i.e. the hybrid. Revision 0002 converts the column to
   `text` and drops the phantom FK.
3. **`fiscal_calendar` is live.** `015`'s comment asserting it "does NOT exist
   in Supabase" is a false record in a tracked file.
4. `ts_benefit_override` — still open; not a schema question.

**Two failures of the replay itself**, which no file-side reading could have
found: `012`'s `SET NOT NULL` and all of `014`'s statements on `clients` /
`invoices` error on a database built from empty. The aws-trial script that
"proved" the replay swallowed every exception. See
`migrations/baseline/SKIPPED.md`.

### 7.2 The original file-side checklist (kept as written)

- [x] **`027_invite_codes_email.sql` never applied.** **WRONG — see §7.1 row 9.
      It *was* applied; `invite_codes.email` is live.** Left here as written
      because it is the file-side reading that was wrong, and that is the point
      of keeping §7.2. *File side verified.* The
      file exists and does exactly one thing:
      `ALTER TABLE public.invite_codes ADD COLUMN IF NOT EXISTS email TEXT`
      (`:17-18`) plus a `COMMENT`. Plan says the column is absent live. Because
      it is `IF NOT EXISTS`, replaying 0001 is safe either way — the drift is
      only detectable by dumping the live table.

- [ ] **`REFERENCES auth.users(id)` foreign keys that do not exist live.**
      *File side verified: **14** declarations, not the plan's "~12".*
      `001:15` (`org_members.user_id`), `001:17` (`org_members.invited_by`),
      `002:23` (`import_batches.created_by`), `002:167` (`uploads.created_by`),
      `002:251/269/287/306` (`config_providers/locations/payers/employees.updated_by`),
      `002:322` (`config_history.changed_by`), `005:16`
      (`config_mx_employees.updated_by`), `015:22/23`
      (`invite_codes.created_by/used_by`), `015:77` (`superadmins.user_id` — a
      primary key, so this one cannot simply be dropped without deciding what
      the PK becomes), `015:154` (`invoices.created_by`).
      Revision 0003 strips all 14; revision 0002 must record which of them the
      live database actually has, because the two revisions disagree only if 0002
      gets it wrong.

- [ ] **`updated_by` / `changed_by`: `TEXT` live, `UUID` in the file.**
      *File side verified: exactly **six** columns are declared `UUID … REFERENCES
      auth.users(id)`* — `config_providers.updated_by` (`002:251`),
      `config_locations.updated_by` (`002:269`),
      `config_payers.updated_by` (`002:287`),
      `config_employees.updated_by` (`002:306`),
      `config_history.changed_by` (`002:322`),
      `config_mx_employees.updated_by` (`005:16`).
      The plan's "six" is exactly right.
      **And the repo contains the likely cause:** `023_config_mappings.sql`
      re-declares `config_providers` (`:39`), `config_locations` and
      `config_payers` with `updated_by TEXT` and no FK, and its own header
      (`:17-19`) says those tables "already exist in the live project, created
      ad hoc outside the migration folder". So for three of the six, the `TEXT`
      shape is what a fresh replay produces *only if* `002` has not run first —
      the `IF NOT EXISTS` makes the outcome depend on order. Revision 0002 must
      pick one and say so. Same pattern, newer tables, already standardised on
      `TEXT`: `qb_usa_employee.updated_by` (`020:135`),
      `ts_benefit_override.updated_by` (`019:58`),
      `mx_payroll_column_map.updated_by` (`008:15`).

- [ ] **Two files share prefix `013`.** *Verified:*
      `013_not_null_org_id_unique_constraints.sql` and
      `013_wearbly_uniforms.sql`. Both runners sort by filename, which puts
      `_not_null` first (`n` < `w`), and the two touch disjoint tables, so the
      current order is safe. Alembic revisions are a linked list, so the chain
      must state the order explicitly rather than inherit it from `sorted()`.

- [ ] **`fiscal_calendar` exists live with no migration file.** *Verified*
      (§1). Worse than "missing": `015:93-101` contains a commented-out schema
      and prose asserting the table "does NOT exist in Supabase". If the plan's
      6,209 live rows are real, that comment is a false record in a tracked
      file and revision 0002 should delete it in the same commit that creates
      the table.

- [ ] **`qgenda_workspaces` exists live with no migration file.** *Verified* —
      zero mentions anywhere in `supabase_migrations/`. Plan excludes it from
      the dump and leaves it in the retained Supabase archive.

- [ ] **`trial_migrations` exists with no migration file.** *Verified, and
      explained*: created by `deploy/aws-trial/apply_migrations.py` on the
      `aws-trial` branch. Not part of Meridian's schema; exclude from both the
      dump and the parity suite.

- [ ] **Table count: 63 declared vs 57 in the plan's parity suite.** *File side
      verified* (§1). Six tables are unaccounted for. The Wearbly `uniform_*`
      five (`013_wearbly_uniforms.sql`) and `config_departments`
      (`023:129`) are the obvious candidates — exactly six. Confirm against the
      dump; if the `uniform_*` tables are absent live, that is a separate
      question for revision 0002 (Wearbly is a different product).

- [ ] **Sequence count: 52 declared vs 45 in the plan's parity suite.** *File
      side verified* (§3). Probably the same six tables plus one. The parity
      check "all sequences `last_value >= max(id)`" needs the right
      denominator or it silently checks fewer.

- [ ] **Policy count: 93 on `public` across 19 files (95/20 including
      `storage.objects`) vs the plan's 94/19.** *Verified* (§2). And neither is
      the live count — `014`, `015` and `023` re-create policies that earlier
      files made, so the distinct-name count is around 68. Take the real number
      from `pg_policies`.

- [ ] **`config_providers` / `config_locations` / `config_payers` are declared
      twice with different shapes.** *Verified:* `002:242/259/277` (UUID
      `updated_by`, FK to `auth.users`) and `023:29/64/100`
      (TEXT `updated_by`, no FK, plus `location_code` / `facility_raw` columns
      that `002` lacks, added defensively by `ALTER … ADD COLUMN IF NOT EXISTS`
      on the next line). On a replay from empty, `002` wins and `023`'s
      `ALTER`s patch it — so the replayed shape is a *hybrid* that neither file
      describes on its own. This is the single most likely source of a
      surprising 0002 diff. Diff these three tables column-by-column first.

- [ ] **`bkv5_location_remap`'s primary key changed.** *Verified:* `011:17-21`
      creates it with `PRIMARY KEY (location_code, entity)` and **no `org_id`**;
      `012:23` adds `org_id`, `:31` backfills every row with a hardcoded
      production organization UUID, `:38` makes it `NOT NULL`, and `:46-49`
      drops and recreates the PK as `(org_id, location_code, entity)`. Two
      consequences: the replayed schema depends on both files running, and
      `012` contains a tenant identifier hardcoded in a tracked, pushed file —
      flag it for the safety sweep even though it is not PHI.

- [ ] **`is_test` and `superseded_by` columns are `ALTER`-added across eight
      tables.** `028_mark_test_data.sql:27-34` adds `is_test` to
      `journal_entries`, `transactions`, `import_batches`, `uploads`,
      `processing_runs`, `process_runs`, `qb_export_tie_out` and
      `qb_usa_payroll_journal`; `:43` adds `import_batches.superseded_by`, and
      `026_process_runs_superseded_by.sql` does the same for `process_runs`.
      The same file also runs data `UPDATE`s against specific live row ids
      (`:71-79`). A replay from empty applies the DDL and no-ops the data
      updates; Phase 3 must decide whether 0001 replays those `UPDATE`s at all.
      Both `superseded_by` columns are self-referencing FKs — these are the two
      the plan flags for `pg_restore --disable-triggers`.

- [ ] **`role_permissions.process` CHECK constraint was widened four times.**
      `004:17` (5 values) → `018` → `029` → `030` (`code_grader`). Revision
      0002 must carry the final widened set, and
      `tests/test_role_permission_constraint.py` compares it to
      `src.auth.ALL_PROCESSES` — keep that test pointed at whatever replaces
      `030`.

- [ ] **`config_mx_employees`'s policy is non-deterministic.** `005:22-26`
      inlines `user_org_id()`'s *original* body (`LIMIT 1`, no `ORDER BY`)
      rather than calling the function, so `014`'s determinism fix at `:189`
      never reached it. A user in two orgs gets an arbitrary org on this one
      table. Fix it in the port rather than transcribing it.

- [ ] **20 of `002`'s policies have `USING` but no `WITH CHECK`.** `014` fixed
      exactly those 20 plus `clients` and `invoices`. Any table whose policy
      predates `014` and was not re-created by it should be re-checked:
      `payroll_column_account_map` (`007:18`) and `mx_payroll_column_map`
      (`008:18`) both still have `USING` only, and `005`'s does too. Three
      tables can therefore be *written* with another org's `org_id` today.

---

## Open questions for Phase 3

1. Does the live database have the six extra tables (Wearbly `uniform_*` plus
   `config_departments`), or is the plan's 57 correct? Same question decides
   the 45-vs-52 sequence count.
2. Which shape do `config_providers` / `config_locations` / `config_payers`
   actually have live — `002`'s, `023`'s, or the hybrid a replay produces?
3. Is `fiscal_calendar` live (6,209 rows, per the plan) despite `015`'s comment
   saying it is not? Whichever is true, one of the two records is wrong and
   should be corrected in the same commit.
4. Is `ts_benefit_override` PHI? It holds named employees against carrier
   (UNUM/BCBS) benefit amounts. It is not patient data and carries no DOB, SSN
   or member id in the declared columns, so this inventory calls it internal —
   but it is the closest call on the list and deserves a decision, not a
   default.

## 8. Live counts (Supabase, read 2026-09-15 via `pg_policies` / `information_schema`)

| Measure | Files say | Live |
|---|---|---|
| Tables in `public` | 63 declared (57 in the plan) | **66**, including `fiscal_calendar`, `qgenda_workspaces`, `trial_migrations` (no migration file) |
| RLS policies on `public.*` | 95 `CREATE POLICY` statements (many re-create earlier ones) | **74** distinct policies on 65 tables |
| RLS policies on `storage.objects` | 2 | **2** |
| Tables with RLS disabled | — | **1**: `public.trial_migrations` (the trial ledger; dropped at cutover, tracked in `docs/migration-tracker.md`) |

**The 65 in this table was wrong**, and §7.1 said 66. The dump settles it: 66
`CREATE TABLE public.*` statements, none of them `alembic_version` (live has no
Alembic ledger — the count `list_tables` returned had excluded one of the
no-migration-file tables). Both sections now say 66, counted the same way, from
the same file. **74 distinct policies** likewise counts live `public` policies
only; revision 0004 replaces every one of them with a single
`meridian_org_isolation` per tenant table, plus three on the identity tables, so
the post-migration count is not comparable and is not a parity denominator.

The live numbers are the parity-suite denominators for Phase 3; the file counts are not.
