# docs/compliance/

The compliance evidence that lives **in the repo**: the documents an auditor, an attorney, or
a future session needs in order to understand what Meridian holds, where it flows, what can
go wrong, and which control answers which requirement.

## What lives here

| File | What it is |
|---|---|
| `control-matrix.md` | Requirement → control → implementation → **evidence location** → phase → status, for HIPAA Security Rule 164.308/310/312/314/316, SOC 2 (Security, Availability, Confidentiality) and the OWASP API Security Top 10. Ends with the `needs-a-human` list. Completed in Phase 8. |
| `threat-model.md` | STRIDE threat model, one section per trust boundary, plus §9 (threats in today's system), §10 (the OWASP API Top 10 mapping — the source of truth) and §11 (gaps the model found in the plan). |
| `phi-classification.md` | The PHI determination, every store and artifact classified, the two PHI channels end to end, the minimum-necessary review, and PHI/PII in logs. |
| `data-flows.md` | What data leaves AWS, to whom, carrying what. One entry per external call. |
| `inventory-data-layer.md` | Every table, RLS policy, migration and data-access call site. |
| `inventory-config-and-external-calls.md` | Every environment variable, config file, secret and outbound call. |
| `in-transit-encryption.md` | *(Phase 8)* The position paper for the one addressable specification Meridian documents instead of implementing: the plaintext ALB → ECS task hop inside the private subnet. |

## What does not live here

- **Signed documents.** BAAs, the risk analysis, the policy set, training records, the
  monthly activity reviews and the annual evaluation live in the Evidence set outside this
  repo (`~/Business/Meridians Logic/Company/Compliance/`). This repo is pushed to GitHub.
- **Any PHI, any client data, any secret, any ACH or bank number.** Not in a document, not
  in an example, not in a test fixture. PHI lives in the PHI vault; secrets live in `.env`
  and, after Phase 1, in AWS Secrets Manager.
- **Architecture decisions** — those are ADRs, in `docs/adr/`.
- **Operational procedures** — those are runbooks, in `docs/runbooks/`.

## How these fit together

`phi-classification.md` says *what* is sensitive. `data-flows.md` says *where it goes*.
`threat-model.md` says *what could go wrong on each hop*. `control-matrix.md` says *what we do
about it and where the proof is*. The inventories are the raw material all four are built on,
and each is line-cited to the commit it was written against, so a stale citation is visible.
