# Data flows — today and after the AWS migration

Companion to `docs/compliance/phi-classification.md`. Same rule: no real patient or
employee value appears here, only field names.

**Line citations:** every `path:line` in this document **cites commit `4ccddcb`** (2026-09-15). Later commits reformat and fix those files, so check a citation with `git show 4ccddcb:<path>`, not the working tree.

**Why this document exists.** A HIPAA risk analysis has to say where PHI goes, who can see
it on the way, and what contract or control covers each hop. This is that map, drawn twice:
the system as it runs today, and the system the migration plan (`docs/aws-migration-plan.md`
§2.5) is building.

**Jargon, defined once**

| Term | Plain meaning |
|---|---|
| **Reverse proxy** | A server that forwards a browser's request to another server and returns the answer, so the browser only ever talks to one address. `web/next.config.mjs` does this. |
| **CloudFront / WAF** | AWS's edge network, and the firewall rules that sit in front of it. |
| **ALB** | Application Load Balancer — the thing inside AWS that receives traffic and hands it to a container. |
| **ECS Fargate** | AWS runs your container; you never manage the server. |
| **NAT gateway** | The one door through which a private container can call *out* to the public internet. |
| **IdP** (identity provider) | The service that proves who someone is — here Google or Microsoft. |
| **Federation** | Letting an IdP do the proving, instead of a password stored here. |
| **BAA** | Business associate agreement: the contract that lets a vendor touch PHI. |
| **Presigned / signed URL** | A time-limited link that grants access to one file without a login. |

---

## 1. Today

### 1.1 Diagram

```mermaid
flowchart TB
    subgraph Browser["Browser (workforce, 2 people)"]
        B["www.meridiansgrp.com"]
    end

    subgraph Render["Render (US) — no BAA on record"]
        WEB["meridian-web<br/>Next.js, reverse proxy<br/>web/next.config.mjs:50-64"]
        API["meridian-api<br/>Flask + gunicorn --workers 1<br/>render.yaml"]
        DISK["container disk<br/>data/input/**<br/>web_app.py:245"]
        LOGS["Render log stream<br/>(names today — see phi-classification.md §5)"]
    end

    subgraph Supabase["Supabase (hosted) — no BAA on record"]
        PG[("Postgres<br/>transactions, source_transactions,<br/>qb_usa_*, config_*")]
        AUTH["GoTrue Auth<br/>users, sessions, OAuth"]
        ST["Storage<br/>uploads / outputs / templates"]
    end

    subgraph Ext["External"]
        RESEND["Resend<br/>transactional email"]
        QBO["Intuit QuickBooks Online"]
        GOOG["Google IdP"]
        MSFT["Microsoft Entra ID"]
    end

    B -->|"HTTPS: uploaded billing & carrier files, session cookie"| WEB
    WEB -->|"HTTPS proxy: /api/*, /auth/*, /static/*"| API
    API --> DISK
    API --> LOGS
    API -->|"PostgREST + service key: row reads/writes incl. PHI"| PG
    API -->|"JWT verify, OAuth handoff"| AUTH
    API -->|"upload / signed URL mint (TTL 120-300s)"| ST
    B -.->|"signed URL: downloads the file DIRECTLY, bypassing Flask"| ST
    B -.->|"redirect to /auth/v1/authorize (web_app.py:1863-1877)"| AUTH
    AUTH --> GOOG
    AUTH --> MSFT
    API -->|"invite code, run summary (counts + totals)"| RESEND
    API -->|"OAuth2 + aggregate JE lines"| QBO
```

### 1.2 What each hop carries

| Hop | Data | PHI? | Control today |
|---|---|---|---|
| Browser → Next.js → Flask | uploaded billing export, bank file, ADP register/invoice, UNUM/BCBS carrier files; session cookie | **yes** | TLS; `HttpOnly` + `Secure` cookies keyed off `FLASK_ENV=production` (`src/auth.py:223`, `render.yaml`) |
| Flask → container disk | the same files, staged for processing | **yes** | none beyond the platform; cleanup only on failure/cancel paths (`src/api/v2/qb_usa_runs.py:877`, `:880`, `:1011`) |
| Flask → Supabase Postgres | `transactions` (account no, claim, encounter, service/payment dates), `source_transactions.raw_data` verbatim | **yes** | TLS; RLS policies (94 across 19 migration files, per the plan); the **service key bypasses RLS**, and org scoping rests on the application's `org_id` predicate |
| Flask → Supabase Storage | workbooks, JE CSVs, review workbooks, ZIPs | **yes** | bucket RLS (`003_storage_buckets.sql:10-17`) + first-path-segment check (`src/storage.py:34-49`) |
| Browser ← Supabase Storage (signed URL) | one artifact | **yes** | 120 s / 300 s TTL (`src/storage.py:17-21`); mint audited in `artifact_downloads` (`022_process_runs.sql:107-120`). Flask never sees the GET. |
| Browser → Supabase Auth → Google/Microsoft | email, name, IdP tokens | no | TLS; standard OAuth2 |
| Flask → Resend | recipient email, invite code, org name, role, period, record **count**, total amount (`src/email_service.py:91`, `:133-137`) | no PHI found; amounts are aggregate | API key in env; **no BAA** |
| Flask → Intuit QBO | JE header + aggregate lines: account, class, department, amount, description (`src/qbo_je_adapter.py:112`, `:157`) | no — descriptions are `{Period} - {FY} - Cash Sales - {Location} {PayerType}` and `{period} - {fy} - Payroll` (`src/booking_je_generator.py:150`) | OAuth2, tokens in `qbo_connection` (migration 035) |
| Flask → log stream | see `phi-classification.md` §5 | **yes, today** | none |

### 1.3 The exposures this picture contains

1. **Two vendors hold PHI with no BAA on record** — Supabase (database + storage) and
   Render (compute, disk, logs). Nothing in `docs/` covers either (plan §4, Track C).
2. **The log stream carries employee and subscriber names** and, through `exc_info`
   tracebacks, can carry patient account numbers.
3. **PHI sits on a container's local disk** with no lifecycle and an incomplete cleanup.
4. **Superadmin crosses organizations silently** (`src/auth.py:610`, `:632`, `:838-848`).
5. **The Supabase service key is an RLS bypass** held by the application process.
6. PHI is also on one MacBook (plan Track C item 11).

---

## 2. Target (after the migration)

### 2.1 Diagram

```mermaid
flowchart TB
    subgraph Internet["Public internet"]
        B["Browser<br/>app.meridiansgrp.com (the app)<br/>www. = public website only (ADR 0050)"]
        GOOG["Google IdP"]
        MSFT["Microsoft Entra ID"]
        QBO["Intuit QuickBooks Online"]
        SUPA["Supabase Auth<br/>(transition only, until Phase 10)"]
    end

    subgraph AWS["Our AWS account — BAA accepted (Phase 1)"]
        CF["CloudFront + WAF<br/>managed core, IP reputation, rate<br/>ACM cert"]
        ALB["ALB<br/>SG = CloudFront prefix list only<br/>origin-verify header"]

        subgraph VPCpriv["VPC — private app subnets"]
            WEBT["ECS Fargate: web<br/>Next.js standalone"]
            APIT["ECS Fargate: api<br/>FastAPI (+ Flask in transition)<br/>desiredCount=1"]
            WORK["ECS Fargate: worker<br/>(Phase 11)"]
            SQS["SQS job queue + DLQ<br/>(Phase 11)"]
        end

        subgraph VPCdata["VPC — private data subnets"]
            RDS[("RDS PostgreSQL 17<br/>public schema | phi schema | audit schema<br/>meridian_app + phi_access roles")]
        end

        S3A[("S3 artifacts")]
        S3P[("S3 phi")]
        S3AUD[("S3 audit / CloudTrail<br/>Object Lock")]
        COG["Cognito user pool<br/>custom:app_uid, MFA ON"]
        LAM["User Migration Lambda<br/>outside VPC, 5s timeout"]
        SES["SES"]
        NAT["NAT gateway"]
        CW["CloudWatch Logs<br/>redaction filter"]
    end

    B -->|HTTPS| CF --> ALB
    ALB --> WEBT
    ALB -->|"/api/*, /auth/*"| APIT
    WEBT --> APIT
    APIT --> RDS
    APIT --> S3A
    APIT --> S3P
    APIT --> SQS --> WORK
    WORK --> RDS
    WORK --> S3P
    APIT --> CW
    WORK --> CW
    CW --> S3AUD
    B -.->|"presigned URL, short TTL"| S3A
    B -.->|"presigned URL, short TTL, audited"| S3P
    B -->|"hosted UI / token exchange"| COG
    COG --> GOOG
    COG --> MSFT
    COG -->|"UserMigration trigger"| LAM
    LAM -.->|"transition only: password check"| SUPA
    APIT -->|"via NAT"| NAT
    NAT --> QBO
    APIT --> SES
```

### 2.2 Every arrow that crosses the AWS boundary

"Crosses the boundary" = leaves AWS-controlled infrastructure, or enters it from outside.

| # | Arrow | Exactly what leaves / arrives | PHI possible? | Control |
|---|---|---|---|---|
| 1 | Browser → CloudFront → ALB → ECS | uploaded billing exports (`Patient Acct No`, `Claim No`, `Encounter ID`, `Service Date`, `Payment Date`, provider, payer, amount); ADP register/invoice; UNUM/BCBS carrier files (`EE DOB`, `Member ID`, `Subscriber ID`); session cookie or bearer token | **yes — the main PHI ingress** | TLS 1.2+ end to end; WAF managed rules + rate limiting; ALB security group admits only CloudFront's managed prefix list plus an origin-verify header (plan §2.4); Cognito auth before any upload route; GuardDuty malware scan before processing (plan §2.3) |
| 2 | ECS → Browser (API responses) | run metadata, totals, gate results, JE previews; PHI **masked by default** in `/api/v3`, unmasked only with the `phi:read` scope | **yes, when unmasked** | Cognito token verified locally (PyJWT + cached JWKS); `phi:read` never granted to an external client without a recorded partner BAA + admin approval; every unmasked read writes an `audit.phi_access` row (plan §2.3) |
| 3 | Browser ← S3 presigned URL (`artifacts`) | one JE CSV, workbook or ZIP; aggregate content | no (tokenized default export, plan P-2) | short TTL (keep today's 120 s / 300 s, `src/storage.py:17-21`); org-prefix path check; mint audited |
| 4 | Browser ← S3 presigned URL (`phi`) | the permission-gated detail workbook (`Patient Acct No` present) or a carrier-file copy | **yes** | same as #3 plus a permission check and an `audit.phi_access` row; SSE-KMS with a per-environment customer-managed key |
| 5 | Browser → Cognito (hosted UI / token endpoint) | email, password or federated assertion, MFA TOTP code | no | AWS service inside the BAA; MFA `ON`; `PreventUserExistenceErrors=ENABLED`; threat protection `AUDIT` → `ENFORCED` |
| 6 | Cognito ↔ Google IdP | email, name, `sub`, OAuth2 authorization code | no | standard OIDC; allowlisted redirect URIs; one live google-only member (plan §2.1) |
| 7 | Cognito ↔ Microsoft Entra ID | email, name, `oid`/`sub`, OAuth2 code | no | same; **the single superadmin is azure-only** (plan §2.1) — pre-create with `AdminCreateUser` + `AdminLinkProviderForUser` *before* enabling the IdP |
| 8 | Lambda → Supabase Auth (**transition only**) | one email address and the plaintext password the user just typed, for a single verification call | no PHI; a credential in flight | TLS to Supabase; **never logged** (plan D-06); fails closed on a Supabase outage; 5 s timeout; Lambda kept outside the VPC with a stdlib/`urllib3`-only dependency set; the arrow is **deleted at the Phase 10 cut-off**, after which unmigrated users get a password reset |
| 9 | ECS api → NAT → Intuit QBO | OAuth2 token exchange, then JE create/query: realm id, account, class, department, amount, and an **aggregate** line description | **no, by construction** — verify with a byte-diff gate that no per-employee or per-patient string reaches `Description` (`src/qbo_je_adapter.py:157` truncates at 4000 chars but does not filter) | TLS; egress allowlist on the NAT path (Intuit + IdP endpoints only); tokens in `qbo_connection` / Secrets Manager; Intuit is **not** a BAA counterparty and must not receive PHI |
| 10 | ECS api → SES | recipient email, invite code, org name, role, period, record count, total amount | no PHI (matches today's payloads, `src/email_service.py:91`, `:133-137`) | SES is in the AWS BAA once accepted; domain verified in Phase 1; DKIM/SPF/DMARC; a written rule that email bodies stay aggregate |
| 11 | ECS → CloudWatch Logs → S3 audit | application logs, ALB access logs, CloudTrail | **must be no** | the redaction work in `phi-classification.md` §5 lands **before** this arrow carries production traffic; 400-day log retention; Object-Locked audit bucket for the six-year policy retention |
| 12 | RDS ↔ ECS (internal, listed for completeness) | every PHI column | yes | never crosses the boundary: private data subnets, `PubliclyAccessible=false`, `rds.force_ssl=1`, `meridian_app` has zero grants on the `phi` schema, `phi_access` via `SET ROLE` + audit row (plan §2.3) |
| 13 | Admin laptop → SSM Session Manager → RDS | ad-hoc `psql` | **yes** | no inbound ports anywhere; SSM port-forward to an SSM-managed host with zero security-group ingress; CloudTrail records the session (plan §2.4) |

### 2.3 Explicitly allowed external calls

Everything else is denied by default on the NAT egress path. This table is the allowlist.

| Destination | Direction | Purpose | Data that crosses | PHI allowed? | Contract / control | Wired today? |
|---|---|---|---|---|---|---|
| **Intuit QuickBooks Online** | outbound via NAT | post journal entries, read account/class/department maps | OAuth2 tokens; aggregate JE lines | **No.** Aggregate only | no BAA (none needed while aggregate-only); TLS; `src/qbo_client.py` is the only module that talks to QBO | **Yes** — `src/qbo_client.py`, tokens in `qbo_connection` (migration 035) |
| **Google IdP** | inbound via Cognito federation | workforce sign-in | email, name, `sub` | No | OIDC, allowlisted redirect URIs | **Yes**, today via Supabase (`api/routers/oauth.py` `auth_google` → `_start`); moves to Cognito federation |
| **Microsoft Entra ID** | inbound via Cognito federation | workforce sign-in | email, name, `oid` | No | OIDC, allowlisted redirect URIs | **Yes**, today via Supabase (`api/routers/oauth.py` `auth_microsoft`, provider id `azure`) |
| **NetSuite** | — | — | — | — | — | **No. Not wired at all.** A repo-wide grep for `suitetalk` and `restlet` returns nothing, and every `netsuite` hit is a *file-format* reference: `src/je_generator.py:1`, `src/adp_je_generator.py:4`, `src/booking_je_generator.py:2`, and column names like `department_netsuite`. Meridian writes CSVs that a human imports into NetSuite. **There is no NetSuite network call to allow, and none should be added to the allowlist until one exists.** |
| **Supabase Auth** | outbound from the User Migration Lambda | verify a legacy password once, at first Cognito login | email + plaintext password for that one call | No | TLS; never logged; fails closed; **time-boxed — removed at the Phase 10 cut-off** | **Yes today** as the whole auth system (`web_app.py:1863-1877`); becomes transition-only |
| **Resend** | outbound | transactional email | recipient email, invite code, counts, totals | No | **replaced by SES in Phase 7**; until then it is an unBAA'd vendor holding workforce emails only | **Yes** — `src/email_service.py:57-69`, key from `RESEND_API_KEY` |

**Denied by default and worth naming:** Supabase Postgres/PostgREST and Supabase Storage
(gone after Phase 10), Render (gone after Phase 10), any analytics or error-reporting SaaS
(none is wired today — keep it that way, or sign a BAA first), and any CDN-hosted font or
script in a server-rendered PDF path (the invoice templates already bundle Inter locally at
`static/fonts/` for exactly this reason).

### 2.4 Transition period: what is true at once

Between Flip 1 (end of Phase 4) and Phase 10 the picture is a hybrid, and the risk analysis
has to say so:

- Identity is Cognito, **and** `require_auth` still accepts a Supabase JWT (plan §2.1
  dual-token acceptance).
- Data is still in Supabase Postgres/Storage until Flip 2 (Phase 9); compute may already be
  on AWS.
- The Lambda → Supabase Auth arrow (#8) exists only in this window.
- Therefore **Supabase and Render remain PHI-holding vendors during the transition**, and
  their BAAs — or a written risk acceptance signed by the security official — are needed
  for the whole window, not just for today.

### 2.5 Live → developer laptop (`scripts/pull_live_data.py`)

Added 2026-09-30. A developer pulls the live database onto the laptop to test there. One
read-only, repeatable-read transaction against the live database (`BEGIN ... READ ONLY`,
checked with `SHOW transaction_read_only` before the first query); nothing is written back.
The script refuses any target that is not `127.0.0.1`/`localhost`/a Unix socket.

| Mode | Where it lands | What crosses | PHI? |
|---|---|---|---|
| `--config-only` (default) | the normal local cluster (`$MERIDIAN_LOCAL_PGDATA`, port 55432) | organizations (settings stripped of tokens, ACH, keys, e-mails), roles, permissions, modules, mapping/config tables. Members only as counts per (org, membership type, role), turned into synthetic users; `*_by` columns overwritten | **No.** No patient data, no employee rosters, no real user id or e-mail |
| `--full` | a separate cluster on the encrypted PHI volume only (`/Volumes/MeridianPHI/Meridian/local-pg`, port 55433); refused unless the volume is mounted and the directory is on its device | the above plus employee rosters and every data table; patient identifiers go to `phi.transaction_identity`, `public.transactions.patient_ref` is re-keyed with the laptop's own HMAC key | **Yes**, and only there. Each pull is logged (date, mode, table counts, no contents) to `/Volumes/MeridianPHI/Meridian/pull-log.txt`; the cluster's env file (mode 0600) sits beside it |

Never copied in either mode: QuickBooks tokens (`qbo_connection`), invite codes, machine
clients, webhook secrets and deliveries, the idempotency ledger, superadmins, real
`org_members`/`user_profiles`. The script prints only table names, column names, counts and
`OK`/`DIFF`. A database error is printed as its class, SQLSTATE and constraint name, never
its text, because that text can quote a row.

### 2.6 Laptop sandboxes (`scripts/sandbox.sh`)

Added 2026-09-30. A sandbox is a copy of a pulled database on the same laptop, for building
and testing a branch. It adds no new path out of live: the only read of live is the pull in
2.5 (`sandbox.sh golden` runs it, read-only, into a database `meridian_golden`), and every
sandbox is `CREATE DATABASE ... TEMPLATE meridian_golden` on the same local cluster.

| Kind | Where it lands | What it holds | PHI? |
|---|---|---|---|
| default | the normal local cluster on the laptop disk (port 55432): databases `meridian_golden` and `sandbox_<name>`; env file, uploaded files and logs in `$MERIDIAN_LOCAL_PGDATA.sandboxes/<name>/` (outside the repo, 0700; env file 0600) | the `--config-only` set of 2.5 plus the synthetic seed users | **No.** Configuration only |
| `--phi` | the PHI cluster on the encrypted volume only (`/Volumes/MeridianPHI/Meridian/local-pg`, port 55433): `meridian_golden` from a `--full` pull, `sandbox_<name>`, and the sandbox's env file, uploaded files and logs beside that cluster on the volume | the `--full` set of 2.5 | **Yes**, and only on the volume. Refused unless it is mounted and the cluster exists |

A sandbox cannot send anything out: its env file turns off QuickBooks posting
(`MERIDIAN_QBO_POSTING=off`, checked in `QboClient.create_journal_entry` before any
request), e-mail, webhooks (`MERIDIAN_API_V3=0`, no queue/bus names) and S3 (local storage),
removes QuickBooks app credentials, and every organization in the copy is put in Test mode
with its QuickBooks connections and webhook subscriptions deleted. Before the api starts,
every database/storage/service URL in its environment is checked to name this machine
(the same loopback check the pull uses for its target); any other host refuses the start.
The git worktree itself (code) holds no data: a comment-only `.env` stops the app from
reading the main checkout's.

---

## 3. What this document assumes, and does not prove

- Every claim above is from a file in this repo, cited by `path:line`, except the live row
  counts and the "no BAA on record" statements, which come from
  `docs/aws-migration-plan.md:52` and §4 Track C respectively.
- The target diagram describes the plan, not deployed reality. `src/phi.py`, the `phi` and
  `audit` schemas, the `artifacts`/`phi` buckets, Cognito and SES do not exist yet.
- The egress allowlist in §2.3 is a design statement. Nothing enforces it today, because
  today there is no VPC.
