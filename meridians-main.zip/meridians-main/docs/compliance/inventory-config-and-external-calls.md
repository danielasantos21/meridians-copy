# Inventory — configuration and external calls

Phase 0 deliverable for `docs/aws-migration-plan.md`. Every environment variable
the app reads, every network call it makes, and every legacy config file still
loaded off disk. Read out of the code on branch `aws-migration`; every claim
cites `path:line`.

**Line citations cite commit `4ccddcb`** (2026-09-15). Use `git show 4ccddcb:<path>`, not the
working tree.

> **§1 was read before Phase 0c.** Commit `fef0bae` changed how the backend is chosen: the
> `SUPABASE_URL`-presence sentinel and the `DATABASE_MODE` flag were replaced by one typed
> settings module, `src/settings.py`, exposing explicit `DATABASE_BACKEND` /
> `STORAGE_BACKEND` / `AUTH_BACKEND` switches that fail loud when unset outside development.
> The rows below that describe the old behaviour are marked; the variables themselves still
> exist, but the *decision* they used to make is now made in one place.

**No secret values appear in this document, and none were read.** The real `.env`
was never opened. `.env.example` was read for its key names only.

---

## 1. Environment variables

Scope searched: `web_app.py`, `src/**`, `scripts/**`, `tests/**`, `web/**`
(including `web/next.config.mjs`), plus `render.yaml` and `.env.example`.
Excluded: `.claude/worktrees/`, `.venv/`, `node_modules/`, `web/.next/`.
There is no `deploy/`, no `wsgi*.py` and no `gunicorn*` file in the tracked repo;
Render invokes gunicorn from a `startCommand` string in `render.yaml`.

### 1.1 Core platform

| Variable | Read at | Purpose | Default | render.yaml | .env.example |
|---|---|---|---|---|---|
| `SUPABASE_URL` | `web_app.py:117`, `:334`, `:356`, `:1865`, `:2134`; `src/auth.py:32`, `:54`, `:195`, `:501`; `src/database.py:2017`, `:3499`; `src/storage.py:263`, `:265`; `src/process_runs.py:90`; `src/api/v2/config_routes.py:334`; `src/api/v2/routes.py:156` | The connection URL. **Changed in Phase 0c: now `src/settings.py`.** It used to be *both* the URL and the "are we in Supabase mode" switch — a falsy value silently selected the local SQLite backend (threat model 9.4). The switch is now `DATABASE_BACKEND` / `STORAGE_BACKEND` / `AUTH_BACKEND`, and a backend set to `supabase` with no `SUPABASE_URL` raises instead of falling back. `web_app.py:158` still requires `SUPABASE_URL` unconditionally outside development — an open row in `docs/migration-tracker.md` (Phase 4). | none | yes (`sync: false`) | yes |
| `SUPABASE_SERVICE_KEY` | `src/auth.py:55`; `src/database.py:2018`, `:3499`; `src/storage.py:263`, `:265`; `src/process_runs.py:91`; `scripts/generate_wearbly_order_2026_06_04.py:266`; `scripts/seed_qb_usa_payroll_roster.py:334` | Service-role key. **Bypasses RLS**, which is why every query also carries an explicit `.eq('org_id', …)` | none | yes (`sync: false`) | yes |
| `SUPABASE_ANON_KEY` | `src/auth.py:33` (second in an `or`) | Anon-role client for sign-in and token validation | none | yes (`sync: false`) | yes |
| `SUPABASE_KEY` | `src/auth.py:33`, `:35` | Undocumented alias checked **before** `SUPABASE_ANON_KEY` | none | **no** | **no** |
| `SUPABASE_JWT_SECRET` | **never read** in tracked Python | declared only | yes (`render.yaml:29`, `sync: false`) | yes |
| `SUPABASE_DB_URL` | `src/database.py:2026`; `scripts/migrate_sqlite_to_supabase.py:51`; `scripts/run_migrations.py:72`; `tests/test_pnl_rls_live.py:31` | Direct Postgres DSN for bulk inserts, migrations and RLS tests | falls through to `DATABASE_URL` | yes (`sync: false`) | yes |
| `DATABASE_URL` | `src/database.py:2026` | Fallback DSN | `''` | **no** | **no** |
| `DATABASE_MODE` | **Changed in Phase 0c: now `src/settings.py`.** Previously read at five sites (`web_app.py:332`, `:354`; `src/database.py:3495`; `src/api/v2/config_routes.py:331`; `src/api/v2/routes.py:153`) | `"local"` forced the SQLite backend. It is now a **legacy alias** honoured in one place, and only when `DATABASE_BACKEND` is unset. Tracked for deletion in `docs/migration-tracker.md` (Phase 5a) | `''` | **no** | **no** |

### 1.2 Flask / auth

| Variable | Read at | Purpose | Default | render.yaml | .env.example |
|---|---|---|---|---|---|
| `FLASK_ENV` | `web_app.py:115`, `:166`, `:216`, `:1883`; `src/auth.py:223`, `:496` | Dev-mode gate: ProxyFix, secure-cookie flags, and whether the auth bypass is even eligible | none | yes (hard-coded `value: production`) | **no** |
| `FLASK_SECRET_KEY` | `web_app.py:121`, `:157` | Session signing key. **Falls back to the literal `'dev-fallback-secret-key'` at `web_app.py:157`** | see left | yes (`generateValue: true`) | yes |
| `AUTH_MODE` | `web_app.py:347`; `src/auth.py:499` | Local-dev auth bypass | `''` / `None` | **no** | **no** |
| `AUTH_CACHE_DISABLED` | `src/auth.py:106` | Turns off the in-process permission cache | `''` | **no** | **no** |
| `LOCAL_DEV_ORG_ID` | **Changed in Phase 0c: now `src/settings.py`** (was `web_app.py:348`) | Org id used when the local auth bypass is on. The canonical name | none | **no** | **no** |
| `LOCAL_ORG_ID` | **Changed in Phase 0c: now `src/settings.py`** (was `src/auth.py:592`) | Same concept as `LOCAL_DEV_ORG_ID`, **different name**. `LOCAL_DEV_ORG_ID` is now canonical and `LOCAL_ORG_ID` is a deprecated fallback that logs a warning. Tracked for deletion in `docs/migration-tracker.md` (Phase 4) | none | **no** | **no** |
| `SITE_URL` | `web_app.py:1872` | Base URL for the OAuth `redirect_to` | `'https://www.meridiansgrp.com'` | yes (`sync: false`) | **no** |
| `PUBLIC_APP_URL` | `src/settings.py` (`public_app_url`, ADR 0050) | The app origin every absolute URL is built from (e-mail links, Cognito and QuickBooks callbacks). Wins over `SITE_URL`; ECS sets `https://app.meridiansgrp.com` / `https://staging-app.meridiansgrp.com` | falls back to `SITE_URL`, then `'https://www.meridiansgrp.com'` | no (Render keeps `SITE_URL`) | **no** |
| `PUBLIC_WWW_URL` | `web/src/lib/site-hosts.ts` (ADR 0050) | The public website's origin; with `PUBLIC_APP_URL` set and different, the web service splits www from app | none (no split) | no | **no** |

### 1.3 QuickBooks Online

| Variable | Read at | Purpose | Default | render.yaml | .env.example |
|---|---|---|---|---|---|
| `QBO_CLIENT_ID` | `src/qbo_client.py:31`; `scripts/qb_connect.py:42`, `:78` | OAuth app client id (Basic auth on the token endpoint only) | `''` | **no** | yes |
| `QBO_CLIENT_SECRET` | `src/qbo_client.py:32`; `scripts/qb_connect.py:42` | OAuth app secret | `''` | **no** | yes |
| `QBO_REDIRECT_URI` | `src/qbo_client.py:265`, `:278` | OAuth callback URL | `''` | **no** | yes |
| `QBO_REALM_ID` | `web_app.py:2060`; `scripts/qb_connect.py:53`, `:56`, `:101`; `scripts/qb_fetch_accounts.py:205`, `:237`, `:251` | QuickBooks company id | none | **no** | yes |
| `QBO_ENVIRONMENT` | `scripts/qb_connect.py:100`, `:110`; `scripts/qb_fetch_accounts.py:221`, `:226` | sandbox vs production — **scripts only** | `'sandbox'` | **no** | yes |
| `QBO_ACCESS_TOKEN` | `scripts/qb_connect.py:54`, `:103`; `scripts/qb_fetch_accounts.py:206` | Script-local token cache, written back into `.env` | none | **no** | **no** |
| `QBO_REFRESH_TOKEN` | `scripts/qb_connect.py:55`, `:95` | as above | none | **no** | **no** |
| `QBO_SECRET_ID` | `scripts/qb_fetch_accounts.py:209` | AWS Secrets Manager id | `'mergio/qbo-tokens'` | **no** | yes |
| `QBO_CONFIG_SECRET_ID` | `scripts/qb_fetch_accounts.py:203`, `:224` | AWS secret holding the entity/QBO config roster | none | **no** | yes |

### 1.4 Email, invoicing, misc

| Variable | Read at | Purpose | Default | render.yaml | .env.example |
|---|---|---|---|---|---|
| `EMAIL_BACKEND` | `src/settings.py` (`load_settings`) | **Phase 7.** Which transport sends: `resend` (default, today), `ses`, `disabled`. Unset in a named environment **raises at startup**, like the other three switches | `'resend'` outside a named environment | yes (`value: resend`) | not read here |
| `RESEND_API_KEY` | `src/email_service.py` (`EmailService.__init__`) | Resend API key; falsy disables that transport. **Retired at the Phase 7 flip** | none | yes (`sync: false`) | yes |
| `RESEND_FROM_EMAIL` | `src/email_service.py` (`EmailService.__init__`) | From-address for the Resend transport. **Retired at the Phase 7 flip** | `'noreply@example.com'` | yes (`sync: false`) | yes |
| `MERIDIAN_SES_FROM_EMAIL` | `src/settings.ses_from_address`; injected by `infra/meridian/stacks/compute.py` | The one `From` SES may send as — `no-reply@meridiansgrp.com`. **Not a credential**, and the api task role's `ses:FromAddress` condition names this exact value | none (required when `EMAIL_BACKEND=ses`) | **no** (set by hand at the flip) | — |
| `MERIDIAN_SES_CONFIGURATION_SET` | `src/settings.ses_configuration_set`; injected by `compute.py` | `meridian-shared-ses-default` — carries TLS-required, reputation metrics, the suppression list and the bounce/complaint event destination | none (required when `EMAIL_BACKEND=ses`) | **no** | — |
| `MERIDIANS_ACH_BANK` | `src/app_settings.py:65`; `scripts/build_meridians_invoices.py:59` | Bank name on invoices | `'Chase'` | **no** | **no** |
| `MERIDIANS_ACH_ROUTING` | `src/app_settings.py:66`; `scripts/build_meridians_invoices.py` | **Real bank routing number.** No default; renders blank if unset | none | yes (`sync: false`) | **no** (comment only) |
| `MERIDIANS_ACH_ACCOUNT` | `src/app_settings.py:67`; `scripts/build_meridians_invoices.py` | **Real bank account number.** Same | none | yes (`sync: false`) | **no** (comment only) |
| `MERIDIAN_PORT` | `web_app.py:11555` | Local `app.run` port | `'5050'` | **no** (Render uses `$PORT` in `startCommand`) | **no** |
| `MERIDIAN_OPENAPI_INTROSPECT` | `scripts/generate_openapi.py:1275` — `setdefault` only, never read back | vestigial | — | **no** | **no** |
| `PNL_TIEOUT_FIXTURE` | `tests/test_pnl_workbook_tieout.py:227` | test-only fixture override | none | n/a | n/a |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | **never read** | declared for an integration that does not exist in code — OAuth is brokered by Supabase (§2.3) | — | yes (`render.yaml:35`, `:37`) | yes (blank) |
| `MICROSOFT_CLIENT_ID` / `MICROSOFT_CLIENT_SECRET` | **never read** | as above | — | yes (`render.yaml:39`, `:41`) | yes (blank) |
| `AWS_REGION`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY` | never read explicitly — resolved by boto3's own credential chain for `scripts/qb_fetch_accounts.py` | AWS access for the one Secrets Manager script | boto3 default | **no** | yes (`AWS_REGION=us-east-1`, the other two blank) |

### 1.5 Front end (`web/`)

| Variable | Read at | Purpose | Default |
|---|---|---|---|
| `MERIDIAN_API_ORIGIN` | `web/next.config.mjs:22` | Flask origin the Next.js rewrites proxy `/api/*` and the Jinja route families to | `'http://localhost:5050'` — in `render.yaml` for `meridian-web` (`sync: false`), no `web/.env.example` exists |
| `MERIDIAN_JINJA_AUTH` | `web/next.config.mjs:23` | `"1"` hands `/login` and `/dashboard` back to Flask | falsy; in neither config file |
| `NODE_ENV` | `web/src/components/ui/data-table.tsx:388`; `web/src/components/ui/command-palette.tsx:73` | dev-only console behaviour | set by the platform |

**There are no `NEXT_PUBLIC_*` variables anywhere in `web/`.** Nothing secret is
compiled into the browser bundle, and the browser talks only to same-origin
`/api/v2/*` routes — the Supabase client is server-side only.

### 1.6 Gaps and inconsistencies to carry into Phase 1

**Read by code, declared nowhere** (neither `render.yaml` nor `.env.example`):
`DATABASE_MODE`, `AUTH_MODE`, `AUTH_CACHE_DISABLED`, `LOCAL_DEV_ORG_ID`,
`LOCAL_ORG_ID`, `SUPABASE_KEY`, `DATABASE_URL`, `MERIDIAN_PORT`,
`MERIDIANS_ACH_BANK`, `MERIDIAN_JINJA_AUTH`, `MERIDIAN_OPENAPI_INTROSPECT`.

**Declared but never read:** `SUPABASE_JWT_SECRET`, `GOOGLE_CLIENT_ID`,
`GOOGLE_CLIENT_SECRET`, `MICROSOFT_CLIENT_ID`, `MICROSOFT_CLIENT_SECRET`. Five
secret slots are provisioned on Render for code that does not exist. They should
be removed rather than carried to AWS.

**In `render.yaml` but missing from `.env.example`:** `SITE_URL`,
`MERIDIANS_ACH_ROUTING`, `MERIDIANS_ACH_ACCOUNT`. A developer following the
example file alone would not know the last two exist — and they are real bank
credentials, so this is the right way round, but it should be a deliberate note
rather than an omission.

**Phase 0c steps 19 and 22 — what has since changed in this section.**
`SUPABASE_URL` is no longer a mode switch anywhere: `DATABASE_BACKEND`,
`STORAGE_BACKEND` and `AUTH_BACKEND` (`src/settings.py`) carry that decision,
are validated against an allowed set, and are **required** whenever
`APP_ENV`/`FLASK_ENV` names a non-development environment. All three are in
`render.yaml` and `.env.example`; they must also be set by hand in both Render
dashboards (`docs/migration-tracker.md`). Drift items 1, 2 and 4 below are
fixed: `AUTH_MODE` is compared case-insensitively in one place
(`settings.auth_mode_is_local`), `LOCAL_DEV_ORG_ID` is the canonical name with
`LOCAL_ORG_ID` accepted under a `DeprecationWarning`
(`settings.local_dev_org_id`), and `FLASK_SECRET_KEY` no longer falls back to a
committed literal — production already refuses to start without it, and dev
generates a random per-process key with a warning. Item 3 (bracket access in
`src/database.py`) is unchanged: it is behind the backend switch now, so it is
reached only when the credentials are required anyway.

**Behavioural drift between sites:**

1. **`AUTH_MODE` is compared two different ways.** `src/auth.py:499` uses
   `.get('AUTH_MODE', '').lower() == 'local'` (case-insensitive);
   `web_app.py:347` uses `os.environ.get('AUTH_MODE') == 'local'`
   (case-sensitive). `AUTH_MODE=Local` would enable the bypass in one module and
   not the other.
2. **Two names for one concept.** `web_app.py:348` reads `LOCAL_DEV_ORG_ID`;
   `src/auth.py:592` reads `LOCAL_ORG_ID`. This looks like naming drift, not a
   two-tier fallback. Worth confirming before either is carried forward.
3. **Bracket access vs `.get`.** `src/database.py:2017-2018` uses
   `os.environ['SUPABASE_URL']` / `['SUPABASE_SERVICE_KEY']`, which raises
   `KeyError` if unset, while every other site treats them as optional. (The
   bracket access in `src/storage.py:265` is safe — `:263` guards it first.)
4. `FLASK_SECRET_KEY` silently falls back to a **hard-coded literal**
   (`web_app.py:157`). Fine for dev; it must be impossible in the AWS task
   definition.

---

## 2. Outbound network calls

### 2.1 Intuit QuickBooks Online — `src/qbo_client.py`

The only module in the app that talks to QBO.

| Endpoint | Called by | Sent | PHI? |
|---|---|---|---|
| `https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer` (`src/qbo_client.py:35`) | `_refresh()` `:103-113`, `exchange_code()` `:271-283` | refresh token or auth code, plus client id/secret as HTTP Basic | no |
| `https://appcenter.intuit.com/connect/oauth2` (`:34`) | `authorize_url()` `:259-268` | a browser redirect; no payload | no |
| `{base}/{realm}/query?minorversion=65` | `_query_all()` `:165-179`, used by `account_map()`/`class_map()`/`department_map()` `:197-207`, and `journal_entries_on_date()` `:216-228` | SQL-like query strings naming Account / Class / Department entities; the JE query is a duplicate-post guard on `DocNumber` + `TxnDate` | no |
| `{base}/{realm}/preferences?minorversion=65` (`:209-214`) | `preferences()` | nothing; reads class/location-tracking flags | no |
| **`POST {base}/{realm}/journalentry?minorversion=65`** (`:231-237`) | `create_journal_entry()` | **the only write of business data to QBO** | see below |

`{base}` is chosen per connected row by `_base_url()` (`:153-155`) from the
`environment` column — `https://sandbox-quickbooks.api.intuit.com/v3/company` or
`https://quickbooks.api.intuit.com/v3/company` (`:38-41`). It is **not** a global
env var, so two orgs can be on different Intuit environments at once.

`minorversion=65` is hard-coded at `:172`, `:212`, `:225`, `:235`.

**What a journal entry actually carries.** The body is built by
`src/qbo_je_adapter.build_journal_entry` (pure, no network). Per line:
`Amount`, `PostingType`, `AccountRef.value`, optional `DepartmentRef.value`,
optional `ClassRef.value`, optional `Description` truncated to 4000 characters
(`src/qbo_je_adapter.py:141-159`). The adapter deliberately omits `Id`,
`SyncToken`, `MetaData`, `Entity` and `ProjectRef` (`:74-78`).

**PHI assessment: no.** These are aggregate dollar totals by account,
department and class. No patient identifier and no employee name reaches Intuit.
The `Description` field is the one to keep an eye on — it is free text drawn
from the CSV's description column, today a location/payer/summary label. A
conformance test that asserts no name-shaped value reaches `Description` would
be cheap insurance and does not exist.

**Token handling.** `_ensure_fresh()` (`:135-139`) refreshes with under 120 s of
life left; `_refresh()` checks `refresh_expires_at` first and raises
`QboReconnectRequired` (`:93-101`). Intuit rotates the refresh token on every
use, so both tokens are re-persisted (`:118-133`).

### 2.2 Email — `src/email_service.py`: Resend today, SES behind a switch

Uses the official `resend` SDK (`:67-69`), not a literal URL. `resend.api_key`
is set from `RESEND_API_KEY` (`:57`); `enabled` is false when it is unset and
the service logs "Resend not configured, skipping email" (`:62-63`, `:74`)
rather than failing a run.

Each call sends `from`, `to`, `subject`, `html` (`send()`, `:72-89`).

**Templates — names only; Phase 7 (Resend → SES) must keep all of them:**

| Function | `path:line` |
|---|---|
| `_wrap(content)` — the shared HTML shell every template renders into | `src/email_service.py:23` |
| `send(to, subject, html)` — the low-level sender all templates funnel through | `:72` |
| `send_invite_code(to, code, org_name, role)` | `:91` |
| `send_processing_complete(to, process_type, period, fy, summary)` | `:133` |

That is the complete set — the file is 191 lines and defines nothing else.

**PHI assessment: no.** Invite emails carry an invite code, org name, role label
and a signup link. Completion emails carry a process name, period, fiscal year,
a record count and an aggregate dollar total. Recipients are org members, never
patients. There is **no raw SMTP anywhere** — `smtplib` has zero hits in the
repo.

**Phase 7 — the SES transport (ADR 0025).** `EMAIL_BACKEND` now chooses between
three transports behind the same two templates: `resend` (the default, and what
production still runs), `ses`, and `disabled`. **There is no dual-send mode** —
one event sends exactly one email, so the cutover and the rollback are the same
variable (`docs/runbooks/email-cutover.md`).

The SES transport calls **one** AWS API, `sesv2:SendEmail`, in `us-east-1`, with:

| Field | Value | Why it is here |
|---|---|---|
| `FromEmailAddress` | `MERIDIAN_SES_FROM_EMAIL` | Never a literal; the task role's `ses:FromAddress` condition allows this one mailbox and no other |
| `ConfigurationSetName` | `MERIDIAN_SES_CONFIGURATION_SET` | TLS `REQUIRE`, reputation metrics, suppression list, and the bounce/complaint/reject/rendering-failure event destination. Also an IAM **resource**, so a send without it is denied |
| `Content.Simple` | subject + HTML, UTF-8 | No raw MIME and no attachments |
| `EmailTags` | `env`, `template` | So "which template is bouncing" is answerable from metrics without opening a message |
| `ListManagementOptions` | **not sent** | Marketing subscription management; every message here is transactional |

**Credentials: none read.** boto3 resolves the ECS task role. Retries are
botocore's `standard` mode (5 attempts, throttling only), never a loop.

**Logging:** one line per send, carrying the template name and the SES message
id. **No recipient and no body**, enforced by
`scripts/lint_no_phi_logging.py` and by `tests/test_email_ses.py`'s `caplog`
assertions. An SES failure returns the botocore error **code**, not its message —
the message quotes the recipient address.

**PHI assessment: unchanged — no.** The transport changed; the two templates did
not (`tests/test_email_ses.py` compares them byte for byte across transports).
Bounce notifications on the SNS topic **do** name a recipient, which is why that
topic is classified `internal` rather than `public`.

### 2.3 Google / Microsoft sign-in — brokered by Supabase, not direct

`/auth/google` and `/auth/microsoft` (`api/routers/oauth.py`, FastAPI since Phase 11 G2) both
call `_start(request, provider, label)`, which under `AUTH_BACKEND=supabase` redirects the
browser to (Cognito's hosted domain under `AUTH_BACKEND=cognito`):

```
{SUPABASE_URL}/auth/v1/authorize?provider={google|azure}&redirect_to={SITE_URL}/auth/callback
```

(`azure` is Supabase's provider id for Microsoft Entra ID — see the comment on
`auth_microsoft`.) **The app never calls Google's or Microsoft's OAuth or token
endpoints itself**; there is no `accounts.google.com` or
`login.microsoftonline.com` anywhere in the code. Supabase runs the whole dance
and lands the user back at `/auth/callback` (`api/routers/oauth.py`).

The React login renders these as plain anchors, not fetches
(`web/src/components/login-form.tsx:175-179`, with the reason at `:25`).

This is why `GOOGLE_CLIENT_ID` and friends (§1.4) are never read: the client
credentials are configured **inside the Supabase project**, not in this app. A
migration off Supabase Auth has to recover them from the Supabase dashboard —
they are not in this repo or in `render.yaml`'s values.

### 2.4 Supabase

| Client | Built at | Key | Used for |
|---|---|---|---|
| anon | `src/auth.py:28-37` (`get_supabase()`, memoised `_supabase_client`) | `SUPABASE_KEY or SUPABASE_ANON_KEY` | `sign_in_with_password` `:239-258`, `_fetch_user` `:291-310`, `try_refresh_token` `:313-326`, and `verify_otp` from `web_app.auth_callback` |
| service-role | `src/auth.py:40-59` (`get_supabase_admin()`, memoised `_supabase_admin_client`) | `SUPABASE_SERVICE_KEY` | essentially all data access |
| service-role (database) | `src/database.py:2019` | same | business data |
| service-role (storage) | `src/storage.py:265` | same | the `uploads` and `outputs` buckets |
| scripts | `scripts/generate_wearbly_order_2026_06_04.py:272`, `scripts/seed_qb_usa_payroll_roster.py:338` | same | one-off seeding |

Endpoints reached through the SDK: `{SUPABASE_URL}/rest/v1/…` (PostgREST),
`{SUPABASE_URL}/auth/v1/…`, and Supabase Storage.

**PHI assessment: yes — this is the system of record.** The `transactions`
table carries `patient_id` (`src/database.py:173`), and the payroll tables carry
employee-level wage and allocation data. All of it moves over the service-role
client, which **bypasses RLS** — so the explicit `.eq('org_id', …)` filters in
`src/process_runs.py`, `src/database.py` and `src/api/v2/*` are the actual
tenancy control, and RLS is the backstop. This is stated in the code itself at
`src/run_store.py:32-36` and `supabase_migrations/migrations/022_process_runs.sql:122-125`.

No Supabase client runs in the browser: `web/src/lib/api/*` fetches only
same-origin `/api/v2/*` paths.

### 2.5 NetSuite — not wired

Grepped `netsuite`, `suitetalk`, `restlet`, `nlapi`, `NS_` case-insensitively
across tracked code. **Zero HTTP calls, zero SDK, zero credentials.** Every hit
is one of four things:

1. **CSV file generation** whose output format targets NetSuite's importer —
   `process_revenue.py:5`, `:304-305`, `:565`, plus the booking exporters;
2. **marketing copy** on the public Next.js site, e.g.
   `web/src/app/(marketing)/pricing/page.tsx:68` ("generates NetSuite-compatible
   CSV files that can be imported directly");
3. **a planning document for an integration that does not exist** —
   `docs/processes/netsuite-mcp-admin-setup.md`;
4. **config data** — `department_netsuite` / `netsuite_entity` columns storing
   NetSuite's own codes as mapping values.

**Verdict: NetSuite is a file format, not an integration.** Nothing in the
migration needs a NetSuite network path, credential or egress rule.

### 2.6 Everything else

- **Stripe, Sentry, and all analytics** (GA/gtag/GTM/PostHog/Segment/Mixpanel):
  zero hits. Not wired.
- **Google Fonts** — `<link>` tags in `templates/portal/base.html:11-12`,
  `templates/superadmin/base.html:12`, `templates/public/base.html:12-13`,
  `templates/invoice/preview.html:19-20`. Static assets only, and only on the
  Jinja surface being retired. (Note: `docs/aws-migration-plan.md`'s own PDF
  guidance already says WeasyPrint must use the bundled `static/fonts/` rather
  than the CDN.)
- **Other CDNs allowlisted in the CSP** (`web_app.py:207-213`):
  `cdn.jsdelivr.net`, `cdn.tailwindcss.com`, `unpkg.com`, `cdnjs.cloudflare.com`
  — script/style sources for the Jinja pages. `connect-src` is restricted to
  `'self' https://*.supabase.co` (`web_app.py:214`), so the browser can only
  make data calls to the app and to Supabase.

---

## 3. The two QuickBooks credential paths

The plan (`docs/aws-migration-plan.md:302`) flags this as an open question. The
answer from the code is that they are **two independent, non-overlapping paths,
and only one of them is the application's.**

### Path A — what the app uses

`qbo_connection`, added by
`supabase_migrations/migrations/035_qbo_connection.sql`:

| Column | Notes |
|---|---|
| `id` | `SERIAL` PK |
| `org_id` | `UUID` → `organizations` |
| `realm_id` | `TEXT` — the QuickBooks company |
| `environment` | `TEXT`, `'sandbox'` or `'production'` |
| `access_token` | **secret** |
| `refresh_token` | **secret** |
| `access_expires_at` | `TIMESTAMPTZ` |
| `refresh_expires_at` | `TIMESTAMPTZ`, nullable |
| `connected_by` | `UUID`, nullable |
| `created_at`, `updated_at` | `TIMESTAMPTZ` |

Unique on `(org_id, realm_id)`; RLS on with `qbo_connection_org_isolation`
scoped by `org_id = user_org_id()`. The migration's own comment records that the
tokens are read and written server-side only via the service-role client, never
logged and never returned to a browser.

`QboClient._load_row()` (`src/qbo_client.py:72-84`) reads that row, and
`_url()` / `_base_url()` / `_headers()` all derive from it. **Every API call's
realm, environment and bearer token come from Postgres.**

The `QBO_*` env vars supply only the static app-registration values —
`QBO_CLIENT_ID`, `QBO_CLIENT_SECRET` (`src/qbo_client.py:31-32`) for the Basic
auth on the token endpoint, and `QBO_REDIRECT_URI` (`:265`, `:278`) for the
OAuth callback. The module docstring (`src/qbo_client.py:5-9`) says why the
tokens cannot live in `.env`: gunicorn runs several workers and Intuit rotates
the refresh token on every use, so a value read once at process start goes stale
immediately.

**So: env vars for the static client identity; the database for everything
connection-specific. The database wins for realm, environment and tokens.**

### Path B — what the app does not use

`mergio/qbo-tokens` in AWS Secrets Manager appears in exactly one runtime file:
the standalone CLI `scripts/qb_fetch_accounts.py`, which imports `boto3` inside
a function so `--help` works without it (`:46-47`) and defaults
`--secret` to `os.getenv("QBO_SECRET_ID", "mergio/qbo-tokens")` (`:209`).

Nothing in `src/`, `web_app.py` or `process_*.py` imports that script. Migration
035's own header cross-references the secret precisely to say the app must not
depend on it, and `docs/aws-migration-plan.md:46` records that it is
Mergio-owned and read-only from here.

**Verdict: `mergio/qbo-tokens` is not an application dependency.** It is one
developer-facing script. No AWS Secrets Manager or boto3 reference exists in any
code path reachable from a running request.

---

## 4. Legacy JSON (and XLSX) config files in `config/`

| File | Tracked? | Still read by | Notes |
|---|---|---|---|
| `app_settings.json` | yes | `src/app_settings.py:85` (default path), `src/booking_je_exporter.py:42`, `web_app.py:8243`, `:8259`, `:8480`, `:8942` | **Live.** The invoice/company block; `src/app_settings.py:65-67` layers the three `MERIDIANS_ACH_*` env vars over it so the bank numbers never enter the file |
| `mso_mappings.json` | yes | `web_app.py` (`MSO_MAPPINGS_FILE`, the config screen) | **Live**, for the MSO/ADP config tab; its only JE reader, `src/adp_je_generator.py`, was deleted 2026-09-22 with the Jinja `/adp_payroll` wizard (CX-API-03) |
| `mappings.xlsx` | no (only `mappings.example.xlsx` is tracked) | `src/config.py:83` (`Config` default), `:179`, `:204`, `:224`, `:244`, `:293`, `:368` | **Live but demoted.** `load_enrichment_config` (`src/config.py:368-400`) takes provider/location/payer maps from the org-scoped `config_providers`/`config_locations`/`config_payers` tables and uses the workbook only as a fallback. The fallback is never silent: `mappings_source` becomes `"workbook"` and the log line is `ERROR` (`:393-398`). `settings`, `account_codes`, `fiscal_calendar` and `clinic_groups` are **still workbook-only** |
| `employee_allocations.json` | no (`.example.json` is) | `src/database.py:540`; `web_app.py:9277-9284` | **Seed only** — a one-time migration into Supabase |
| `mx_employee_roster.json` | no (`.example.json` is) | `src/payroll_processor.py:378`, `:1547`; `src/database.py:3338`; `web_app.py:7516` | **Live** for MX payroll department lookups, plus a one-time Supabase seeder |
| `provider_maps.json` | no (`.example.json` is) | `src/config.py:487`, with a warning-and-fall-back-to-example at `:497` | **Live**; missing file degrades to the redacted example |
| `ts_benefit_overrides.local.json` | no (gitignored) | `src/qb_usa_payroll_maps.py:25` (`BENEFIT_OVERRIDES_PATH`) | **Live, and deliberately untracked** (`:11`). Note migration 036 adds `ts_benefit_override_fixed_pool`, so this one is mid-migration |

Every one of these is a file on an **ephemeral Render disk today**. Only
`app_settings.json` and `mso_mappings.json` are tracked, so the rest must be
recreated by hand on any new machine or container — which is itself the
argument for the plan's "all config in the database" rule.

**Consequence for the migration:** a container that starts with an empty
`config/` loses the MX roster, the provider maps, the benefit overrides, and —
for `settings`, `account_codes`, `fiscal_calendar` and `clinic_groups` — the
only copy of the fiscal calendar. `load_enrichment_config` will log an `ERROR`
and fall back to a shared, non-org-scoped workbook rather than fail, which is
the quiet failure mode to close before cutover.
