# Custody record — the retained Supabase archive (TEMPLATE)

**Status: TEMPLATE, unsigned.** Filled in and signed by Andres (custodian and security
official) **before** the Phase 10 archive is taken — the record has to exist before the
dump does (`docs/migration-tracker.md`, the custody-record row). The signed copy goes into
the Evidence set (`~/Business/Meridians Logic/Company/Compliance/`, control-matrix §1); this
file stays in the repository as the blank form and **never** holds a value from the archive
itself (no patient identifier, no key, no bucket content).

Source of every rule below: `docs/runbooks/decommission-supabase-render.md` step 2
("Retention and custody, written down, not implied") and plan §6. Where this form and the
runbook disagree, the runbook wins and this form is corrected.

---

## 1. What is held

| Field | Value |
|---|---|
| Archive | Final `pg_dump` of the Supabase project, taken at Phase 10 step 2 |
| Contents (class) | **PHI.** Patient identifiers, the `auth` schema, the `storage` metadata (names, sizes, MIME types — not the object bytes) |
| Supabase project reference | `____________________` |
| Dump taken (UTC) | `____-__-__ __:__` |
| Dump tool and version | `pg_dump ______` (≥ 17.6) |
| SHA-256 of the dump file | `________________________________________________________________` |
| Object location | `s3://meridian-production-s3-archive/________________________` |
| Object version id | `____________________` |
| Encryption | SSE-KMS on the **`phi`** CMK (key id `____________________`) |
| Object Lock | Compliance mode, retain-until `____-__-__` (seven years from upload) — paste the `aws s3api get-object-retention` output below |

```text
(get-object-retention output, pasted verbatim)
```

**Not in this archive, and where it is instead:** the storage objects themselves. Their
custody record is the versioned, KMS-encrypted `meridian-production-s3-artifacts` and
`meridian-production-s3-phi` buckets, evidenced by `cutover.md` step 4's `sync` output and
its zero-`MISSING` `head_object` sweep, filed with the Phase 9 report.

## 2. Custody

| Field | Value |
|---|---|
| Custodian | Andres Santos |
| Delegate (if the custodian is unavailable) | `____________________` (none named yet — needs-a-human row 42) |
| Who may read it | The custodian, for a documented reason, logged in the monthly activity review |
| Retention | **Seven years from the upload date**, enforced by Object Lock — not by policy, not by intention (HIPAA's six-year documentation retention, 45 CFR 164.316(b)(2), plus slack) |
| Disposal | Per the Track C disposal procedure, **after** the retention expires. Never before; Object Lock makes "before" impossible anyway |
| The sentence that must never appear on this record | *"delete after verification"* |

## 3. Copies

Every copy is PHI. The S3 object is **the** archive; any other copy is a second thing that
can leak.

| Copy | Location | Created | Shredded (date, method) | By |
|---|---|---|---|---|
| Working copy on the encrypted laptop volume | `/Volumes/MeridianPHI/…` | `____-__-__` | `____-__-__`, `________` | |
| S3 object (the archive) | as §1 | `____-__-__` | **never** — retained | — |

## 4. Access log

One row per read of the archive after it is locked.

| Date (UTC) | Who | Why | Ticket / note |
|---|---|---|---|
| | | | |

## 5. Signature

I confirm the archive described above exists, is held under the retention and custody
stated, and that I am its custodian.

Name: Andres Santos · Role: security official, custodian

Signature: ______________________ · Date: ____-__-__
