# Meridian — Threat Model (STRIDE)

**Status:** draft for review · **Owner:** Andres Santos (named security official, Track C item 4)
**Date:** 2026-09-15 · **Last reviewed:** 2026-09-16 (Phase 8 — §13) · **Branch:** `aws-migration`
**Delivers:** `docs/aws-migration-plan.md` Phase 0 step 11 (threat model, one page per trust boundary).
**Line citations:** every `path:line` below **cites commit `4ccddcb`**. Later commits reformat
and fix those files, so check a citation with `git show 4ccddcb:<path>`, not the working tree.

---

## 0. How to read this document

### What a threat model is

A threat model is a written list of *the ways this system could be attacked or could fail
in a way that harms someone*, plus what we do about each one. It is not a bug list and not
a penetration test. It is the document an auditor asks for first, and the document that
tells us which controls in the migration plan are load-bearing rather than nice to have.

### STRIDE, defined

STRIDE is a checklist of six kinds of threat. For every boundary we walk the same six
letters, so nothing is skipped because nobody thought of it:

| Letter | Name | Plain meaning |
|---|---|---|
| **S** | Spoofing | Pretending to be someone (or something) you are not. |
| **T** | Tampering | Changing data or code you are not allowed to change. |
| **R** | Repudiation | Doing something and being able to deny it, because nothing recorded it. |
| **I** | Information disclosure | Seeing data you should not see — for us, mostly PHI and payroll. |
| **D** | Denial of service | Making the system unavailable or unusably slow. |
| **E** | Elevation of privilege | Turning a small amount of access into a large amount. |

### Trust boundary, defined

A **trust boundary** is a line in the architecture where data or a request passes from
something we trust less into something we trust more (browser → our edge; our API → our
database; our Lambda → a third party). Attacks happen at boundaries, so the model has one
section per boundary rather than one per component.

### Other jargon used below, defined on first use

- **SSRF** (Server-Side Request Forgery): tricking *our* server into making a request to an
  address of the attacker's choosing — typically an internal address such as the cloud
  metadata service at `169.254.169.254`, which hands out credentials.
- **mTLS** (mutual TLS): normal HTTPS proves the *server's* identity to the client; mutual
  TLS also makes the *client* present a certificate, so only a named partner can connect.
- **RLS** (Row Level Security): a PostgreSQL feature where the database itself refuses to
  return rows that do not match a policy — here, rows belonging to another organization.
- **Prefix list**: an AWS-maintained, automatically updated list of IP ranges (here,
  CloudFront's) that a firewall rule can reference by name instead of by address.
- **Replay**: capturing a valid request or webhook and sending it again later to make the
  effect happen twice.
- **Presigned URL**: a normal HTTPS link to a file in S3 that carries a short-lived
  signature instead of a login — anyone holding the link holds the file until it expires.
- **KMS / CMK**: AWS Key Management Service; a customer-managed key is an encryption key
  whose policy we write and whose use is logged.
- **pgaudit**: a PostgreSQL extension that writes an audit line for statements we choose,
  so "who read what" is recoverable.
- **Client credentials**: an OAuth2 flow where a *machine* (no human, no browser) presents
  an id and a secret and receives a short-lived access token.
- **Idempotency**: sending the same request twice produces one effect, not two. It is the
  difference between booking a journal entry once and booking it twice.
- **Fails closed**: when a dependency is unavailable, the system refuses the operation
  rather than letting it through unchecked. The opposite (fails open) is how outages turn
  into breaches.

### Ratings

**Likelihood** and **Impact** are H/M/L, judged for *this* system: two workforce members
(D-04), one covered-entity customer, PHI in scope (plan §1 "PHI: resolved as YES"), and
money — a journal entry booked wrong is a real accounting error. Impact is H when the
outcome is PHI disclosure, cross-organization data access, or a wrongly booked close.

### Evidence

Every row names the artifact that will *prove* the mitigation exists: a test name, a CDK
construct, an alarm, or an audit table. A mitigation with no evidence artifact is an
intention, not a control. Where a test does not exist yet the name given here is the name
it should be created under, so the control matrix and the test suite agree.

### Scope

Sections 1-8 model the **target** architecture (plan §2.5). Section 9 models **today's**
system on Render + Supabase, grounded in code read on this branch. Section 10 maps the
OWASP API Security Top 10 (2023). Section 11 lists gaps the plan does not currently close.

---

## 1. Boundary — browser → CloudFront / WAF

**What crosses it.** Every human request: sign-in, the Next.js app, `/api/*` calls carrying
the session cookie, multipart uploads of billing exports and payroll registers (PHI in the
request body), and downloads of generated journal entries.

**Trust change.** The public internet (untrusted, unauthenticated, unbounded) becomes a
request inside our distribution. CloudFront + AWS WAF (managed core rule set, IP-reputation
rules, rate-based rules) and Shield Standard are the only controls in front of it
(plan §2.5 diagram; §2.4 "Isolation, concretely" → *Ingress*).

| # | STRIDE | Threat | L | I | Mitigation (plan cite) | Evidence artifact | Phase |
|---|---|---|---|---|---|---|---|
| 1.1 | S | Stolen session cookie replayed from another machine | M | H | ID token 60 min in an HttpOnly cookie with a 12-hour refresh, down from Supabase's 7 days (§2.1); `SESSION_COOKIE_SAMESITE='Lax'` (contract §6.1); `FLASK_ENV=production` so the `Secure` flag is on (§2.5 load-bearing constraints) | `tests/security/test_session_cookie_flags.py`; ECS task-definition env in the `compute` stack | 4, 5a |
| 1.2 | S | Credential stuffing / password spray against sign-in | H | H | Cognito threat protection `AUDIT` → `ENFORCED`, `PreventUserExistenceErrors=ENABLED`, MFA `ON` with TOTP for both workforce members (§2.1); WAF rate-based rule + progressive lockout on auth failures (Phase 12 step 8) | Cognito pool CDK construct; CloudWatch alarm on Cognito `SignInThreatScore`; `tests/security/test_auth_lockout.py` | 4, 12 |
| 1.3 | S | Phishing of the federated superadmin (azure-only) | M | H | MFA required on the pool; IdP accounts pre-linked so no duplicate account exists to phish into (§2.1) | Phase 4 pre-link runbook + `AdminLinkProviderForUser` output recorded | 4 |
| 1.4 | T | Cross-site request forgery — a third-party page makes the browser book a journal entry with the ambient cookie | M | H | Global `CSRFProtect`, v2 blueprint deliberately **not** `csrf.exempt`; `XSRF-TOKEN` non-httpOnly cookie; `WTF_CSRF_TIME_LIMIT=None` tied to session (contract §6.1); `SameSite=Lax` as defence in depth | `tests/security/test_csrf_required_on_mutations.py`; `CSRF_INVALID` in the §4 code catalogue | 5a |
| 1.5 | T | Stored/reflected XSS stealing the session | L | H | Session cookie is HttpOnly; strict security headers and a strict CORS allowlist on every response (Phase 12 step 8); React escapes by default | `tests/security/test_security_headers.py`; ZAP baseline scan | 12 |
| 1.6 | R | A user denies uploading the file that produced a wrong close | M | M | CloudFront + ALB access logs to an Object-Locked bucket; `process_runs` row per run with the acting user; `artifact_downloads` audit row per signed URL minted (contract §8, §7.2) | `audit` bucket with Object Lock; `process_runs`, `artifact_downloads` tables | 6 |
| 1.7 | I | PHI in a URL, and therefore in access logs, browser history and referrers | M | H | Uploads are multipart bodies, downloads are presigned S3 URLs with opaque keys; ids only in paths, never patient identifiers (§2.3; contract §7) | `scripts/lint_no_phi_logging.py`; access-log review in the monthly activity review (Track C item 6) | 0, 6 |
| 1.8 | I | Verbose errors leaking stack traces, SQL or the existence of another org's data | M | M | One error envelope for every `/api/*` path; cross-org reads return `404`, never `403` (contract §4.1, §8); "errors never leak stack traces, SQL, internal ids or cross-org existence" (Phase 12 step 8) | `tests/security/test_error_envelope_leaks.py`; ZAP baseline | 5a, 12 |
| 1.9 | D | Volumetric or application-layer flood | M | M | Shield Standard (free) + WAF managed rules + rate-based rules at the edge; per-user rate limits behind it (contract §9) | WAF web ACL construct; CloudWatch alarm on `BlockedRequests` | 2, 12 |
| 1.10 | D | Upload-based exhaustion (very large or many files) | M | M | `MAX_CONTENT_LENGTH` → `413 FILE_TOO_LARGE` (contract §4.2); create limited to `10/minute`, `60/hour` per user, the hourly cap explicitly there to bound storage (contract §9); presigned upload URLs carry size and type limits (Phase 12 step 1) | `tests/security/test_oversized_payload.py`; S3 bucket metric alarm | 5a, 12 |
| 1.11 | E | Reaching an admin-only route by URL guessing | L | H | `@require_auth` + `@require_org` + `@require_role('admin')` on every admin route (already the house style, e.g. `web_app.py:2432-2436`); scopes enforced by one dependency, never ad hoc per handler (Phase 12 step 2) | `tests/security/test_route_authz_matrix.py` | 5a, 12 |

**Residual risk.** A stolen *unexpired* cookie on an already-authenticated device is not
detectable at this boundary; the 60-minute lifetime bounds it. WAF managed rules generate
false positives on large multipart uploads — tune in staging before Flip 2, and record the
tuning, because "we disabled the rule" is a finding if it is not written down.

---

## 2. Boundary — CloudFront → ALB → ECS

**What crosses it.** Every request CloudFront forwards, stamped with an origin-verify
header and an `X-Forwarded-For` chain. Two proxies sit in the chain: CloudFront, then the
ALB.

**Trust change.** "A request from the internet" becomes "a request our application will
act on, with a client IP it trusts for rate limiting and logging".

| # | STRIDE | Threat | L | I | Mitigation (plan cite) | Evidence artifact | Phase |
|---|---|---|---|---|---|---|---|
| 2.1 | S | Attacker hits the ALB DNS name directly, bypassing WAF and the edge rate limits | H | H | ALB security group admits **only** CloudFront's managed prefix list; an origin-verify header rule rejects direct hits (§2.4 *Ingress*) | ALB SG + listener-rule CDK constructs; `tests/security/test_origin_verify.py` (direct ALB request → 403) | 2 |
| 2.2 | S | Origin-verify header value leaks and is replayed | L | M | Value in Secrets Manager, rotatable; prefix-list SG still stands alone as a second control (§2.4; §2.5 "no plaintext credentials in `environment:`") | Secrets Manager secret + rotation note in the `compute` stack | 2, 8 |
| 2.3 | S | Spoofed `X-Forwarded-For` so rate limits and logs record a chosen IP | H | M | `ProxyFix(x_for=2)` — CloudFront and the ALB are two proxies. `x_for=1` re-creates the rate-limit-keys-on-edge-IP bug that commit `71decf2` fixed (§2.4 *Ingress*). **Today's code sets `x_for=1`** (`web_app.py:168`), correct for one proxy and wrong the moment CloudFront is in front | `tests/security/test_proxyfix_client_ip.py` asserting the client IP from a two-hop `X-Forwarded-For`; task-definition diff | 5a |
| 2.4 | T | Request smuggling / header injection between the two proxies | L | H | Managed CloudFront + ALB terminate and re-serialize HTTP; WAF managed core rule set; HTTP:80 → 301 only (§2.5) | ZAP baseline; ALB listener config | 2, 12 |
| 2.5 | T | An in-flight deploy serves half-old, half-new behaviour mid-close | M | H | `desiredCount: 1`, `maximumPercent: 100`, `minimumHealthyPercent: 0` until Phase 11 — deliberately a hard 3-6 minute outage rather than two tasks running at once, because two tasks mis-book journal entries silently (§2.5; `src/run_store.py:1-12` documents the failure) | `HealthyHostCount > 1` alarm on the api target group; CDK comment carrying the constraint | 5a |
| 2.6 | R | No record of which task served a request that produced a bad JE | M | M | ALB access logs on; structured logs with `request_id` (contract §4.1); `process_runs` carries the run (§2.5, Phase 6) | ALB access-log bucket; `request_id` present in every error envelope | 6 |
| 2.7 | I | ALB target group reachable from another workload in the shared account | M | H | Own VPC per environment, no peering, no shared NAT; IAM conditioned on `aws:ResourceTag/Environment`; nothing in staging can read a production ARN (§2.4) | `network` stack per env; IAM policy conditions; `tests/infra/test_no_cross_env_arns.py` | 1, 2 |
| 2.8 | I | Plaintext credentials visible in the task definition | M | H | "No plaintext credentials in `environment:`; everything credential-bearing via `secrets:` from Secrets Manager" (§2.5) | `tests/infra/test_no_plaintext_secrets_in_taskdef.py`; AWS Config rule | 2, 8 |
| 2.9 | D | One task, one point of failure — a crash is an outage | M | M | Accepted by decision: RTO 8 business hours / RPO 1 hour, single-AZ (D-14); ECS restarts the task; alarms on unhealthy host count and 5xx rate (Phase 6) | `HealthyHostCount` and `5xx` alarms; DR drill record (Track C item 9) | 6 |
| 2.10 | E | Container escape or compromised image reaching AWS credentials | L | H | Task roles `meridian-<env>-ecs-api-task` / `-worker-task` / `-web-task` with no wildcard actions, conditioned on environment tag; execution role separate (§2.4) | IAM role documents in the `compute` stack; `tests/infra/test_task_role_no_wildcards.py` | 2 |

**Residual risk.** The origin-verify header is a shared secret in a header — it stops
casual direct hits, not an attacker who has already read our secrets. The prefix-list SG is
the control that actually holds. Until Phase 11, `desiredCount: 1` means availability is
traded for correctness on purpose; that trade must appear in the contingency plan, not just
in the CDK.

---

## 3. Boundary — api → RDS PostgreSQL

**What crosses it.** Every query the application makes, over TLS inside the private data
subnets, as the `meridian_app` role — and, only through `src/phi.py`, as `phi_access`.

**Trust change.** "Application code, with a user's org in `g.org`" becomes "rows returned
from a database that holds every organization's payroll and every patient identifier".

| # | STRIDE | Threat | L | I | Mitigation (plan cite) | Evidence artifact | Phase |
|---|---|---|---|---|---|---|---|
| 3.1 | S | Stolen database credentials used from outside | L | H | `PubliclyAccessible=false`, private data subnets, `rds.force_ssl=1`, **no inbound ports anywhere** — `psql` only via SSM Session Manager port-forwarding to an SSM-managed `t4g.nano` with zero SG ingress (§2.4) | `data` stack RDS + SG constructs; `tests/infra/test_rds_not_public.py` | 3 |
| 3.2 | T | SQL injection through a hand-written statement | M | H | Raw SQL behind the repository layer with parameters everywhere; parameterized `ILIKE` for the 4 `.or_()` filters, "fixing an injection bug" (§2.2); `COPY` never `execute_values` for `phi.*` bulk writes | `tests/security/test_sql_injection_repository.py`; `scripts/lint_org_scope.py` | 5a |
| 3.3 | T | A dropped `WHERE org_id` writes or reads another org's rows | **H** | H | Two layers, both required: (a) explicit `org_id` predicate on every statement, enforced by `scripts/lint_org_scope.py` against a schema-generated `scripts/tenant_tables.txt` (~50 tables); (b) Postgres RLS with `FORCE ROW LEVEL SECURITY`, policies `USING (org_id = current_setting('app.org_id', true)::uuid)`, under `meridian_app` which is **not** the table owner and has no `BYPASSRLS` (§2.2, D-10) | `tests/test_run_isolation.py` and `tests/test_pnl_rls_pg.py` ported to the RDS fixture; `scripts/lint_org_scope.py` in CI | 3, 5a |
| 3.4 | T | `app.org_id` leaks across pooled connections, so one user's request runs with another's org | M | H | Set session-level on checkout (`SET app.org_id = %s`) because the layer is autocommit and `SET LOCAL` needs a transaction; **`RESET app.org_id` unconditionally on return to the pool**, the same shape as `RESET ROLE` in `src/phi.py` (§2.2) | A test that checks out a connection after a scoped operation and asserts `current_setting('app.org_id', true)` is empty (§2.2 names it) | 3 |
| 3.5 | R | A PHI read with nothing recording it | M | H | Every PHI touch goes through `src/phi.py`: `SET ROLE phi_access` → write `audit.phi_access` row → execute → `RESET ROLE` in a `finally`. `meridian_app` gets INSERT-only on `audit.phi_access` so the application cannot erase its own trail (§2.3) | `audit.phi_access` table (who/what/when/row count/request_id/ip — **never PHI values**); `tests/security/test_phi_access_audited.py` | 3, 6 |
| 3.6 | R | DDL or role changes made by hand and later denied | L | M | `pgaudit.log='ddl,role,write'` instance-wide; `ALTER ROLE phi_access SET pgaudit.log='read,write'` so reads are audited on the one role that can perform them (§2.3) | RDS parameter group; log group retention; monthly activity review (Track C item 6) | 3, 6 |
| 3.7 | I | Application role reads PHI directly, bypassing the audit path | M | H | `meridian_app` has **zero grants** on the `phi` schema; only `phi_access` holds SELECT/INSERT there (§2.3) | Grant matrix in Alembic revision 0003; `tests/security/test_meridian_app_cannot_read_phi.py` | 3 |
| 3.8 | I | PHI values land in Postgres logs | M | H | `COPY`, never `execute_values`, for every `phi.*` bulk write, because psycopg2 interpolates literals client-side and they would land in the logs (§2.2) | Code review gate + `scripts/lint_no_phi_logging.py`; a log sample check in the Phase 8 evidence pack | 5a, 8 |
| 3.9 | I | Backups or snapshots read by someone who should not | L | H | One CMK each for RDS, `artifacts`, `phi`, logs, backups, with key policies naming only that environment's roles; AWS Backup 35-day locked vault with cross-region copy (§2.4) | KMS key policies in the `data` stack; restore drill record | 3, 6 |
| 3.10 | D | A runaway query or connection exhaustion on a `t4g.small` single-AZ instance | M | M | Single-AZ accepted (D-14); per-user rate limits bound request volume (contract §9); alarms on CPU, connections and replica lag equivalent (Phase 6) | CloudWatch alarms; RTO/RPO drill (Track C item 9) | 6 |
| 3.11 | E | A superadmin or cross-org admin path used as a general-purpose bypass | M | H | Bypass exists **only through one named function, which writes an audit row** (§2.2) | `audit` row per bypass; `tests/security/test_superadmin_bypass_audited.py` | 3 |

**Residual risk, stated plainly.** Plan §2.2's own honest note applies: raw SQL's safety
model is discipline plus a lint, applied **202** times (`.table(` call sites counted on this
branch — 194 in `src/` + `web_app.py`, 8 in `scripts/`; `inventory-data-layer.md` is the
authoritative count), by a solo developer still learning. RLS is the backstop and is the reason to pay
the 3-5 extra days. If a parity diff catches a mis-scoped transcription, §2.2's escape
hatch (SQLAlchemy Core at the repository boundary) is the response, not more discipline.

---

## 4. Boundary — api / worker → S3

**What crosses it.** Uploaded billing and payroll workbooks (PHI), generated journal-entry
CSVs, explanatory workbooks, ZIP bundles, and the presigned URLs that let a browser fetch
them without our servers in the path.

**Trust change.** Bytes from a user, and bytes we generate, become durable objects — and a
presigned URL turns an authorization decision into a bearer link that works for anyone who
holds it until it expires.

| # | STRIDE | Threat | L | I | Mitigation (plan cite) | Evidence artifact | Phase |
|---|---|---|---|---|---|---|---|
| 4.1 | S | A presigned URL forwarded, logged or pasted into a ticket, then used by someone else | **H** | H | Short TTLs — 120 s for a single file, 300 s for a bundle (`src/storage.py:21-22`, carried forward); every mint is rate-limited (`30/minute`, `200/hour`) and writes an audit row (contract §9, §7.2) | `artifact_downloads` rows; `tests/security/test_signed_url_expiry.py` | 5a |
| 4.2 | T | Path manipulation writes or reads another org's prefix | M | H | Every path is `{org_id}/{batch_id}/{subfolder}/{file}`; before signing, the handler asserts the first segment equals `g.org['org_id']` — "a signed URL bypasses RLS, so this check is the only thing standing between a path-manipulation bug and cross-tenant salary data" (contract §8 layer 4). Implemented today as the single choke point `assert_org_path` (`src/storage.py:36-51`), which deliberately does not echo the requested path back | `tests/security/test_assert_org_path.py`; `StoragePathError` on the wrong first segment | 5a |
| 4.3 | T | A malicious upload (macro-bearing or crafted workbook) processed by the worker | M | H | GuardDuty Malware Protection scans every uploaded object; **nothing is processed until tagged clean** (§2.3, addition from the prompt) | GuardDuty malware-scan finding + object tag check in the worker; `tests/security/test_unscanned_object_not_processed.py` | 8 |
| 4.4 | T | Objects overwritten or deleted, destroying the evidence of a close | M | H | Versioning + AWS Backup on the buckets; the audit/log bucket is Object-Locked (policy retention six years — "400-day log groups do not" satisfy it, Track C item 13) | Bucket versioning + Object Lock constructs | 2, 6 |
| 4.5 | R | No record of who downloaded a payroll bundle | M | M | Every mint creates a bearer URL **and an audit row** (contract §9, download-mint class); S3 server access / CloudTrail data events | `artifact_downloads`; CloudTrail S3 data events | 6 |
| 4.6 | I | Bucket or object readable publicly | L | H | Block Public Access; SSE-KMS enforced with a bucket policy that denies unencrypted `PutObject`; separate `artifacts` and `phi` buckets with separate CMKs (§2.3, §2.4) | `tests/infra/test_bucket_public_access_blocked.py`; `tests/infra/test_sse_kms_enforced.py`; AWS Config rules | 2 |
| 4.7 | I | PHI stored where the tokenized model says it should not be | M | H | The raw workbook and the permission-gated detail export land in the **`phi` bucket**; the default export is tokenized (§2.3, P-2) | Phase 0 data-flow diagram (step 5); bucket-per-classification in the `data` stack | 0, 3 |
| 4.8 | D | Storage growth from repeated uploads | L | L | `10/minute`, `60/hour` create limit explicitly bounds storage (contract §9); lifecycle rules on temp prefixes | Bucket lifecycle policy; cost anomaly alarm (§2.4) | 5a |
| 4.9 | E | Worker task role usable to read the `phi` bucket when it should not | M | H | Task roles are separate (`-api-task`, `-worker-task`, `-web-task`) with no wildcard actions; the `phi` CMK's key policy names only the roles that may use it (§2.4) | KMS key policy; `tests/infra/test_web_task_cannot_read_phi_bucket.py` | 2 |

**Residual risk.** A presigned URL is a bearer credential by design. 120 seconds is short,
but a screen-shared browser or a URL pasted into a chat is still a disclosure; the audit row
is what makes it *detectable*, not preventable.

---

## 5. Boundary — User Migration Lambda → Supabase Auth

**Transition only.** This boundary exists between Phase 4 (Cognito live) and Phase 10
(Supabase decommissioned). It is the only path by which a plaintext password leaves Cognito,
and the only remaining runtime dependency on the old identity provider.

**What crosses it.** A username and the password the user just typed, sent from a Lambda
outside the VPC to Supabase Auth, once per user, at that user's first Cognito sign-in
(§2.1, D-06).

| # | STRIDE | Threat | L | I | Mitigation (plan cite) | Evidence artifact | Phase |
|---|---|---|---|---|---|---|---|
| 5.1 | S | The trigger is used as a password-verification oracle (spray via first-login attempts) | M | H | The trigger only fires under `ADMIN_USER_PASSWORD_AUTH`; Cognito threat protection and `PreventUserExistenceErrors=ENABLED` in front of it; WAF/lockout on auth failures (§2.1; Phase 12 step 8) | Cognito pool config; `tests/security/test_migration_lambda_no_oracle.py` | 4 |
| 5.2 | S | A migrated user is created with the wrong `custom:app_uid` and inherits another person's data | L | **H** | `custom:app_uid` is String(36) **immutable**, set from the legacy Supabase UUID at creation; `verify()` returns `claims.get('custom:app_uid') or claims['sub']` so no application row is ever rewritten (§2.1) | `tests/security/test_app_uid_immutable_and_unique.py`; migration percentage report (`ListUsers` diffed against `legacy_users.json`, weekly) | 4 |
| 5.3 | T | Man-in-the-middle on the Lambda → Supabase call | L | H | HTTPS only, dependency set limited to `urllib3`/stdlib — a deliberately tiny supply-chain surface (§2.1) | Lambda package manifest; `tests/security/test_migration_lambda_deps.py` | 4 |
| 5.4 | R | No record of which accounts migrated when | M | M | Migration percentage reported weekly from `ListUsers` diffed against `legacy_users.json`; CloudTrail + Lambda logs (§2.1) | Weekly migration report artifact | 4 |
| 5.5 | I | **The password is logged** | M | **H** | "never logs passwords" is a stated requirement of the Lambda (§2.1) | Code review + `tests/security/test_migration_lambda_never_logs_password.py`; a log-scan check in the Phase 8 evidence pack | 4, 8 |
| 5.6 | D | Supabase outage during the transition blocks all first logins | M | M | **Fails closed on a Supabase outage with a clear error** (§2.1) — an outage becomes a refusal, not an unchecked admission. Supabase Auth stays live and paid until Phase 10's cut-off date; after it, unmigrated users get a password reset instead | `tests/security/test_migration_lambda_fails_closed.py`; the Phase 10 cut-off date recorded | 4, 10 |
| 5.7 | D | The 5-second Cognito trigger timeout is exceeded and every first login fails | M | M | 5-second Lambda timeout, kept outside the VPC (no ENI cold-start penalty), **p99 measured on staging before the production flip** (§2.1) | Staging p99 measurement recorded; Lambda `Duration` p99 alarm | 4 |
| 5.8 | E | Federated-only users get a silently duplicated empty account during migration | M | H | The trigger never fires for federated sign-in; the google-only member, the azure-only member and the **azure-only superadmin** are pre-created with `AdminCreateUser` (`MessageAction='SUPPRESS'`) and linked with `AdminLinkProviderForUser` **before the IdPs are enabled** (§2.1) — see §7 | Phase 4 pre-link runbook output; `tests/security/test_no_duplicate_federated_users.py` | 4 |

**Residual risk.** For the life of the transition, a Supabase compromise is a Meridian
authentication compromise. That is the strongest argument for keeping Phase 10's cut-off
date short and dated rather than "when convenient".

---

## 6. Boundary — api → Intuit QuickBooks Online

**What crosses it.** Outbound only, over the NAT gateway (no VPC endpoint exists for Intuit,
§2.4 D-19): an OAuth token exchange, then journal entries posted into the customer's real
books. This is the boundary where a software bug becomes a financial statement.

**What lives here today.** `src/qbo_client.py` holds per-org tokens in a `qbo_connection`
table keyed on `(org_id, realm_id)` (`src/qbo_client.py:72-85`, `286-320`), refreshes and
persists **both** tokens because QBO rotates the refresh token on every use
(`src/qbo_client.py:86-130`), and offers `journal_entries_on_date()` returning
`{DocNumber: Id}` as "the duplicate guard for callers with no local tracking row"
(`src/qbo_client.py:216-229`). At commit `4ccddcb`, `create_journal_entry()`
(`src/qbo_client.py:231-238`) posted **without** an Intuit `RequestId`. **Phase 0c (commit
`fef0bae`) changed that:** `create_journal_entry(body, request_id=…)` now sends Intuit's
`requestid`, derived by `journal_request_id(org_id, doc_number, txn_date)`. What is still
missing at this boundary is the *local* post-ledger — see row 6.3 and gap G-1.

| # | STRIDE | Threat | L | I | Mitigation (plan cite) | Evidence artifact | Phase |
|---|---|---|---|---|---|---|---|
| 6.1 | S | Stolen QBO refresh token used to post entries into the customer's books | L | **H** | Tokens move to Secrets Manager / encrypted storage under the RDS CMK; Phase 0 step 8 first **inventories the two credential paths** (`mergio/qbo-tokens` in Secrets Manager vs `QBO_*` in `.env` per migration 035) and writes down which the containerized app uses — the ambiguity itself is the finding | Phase 0 inventory entry; Secrets Manager secret; `tests/security/test_no_qbo_tokens_in_env.py` | 0, 2 |
| 6.2 | S | OAuth callback CSRF — an attacker links *their* QuickBooks company to our org | L | H | D18 (2026-09-24): the `state` is a one-time handle naming a sealed record parked server-side (`src/api/v2/qbo_connection.py`, revision 0017's store), BOUND to the org and the admin who pressed Connect; the callback refuses a state issued to another org or user, spends it on first use (replay), and requires the org admin role at both ends; every connect/disconnect is audited (revision 0021) | `tests/security/test_qbo_connection.py` (tampered, cross-org, cross-user, replayed, non-admin, Intuit `error`, no token in responses or logs — each with a `--known-bad` control) | 11 |
| 6.3 | T | A journal entry posted twice — the double-post risk | **H** | **H** | Not yet closed by the plan beyond `IDEMPOTENCY_CONFLICT` semantics (contract §4.2) and the `Idempotency-Key` requirement on non-idempotent calls (contract §9: "never `execute`, which is not idempotent without an `Idempotency-Key`"). Intuit's `requestid` is now sent on every create: `create_journal_entry(body, request_id=…)` and `journal_request_id(org_id, doc_number, txn_date)` (`src/qbo_client.py`), wired into `src/qb_usa_payroll_quickbooks.py` and `scripts/qbo_post_je.py` (Phase 0c, gap G-1). The existing `journal_entries_on_date()` pre-check by `DocNumber` stays as the backstop for an entry keyed in by hand. **See gap G-1 (§11)** | `tests/test_qbo_request_id.py` (exists today, 11 tests); Phase 12 adds the redelivery test — the same post replayed after a lost response must not book twice; a local post-ledger table recording `(org, run, DocNumber) → QBO Id` | **0c** (requestid, done) → **3** (ledger column) → **12** (redelivery test) |
| 6.4 | T | A partial batch — some of the nine entries posted, then a failure | M | H | The existing house rule "an unmapped item stops the run before any JE exists… booking the transactions you understand and dropping the rest produces a set of JEs that balances perfectly and is wrong" (contract §5) extends to posting | Run state machine test; `EXPORT_FAILED` vs `RUN_RECORD_FAILED` distinction (contract §4.2) | 11 |
| 6.5 | R | No local record of what was posted to QBO and by whom | M | H | `process_runs` + the batch row already carry the run and actor; the post-ledger in 6.3 completes it | Post-ledger table; `audit` retention | 11/12 |
| 6.6 | I | PHI or employee identifiers leaving in a JE payload | L | H | Journal entries carry accounts, departments, locations and amounts — not patient or employee identifiers; the Phase 0 data-flow diagram explicitly covers "what leaves AWS (a journal entry to QBO/NetSuite…)" (Phase 0 step 5) | Phase 0 data-flow diagram; `tests/security/test_je_payload_has_no_pii.py` | 0 |
| 6.7 | I | Intuit error bodies logged verbatim, carrying the token or payload | M | M | `_check()` raises with context; `scripts/lint_no_phi_logging.py` covers the general rule (Phase 0 step 18) | Lint in CI; log sample in the Phase 8 evidence pack | 0, 8 |
| 6.8 | D | Intuit outage or throttling mid-close | M | M | Retries with backoff on the worker; SQS + DLQ once Phase 11 lands; the close is not real-time | DLQ alarm; retry test | 11 |
| 6.9 | E | A machine client with `processes:run` able to post to QBO without approval | M | H | Scopes are per-resource and enforced by one dependency; admin approval to create a client; alarms on scope escalation (Phase 12 steps 2-3) | `tests/security/test_scope_enforcement.py`; scope-escalation alarm | 12 |

**Residual risk.** 6.3 is the highest-impact **partly** closed design item in this model.
Phase 0c removed the common case — a retried post now carries the same Intuit `requestid`, so
Intuit itself deduplicates it. What remains is the local record: nothing on our side maps
`(org, run, DocNumber)` to the QBO `Id`, so a post whose response was lost cannot be
*verified* from our data, only re-derived. Everything else at this boundary is credential
hygiene; this one silently doubles a customer's books.

---

## 7. Boundary — Cognito ↔ Google / Microsoft federation

**What crosses it.** An identity assertion from an external identity provider, and the
claims we map onto a Cognito user — including `custom:app_uid`, which is what the
application uses as the user id (§2.1).

**Why it is its own section.** The sequencing trap here is specific and expensive: live data
(2026-08-29, §2.1) shows one google-only member, one azure-only member, and **the single
superadmin is azure-only**. Enabling an IdP before pre-linking auto-creates a duplicate
empty account, and the cleanup is delete-and-relink **with the superadmin in the blast
radius**.

| # | STRIDE | Threat | L | I | Mitigation (plan cite) | Evidence artifact | Phase |
|---|---|---|---|---|---|---|---|
| 7.1 | S | Account takeover by email-claim collision — an attacker registers the same email at the other IdP and is merged into the existing account | M | **H** | Pre-link explicitly with `AdminLinkProviderForUser` for the three known federated identities **before the IdPs are enabled**; no self-service signup (invite-only, P-6), so there is no path to auto-provision an unlinked account (§2.1) | Phase 4 pre-link runbook; `tests/security/test_no_implicit_account_linking.py` | 4 |
| 7.2 | S | Unverified-email claim accepted from an IdP | L | H | Invite-only provisioning means membership comes from an `org_members` row, not from an IdP claim; `require_org` fails closed without one (contract §8 layer 1) | `tests/security/test_org_membership_required.py` | 4 |
| 7.3 | T | The duplicate-account trap: the superadmin's `custom:app_uid` is wrong after a delete-and-relink, silently detaching them from their data | M | **H** | Ordering is the whole control: `AdminCreateUser` with the right `custom:app_uid` and `MessageAction='SUPPRESS'`, then `AdminLinkProviderForUser`, then enable the IdP (§2.1). `custom:app_uid` is immutable, so a wrong value cannot be quietly corrected later | Pre-link runbook output recorded; post-flip check that every federated user's `custom:app_uid` matches `legacy_users.json` | 4 |
| 7.4 | R | An IdP-side change (a disabled Google account) with no trace on our side | L | M | Cognito sign-in events → CloudWatch; quarterly access review (Phase 12 step 3) and the termination checklist (Track C item 7) | Access-review report; termination checklist | 6, 12 |
| 7.5 | I | Profile claims from the IdP written into application tables | L | M | Profile fields live in `user_profiles`, added as a Phase 4 prerequisite; nothing from an IdP is treated as authorization (§2.1) | `user_profiles` migration; `tests/security/test_idp_claims_not_authz.py` | 4 |
| 7.6 | D | IdP outage locks out the only superadmin | M | H | MFA-enrolled Cognito credentials exist for both workforce members; both IdPs stay (P-8); a break-glass path is part of the termination/rotation procedure (Track C item 7) | Break-glass credential record + rotation date | 4 |
| 7.7 | E | An IdP-supplied group or role claim mapped to admin | L | H | Authorization is Postgres tables, unchanged — "Authz: Postgres tables, unchanged" (§2.5). No IdP claim grants anything | `tests/security/test_role_from_db_not_token.py` | 4 |

**Residual risk.** 7.3 is a one-shot, ordering-dependent operation on the account with the
most privilege. It should be rehearsed on staging and executed from a written runbook, with
the superadmin's recovery path confirmed *before* the first IdP is enabled.

---

## 8. Boundary — machine clients → `/api/v3` (Phase 12, design-level)

**What crosses it.** Requests from outside systems and our own scripts, authenticated by
OAuth2 client credentials rather than a browser session; and webhooks we send *out* to
partner-controlled URLs.

**Status.** Design-level. Nothing here exists yet; this section is the specification the
Phase 12 security tests are written against.

| # | STRIDE | Threat | L | I | Mitigation (plan cite) | Evidence artifact | Phase |
|---|---|---|---|---|---|---|---|
| 8.1 | S | A leaked client secret used indefinitely | M | H | One Cognito app client per external system; secrets shown once, **stored hashed in Postgres**, rotatable without downtime, revocable instantly; tokens ≤15 minutes; optional IP allowlist; auto-disable after 90 idle days (Phase 12 step 3; §2.1) | `tests/security/test_revoked_client_token_fails_within_60s.py` (Phase 12 verify: "a revoked client's token fails within one minute"); admin screen audit log | 12 |
| 8.2 | S | A token from the staging pool accepted in production | L | H | Separate Cognito pool per environment; issuer and audience verified locally via PyJWT with cached JWKS (§2.1, §2.4) | `tests/security/test_token_issuer_audience.py` | 12 |
| 8.3 | T | Mass assignment — a client sets a field it should not (org, status, amounts) | M | H | Strict pydantic schemas with `extra='forbid'`; property-level authorization (Phase 12 step 1) | `tests/security/test_unknown_fields_rejected.py` | 12 |
| 8.4 | T | **Replay** of a captured request or webhook | M | H | `Idempotency-Key` with `IDEMPOTENCY_CONFLICT` on a same-key/different-payload retry (contract §4.2); webhooks carry an HMAC signature with a timestamp and a unique id for replay protection (Phase 12 step 5) | `tests/security/test_replay_rejected.py` (Phase 12 verify: "a replayed webhook is rejected") | 12 |
| 8.5 | R | A machine action with no attributable actor | M | M | Every request carries the client id; `request_id` in every envelope; delivery history visible in the admin screen; quarterly access-review report (Phase 12 steps 3, 5, 6) | Admin screen delivery log; access-review report | 12 |
| 8.6 | I | **Broken object-level authorization** — a client reads another org's run by guessing an id | **H** | **H** | Object-level authorization on **every** request (this caller, this record, this org), returning `404`, never `403`, on cross-org (Phase 12 step 1; contract §8) | `tests/security/` object-level tests with **ID swapping and cross-org attempts**, each with a known-bad control test that fails (Phase 12 step 8 + verify) | 12 |
| 8.7 | I | PHI returned to a client that has no right to it | M | **H** | PHI **masked by default** in every `/api/v3` response; `phi:read` unmasks and is never granted without a recorded partner BAA (a `partner_baas` table with document reference and dates) + admin approval; every unmasked read writes an `audit.phi_access` row; **mTLS via API Gateway custom domain + truststore for any PHI-scoped partner** (§2.3; Phase 12 step 4) | `partner_baas` table; `audit.phi_access` rows; `tests/security/test_phi_masked_without_scope.py` (Phase 12 verify) | 12 |
| 8.8 | I | **SSRF via webhook subscription** — a partner points a subscription at `169.254.169.254` and we fetch instance credentials for them | M | **H** | SSRF guard blocking private, link-local and metadata IP ranges **at subscription time and again at delivery time after DNS resolution** — the second check is what defeats DNS rebinding; HTTPS only; ids only in payloads, never PHI (Phase 12 step 5) | `tests/security/test_webhook_ssrf_blocked.py` (Phase 12 verify: "a webhook to `169.254.169.254` is refused") | 12 |
| 8.9 | D | Unlimited resource consumption by one client | M | M | WAF rate-based rules + per-client quotas + progressive lockout on auth failures; cursor pagination with bounded page sizes (Phase 12 steps 1, 8) | `tests/security/test_rate_limits.py`; WAF metrics | 12 |
| 8.10 | E | Scope escalation — a client obtains a scope it was not granted | M | H | Scopes as Cognito resource-server scopes, enforced server-side by **one dependency, never per-handler ad hoc**; alarms on scope escalation and on a new client IP; admin approval to create (Phase 12 steps 2, 3) | `tests/security/test_scope_enforcement.py`; scope-escalation alarm | 12 |
| 8.11 | E | Unsafe consumption of a partner API / unmanaged inventory of old versions | M | M | `/api/v1` and `/api/v2` retired once `/api/v3` covers each, with sign-off; the health-check path moves to `/api/v3/health` and the ALB/CloudFront health checks change in the same commit; `docs/migration-tracker.md` empty (Phase 12 step 10, D-25) | Empty `docs/migration-tracker.md`; generated OpenAPI clients type-checking against `web/` | 12 |
| 8.12 | — | A sandbox client reaching real PHI | L | H | Sandbox is a **synthetic org inside staging** with generated data (`deploy/aws-trial/make_sample_revenue.py` as the seed), separate API clients, never real PHI; staging cannot read a production ARN (D-18; §2.4) | `tests/infra/test_no_cross_env_arns.py`; sandbox seed script | 12 |

**Residual risk.** Object-level authorization (8.6) is the item that is easy to implement in
99% of handlers and fatal in the 1% that is missed. Phase 12 step 8's requirement that every
security test have "a known-bad control test that fails" is what stops the suite from
passing vacuously; it should be treated as non-negotiable.

---

## 9. Threats present in TODAY's system

Everything in this section was read on the `aws-migration` branch on 2026-09-15 and is
cited `path:line`. Line numbers in the migration plan were written against an earlier tree;
where they have moved, the verified location is given and the difference is noted.

### 9.1 Cross-org role / permission escalation — Jinja admin routes · **Severity: High**

`admin_update_role` updates the role row by id alone:

```
web_app.py:2450    sb.table('roles').update(updates).eq('id', role_id).execute()
web_app.py:2456    sb.table('role_permissions').upsert({...}, on_conflict='role_id,process')
```

Neither statement carries `org_id`, and `sb` is `get_supabase_admin()` — the service-role
client, which bypasses RLS (`src/auth.py:40-59`, docstring: "bypasses RLS"). The
`@require_role('admin')` decorator proves the caller is an admin **of their own org**, not
of the org that owns `role_id`. An admin of org A who learns a role id from org B can
rename it and rewrite its permission matrix, granting or revoking access for org B's users.
`admin_create_role` (`web_app.py:2408-2425`) inserts with the caller's `org_id` and is safe;
`admin_delete_role` (`web_app.py:2483`) correctly carries `.eq('org_id', ...)`, which shows
the check was understood and simply not applied consistently. Role ids are UUIDs, so this
needs a leaked id — an insider or a support transcript, not an internet scan; the impact is
a silent, persistent authorization change in another tenant.

The related read at `web_app.py:2297` (`role_permissions` selected by `role_id` alone) is
reached only after an org-scoped roles list at `web_app.py:2295`, so it is not independently
exploitable.

**Fixed (2026-09-15, Phase 0c step 16):** `admin_update_role` now calls
`_role_in_caller_org(role_id)` before anything is written — a thin wrapper over
`_find_role(org_id, role_id)`, the SAME helper the `/api/v2` role routes use, so the two
surfaces cannot drift apart. The `roles` update also carries `.eq('org_id', …)` now.
**Note on the Verify wording:** the answer is **404, not 403**. A 403 confirms that the id
exists in another org, which is what contract §8 forbids and what the `/api/v2` twin
already answers. Regression: `tests/test_role_org_isolation.py` (Jinja) and
`test_patching_another_orgs_matrix_is_404_and_writes_nothing` in
`tests/test_api_v2_users.py` (the JSON twin).

### 9.2 Plan accuracy — the `/api/v2` role routes are already guarded · **Severity: Informational**

Phase 0 step 16 also names `src/api/v2/user_routes.py:411, 548, 637, 650, 664`. Those lines
are helpers (`_permission_rows`, `_insert`, `_write_matrix`) that do address
`role_permissions` by `role_id` alone — but every route that reaches them resolves the role
through `_find_role(org_id, role_id)` first and raises `_no_such_role()` on a miss:

```
src/api/v2/user_routes.py:791   row = _find_role(org_id, role_id)   # PATCH /org/roles/<id>
src/api/v2/user_routes.py:836   row = _find_role(org_id, role_id)   # DELETE /org/roles/<id>
```

`_find_role` (`:390-395`) scans `_role_rows(org_id)`, which is `_select(ROLE_TABLE, org_id, …)`
(`:114-126`) — org-filtered. Role creation (`:756`) inserts with the caller's `org_id`.
Member and invite writes go through `_write` / `_erase`, which carry `.eq("org_id", org_id)`
(`:316-339`). The v2 surface therefore has the check the Jinja surface lacks; the docstring
at `:402-408` states the invariant explicitly. **Recommendation:** keep the regression tests
Phase 0 step 16 asks for on the v2 routes (they lock in a property that currently holds by
convention, one caller at a time), but scope the *fix* work to `web_app.py`. Correct the
plan's step 16 wording so the estimate is not spent twice.

### 9.3 Service-key RLS bypass is the ambient authorization model · **Severity: High (systemic)**

`get_supabase_admin()` returns a memoized service-role client that bypasses RLS
(`src/auth.py:40-59`); it has **41 call sites** across `src/` and `web_app.py`, against
**202** `.table(` call sites in total (194 in `src/` + `web_app.py`, 8 in `scripts/` —
`inventory-data-layer.md` is the authoritative count). Contract §8 states the consequence plainly: "service-key
access bypasses RLS, so layer 2 is what actually protects reads today; RLS is the backstop."
Today there is no backstop — the 94 `CREATE POLICY` statements in the migrations are
inert for every request the application makes. Every one of 9.1's missing `org_id`
predicates is therefore a live cross-tenant hole rather than a defence-in-depth lapse.

**Fix:** plan §2.2 / D-10 — `meridian_app` is not the table owner and has no `BYPASSRLS`,
`FORCE ROW LEVEL SECURITY`, `app.org_id` set on checkout and `RESET` on return, plus
`scripts/lint_org_scope.py`. **Delivered:** Phase 3 (RLS) / Phase 5a (repository layer).
**Evidence:** `tests/test_run_isolation.py`, `tests/test_pnl_rls_pg.py` on the RDS fixture.

### 9.4 The `SUPABASE_URL`-presence sentinel · **Severity: High**

There is a hard guard at process start:

```
web_app.py:116-120   if not _is_dev and not os.environ.get('SUPABASE_URL'): raise RuntimeError(...)
```

(the plan cites ~111-121; on this branch it is 115-120, and `_is_dev` is `web_app.py:115`).
That guard only covers the **web process**. The same environment variable is then used, at
~22 sites, as a silent mode switch:

```
src/database.py:3499   if os.environ.get('SUPABASE_URL') and os.environ.get('SUPABASE_SERVICE_KEY') and org_id:  → Supabase, else SQLite
src/storage.py:263     same shape → Supabase Storage, else local disk
src/auth.py:501        _auth_disabled() = not os.environ.get('SUPABASE_URL')   (under FLASK_ENV=development)
src/process_runs.py:90 same shape
web_app.py:334, 356, 2134   feature-availability branches
```

If the variable is unset or mistyped in a context that did not hit the start-up guard, the
application does not fail — it books journal entries into SQLite on an ephemeral disk and
writes outputs to local disk, and tells the user the run succeeded. The one place that
refuses is `_qb_usa_require_supabase` (`web_app.py:3981-3996`), whose docstring is the
model the plan wants generalized: "that fallback must never happen quietly… the whole job
must fail with a message that says plainly nothing was saved" (matching
`PERSISTENCE_UNAVAILABLE`, contract §4.2). Note also that `_auth_disabled()`
(`src/auth.py:490-502`) is correctly gated on `FLASK_ENV=development` — the sentinel cannot
disable authentication in production. Audit impact is separate and real: a run that lands
in SQLite leaves no row anyone can later find.

**Fix:** Phase 0 step 19 — replace with explicit `DATABASE_BACKEND` / `STORAGE_BACKEND` /
`AUTH_BACKEND` switches across all 22 sites, fail-loud on missing config, in the stated
non-negotiable order (Auto-Deploy off → set the three vars in both Render dashboards →
merge → deploy manually).

### 9.5 `/auth/set-session` is CSRF-exempt and accepts caller-supplied tokens · **Severity: Medium**

```
web_app.py:1971-1994
@app.route('/auth/set-session', methods=['POST'])
@csrf.exempt
@limiter.limit("5/minute")
```

The handler takes `access_token` and `refresh_token` from the JSON body, validates the
access token against Supabase (`sb.auth.get_user(access_token)`, `web_app.py:1985-1990`) and
then sets both as HttpOnly cookies. Three observations:

- It is the **only** `csrf.exempt` route in the tree (`web_app.py:1972`; the v2 blueprint is
  deliberately not exempt — `web_app.py:181`, `src/api/v2/__init__.py:7`). Exemption exists
  because the caller is the hash-fragment OAuth callback page, which has no CSRF token yet.
- Consequently a cross-origin page can force a **session fixation**: log the victim's browser
  into an *attacker-controlled* account by POSTing the attacker's tokens. The subsequent
  work the victim does then lands in the attacker's org. `SameSite=Lax` blocks cross-site
  POSTs in current browsers, which is what keeps this Medium rather than High.
- Only the **access** token is validated; the refresh token is stored unverified
  (`web_app.py:1991-1993`), and `set_auth_cookies` defaults give it a 7-day life
  (`src/auth.py:220-221`, `refresh_expires=604800`).

**Fix:** not currently an explicit plan step. Cognito's hosted flow removes the hash-fragment
callback this route exists for, so the route disappears at Phase 4 — but it remains live
through Phases 0-3 and during dual-token acceptance. **See gap G-2 (§11).**

### 9.6 `batch_id`-only scoping in the QB USA payroll statements · **Severity: Medium**

```
web_app.py:4078-4081   qb_usa_payroll_journal / _gate selected by .eq('batch_id', batch_id) alone
web_app.py:4650, 4671  insert journal / gate rows with no org_id column in the predicate
web_app.py:4912-4913   gate rows fetched with .in_('batch_id', batch_ids)
```

(the plan cites the `web_app.py:4487-4497` region; the statements are at 4078-4081, 4650,
4671 and 4912 on this branch.) Two of these are safe by construction and one is not:

- `web_app.py:4071-4073` resolves the batch **first** with `.eq('id', batch_id).eq('org_id', org_id).eq('batch_type', 'qb_usa_payroll')` and returns `None` when it misses, so the reads at 4078-4081 are reached only for a batch already proven to belong to the caller. Contract §8 names this exact statement as the house style.
- `web_app.py:4905-4913` derives `batch_ids` from an org-filtered `import_batches` query, so the `.in_()` is likewise contained.
- The inserts at 4650/4671 already write `org_id` in their payload, so the rows themselves are tenanted; only the *predicates* were short.

> **CORRECTION (2026-09-15, Phase 0c step 17).** The paragraph that stood here claimed
> these two tables "have no `org_id` column to write a policy on". That is wrong, and the
> claim is contradicted by this repo's own Phase 0 inventory. `021_qb_usa_payroll_runs.sql`
> declares `org_id UUID NOT NULL REFERENCES public.organizations(id)` on **both** tables
> (`:42` and `:74`), indexes it (`:58`, `:97`), enables RLS and creates
> `qb_usa_payroll_journal_org_isolation` / `qb_usa_payroll_gate_org_isolation` as
> `USING / WITH CHECK (org_id = user_org_id())` (`:113-122`) —
> see `inventory-data-layer.md` rows 99-100 ("org_id? yes") and the policy table at line 214.
> The live database was checked and matches: both tables carry `org_id` and have RLS
> enabled. So the RLS backstop was never missing; what was missing was the explicit
> predicate the house style requires, because the service-role client bypasses RLS.

**Fixed:** Phase 0c step 17 added the explicit `.eq('org_id', org_id)` to the three short
statements (`qb_usa_payroll_journal` and `qb_usa_payroll_gate` selects in
`_qb_usa_batch_snapshot`, and the `.in_('batch_id', …)` gate fetch on the runs list). Every
read and write of either table in `web_app.py`, `src/api/v2/qb_usa_runs.py` and
`src/qb_usa_payroll_quickbooks.py` now names `org_id` in full. Regression:
`tests/test_qb_usa_payroll_org_scoping.py`. No schema change was needed or made.

### 9.7 `ProxyFix(x_for=1)` under a future two-proxy chain · **Severity: Medium (on cutover)**

```
web_app.py:166-168   if FLASK_ENV == 'production': ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
```

Correct today (one proxy: Render, or the Next.js rewrite). Behind CloudFront **and** an ALB
it trusts one hop too few and the application reads the wrong address as the client IP —
re-creating the bug commit `71decf2` fixed, which the comment at `web_app.py:160-165`
describes: every rate limit keys on the proxy address, so "one person fat-fingering a
password locks out everyone". Plan §2.4 specifies `x_for=2`. This is a cutover-day
regression waiting to happen and belongs in the Flip 2 checklist, not only in the CDK.

### 9.8 Rate limiting is per-process and keyed on the proxy · **Severity: Medium**

```
web_app.py:173-178   Limiter(get_remote_address, storage_uri="memory://")
```

Contract §9 states both problems: `get_remote_address` is wrong behind the Next.js rewrite
(all users share one bucket), and `memory://` is per-process, so with N workers the
effective limit is N×. The auth-sensitive routes are capped at `5/minute`
(`web_app.py:1752, 1772, 1821, 1973`) — a number that is only meaningful if the key is the
user, not the proxy. The v2 blueprint already uses a `rate_limit_key` function
(`src/api/v2/auth_routes.py:368`), which is the shape the rest should adopt.

### 9.9 No MFA on the current system · **Severity: High**

`src/auth.py` contains no MFA or TOTP path; sign-in is password-plus-cookie
(`set_auth_cookies` at `src/auth.py:220-233`; `require_auth` at `src/auth.py:519` validates them).
Two workforce members, one of whom is a superadmin, protect PHI and a customer's books with
a single factor. Phase 4 fixes it (MFA `ON`, TOTP, §2.1) — but Phase 4 is months away under
the cutover-first order, and MFA at the IdP for the azure-only superadmin is the only thing
standing in for it today. Worth confirming that Microsoft-side MFA is actually enforced for
that account; if it is not, this is the cheapest High-severity fix available.

### 9.10 Auth-state staleness by cache · **Severity: Medium**

`src/auth.py:93-178` implements TTL caches for tokens, orgs, permissions, modules and
superadmin status, with `AUTH_CACHE_DISABLED=1` as the escape hatch (`:93, :106`). A
revoked permission or a removed member stays effective until the entry expires — plan §2.1
calls these "the documented staleness bug" and deletes them once RDS makes the lookups
1-2 ms. Until then, revocation is not immediate, which matters for the termination
checklist (Track C item 7).

### 9.11 Long-lived refresh cookies · **Severity: Medium**

`set_auth_cookies(..., refresh_expires=604800)` (`src/auth.py:220-221`) — seven days, as
plan §2.1 notes when it cuts the browser refresh to 12 hours. A stolen refresh cookie is a
week of access, and nothing at 9.5 verifies a refresh token before storing it.

### 9.12 PHI in logs — partly fixed, blocklist still a blocklist · **Severity: Medium**

The processor has clearly been hardened since the plan was written: `src/qb_usa_payroll_processor.py:636-642`
logs the **register row number** with an explicit comment ("Identify the row, not the
person. Application logs go to the hosting provider and are retained and read far more
widely than the workbook"). Sites that still log names remain, e.g.
`src/qb_usa_payroll_processor.py:558` (a register name that resolves to no single person),
`:644` (a shared Employee ID), `:744` and `:760` (benefit-override and redistribution
names). Separately, **as found** at commit `4ccddcb`, `RAW_WITHHELD_HEADERS`
(`src/qb_usa_payroll_workbook.py:203-209`) was a **blocklist** — a new carrier column
carrying an identifier was exposed by default. **Fixed in Phase 0c (commit `fef0bae`):** it
is now `RAW_ALLOWED_HEADERS`, an allowlist, so an unrecognised header is blanked and
reported instead.
Nineteen `exc_info=True` handlers in `web_app.py` (392-611 region: `:406, :426, :440, :485,
:507, :533, :548, :604, :611`) can print exception text that carries cell contents.

**Fix:** Phase 0 step 18 — flip the blocklist to an allowlist, wrap ingest parse errors, and
encode "NEVER log a `RunResult`" as `scripts/lint_no_phi_logging.py` in CI.

### 9.13 Backend tests are not run by CI · **Severity: High (as a control failure)**

Phase 0 step 23: `.github/workflows/web.yml` runs only the Next.js checks; the 48 backend
test files are run by nothing, and the CI image must include LibreOffice or
`tests/conftest.py` skips the workbook tests **silently**. Every security control in this
document is evidenced by a test. Until `pytest tests/` runs in CI, none of that evidence is
load-bearing — this is the prerequisite for the whole model, not a line item.

### 9.14 Storage: dead path that swallows a failure · **Severity: Low**

`web_app.py:11121-11127` uploads to a `wearbly-receipts` bucket that never existed, logs a
warning and "stores the path anyway"; `web_app.py:11540` later downloads from it. Phase 0
step 20 deletes the path (P-5). Low severity (frozen feature, no PHI), listed because
"swallow the error and record success" is the same anti-pattern as 9.4 and should be fixed
wherever it appears.

### 9.15 Already fixed on this branch — do not re-spend the estimate · **Severity: Informational**

- The contract §6.2 `Accept`-header bug is **fixed**: `_wants_json()` (`src/auth.py:504-516`)
  is path-first (`req.path.startswith('/api/')`), exactly as the contract specifies.
- `_RUN_OVERRIDES` (contract §8, second scoping hole) is **fixed**: the overrides now live in
  `process_runs.run_state.run_overrides` (migration 022) — `src/qb_usa_payroll_roster.py:146-158`.
- The in-memory wizard dicts are **partly fixed**: `RunStore` backs four of them
  (`web_app.py:43, 3264, 3908, 3910`), storing state in `process_runs`
  (`src/run_store.py:1-20`). The `desiredCount: 1` constraint (§2.5) should be re-checked
  against what `RunStore` now covers before Phase 11 is scoped.
- `assert_org_path` (`src/storage.py:36-51`) already enforces contract §8 layer 4 and
  deliberately does not echo the attacker-supplied path back.

### 9.16 Summary of today's findings

| # | Finding | Severity | Fixed by |
|---|---|---|---|
| 9.1 | Cross-org role/permission write (Jinja admin) | High | Closed, Phase 0c step 16 (404, not 403) |
| 9.3 | Service-key RLS bypass as the ambient model | High | Phase 3 / 5a (D-10) |
| 9.4 | `SUPABASE_URL` sentinel → silent SQLite fallback | High | **Done in Phase 0c (commit `fef0bae`)** — explicit `DATABASE_BACKEND` / `STORAGE_BACKEND` / `AUTH_BACKEND` switches in `src/settings.py`, fail-loud outside development |
| 9.9 | No MFA | High | Phase 4 (IdP MFA meanwhile) |
| 9.13 | Backend tests not in CI | High | **Done in Phase 0c** — `.github/workflows/backend.yml` runs `pytest tests/` on every push, with LibreOffice installed so the workbook tests cannot skip silently |
| 9.5 | `/auth/set-session` CSRF-exempt, caller tokens | Medium | gap G-2 |
| 9.6 | `batch_id`-only payroll predicates (the `org_id` COLUMN exists — see the correction in 9.6) | Medium | Closed, Phase 0c step 17 |
| 9.7 | `ProxyFix(x_for=1)` on cutover | Medium | Phase 5a / Flip 2 checklist |
| 9.8 | Rate limits keyed on proxy, `memory://` | Medium | Phase 5a (contract §9) |
| 9.10 | Auth cache staleness | Medium | Phase 4 |
| 9.11 | 7-day refresh cookie | Medium | Phase 4 |
| 9.12 | PHI in logs; blocklist not allowlist | Medium | **Done in Phase 0c (commit `fef0bae`)** — `RAW_ALLOWED_HEADERS` replaces the blocklist; `scripts/lint_no_phi_logging.py` + `src/log_safe.py` in CI and pre-commit |
| 9.14 | `wearbly-receipts` swallowed failure | Low | **Done in Phase 0c** — the upload path no longer records success on a failed write |

---

## 10. OWASP API Security Top 10 (2023) mapping

The OWASP API Security Top 10 is the industry's list of the ten most common ways APIs are
broken. Phase 12 step 8 requires it mapped in the control matrix; this is that mapping.

| # | Item | Where it is mitigated in the target design | Evidence | Phase |
|---|---|---|---|---|
| **API1** | Broken Object Level Authorization | Object-level authz on every `/api/v3` request (this caller, this record, this org); cross-org returns `404`, never `403`; explicit `org_id` predicate on every statement **plus** RLS on `app.org_id`; storage paths checked against `g.org` before signing (Phase 12 step 1; contract §8; §2.2) | ID-swap and cross-org tests in `tests/security/`, each with a known-bad control that fails; `tests/test_run_isolation.py`; `assert_org_path` test | 3, 5a, 12 |
| **API2** | Broken Authentication | Cognito pool, MFA `ON` with TOTP, `PreventUserExistenceErrors`, threat protection `ENFORCED`; local JWT verification via PyJWT + cached JWKS; ID token 60 min / refresh 12 h; machine tokens ≤15 min; progressive lockout on auth failures (§2.1; Phase 12 steps 3, 8) | Cognito CDK construct; `tests/security/test_auth_*`; lockout alarm | 4, 12 |
| **API3** | Broken Object Property Level Authorization | Strict pydantic schemas with `extra='forbid'`; PHI masked unless `phi:read`; property-level authz stated as a Phase 12 requirement (Phase 12 step 1; §2.3) | `tests/security/test_unknown_fields_rejected.py`; `tests/security/test_phi_masked_without_scope.py` | 12 |
| **API4** | Unrestricted Resource Consumption | WAF rate-based rules at the edge; per-user/per-client limits by class (contract §9); `MAX_CONTENT_LENGTH` → 413; hourly create cap bounding storage; cursor pagination with bounded pages; `desiredCount` and task sizing fixed in the CDK | `tests/security/test_rate_limits.py`; `test_oversized_payload.py`; WAF `BlockedRequests` alarm | 5a, 12 |
| **API5** | Broken Function Level Authorization | `@require_auth` / `@require_org` / `@require_role` / `@require_permission` on every route; scopes enforced by **one** server-side dependency, never ad hoc per handler; authorization from Postgres tables, never from a token claim (Phase 12 step 2; §2.5) | `tests/security/test_route_authz_matrix.py`; `test_scope_enforcement.py` | 5a, 12 |
| **API6** | Unrestricted Access to Sensitive Business Flows | Execute capped at `10/minute`, `40/hour` per user because "each one books journal entries"; `Idempotency-Key` required on non-idempotent calls; gates must be declared before export (`GATES_UNDECLARED`); unmapped items stop the run before any JE exists (contract §9, §4.2, §5) | `tests/security/test_execute_rate_and_idempotency.py`; gate tests | 5a, 12 |
| **API7** | Server Side Request Forgery | Webhook SSRF guard blocking private, link-local and metadata ranges at subscription time **and** at delivery time after DNS resolution; HTTPS only (Phase 12 step 5) | `tests/security/test_webhook_ssrf_blocked.py` (Phase 12 verify: a webhook to `169.254.169.254` is refused) | 12 |
| **API8** | Security Misconfiguration | CDK-only infrastructure, staging rebuilt from empty every session so the chain is proven (D-15); Block Public Access + SSE-KMS enforced; no plaintext credentials in task definitions; security headers and a strict CORS allowlist on every response; `FLASK_ENV=production` for the `Secure` cookie flag; AWS Config + GuardDuty + CloudTrail account-wide | `tests/infra/*`; AWS Config rules; ZAP baseline with no high findings | 1, 2, 8, 12 |
| **API9** | Improper Inventory Management | Phase 0 inventory of every table, policy, env var, external call and Jinja route; `docs/architecture/repo-layout.md`; OpenAPI-generated clients; `/api/v1` and `/api/v2` retired with sign-off; `docs/migration-tracker.md` empty; sandbox is a separate synthetic org, never real PHI (Phase 0 steps 4-5; Phase 12 steps 7, 10) | The inventory documents; empty migration tracker; generated clients type-check | 0, 12 |
| **API10** | Unsafe Consumption of APIs | Intuit QBO responses validated through `_check()`; outbound calls over the NAT with timeouts; the QBO double-post guard (gap G-1); IdP claims never used for authorization; GuardDuty malware scan on every ingested object before processing (§2.3; Phase 12 step 4) | `tests/test_qbo_request_id.py` (exists today); the Phase 12 redelivery test; `test_idp_claims_not_authz.py`; malware-scan tag check | 0c, 8, 11, 12 |

---

## 11. Gaps this model found in the plan

These are the items the migration plan does not currently close. Each needs a decision, not
just an estimate.

- **G-1 — QBO double-post: PARTLY CLOSED (requestid sent, local post-ledger still missing).**
  Plan §2.5 and Phase 11/12 describe
  posting journal entries but no idempotency control for the QBO write itself. **As found**
  (at commit `4ccddcb`), `create_journal_entry()` (`src/qbo_client.py:231-238`) sent no Intuit
  `RequestId`, and the only guard was `journal_entries_on_date()` (`:216-229`), which a caller
  had to remember to use. A retry after a timeout — where the entry *was* created but the response was lost
  — double-books the customer's period.
  **PARTLY CLOSED (2026-09-15, Phase 0c).** `create_journal_entry` now takes `request_id`
  and sends it as Intuit's `requestid` query parameter, and both callers derive it with
  `qbo_client.journal_request_id(org_id, doc_number, txn_date)` —
  `sha256("org|DocNumber|TxnDate")[:50]`, Intuit's length cap. It is derived rather than
  stored deliberately: a retry recomputes the same token without needing a row to have
  survived whatever caused the retry. Tests: `tests/test_qbo_request_id.py`.
  **Still open:** the local post-ledger recording `(org, run, DocNumber) → QBO Id`. The
  payroll push has none by design ("no local push-status table",
  `src/qb_usa_payroll_quickbooks.py`); the revenue script records into `qb_export_tie_out`,
  which has `qbo_je_id` / `qbo_sync_token` / `qbo_posted_at` but no column for the request
  id. Adding that column is a Phase 3 schema decision, not a Phase 0c one.
- **G-2 — `/auth/set-session` has no retirement step.** The only `csrf.exempt` route in the
  tree (`web_app.py:1971-1994`) accepts caller-supplied tokens and stores the refresh token
  unverified. It is implicitly retired by Cognito at Phase 4 but is live through Phases 0-3
  and during dual-token acceptance. **Proposal:** either verify the refresh token before
  setting it and bind the request to a one-time nonce issued by the callback page, or add an
  explicit "delete this route at Flip 1" line to Phase 4.
- **G-3 — WITHDRAWN (2026-09-15).** The premise was false: `qb_usa_payroll_journal` and
  `qb_usa_payroll_gate` both have an `org_id UUID NOT NULL` column and an org-isolation RLS
  policy, from `021_qb_usa_payroll_runs.sql:42, 74, 113-122`, confirmed against the live
  database and already recorded correctly in `inventory-data-layer.md` (rows 99-100, policy
  table line 214). Plan §2.2's RLS backstop covers these tables today. Phase 0c step 17
  added the missing explicit predicates, which is all that was actually owed; no Alembic
  0002/0003 column work is needed. See the correction note in §9.6.
- **G-4 — MFA is months away under the cutover-first order.** 9.9 is a High-severity gap
  from today until Phase 4. **Proposal:** confirm in writing that Microsoft-side MFA is
  enforced for the azure-only superadmin, and record it as an interim compensating control
  in the risk analysis (Track C item 5).
- **G-5 — `ProxyFix(x_for=2)` is in §2.4 but not in any cutover checklist.** It is a one-line
  change with a security consequence that only appears once CloudFront is in front.
  **Proposal:** add it to the Flip 2 checklist (Phase 9) with the assertion test named in
  §2 row 2.3.
- **G-6 — Phase 0 step 16's line references are partly stale** (see 9.2): the `/api/v2`
  routes already guard via `_find_role`. Correct the step so the work is scoped to
  `web_app.py` and the v2 part is "add regression tests", not "add checks".
- **G-7 — No log-content verification anywhere.** Phase 0 step 18 adds a *lint*
  (`scripts/lint_no_phi_logging.py`), which catches patterns in source, not values at
  runtime. **Proposal:** add a Phase 8 evidence item that samples CloudWatch log groups after
  a real run and records that no identifier appears — that is the artifact an auditor will
  ask for, and it also covers §5 row 5.5 (the Lambda never logging a password).
- **G-8 … G-11 were added by the Phase 8 review** and are stated with their evidence in
  §13.8: the one-commit rule has no test (G-8); the dual acceptance window does not close by
  itself (G-9); a sign-in during that window is not attributable to an issuer (G-10); two
  multipart parsers with two sets of limits (G-11).

---

## 12. Review and maintenance

- Reviewed at each phase gate, and re-reviewed in full after Flip 2 (Phase 9), alongside the
  risk analysis (Track C item 5, NIST SP 800-66r2 structure).
- Any new trust boundary — the first PHI-scoped partner, a mobile client, a second AWS
  account — gets its own section before the code that creates it is merged.
- Section 9 is deleted only when each of its rows has the test that proves it is closed.
- Each dated review appends a section rather than editing an old one. §13 is the first.

---

## 13. Phase 8 review — the surfaces added since Phase 0 · **2026-09-16**

**Why this section exists.** Sections 1-8 modelled the *target* architecture as the plan
described it in Phase 0, before any of it was built. Phases 3-7 then built things the plan
described in a sentence or not at all: a second web framework mounted inside the first, a
window in which two different issuers' tokens are both valid, a function that sees a
password in clear text, a CI identity that can deploy, and a proxy that still runs on
Render. Each of those is a surface, and a surface nobody has walked is a surface nobody has
assessed. This is that walk.

**How to read a row.** Threat → control → **residual**. The residual column is the load-bearing
one: it says what is still true after the control, in plain words. "None material" is used
sparingly and means it. Cross-references are to ADRs and to `control-matrix.md` row ids.

**Ratings** are the same H/M/L as §0, judged for this system.

---

### 13.1 FastAPI with Flask mounted inside it (ADR 0023)

**What it is.** `api/main.py` is a FastAPI application that mounts the whole Flask app at
`/` through Starlette's `WSGIMiddleware`. One origin, one process, two frameworks: a path
that has been ported is answered by FastAPI, and everything else falls through to Flask.
Requests cross a framework boundary *inside one process*, which is a trust boundary in the
sense that matters — the two halves have different defaults for the same question.

| # | STRIDE | Threat | L | I | Control | Residual | Ref |
|---|---|---|---|---|---|---|---|
| 13.1.1 | E | A path exists in **both** frameworks and the two disagree about who may call it, so the weaker one is reachable | M | H | ADR 0023's **one-commit rule**: a path leaves Flask in the same commit that lands it in FastAPI, never both, with a test per path. `next.config.mjs`'s `jinja` rewrite allowlist is the second list, and it must not name a ported path | The rule is a convention plus review; nothing in CI fails a build that lands a path twice. **New gap — tracker row** | ADR 0023; CC8.1 |
| 13.1.2 | S | CSRF is enforced differently on the two halves, so a state-changing call reaches the weaker one with only an ambient cookie | M | H | Both halves use the same switch (`WTF_CSRF_ENABLED`); FastAPI does a double-submit comparison of the `XSRF-TOKEN` cookie against the header, Flask does flask-wtf's signature check. Bearer-authenticated calls are exempt **because a cookie is not what authenticated them** | Two implementations of one control. They agree today; a change to one is not a change to the other, and only the Phase 12 `tests/security/test_csrf_required_on_mutations.py` would notice | ADR 0023; 1.4 |
| 13.1.3 | D | A wrong HTTP method on a ported path answers `404`, so a caller retries a path that will never work | L | L | None yet. Starlette scores a method mismatch as a PARTIAL match and keeps looking, falling through to Flask, which 404s | Open, with a tracker row. It is an API-contract defect rather than a security one, but it is also how a scanner concludes a path does not exist when it does | ADR 0023; API9 |
| 13.1.4 | I | `WSGIMiddleware` is deprecated upstream and may be removed, taking the mount with it on a routine dependency bump | M | M | Pinned dependencies plus `pip-audit`; the `a2wsgi` alternative is written down as a decision for Andres | Open decision (`needs-a-human` 25). A deprecated component in the request path of every unported route is not a vulnerability today and is a maintenance risk tomorrow | ADR 0023; CC8.1 |
| 13.1.5 | T | Multipart bodies are parsed by **werkzeug** inside the FastAPI half (`api/uploads.py` spools the ASGI body and hands it to `werkzeug.formparser`), so upload limits are enforced by one framework's rules inside the other's | M | M | `MAX_CONTENT_LENGTH` → `413`; the spool is bounded | The two parsers have different limits and different failure modes for the same request. Tracker row exists | 1.10; API4 |

**Residual, overall.** The mount is the right shape for a module-by-module port and the
wrong shape to leave in place. Its risks are all *drift* risks — two lists, two CSRF
implementations, two parsers — and they end when Phase 11 retires the last Flask path.
Until then the control is the one-commit rule, and the rule has no test.

---

### 13.2 The Cognito dual acceptance window (ADR 0021, ADR 0003)

**What it is.** From Flip 1 until the Phase 10 cut-off, the API accepts a token from
**either** issuer: Supabase's or Cognito's. That is what lets users migrate without a forced
reset. It is also, for that window, two ways to be believed.

| # | STRIDE | Threat | L | I | Control | Residual | Ref |
|---|---|---|---|---|---|---|---|
| 13.2.1 | S | A Supabase token that should have stopped working keeps working, because the acceptance window is open longer than anyone remembers | M | H | Dual acceptance is a property of `AUTH_BACKEND=cognito` with a **stated end**: the Phase 10 cut-off, at which the whole legacy apparatus is deleted (tracker row) | The end date is a plan commitment, not a configuration value that expires by itself. **Nothing fails closed on the cut-off date.** New gap — tracker row | ADR 0021; 312(d) |
| 13.2.2 | E | Confusion between the two issuers' `sub` claims lets one user's Supabase token resolve to another user's Cognito identity | L | H | `custom:app_uid` carries the stable application user id; verification is local PyJWT against a **per-issuer** cached JWKS, and the issuer is checked, not inferred | None material — provided the issuer check is never relaxed to "try both keys". The test that would catch a relaxation is Phase 12's | ADR 0021; 312(a)(2)(i) |
| 13.2.3 | R | A sign-in during the window cannot be attributed to an issuer afterwards | M | M | Cognito logs its own sign-ins; the application's `process_runs` and audit rows carry the application user id, which is the same either way | The audit trail says *who*, not *which issuer believed them*. For a breach investigation covering this window that is a real gap, and it is cheap to close by logging the issuer — **new gap, tracker row** | 312(b) |
| 13.2.4 | I | The legacy Supabase **anon key** sits in `meridian-<env>/legacy-supabase-auth` for the whole window | M | M | Secrets Manager with a CMK; read only by the User Migration Lambda's role | The secret outlives its usefulness by design, because nothing deletes it on the cut-off date. It goes with the rest of the apparatus in Phase 10 | ADR 0021; CC6.1 |

---

### 13.3 The superadmin audited scope (`src/pg.with_superadmin`)

**What it is.** ADR 0011 promised "exactly one audited function" that may cross organization
boundaries. It now exists: `src/pg.with_superadmin(user_id, reason)`, with Alembic revision
`0010_superadmin`. Four `web_app.py` reads that used to run cross-organization on the
Supabase service key were moved behind it.

| # | STRIDE | Threat | L | I | Control | Residual | Ref |
|---|---|---|---|---|---|---|---|
| 13.3.1 | E | An ordinary admin reaches the superadmin scope | L | H | Superadmin is a row in Postgres, never a token claim and never a Cognito group; the function checks it on every call | None material. This is the design ADR 0011 asked for and it is now code rather than a promise | ADR 0011; 308(a)(4)(ii)(B) |
| 13.3.2 | R | A superadmin read happens and nothing records why | M | H | `reason` is a **required argument** — there is no overload without it — and the call writes an audit row | The reason is free text a caller types. It records that a human was asked to justify the read, not that the justification is true. That is the realistic ceiling for this control | 312(b); CC4.2 |
| 13.3.3 | I | A second cross-org path appears beside the audited one and nobody notices | M | H | `scripts/lint_org_scope.py` in CI lists every statement with no `org_id` predicate, and `tests/test_lint_org_scope_ratchet.py` **fails** when either count exceeds `scripts/org_scope_baseline.json` | The lint step itself is `continue-on-error: true` against a backlog of 101 violations and 56 unverifiable statements. The ratchet is the real gate: the backlog cannot grow, but it is not zero, so "every statement is org-scoped" is not yet a true sentence | ADR 0011; 312(a)(1) |

---

### 13.4 The User Migration Lambda (extends §5)

**What it is.** §5 already models the Lambda → Supabase Auth boundary. Two things have
changed since it was written and both are worth stating: the Lambda now ships with a
**hand-generated snapshot** of `auth.users`, and it fails **closed** until a secret a human
must fill in is filled in.

| # | STRIDE | Threat | L | I | Control | Residual | Ref |
|---|---|---|---|---|---|---|---|
| 13.4.1 | I | `lambda/user_migration/legacy_users.json` is a photograph of the identity store, committed alongside code | M | H | It carries no password hashes — the Supabase admin API does not expose them; `has_password` is **inferred** from the presence of an email identity. The file is generated on the day of each deploy and is stale the day after | It is still a list of every user's email address and identity providers, in a tracked repository. Not PHI, but it is the input to a targeted phish. Tracker rows exist for both the staleness and the inference | §5; C1.1 |
| 13.4.2 | D | The secret `meridian-<env>/legacy-supabase-auth` is created **empty**, so every sign-in fails closed until somebody fills it | H | M | Deliberate: fail-closed is correct here, and it is `needs-a-human` item 20 with a named step in `cognito-user-migration.md` | High likelihood, because it *will* happen on the first deploy. It is an availability event at Flip 1, not a security one, and the runbook is what shortens it | §5; A1.2 |
| 13.4.3 | I | The Lambda sees a migrating user's plaintext password once per migration | M | H | It never logs it (§5 row 5.5); its log group is CMK-encrypted with a 400-day retention like every other; **and, new in Phase 8, Inspector now scans Lambda as well as ECR**, so its dependency tree is assessed rather than assumed | The function is the one place in the estate where a password exists in clear text. The control is "it does not write it down", which is verified by reading the code, not by a runtime check | §5; 312(a)(2)(i) |

---

### 13.5 The GitHub Actions deploy role (`meridian-shared-iam-github-deploy`)

**What it is.** A workflow that can deploy is a workforce member that never sleeps.
`deploy.yml` mints a short-lived OIDC token and exchanges it for this role; no AWS key is
stored in GitHub.

| # | STRIDE | Threat | L | I | Control | Residual | Ref |
|---|---|---|---|---|---|---|---|
| 13.5.1 | E | A workflow on any branch, or in a fork, assumes the role | L | H | Trust policy: `StringEquals` on exactly one subject of exactly one repository — the `staging` GitHub Environment (`repo:…:environment:staging`). A job gets that subject only by declaring `environment: staging`, which `deploy.yml`'s `push` and `deploy` jobs alone do; the Environment's deployment-branch policy admits only `aws-migration` and `main`. Branch subjects and `pull_request` are **not** trusted (Codex CX-INF-02, 2026-09-16) | A newly committed workflow on a trusted branch could declare `environment: staging` itself; the Environment's required-reviewers setting is the control for that and is Andres's to switch on (tracker). The `pull_request` subject *is* trusted by the new diff role — see 13.7 | CC6.1 (deploy credentials) |
| 13.5.2 | E | The role's blast radius is the account, not the one stack its policy names | M | H | Honest statement, from critic round 3 (P5AR3-03): `cdk deploy` assumes `cdk-hnb659fds-deploy-role`, which `cdk bootstrap` created account-wide and which passes an `AdministratorAccess` execution role. **The `cloudformation:*`-on-one-stack statement is not the boundary.** What holds the line is `--exclusively` in the workflow and the two-branch trust policy | **Real and open.** A commit merged to either branch can, through this path, reach any stack in the account. The fix — a staging-only bootstrap qualifier with scoped `--cloudformation-execution-policies` — has a tracker row and is not done | CC8.1 |
| 13.5.3 | T | An image is substituted after review | L | H | Both ECR repositories are `IMMUTABLE`; the only tag any build pushes is the commit sha; Trivy fails the run on HIGH/CRITICAL **before** the push, and `.trivyignore` is empty | None material | CC8.1 (image provenance) |
| 13.5.4 | S | The workflow is dispatched by accident | L | M | `workflow_dispatch` only, with a typed `confirm` input that must equal `deploy-staging`, and a `guard` job that fails otherwise | None material | CC8.1 |

---

### 13.6 The web proxy on Render

**What it is.** Until Flip 2, the browser still reaches Meridian through Render. The Next.js
app proxies API calls at run time (`web/src/lib/proxy.ts`) rather than through
`rewrites()` — because `rewrites()` is evaluated during `next build` and any origin it names
is frozen into the routes manifest for ever (P5A-01, and `web.yml` fails the build on it).

| # | STRIDE | Threat | L | I | Control | Residual | Ref |
|---|---|---|---|---|---|---|---|
| 13.6.1 | I | A build-time API origin is baked into the routes manifest and the proxy points somewhere nobody intended | L | H | The `No baked API origin` step in `.github/workflows/web.yml` greps `.next/routes-manifest.json` and fails the build. `MERIDIAN_API_ORIGIN` is unset in that job on purpose — the manifest must come out clean anyway | None material; this one is a gate, not a convention | API8 |
| 13.6.2 | S | The proxy forwards a header the API trusts, from a caller who set it | M | H | On AWS the SPA's calls go browser → CloudFront → ALB → api in **one** pass: the ALB forwards `/api/*`, `/auth/*` and `/static/*` to the `api` target group ahead of the `/*` web rule, so the Next.js route handlers never run on ECS (P5AR5-01). There is no second proxy hop to rewrite `CloudFront-Viewer-Address` | **On Render there is still a hop**, and Render is where production runs until Flip 2. The AWS-side proof is `deploy-staging.md` §7.2 and it is unrun | 2.x; 1.9 |
| 13.6.3 | I | Render holds environment values for a system that is being replaced, and the three backend switches are set in a dashboard rather than in code | H | M | `render.yaml` declares them; the live services were provisioned outside the blueprint, so the dashboard wins | Two sources of truth for the switch that decides which database is live, with a tracker row and a strict ordering rule (auto-deploy off → set the switches → merge). Getting the order wrong crash-loops production | 9.4 |
| 13.6.4 | D | Render auto-deploys every commit to `main`, regardless of CI | H | H | None today. It is `needs-a-human` item 2 and the **first** row in `docs/migration-tracker.md` | Open, and it is the highest-likelihood row in this section: a merge to `main` deploys to production without a green build | CC8.1 |

---

### 13.7 The origin-verify secret, and the new read-only diff role

**What they are.** Two small surfaces that share a theme: a secret whose *rotation* is the
risky part, and an identity whose *read-only-ness* is the whole point — and, round 1's
correction, an identity whose read-only-ness is **not** the same as harmlessness when the
account it reads is a PHI account (13.7.5).

| # | STRIDE | Threat | L | I | Control | Residual | Ref |
|---|---|---|---|---|---|---|---|
| 13.7.1 | S | A request reaches the ALB without passing CloudFront, bypassing the WAF | M | H | Two independent controls (ADR 0018): the security group admits only CloudFront's managed prefix list, **and** the ALB requires the `X-Origin-Verify` header | None material while both hold. Neither alone is sufficient and the ADR says so | ADR 0018; CC6.1 |
| 13.7.2 | D | A rotation drops all traffic — the ALB stops accepting what CloudFront is sending | M | H | The two-step rotation in `rotate-origin-verify-secret.md`: the ALB accepts both versions, CloudFront swaps, the old version is removed. Explicit **version ids** in context, never a staging label — a label renders identical template text at every rotation, so CloudFormation never re-resolves the listener rules while CloudFront does move (finding H-F), and the ALB then refuses everything the edge sends | The failure mode is documented, detectable and recoverable, and the runbook has never been run | ADR 0018; A1.2 |
| 13.7.3 | E | The CI diff identity is used to change something | L | H | **New in Phase 8.** `meridian-shared-iam-github-diff` may assume exactly one bootstrap role — `cdk-hnb659fds-lookup-role`, which `cdk bootstrap` creates with `ReadOnlyAccess` and a deny on `kms:Decrypt` — read `meridian-*` stack templates (`DescribeStacks`, `ListStackResources`, `GetTemplate`), and read the bootstrap version parameter. No `Resource: "*"`, no write action; six tests assert it. `backend.yml` passes `--change-set=template`, so the CLI never asks for `CreateChangeSet` and never assumes `cdk-…-deploy-role` | None material *for changing something*. The reach of what it can READ is 13.7.5, which is a different row and the one that moved | CC8.1 (CI diff) |
| 13.7.4 | S | A **fork's** pull request assumes the diff role | L | M | **Closed structurally in round 1 (P8-03/P8-11), not by a workflow condition.** The `pull_request` subject is gone from the trust policy, so the only subjects left are pushes to `refs/heads/main` and `refs/heads/aws-migration` — and a fork cannot push to either. The old control (an `if:` comparing `head.repo.full_name` to `github.repository`) was necessary only because GitHub builds the `pull_request` subject from the **base** repository; with no such subject there is nothing to confuse. GitHub also withholds `id-token` from a fork's `pull_request` run, so the assume-role would have failed regardless | None material. The residual that remains is that the branch protection on those two branches is now what stands between unreviewed code and this role | CC8.1 (CI diff) |
| 13.7.5 | E | `cdk diff` executes the diffed branch's own Python on a runner holding AWS credentials, and those credentials reach further than "Meridian's templates" | M | M | **Re-scoped in round 1 (P8-03).** The round-1 entry said the worst case was reading Meridian's templates. It is not: the role may assume `cdk-<qualifier>-lookup-role`, which `cdk bootstrap` creates with the AWS-managed **`ReadOnlyAccess`** policy. That is account-wide read — `logs:GetLogEvents`/`FilterLogEvents` over every log group (including `audit.phi_access`'s once it is live, and the api log group), `cognito-idp:ListUsers` over the user pool, `rds:Describe*`, `secretsmanager:ListSecrets` and `DescribeSecret` (names, ARNs, rotation state — not values: `GetSecretValue` is not in `ReadOnlyAccess`), and `s3:GetObject` on every object not encrypted under a CMK (the `kms:Decrypt` deny is what keeps the `phi` and `artifacts` buckets out, since both are CMK-encrypted). **The control is now WHO can put code there:** the `pull_request` subject is withdrawn, the job runs on `push` to the two protected branches only, so the Python that runs has been through review. Additionally: a one-hour session, and a job that posts nothing anywhere — the log is the artifact, so there is no token for a comment action to leak | **Accepted, and lower than round 1's.** Before: any pull request, from anyone who could open one, ran code against an account-wide read-only identity. After: a merged commit does. What is left is that a reviewer who approves a malicious CDK change gives it those reads — which is the same trust the deploy role already requires, and a strictly smaller one | CC8.1 (CI diff) |

---

### 13.8 What this review added to the gap list

Four new gaps, each with a row in `docs/migration-tracker.md`:

- **G-8 — the one-commit rule has no test.** Nothing fails a build that lands a path in both
  FastAPI and Flask, or that leaves a ported path in `next.config.mjs`'s `jinja` allowlist.
  The rule is ADR 0023's load-bearing control and it is enforced by review alone (13.1.1).
- **G-9 — the dual acceptance window does not close by itself.** The Phase 10 cut-off is a
  plan commitment, not a configuration value; nothing fails closed on the date (13.2.1).
- **G-10 — a sign-in during the window is not attributable to an issuer.** The audit rows
  record the application user id, which is the same whichever issuer believed them (13.2.3).
- **G-11 — two multipart parsers, two sets of limits.** werkzeug parses inside the FastAPI
  half, so upload limits are enforced by one framework's rules inside the other's (13.1.5).

The gaps this review *re-states* rather than discovers, because they were already known and
are still open: the deploy role's real blast radius (13.5.2), Render auto-deploy on `main`
(13.6.4), and the org-scope backlog behind the ratchet (13.3.3).

---

## 14. Gap status after the local-first build · **2026-09-24** (Phase 12 T28)

Appended, not edited in place (§12). What changed for the §11 and §13.8 gaps since the
Phase 8 review. "In code" means merged on `aws-migration` and tested against the local
PostgreSQL fixture; nothing below is deployed.

| Gap | Status 2026-09-24 | Evidence |
|---|---|---|
| G-1 QBO double-post | **Closed in code on RDS.** Every journal post writes its intent to `public.job_idempotency` (revision `0012`, requestid history `0018`) before the create, through `src/qbo_posting.post_journal_once`; the qb-usa `qbo_push` job and `scripts/qbo_post_je.py` both use it, and a definite failure rotates the requestid while an ambiguous one keeps it (ADR 0032). The Supabase path keeps the derived requestid until Phase 10. | `tests/test_qbo_push_job_pg.py`, `tests/test_qbo_post_je_ledger_pg.py`, `tests/test_job_idempotency_pg.py`; tracker T:49 |
| G-2 `/auth/set-session` | **Closed** — the route was deleted in Phase 4 step 5. | `tests/test_retired_auth_paths.py` |
| G-4 MFA | Open until Flip 1 (Stage 3). The sign-in challenges (`NEW_PASSWORD_REQUIRED`, `MFA_SETUP`) have screens. | tracker T:33, T:210 |
| G-5 `ProxyFix(x_for=2)` | **FastAPI half closed:** `ProxyHeadersMiddleware` with `FORWARDED_ALLOW_IPS` in `api/main.py`. The Flask `ProxyFix(x_for=1)` half is checked in the Phase 9 rehearsal. | tracker T:97, T:161 |
| G-7 log content | **Code half closed:** `src/log_safe.RedactingFilter` on the one root handler, JSON lines that carry ids and codes only, exceptions reduced to class and frames. The CloudWatch sampling after a real run is Stage 3. | `tests/test_log_setup.py`, `tests/security/test_no_phi_in_json_logs.py` (`--known-bad` all red); tracker T:51/T:52 |
| G-8 one-commit rule | **Closed:** `scripts/lint_route_ownership.py` is a CI step. | `tests/test_lint_route_ownership.py`; tracker T:126 |
| G-9 dual window | Open (Phase 10, Stage 3). | tracker T:127 |
| G-10 issuer attribution | **Closed:** every log line carries `auth.issuer`. | `tests/test_log_setup.py`; tracker T:128 |
| G-11 two multipart parsers | Open until the Flask mount goes; the ported routes share one parser with the zip-bomb bound and the file-signature check. | tracker T:129, T:170 |

New controls this build added that bear on the §10 OWASP rows (the control matrix §3 carries
the evidence per row): the file-signature (magic bytes) check at every input
(`src/file_signature.py`), the GuardDuty malware-tag gate before a stored upload is read
(`src/process_inputs.py`), the execute compare-and-set (`RUN_STATE_CHANGED`) and
`Idempotency-Key` on v2/v3 execute, QuickBooks tokens sealed with a KMS-wrapped data key
(ADR 0044), the webhook outbox written in the same transaction as the run's state change, and
ruff's bandit rules (`S`) in CI.
