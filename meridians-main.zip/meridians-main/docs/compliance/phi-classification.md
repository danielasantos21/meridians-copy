# PHI classification — Meridian

**Status:** first issue. Written for the AWS migration (see `docs/aws-migration-plan.md` §1
"PHI: resolved as YES", §2.3, Track C in §4).
**Scope:** every place Meridian stores or produces data today, and where each one is
supposed to land after the migration.
**Rule used throughout this file:** no real patient or employee value appears here.
Column names, row counts and file paths only.

**Jargon, defined once**

| Term | Plain meaning |
|---|---|
| **PHI** (protected health information) | Health or payment information about a person that can be tied back to them. |
| **IIHI** (individually identifiable health information) | The same idea one step earlier: health/payment data plus anything that identifies the person. |
| **Covered entity** | The clinic/health plan itself — here, Stella Mattina Health, Inc. |
| **Business associate (BA)** | A vendor that handles PHI on the covered entity's behalf. That is Meridian. |
| **BAA** (business associate agreement) | The contract that makes that handling legal. |
| **Safe Harbor de-identification** | 45 CFR 164.514(b)(2): strip all 18 listed identifiers and the data stops being PHI. |
| **Minimum necessary** | 45 CFR 164.502(b): only use or disclose the least PHI the job actually needs. |
| **HMAC token** | A one-way keyed fingerprint of a value. Same input → same token, but the token cannot be turned back into the input without the key. |

---

## 1. PHI determination

**Meridian is in HIPAA scope as a business associate. It handles PHI today.**

Meridian receives billing-system exports from Stella Mattina Health, turns them into
journal entries, and keeps both the raw rows and the enriched rows. The exports are not
aggregate — they are one row per patient payment.

### The identifiers that are actually present

45 CFR 164.514(b)(2) lists 18 identifiers. Data is only de-identified under Safe Harbor
if *all* of them are removed. The billing channel carries at least these:

| 164.514(b)(2) identifier | Where it is, in this repo |
|---|---|
| (vii) Account numbers | `public.transactions.patient_id` — `supabase_migrations/migrations/002_processing_tables.sql:40`. It is populated from the billing export's **`Patient Acct No`** column at `src/enrichment.py:201`. |
| (viii)/(xviii) Other unique identifying numbers | `claim_no`, `encounter_id` — `002_processing_tables.sql:54-55`, populated at `src/enrichment.py:215-216`. |
| (iii) Dates directly related to an individual (service, payment) | `service_date`, `payment_date` — `002_processing_tables.sql:52-53`. |
| Treating/billing provider (not itself an (b)(2) item, but it makes the row about care) | `billing_provider`, `department` — `002_processing_tables.sql:46-48`. |
| The whole row, verbatim | `public.source_transactions.raw_data TEXT` — `002_processing_tables.sql:181`. Whatever the billing system exported, byte for byte. |

Account number + service date + billing provider + payer + dollar amount describes
**payment for the provision of health care to an identifiable individual**. That is IIHI,
and once Meridian holds it on behalf of the clinic, Meridian is a business associate.

The plan's live counts (`docs/aws-migration-plan.md:52`): 76,132 `transactions` rows,
17,606 distinct patient account numbers, 167,290 `source_transactions` rows. Those counts
are quoted from the plan; this document did not re-query the database (the instruction set
for this work forbids reading client data).

### The second channel: QB USA payroll

`src/qb_usa_payroll_processor.py:46-53` is an explicit privacy warning written by the
author of that module. In its own words, `RunResult.inputs` holds the raw parsed rows of
every input file for the run's lifetime, **including UNUM's `EE DOB` and BCBS's
member/subscriber ID**, and net-pay-adjacent dollar figures from the ADP register. The same fields are among those the review workbook refuses to embed.

**How that refusal works (changed in Phase 0c, commit `fef0bae`).** It used to be a
**blocklist** — `RAW_WITHHELD_HEADERS`, a short tuple of banned column names per source
file. A blocklist fails open: a column that ADP or a carrier *added* or *renamed* next month
was embedded un-blanked by default, and nobody was told. The first anyone would have heard
of a new employee-data column was when somebody opened the file.

It is now an **allowlist** — `RAW_ALLOWED_HEADERS` in `src/qb_usa_payroll_workbook.py`, one
tuple of *permitted* column names per source kind (`register`, `unum`, `bcbs`, …). Every
name on it has been read and classified as booked money or non-identifying context, so
adding one is a deliberate act. Anything not on the list is blanked, listed in that sheet's
"Withheld columns" block, and counted in the sheet title — so a source-layout change shows up
as a visible blank column rather than a silent leak. `EE DOB`, `Member ID`, `Subscriber ID`,
`Take Home` and the three "- Employee Tax" columns are withheld by **omission**: they are
simply not on the allowlist, and no rule has to name them. The file contains column *names*
only — no employee data.

**A nuance the migration plan flattens.** HIPAA's definition of PHI (45 CFR 160.103)
*excludes* employment records a covered entity holds in its role as employer. A payroll
register is an employment record. But **UNUM and BCBS carrier bills are group health plan
data** — enrollment, member ID, subscriber ID, date of birth — and group health plan data
about employees is PHI in the hands of the plan and its business associates. The practical
answer does not change (treat both as protected, keep both out of logs), but the *reason*
differs per file, and that matters when the BAA and the risk analysis are written:

- ADP register, ADP invoice, employee master → **sensitive employee PII**, not PHI.
- UNUM and BCBS carrier files → **PHI** (health-plan enrollment data with DOB + member ID).

### Conclusion

Design, controls and evidence proceed as **PHI-in-scope**. Two consequences follow
immediately and are not optional:

1. Every vendor that can see this data needs a signed BAA (AWS, and today Supabase and
   Render and Resend — see `docs/compliance/data-flows.md`).
2. The journal-entry *output* being aggregate does not de-scope anything. The storage
   underneath it is row-level.

---

## 2. Classification of every store and artifact

Classification values: **`phi`** = can carry patient or health-plan identifiers;
**`internal`** = business data, no patient identifiers, still confidential;
**`public`** = safe to publish.

"Who can reach it today" refers to the live permission model: `public.org_members.role`
(`004_roles_permissions.sql`), per-process rows in `public.role_permissions`
(`029_role_permission_processes.sql:24-31`), and `public.superadmins`, which
`src/auth.py:838-848` treats as a cross-organization bypass
(`src/auth.py:610`, `src/auth.py:632` grant every module and every permission).

### 2.1 Database tables (Supabase Postgres today → RDS after)

| Table | Class | Identifiers it can carry | Reachable today by | Target after migration |
|---|---|---|---|---|
| `transactions` | **phi** | `patient_id` (account no), `claim_no`, `encounter_id`, `service_date`, `payment_date`, `billing_provider`, `amount` | org members with `revenue` permission; superadmin | non-identifier columns → `public` schema on RDS **+ `patient_ref`** (HMAC); `patient_id`/`claim_no`/`encounter_id` → `phi.transaction_identity` (plan §2.3) |
| `source_transactions` | **phi** | `raw_data` = the verbatim billing row (everything above and any column the export happened to include) | written at `web_app.py:1294`; **no application reader** — `get_source_transactions` (`src/database.py:1818`, `:3030`) has no call site outside `database.py` | `phi.source_transactions` (plan P-3); candidate for deletion once Andres confirms nobody reads it |
| `uploads` | internal | file name, hash, size, record count, total amount | revenue/payroll users | `public` on RDS |
| `import_batches`, `processing_runs`, `processed_entries`, `process_runs` | internal | run metadata, counts, totals, state | per-process permission | `public` on RDS |
| `journal_entries` | internal | account, department, location, amount, aggregate description (`{Period} - {FY} - Cash Sales - {Location} {PayerType}`) | revenue users | `public` on RDS |
| `unmapped_items` | internal | unmapped payer/location/provider strings | revenue users | `public` |
| `payroll_employees` | internal (employee PII) | `employee_name`, `employee_code`, per-account pay amounts (`002_processing_tables.sql:107-128`) | payroll users | `public` |
| `employee_clinic_allocations` | internal (employee PII) | `employee_name`, `employee_normalized`, location, percentage | payroll/config users | `public` |
| `qb_usa_employee` | internal (employee PII) | `employee_key`, `name`, entity, variant (`020_qb_usa_payroll_roster.sql:120-126`) | `qb_usa_payroll` permission | `public` |
| `qb_usa_payroll_gate` | internal (employee PII) | `offenders` — the migration's own note says it holds **real employee names and dollar amounts** (`021_qb_usa_payroll_runs.sql:25-27`) | `qb_usa_payroll` permission | `public` — but see §5; this is the column most likely to end up in a log line |
| `qb_usa_payroll_journal` | internal | journal no, date, variant, line count, total, storage path | `qb_usa_payroll` permission | `public` |
| `ts_benefit_override` | **phi-adjacent** | carrier-bill subscriber names routed to a coding (`019_totalsource_benefit_overrides.sql:23`, `036_ts_benefit_override_fixed_pool.sql:5`) | `qb_usa_payroll` permission | `public`; re-review once the risk analysis decides on carrier data |
| `config_providers`, `config_locations`, `config_payers`, `config_employees`, `config_mx_employees`, `config_*` | internal | provider and employee names, mapping rules | `config` permission | `public` |
| `qb_*_map` tables, `qb_usa_*_rule`, `qb_usa_coding_exception` | internal | coding rules only | `config` / `qb_usa_payroll` | `public` |
| `pnl_*` (`pnl_cost_lines`, `pnl_driver_values`, …) | internal | provider-level aggregates and counts (e.g. `unique_patients` — a count, never a patient) | `pnl_provider` permission | `public` |
| `uniform_*` (Wearbly) | internal (employee PII) | employee name, size, order | Wearbly rows exist but the process is retired (plan P-5) | `public`, dormant |
| `organizations`, `org_members`, `org_modules`, `roles`, `role_permissions`, `superadmins`, `invite_codes` | internal | workforce emails and roles | admins; superadmin | `public` |
| `qbo_connection` | **secret** | Intuit OAuth refresh/access tokens (`035_qbo_connection.sql`, read by `src/qbo_client.py`) | server only | `public` schema on RDS, column-encrypted or moved to Secrets Manager — decide in Phase 8 |
| `artifact_downloads` | internal (audit) | `user_email`, `ip`, `user_agent`, artifact name, expiry (`022_process_runs.sql:107-120`) | holders of the process's `results` permission | `audit` schema on RDS |
| `invoices`, `clients` | internal | Meridians' own billing to Stella Mattina | invoice permission | `public` |
| `fiscal_calendar`, `config_fiscal_calendar` | internal | period dates | all | `public` |

### 2.2 Object storage

| Bucket / path | Class | Contents | Reachable today by | Target |
|---|---|---|---|---|
| Supabase `uploads` (`003_storage_buckets.sql:5`) | **phi** | the raw billing export, the bank file, and the ADP/UNUM/BCBS carrier files, under `{org_id}/{batch_id}/…` | RLS policy `003_storage_buckets.sql:10-17` scopes to the caller's org; `src/storage.py:34-49` re-checks the first path segment; signed URLs bypass both | S3 **`phi` bucket**, SSE-KMS, Object Lock off, GuardDuty malware scan before processing (plan §2.3) |
| Supabase `outputs` (`003_storage_buckets.sql:6`) | **phi** (mixed) | generated workbooks, JE CSVs, review workbooks, ZIP bundles (`src/storage.py:87-99`, `web_app.py:567`, `web_app.py:4630-4634`, `src/qb_export_artifacts.py:156`) | same RLS + path check; signed URL, TTL 120 s single file / 300 s bundle (`src/storage.py:17-21`) | split: tokenized/aggregate artifacts → S3 **`artifacts`**; anything carrying `Patient Acct No` or carrier rows → S3 **`phi`** (plan P-2) |
| Supabase `templates` (`003_storage_buckets.sql:7`) | internal | workbook templates | any authenticated user (`003_storage_buckets.sql:20-22`) | S3 `artifacts` |
| Container local disk `data/input/` (`web_app.py:245`) and `data/input/qb_usa_payroll_runs/<run_id>/` (`web_app.py:4180`, `src/api/v2/qb_usa_runs.py:871`) | **phi** | every uploaded file, staged before and during processing | the running container; deleted only on the failure/cancel paths (`src/api/v2/qb_usa_runs.py:877`, `:880`, `:1011`) | ephemeral ECS task storage encrypted with a customer-managed key; add an unconditional cleanup |
| System temp dir (`web_app.py:5198`, `web_app.py:5231`, `web_app.py:4565`) | internal | config export/import workbooks, QB export staging | the running container | same; `web_app.py:5231` writes an uploaded file into the *shared* temp dir under a caller-supplied basename — fix regardless of migration |
| The MacBook: `output/`, and the two workbooks the plan names (Track C item 11) | **phi** | local copies of generated workbooks | one laptop | delete / move under the Phase 0 sweep |

### 2.3 Generated artifacts

| Artifact | Class | Identifiers | Where produced | Target |
|---|---|---|---|---|
| Enriched revenue workbook ("DB" sheet) | **phi** | writes the **`Patient Acct No`** column into the workbook — `src/exporters.py:2085`, `:2138-2139` (template path) and `src/exporters.py:2758` (`_write_db_sheet`) | `src/exporters.py` | default export becomes tokenized; a permission-gated detail export goes to the `phi` bucket (plan P-2) |
| JE CSV (`JE_Revenue_{Location}_{Period}_{FY}.csv`) | internal | aggregate credit lines per department × payer type + one clearing debit; description is `{Period} - {FY} - Cash Sales - {Location} {PayerType}` | `src/je_generator.py` | `artifacts` bucket |
| Payroll JE / booking JE CSV | internal | department, account, amount; descriptions are `{period} - {fy} - Payroll` / `… Reconciling` / `… Clearing` (`src/booking_je_generator.py:150`, `:189`, `:205`) — no names | `src/booking_je_generator.py` | `artifacts` |
| QB USA review workbook (embedded RAW source sheets) | **phi** | carries employee names by design; DOB / Member ID / Subscriber ID / take-home are withheld by **omission from the `RAW_ALLOWED_HEADERS` allowlist** (`src/qb_usa_payroll_workbook.py`, Phase 0c) — anything not on the list is blanked and reported | `src/qb_usa_payroll_workbook.py` | `phi` bucket (carrier rows) |
| ZIP bundle of a run's outputs | inherits the worst member | — | `web_app.py:567`, `src/api/v2/qb_usa_runs.py:1413` | follows its members |
| Invoice / service-agreement PDF | internal | Meridians' own billing; ACH details from `.env` | `src/invoice_generator.py` | `artifacts` |
| Application log stream | **currently phi-risk** | see §5 | Render logs today | CloudWatch Logs, 400-day retention, with the §5 fixes made first |
| Outbound email | internal | invite code + org + role (`src/email_service.py:91`); run summary = record **count** and **total amount** only (`src/email_service.py:133-137`) | Resend | SES (plan Phase 7) |
| Audit trail | internal | `artifact_downloads` today; `audit.phi_access` after migration, which must record who/what/when/how many rows and **never a PHI value** (plan §2.3) | — | `audit` schema + Object-Locked audit bucket |

---

## 3. The two channels, end to end

### Channel A — billing exports → transactions → journal entries

1. **Ingest.** Browser upload → Flask, saved to `data/input/` under a collision-proof name
   (`web_app.py:275-287`), and uploaded to the Supabase `uploads` bucket
   (`src/storage.py:70-85`).
2. **Enrich.** `src/enrichment.py:201-216` maps `Patient Acct No` → `patient_id`,
   `Claim No` → `claim_no`, `Encounter ID` → `encounter_id`, plus payer/location/provider
   mappings.
3. **Persist.** Enriched rows → `public.transactions` (`src/database.py:695-720`,
   `:2130-2148`). Verbatim rows → `public.source_transactions`
   (`web_app.py:1294` → `bulk_add_source_transactions`).
4. **Aggregate & export.** JE lines per department × payer type; CSVs plus the enriched
   workbook, uploaded to the `outputs` bucket.
5. **Downstream.** Optional push to QuickBooks Online (`src/qbo_client.py`) using the
   aggregate JE lines only; the line `Description` is the JE row's own description
   (`src/qbo_je_adapter.py:112`, truncated to 4000 chars at `:157`), which for revenue is
   the aggregate string above.
6. **Persisted copies that survive the run:** `transactions`, `source_transactions`,
   `uploads`, `journal_entries`, the `uploads` bucket object, the `outputs` bucket objects,
   and whatever is still on the container's disk.

### Channel B — ADP / UNUM / BCBS → QB USA payroll

1. **Ingest.** Files are uploaded through `/api/v2` and classified by filename convention
   into `register_*`, `invoice_*`, `benefits_1_unum.csv`, `benefits_2_bcbs.csv`
   (`src/api/v2/qb_usa_runs.py:591-690`); Excel uploads are flattened to CSV in place
   (`:523-543`). They are staged on local disk at
   `data/input/qb_usa_payroll_runs/<run_id>/` (`:871`).
2. **Parse.** `src/qb_usa_payroll_parsers.py` → `RunResult.inputs`, which per
   `src/qb_usa_payroll_processor.py:46-53` **holds the raw rows including DOB and member
   IDs for the lifetime of the run**.
3. **Persist.** Run header in `import_batches`; per-journal rows in
   `qb_usa_payroll_journal`; gate results, including the `offenders` list of names and
   amounts, in `qb_usa_payroll_gate` (`021_qb_usa_payroll_runs.sql:40-90`). Roster and
   coding rules in `qb_usa_employee` / `qb_usa_*_rule` (migration 020).
4. **Export.** Up to nine journal CSVs per run plus the review workbook, uploaded to the
   `outputs` bucket (`web_app.py:4630-4634`, `src/qb_export_artifacts.py:146-158`).
5. **Downstream.** QuickBooks Online, aggregate lines only.

---

## 4. Minimum-necessary review

**The plan's claim, verified.** `docs/aws-migration-plan.md:150` says the only reachable
use of the raw patient identifier is duplicate detection at `src/exporters.py:979-990`.
Confirmed: `_detect_duplicates` builds its key from
`['Patient Acct No', 'Service Date', 'Payment', 'Claim No']` at `src/exporters.py:981` and
only ever calls `DataFrame.duplicated` / `groupby` on it. Nothing there needs the cleartext
value, so an HMAC token works identically — with one caveat the plan should state: the
duplicate key also includes `Claim No`, so **`claim_no` has to be tokenized with the same
key**, not just `patient_id`, or the check breaks.

**Where the identifier reaches a workbook.** Three sites, all in the enriched-data
workbook's "DB" sheet: `src/exporters.py:2085` (column spec), `:2138-2139` (cell write),
`:2758` (the non-template writer). This is the single place `Patient Acct No` leaves the
database in a file a person can open, and it is the right place to apply plan P-2.

**Does `patient_id` reach the API or the UI?** No.
- `grep` for `patient_id|claim_no|encounter_id` across `src/` and `web_app.py` returns only
  `src/enrichment.py` (the dataclass and the mapping) and `src/database.py` (the INSERT
  column lists). No route, no serializer, no response body.
- `src/api/v2/*` contains no reference to any of the three.
- `web/src` contains no patient identifier at all. The only "patient" hits are prose in the
  P&L metric catalogue — `web/src/app/pnl-provider/ecw-catalogue.ts:155-161` describes a
  `unique_patients` **count**, and `:23-24` explains that the upstream source is assembled
  per patient. Descriptive text, no values.

**Minimum-necessary gaps that remain:**

| Gap | Evidence | Fix |
|---|---|---|
| `source_transactions.raw_data` is written on every run and read by nothing | writer `web_app.py:1294`; reader `src/database.py:1818` / `:3030` has no external call site | stop writing it, or move to `phi.source_transactions` and set a retention (plan's deferred item) |
| Signed URLs bypass every row-level check once minted | `src/storage.py:15-21` says so in its own comment; mitigated by a 120 s TTL and the `assert_org_path` check at `:34-49`, and audited at mint time in `artifact_downloads` | keep the short TTL on S3 presigned URLs; keep the mint audit |
| Superadmin is a silent cross-org bypass | `src/auth.py:610`, `:632`, `:838-848` — grants every module and permission, writes no audit row | the plan's "bypass only through one named function that writes an audit row" (§2.2) must cover superadmin, not just RLS |
| Whole-workbook detail export is the default | `src/exporters.py:2138-2139` | P-2: tokenized by default, cleartext behind a permission + audit row |

---

## 5. PHI and PII in logs

### 5.1 The plan's list, checked line by line

`docs/aws-migration-plan.md` cites `src/qb_usa_payroll_processor.py:311, 550, 628, 636,
723, 734`. **Four of those six line numbers are stale** — they point at docstrings and
comments, not at logging calls. The file has moved since the plan was written. What is
actually at each line:

| Plan's line | What is really there | Verdict |
|---|---|---|
| `:311` | docstring of `NameIndex` | stale. The real leak is **`:319`**: `logger.warning("NameIndex: %r is ambiguous — …")` — logs an employee/subscriber **name**. |
| `:550` | docstring of the register/roster join | stale. The real leak is **`:558`**: `logger.warning("Register name %r resolves to no single coded person…")` — logs a **name**. |
| `:628` | a coding dict literal | stale. Nearest logging call is `:636`. |
| `:636` | `logger.warning("%s register row %s has no Employee ID…")` | **not a leak — it is the mitigation.** The comment at `:632-635` says explicitly: "Identify the row, not the person. Application logs go to the hosting provider and are retained and read far more widely than the workbook." It logs entity + register row number. The plan has this one backwards. |
| `:723` | docstring of the carrier-charge matcher | stale. |
| `:734` | `charge["matched_name"] = emp.name` — an in-memory assignment, no logging | stale, though it is a genuine data-flow note: the cross-entity name is carried on the charge dict and reaches the gate offenders list. |

### 5.2 The real inventory (grep of `logger.` / `logging.` / `print(`)

**Names or ids in log lines — `src/qb_usa_payroll_processor.py`:**

| Line | What is logged |
|---|---|
| `:319` | ambiguous **name** (`%r`) and how many records share the key |
| `:558` | register **name** that resolves to no coded person |
| `:644` | `"Employee ID %r is shared by %d paid rows"` — **employee id** |
| `:744` | `"Benefit override for %r (%s) matched nobody paid this run"` — **carrier-bill name** |
| `:760` | `"Redistribution name %r matched nobody paid this run"` — **carrier-bill name** |
| `:1409-1415` | `print()` in the CLI `main()`: journal numbers, totals, gate pass/fail. No names, but it goes to stdout, which on a container is the log stream. |

Clean by design and worth keeping that way: `:636` (row number, not person), `:671`,
`:779-782`, `:790-795` (entity + counts + amounts), `:1069` (source file), `:1329`
(a count of people, not the people), `:1382` (gate name, amounts, **count** of offenders —
deliberately not the offenders themselves).

**Names in log lines — elsewhere, not in the plan's list:**

| Location | What is logged |
|---|---|
| `src/booking_je_generator.py:88` | `"Employee '{emp.name}' (FILE# {emp.file_number}) has no allocation, skipping"` — **name + file number**. Also copied into a user-facing `warnings` list at `:87`. |
| `src/database.py:1439`, `:1459` (SQLite) and `:2725`, `:2733` (Postgres) | `"Saved {n} allocations for {employee_name}"` / `"Deleted allocations for {employee_name}"` — **name** |
| `src/database.py:3266` | `"sync_mx_employees_from_file: {employee_id} failed"` — **employee id** |
| `src/adp_v3_processor.py:227`, `:444`; `src/adp_booking_v5_processor.py:333`, `:428`, `:581`; `src/booking_je_processor.py:150-176`, `:293` | file paths and sheet headers. Not identifiers, but the **file path** of a payroll export is itself a hint and shows up in a shared log stream. |

**`exc_info=True` handlers — `web_app.py`:** the plan names `~392, 412, 471, 519, 534`.
Those are approximately right but off by a line or two (the real calls end at `:406`,
`:412`, `:426`, `:440`, `:485`, `:507`, `:533`, `:548`, `:604`, `:611`). In total there are
**22** `exc_info` sites in `web_app.py`; the PHI-relevant ones are the processing and export
paths: `:3972`, `:4206`, `:4468`, `:4604`, `:4717`, `:4726`, `:4924`, `:4943`, `:7821`,
`:7862`, `:7890`. The risk is not the handler — it is that a pandas, openpyxl or psycopg2
exception routinely embeds the offending cell value or the failing SQL row in its message,
so a traceback can print a patient account number or an employee name that no format string
ever asked for. Two of them also use f-strings around the exception
(`web_app.py:1937`, `:1956`, `:7821`, `:7862`, `:7890`), which defeats any later scrubbing
based on log-record arguments.

### 5.3 What to do about it

1. Replace names with stable surrogates in every line in §5.2 — `src/qb_usa_payroll_processor.py:632-635`
   already documents exactly the right pattern (identify the row, not the person).
2. Add a logging filter that redacts on the way out, so a traceback cannot leak what a
   format string does not name. Do this **before** logs start going to CloudWatch, because
   CloudWatch retention (400 days, plan §2) makes anything logged a 400-day problem.
3. Never log a `RunResult` or any field under `RunResult.inputs`
   (`src/qb_usa_payroll_processor.py:51-52`). Worth an explicit test.
4. Treat the `qb_usa_payroll_gate.offenders` column and `web_app.py`'s error responses as
   the two most likely ways names reach a place they should not.

---

## 6. Open items for the risk analysis

- Decide, in writing, whether carrier (UNUM/BCBS) files are PHI or employee PII — §1 says
  PHI; the BAA and the training material need one answer.
- Confirm nobody reads `source_transactions.raw_data`, then stop writing it.
- `patient_ref` is a keyed HMAC, not de-identification: service dates stay, so the data is
  still PHI (plan §2.3 says this; keep saying it).
- The `qbo_connection` token columns are secrets sitting in an application table.
- `src/phi.py` does not exist yet — it is the plan's design, not the current state.


## 5a. Status after Phase 0c (2026-09-15)

The leak inventory in §5 describes the tree at commit `4ccddcb`. Phase 0c fixed every listed
site plus two the inventory missed:

- `src/qb_usa_payroll_roster.py` logged the employee name when storing coding (found by the
  new lint, `scripts/lint_no_phi_logging.py`).
- The auth callback in `web_app.py` logged the whole Supabase session response — access and
  refresh tokens — on failure.

Names and ids in log lines are replaced by `src/log_safe.py` surrogates (`log_ref`, a short
keyed-free hash for correlating lines; `id_tail`, the last four characters for user-facing
text). The raw-input sheet in the QB USA payroll workbook is now an **allowlist**
(`RAW_ALLOWED_HEADERS`): a column a carrier adds next month is blanked and listed, not
shipped. Names stay on that allowlist on purpose — the workbook is access-controlled and the
name is the audit-trail join key; the log stream is not.

**Closed 2026-09-24:** the redacting logging *filter* (§5.3 item 2) — `src/log_safe.RedactingFilter`,
in front of the JSON handler `src/log_setup.configure_logging` installs. Secrets and
identifier-shaped values are redacted from every message and `extra=` value, and an exception is
logged as its class and frames only, never its text, so a traceback can no longer carry a cell
value into CloudWatch. `tests/security/test_no_phi_in_json_logs.py` proves it, with known-bad
controls.
