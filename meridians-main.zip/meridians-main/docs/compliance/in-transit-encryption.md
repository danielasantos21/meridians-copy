# Position paper — encryption in transit, and the one plaintext hop (DRAFT)

**Status: DRAFT for Andres to review, correct and sign. Not evidence until signed.**
Drafted 2026-09-24 by Claude from the CDK code as it stands on `aws-migration`; every
statement about the estate cites the file it was read from. The runbook asks Andres to write
this paper (`docs/runbooks/production-readiness.md` §10) — this draft exists so that writing
it is an edit, not a blank page. The two statements marked **VERIFY** are about AWS's own
platform and must be checked against AWS's current documentation before signing; nothing in
this repository can prove them.

Control: HIPAA Security Rule 45 CFR 164.312(e)(2)(ii), *Encryption* (addressable), and
164.312(e)(2)(i), *Integrity controls* (addressable). Control-matrix rows 312(e)(2)(i) and
312(e)(2)(ii).

---

## 1. What "addressable" requires

An addressable specification is not optional. The covered entity or business associate must
implement it, **or** document why it is not reasonable and appropriate and what equivalent
measure is used instead (45 CFR 164.306(d)(3)). This paper is that documentation for exactly
one network hop. Every other hop is encrypted.

## 2. The hops, and which are encrypted

| Hop | Protocol | Where it is set |
|---|---|---|
| Browser → CloudFront | TLS 1.2+ (`TLS_V1_2_2021` security policy) | `infra/meridian/stacks/edge.py` (distribution `minimum_protocol_version`) |
| CloudFront → ALB | TLS 1.2 (origin SSL protocols) to the HTTPS listener (`RECOMMENDED_TLS` policy) | `edge.py` (origin, HTTPS listener) |
| **ALB → ECS task (`api` :8000, `web` :3000)** | **HTTP, plaintext** | `edge.py` target groups (`ApplicationProtocol.HTTP`); ports in `infra/meridian/stacks/vpc.py` |
| api → RDS PostgreSQL | TLS, forced (`rds.force_ssl=1`), CA bundle pinned in the image | `infra/meridian/stacks/data.py`; `Dockerfile.api`; `infra/pins/rds-global-bundle.sha256` |
| api / worker → S3, SES, Cognito, Secrets Manager, KMS | HTTPS (AWS SDK endpoints) | `src/storage.py`, `src/email_service.py`, `src/cognito.py` |
| SES → recipient mail server | TLS required (`TlsPolicy: REQUIRE`) | `meridian-shared-ses-default` configuration set |

## 3. The plaintext hop, described

- The ALB terminates TLS and forwards HTTP to the task's private IP.
- The tasks run in the `private-app` subnets with `assign_public_ip=False`
  (`infra/meridian/stacks/compute.py`, the service definition).
- The `app` security group's **only ingress is the ALB security group, on the two container
  ports**; its only route out is the NAT gateway (`compute.py`, service docstring;
  `vpc.py`). Nothing on the internet can open a connection to a task.
- **VPC flow logs record ALL traffic** in the VPC to a CMK-encrypted CloudWatch log group
  (`edge.py` `_flow_logs`, `FlowLogTrafficType.ALL`).
- The VPC holds one tenant's estate: Meridian's own. No other customer's workload shares it.
- What crosses the hop: HTTP requests and responses between the ALB and the application —
  including session cookies, uploaded workbooks and API responses that can carry PHI.

## 4. Why not encrypt it (the alternative considered)

**TLS to the task** means a certificate per task (or a private CA), rotation, a trust store in
the ALB target group, a health check over TLS, and application servers (uvicorn, Next.js)
configured to serve TLS. Its operational cost for a two-person workforce is real: a private
CA alone is priced per month per CA, and every certificate failure is an outage of the whole
application. Its security gain is bounded to one threat: an attacker already able to read
packets **inside** the VPC's private subnets, which requires either an AWS-side compromise or
a foothold on a host in the VPC — at which point that attacker can read the task's memory
and environment as well.

**VERIFY (1):** AWS states that traffic between supported **Nitro-based EC2 instance types**
in the same VPC is automatically encrypted at the physical layer. Whether **Fargate** tasks
get the same in-VPC encryption, and whether the ALB-to-target path is covered, must be
confirmed from AWS's current documentation (or AWS Support) and quoted here with the date.
If it is covered, this hop is encrypted by the platform and §5 becomes a statement of fact;
if it is not, the decision below stands on §3 alone.

**VERIFY (2):** the ALB target group could instead use HTTPS with a self-signed certificate on
the task (the ALB does not validate target certificates). Record whether that option — cheap,
no CA — was considered and why it was or was not taken.

## 5. Decision (proposed)

Leave the ALB → task hop as HTTP inside the private subnets, relying on: private subnets with
no public IPs; a security group admitting only the ALB; VPC flow logs on all traffic; a
single-tenant VPC; and TLS on every hop that leaves it. This is the "equivalent alternative
measure" 164.306(d)(3) asks for, documented rather than assumed.

## 6. Triggers to revisit

Revisit this paper — and encrypt the hop unless the answer is written down again — at the
**first** of:

1. the first PHI-scoped external partner (a `phi:read` API client), or
2. a second tenant's workload in the same VPC, or
3. an auditor or pen-test finding against this hop, or
4. VERIFY (1) coming back "not covered" for Fargate, if Andres decides that changes the
   balance, or
5. the annual policy review.

## 7. Evidence kept with this paper

- This paper, dated and signed, in the Evidence set.
- The CDK lines cited in §2-§3, at the commit the paper is signed against: `__________`.
- The VPC flow-log group name and retention, read from the deployed stack.
- The AWS documentation page(s) quoted for VERIFY (1), with the retrieval date.

## 8. Signature

Name: Andres Santos · Role: security official

Signature: ______________________ · Date: ____-__-__
