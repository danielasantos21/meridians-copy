# Adding a process

A **process** is one kind of run Meridian does for a client: a billing export in, revenue
journal entries out (QB Revenue); a payroll workbook in, payroll entries out (MX Payroll).
Adding one should be **one folder plus business logic**. This page says how, what the
scaffold does for you, and what is still manual today (Phase 11 is not finished; the list
at the end shrinks as it lands).

Terms used below:

- **Manifest**: a small Python file that describes a process as data: its id, name and
  colour, the files it accepts, its wizard steps, its background jobs, and what run state
  it keeps. `src/processes/<pkg>/manifest.py`.
- **Processor**: the business logic. Pure Python: paths and values in, values out. No web
  framework, no AWS SDK. `src/processes/<pkg>/processor.py`.
- **Handler**: the function the background worker calls for one job (`execute`, `parse`,
  …). It gets a `JobContext` (ids plus three callables) and returns a `JobOutcome` (the
  next state). `src/processes/<pkg>/handler.py`.
- **Registry**: `src/processes/__init__.py` loads every manifest into `REGISTRY`. It is
  the one list of processes; the permission list, the process catalogue the React app
  reads, the retry list and the others are all derived from it.
- **Conformance suite**: `tests/conformance/`, the checks every process must pass before
  it counts as registered.

## 1. Scaffold it

```bash
venv/bin/python scripts/new_process.py <id> --dry-run          # see the plan
venv/bin/python scripts/new_process.py <id> --label "Name" --color "#0F766E" [--touches-phi]
```

`<id>` is lowercase words joined by hyphens (`vendor-invoices`). The permission defaults
to the id with underscores (`vendor_invoices`); pass `--permission` to reuse an existing
one. `--touches-phi` says an input can carry patient identifiers
(`docs/phi-classification.md`). `--category revenue|payroll|other` (default `other`) and
`--description "One line: what goes in, what comes out."` fill the manifest's catalogue
fields (see "5. In the Processes catalogue and the sidebar").

It writes:

| File | What |
|---|---|
| `src/processes/<pkg>/manifest.py` | the manifest: one `.csv`/`.xlsx` input, steps upload → processing → results, an `execute` job wired to the handler |
| `src/processes/<pkg>/processor.py` | a validator that checks the header row, and a stub calculation |
| `src/processes/<pkg>/handler.py` | the `execute` handler: runs the stub, records a summary, completes the run |
| `tests/test_process_<pkg>.py` | the process's own tests |
| `migrations/versions/<NNNN>_process_<pkg>.py` | the Alembic revision that widens the two database CHECKs (`process_runs.process`, `role_permissions.process`) |

and edits `src/processes/__init__.py` (the CHECK values it states, the manifest list),
`src/api/v2/schemas.py` (`ProcessKey`, `<Name>CreateParams`, `<Name>Run`, the
`RunEnvelope` union), `tests/test_migrations.py` (`HEAD_REVISION`) and the table at the end
of this page. It writes nothing under `infra/`: a process needs no infrastructure of its
own. It refuses, writing nothing, if the id is malformed or taken, the folder exists, or a
file it edits has changed shape.

## 2. Make it real

1. **The processor.** Replace `REQUIRED_COLUMNS` and `summarize`. Keep it pure:
   `scripts/lint_processor_purity.py` refuses `flask`, `fastapi`, `boto3`, `web_app` and
   the HTTP layer in `processor.py` and `handler.py`.
2. **The validator** must refuse a file it cannot use with a `ProcessInputError` whose
   code is in `src/api/v2/errors.py` (`FILE_HEADERS_INVALID`, `FILE_UNREADABLE`, …), and
   its message, details and logs must never quote a cell: a cell can be PHI. Name the
   missing column, never the value found.
3. **Params.** Edit `<Name>CreateParams` in `src/api/v2/schemas.py`: those fields are what
   the create form asks for (the React form is generated from their JSON Schema), and
   `public_params` in the manifest is what the browser may see again.
4. **State.** Every `run_state` key the handler returns and every state object it writes
   must be declared in `state_fields` with a class: `public` (anyone who can see the run),
   `personnel` (employee names, pay aggregates), `phi` (a state object only, audited),
   `never` (not stored). The suite reads `handler.py` to check; keep `run_state={...}` a
   literal dict and state names literal strings.
5. **A human step** (a review, a preview): add a `StepSpec("<step>", "access", custom=True)`
   with a step id from `schemas.Step`, and register its React component.

## 3. Prove it

```bash
venv/bin/python -m pytest tests/conformance tests/test_process_<pkg>.py -q
venv/bin/python scripts/generate_openapi.py        # the API document names the process
(cd web && npm run generate:types)                 # and so do the TypeScript types
scripts/check_api_drift.sh                         # all three in step
```

The conformance checks, each proved able to fail by `tests/conformance/test_known_bad.py`:

| Check | Passes when |
|---|---|
| `db_checks` | the id and permission are allowed by the Alembic CHECKs and by the values the registry states |
| `state_machine` | steps come from `schemas.Step`, start at `upload`, end at `results`, are `custom` exactly where the standard shell has no screen; jobs start from reachable states and fit under the 900 s queue visibility; there is an `execute` job |
| `openapi` | `openapi/meridian-v2.json` names the process in every process enum and maps its envelope |
| `http_routes` | the document serves `POST /api/v2/<id>/runs` |
| `handlers` | every job has a handler in the process's own package, or a `HANDLER_PENDING` row naming the task that wires it |
| `state_fields` | the status keys are declared as the platform declares them, and what the handler writes is declared with a class allowed there |
| `inputs` | each input has browser content types, a size ceiling of at most 50 MiB, a validator |
| `file_validation` | the validator refuses junk and a table of canary identifiers, with a registered code, and the canary appears in no message, detail or log line |
| `permissions` | the id and permission are well formed, `auth` serves the permission with the manifest's label, only `results` is at the results level, machine scopes exist |
| `purity` | `processor.py` and `handler.py` pass the purity lint |
| `catalog` | the manifest declares a `category` (`revenue`, `payroll` or `other`) and a one-line `description` (at most 120 characters) |

## 4. Still manual today

These are the gaps between "registered and conformance-green" and "a person can run it".
Each names the task that removes it.

- **HTTP routes (the `http_routes` check stays red).** The `/api/v2/<id>/runs` routes are
  still hand-written per process (`api/routers/oneshot_runs.py`, `qb_usa_runs.py`) and
  listed by hand in `scripts/generate_openapi.py`'s `ROUTES`. Until D4 generates them from
  the manifest, a new process needs a router and its `ROUTES` rows written by hand.
- **The React screens.** The generic create form (F3) renders any process's params from
  the catalogue's `create.params_schema`, unless the process registers its own create step
  in `web/src/components/create-params/registry.tsx` (the three shipped ones do). The key
  still has to be added to `web/src/lib/api/runs.ts` (`ProcessKey`, `PROCESS_KEYS`) and to
  `PROCESS_META` / `PERIOD_BASIS` in `web/src/lib/run-view.ts` (`npm run typecheck` names
  them), and the results screen and sidebar still branch on the three ids in places.
- **Tests pinned to today's three processes.** `tests/test_process_manifest.py` (the
  literal catalogue) and `tests/snapshots/api_v2_processes.json` (the `/api/v2/processes`
  bytes) must be updated on purpose.
- **Before cutover, the Supabase side.** Production runs on Supabase until Phase 9, and
  `tests/test_registry_conformance.py` holds the Supabase `022`/`030` CHECKs equal to the
  registry. A process added before cutover needs those widened on Supabase too (which is
  a production schema change, and Andres's call); after cutover the Alembic revision is
  the whole story.

## 5. In the Processes catalogue and the sidebar

**The catalogue needs nothing from you beyond the manifest.** The Processes page
(`/processes`, the "Processes" link in the sidebar) reads `GET /api/v2/processes`, which is
built from the registry, so a registered process appears there on the next deploy with its
`label`, its `category` group, its `description`, its last run and an Open button, for
every organization that has its module and every user whose role grants its permission.
No React change is needed for it to be listed. (Its Open button reaches the wizard only
once the key is in `web/src/lib/api/runs.ts`; see "Still manual today".)

**It does not appear in anyone's sidebar until it is pinned.** The sidebar shows the pinned
processes (at most 6) and the Processes link:

- **An org admin** opens Processes, scrolls to "Organization default", ticks the processes
  in the order the sidebar should show them and presses "Save organization default". That
  is what every member sees until they choose their own. "Clear" removes it.
- **Any user** presses the star on a process to pin or unpin it for themselves; from then
  on their own list is used. "Reset to organization default" drops their own list.
- **Nobody pinned anything** (the starting point for every org), or every pinned process
  is one this user cannot open: the sidebar shows every process this user can open — the
  org has the module AND the role grants `access` (`web/src/lib/nav-access.ts`; a new
  process needs its route key → scope there, in `SCOPE_FOR`). Processes the user cannot
  open are never listed (owner, 2026-09-30); a direct link shows a no-access panel.

A pinned process the user cannot open (no permission, module off, or View-as-role) is
skipped silently. Pins are stored in `public.org_process_pins` / `public.user_process_pins`
on RDS (revision `0034_process_pins`) and in `organizations.settings.process_pins` on the
Supabase backend; the API is `GET|PUT /api/v2/me/process-pins` and
`GET|PUT /api/v2/org/process-pins` (admins), and an unknown process key is a 422.

## Build it in a sandbox with real data

Scaffold and build the process in a **sandbox**, so you can run it in the app against the
live organizations' real configuration (mappings, fiscal calendar, roles) while everything
it saves stays on your laptop, in a database nobody else uses:

```bash
scripts/sandbox.sh golden                     # a fresh copy of the live configuration
scripts/sandbox.sh new <id>                   # branch sandbox/<id> + its own database
cd .claude/worktrees/sandbox-<id>             # the worktree: build the process here
../../../venv/bin/python scripts/new_process.py <id> ...  # the main checkout's venv
scripts/sandbox.sh start <id>                 # migrates ITS database, starts api + web
```

- A new Alembic revision in the branch is applied to that sandbox's database only.
- The sandbox cannot post to QuickBooks (`MERIDIAN_QBO_POSTING=off`), send e-mail or
  webhooks, or write to S3; every organization is in Test mode. Try the whole flow freely.
- `scripts/sandbox.sh refresh <id>` starts the data over; `drop <id>` removes it all (it
  keeps the branch unless it is merged, and refuses uncommitted work without `--force`).
- To test with patient data, use `--phi` (the PHI drive must be mounted). Without it the
  sandbox has configuration only. See README, "Local development", "Sandboxes".

## Processes

| Id | Permission | Folder | Name |
|---|---|---|---|
| `qb-revenue` | `revenue` | `src/processes/qb_revenue/` | QB Revenue |
| `mx-payroll` | `payroll` | `src/processes/mx_payroll/` | QB MX Payroll |
| `qb-usa-payroll` | `qb_usa_payroll` | `src/processes/qb_usa_payroll/` | QB USA Payroll |
<!-- new_process.py adds rows above this line -->
