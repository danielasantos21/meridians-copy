# `docs/` — Meridian documentation

Tracked Markdown only. No secrets, no account or routing numbers, no API keys, no client
data, no generated reports. Plain language: every technical term is defined the first time
it appears.

## The migration's founding documents

| File | What it is |
|---|---|
| [`aws-migration-plan.md`](aws-migration-plan.md) | The plan (v3.1). Effort, cost, sequencing, data safety, and §8's decision register (D-01…D-25, P-1…P-10). The long form of everything below. |
| [`aws-migration-prompt.md`](aws-migration-prompt.md) | The instructions pasted into the session that executes the migration. Wins on architecture; the plan wins on effort, sequencing and decisions — **including phase order** (ADR 0004). |
| [`migration-tracker.md`](migration-tracker.md) | Anything half-migrated, with an owner and a deadline. Nothing may stay in two places without a row here. |

## Subfolders

| Folder | What lives there |
|---|---|
| [`adr/`](adr/README.md) | **Architecture Decision Records** — one short dated note per significant choice: context, decision, consequences, and what would make us revisit it. Fifteen founding ADRs plus the provisional decisions P-1…P-10 with their triggers. Start at [`adr/README.md`](adr/README.md). |
| [`architecture/`](architecture/) | How the system is laid out and why. [`repo-layout.md`](architecture/repo-layout.md) is the target folder tree, today's actual tree, the today→target migration table, the naming and tagging conventions, and the three rules that replace `CLAUDE.md` rules for this migration. Also [`dns.md`](architecture/dns.md) and the `inventory-*.md` documents. What a React Native client needs is in [`plans/mobile-readiness.md`](plans/mobile-readiness.md) (Phase 12 T16). The data-flow diagrams are not here; they are in [`compliance/data-flows.md`](compliance/data-flows.md), next to the PHI classification they belong to. |
| [`compliance/`](compliance/) | The control matrix (control → implementation → evidence) covering the HIPAA Security Rule safeguards and the SOC 2 Security / Availability / Confidentiality criteria, the PHI determination, data-flow diagrams, and the threat model. Updated every phase. |
| [`runbooks/`](runbooks/) | Step-by-step procedures a person follows under pressure: deploy, rollback, restore, rotate secrets, revoke an API client, incident response, onboard a partner, add a process, cutover, and [`production-readiness.md`](runbooks/production-readiness.md) — the Phase 8 gates, what proves each one, and the consolidated list of what only a person can do. Written to be followed literally — the second cutover rehearsal follows `cutover.md` with no edits allowed. |
| [`processes/`](processes/) | Plain-language explainers for how a process works: [`qb-usa-payroll-gates-explained.md`](processes/qb-usa-payroll-gates-explained.md), [`mx-payroll-day-split-explained.md`](processes/mx-payroll-day-split-explained.md), [`payroll-booking-report-how-it-works.md`](processes/payroll-booking-report-how-it-works.md), and the NetSuite admin setup, [`netsuite-mcp-admin-setup.md`](processes/netsuite-mcp-admin-setup.md). |
| [`plans/`](plans/) | Specs and plans for work outside the migration phases: [`language-toggle-plan.md`](plans/language-toggle-plan.md), [`pnl-provider-dashboard-v2.md`](plans/pnl-provider-dashboard-v2.md), [`mobile-readiness.md`](plans/mobile-readiness.md), [`api-v2-follow-ups.md`](plans/api-v2-follow-ups.md) and [`qb-api-test-plan.md`](plans/qb-api-test-plan.md). |
| [`pending-questions/`](pending-questions/README.md) | Questions waiting on a person, one file each. |
| [`reports/`](reports/) | Phase reports, phase plans and the critic log. |
| [`markdown-export/`](markdown-export/) | The document design tokens ([`formatting-and-feel.md`](markdown-export/formatting-and-feel.md)) the branded PDFs and the printed P&L follow. |
| [`screens/`](screens/) | Screenshots embedded in the SOP PDF (`templates/docs/sop_qb_revenue.html`), captured by `scripts/capture_screens.mjs` against fixtures. |

These stay at the top of `docs/` because code, a script or an instruction file names
their path there:
[`api-v2-contract.md`](api-v2-contract.md) (the `/api/v2` contract, cited across `src/api/v2/`
and by `scripts/check_api_drift.sh`), [`adding-a-process.md`](adding-a-process.md) (edited in
place by `scripts/new_process.py`), [`je-diff-procedure.md`](je-diff-procedure.md) (printed by
`scripts/diff_je_output.py`), and the three founding documents above. The email drafts and
the BKv5 comparison workings that used to sit here named client staff and carried client
figures; the Phase 0 sweep moved them out of the repository to the product's data folder.

## Line-number citations

The Phase 0 inventory documents cite code as `path:line` **as of commit `4ccddcb`**
(2026-09-15). Later commits reformat and fix those files, so to check a citation use
`git show 4ccddcb:<path>` rather than the working tree.
