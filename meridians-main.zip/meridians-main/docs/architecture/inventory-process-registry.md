# Inventory — the process registry, as it exists today

Phase 0 deliverable for `docs/aws-migration-plan.md` Phase 11 ("Process framework").
Everything here was read out of the code on branch `aws-migration`; every claim
cites `path:line`. Nothing in this document is a proposal — it is what the
framework in Phase 11 has to extend.

**Line citations:** every `path:line` in this document **cites commit `4ccddcb`** (2026-09-15). Later commits reformat and fix those files, so check a citation with `git show 4ccddcb:<path>`, not the working tree.

Plain-language summary of what "the registry" actually is today: **there is no
single registry.** There are five separate lists that each describe "the
processes", they are kept in step by hand (and in one case by a test), and they
do not even use the same names for the same thing. Phase 11's manifest has to
become the one source that populates all five.

---

## 0. The five lists, and how they disagree

| # | List | Where | Contains |
|---|---|---|---|
| 1 | `process_runs.PROCESSES` | `src/process_runs.py:59` | `qb-revenue`, `mx-payroll`, `qb-usa-payroll` |
| 2 | `auth.ALL_PROCESSES` | `src/auth.py:677-679` | 8 permission scopes, hyphen-free: `revenue`, `payroll`, `qb_usa_payroll`, `adp_payroll`, `config`, `invoice`, `booking_payroll`, `pnl_provider` |
| 3 | `role_permissions.process` CHECK | `supabase_migrations/migrations/030_role_permission_processes.sql:20-33` | 11 values (8 live + `code_grader` + 2 retired) |
| 4 | `routes.PROCESS_CATALOGUE` | `src/api/v2/routes.py:39-63` | the same 3 run-able processes, with colour, permission and wizard steps |
| 5 | `qb_export_artifacts.PROCESSES` | `src/qb_export_artifacts.py:48` | `qb-revenue`, `mx-payroll` only |

The two naming conventions are the first thing a manifest has to reconcile:

- a **run-able process id** is hyphenated (`qb-usa-payroll`) and is what
  `process_runs.process` stores and what a URL contains;
- a **permission scope** is underscored (`qb_usa_payroll`) and is what
  `role_permissions.process` stores.

`PROCESS_CATALOGUE` is the only place the two are joined
(`src/api/v2/routes.py:44`, `:52`, `:59` map `key` → `permission`), and it is a
hand-written tuple.

---

## 1. `src/process_runs.PROCESSES` — the run-able set

```python
PROCESSES = frozenset({"qb-revenue", "mx-payroll", "qb-usa-payroll"})
```
`src/process_runs.py:59`

It is a **flat frozenset of three strings with no fields at all.** Phase 11's
step 1 says the manifest "populates `src/process_runs.PROCESSES`" — worth
knowing that there is nothing to populate beyond the three ids; every other
per-process fact (colour, permission, steps, input types, worker) lives
somewhere else. The set is enforced in one place: `create_run` rejects an
unknown process (`src/process_runs.py:295-297`).

The same three values are also hard-coded a second time as a Postgres CHECK:

```sql
process TEXT NOT NULL
        CHECK (process IN ('qb-revenue', 'mx-payroll', 'qb-usa-payroll')),
```
`supabase_migrations/migrations/022_process_runs.sql:60-61`

**So adding a fourth run-able process today needs a migration**, not just a code
edit — and unlike `role_permissions` (§2) nothing tests that the two agree.

### Sibling constants in the same module

| Constant | `path:line` | Value |
|---|---|---|
| `TERMINAL_STATES` | `src/process_runs.py:51` | `completed`, `failed`, `expired`, `superseded` |
| `VALID_STATES` | `src/process_runs.py:53-56` | the ten §2.1 states |
| `TABLE` / `DOWNLOADS_TABLE` | `src/process_runs.py:61-62` | `process_runs`, `artifact_downloads` |
| `DEFAULT_TTL_HOURS` | `src/process_runs.py:65` | 24 |
| `OVERRIDE_FIELDS` | `src/process_runs.py:70-71` | `entity`, `variant`, `qb_location`, `qb_department`, `qb_class`, `name` — the only keys a one-run-only roster answer may carry |

---

## 2. `auth.ALL_PROCESSES`, `PROCESS_LABELS`, and the 029/030 CHECK

### The lists

```python
ALL_PROCESSES = [
    'revenue',
    'payroll',
    'qb_usa_payroll',
    'adp_payroll',
    'config',
    'invoice',
    'booking_payroll',
    'pnl_provider',
] + list(EXTRA_PROCESSES)
```
`src/auth.py:677-679`

`PROCESS_LABELS` (`src/auth.py:686-701`) gives each scope its on-screen name —
`revenue` → "QB Revenue", `payroll` → "QB MX Payroll", `qb_usa_payroll` → "QB
USA Payroll", `adp_payroll` → "ADP Payroll", `config` → "Configuration",
`invoice` → "Invoices", `booking_payroll` → "Booking Payroll", `pnl_provider` →
"P&L by Provider". A module-import-time `assert` keeps the two in step
(`src/auth.py:702-703`).

`INHERITS_FROM` (`src/auth.py:709-716`) records which scope each newer one was
carved out of — `qb_usa_payroll` from `payroll`, `pnl_provider` from `config` —
so a role that predates the split keeps what it could do yesterday.

### How the migrations constrain it

`role_permissions.process` carries a CHECK constraint. Every process a role can
be granted must be listed there or the **insert raises and the checkbox silently
un-ticks**:

- **018** (`.../018_role_permissions_process_check.sql:12-16`) widened the
  original migration-004 list to 8 values, adding `invoice`, `booking_payroll`,
  `wearbly`.
- **029** (`.../029_role_permission_processes.sql:26-38`) added
  `qb_usa_payroll` and `pnl_provider`. Its own comment says this is why *no role
  in any org had ever had a `qb_usa_payroll` row* — every write had been
  rejected by Postgres. It keeps `mso_payroll` and `wearbly` even though they
  left `ALL_PROCESSES`, because "a constraint that a stored row fails is a
  constraint that breaks the next unrelated write to that row"
  (`:20-22`).
- **030** (`.../030_role_permission_processes.sql:20-33`) is the current
  constraint. It adds `code_grader`. Full allowed set: `revenue`, `payroll`,
  `qb_usa_payroll`, `adp_payroll`, `config`, `invoice`, `booking_payroll`,
  `pnl_provider`, `code_grader`, plus retired `mso_payroll`, `wearbly`.

### The test that enforces it

`tests/test_role_permission_constraint.py` reads the newest
`*_role_permission_processes.sql` off disk (`:35-37`) rather than talking to a
database, and asserts both directions:

- `test_every_process_can_actually_be_stored` — nothing in `ALL_PROCESSES` is
  rejected by the CHECK (`:40-44`);
- `test_the_constraint_allows_nothing_unexplained` — nothing storable is
  unaccounted for, modulo `RETIRED = {mso_payroll, wearbly}` (`:25`) and
  `LOCAL_ONLY = {code_grader}` (`:31`).

This test is the closest thing the codebase has to a registry conformance
check, and it is the model Phase 11's conformance suite should follow: it
compares a Python list to a SQL file with no infrastructure at all.

**Gap to close in Phase 11:** the equivalent test does not exist for the
`process_runs.process` CHECK (§1) or for `PROCESS_CATALOGUE` (§4). Migration
022's list can drift from `process_runs.PROCESSES` and nothing notices.

---

## 3. `src/api/v2/state_machine.py`

134 lines; the whole run lifecycle is data, not code branches.

### States

`TERMINAL = {completed, failed, expired, superseded}` (`:23`). The full ten
states live in `process_runs.VALID_STATES` (`src/process_runs.py:53-56`) and in
the CHECK at `022_process_runs.sql:75-78`; the state machine only names the
terminal subset because the rest are implied by `TRANSITIONS`.

### Transitions

`TRANSITIONS` (`src/api/v2/state_machine.py:35-45`):

| from | to |
|---|---|
| `draft` | `parsing`, `needs_input`, `ready`, `running`, `blocked` |
| `parsing` | `needs_input`, `ready`, `blocked` |
| `needs_input` | `needs_input`, `ready`, `running` |
| `ready` | `running`, `needs_input` |
| `running` | `completed`, `blocked`, `failed` |
| `blocked` | `running` |
| `completed` | `superseded` |
| `failed` / `expired` / `superseded` | (none) |

Then a loop at `:46-48` adds `failed` and `expired` as legal targets from every
non-terminal state, because the TTL sweeper and a worker exception can happen
anywhere.

`draft → running` is deliberate and is the §12.1 case written into code
(`:21-28`): for `qb-revenue` and `mx-payroll` the create request *is* the
execute, so there is no state between the two.

`assert_transition(current, target)` (`:126-134`) is the single guard against an
impossible move.

### Per-process differences

Only two things in this module vary by process:

1. **`RETRY_PROCESSES = frozenset({"qb-revenue"})`** (`:66`), used at `:101`.
   §12.8: retry is the only way out of `blocked`, and `qb-revenue` is the only
   process that can be blocked. `qb-usa-payroll` never advertises `retry`.
2. **`step`**, which refines two states. `actions_for()` (`:69-104`) keys on
   `(state, step)`: `needs_input:roster_review` → `submit_review`;
   `needs_input|ready:preview` → `execute`, or `declare_gates` when a
   `GATES_UNDECLARED` blocker is present (`:97-100`). A process with no
   `roster_review` or `preview` step simply never reaches those branches.

`ACTION_STATES` (`:47-55`) is a second, coarser map used only to render the
"it is available from: …" sentence in the 409 (`:118-124`).

Two viewer flags cross-cut everything (§12.11): `can_execute` and
`can_view_results` (`:79-81`, `:87-92`). A user with `payroll:access` but not
`payroll:results` gets a `completed` run with an **empty** `available_actions`
list rather than a 403 after the money is booked.

### How `/api/v2/processes` is served

`src/api/v2/routes.py:558-587`. `GET /api/v2/processes`, `@limit(LIMIT_READ)`,
`@require_auth`, `@require_org` — note it needs no per-process permission; it is
the catalogue, and it tells you what you may do rather than refusing.

It iterates the hand-written `PROCESS_CATALOGUE` tuple (`:39-63`) and for each
entry builds a `ProcessDescriptor` with:

| field | source |
|---|---|
| `key`, `color`, `steps` | the literal tuple entry |
| `name` | `PROCESS_LABELS[...]` — never restated (`:41`, `:49`, `:57`; the comment at `:23-27` records that the one name that *was* restated is the one that drifted) |
| `enabled` | `module_enabled(permission)` — **fails open** (`:65-77`): unknown org modules render as enabled, because hiding a client's whole product on a context-less request is worse than showing it |
| `can_access` / `can_view_results` | the caller's permission map (`:568`, `:575-576`) |
| `create` | always `multipart/form-data` at `/api/v2/{key}/runs` (`:578-581`) |
| `last_run` | only when the caller has `access` (`:582`) |
| `readiness` | `{"roster_ready": …}` for `qb-usa-payroll` only; `None` for the other two (`:583-584`) |

That `readiness` field is the existing precedent for a per-process extension
point, and the hand-written tuple is exactly what Phase 11's manifest replaces.

---

## 4. The three processes, side by side

### 4.1 `qb-revenue`

| | |
|---|---|
| **Permission scope** | `revenue` (`src/api/v2/routes.py:44`) |
| **Flask routes** | `/qb-revenue` `web_app.py:2910`; `/qb-revenue/process` POST `:2932`; `/qb-revenue/processing/<job_id>` `:3028`; `/qb-revenue/results/<batch_id>` `:3040`; `/qb-revenue/download-all/<batch_id>` `:3074`; `/qb-revenue/download/<batch_id>/<filename>` `:3095` |
| **Permissions per route** | `revenue:access` on index/process/processing; `revenue:results` on results/download/download-all |
| **v2 routes** | registered generically by `_register_one` (`src/api/v2/oneshot_runs.py:613-927`) at `/api/v2/qb-revenue/runs`: POST create `:618`, GET list `:709`, GET one `:756`, DELETE `:768`, POST `/execute` `:798`, POST `/retry` `:825` (this process only), GET `/artifacts` `:852`, GET `/artifacts/<id>/download-url` `:875`, POST `/artifacts/bundle` `:900` |
| **Processor modules** | `WebProcessor` in `web_app.py` via `process_in_background` (`web_app.py:1595`) → `src/enrichment.py`, `src/aggregation.py`, `src/je_generator.py`, `src/fiscal_calendar.py`, `src/exporters.py`, `src/revenue_qb_exporter.py`, `src/unposted_generator.py`, `src/hospital_enrichment.py`, `src/hospital_reader.py` |
| **Inputs** | one Excel billing export. Validated by `validate_file_headers` (`web_app.py:697-730`), which reads the "All clinics" sheet if present and requires `REQUIRED_HEADERS = {Transaction Date, Primary Payer Group Name, Facility Name, Billing Provider Name}` (`web_app.py:690-695`). Failure → `FILE_HEADERS_INVALID` or `FILE_UNREADABLE` (`src/api/v2/oneshot_runs.py:229-245`) |
| **Params** | `QbRevenueCreateParams` (`src/api/v2/schemas.py:1625-1647`): `period` (nullable), `fiscal_year` (nullable), `je_date`, `generate_unposted`, `bank_deposits` (clinic group → deposited cash). Null period/fiscal year *is* today's `'auto'` sentinel |
| **Wizard steps** | `upload → processing → (mapping_fix) → results` (`src/api/v2/routes.py:45`). **No human step** in the normal path; `mapping_fix` is entered from `blocked`, mid-run |
| **Outputs** | `JE_Revenue_*_QB.csv` under `journal_entries/` (`src/qb_export_artifacts.py:55`), plus enriched data workbooks and validation reports on the local `output/` tree; uploaded to the `outputs` bucket and the tie-out persisted to `qb_export_tie_out` (`src/qb_export_artifacts.py:44`, `:59`) |
| **Touches PHI** | **Yes.** The input carries `Patient Acct No`, which becomes `patient_id` on the enriched transaction (`src/enrichment.py:29`, `:201`), is stored in the `transactions` table (`src/database.py:173`, `:695-705`, `:2130-2143`), and is written into exported workbooks (`src/exporters.py:981`, `:2085`, `:2139`, `:2758`). A patient account number alongside a service date and a payment amount is PHI |
| **State lives in** | `processing_status = RunStore('qb-revenue', volatile=('result',), params_key='_retry_params')` (`web_app.py:43-44`). `_retry_params` goes to the `params` column because `blocked` means a human walks away and may come back after a deploy (`web_app.py:3259-3262`); `result` is a process-local cache |

### 4.2 `mx-payroll`

| | |
|---|---|
| **Permission scope** | `payroll` (`src/api/v2/routes.py:52`). Since the split, `payroll` means MX Payroll *only* (`src/auth.py:662-665`) |
| **Flask routes** | `/mx-payroll` `web_app.py:3749`; `/mx-payroll/process` POST `:3771`; `/mx-payroll/processing/<job_id>` `:3821`; `/mx-payroll/results/<batch_id>` `:3833`; `/mx-payroll/download-all/<batch_id>` `:3864`; `/mx-payroll/download/<batch_id>/<filename>` `:3885`. A legacy `/qb-payroll` redirect pair sits at `:3677-3678` |
| **Permissions per route** | `payroll:access` on index/process/processing; `payroll:results` on results/downloads |
| **v2 routes** | same generic set as qb-revenue at `/api/v2/mx-payroll/runs`, **minus `/retry`** — `supports_retry=False` (`src/api/v2/oneshot_runs.py:293`), so the route is never registered and the URL 404s rather than 405s |
| **Processor modules** | `process_payroll_in_background` (`web_app.py:3582`) → `src/payroll_processor.py`, `src/payroll_je_generator.py`, `src/payroll_exporter.py`, `src/payroll_qb_exporter.py` |
| **Inputs** | one payroll workbook. Validation is period detection: `_mx_detect_schedule` (`src/api/v2/oneshot_runs.py:254-272`), the same call the Jinja page makes, so the two front ends can never book different months |
| **Params** | `MxPayrollCreateParams` (`src/api/v2/schemas.py:1650-1657`) — **deliberately empty.** Period, year, the NRF day split and the provision date are all read out of the workbook. A file whose period cannot be read fails as `PERIOD_UNDETECTABLE` rather than being booked into a guessed month |
| **Wizard steps** | `upload → processing → results` (`src/api/v2/routes.py:53`). **No human step at all** |
| **Outputs** | `JE_Payroll_*_QB.csv` under `journal_entries/` (`src/qb_export_artifacts.py:56`) — a Main and a Provision file — to the `outputs` bucket, tie-out in `qb_export_tie_out` |
| **Touches PHI** | No patient data. It carries employee personal data (names, wages) — personnel data, not PHI |
| **State lives in** | `payroll_processing_status = RunStore('mx-payroll')` (`web_app.py:3264`) — **no `volatile`, no `params_key`.** See §5 for why that asymmetry matters |

### 4.3 `qb-usa-payroll`

| | |
|---|---|
| **Permission scope** | `qb_usa_payroll` — its own scope since the split (`src/api/v2/routes.py:59-60`) |
| **Flask routes** | `/qb-usa-payroll` `web_app.py:4102`; `/accrual` `:4120`; `/upload` POST `:4143`; `/review/<session_id>` GET `:4296` and POST `:4320`; `/preview/<session_id>` `:4383`; `/process/<session_id>` POST `:4412`; `/processing/<job_id>` `:4737`; `/status/<job_id>` `:4750`; `/results/<batch_id>` `:4762`; `/download/<batch_id>` `:4795`; `/download-workbook/<batch_id>` `:4844`; `/history` `:4885` |
| **Permissions per route** | `qb_usa_payroll:access` on index, accrual, upload, review, preview, process, processing, status (`:4105`, `:4123`, `:4147`, `:4299`, `:4324`, `:4386`, `:4415`, `:4740`, `:4753`). `qb_usa_payroll:results` on results, both downloads and history (`:4765`, `:4798`, `:4847`, `:4888`). **This is the §12.11 split, in the code** |
| **v2 routes** | `src/api/v2/qb_usa_runs.py:799-1310`: `/accrual-preview` `:817`; POST create `:845`; GET list `:922` (**`results` permission**, unlike every other read); GET one `:970`; DELETE `:990`; GET/POST `/review` `:1019`, `:1053`; GET `/preview` `:1125`; POST `/declarations` `:1174`; POST `/execute` `:1223`; POST `/quickbooks` `:1301` |
| **Processor modules** | `src/qb_usa_payroll_processor.py` (`process_qb_usa_payroll`), plus `_parsers`, `_maps`, `_roster`, `_exporter`, `_workbook`, `_quickbooks` |
| **Inputs** | **many CSV/Excel files in one dropzone**, classified *by content*, not by form field: `_classify_uploads` (`src/api/v2/qb_usa_runs.py:591-729`) accepts `.csv/.xlsx/.xlsm/.xls` (`:619`), converts Excel to CSV (`:628-630`), and sorts each file with `identify_csv` into `register` / `invoice` / `unum` / `bcbs` / unrecognised. Registers must carry a pay date (from the name, `register_YYYY-MM-DD.csv`); duplicate invoices and second carrier bills are rejected with a named collision (`:659-666`, `:685-690`); a run missing registers, invoices, the UNUM bill or the BCBS bill is reported as `Missing: …` (`:715-724`) |
| **Params** | `QbUsaCreateParams` (`src/api/v2/schemas.py:1381-1390`): `period` (1-12), `year`, `accrual_days` (0-14), `accrual_days_prefill`. The prefill exists so the server can tell "left as derived" from "deliberately overridden" (`_derive_accrual`, `src/api/v2/qb_usa_runs.py:731-747`) |
| **Wizard steps** | `upload → roster_review → preview → processing → results` (`src/api/v2/routes.py:61`). **The only process with human steps.** `roster_review` is skipped when prompts and alerts are both empty; gate declaration is a sub-state of `preview`, not its own step (contract §2.3) |
| **Outputs** | nine journal-entry CSVs to `outputs/{org_id}/{batch_id}/journal_entries/` (`web_app.py:4629-4631`), a review workbook `.xlsx` to `.../reports/` (`web_app.py:4632-4634`), rows in `qb_usa_payroll_journal` with a `storage_path` per journal (`web_app.py:4650`) and rows in `qb_usa_payroll_gate`. Downloads are signed URLs, 300 s for the ZIP and 120 s for the workbook (`web_app.py:4795`, `:4844`) |
| **Touches PHI** | No patient data. It holds the **most sensitive employee data in the product** — `web_app.py:4611-4618` names it: net pay, employee-side withholding, direct-deposit splits, DOB and carrier member IDs. It is deliberately released from memory as soon as the workbook has read it (`result.inputs = []`, `web_app.py:4619`) and is **never** written to `process_runs` |
| **State lives in** | two stores: `qb_usa_payroll_sessions = RunStore('qb-usa-payroll', volatile=('result', 'prompts', 'alerts'))` (`web_app.py:3908-3909`) and `qb_usa_payroll_jobs = RunStore('qb-usa-payroll')` (`:3910`). The session dict's shape is at `web_app.py:4268-4291`. One-run-only roster answers live in `process_runs.run_state.run_overrides` |

### Why they differ — contract §12.1-12.11, condensed

The uniform runs model in the contract is deliberately *not* uniform in eleven
named places. Each one is a per-process manifest field waiting to be declared:

| § | The mismatch | What the manifest must carry |
|---|---|---|
| 12.1 | qb-revenue and mx-payroll have **no human step**; only qb-usa has `roster_review` and `preview` | wizard steps are per-process, and a missing sub-resource 404s rather than being faked |
| 12.2 | `blocked` is reached **from `running`** (revenue, at 45% of enrichment), while qb-usa's equivalent is pre-execution | `running → blocked → running` is legal; two different points in one lifecycle |
| 12.3 | `run_id` and `batch_id` never line up — qb-usa allocates the batch inside the worker | `batch_id` is a nullable *attribute*, never the identity |
| 12.4 | `params` cannot be uniform: `bank_deposits` (11 clinic groups) vs `accrual_days` vs nothing | `params` is a discriminated union on `process` — which is exactly what `SPECS[...].params_model` already is (`src/api/v2/oneshot_runs.py:275-299`) |
| 12.5 | period/fiscal year: qb-usa requires them; qb-revenue accepts `'auto'`; mx-payroll parses them out of the sheet and **fails the run** if it cannot | a `period_source` field: `required` / `derived` / `parsed` |
| 12.6 | qb-usa can raise with prompts hung off the exception and **no result at all** (`_qb_usa_run`, `web_app.py:3958-3971`) | `has_result: false` is a real state; an empty-but-successful preview must be impossible |
| 12.7 | only qb-usa wrote to Supabase Storage originally | now closed by `src/qb_export_artifacts.py`, but that module covers **two** of the three (`:48`), because qb-usa has its own richer persistence and two answers to "what did this run book" would be worse than one (`:45-47`) |
| 12.8 | `retry` exists for exactly one process | `supports_retry` — already a `Spec` field (`src/api/v2/oneshot_runs.py:283`) and already `RETRY_PROCESSES` in the state machine (`:66`). Two copies |
| 12.9 | idempotency contradicts itself — revenue hashes the file, qb-usa sets `file_hash = session_id` so a re-run never dedupes | an `idempotency` field: `content_hash` vs `always_new` |
| 12.10 | `superseded` was defined and never set | now implemented in `process_runs.supersede_earlier_runs` (`src/process_runs.py:376-434`), and it no-ops when period or fiscal year is null (`:405-409`) — i.e. for exactly the 12.5 processes |
| 12.11 | permission splits **inside** one wizard: `access` to book, `results` to see what you booked | required permissions are per *step*, not per process — and the run envelope must carry `viewer.can_execute` / `can_view_results` (`state_machine.py:79-81`) |

---

## 5. Volatile worker state — what is in memory and whether it serialises

Phase 11 step 3 is "every worker result serialized out of process memory". This
is the honest inventory.

### 5.1 `src/run_store.py` — the mechanism

`RunStore(process, volatile=(), params_key=None)` (`src/run_store.py:189-196`)
is a `Mapping` that looks like the old `{job_id: {...}}` dict but writes through
to `process_runs`. A write is routed three ways (`_persist`,
`src/run_store.py:109-159`):

1. a key named in `volatile` → the **process-local** `_volatile` dict
   (`src/run_store.py:61`, written at `:110-113`);
2. the key named by `params_key` → the `params` **column** (`:117-120`);
3. everything else → merged into the `run_state` **JSONB column** (`:130-136`).

`_jsonable()` (`src/run_store.py:64-75`) is the guard: **anything reaching
Postgres that will not `json.dumps` raises**, with a message telling the author
to declare it volatile instead. So by construction nothing in `run_state` is
unserialisable — the unserialisable things are precisely the ones already
declared volatile.

Two more translations happen in `_persist`: the legacy status vocabulary
(`'complete'`, `'error'`) is mapped to §2.1 states via `LEGACY_STATUS_TO_STATE`
(`src/run_store.py:48-57`), and a `completed` write defaults `step` to
`'results'` (`:147-152`) because the worker only ever writes its own vocabulary
and a run otherwise reports `completed:processing`, which routes to no screen.

`RunState` is a real `dict` subclass (`src/run_store.py:78-187`) so Jinja
templates keep working. **Nested mutation is not seen** (`:90-93`) — `state['x']['y'] = v` never persists; the whole key must be re-assigned. That is a
live foot-gun for any Phase 11 rewrite.

### 5.2 Every volatile key, by store

| Store | `path:line` | Volatile keys | What the value is | Serialisable as-is? |
|---|---|---|---|---|
| `processing_status` (qb-revenue) | `web_app.py:43-44` | `result` | the `WebProcessor.process_with_progress` return dict, written at `web_app.py:1736`, alongside a `result_overview` summary that is **not** volatile | Mostly — it is a dict of scalars and nested dicts. It is declared volatile as a *cache*, not because it cannot serialise (`web_app.py:3261-3262`: "`result` is a recomputable cache, so it stays process-local") |
| `payroll_processing_status` (mx-payroll) | `web_app.py:3264` | **none** | its `result` dict is written to `run_state` at `web_app.py:3643-3651` and therefore already passes `_jsonable` | Yes — already in Postgres today |
| `qb_usa_payroll_sessions` | `web_app.py:3908-3909` | `result`, `prompts`, `alerts` | `result` is a `RunResult` **dataclass** (`src/qb_usa_payroll_processor.py:202-232`) holding `journal_entries`, `gates`, `prompts` (`roster.PersonPrompt` objects), `alerts` (`ChangeAlert` objects), `employee_runs` (per-employee lines), `maps`, and `inputs` (raw register/invoice/carrier rows) | **No.** Dataclasses of dataclasses; `json.dumps` raises, which is why they are volatile. They are reconstructible by re-running `_qb_usa_run` (`web_app.py:3940-3977`) |
| `qb_usa_payroll_jobs` | `web_app.py:3910` | **none** | progress/status scalars only | Yes |

`_volatile` itself is keyed `"{org_id}|{run_id}"` (`src/run_store.py:65-66`) and
cleared only by `reset_volatile()` (test teardown, `:57`) or a `pop`
(`src/run_store.py:281`). **It is never bounded and never expires** — a
long-lived worker accumulates one `RunResult` per run it happens to serve.

### 5.3 The `_RUN_OVERRIDES` correction

**`_RUN_OVERRIDES` no longer exists.** `src/qb_usa_payroll_roster.py:138-175` is
now a thin delegation to `process_runs`:

```python
from src import process_runs as _run_state
def run_overrides(org_id=None, run_id=None): return _run_state.get_run_overrides(...)
def set_run_override(...):                   _run_state.merge_run_override(...)
```
`src/qb_usa_payroll_roster.py:161-171`

The only surviving mention of the name is the historical comment at
`src/qb_usa_payroll_roster.py:150-155` explaining why it was removed. The
answers live in `process_runs.run_state.run_overrides`, restricted to
`OVERRIDE_FIELDS` (`src/process_runs.py:70-71`), and are dropped on any terminal
state by `set_state` (`src/process_runs.py:352-367`) with `expires_at` as the
backstop sweep.

### 5.4 Module-level mutable state that is still a plain dict

These are outside `process_runs.PROCESSES` and so outside Phase 11's stated
scope, but they are the "5 in-memory wizards" the plan's Phase 11 goal refers
to, and they are *still* module-level dicts on this branch:

| Wizard | `path:line` | Dicts |
|---|---|---|
| ~~ADP payroll~~ | — | ~~`adp_payroll_session`, `adp_payroll_job_status`~~ **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~Booking payroll~~ | — | ~~`booking_payroll_session`, `booking_payroll_job_status`~~ **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~ADP v3~~ | — | ~~`adp_v3_session`, `adp_v3_job_status`~~ **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~BKv4~~ | — | ~~`bkv4_session`, `bkv4_job_status`~~ **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~BKv5~~ | — | ~~`bkv5_session`, `bkv5_job_status`~~ **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |

Elsewhere: `src/auth.py:24-25` (`_supabase_client`, `_supabase_admin_client`),
`src/auth.py:101-102` (a lock-guarded permissions `_cache`),
`src/process_runs.py:231`/`:239` (`_injected_store`, `_supabase_store`). None of
those hold run results; they are client/cache singletons.

### 5.5 Background threads

15 `threading.Thread` sites, matching the plan's count: 12 in `web_app.py`
(`:2717`, `:2802`, `:3018`, `:3812`, `:4445`, `:6788`, `:8468`, `:8847`,
`:9688`, `:10266`, `:10787`, `:11435`) and 3 in the v2 layer
(`src/api/v2/oneshot_runs.py:594`, `:703`; `src/api/v2/qb_usa_runs.py:1296`).
The v2 layer starts the **same** `web_app` worker functions the Jinja wizards
do, so v2 and Jinja are two front ends over one run row
(`src/api/v2/oneshot_runs.py:40-46`).

### 5.6 The tension Phase 11 has to resolve explicitly

Serializing "every result the worker produces" to S3 (Phase 11 step 3) is in
direct tension with `web_app.py:4611-4619`, which **deliberately drops**
`result.inputs` from memory as soon as the workbook has read it, because it is
"the most sensitive thing in memory: net pay, employee-side withholding,
direct-deposit splits, DOB and carrier member IDs — none of which is ever
written to `process_runs`". A blanket "pickle the result to S3" would write
exactly that to durable storage. The manifest needs a per-field
**persist / recompute / never-persist** classification, not a whole-object rule.

---

## 6. The tables the framework must extend, not replace

### `process_runs` (migration 022)

`supabase_migrations/migrations/022_process_runs.sql:57-80`

| Column | Type | Notes |
|---|---|---|
| `run_id` | `UUID PK DEFAULT gen_random_uuid()` | server-issued; the only id an API client sees |
| `org_id` | `UUID NOT NULL → organizations(id) ON DELETE CASCADE` | |
| `process` | `TEXT NOT NULL CHECK IN (qb-revenue, mx-payroll, qb-usa-payroll)` | the hard-coded registry of §1 |
| `state` | `TEXT NOT NULL` + `process_runs_state_check` (the ten §2.1 states, `:75-78`) | |
| `step` | `TEXT` | the §2.3 discriminator |
| `batch_id` | `INTEGER → import_batches(id) ON DELETE SET NULL` | NULL until the worker allocates a booking |
| `fiscal_year` | `INTEGER` | NULL for the §12.5 processes until detected |
| `period` | `INTEGER` | as above |
| `params` | `JSONB NOT NULL DEFAULT '{}'` | the `params_key` destination |
| `inputs` | `JSONB NOT NULL DEFAULT '{}'` | uploaded filenames |
| `run_state` | `JSONB NOT NULL DEFAULT '{}'` | per-run scratch, incl. `run_overrides` |
| `progress` | `JSONB NOT NULL DEFAULT '{}'` | |
| `error` | `JSONB` | `{code, message}` |
| `idempotency_key` | `TEXT` | |
| `created_by` | `UUID` | |
| `created_at` / `updated_at` / `expires_at` | `TIMESTAMPTZ` | |
| `superseded_by_run_id` | `UUID → process_runs(run_id) ON DELETE SET NULL` | **added by migration 026** (`026_process_runs_superseded_by.sql:28-30`) |

Indexes: a **partial unique** index on `(org_id, idempotency_key)` where the key
is non-null (`:83-85`) — this is the §12.9 mechanism Phase 11 step 4 says needs
a `job_idempotency` table; `(org_id)`, `(org_id, process, created_at DESC)`,
`(batch_id)` (`:87-92`); a TTL-sweep index on `expires_at` restricted to
`draft/parsing/needs_input/ready` (`:96-98`); and from 026, an index on
`superseded_by_run_id` and a partial `(org_id, process, fiscal_year, period)
WHERE state='completed'` (`026_…:34-43`).

RLS is on with an `org_id = user_org_id()` policy (`:127-133`), but the header
is explicit that **the service key bypasses RLS**, so the `.eq('org_id', …)`
filter in `src/process_runs.py` is the actual control and RLS is the backstop.

### `artifact_downloads` (migration 022)

`supabase_migrations/migrations/022_process_runs.sql:106-120`

`id SERIAL PK`, `org_id UUID NOT NULL`, `run_id UUID`, `batch_id INTEGER`,
`artifact_id TEXT`, `artifact_name TEXT`, `user_id UUID`, `user_email TEXT`,
`ip TEXT`, `user_agent TEXT`, `expires_at TIMESTAMPTZ`, `created_at
TIMESTAMPTZ`.

One row per signed URL **minted**, not per download — Flask never sees the GET
(`:101-104`, and `src/process_runs.record_download`,
`src/process_runs.py:437-466`). Anything Phase 11 writes about "downloaded" must
keep saying "link issued", or the audit trail becomes a claim we cannot support.

### Adjacent tables Phase 11 will touch but must not duplicate

`import_batches` (the booking row, with `'superseded'` from migration 021/024),
`qb_export_tie_out` (migration 025, one row per file × journal, written at
export time by `src/qb_export_artifacts.py`), `qb_usa_payroll_journal` and
`qb_usa_payroll_gate` (migration 021), `qbo_connection` (migration 035).

---

## 7. The `local_plugins` seam

Two tracked import sites, both guarded by `try/except ImportError`:

**Blueprints** — `web_app.py:187-197`:
```python
try:
    from local_plugins import register_blueprints as _register_local_blueprints
except ImportError:  # pragma: no cover - the shipped configuration
    pass
else:
    _register_local_blueprints(app)
```
The comment at `:188-191` says it plainly: "`local_plugins` is not in the
repository. It is the seam a process under development uses to mount itself
without the repository — or GitHub — learning it exists."

**Permission scopes** — `src/auth.py:672-675`:
```python
try:
    from local_plugins import EXTRA_PROCESSES, EXTRA_PROCESS_LABELS
except ImportError:  # pragma: no cover - the shipped configuration
    EXTRA_PROCESSES, EXTRA_PROCESS_LABELS = [], {}
```
feeding `ALL_PROCESSES` (`:679`) and `PROCESS_LABELS` (`:700`).

**The module itself is gitignored** (`.gitignore:86-87`: `code_grader/`,
`local_plugins.py`) and **is not present in this working copy**. So on this
machine `EXTRA_PROCESSES == []`, the blueprint registration is a no-op, and the
plan's D-24 disposition — "otherwise ignore it" — is the correct one.

### Where the plan's D-24 wording needs a footnote

D-24 says `local_plugins.EXTRA_PROCESSES` "is in no tracked branch". The
*module* is not, but **four tracked artifacts describe it**, and Phase 11 will
meet all four:

1. `web_app.py:187-197` — the blueprint seam (tracked).
2. `src/auth.py:672-675` — the scope seam (tracked).
3. `supabase_migrations/migrations/030_role_permission_processes.sql` — a
   **tracked, applied migration** whose entire purpose is to let `code_grader`
   be stored. Its own comment says `code_grader` "is the only screen in the
   product that reads a clinical note" (`:10-12`), which makes it the one
   would-be process with a direct PHI exposure.
4. `web/src/lib/local-nav.ts` — a tracked file that ships with a **non-empty**
   `LOCAL_NAV_ITEMS` naming Code Grader and a `LOCAL_MODULE_FOR` mapping
   `"code-grader" → "code_grader"` (`:17-38`), despite its own docstring saying
   "it ships EMPTY" (`:6`).

Practical consequence for Phase 11: the manifest loader must **tolerate an
absent optional plugin package** (both seams, not one), and the conformance
suite must not treat a CHECK-allowed-but-unregistered scope as a failure — which
is precisely what `tests/test_role_permission_constraint.py`'s `LOCAL_ONLY`
escape hatch (`:27-31`) now encodes. It is not a dependency, but it is a
constraint on the loader's shape.
