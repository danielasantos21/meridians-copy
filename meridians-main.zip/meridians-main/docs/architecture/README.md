# docs/architecture/

How Meridian is put together, and what it is made of today. Descriptive and factual — the
*reasoning* behind a choice belongs in an ADR (`docs/adr/`), and the *schedule* belongs in
`docs/aws-migration-plan.md`.

## What lives here

| File | What it is |
|---|---|
| `repo-layout.md` | The target repository layout after the migration (`infra/`, `src/`, `src/processes/`, `api/`, `workers/`, `web/`, `migrations/`, `tests/`, `docs/`, `scripts/`), and what belongs in each folder. |
| `dns.md` | Registrar, nameservers, mail records and the apex/CloudFront problem, with the provisional Route 53 decision and the human step it needs. |
| `inventory-web-surface.md` | Every route the application serves today: the Jinja screens, the `next.config.mjs` rewrite allowlist, `/api/v1` and `/api/v2`. |
| `inventory-process-registry.md` | The process registry as it exists today (`src/process_runs.PROCESSES`, `role_permission_processes`, the `/api/v2` state machine) — the thing Phase 11's manifest must extend rather than replace. |

## What does not live here

- **Decisions with alternatives considered** → `docs/adr/`.
- **Phase order, effort and cost** → `docs/aws-migration-plan.md`.
- **Controls and evidence** → `docs/compliance/`.
- **Step-by-step operational procedures** → `docs/runbooks/`.
- **Anything account-identifying beyond the account number already in the plan** — no keys,
  no instance ids that are not already public, no `.trial-env`-style files.

Diagrams are inline in the documents that need them; the ASCII target-architecture diagram
is in `docs/aws-migration-plan.md` §2.5 and is not duplicated here.
