# DNS and mail for `meridiansgrp.com` (Phase 0 step 7)

Looked up 2026-09-15 with `dig` and `whois`. No secrets here; everything below is public DNS.

| Record | Today | What it means for the migration |
|---|---|---|
| Registrar | GoDaddy.com, LLC | Nameserver changes are made in the GoDaddy account. |
| Nameservers | `ns25/ns26.domaincontrol.com` (GoDaddy DNS) | GoDaddy DNS **cannot alias the bare domain (apex) to a CloudFront distribution**; it only allows an A record with a fixed IP, and CloudFront has no fixed IP. |
| Apex `meridiansgrp.com` A | `216.24.57.1` (Render) | Must move with cutover. |
| `www` CNAME | `meridian-web-c2sv.onrender.com` — the Render Next.js service's own hostname. It **is** now written down, in `infra/meridian/stacks/dns.py`: the Route 53 zone has to reproduce it exactly or `www` goes dark at the nameserver switch. It is our own public DNS, readable by anyone with `dig`, not another owner's identifier. | Must move with cutover. |
| MX | `mx1/2/3-usg2.ppe-hosted.com` (Proofpoint Essentials, sold through GoDaddy / Microsoft 365) | Inbound mail is NOT moving. SES only sends. |
| SPF | `v=spf1 include:_spf-usg2.ppe-hosted.com include:secureserver.net ~all` | Phase 1 adds `include:amazonses.com` (or uses a custom MAIL FROM subdomain, which keeps the root SPF unchanged — preferred). |
| DMARC | `p=quarantine; adkim=r; aspf=r` | Relaxed alignment, so SES DKIM signing on `meridiansgrp.com` with MAIL FROM `mail.meridiansgrp.com` passes without touching this record. |
| Microsoft 365 tenant TXT | `NETORGFT20419956.onmicrosoft.com` | The Microsoft sign-in tenant exists; Phase 4 re-registers the app in it. Copied into the Route 53 zone with the SPF string — one TXT record set, two values — for the same reason as the row above. |

## Decided, and built — **ADR 0017**

The provisional decision below was taken, and the zone now exists as code:

| | |
|---|---|
| **The decision** | [`docs/adr/0017-route53-zone.md`](../adr/0017-route53-zone.md) — Route 53 public hosted zone, registrar stays GoDaddy. |
| **The zone, as code** | [`infra/meridian/stacks/dns.py`](../../infra/meridian/stacks/dns.py) (stack `meridian-shared-dns`), asserted record by record in `infra/tests/test_dns.py`. |
| **The switch** | [`docs/runbooks/dns-nameserver-switch.md`](../runbooks/dns-nameserver-switch.md) — verify with `dig @<ns>` first, lower TTLs a day ahead, switch at GoDaddy, roll back by switching the nameservers back. |

**DNS is now code.** A record changed in the Route 53 console is silently reverted by the
next `cdk deploy`; change `infra/meridian/stacks/dns.py` instead. The SES DKIM CNAMEs and
the `mail.meridiansgrp.com` MAIL FROM records are written by the stack, not typed by hand —
which is why the row below says the custom MAIL FROM subdomain is preferred, and why the
apex SPF record is left exactly as it is.

## The original provisional decision (kept for the reasoning)

**Provisional decision (safe default): create a Route 53 public hosted zone for
`meridiansgrp.com` in Phase 1 and move the nameservers from GoDaddy to Route 53 before
Phase 2 needs CloudFront.** Reason: Route 53 is the only way to point the apex at
CloudFront (an ALIAS record); GoDaddy DNS cannot. Everything else (MX, SPF, DMARC, the
Microsoft TXT, DKIM) is copied into the zone first, verified with `dig` against the Route 53
nameservers, and only then are the nameservers switched. The registrar stays GoDaddy.
Cost: $0.50/month per zone plus queries (cents).

- **Trigger to change it:** Andres prefers to keep DNS at GoDaddy. Then the apex must
  redirect to `www` at the DNS host (GoDaddy "forwarding") and only `www` points at
  CloudFront — workable, but the bare domain then depends on GoDaddy's forwarder, which
  is plain HTTP for the first hop.
- **Needs a human:** the nameserver switch itself is done in the GoDaddy account by Andres;
  it is reversible (switch back) and has a TTL tail of up to 48 hours. Lower the TTLs on the
  Render records to 300 s at least a day before cutover (Phase 9 precondition).

## Update 2026-09-15 (Phase 1/2)

The table above was the first inventory and listed only the records that matter for the
web and mail moves. The complete live zone — **sixteen record sets**, including Microsoft
365 autodiscover, the DKIM selectors, Lync/Teams federation, `msoid`, GoDaddy's
`_domainconnect`, and `ai` — is exported in `infra/dns/meridiansgrp.com.zone.json` and
reproduced by the `meridian-shared-dns` stack;
`docs/runbooks/dns-nameserver-switch.md` verifies every one of them before the switch.
The network stack adds `origin-<env>.meridiansgrp.com` for CloudFront's origin (ADR 0018).

**Fourteen came from the `dig` export; two came from a candidate-name sweep.** §3a of the
runbook now does both — a GoDaddy zone-file export diffed by `scripts/dns_zone_diff.py`,
and a list of likely names dug straight at `ns25.domaincontrol.com`. The export tells you
about records somebody chose to export; the sweep asks about names nobody wrote down.

**`ai.meridiansgrp.com` is not Meridian's.** It is the other owner's application in the
shared AWS account (ADR 0001), a CNAME to their own CloudFront distribution. Route 53 has
to keep answering it after the switch or their product goes dark because of a change we
made. Never repoint, shorten or remove it; "confirm `ai.meridiansgrp.com` still serves" is
a post-switch check and a Phase 2 roll-back line.
