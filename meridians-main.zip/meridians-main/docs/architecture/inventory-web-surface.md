# Inventory — web surface (Next.js rewrites, Flask screens, APIs, threads, auth)

Phase 0 inventory for the AWS migration (`docs/aws-migration-plan.md` §2.5, Phase 5b).
Every line below was read out of the repo on the `aws-migration` branch; each claim cites
`path:line`. No code was changed to produce it.

**Line citations:** every `path:line` in this document **cites commit `4ccddcb`** (2026-09-15). Later commits reformat and fix those files, so check a citation with `git show 4ccddcb:<path>`, not the working tree.

Plain-language note: a *rewrite* is a rule in the Next.js config that says "when the
browser asks for this path, quietly fetch it from the Flask server instead". A path that
has no rewrite and no React page simply does not exist once the domain points at the
Next.js app — it returns 404.

---

## 1. `web/next.config.mjs` rewrites

The file builds the rules from one list, so the rule count is bigger than the line count.

**The `jinja` list** (`web/next.config.mjs:34-45`) — 9 path families, each expanded into
**two** rules (`web/next.config.mjs:53-58`): the bare path and `"<path>/:path*"` for its
sub-pages. Destination is always `${FLASK}` + the same path, where `FLASK` is
`MERIDIAN_API_ORIGIN` or `http://localhost:5050` (`web/next.config.mjs:22`).

| # | Source | Also | Destination |
|---|---|---|---|
| ~~1~~ | ~~`/logout`~~ | — | **Retired 2026-09-16** (Phase 5b). **Dropped**, not rebuilt: signing out is `POST /api/v2/auth/logout`, which the React shell already calls. The Flask route was a redirect plus a cookie clear with no screen behind it. |
| ~~2~~ | ~~`/signup`~~ | — | **Retired 2026-09-16** (Phase 4 step 5). Route, template and rewrite deleted; membership is invite-only (P-6). |
| ~~3~~ | ~~`/forgot-password`~~ | — | **Retired 2026-09-16** (Phase 4 step 5). Now a React route in `web/src/app/forgot-password/`; Flask route and template deleted. |
| ~~4~~ | ~~`/reset-password`~~ | — | **Retired 2026-09-16** (Phase 4 step 5). Now a React route in `web/src/app/reset-password/`; the rewrite had never had a Flask route behind it (finding 3 below). |
| ~~5~~ | ~~`/invoice`~~ | — | **Retired 2026-09-16** (Phase 5b). Now a React wizard at `web/src/app/invoice/` over `/api/v2/invoices`; the seven Flask routes, the `/api/invoice/clients` endpoint and four Jinja templates are deleted. `templates/invoice/pdf_template.html` STAYS — WeasyPrint renders it into the PDF. |
| ~~6~~ | ~~`/superadmin`~~ | — | **Retired 2026-09-16** (Phase 5b). Now `web/src/app/superadmin/`, over `/api/v2/superadmin/orgs`. The `/superadmin/test` dry-run harness was **dropped**, not ported. |
| ~~7~~ | ~~`/profile`~~ | — | **Retired 2026-09-16** (Phase 5b). Now `web/src/app/profile/`, which redirects to `/settings#profile` — the section that already owned the content. |
| ~~8~~ | ~~`/wearbly`~~ | — | **Retired 2026-09-16** (Phase 5b). **Dropped**, not rebuilt — the product is frozen (plan P-5). The four `uniform_*` tables keep their reader; the six wizard routes, their templates and the order worker are gone. |
| ~~9~~ | ~~`/config/mx-employees`~~ | — | **Retired 2026-09-16** (Phase 5b). Now `web/src/app/config/mx-employees/`, over `/api/v2/config/mx-employees`. |

= **0 rules from 0 families — the list is empty.** (18 from 9 when this was written; 12
from 6 after Phase 4 step 5; Phase 5b closed all six on 2026-09-16, across its two slices.
`infra/meridian/edge_paths.py`'s pin moved 15 → 3 ALB patterns — `/auth/*`, `/api/*`,
`/static/*` and nothing else.)

**Conditional additions** (`web/next.config.mjs:44`): if `MERIDIAN_JINJA_AUTH=1`
(`web/next.config.mjs:23`), `/login` and `/dashboard` are appended to the same list,
adding 4 more rules (2 families). They are **off by default** — the React login posts to
`/api/v2/auth/login` instead (`web/next.config.mjs:12-16`).

**`/auth/*` proxy** (`web/next.config.mjs:60`), in `beforeFiles`:

| Source | Destination |
|---|---|
| `/auth/:path*` | `${FLASK}/auth/:path*` |

**`afterFiles`** (`web/next.config.mjs:63-64`):

| Source | Destination |
|---|---|
| `/api/:path*` | `${FLASK}/api/:path*` |
| `/static/:path*` | `${FLASK}/static/:path*` |

`fallback` is empty (`web/next.config.mjs:66`).

### Counts

| Group | Rules |
|---|---|
| `jinja` list (9 families × 2) | 18 |
| `/auth/:path*` | 1 |
| `/api/:path*`, `/static/:path*` | 2 |
| **Total, default config** | **21** |
| `MERIDIAN_JINJA_AUTH=1` adds | +4 (25) |

**The plan's "21 rules, 9 Jinja path families" is correct** for the default configuration.

---

## 2. Flask `render_template()` inventory

`web_app.py` contained **78** `render_template(` calls when this was written — matching the
plan. Phase 5b removed four of them with the invoice wizard. The one outside `web_app.py`,
in `src/invoice_generator.py`, renders the invoice **PDF** template (not a screen) and is
no longer a `render_template` at all: it is that module's own Jinja environment, because
there is no Flask application in the call path since the wizard moved to FastAPI.

Classification used below (mutually exclusive):

- **(a) reachable through a rewrite** — a `jinja`-list family points at it.
- **(b) one of the three process wizards** — `qb-revenue`, `mx-payroll`,
  `qb-usa-payroll`, including their processing/results pages. Owned by Phase 11.
- **(c) auth flow** — sign-in, sign-up, password reset, OAuth callback, org setup.
- **(d) unreachable/dead** — no rewrite points at it and nothing under `web/src` links
  to it. The only paths React links to are `/`, `/dashboard`, `/features`,
  `/forgot-password`, `/login`, `/onboarding/org`, `/pnl-provider`(+3 sub-pages),
  `/pricing`, `/runs`, `/settings`, `/signup` — all of which are React pages except
  `/forgot-password` and `/signup`, which are in the rewrite list.

### (a) Reachable through a rewrite — 0 calls

**All sixteen went on 2026-09-16 (Phase 5b), across its two slices:** the `/profile`, `/superadmin`, `/wearbly` and `/config/mx-employees` families in one, `/invoice`'s four in the other, each with their templates. The heading said "4 calls" while the prose below it said all sixteen were retired, which is a contradiction on the page (critic P5B-04); the `jinja` array in `web/next.config.mjs` is empty, so the count is **0**. The table below is kept as the record of what was retired, not as a list of what is left.

| Route | Methods | Template | Line |
|---|---|---|---|
| ~~`/profile`~~ | — | ~~`portal/profile.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/config/mx-employees`~~ | — | ~~`config/mx_employees.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/superadmin`~~ | — | ~~`superadmin/orgs.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/superadmin/org/<org_id>`~~ | — | ~~`superadmin/org_detail.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/superadmin/org/<org_id>/data`~~ | — | ~~`superadmin/org_data.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/superadmin/test`~~ | — | ~~`superadmin/test.html`~~ | **Retired 2026-09-16** (Phase 5b), dropped rather than ported |
| ~~`/invoice`~~ | — | ~~`invoice/index.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/invoice/items`~~ | — | ~~`invoice/items.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/invoice/preview`~~ | — | ~~`invoice/preview.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/invoice/history`~~ | — | ~~`invoice/history.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/wearbly`~~ | — | ~~`wearbly/index.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/wearbly/map_columns/<session_id>`~~ | — | ~~`wearbly/map_columns.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/wearbly/configure/<session_id>`~~ | — | ~~`wearbly/configure.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/wearbly/preview/<session_id>`~~ | — | ~~`wearbly/preview.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/wearbly/processing/<job_id>`~~ | — | ~~`wearbly/processing.html`~~ | **Retired 2026-09-16** (Phase 5b) |
| ~~`/wearbly/results/<order_id>`~~ | — | ~~`wearbly/results.html`~~ | **Retired 2026-09-16** (Phase 5b) |

`/logout` and `/reset-password` were also in the rewrite list and rendered
no template — `/logout` redirected, and **`/reset-password` had no Flask route at all**
(no `@app.route('/reset-password')` exists in `web_app.py`; the reset mail is sent by
`sb.auth.reset_password_email` at `web_app.py:1827` and `web_app.py:2260`). That rewrite
family currently proxies to a Flask 404.

### (b) The three process wizards — 12 calls

| Route | Methods | Template | Line |
|---|---|---|---|
| `/qb-revenue` | GET | `qb_revenue/index.html` | `web_app.py:2929` |
| `/qb-revenue/processing/<job_id>` | GET | `qb_revenue/processing.html` | `web_app.py:3037` |
| `/qb-revenue/results/<int:batch_id>` | GET | `qb_revenue/results.html` | `web_app.py:3067` |
| `/mx-payroll` | GET | `mx_payroll/index.html` | `web_app.py:3768` |
| `/mx-payroll/processing/<job_id>` | GET | `mx_payroll/processing.html` | `web_app.py:3830` |
| `/mx-payroll/results/<int:batch_id>` | GET | `mx_payroll/results.html` | `web_app.py:3857` |
| `/qb-usa-payroll` | GET | `qb_usa_payroll/index.html` | `web_app.py:4115` |
| `/qb-usa-payroll/review/<session_id>` | GET | `qb_usa_payroll/review.html` | `web_app.py:4314` |
| `/qb-usa-payroll/preview/<session_id>` | GET | `qb_usa_payroll/preview.html` | `web_app.py:4405` |
| `/qb-usa-payroll/processing/<job_id>` | GET | `qb_usa_payroll/processing.html` | `web_app.py:4746` |
| `/qb-usa-payroll/results/<batch_id>` | GET | `qb_usa_payroll/results.html` | `web_app.py:4788` |
| `/qb-usa-payroll/history` | GET | `qb_usa_payroll/history.html` | `web_app.py:4947` |

None of these paths is in the `jinja` rewrite list, so **today they are already
unreachable through the Next.js origin** — React covers them at
`/processes/[process]/new` and `/processes/[process]/runs/[runId]` (§7).

### (c) Auth flow — 6 calls

| Route | Methods | Template | Line | Reachable? |
|---|---|---|---|---|
| `/login` | GET, POST | `auth/login.html` | `web_app.py:1768` | only with `MERIDIAN_JINJA_AUTH=1` |
| ~~`/signup`~~ | — | ~~`auth/signup.html`~~ | — | **Retired 2026-09-16** — route and template deleted |
| ~~`/forgot-password`~~ | — | ~~`auth/forgot_password.html`~~ | — | **Retired 2026-09-16** — rebuilt in React |
| `/auth/callback` | GET | — | `api/routers/oauth.py` (FastAPI since Phase 11 G2) | yes — `/auth/:path*`. **`auth/callback.html` deleted 2026-09-16**: it existed only to feed the hash-fragment implicit grant back to the server, and that branch went with it. The route now does one code→token exchange and renders nothing. |
| `/setup-org` | GET, POST | `auth/setup_org.html` | `web_app.py:2103` | **no** — not rewritten; React equivalent is `/onboarding/org` |

### (d) Unreachable / dead — 44 calls, RETAINED

Dead means "nothing reaches them": no rewrite points at them and nothing under `web/src`
links to them. It does **not** mean deleted — every template and every Flask route below is
still in the tree. They are retired in **Phase 11**, in the same sweep that retires the three
process wizards, and `docs/migration-tracker.md` carries the row that owns them.

| Group | Routes (line) | Count |
|---|---|---|
| Portal dashboard | `/dashboard` (`2214`) — reachable only with `MERIDIAN_JINJA_AUTH=1`; React owns `/dashboard` | 1 |
| Admin | `/admin/users` (`2319`, `2323`), `/admin/organization` (`2382`, `2385`) | 4 |
| Public marketing | `/` (`2520`), `/features` (`2526`), `/pricing` (`2532`), `/privacy` (`2537`), `/terms` (`2542`), `/security` (`2547`) — all six have React equivalents under `web/src/app/(marketing)/` | 6 |
| Legacy revenue (pre-QB) | `/revenue` (`2588`), `/revenue/processing/<job_id>` (`2746`), `/revenue/results/<int:batch_id>` (`2901`) | 3 |
| File preview | `/preview/<path:filename>` (`3169`, `3177`) | 2 |
| Config / settings | `/config` (`5127`), `/settings` (`6404`) | 2 |
| ~~ADP payroll~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. | ~~6~~ |
| Error handlers | `@app.errorhandler(404)` (`7946` → `errors/404.html` at `7953`), `@app.errorhandler(405)` (`7956` → `errors/404.html` at `7960`) | 2 |
| ~~Booking payroll (v1)~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. | ~~6~~ |
| ~~Booking payroll v3~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. | ~~4~~ |
| ~~Booking payroll v4~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. | ~~4~~ |
| ~~Booking payroll v5~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. | ~~4~~ |

The two error handlers are a special case: they are dead *as URLs* (no route points at
them) but live as behaviour — any unmatched Flask URL renders `errors/404.html`.

### Class totals

As classified when this inventory was written (the 78 `render_template()` calls in
`web_app.py` at that date):

| Class | Calls | Where they stand on 2026-09-16 |
|---|---|---|
| (a) reachable through a rewrite | 16 | **0 left** — all sixteen retired in Phase 5b, with their templates and their rewrites |
| (b) three process wizards | 12 | still here, Phase 11 |
| (c) auth flow | 6 | still here, Phase 4 |
| (d) unreachable / dead | 44 | **20 left** — the 24 of the five payroll families were deleted 2026-09-22 (CX-API-03); the rest still here, unreachable, Phase 11 |
| **Total (`web_app.py`)** | **78** | |

Four of the five booking-payroll generations (`booking_payroll`, `_v3`, `_v4`, `_v5`) plus
`adp_payroll` account for 24 of the 44 dead calls — over half. All 24 were deleted on
2026-09-22 with their routes, templates and dicts (Codex CX-API-03, Andres's approval).

---

## 3. `/api/v1` legacy surface

**One path left, and it is FastAPI's:** `/api/v1/health` (and its `/health`
alias), `api/routers/health.py` since Phase 5a. Render's `healthCheckPath`, the ALB
target group and CloudFront point at it; Phase 12 D-25 retires it.

**The other ten were deleted in Phase 11 G2** (Andres's yes of 2026-09-22, plan §7.2),
on grep evidence that nothing in `web/`, `api/`, `src/`, `workers/`, `scripts/`,
`infra/`, `lambda/`, `docs/runbooks/` or `render.yaml` called them:

| Route | Methods | Purpose |
|---|---|---|
| `/api/v1/revenue/batches` | GET | List revenue batches |
| `/api/v1/revenue/results/<int:batch_id>` | GET | One revenue batch's results (no `org_id` predicate) |
| `/api/v1/payroll/batches` | GET | List payroll batches (no `org_id` predicate) |
| `/api/v1/config/providers` | GET | Provider mapping rows |
| `/api/v1/config/locations` | GET | Location mapping rows |
| `/api/v1/config/payers` | GET | Payer mapping rows |
| `/api/v1/config/employees` | GET | Employee mapping rows |
| `/api/v1/settings` | GET, PUT | Read / update application settings |
| `/api/v1/user/me` | GET | Current user and org |

`tests/test_retired_flask_api.py` keeps them gone: no Flask rule under `/api/v1`, no
caller anywhere, no view function left on `web_app`.

---

## 4. `/api/v2` surface

One Flask blueprint, `api_v2`, built by `create_api_v2_blueprint()` at
`src/api/v2/__init__.py:118-122` with `url_prefix="/api/v2"`. It is **not** FastAPI and
not `csrf.exempt` (`src/api/v2/__init__.py:7-8`).

### Router modules

| Module | `@bp.route` decorators | Registered by | URL rules produced |
|---|---|---|---|
| `src/api/v2/routes.py` | 15 | `register_routes` (`__init__.py:123`) | 15 |
| `src/api/v2/auth_routes.py` | 3 | `register_auth_routes` (`__init__.py:127`) | 3 |
| `src/api/v2/config_routes.py` | 13 | `register_config_routes` (`__init__.py:133`) | 19 |
| `src/api/v2/user_routes.py` | 8 | `register_user_routes` (`__init__.py:138`) | 8 |
| `src/api/v2/qb_usa_runs.py` | 15 | `register_runs_routes` (`__init__.py:141`) | 15 |
| `src/api/v2/oneshot_runs.py` | 9 | `register_oneshot_routes` (`__init__.py:146`) | 18 |
| `src/api/v2/pnl_routes.py` | 9 | `register_pnl_routes` (`__init__.py:151`) | 9 |
| **Total** | **72** | | **88** |

Decorator count and rule count differ because two modules register in a loop:
`config_routes.py:458` and `:467` register PATCH and DELETE once per mapping collection,
and `oneshot_runs.py:618-900` registers its nine endpoints once per one-shot process
(`qb-revenue` and `mx-payroll`).

Non-router modules in the same package: `errors.py`, `limits.py`, `runs_common.py`,
`schemas.py`, `state_machine.py` (0 route decorators each).

### OpenAPI cross-check — **one mismatch**

Registering the blueprint on a bare Flask app gives **88 URL rules over 63 unique paths,
88 GET/POST/PUT/PATCH/DELETE operations**.
`openapi/meridian-v2.json` declares **62 paths / 87 operations**.

The one path present in code and missing from the spec is:

```
POST /api/v2/qb-usa-payroll/runs/{run_id}/quickbooks   (src/api/v2/qb_usa_runs.py:1301)
```

Every other path and every method set matches exactly. The checked-in spec — and
therefore the generated `web/src/lib/api/schema.d.ts` — is stale by that one endpoint.

### Where the contract says pydantic must NOT be used

`docs/api-v2-contract.md` §10.1 (`docs/api-v2-contract.md:1106-1116`): *"Pydantic lives at
the HTTP edge only, in `src/api/v2/schemas/`. It does not enter
`src/qb_usa_payroll_processor.py`, `src/qb_usa_payroll_roster.py`, or any other
processor."* Processors use plain dataclasses; the bridge is a thin
`to_response(run_result) -> RunEnvelope` adapter per process. Pydantic has exactly three
jobs there: request validation, response serialisation, and being the schema source for
OpenAPI → TypeScript.

---

## 5. Background threads and module-level run state

### `threading.Thread(` sites — 15 total

| File:line | Target | What it runs |
|---|---|---|
| `web_app.py:2717` | `process_in_background` | Legacy revenue processing |
| `web_app.py:2802` | `process_in_background` | Legacy revenue, second entry point |
| `web_app.py:3018` | `process_in_background` | QB revenue (same worker, QB flag) |
| `web_app.py:3812` | `process_payroll_in_background` | MX payroll |
| `web_app.py:4445` | `qb_usa_payroll_process_background` | QB USA payroll export |
| ~~`web_app.py:6788`~~ | ~~`adp_payroll_process_background`~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`web_app.py:8468`~~ | ~~`booking_payroll_process_background`~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`web_app.py:8847`~~ | ~~`booking_payroll_process_background`~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`web_app.py:9688`~~ | ~~`adp_v3_process_background`~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`web_app.py:10266`~~ | ~~`bkv4_process_background`~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`web_app.py:10787`~~ | ~~`bkv5_process_background`~~ | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`web_app.py:11435`~~ | ~~`_wearbly_process_background`~~ | **Gone 2026-09-16** (Phase 5b): the daemon went with the screen, and the five broken `uniform_*` writes with it. |
| `src/api/v2/qb_usa_runs.py:1296` | `webapp.qb_usa_payroll_process_background` | v2 `execute` for QB USA payroll — reuses the Jinja worker |
| `src/api/v2/oneshot_runs.py:594` | local `worker` | v2 one-shot run creation |
| `src/api/v2/oneshot_runs.py:703` | local `worker` | v2 one-shot run, second entry point |

12 in `web_app.py`, 3 under `src/api/v2/`. The plan's "~15-17" is right; the exact number
today is **15**.

### `src/run_store.py` module-level state

- `LEGACY_STATUS_TO_STATE` (`src/run_store.py:48`) — a constant lookup, not run state.
- `_volatile = {}` (`src/run_store.py:61`) — **the one mutable module-level dict**: a
  process-local cache of the keys declared volatile (a parsed `RunResult`, a
  DataFrame-backed result blob). By design these are recomputable from the run's own
  params, so a worker without the cache recomputes rather than booking off a half-empty
  dict (`src/run_store.py:23-30`).
- `class RunStore(Mapping)` (`src/run_store.py:189`) — the dict-shaped facade whose
  storage is Postgres `process_runs`, not memory.

### Other module-level mutable state holding run results

**Already migrated to Postgres** (these are `RunStore` instances, safe across workers):

| Name | Line | Process |
|---|---|---|
| `processing_status` | `web_app.py:43` | `qb-revenue`, `volatile=('result',)` |
| `payroll_processing_status` | `web_app.py:3264` | `mx-payroll` |
| `qb_usa_payroll_sessions` | `web_app.py:3908` | `qb-usa-payroll` |
| `qb_usa_payroll_jobs` | `web_app.py:3910` | `qb-usa-payroll` |

**Still plain in-process dicts** — these are what pin `desiredCount: 1`:

| Name | Line | Holds |
|---|---|---|
| ~~`adp_payroll_session`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`adp_payroll_job_status`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`booking_payroll_session`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`booking_payroll_job_status`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`adp_v3_session`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`adp_v3_job_status`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`bkv4_session`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`bkv4_job_status`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`bkv5_session`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`bkv5_job_status`~~ | — | **Deleted 2026-09-22** (CX-API-03, with Andres's approval): routes, templates, session/job dicts and workers. |
| ~~`wearbly_session`~~ | — | **Gone 2026-09-16** (Phase 5b): the Wearbly wizard was dropped. |
| ~~`wearbly_job_status`~~ | — | **Gone 2026-09-16** (Phase 5b): same commit, same reason. |

Six wizards, twelve dicts — all twelve now gone (Wearbly in Phase 5b, the five payroll
families on 2026-09-22, CX-API-03). In `src/process_runs.py` the module-level singletons
`_memory_store` (`:228`), `_injected_store` (`:231`) and `_supabase_store` (`:239`) are
storage-backend handles, not per-run result holders.

`_RUN_OVERRIDES` **no longer exists**. It was replaced by
`process_runs.run_state.run_overrides` in migration 022; the identifier survives only in
comments at `src/qb_usa_payroll_roster.py:150` and `src/process_runs.py:24`, and the
public accessor is `run_overrides(org_id, run_id)` at `src/qb_usa_payroll_roster.py:163`.

No `results_cache` or bare `_runs` module-level name exists anywhere in `web_app.py` or
`src/`.

---

## 6. Auth surface

| Route | Methods | Line | `@csrf.exempt` | Reaches Flask via |
|---|---|---|---|---|
| `/login` | GET, POST | `web_app.py:1751` | no | only with `MERIDIAN_JINJA_AUTH=1` |
| ~~`/signup`~~ | — | **deleted 2026-09-16** | — | — |
| ~~`/forgot-password`~~ | — | **deleted 2026-09-16** | — | — |
| `/auth/google` | GET | `api/routers/oauth.py` (FastAPI, Phase 11 G2) | no | `/auth/:path*` — redirects to the Cognito hosted domain under `AUTH_BACKEND=cognito`, Supabase otherwise |
| `/auth/microsoft` | GET | `api/routers/oauth.py` (FastAPI, Phase 11 G2) | no | `/auth/:path*` — as above |
| `/auth/callback` | GET | `api/routers/oauth.py` (FastAPI, Phase 11 G2) | no | `/auth/:path*` — **authorization code only** since 2026-09-16 |
| ~~`/auth/set-session`~~ | — | **deleted 2026-09-16** | — | — |
| `/logout` | GET | `web_app.py` | no | `jinja` list |
| `/setup-org` | GET, POST | `web_app.py` | no | **nothing** — no rewrite |
| ~~`/reset-password`~~ | — | never existed; rewrite deleted 2026-09-16 | — | — |

**There is no longer any `@csrf.exempt` route** in `web_app.py`, `src/*.py` or
`src/api/v2/*.py`. `/auth/set-session` was the only one and was deleted in Phase 4
step 5; `tests/test_security.py`'s SEC-04 now asserts it 404s. The v2 blueprint is
deliberately not exempt (`src/api/v2/__init__.py:7-8`).

The React-side auth endpoints live under the v2 blueprint instead:
`POST /api/v2/auth/login` (`src/api/v2/auth_routes.py:371`),
`POST /api/v2/auth/logout` (`:412`), `GET /api/v2/dashboard` (`:427`).

---

## 7. React screens that exist today

19 `page.tsx` files under `web/src/app/`:

| Route | File |
|---|---|
| `/` | `web/src/app/(marketing)/page.tsx` |
| `/features` | `web/src/app/(marketing)/features/page.tsx` |
| `/pricing` | `web/src/app/(marketing)/pricing/page.tsx` |
| `/privacy` | `web/src/app/(marketing)/privacy/page.tsx` |
| `/security` | `web/src/app/(marketing)/security/page.tsx` |
| `/terms` | `web/src/app/(marketing)/terms/page.tsx` |
| `/config` | `web/src/app/config/page.tsx` |
| `/dashboard` | `web/src/app/dashboard/page.tsx` |
| `/help/[process]` | `web/src/app/help/[process]/page.tsx` |
| `/login` | `web/src/app/login/page.tsx` |
| `/onboarding/org` | `web/src/app/onboarding/org/page.tsx` |
| `/pnl-provider` | `web/src/app/pnl-provider/page.tsx` |
| `/pnl-provider/cost-upload` | `web/src/app/pnl-provider/cost-upload/page.tsx` |
| `/pnl-provider/drivers-upload` | `web/src/app/pnl-provider/drivers-upload/page.tsx` |
| `/pnl-provider/setup` | `web/src/app/pnl-provider/setup/page.tsx` |
| `/processes/[process]/new` | `web/src/app/processes/[process]/new/page.tsx` |
| `/processes/[process]/runs/[runId]` | `web/src/app/processes/[process]/runs/[runId]/page.tsx` |
| `/runs` | `web/src/app/runs/page.tsx` |
| `/settings` | `web/src/app/settings/page.tsx` |

Plus the shared shells `layout.tsx`, `loading.tsx`, `error.tsx` and `not-found.tsx` in
`web/src/app/`.

**Gap against the `jinja` list:** **no families remain** (was 9). Phase 4 step 5 closed
three on 2026-09-16 — `/forgot-password` and `/reset-password` are React screens now, and
`/signup` was dropped rather than rebuilt (P-6). Phase 5b closed the last six the same
day, across its two slices: `/invoice` is a React wizard at `web/src/app/invoice/` over
`/api/v2/invoices`, and `/profile`, `/superadmin` and `/config/mx-employees` are React
screens (`web/src/app/{profile,superadmin,config/mx-employees}/`); `/logout` and
`/wearbly` were **dropped** — signing out is `POST /api/v2/auth/logout`, and Wearbly is
frozen (P-5) with its screen not rebuilt and its four `uniform_*` tables left readable.
React *does* already cover the three process wizards via
`/processes/[process]/new` and `/processes/[process]/runs/[runId]`, and the six public
marketing pages.

---

## 8. Corrections to `docs/aws-migration-plan.md`

1. **`_RUN_OVERRIDES` no longer exists.** §2.5 / Phase 11 step 3 cites
   "`_RUN_OVERRIDES` at `src/qb_usa_payroll_roster.py:142`". That line is a comment
   explaining that the dict was **removed**; the state lives in
   `process_runs.run_state.run_overrides` (migration 022). See
   `src/qb_usa_payroll_roster.py:150-160`.
2. **The five wizard line references in §2.5 are stale or point at the wrong thing.**
   `web_app.py:7013, 8648, 9807, 10348, 10892` are mid-function statements, not the
   module-level dicts. The dicts to serialize are the twelve listed in §5 above
   (`web_app.py:6597, 6598, 8232, 8233, 9391, 9393, 9932, 9935, 10476, 10478, 11077,
   11080`), and they belonged to **six** wizards (ADP, booking payroll v1/v3/v4/v5,
   Wearbly), not five. **Five after 2026-09-16**: Phase 5b dropped the Wearbly screen and
   its two dicts, so Phase 11 has two fewer to serialize.
3. **`/reset-password` is proxied but has no Flask route.** Phase 5b lists it as
   "built in Phase 4"; the rewrite family existed and the destination 404ed.
   **Resolved 2026-09-16** (Phase 4 step 5): the rewrite is deleted and the screen is
   React.
4. **`openapi/meridian-v2.json` is one path behind the code** —
   `POST /api/v2/qb-usa-payroll/runs/{run_id}/quickbooks` is missing (62 paths / 87
   operations in the spec vs 63 paths / 88 operations live).
5. **The three process wizards are already unreachable through Next.js.** Phase 9's exit
   criterion says the `jinja` array will be "empty except the three process wizards" —
   but `/qb-revenue`, `/mx-payroll` and `/qb-usa-payroll` are **not in the array now** and
   never were, so the criterion as written cannot be met literally; the array must reach
   empty outright.
