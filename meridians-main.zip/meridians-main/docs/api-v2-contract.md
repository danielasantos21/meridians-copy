# Meridian `/api/v2` Contract

**Status:** proposal / specification. No implementation code.
**Consumers:** Next.js (React + TypeScript) app, same browser origin, `/api/*` rewritten to Flask.
**Producers:** Flask (`web_app.py` + new `src/api/v2/` blueprint).
**Scope:** three processes — `qb-revenue`, `mx-payroll` (currently `qb_payroll`), `qb-usa-payroll` — plus `/api/v2/me`, `/api/v2/processes`, `/api/v2/csrf`, and config reads.

Grounded in the current handlers: `web_app.py` `qb_revenue_*` (2355–2560), `qb_payroll_*` (3642–3830), `qb_usa_payroll_*` (4034–4700), the v1 block (7010–7175), `src/auth.py`, `src/storage.py`, `src/qb_usa_payroll_roster.py`, migration `021_qb_usa_payroll_runs.sql`.

---

## 0. Design premises

> **Superseded by ADR 0021** (`docs/adr/0021-auth-cognito-sessions.md`), from Phase 4 onward. The premises below still describe the shape of the API; the single-issuer cookie premise does not survive Cognito.

| Premise | Consequence |
|---|---|
| Same origin via Next.js rewrites | No CORS config, no `Access-Control-*`, cookies are first-party. `SameSite=Lax` is sufficient and should be set. |
| httpOnly Supabase JWT cookies kept | The SPA never sees the token. Auth state comes from `GET /api/v2/me`, not from decoding a JWT client-side. |
| Global `CSRFProtect` stays on | Every unsafe v2 method needs a token header. §6. |
| Uniform `runs` resource | One resource shape, **per-process discriminated payloads**. §12 lists every place the uniformity is a lie and what to do instead. |
| Real money, real PII | Downloads are short-TTL signed URLs with an audit row, never long-lived links. Gate declarations are permanent records (migration 021 already enforces `declared ⇒ declared_by AND declared_at`). |

### Blocking prerequisite

All three processes today keep run state in **module-level dicts inside one Flask process**:
`qb_usa_payroll_sessions`, `qb_usa_payroll_jobs`, `processing_status`, `payroll_processing_status`, and `_RUN_OVERRIDES` (`src/qb_usa_payroll_roster.py:142`). With Jinja this survives because the browser is pinned to one worker for a short wizard. Under a SPA polling across gunicorn workers it does not.

**`/api/v2` cannot be built on those dicts.** It needs a `process_runs` table (sketch in §1.1). Every endpoint below assumes it exists.

---

## 1. Resource model

### 1.1 `process_runs` (new — migration 022)

```
run_id        UUID PRIMARY KEY              -- server-issued at create, the ONLY id the SPA uses
org_id        UUID NOT NULL REFERENCES organizations(id)
process       TEXT NOT NULL CHECK (process IN ('qb-revenue','mx-payroll','qb-usa-payroll'))
state         TEXT NOT NULL                 -- §2
step          TEXT                          -- §2, discriminator within needs_input
batch_id      INTEGER REFERENCES import_batches(id)   -- NULL until the worker allocates one
fiscal_year   INTEGER                       -- NULL until parsed (mx-payroll derives it from the file)
period        INTEGER
params        JSONB NOT NULL DEFAULT '{}'   -- per-process create params (§3)
inputs        JSONB NOT NULL DEFAULT '{}'   -- classified file manifest
run_state     JSONB NOT NULL DEFAULT '{}'   -- prompts, alerts, declared_gates, run-only roster overrides
progress      JSONB NOT NULL DEFAULT '{}'   -- {step,message,percent}
error         JSONB                         -- {code,message,details}
idempotency_key TEXT
created_by    UUID
created_at    TIMESTAMPTZ DEFAULT now()
updated_at    TIMESTAMPTZ DEFAULT now()
expires_at    TIMESTAMPTZ                   -- draft/needs_input TTL, 24h
```

RLS mirrors migrations 019–021: `FOR ALL USING (org_id = user_org_id()) WITH CHECK (org_id = user_org_id())`.
Unique partial index on `(org_id, idempotency_key)` where `idempotency_key IS NOT NULL`.

`run_state.run_overrides` replaces `_RUN_OVERRIDES` — the "just this run" roster answers must be readable by whichever worker serves the execute call, and must still be dropped when the run terminates (the `clear_run_overrides` contract).

### 1.2 Run envelope (returned by every runs endpoint)

```jsonc
{
  "run_id": "3f1a…",
  "process": "qb-usa-payroll",
  "state": "needs_input",
  "step": "roster_review",
  "period": 7,
  "fiscal_year": 2026,
  "batch_id": null,
  "created_at": "2026-08-23T14:02:11Z",
  "created_by": { "id": "…", "email": "controller@…" },
  "progress": { "step": "roster_review", "message": null, "percent": 0 },
  "available_actions": ["submit_review", "cancel"],
  "blockers": [ /* §5 + §2.3 */ ],
  "counts": { "prompts": 2, "alerts": 1, "journals": 0, "gates": 0 },
  "links": {
    "self": "/api/v2/qb-usa-payroll/runs/3f1a…",
    "review": "/api/v2/qb-usa-payroll/runs/3f1a…/review",
    "preview": "/api/v2/qb-usa-payroll/runs/3f1a…/preview"
  },
  "error": null
}
```

`available_actions` is authoritative. The SPA enables buttons from it and never re-derives legality from `state`.

---

## 2. Run state machine

### 2.1 States

| State | Meaning | Terminal |
|---|---|---|
| `draft` | Created, files accepted, nothing parsed yet | no |
| `parsing` | Server is classifying/reading inputs | no |
| `needs_input` | Waiting on the human. `step` says which screen. | no |
| `ready` | Everything answered/declared; execute is legal | no |
| `running` | Background export in flight | no |
| `blocked` | Ran (or parsed), hit a **fixable** refusal — unmapped config, the org's QuickBooks maps / MX column map missing or unreadable, the qb-usa roster empty or its benefit overrides unreadable — **nothing written**. `error.code` + `details` say why; `retry` re-runs it from the recorded upload. Every process (Andres, 2026-09-25). §5 | no |
| `completed` | Artifacts exist and are downloadable | yes |
| `failed` | Unrecoverable (a file that cannot be read, an internal error); may or may not have a `batch_id`. Never retried: start a new run | yes |
| `expired` | `expires_at` passed while in `draft`/`needs_input`; uploads purged | yes |
| `superseded` | A later run booked the same `(process, period, fiscal_year)` | yes |

`superseded` already exists in `import_batches.status` (migration 021) and nothing currently sets it. v2 should set it on both tables when a later run for the same period reaches `completed`.

### 2.2 Legal transitions

```
draft ──▶ parsing ──▶ needs_input ──▶ ready ──▶ running ──▶ completed
             │             │▲                       │         │
             │             ││ (re-parse after       │         └──▶ superseded
             │             │└─ answers submitted)   │
             │             │                        ├──▶ blocked ──▶ running   (retry: one-shots)
             ├──▶ failed   ├──▶ ready (nothing to   └──▶ failed      │
             └──▶ blocked  │     ask: qb-usa skips                    └──▶ parsing | needs_input | ready
                           │     review when clean)                        (retry: qb-usa re-reads the period)
                           └──▶ blocked (a re-parse meets a fixable refusal)

any non-terminal ──▶ expired   (TTL sweeper)
any non-terminal ──▶ failed    (worker exception)
draft|needs_input|blocked ──▶ cancelled  (DELETE)
```

**`blocked` is for every process** (Andres, 2026-09-25: "every process blocks and gives an error code, and can be re-run"). A FIXABLE refusal parks the run with nothing booked; `retry` (offered only from `blocked`) re-runs it from the RECORDED upload — the same object version, through the malware gate on RDS — as a compare-and-set start (`process_runs.begin_action`: of two retries exactly one starts, the other is `409 RUN_STATE_CHANGED`) under the `Idempotency-Key` ledger. qb-revenue and mx-payroll retry into `running`; qb-usa's retry is a PARSE (`retry` job held in `parsing`, `JobSpec.working_state`) that lands on `roster_review` / `preview` — it never books. What is fixable, per process: qb-revenue — unmapped providers/facilities/payers (`MAPPINGS_MISSING`), QuickBooks maps empty/unreadable/incomplete (`QB_MAPPINGS_UNAVAILABLE`), clinic groups for unposted JEs (`UNPOSTED_CONFIG_UNAVAILABLE`); mx-payroll — QuickBooks payroll maps or the MX column map empty/unreadable/incomplete (`QB_MAPPINGS_UNAVAILABLE`, `details.reason` `empty`/`load_failed`/`incomplete`/`column_map_empty`/`column_map_load_failed`); qb-usa-payroll — the roster empty (`ROSTER_EMPTY`, `details.reason` `empty`) or the month's benefit overrides unreadable (`QB_MAPPINGS_UNAVAILABLE`, `details.reason` `load_failed`/`no_session`/`no_org`), at the parse or at the execute's re-parse. Anything else (`FILE_UNREADABLE`, `PERIOD_UNDETECTABLE`, `EXPORT_FAILED`, an internal error) stays `failed`.

Illegal transitions return `409 RUN_STATE_INVALID` with `details.state` / `details.expected_states`, mirroring today's `'Job is not in blocked state'` (web_app.py:2227).

**`ready → running` is the only place money leaves.** It is guarded server-side by re-evaluating gates and prompts, exactly as `qb_usa_payroll_process` does now — the client's `declared_gates` list is an input to that check, never a substitute for it.

### 2.3 The `step` discriminator

`needs_review` is not one screen. `step` is what the Next.js router keys on.

| process | `step` values (in order) | Notes |
|---|---|---|
| `qb-usa-payroll` | `upload` → (`mapping_fix`) → `roster_review` → `preview` → `processing` → `results` | `roster_review` is skipped when `prompts` and `alerts` are both empty (matches `qb_usa_payroll_review` redirecting straight to preview). `mapping_fix` is entered from `blocked` (a fixable parse refusal). |
| `qb-revenue` | `upload` → `processing` → (`mapping_fix`) → `results` | `mapping_fix` is entered from `blocked`, mid-run. |
| `mx-payroll` | `upload` → `processing` → (`mapping_fix`) → `results` | No human step; `mapping_fix` is entered from `blocked`, mid-run. |

**Gate declaration is not a separate `step`.** In the real UI it lives on the preview screen as a blocking sub-state (`templates/qb_usa_payroll/preview.html:166`). Modelling it as its own step would invent a screen that does not exist and would make "go back and look at the numbers again" a navigation instead of a scroll. Instead:

```jsonc
{ "state": "needs_input", "step": "preview",
  "available_actions": ["declare_gates", "cancel"],
  "blockers": [
    { "code": "GATES_UNDECLARED", "severity": "block",
      "message": "2 failed gates have not been reviewed.",
      "items": ["employer_tax_crossfoot", "benefit_allocation_crossfoot"],
      "resolve": { "method": "POST", "path": "…/declarations" } }
  ] }
```

When `blockers` is empty on `step: "preview"`, `available_actions` contains `execute`. That is one screen with two states, which is what the accountant actually sees.

### 2.4 Next.js routing map

Single dynamic route, one switch:

```
/processes/[process]/runs/[runId]
```

```ts
// state+step → screen. Exhaustive; unknown pairs render <UnknownRunState/> and log.
const SCREEN = {
  'draft:*':                 'UploadScreen',      // (create is at /processes/[process]/new)
  'parsing:*':               'ParsingScreen',     // spinner, polls
  'needs_input:roster_review': 'RosterReviewScreen',
  'needs_input:preview':     'PreviewScreen',     // gate declaration inline
  'needs_input:mapping_fix': 'MappingFixScreen',  // qb-revenue only
  'ready:preview':           'PreviewScreen',
  'running:processing':      'ProcessingScreen',  // polls or SSE
  'blocked:mapping_fix':     'MappingFixScreen',
  'completed:results':       'ResultsScreen',
  'failed:*':                'FailureScreen',
  'expired:*':               'ExpiredScreen',     // "upload the files again"
  'superseded:*':            'SupersededScreen',  // read-only, links to the newer run
} as const;
```

Rules:
- The URL never encodes the step. Deep links stay valid as the run advances.
- After any mutation the server returns the **full new envelope**; the client swaps state and re-renders. No client-side state machine.
- `ProcessingScreen` polls `GET …/runs/{id}` (or subscribes to `…/events`) and navigates on terminal state.

---

## 3. Endpoint tables

Every endpoint below: `@require_auth` → `@require_org` → `@require_permission(...)`, in that order, inheriting the v1 decorator stack. Every response error uses the §4 envelope.

### 3.1 Cross-cutting

| Method | Path | Purpose | Permission | Request | Response | Codes |
|---|---|---|---|---|---|---|
| GET | `/api/v2/health` | Liveness + backend mode | none | — | `{status,version,database}` | 200 |
| GET | `/api/v2/csrf` | Mint CSRF token; sets readable `XSRF-TOKEN` cookie | auth only | — | `{token,expires_at}` | 200, 401 |
| GET | `/api/v2/me` | Session bootstrap for the whole SPA | auth + org | — | §3.1a | 200, 401, 403 |
| GET | `/api/v2/processes` | Which processes this user may see, and their entry points | auth + org | — | §3.1b | 200, 401, 403 |
| POST | `/api/v2/auth/logout` | Clear auth cookies | auth | — | `{ok:true}` | 204, 401 |
| POST | `/api/v2/auth/mfa` | Answer the TOTP challenge a sign-in returned | none | `{session,code}` | §3.1c | 200, 401, 422, 429 |
| POST | `/api/v2/auth/forgot-password` | Send a reset code | none | `{email}` | `{ok:true}` | 200, 422, 429 |
| POST | `/api/v2/auth/reset-password` | Spend a reset code on a new password | none | `{email,code,password}` | `{ok:true}` | 200, 400, 422, 429 |
| POST | `/api/v2/auth/mfa/setup` | Begin enrolling an authenticator | auth | `{password}` | `{secret,otpauth_uri,session}` | 200, 401, 409, 422, 429 |
| POST | `/api/v2/auth/mfa/verify` | Verify the first code and enable TOTP | auth | `{session,code}` | `{ok:true}` | 200, 401, 422, 429 |

**3.1c The MFA step and the reset pair — added in Phase 4 step 5. Decisions: [ADR 0021](adr/0021-auth-cognito-sessions.md).**

All five are reached only under `AUTH_BACKEND=cognito`; `/auth/forgot-password` also serves the Supabase path. They are registered in both modes so the surface does not change shape with a config switch, and refuse in the §4 envelope rather than 404-ing.

`POST /auth/login` may now answer 200 with a **challenge** instead of a session:

```jsonc
{ "user": null, "org": null, "challenge": "mfa", "session": "<opaque handle>" }
```

`session` is a **server-side handle**, not the Cognito session. The Cognito `Session`, the username and Cognito's `ChallengeParameters` stay in the Flask process; the client could not replay the handle against Cognito even if it leaked, and it is spent on first use. `POST /auth/mfa` redeems it and answers with the same `LoginOut` a password-only sign-in returns.

**Field constraints, enforced as a 422 before any Cognito call.** `code` on `/auth/mfa` and `/auth/mfa/verify` must match `^\d{6}$`; `password` on `/auth/reset-password` must be at least **12** characters, the pool's policy minimum. Both refusals are `VALIDATION_ERROR` with the offending field named — which is the point: the alternative for a short password is `RESET_CODE_INVALID`, one opaque message covering four different causes. A malformed `code` also leaves the parked handle **unspent**, so a typo does not cost the user their half-finished sign-in.

Two endpoints answer **identically whether or not the account exists**, which is the whole point of them: `/auth/forgot-password` is always `200 {"ok":true}`, and `/auth/reset-password` refuses with one `RESET_CODE_INVALID` for a wrong code, an expired code, a refused password and an unknown address alike.

Enrolment re-asks for the password (`/auth/mfa/setup`), which is what stops a borrowed, still-signed-in browser from registering a second factor. A user who **already** has an authenticator gets `409 MFA_ALREADY_ENROLLED` rather than `INVALID_CREDENTIALS`: the pool answering with the TOTP challenge means the password was right, and sending that user off to re-type it named the wrong problem. Nothing is disclosed — the caller is signed in as that account and has just re-authenticated as it. The secret is returned **once** and is not retrievable afterwards. `/auth/mfa/verify` does `VerifySoftwareToken` **and** `SetUserMFAPreference` in one request — the first alone registers a device the pool never asks for.

All five key on the auth-path rate-limit bucket (`LIMIT_AUTH`, §9).

**3.1a `GET /api/v2/me`**
```jsonc
{ "user": { "id":"…", "email":"controller@stellamattina.com", "name":"…",
            "dashboard_preferences": {} },
  "org":  { "id":"…", "name":"Stella Mattina Health, Inc.", "slug":"smh", "role":"admin" },
  "permissions": { "revenue": {"access":true,"results":true},
                   "payroll": {"access":true,"results":false},
                   "adp_payroll": {"access":false,"results":false},
                   "config":  {"access":true,"results":true} },
  "csrf": { "token": "…", "expires_at": "2026-08-23T15:02:11Z" } }
```
Shipping `permissions` here is what lets the nav render correctly without a round trip per link. It is a **UI hint only** — every endpoint still enforces `require_permission` server-side.

**3.1b `GET /api/v2/processes`**
```jsonc
{ "data": [
  { "key":"qb-revenue", "name":"QB Revenue", "color":"#2563EB",
    "permission":"revenue", "can_access":true, "can_view_results":true,
    "steps":["upload","processing","results"],
    "create": { "content_type":"multipart/form-data", "path":"/api/v2/qb-revenue/runs",
                "params_schema": { "type":"object", "additionalProperties":false,
                                   "properties": { "period": {…}, "fiscal_year": {…}, … } } },
    "last_run": { "run_id":"…", "state":"completed", "period":7, "fiscal_year":2026 } },
  { "key":"mx-payroll", "name":"MX Payroll", "color":"#7C3AED", "permission":"payroll", … },
  { "key":"qb-usa-payroll", "name":"QB USA Payroll", "color":"#7C3AED", "permission":"payroll",
    "steps":["upload","roster_review","preview","processing","results"],
    "readiness": { "roster_ready": true } }   // today's `roster_ready=_qb_usa_roster() is not None`
] }
```
`create.params_schema` (Phase 11 F3) is the JSON Schema of the `params` part §3.3 describes: the process manifest's `params_model` in validation mode, without the model's docstring. The SPA renders the create form of a process that registers no custom create step (`web/src/components/create-params/registry.tsx`) from it alone.

### 3.2 Uniform runs resource

`{process}` ∈ `qb-revenue | mx-payroll | qb-usa-payroll`. Permission column shows the mapped `require_permission(process_key, level)`.

| Method | Path | Purpose | Permission | Request | Response | Codes |
|---|---|---|---|---|---|---|
| POST | `/api/v2/{process}/runs` | Create a run; upload + classify inputs | `access` | `multipart/form-data` (§3.3) | Run envelope | 201, 400, 401, 403, 409, 413, 415, 422, 429 |
| GET | `/api/v2/{process}/runs` | Run history, paginated + filtered (§11) | `results` | query | `{data:[RunSummary],page:{…}}` | 200, 401, 403 |
| GET | `/api/v2/{process}/runs/{run_id}` | Canonical run envelope; the SPA's poll target | `access` | — | Run envelope | 200, 401, 403, 404 |
| DELETE | `/api/v2/{process}/runs/{run_id}` | Cancel/abandon a non-terminal run, purge uploads | `access` | — | 204 | 204, 401, 403, 404, 409 |
| GET | `/api/v2/{process}/runs/{run_id}/events` | SSE stream of envelope deltas (poll fallback: `GET …/runs/{id}`) | `access` | — | `text/event-stream` | 200, 401, 403, 404 |
| GET | `/api/v2/{process}/runs/{run_id}/artifacts` | List output files | `results` | — | §3.7 | 200, 401, 403, 404, 409 |
| POST | `/api/v2/{process}/runs/{run_id}/artifacts/{artifact_id}/download-url` | Mint a short-lived signed URL + write an audit row | `results` | — | §7 | 201, 401, 403, 404, 409, 429 |
| POST | `/api/v2/{process}/runs/{run_id}/artifacts/bundle` | Build/refresh the ZIP, return a signed URL | `results` | — | §7 | 201, 401, 403, 404, 409, 429 |

Process-specific sub-resources (advertised via `links` / `available_actions`; absent endpoints 404 rather than 405, so the SPA never has to special-case a process):

| Method | Path | Processes | Purpose | Permission | Codes |
|---|---|---|---|---|---|
| GET | `…/runs/{id}/review` | qb-usa-payroll | Roster prompts + change alerts (§3.4) | `access` | 200, 404, 409 |
| POST | `…/runs/{id}/review` | qb-usa-payroll | Submit answers + alert decisions; re-parses | `access` | 200, 409, 422, 429 |
| GET | `…/runs/{id}/preview` | qb-usa-payroll | 9 JEs + gate results + explanations (§3.5) | `access` | 200, 404, 409 |
| POST | `…/runs/{id}/declarations` | qb-usa-payroll | Declare expected gate failures | `access` | 200, 409, 422 |
| POST | `…/runs/{id}/execute` | all three | Start the export | `access` | 202, 409, 422, 429 |
| POST | `…/runs/{id}/retry` | qb-revenue | Re-run after fixing mappings (§5) | `access` | 202, 409, 429 |
| GET | `/api/v2/qb-usa-payroll/accrual-preview?period=&year=` | qb-usa-payroll | Guess accrual days before any upload | `access` | 200, 422 |

`accrual-preview` is deliberately **not** under `/runs` — it exists before a run does. Process helpers live at `/api/v2/{process}/{helper}`.

**`Idempotency-Key` on `execute` and `retry`** (§12.9; Phase 11 E3, enforced on RDS). 1-128 visible ASCII
characters (else `422 VALIDATION_ERROR`), unique per organization **and** process. The request is
fingerprinted as `{process, run_id, action, body}` (qb-usa's `confirm_declared_gates` compared as a set):

- a repeat with the same key and the same request replays the SAME run's envelope (`202`, the run as it
  stands now) and never starts the export a second time;
- the same key with a different request (another run, another action, other declarations) is
  `409 IDEMPOTENCY_CONFLICT`, `details.reason: "payload_mismatch"`;
- the same key while the first request is still being handled is `409 IDEMPOTENCY_CONFLICT`,
  `details.reason: "in_progress"`, `retryable: true`;
- a request that was refused (any `4xx` before the export started) is not cached: the same key may be
  sent again once the cause is fixed.
- a key left `pending` by a request that died before its effect answers `in_progress` for 15 minutes
  (measured by the database clock); after that the next request with it takes it over and, finding no
  effect on the run, does the action (Phase 11 D4 wave).

Independently of the key, the start itself is a compare-and-set on RDS: of two `execute`/`retry` requests
that both passed the state check (different keys, or none) exactly one starts the run and the other is
`409 RUN_STATE_CHANGED`.

The ledger is `public.job_idempotency`, scope `run.execute` (`src/api/v2/execute_idempotency.py`). Off RDS
(Supabase, until cutover) qb-usa keeps its `run_state.execute_idempotency_key` check and the one-shots
ignore the header on `execute`/`retry`. The create's own key (§3.3) is unchanged.

### 3.3 Create request shapes (per-process, discriminated)

`multipart/form-data`, part `files[]` repeated, plus one JSON part `params` (`Content-Type: application/json`). A JSON part avoids the string-typed form fields the current handlers hand-parse.

```jsonc
// qb-usa-payroll
{ "period": 7, "year": 2026, "accrual_days": 3, "accrual_days_prefill": 3 }
// accrual_days: 0..14. accrual_days_prefill lets the server distinguish
// "left as derived" from "deliberately overridden" (web_app.py:4106).

// qb-revenue
{ "period": null, "fiscal_year": null,          // null == today's "auto"
  "je_date": "2025-12-28",
  "generate_unposted": true,
  "bank_deposits": { "WSC": 412300.55, "Galloway": 88100.00 } }

// mx-payroll
{ }   // period, year, day-split and provision date are all derived from the file
```

Limits: `413` over `MAX_CONTENT_LENGTH`; `415` on a non-CSV/XLSX part; `422` on `params` validation.
`Idempotency-Key` request header: a repeat with the same key returns the original run (`200`, not `201`) rather than creating a second booking of the same period.

### 3.4 `GET/POST …/runs/{id}/review` — qb-usa-payroll

Full request/response examples in §3A steps 2–3. Mirrors `qb_usa_payroll_review` / `qb_usa_payroll_review_save`, with `apply_answers` / `apply_alert_decision` persist-vs-run-only semantics preserved exactly.

### 3.5 `GET …/runs/{id}/preview` — qb-usa-payroll

Full example in §3A step 4. Mirrors `qb_usa_payroll_preview`: journals, gates, `explain_gates()` text, `undeclared`, `grand_total`. Returns `409 ROSTER_PROMPTS_OUTSTANDING` when prompts remain (today: a flash + redirect back to review).

### 3.6 Config reads (and the writes the blocked state needs)

| Method | Path | Purpose | Permission | Codes |
|---|---|---|---|---|
| GET | `/api/v2/config/providers` | Provider → department mappings | `config:access` | 200 |
| GET | `/api/v2/config/locations` | Facility → location/clinic group | `config:access` | 200 |
| GET | `/api/v2/config/payers` | Payer → type + account code | `config:access` | 200 |
| GET | `/api/v2/config/departments` | Managed department list | `config:access` | 200 |
| GET | `/api/v2/config/employees` | Employee allocations | `config:access` | 200 |
| GET | `/api/v2/config/settings` | Org settings | `config:access` | 200 |
| PUT | `/api/v2/config/settings` | Update org settings | `config:access` | 200, 422 |
| GET | `/api/v2/config/fiscal-calendar` | Period → JE date | `config:access` | 200 |
| GET | `/api/v2/config/qb-usa/roster` | Location/department rules, exceptions, master | `config:access` | 200 |
| POST | `/api/v2/config/providers` | Add a provider mapping (unblocks a run) | `config:access` | 201, 409, 422 |
| POST | `/api/v2/config/locations` | Add a location mapping | `config:access` | 201, 409, 422 |
| POST | `/api/v2/config/payers` | Add a payer mapping | `config:access` | 201, 409, 422 |
| POST | `/api/v2/config/departments` | Add a department | `config:access` | 201, 409, 422 |
| GET | `/api/v2/config/clinic-groups` | Clinic groups, incl. the unposted fields (`hospital_location`, `primary_location_code`: RDS only) | `config:access` | 200 |
| POST | `/api/v2/config/clinic-groups` | Add a clinic group | `config:access` | 201, 409, 422 |
| PATCH | `/api/v2/config/clinic-groups/{id}` | Edit `locations`, `bank_account_key`, `hospital_location`, `primary_location_code` — the in-app fix for `UNPOSTED_CONFIG_UNAVAILABLE` (N1). RDS only: 503 `details.reason: backend` elsewhere; another org's id 404; `locations`/`primary_location_code` blank 422; logs `clinic_group_change` | `config:access` | 200, 404, 422, 503 |
| GET | `/api/v2/config/mx-employees` | The org's ACTIVE MX employee roster | `config:access` | 200 |
| GET | `/api/v2/config/mx-departments` | NetSuite departments a roster row may take | `config:access` | 200 |
| PUT | `/api/v2/config/mx-employees/{employee_id}` | Create or replace one roster row | `config:access` | 200, 404, 422 |
| DELETE | `/api/v2/config/mx-employees/{employee_id}` | Take one employee off the roster (soft) | `config:access` | 204, 404 |
| POST | `/api/v2/config/mx-employees/{employee_id}/reactivate` | Put a deactivated employee back | `config:access` | 200, 404 |
| POST | `/api/v2/config/mx-employees/import` | One-time seed from the roster file | `config:access` | 200, 503 |

All list responses use the uniform collection shape `{"data":[…],"count":N}` — v1's bespoke `{"providers":…}`, `{"locations":…}` keys do not survive into v2, because a generated TS client wants one `Collection<T>`.

**The MX roster (Phase 5b) is keyed on the PAYROLL CODE, not on the table's row id.** `employee_id` is what the ADP export carries, what the roster is joined on and what the person editing the screen knows; a URL keyed on the surrogate would make "fix the row for employee 4471" an operation the screen has to look up first. `PUT` and not `PATCH` for the same reason the Jinja form posted every field every time: a partial update would let a half-filled inline edit blank a department nobody was editing.

`DELETE` is a **deactivation** — `active = false`, nothing removed, because a roster row a booked period already used is history. A code this organization does not have answers 404, exactly as a code another organization has would (§8).

**A known limitation, carried over rather than introduced:** the list is ACTIVE-only on both backends, so a deactivated employee is not in it and `…/reactivate` is reachable only by knowing the code. That was true of the Jinja page too; widening the read is a change to `src/database.py`'s dual-backend surface rather than to this port, and `docs/migration-tracker.md` carries the row. Re-`PUT`ting a code works today: the upsert sets `active = True`.

`mx-departments` is its own collection rather than a field on the roster response, because the rule above says every list is a `Collection<T>`. It is static (`src.payroll_processor.DEPARTMENT_ORDER`) and the same for every organization; it still takes the org, so a caller with none fails closed like its neighbours.

### 3.6a Invoices

The `/invoice` wizard's resource. Phase 5b; it replaces seven Flask routes and
`/api/invoice/clients`.

| Method | Path | Purpose | Permission | Codes |
|---|---|---|---|---|
| GET | `/api/v2/invoices/config` | Company block, clients on file, and the number to suggest | `invoice:access` | 200 |
| POST | `/api/v2/invoices/preview` | Normalise the lines and total them. Writes nothing | `invoice:access` | 200, 422 |
| POST | `/api/v2/invoices` | Write the row (spending a number), then render the PDF under it | `invoice:access` | 201, 422, 500, 503 |
| GET | `/api/v2/invoices` | The organization's invoices, newest first | `invoice:results` | 200 |
| POST | `/api/v2/invoices/{id}/render` | Produce the document for an invoice that has none | `invoice:access` | 200, 404, 409, 500, 503 |
| GET | `/api/v2/invoices/{id}/download` | The stored PDF, as an attachment | `invoice:results` | 200, 404, 409 |

**Two permissions, not one**, and it is §12.11's split inside a single wizard: raising an
invoice is `invoice:access`, reading the history of them is `invoice:results`. A caller who
holds the first and not the second is a normal caller, so a screen must render the denial in
place rather than treat it as a failure.

**No draft is stored between steps.** One `InvoiceDraftIn` body goes to `/preview` and the
same body goes to the create. The Flask wizard kept a half-built draft in the session, which
is why a refresh lost it and two tabs merged into one invoice; a stateless resource is also
what lets more than one api task serve it (plan §2.5).

**`/preview` is a POST on the READ rate-limit class.** The method is unsafe — so §6.1's CSRF
check applies — but the handler writes nothing and it is pressed once per edited line.

**Numbering.** `config.next_invoice_number` is a PEEK: reading it does not consume a number,
because opening the wizard and walking away must not leave a hole in a series an accountant
reads. The number is spent in the create, in one atomic statement, and a blank
`invoice_number` means "allocate one". A number the caller typed is honoured and the counter
is then pushed up past it. A collision the unique index refuses is retried exactly once.

**An invoice with no document is not a missing invoice** (Phase 5b critics P5B-05 and
P5AR5-03). The create writes the row before it renders, so that a document can never carry a
number the database disagrees with; the price is one reachable state where the row exists,
its number is spent and `pdf_filename` is null because the render failed after it. Three
rules follow, and they replace a 404 that used to cover all of them:

- `GET /{id}/download` answers **409 `INVOICE_NOT_RENDERED`** for that row — *"recorded, no
  document yet"* — and keeps 404 for an id this organization does not have and for a
  recorded filename whose file has left the disk.
- `POST /{id}/render` produces the missing document from the stored row, under the number
  the row already carries, and attaches it. It refuses an invoice that already has one with
  **409 `INVOICE_ALREADY_RENDERED`**, because overwriting it would make two documents with
  one number. It is `invoice:access`: it writes.
- The create's failure message must never say "raise it again". Raising it again spends a
  second number for one invoice, which is the hole this whole ordering exists to avoid.

The history carries the state: a row whose `pdf_filename` is `""` has no document, and a
screen must offer "render" there rather than a download link into a 409.

**Order inside the create: ALLOCATE, then render, then answer.** The row is written first —
which is what spends the number, retrying once onto a fresh one if the unique index refuses
the one the wizard was showing — and only then is the PDF rendered, under the number the row
came back carrying. The other order is how a document goes out named, printed and downloaded
as `INV-2026-007` while the database calls that invoice `INV-2026-008` and `007` belongs to
someone else.

A row that could not be written answers `503 PERSISTENCE_UNAVAILABLE` (retryable) and nothing
was rendered — no orphan PDF, no number spent, no success with a download URL for a row that
is not there. A render that fails after the row exists answers `500 EXPORT_FAILED`, and says
plainly that the invoice was recorded without a document rather than reporting success.

**Tax follows the organization, never the request.** `tax_rate` in the body is ignored unless
the org's `collect_tax` is on, which it is not until a Texas sales-tax permit is issued.

**The ACH numbers are masked** to their last four in `/config`, with `has_routing` /
`has_account` saying whether one is configured at all. The full values are rendered into the
PDF server-side and never reach a browser.

**Cross-tenant ids answer 404, never 403** (§8) — a 403 would confirm the id exists.

---

### 3.7 Artifacts

```jsonc
{ "data": [
  { "artifact_id": "a_9f2…",
    "name": "JE_QBUSA_HW3_smh_salaried_main_P07_FY26.csv",
    "kind": "journal_entry",           // journal_entry | workbook | data | report | bundle
    "subfolder": "journal_entries",
    "journal_no": "HW3_smh_salaried_main",
    "size_bytes": 18422,
    "content_type": "text/csv",
    "line_count": 142,
    "total": 412300.55 },
  { "artifact_id": "a_c41…", "name": "QB_USA_Payroll_Review_P07_FY26.xlsx",
    "kind": "workbook", "subfolder": "reports", "size_bytes": 91004,
    "content_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }
],
  "warnings": [
    { "code": "WORKBOOK_UNAVAILABLE",
      "message": "The workbook module is not installed on this server." }
  ] }
```

`warnings` carries today's `sess['workbook_error']` — a workbook that quietly went missing must not look like one that was never asked for.

**qb-revenue / mx-payroll on RDS (Phase 11).** After the QuickBooks CSVs from the tie-out, the
list carries what the run published besides them (`run_state.published_outputs`, written by the
worker job and by the in-process thread alike): the NetSuite JE CSVs (`journal_entry`,
`journal_entries`, the `artifacts` bucket), the enriched-data workbook (`data`), the revenue
workbook (`workbook`, subfolder `data`) and the validation report (`report`, `reports`) — those
three in the `phi` bucket. No `line_count`/`total` on these rows; `size_bytes` is set. The storage
path is rebuilt from the org, the run's batch and the recorded subfolder and name, never read
back. Off RDS the list is the tie-out alone, as before. Minting a `phi`-bucket file — these
workbooks, qb-usa's review workbook, any bundle — is an audited PHI access on RDS
(`src.phi.open_artifact`: two `audit.phi_access` rows, `object_name` `artifact:{batch_id}/{artifact_id}`),
in addition to the `artifact_downloads` row.
`409 ARTIFACTS_NOT_READY` when `state != completed`. This is a financial control (`qb_usa_payroll_download` re-checks it against Postgres, never the in-process session) and must be re-evaluated against the DB on every call.

---

## 3A. Worked example — `qb-usa-payroll` end to end

The richest flow, in full. Every field below maps to something a current handler already produces.

### Step 0 — accrual guess, before any file exists

```http
GET /api/v2/qb-usa-payroll/accrual-preview?period=7&year=2026
```
```jsonc
{ "days": 3, "pay_dates": ["2026-07-15", "2026-07-31"], "source": "pay_calendar" }
```

### Step 1 — create the run (multipart)

```http
POST /api/v2/qb-usa-payroll/runs
Content-Type: multipart/form-data; boundary=----x
X-CSRFToken: IjY0Y2E…
Idempotency-Key: 0f9c1b3e-2b7a-4e51-9a6b-8b2d6b0e11aa

------x
Content-Disposition: form-data; name="params"
Content-Type: application/json

{"period":7,"year":2026,"accrual_days":3,"accrual_days_prefill":3}
------x
Content-Disposition: form-data; name="files[]"; filename="PR_Register_07152026.csv"
Content-Type: text/csv
…
------x
Content-Disposition: form-data; name="files[]"; filename="PR_Register_07312026.csv"
…
------x
Content-Disposition: form-data; name="files[]"; filename="ADPINV_772913.csv"
…
------x
Content-Disposition: form-data; name="files[]"; filename="unum july 2026.csv"
…
------x
Content-Disposition: form-data; name="files[]"; filename="BCBS 7-2026 bill.csv"
…
------x--
```

One `files[]` field for everything — no `adp_files` / `benefit_files` split. The server sorts by content.

**`201 Created`**

```jsonc
{
  "run_id": "3f1a9c60-5f0e-4c1d-9a2b-77c9e5a10b41",
  "process": "qb-usa-payroll",
  "state": "needs_input",
  "step": "roster_review",
  "period": 7,
  "fiscal_year": 2026,
  "batch_id": null,
  "has_result": false,
  "created_at": "2026-08-23T14:02:11Z",
  "created_by": { "id": "8ab…", "email": "controller@stellamattina.com" },
  "viewer": { "can_execute": true, "can_view_results": true },
  "params": { "period": 7, "year": 2026, "accrual_days": 3 },
  "inputs": {
    "classified": [
      { "uploaded_as": "PR_Register_07152026.csv", "stored_as": "register_2026-07-15.csv",
        "kind": "register", "pay_date": "2026-07-15" },
      { "uploaded_as": "PR_Register_07312026.csv", "stored_as": "register_2026-07-31.csv",
        "kind": "register", "pay_date": "2026-07-31" },
      { "uploaded_as": "ADPINV_772913.csv", "stored_as": "invoice_2026-07-15_HW3.csv",
        "kind": "invoice", "pay_date": "2026-07-15", "entity": "HW3" },
      { "uploaded_as": "unum july 2026.csv", "stored_as": "benefits_1_unum.csv", "kind": "unum" },
      { "uploaded_as": "BCBS 7-2026 bill.csv", "stored_as": "benefits_2_bcbs.csv", "kind": "bcbs" }
    ],
    "rejected": [],
    "derived": { "accrual_days": 3, "accrual_days_source": "register_filenames" }
  },
  "progress": { "step": "roster_review", "message": null, "percent": 0 },
  "counts": { "prompts": 2, "alerts": 1, "journals": 0, "gates": 0, "blockers": 1 },
  "available_actions": ["submit_review", "cancel"],
  "blockers": [
    { "code": "ROSTER_PROMPTS_OUTSTANDING", "severity": "block",
      "message": "2 people on this payroll cannot be coded yet.",
      "resolve": { "method": "GET", "path": "/api/v2/qb-usa-payroll/runs/3f1a…/review" } }
  ],
  "warnings": [],
  "links": {
    "self":    "/api/v2/qb-usa-payroll/runs/3f1a…",
    "review":  "/api/v2/qb-usa-payroll/runs/3f1a…/review",
    "preview": "/api/v2/qb-usa-payroll/runs/3f1a…/preview",
    "execute": "/api/v2/qb-usa-payroll/runs/3f1a…/execute"
  },
  "error": null
}
```

`state` is `needs_input` because the roster produced prompts. When `prompts` **and** `alerts` are both empty, the create response instead comes back `state:"needs_input", step:"preview"` — the server skips the review screen exactly as `qb_usa_payroll_review` redirects today. The SPA does not decide this.

**Rejected-file variant — `422`** (atomic: the run directory is deleted, no run is created)

```jsonc
{ "error": {
  "code": "FILES_MISSING",
  "message": "These are payroll registers, but a register carries no pay date inside it, so it must be named register_YYYY-MM-DD.csv: july15.csv. Missing: ADP invoices, the BCBS carrier bill.",
  "details": {
    "undated": ["july15.csv"],
    "unrecognized": ["Book1.csv"],
    "missing": ["ADP invoices", "the BCBS carrier bill"]
  },
  "request_id": "req_01J8…", "retryable": false } }
```

### Step 2 — read the review

```http
GET /api/v2/qb-usa-payroll/runs/3f1a…/review
```
```jsonc
{
  "run_id": "3f1a…",
  "roster_source": "supabase",
  "prompts": [
    { "employee_key": "HW3-104882",
      "name": "RAMIREZ, Maria",
      "adp_entity": "HW3",
      "adp_cost_code": "006004",
      "adp_cost_desc": "MEDICAL ASSISTANT",
      "adp_dept_code": "009002",
      "adp_dept_desc": "SAMUELL",
      "suggested": { "qb_location": "9002 - Samuell", "entity": "HW3",
                     "variant": "smh_salaried" },
      "missing": ["qb_department"],
      "reason": "RAMIREZ, Maria is being paid on this payroll and we have them on file, but part of their coding is still blank. ADP has them at SAMUELL as MEDICAL ASSISTANT, under Stella Mattina Health, Inc. From that we suggest location 9002 - Samuell.",
      "fields": [
        { "name": "entity",        "required": true,  "enum": ["HW3", "DJ8"],
          "value": "HW3" },
        { "name": "variant",       "required": true,
          "enum": ["smh_salaried", "smllc_salaried", "smllc_hourly"],
          "value": "smh_salaried" },
        { "name": "qb_location",   "required": true,  "value": "9002 - Samuell" },
        { "name": "qb_department", "required": true,  "value": null },
        { "name": "qb_class",      "required": false, "value": null }
      ] },
    { "employee_key": "DJ8-220417",
      "name": "OKONKWO, Daniel",
      "adp_entity": "DJ8", "adp_cost_code": "006005", "adp_cost_desc": "FRONT DESK",
      "adp_dept_code": "009004", "adp_dept_desc": "GALLOWAY",
      "suggested": { "qb_location": "9004 - Galloway", "entity": "DJ8" },
      "missing": ["variant", "qb_department"],
      "reason": "OKONKWO, Daniel is being paid on this payroll but we have never coded them before. ADP has them at GALLOWAY as FRONT DESK, under Stella Mattina, LLC. From that we suggest location 9004 - Galloway.",
      "fields": [ /* variant has no default: DJ8 runs both a salaried and an hourly payroll */ ] }
  ],
  "alerts": [
    { "token": "HW3-100231|qb_location",
      "employee_key": "HW3-100231",
      "name": "DOE, Jordan",
      "field": "qb_location",
      "stored": "9001 - Bishop",
      "incoming": "9004 - Galloway",
      "reason": "We have Jordan Doe at 9001 - Bishop, but this month ADP has them at GALLOWAY. The run continues on 9001 - Bishop unless you change it.",
      "choices": [
        { "value": "keep",      "label": "Keep 9001 - Bishop",   "applies": "run" },
        { "value": "run",       "label": "Use 9004 - Galloway this run only", "applies": "run" },
        { "value": "permanent", "label": "Use 9004 - Galloway from now on",   "applies": "master" }
      ] }
  ],
  "enums": {
    "entities": ["HW3", "DJ8"],
    "variants": ["smh_salaried", "smllc_salaried", "smllc_hourly"],
    "alert_fields": ["entity", "variant", "qb_location", "qb_department"]
  }
}
```

The `reason` strings are the existing `_prompt_reason()` prose, verbatim. They are the product — an accountant answers the prompt from that sentence alone, without asking an engineer.

### Step 3 — submit answers (persist vs run-only)

```http
POST /api/v2/qb-usa-payroll/runs/3f1a…/review
Content-Type: application/json
X-CSRFToken: IjY0Y2E…
```
```jsonc
{
  "answers": [
    { "employee_key": "HW3-104882", "name": "RAMIREZ, Maria",
      "entity": "HW3", "variant": "smh_salaried",
      "qb_location": "9002 - Samuell", "qb_department": "07 - Medical Assistants",
      "qb_class": "",
      "persist": true },

    { "employee_key": "DJ8-220417", "name": "OKONKWO, Daniel",
      "entity": "DJ8", "variant": "smllc_hourly",
      "qb_location": "9004 - Galloway", "qb_department": "08 - Medical Office Assistants",
      "qb_class": "",
      "persist": false }
  ],
  "alert_decisions": [
    { "employee_key": "HW3-100231", "field": "qb_location",
      "value": "9004 - Galloway", "persist": false }
  ]
}
```

**`persist` semantics — this is the whole point of the screen, and must not be blurred:**

| `persist` | Effect | Storage |
|---|---|---|
| `true` | Permanent coding for this person | `_upsert_master` → `qb_usa_employee` row in Supabase. Location/department stored as `NULL` when they merely agree with the rule, so a stored copy of a rule can't go stale. |
| `false` | This run only | `set_run_override` → `run_state.run_overrides` on the run row (today: process-local `_RUN_OVERRIDES`). Dropped when the run terminates, so this period's decision can never leak into next period's. |

Alert decisions carry the same flag: `persist:false` maps to `applies:"run"`, `persist:true` to `applies:"permanent"` (`_update_master`). A `keep` choice submits nothing — the stored value is already what the run uses.

**`200 OK`** — the answers are applied and the processor is re-run with them (`_qb_usa_run(sess, force=True)`). The full new envelope comes back:

```jsonc
{ "run_id": "3f1a…", "state": "needs_input", "step": "preview",
  "has_result": true,
  "counts": { "prompts": 0, "alerts": 0, "journals": 9, "gates": 6, "blockers": 1 },
  "available_actions": ["declare_gates", "cancel"],
  "applied": { "answers": 2, "persisted": 1, "run_only": 1, "alert_decisions": 1 },
  "blockers": [ { "code": "GATES_UNDECLARED", "…": "…" } ],
  "links": { "…": "…" } }
```

**Persist failure without Supabase — `409`** (the run is still viable):

```jsonc
{ "error": {
  "code": "ROSTER_PERSIST_UNAVAILABLE",
  "message": "Saving a roster change needs Supabase; this run has no database connection. The change can still be applied to this run only.",
  "details": { "employee_keys": ["HW3-104882"], "can_retry_as": { "persist": false } },
  "retryable": false } }
```

**Invalid answer — `422`:**

```jsonc
{ "error": { "code": "ROSTER_ANSWER_INVALID",
  "message": "OKONKWO, Daniel: 'hourly' is not a payroll variant; expected one of ['smh_salaried', 'smllc_salaried', 'smllc_hourly']",
  "field_errors": { "answers[1].variant": ["not a valid payroll variant"] } } }
```

### Step 4 — the preview, with gate results

```http
GET /api/v2/qb-usa-payroll/runs/3f1a…/preview
```
```jsonc
{
  "run_id": "3f1a…",
  "period": 7, "fiscal_year": 2026,
  "accrual_days": 3,
  "grand_total": "1284920.44",
  "roster_source": "supabase",
  "journal_entries": [
    { "journal_no": "HW3_smh_salaried_main",    "date": "2026-07-31",
      "variant": "smh_salaried",   "kind": "main",    "line_count": 142, "total": "612044.10" },
    { "journal_no": "HW3_smh_salaried_accrual", "date": "2026-08-03",
      "variant": "smh_salaried",   "kind": "accrual", "line_count": 142, "total": "59230.08" },
    { "journal_no": "DJ8_smllc_salaried_main",  "date": "2026-07-31",
      "variant": "smllc_salaried", "kind": "main",    "line_count": 88,  "total": "311220.55" },
    { "journal_no": "DJ8_smllc_hourly_main",    "date": "2026-07-31",
      "variant": "smllc_hourly",   "kind": "main",    "line_count": 210, "total": "302425.71" }
    /* … up to nine: main + accrual across the three variants */
  ],
  "gates": [
    { "name": "gross_pay_crossfoot", "passed": true,
      "expected": "1002144.36", "actual": "1002144.36", "variance": "0.00",
      "offender_count": 0, "offenders": [],
      "why": "Gross pay on the registers equals gross pay booked to the JEs.",
      "declared": false },

    { "name": "employer_tax_crossfoot", "passed": false,
      "expected": "78210.44", "actual": "78188.19", "variance": "-22.25",
      "offender_count": 2,
      "offenders": [
        { "employee_id": "HW3-100231", "name": "DOE, Jordan",   "amount": "-18.10" },
        { "employee_id": "DJ8-220417", "name": "OKONKWO, Daniel", "amount": "-4.15"  } ],
      "why": "Employer taxes on the ADP invoice do not equal the employer taxes booked. A mid-period entity change usually explains a small variance.",
      "declared": false },

    { "name": "benefit_allocation_crossfoot", "passed": false,
      "expected": "44120.00", "actual": "44520.00", "variance": "400.00",
      "offender_count": 1,
      "offenders": [ { "employee_id": "HW3-104882", "name": "RAMIREZ, Maria", "amount": "400.00" } ],
      "why": "The carrier bills total more than the benefit deductions allocated. A retro-billed month is the usual cause.",
      "declared": false }
  ],
  "undeclared": ["employer_tax_crossfoot", "benefit_allocation_crossfoot"],
  "state": "needs_input",
  "step": "preview",
  "available_actions": ["declare_gates", "cancel"]
}
```

`offenders` is real employee names and dollar amounts. It is served only to `payroll:access` holders, is never written to `import_batches.overview_data` (plain TEXT), and lives only in `qb_usa_payroll_gate`. That constraint is already respected in the export path and must be respected here.

`why` is `explain_gates()`.

### Step 5 — declare the failed gates

```http
POST /api/v2/qb-usa-payroll/runs/3f1a…/declarations
```
```jsonc
{ "declared_gates": ["employer_tax_crossfoot", "benefit_allocation_crossfoot"],
  "note": "Mid-period entity change for Doe; BCBS retro-billed June for Ramirez." }
```

**`200 OK`**
```jsonc
{ "run_id": "3f1a…", "state": "ready", "step": "preview",
  "declared_gates": ["employer_tax_crossfoot", "benefit_allocation_crossfoot"],
  "declared_by": "controller@stellamattina.com",
  "declared_at": "2026-08-23T14:09:03Z",
  "undeclared": [],
  "blockers": [],
  "available_actions": ["execute", "cancel"] }
```

Declaring a gate that **passed** is rejected — `422 VALIDATION_ERROR`, `details.gates:["gross_pay_crossfoot"]`. Migration 021's `qb_usa_payroll_gate_only_failed_declared` check enforces the same rule at the storage layer; the API rejects it earlier with a better message. Declaring a pass would hide a real failure behind a stale declaration.

Declarations are re-evaluated at execute against the *current* result. If a re-parse changed which gates fail, previously-declared names that no longer fail are dropped and any new failure re-enters `undeclared`.

### Step 6 — execute

```http
POST /api/v2/qb-usa-payroll/runs/3f1a…/execute
Idempotency-Key: 2c4e7a91-…
```
```jsonc
{ "confirm_declared_gates": ["employer_tax_crossfoot", "benefit_allocation_crossfoot"] }
```

The body restates the declarations so the client cannot execute against a preview it never saw. The server checks its own stored declarations against its own recomputed `failed_gates` — the body is a concurrency guard, not the authority.

**`202 Accepted`**
```jsonc
{ "run_id": "3f1a…", "state": "running", "step": "processing",
  "progress": { "step": "validating", "message": "Starting…", "percent": 0 },
  "available_actions": [],
  "links": { "self": "/api/v2/qb-usa-payroll/runs/3f1a…",
             "events": "/api/v2/qb-usa-payroll/runs/3f1a…/events" } }
```

**Undeclared gate — `409`** (the export refusal, a financial control):
```jsonc
{ "error": {
  "code": "GATES_UNDECLARED",
  "message": "Cannot export: 1 gate failure(s) are still undeclared — benefit_allocation_crossfoot",
  "details": { "gates": ["benefit_allocation_crossfoot"] },
  "retryable": false } }
```

**No durable persistence — `503`:**
```jsonc
{ "error": {
  "code": "PERSISTENCE_UNAVAILABLE",
  "message": "Supabase is not configured (SUPABASE_URL/SUPABASE_SERVICE_KEY missing) — refusing to run QB USA Payroll without durable persistence. Nothing was saved.",
  "retryable": false } }
```

### Step 7 — poll

`GET /api/v2/qb-usa-payroll/runs/3f1a…` every 2 s, or subscribe to `…/events`. `progress.step` carries the worker's own labels, unchanged, so the label the user reads is the work actually happening:

```
validating (5) → loading (20) → declarations (40) → workbook (60)
   → exporting (78) → uploading (92) → complete (100)
```

```jsonc
{ "run_id": "3f1a…", "state": "running", "step": "processing",
  "batch_id": 1421,
  "progress": { "step": "uploading",
                "message": "Saving the run and uploading files...", "percent": 92 } }
```

`batch_id` appears mid-run, as soon as the `import_batches` row is allocated — deliberately **before** any export work, so its presence proves Postgres was reachable.

**Terminal:**
```jsonc
{ "run_id": "3f1a…", "state": "completed", "step": "results",
  "batch_id": 1421,
  "progress": { "step": "complete",
                "message": "Saved run and wrote 9 journal entry files.", "percent": 100 },
  "counts": { "journals": 9, "gates": 6, "gates_failed": 2, "gates_declared": 2 },
  "grand_total": "1284920.44",
  "available_actions": ["download", "view_results"],
  "warnings": [],
  "links": { "artifacts": "/api/v2/qb-usa-payroll/runs/3f1a…/artifacts" } }
```

**Failure after the batch row existed** — distinct from failure before it:
```jsonc
{ "state": "failed", "batch_id": 1421,
  "error": { "code": "STORAGE_UPLOAD_FAILED",
             "message": "Export failed after the run was recorded (batch 1421): …",
             "details": { "batch_id": 1421 } } }
```
vs.
```jsonc
{ "state": "failed", "batch_id": null,
  "error": { "code": "RUN_RECORD_FAILED",
             "message": "Nothing was saved: Could not create the run record in Postgres…" } }
```
The SPA must render these differently: the first leaves an `error` batch row an accountant will find later; the second leaves nothing at all.

### Step 8 — artifacts and download

```http
GET /api/v2/qb-usa-payroll/runs/3f1a…/artifacts
```
```jsonc
{ "data": [
    { "artifact_id": "a_9f2c…", "name": "JE_QBUSA_HW3_smh_salaried_main_P07_FY26.csv",
      "kind": "journal_entry", "subfolder": "journal_entries",
      "journal_no": "HW3_smh_salaried_main", "line_count": 142, "total": "612044.10",
      "size_bytes": 18422, "content_type": "text/csv" },
    /* … eight more … */
    { "artifact_id": "a_c410…", "name": "QB_USA_Payroll_Review_P07_FY26.xlsx",
      "kind": "workbook", "subfolder": "reports",
      "size_bytes": 91004,
      "content_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }
  ],
  "warnings": [] }
```

```http
POST /api/v2/qb-usa-payroll/runs/3f1a…/artifacts/a_9f2c…/download-url
```
```jsonc
{ "url": "https://xyz.supabase.co/storage/v1/object/sign/outputs/8ab…/1421/journal_entries/JE_QBUSA_HW3_smh_salaried_main_P07_FY26.csv?token=eyJ…",
  "expires_at": "2026-08-23T14:12:41Z",
  "expires_in": 120,
  "filename": "JE_QBUSA_HW3_smh_salaried_main_P07_FY26.csv",
  "content_type": "text/csv",
  "size_bytes": 18422,
  "audit_id": "dl_01J8…" }
```

The whole-run ZIP is `POST …/artifacts/bundle`, `expires_in: 300`. Both mints re-check, against Postgres: `payroll:results`, org ownership of the path prefix, `batch.status == 'completed'`, and no undeclared failed gates on `qb_usa_payroll_gate`.

---

### 3.8 Superadmin console (Phase 5b)

Meridian's cross-tenant console, moved off Jinja. **Superadmin only — a row in `public.superadmins` — and the refusal is `404 NOT_FOUND`, never `403`.** §8's 404-not-403 rule one level up: there it hides another tenant's row, here it hides a whole screen. `src.auth.require_superadmin` has answered 404 since it was written and this keeps that promise.

The gate hangs off the **user**, not the org. A superadmin need not be a member of anything — `src.auth.org_context` gives one a system context whose `org_id` is `None` — so a gate built on the org check would refuse the person it exists for. The three org-scoped endpoints take their organization from the **path**.

| Method | Path | Purpose | Permission | Codes |
|---|---|---|---|---|
| GET | `/api/v2/superadmin/orgs` | Every organization: member count, modules, latest batch, health | superadmin | 200, 404 |
| GET | `/api/v2/superadmin/orgs/{org_id}` | One organization: its row, membership and modules | superadmin | 200, 404 |
| GET | `/api/v2/superadmin/orgs/{org_id}/batches` | That organization's import-batch history | superadmin | 200, 404 |
| PUT | `/api/v2/superadmin/orgs/{org_id}/modules` | Turn one module on or off | superadmin | 200, 404, 422 |

**Only the first one is cross-organization, and only it is audited.** It goes through `src/pg.with_superadmin` — ADR 0011's one audited function, added in Phase 5b with Alembic revision 0010 — which verifies the caller's own `superadmins` row under `with_user` and then iterates `with_org(org_id)` once per organization, writing one `audit.superadmin_access` row per organization **before** reading it. The other three name an organization, and a superadmin acting on a named organization is an ordinary scoped checkout with the same RLS predicate any member of it gets (ADR 0022); auditing those as if they were cross-tenant would fill the trail with rows that mean nothing.

That is why the list is **one request** rather than one per organization plus two probes: the audit trail should be the size of the look.

```jsonc
// GET /api/v2/superadmin/orgs
{ "data": [
    { "id": "8ab…", "name": "…", "slug": "…", "created_at": "2026-01-02T00:00:00Z",
      "member_count": 6,
      "enabled_modules": ["revenue", "qb_usa_payroll"],
      "last_batch": { "status": "complete", "batch_type": "revenue",
                      "processed_at": "2026-09-01T10:04:00Z",
                      "record_count": 2481, "total_amount": 128401.22 } }
  ],
  "count": 1,
  "health": { "database": true, "mappings": false },
  "all_modules": ["adp_payroll", "booking_payroll", "config", "invoice", "payroll",
                  "pnl_provider", "qb_usa_payroll", "revenue"] }
```

**`health` is two answers, never one tick.** The Jinja console showed a single green light built from "the database answered" AND "`config/mappings.xlsx` loaded", so a missing workbook and a database outage looked identical from the one screen that exists to tell them apart. `health.database` is not a separate probe either — listing the organizations answers it with the same statement.

**No member's name or address appears on this surface.** `SuperadminOrgDetailOut.members` carries the user id, the role and the join date and nothing else: this is the one screen in the product that reads across tenants, and a directory of every customer's staff is not a thing it may become. An org's own admins have §3.7's `/api/v2/org/members` for that, gated on membership.

**The module toggle states `enabled` rather than implying it**, so a double-submitted request cannot flip it back, and it answers with the organization's WHOLE enabled set so the screen never renders its own guess. A module name that is not in `src.auth.ALL_PROCESSES` is a **422**, not a 404: the organization exists and the caller may reach it — the value is wrong, and a 404 would send the screen looking for a missing organization.

**Dropped rather than ported:** `/superadmin/test` and `/superadmin/test/run/<process>`. They were a developer harness — upload a file, run one of three processors against a `NoopDatabase`, render the counts — superseded by the real runs surface at `/processes/{process}/new`, and they accepted an arbitrary upload on a superadmin route that wrote it into the shared upload folder. Their two cross-organization reads did **not** go with them: `_check_process_health` and `_get_last_batch` are the `health` and `last_batch` fields above.

---

## 4. Error envelope and code catalogue

### 4.1 Envelope

v1's `api_error()` returns `{"success":false,"error":"…","code":"…"}` (web_app.py:275). v2 nests, so `error` is always an object and `details` has somewhere to live:

```jsonc
{ "error": {
    "code": "GATES_UNDECLARED",
    "message": "Cannot export: 2 gate failure(s) are still undeclared.",
    "details": { "gates": ["employer_tax_crossfoot", "benefit_allocation_crossfoot"] },
    "field_errors": null,
    "request_id": "req_01J…",
    "retryable": false
} }
```

- `message` is **user-facing prose**. The existing handlers already write good accountant-readable sentences (`_prompt_reason`, the upload `problems` list); those strings move here verbatim rather than being replaced with developer-speak.
- `field_errors`: `{"params.accrual_days": ["must be between 0 and 14"]}` for 422.
- `request_id` is logged server-side; it is what the user quotes in a support message.
- `api_error()` is kept and widened, not replaced — the v1 block keeps working.
- One `@errorhandler` per exception class returns this envelope for **every** `/api/*` path, including 404/405/413/429/500, so the SPA never has to parse an HTML error page.

### 4.2 Code catalogue (derived from actual failure modes)

**Auth / tenancy**

| Code | HTTP | Source |
|---|---|---|
| `AUTH_REQUIRED` | 401 | `require_auth` — no valid access token, refresh failed (`src/auth.py:334`) |
| `SESSION_EXPIRED` | 401 | Refresh token itself expired |
| `ORG_REQUIRED` | 403 | `require_org` — user belongs to no org |
| `PERMISSION_DENIED` | 403 | `require_permission` (`src/auth.py:543`); `details.required = {"process":"payroll","level":"results"}` |
| `CSRF_INVALID` | 403 | `CSRFError` from `CSRFProtect` |
| `RATE_LIMITED` | 429 | flask-limiter; `Retry-After` header set |
| `MFA_CHALLENGE_INVALID` | 401 | §3.1c — wrong TOTP code, spent handle, handle that never existed, or a Cognito challenge this app has no screen for. One code for all four on purpose. |
| `RESET_CODE_INVALID` | 400 | §3.1c — wrong or expired reset code, a password the pool's policy refused, or an address nobody owns. One code for all four, because `PreventUserExistenceErrors` already makes them identical coming out of Cognito. |
| `MFA_ALREADY_ENROLLED` | 409 | §3.1c — `/auth/mfa/setup` for a user who already has an authenticator. Distinct from `INVALID_CREDENTIALS` because the password was accepted; safe to distinguish because the caller has just re-authenticated as that account. |

**Input / files**

| Code | HTTP | Source |
|---|---|---|
| `VALIDATION_ERROR` | 422 | period 1–12, year 2020–2100, accrual 0–14 (web_app.py:4068, 4101, 4107) |
| `FILE_TYPE_INVALID` | 415 | `allowed_file()` — qb-revenue/mx-payroll reject non-xlsx/xls. Also, on every upload route and both backends, the **file signature** (`src/file_signature.py`, checked at the multipart ingress, at `storage.vet_upload` and in each manifest's input validator): a `.xlsx`/`.xlsm`/`.xls` must be an Excel workbook — either container, whatever the Excel extension (pandas opens by content): an OOXML workbook ZIP (`PK\x03\x04` + `[Content_Types].xml` + a SpreadsheetML workbook part) or an OLE2 document (`D0 CF 11 E0`); a `.csv` text with no NUL (UTF-8 or cp1252). `details.reason` is a fixed code (`not_excel`, `ooxml_corrupt`, `ooxml_parts_missing`, `csv_binary`, `csv_not_text`); the file is never named |
| `FILE_TOO_LARGE` | 413 | `MAX_CONTENT_LENGTH` |
| `FILE_UNRECOGNIZED` | 422 | `identify_csv` returned no kind — "Not recognised as an ADP register, an ADP invoice, or a UNUM or BCBS carrier bill" |
| `REGISTER_UNDATED` | 422 | register that doesn't match `_REGISTER_RE`; must be `register_YYYY-MM-DD.csv` |
| `FILES_MISSING` | 422 | missing registers / invoices / UNUM / BCBS; `details.missing[]` |
| `FILE_HEADERS_INVALID` | 422 | `validate_file_headers` — `details.missing = ["Facility Name", …]` |
| `PERIOD_UNDETECTABLE` | 422 | mx-payroll: `period_num == 0 or year == 0` |
| `PAYROLL_SHEET_NOT_FOUND` | 422 | mx-payroll: no `Costo nómina {Month} {Year}` sheet |
| `FILE_UNREADABLE` | 422 | any parse exception — "Could not read this period: …" |
| `FILE_UNSAFE` | 422 | Phase 11 C1, RDS only: a stored upload GuardDuty did not tag `NO_THREATS_FOUND`, or whose version/sha256 is not the one the run recorded (`src/process_inputs.py`); `details.reason` is a code |
| `FILE_SCAN_PENDING` | 409 | Phase 11 C1, RDS only: the malware scan of a fresh upload has not finished; try again shortly |

**Run lifecycle**

| Code | HTTP | Source |
|---|---|---|
| `RUN_NOT_FOUND` | 404 | Unknown run, **or a run in another org** (§8) |
| `RUN_EXPIRED` | 410 | "Session expired. Please upload the files again." |
| `RUN_STATE_INVALID` | 409 | e.g. retry on a non-blocked run; execute on `needs_input` |
| `ROSTER_PROMPTS_OUTSTANDING` | 409 | "There are unanswered roster questions. Finish the review first." |
| `GATES_UNDECLARED` | 409 | `_qb_usa_undeclared()` non-empty at execute; `details.gates[]` |
| `MAPPINGS_MISSING` | 409 | revenue `blocked` branch; `details.unmapped_{providers,facilities,payers}` |
| `QB_MAPPINGS_UNAVAILABLE` | 409 | Critic H-1, `DATABASE_BACKEND=postgres` only: a qb-revenue run whose QuickBooks revenue maps did not come from the org's own `qb_*_map` rows — the read raised (`run_state.error` says retry in a moment) or `qb_account_map` (revenue) / `qb_clinic_map` / `qb_provider_map` has no rows for the org (add them, then retry). The run is `blocked` (step `mapping_fix`, `retry` offered) **before any batch is opened**: nothing booked, no JE file, nothing published — never coded from the checked-in defaults (`src/qb_revenue_mappings.default_revenue_maps`), which Supabase/SQLite runs still fall back to. `details.qb_maps_source` is `"hardcoded"`; the run envelope's `qb_maps_source` says where a completed run's QuickBooks lines were coded from (`postgres` / `supabase` / `hardcoded`). **mx-payroll** (the same fix for payroll): a run whose QuickBooks payroll maps did not come from the org's own rows — the read raised, or `qb_account_map` has no `domain = 'payroll'` rows or `qb_department_map` none — stops while the configuration loads, before the file is read or a batch opened. The run is `blocked` (step `mapping_fix`, `retry` offered; Andres, 2026-09-25 — before that it was `failed`) with this code (`run_state.blocked_code`, the envelope's `error.code`, on both the worker and the thread path), `error.message` is the processor's sentence (`processor._MAPS_REFUSED`), `details.qb_maps_source` is `"hardcoded"`; nothing booked, `retry` once the maps are there. `MXPayrollRun.qb_maps_source` carries the source as on qb-revenue. **Critic R2-H1 (Postgres only): maps that exist but do not cover the file.** The maps must cover EVERY row the QuickBooks exporter indexes for THIS file, checked before anything books. qb-revenue reads and enriches the file before the batch is opened and runs the exporter's own builders over it (clinic and hospital tabs; every revenue account the posted JE carries, 43006 when the run makes unposted JEs, 18099; every clinic, class, catch-all provider code and payer label): one missing -> `blocked` as above, `details.reason` `"incomplete"`, `details.qb_maps_source` `"postgres"`, and one list of missing NetSuite values per mapping TABLE, flat in `details` (`qb_account_map`, `qb_department_map`, `qb_clinic_map`, `qb_other_code_map`, `qb_payer_label_map`, and `account_codes` for a payer type with no revenue account), e.g. `{"qb_maps_source": "postgres", "reason": "incomplete", "qb_clinic_map": ["Forest"]}`; no batch is opened. mx-payroll computes the journal lines before the roster sync or the batch and lists every account, class and location they carry: one missing -> `blocked` with this code, `details.reason` `"incomplete"` and the per-table lists (`qb_account_map`, `qb_department_map`, `qb_location_map`). A raw/test MX file whose org `mx_payroll_column_map` is empty or unreadable -> `blocked`, `details.reason` `column_map_empty` / `column_map_load_failed` (never the checked-in column map; the excel method does not read it). `details.reason` is also set for the H-1 cases (`empty`, `load_failed`). The QuickBooks export on Postgres is never swallowed: a failure there fails the run (`EXPORT_FAILED`), never a `completed` run with raw NetSuite values or no QuickBooks CSV. The unmapped values are account numbers, department / clinic names, payer types and service lines — never a person. **Also this code:** the provider P&L routes (`GET /config/pnl-providers`, `GET /config/pnl-preview`, the drivers template and the drivers upload) when the org's QuickBooks revenue maps are empty or unreadable on Postgres (`details.reason`), instead of the checked-in roster; and a qb-usa-payroll parse on Postgres whose `ts_benefit_override` read FAILED (`blocked`, `details.reason`, `retry` re-reads the uploads — instead of booking without the month's overrides; an org with no rows for the month is unchanged) |
| `ROSTER_EMPTY` | 409 | qb-usa-payroll: the org's roster tables hold nobody and no rule, so no one can be coded. The run is `blocked` (step `mapping_fix`, `details.reason` `"empty"`), nothing booked; load the roster, then `retry` (Andres, 2026-09-25) |
| `UNPOSTED_CONFIG_UNAVAILABLE` | 409 | Stage 2 F3, `DATABASE_BACKEND=postgres` only: a qb-revenue run that asked for unposted JEs (`generate_unposted` with bank deposits, and the org setting on) whose org clinic groups (`config_clinic_groups`, the whole `unposted_config` sheet since revision 0029: `locations`, `hospital_location`, `bank_account_key`, `primary_location_code`) could not be read (`details.reason` `load_failed`), do not exist (`empty`), or lack `locations` / `primary_location_code` on a group (`incomplete`, `details.missing` = `{field: [group]}`). The run is `blocked` (step `mapping_fix`, `retry` offered) **before any batch is opened**: nothing booked, no JE file — never booked with the unposted JEs silently skipped, which is what happened when the generator read a workbook that is not on the server. Supabase/SQLite runs still read the workbook sheet. A completed qb-revenue run says what became of its unposted JEs in `run_state.result_overview.unposted` (`produced`, `not_needed`, `unconfigured`, `failed`, `disabled`, `not_requested`); `not_needed` adds the artifacts warning `UNPOSTED_NOT_NEEDED`, `unconfigured` / `failed` add `UNPOSTED_NOT_PRODUCED`. Clinic group and field names only |
| `ARTIFACTS_NOT_READY` | 409 | `batch.status != 'completed'` |
| `IDEMPOTENCY_CONFLICT` | 409 | Same `Idempotency-Key`, different payload (`details.reason: "payload_mismatch"`), or the first request with that key is still being handled (`"in_progress"`, `retryable: true`). A key left `pending` by a request that died stops answering `in_progress` after 15 minutes (the database clock) and may be sent again. §3.2 |
| `RUN_STATE_CHANGED` | 409 | Phase 11 D4 wave, RDS only: the run changed between this request's state check and its start — another `execute`/`retry` started it a moment ago (with a different `Idempotency-Key`, or none), or a job is queued on it or holds its lease. The start is one compare-and-set (`process_runs.begin_action`): exactly one of two concurrent requests wins. `details`: `state` (as this request read it), `action`. Reload the run |
| `QBO_PUSH_REFUSED` | 409 / 503 | Critic Stage 1 H-3, RDS with qb-usa not routed to the worker: `POST …/quickbooks` runs the push in the request through the same idempotency ledger as the `qbo_push` job, and it could not start — nothing was sent. `details.reason` is the push's code (`QBO_NOT_CONNECTED`, `QBO_RECONNECT_REQUIRED`, `QBO_TRACKING_OFF`, `QBO_UNAVAILABLE`, `NO_JOURNALS`, `LEDGER_UNAVAILABLE`); 503 for `QBO_UNAVAILABLE` and `LEDGER_UNAVAILABLE`, else 409. Never QuickBooks' own wording. A push that started answers 200 `QuickbooksPushOut` with a code per failed journal (`QBO_IN_FLIGHT`: another attempt at that journal began less than the push lease ago; nothing was sent) |

**Roster (qb-usa-payroll)**

| Code | HTTP | Source |
|---|---|---|
| `ROSTER_ANSWER_INVALID` | 422 | `apply_answers` / `apply_alert_decision` `ValueError` — bad variant, bad alert field |
| `ROSTER_PERSIST_UNAVAILABLE` | 409 | `_sb()` raised: "Saving a roster change needs Supabase… The change can still be applied to this run only." `details.can_retry_as = {"persist": false}` |
| `ROSTER_MODULE_UNAVAILABLE` | 503 | `_qb_usa_roster()` is `None` and answers were submitted |

**Persistence / infrastructure**

| Code | HTTP | Source |
|---|---|---|
| `PERSISTENCE_UNAVAILABLE` | 503 | `_qb_usa_require_supabase` — Supabase or Storage fell back to local. `message` must keep saying **nothing was saved**. Also (Phase 11 D4, RDS): the job queue refused the run's job message — nothing was started; a create whose job could not be queued is left `failed` with this code. |
| `PROCESS_PAUSED` | 503 | Phase 11 D4, RDS only: `PROCESS_SUBMISSIONS_PAUSED` names this process (rollback step 1, `docs/reports/phase-11-plan.md` §5.2). Every submission — create, `execute`, `retry`, and qb-usa's `review` — is refused and nothing is started; reads, downloads and cancel keep working, runs already queued finish, and `/api/v2/processes` lists the process `enabled: false`. `details.process`; `retryable: true` |
| `RUN_RECORD_FAILED` | 500 | `import_batches` insert failed → nothing exported, nothing uploaded |
| `STORAGE_UPLOAD_FAILED` | 500 | `upload_output_file` raised after the batch row existed → batch marked `error` |
| `EXPORT_FAILED` | 500 | Any other worker exception; `details.batch_id` when one was allocated |
| `INTERNAL_ERROR` | 500 | Unhandled |

The distinction between `RUN_RECORD_FAILED` ("Nothing was saved") and `EXPORT_FAILED` with a `batch_id` ("Export failed **after** the run was recorded") is deliberate and already implemented — the SPA must surface these differently, because one leaves an `error` batch row an accountant will find later and the other does not.

---

## 5. The `blocked` state (unmapped providers / facilities / payers)

This is existing accounting behaviour and the single most important thing not to lose. Today: `RevenueProcessor.process_with_progress` finds any unmapped item, **deletes the batch**, and returns `blocked: True` with three dicts (web_app.py:849–866); `process_in_background` puts the job into `status: 'blocked'`; `templates/revenue/processing.html` renders inline add-mapping forms against `/api/config/add/*`; `/api/processing/{job}/retry` re-runs from `_retry_params`.

The invariant: **an unmapped item stops the run before any JE exists.** Booking the transactions you understand and dropping the rest produces a set of JEs that balances perfectly and is wrong. (The qb-usa `RunResult` docstring states the same principle for roster prompts.)

The same pause covers a qb-revenue run on Postgres whose org has no usable QuickBooks revenue maps (critic H-1): `blocked`, `error.code` `QB_MAPPINGS_UNAVAILABLE` (§4.2), no blockers list, `retry` once the `qb_*_map` rows exist or the database answers again. It stops the run before the batch is opened, so nothing is booked either. So does a Postgres org whose maps exist but miss an item this file's QuickBooks JEs index (critic R2-H1): the same pause, `details.reason` `"incomplete"` and the missing NetSuite values listed per mapping table in `details`; add them, then `retry`.

**Every process has this pause** (Andres, 2026-09-25): mx-payroll for its QuickBooks payroll maps and MX column map, qb-usa-payroll for its roster (`ROSTER_EMPTY`) and benefit overrides (`QB_MAPPINGS_UNAVAILABLE`) — see §2.2 for the list. The same `mapping_fix` screen, the same "Run it again" (`retry`), no blockers list: `error.code` / `error.details` say what to fix. A retry after the fix books the same bytes a first run would have (the golden tests: `tests/test_qb_maps_coverage_pg.py`, `tests/test_mx_payroll_maps_source_pg.py`, `tests/test_qb_usa_blocked_retry_pg.py`).

### v2 shape

`GET /api/v2/qb-revenue/runs/{id}` while blocked:

```jsonc
{ "run_id":"7c2…", "process":"qb-revenue", "state":"blocked", "step":"mapping_fix",
  "batch_id": null,
  "progress": { "step":"enriching", "message":"Unmapped items found - fix before processing", "percent":45 },
  "available_actions": ["retry", "cancel"],
  "error": { "code":"MAPPINGS_MISSING",
             "message":"Unmapped items found - add them to config before processing" },
  "blockers": [
    { "code":"UNMAPPED_PROVIDER", "severity":"block",
      "message":"3 billing providers have no department mapping.",
      "items":[
        {"key":"DOE, jordandoe","transaction_count":42,"amount":18422.10},
        {"key":"NGUYEN, tnguyen","transaction_count":7,"amount":2210.00},
        {"key":"PATEL, rpatel","transaction_count":1,"amount":180.00}],
      "resolve": { "method":"POST", "path":"/api/v2/config/providers",
                   "body_schema":"ProviderMappingCreate",
                   "fields":[
                     {"name":"provider_name","prefill_from":"key","readonly":true},
                     {"name":"department","enum_source":"/api/v2/config/departments","required":true},
                     {"name":"location_code","enum_source":"/api/v2/config/locations"}] } },
    { "code":"UNMAPPED_FACILITY", "severity":"block", "items":[…],
      "resolve": { "method":"POST", "path":"/api/v2/config/locations", … } },
    { "code":"UNMAPPED_PAYER", "severity":"block", "items":[…],
      "resolve": { "method":"POST", "path":"/api/v2/config/payers", … } }
  ] }
```

`resolve` is a self-describing form contract. `MappingFixScreen` renders the inline form generically from `resolve.fields` — it does not hardcode three different forms. Adding a fourth blocker type later needs no frontend change.

Loop: add mapping (`201` or `409 MAPPING_EXISTS`) → local optimistic removal from `blockers` → when `blockers` is empty, `retry` enables → `POST …/retry` → `202` and `state: running`.
`retry` on a non-blocked run: `409 RUN_STATE_INVALID`.

The retry params (`filepath`, `period`, `fiscal_year`, `je_date`, `generate_unposted`, `upload_id`, `bank_deposits`, `emit_qb`) move from the in-memory `_retry_params` into `process_runs.params` — they must survive a restart, since the whole point is that a human goes away and fixes config first.

`counts.blockers` also appears on `RunSummary` so the history list can show "3 unmapped" without fetching the run.

### Prerequisite that must not be skipped

`/api/config/add/*` (web_app.py:5692–5840) writes rows into **`config/mappings.xlsx` on local disk**, with `openpyxl.load_workbook` + `wb.save()`. That is:

1. **Not org-scoped at all** — one workbook shared by every tenant. Org A adding a provider changes Org B's department assignment. This is a live cross-tenant data problem, not a v2 concern.
2. **Not durable on Render** — an ephemeral filesystem loses the mapping on the next deploy, and the run blocks again.
3. **Not concurrency-safe** — read-modify-write on a whole workbook, no lock.
4. Contradicts the project's own rule that all configuration lives in Supabase.

**`/api/v2/config/*` writes must go to Supabase tables (`config_providers`, `config_locations`, `config_payers`, `config_departments`) with `org_id` + RLS, and the enrichment path must read from them.** Shipping the v2 blocked flow on top of the workbook would harden a bug into a contract.

---

## 6. CSRF and auth-failure semantics

> **Superseded by ADR 0021** (`docs/adr/0021-auth-cognito-sessions.md`), from Phase 4 onward. Double-submit CSRF is unchanged for cookie-authenticated requests; `Authorization: Bearer` requests are exempt, and two issuers are accepted at once until the Phase 10 cut-off.

### 6.1 CSRF

Keep global `CSRFProtect`. Do **not** `csrf.exempt` the v2 blueprint — these endpoints book journal entries, and the cookie is ambient.

- `GET /api/v2/csrf` returns `{token, expires_at}` and sets a **non-httpOnly** `XSRF-TOKEN` cookie. The token is not a secret from the page; it is a secret from other origins.
- Flask config: `WTF_CSRF_HEADERS = ['X-CSRFToken', 'X-CSRF-Token']`, `WTF_CSRF_TIME_LIMIT = None` (tie to session lifetime, so a 40-minute review screen doesn't fail on submit — a real risk in the roster flow).
- The generated client attaches `X-CSRFToken` from the cookie on every `POST/PUT/PATCH/DELETE`. Next.js server components never call `/api/v2` mutations.
- `@app.errorhandler(CSRFError)` → `403 CSRF_INVALID`, `retryable: true`. Client refetches `/api/v2/csrf` once and retries once, then surfaces the error.
- Multipart matters: `CSRFProtect` reads the header before the body, so a large upload is not buffered before rejection.
- Defence in depth: `SESSION_COOKIE_SAMESITE='Lax'` and the same on the Supabase auth cookies. Because Next.js rewrites make everything same-origin, `Lax` costs nothing.

### 6.2 The `Accept` header bug (`src/auth.py:334`)

```python
if request.is_json or request.headers.get('Accept') == 'application/json':
    return jsonify({'error': 'Authentication required'}), 401
return redirect(url_for('login', next=request.path))
```

Two independent failures, both hit by a SPA:

1. **Exact string equality.** Real clients send `Accept: application/json, text/plain, */*` (axios) or `*/*` (bare `fetch`). Neither equals `'application/json'`.
2. **`request.is_json` is content-type based** — false for every `GET`, and false for `multipart/form-data` uploads.

So today an expired token on a SPA request returns `302 → /login`, `fetch` follows it transparently, and the client receives **`200 OK` with a login HTML page**. `res.ok` is true. The SPA either renders HTML into a JSON slot or silently shows an empty screen. The identical bug is in `require_permission` (`src/auth.py:543`).

**Fix (must land before v2):**

```
_wants_json(request) := request.path.startswith('/api/')
                        or request.is_json
                        or 'application/json' in request.headers.get('Accept','')
                        or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
```

Path-first is the load-bearing clause: **anything under `/api/` never redirects**, regardless of headers. Apply to both decorators.

Response semantics:

| Situation | Status | Code | SPA behaviour |
|---|---|---|---|
| No/invalid access token, refresh succeeded | (request proceeds) | — | Transparent. `Set-Cookie` rides the response — the `make_response` path in `require_auth` must be preserved for JSON, including for `202` and `204`. |
| No valid token, refresh failed | 401 | `AUTH_REQUIRED` | Global interceptor → `router.push('/login?next=' + pathname)`. Never auto-retry. |
| Valid token, no org | 403 | `ORG_REQUIRED` | Route to org-selection/onboarding. |
| Valid token + org, permission denied | 403 | `PERMISSION_DENIED` | Render a denied panel in place. Never redirect to dashboard. |

Two behavioural changes the frontend depends on: `require_permission` currently **flashes and redirects to the dashboard**, which for a SPA is an unexplained navigation; and 401 must be distinguishable from 403, which the current shared `redirect(url_for('login'))` makes impossible.

Cookie refresh under concurrency: several parallel SPA requests can each attempt a refresh with the same rotated refresh token and race. Serialise refresh (single-flight per session) or the SPA will randomly log itself out.

---

## 7. File handling

### 7.1 Upload

- `POST /api/v2/{process}/runs`, `multipart/form-data`, `files[]` repeated + a JSON `params` part.
- **Classification is by content, not by which box the file came from.** No `adp_files` vs `benefit_files` split in v2 — the SPA has one dropzone; the server sorts. This already works (`identify_csv(read_rows(staged), original)`); v2 just stops pretending the field name means anything.
- Each part is streamed to a per-run temp dir, read, classified, then renamed to the canonical name the processor expects (`invoice_{pay_date}_{entity}.csv`, `benefits_1_unum.csv`, `benefits_2_bcbs.csv`). Registers keep their name — a register carries no pay date inside it, so `register_YYYY-MM-DD.csv` is load-bearing.
- **Failure is atomic**: if any `problems` accumulate, the whole run directory is removed and `422` returned with every problem at once (today's behaviour — `shutil.rmtree` then a single flash). Never a half-accepted upload.
- Response echoes the manifest so the UI can show what it decided:

```jsonc
"inputs": {
  "classified": [
    { "uploaded_as":"PR_Register_07152026.csv", "stored_as":"register_2026-07-15.csv",
      "kind":"register", "pay_date":"2026-07-15" },
    { "uploaded_as":"ADPINV_772913.csv", "stored_as":"invoice_2026-07-15_HW3.csv",
      "kind":"invoice", "pay_date":"2026-07-15", "entity":"HW3" },
    { "uploaded_as":"unum_july.csv", "stored_as":"benefits_1_unum.csv", "kind":"unum" },
    { "uploaded_as":"bcbs 7-2026.csv", "stored_as":"benefits_2_bcbs.csv", "kind":"bcbs" }
  ],
  "rejected": [],
  "derived": { "accrual_days": 3, "accrual_days_source": "register_filenames" }
}
```

`accrual_days_source` ∈ `register_filenames | pay_calendar | user_override` — the server re-derives from the **saved** files and only honours the typed value when it differs from what the page prefilled.

Inputs are uploaded to the `uploads` bucket under `{org_id}/{run_id}/input/` rather than left on the web server's disk, so a retry or a different worker can reach them.

### 7.2 Download — signed URLs

`src/storage.py:79` already has `get_signed_url(bucket, path, expires_in=3600)` and **no download route uses it**. Today's routes stream bytes through Flask (`download_all_outputs_as_zip` even re-downloads and re-zips every file on every click). v2 stops proxying:

```
POST /api/v2/qb-usa-payroll/runs/{run_id}/artifacts/{artifact_id}/download-url
→ 201
{ "url": "https://…supabase.co/storage/v1/object/sign/outputs/…?token=…",
  "expires_at": "2026-08-23T14:04:11Z",
  "expires_in": 120,
  "filename": "JE_QBUSA_HW3_smh_salaried_main_P07_FY26.csv",
  "content_type": "text/csv",
  "size_bytes": 18422 }
```

**TTL policy** — a signed URL bypasses RLS entirely; anyone holding it is authenticated. These files contain employee names and salary amounts.

| Artifact | TTL | Why |
|---|---|---|
| Single CSV / workbook | **120 s** | Minted on click, consumed immediately. Long enough for a slow network, short enough that a URL in a chat message is dead. |
| ZIP bundle | **300 s** | Building + uploading the ZIP happens first. |
| Input file re-download (audit) | **120 s** | Same class. |

Never the 3600 s default. `expires_in` is returned so the client can grey out a stale button rather than sending the user to an expired link.

ZIP bundles are built once, stored at `{org_id}/{batch_id}/bundle/{name}.zip`, recorded as an artifact, and re-signed on later clicks. Rebuild only when an artifact list changes.

**Preconditions on every mint**, re-evaluated against Postgres and never against a cached session:
1. `require_permission(process, 'results')`.
2. The run's `org_id` equals `g.org['org_id']`.
3. `batch.status == 'completed'` — a batch not completed must never offer a download.
4. For qb-usa: no undeclared failed gates recorded on `qb_usa_payroll_gate`. This is the financial control; it must survive a server restart, which is exactly why it is a DB check.

**Audit** — one row per mint, in a new `artifact_downloads` table:

```
id, org_id, run_id, batch_id, artifact_id, artifact_name,
user_id, user_email, ip, user_agent, expires_at, created_at
```

Minted, not fetched — the actual GET goes to Supabase and Flask never sees it. That is the honest thing to record, and the log should say "issued a download link", not "downloaded". Retain ≥ 7 years alongside the JE record. Surface it read-only at `GET /api/v2/{process}/runs/{id}/downloads` for `results` holders.

---

## 8. Multi-tenancy

Four layers, all required. Any one alone has a hole.

1. **Decorator.** `@require_org` sets `g.org`. No v2 route omits it (only `/api/v2/health`). `_auth_disabled()` bypass stays gated on `FLASK_ENV=development` and must never bypass `require_org` in a way that leaves `g.org` unset — v2 handlers should fail closed (`ORG_REQUIRED`) rather than query with `org_id=None`.

2. **Every query is org-filtered explicitly**, as defence in depth even where RLS applies — this is already the house style (`_qb_usa_load_from_db` does `.eq('id', batch_id).eq('org_id', org_id).eq('batch_type', …)`). No v2 handler may look a run up by id alone.

3. **RLS.** `process_runs` and `artifact_downloads` get the same `org_id = user_org_id()` policy as migrations 019/020/021. Note that service-key access bypasses RLS, so layer 2 is what actually protects reads today; RLS is the backstop.

4. **Storage prefixes.** Every path is `{org_id}/{batch_id}/{subfolder}/{file}`. Before signing, the handler asserts the path's first segment equals `g.org['org_id']`. A signed URL bypasses RLS, so this check is the only thing standing between a path-manipulation bug and cross-tenant salary data.

**Cross-org access returns `404 RUN_NOT_FOUND`, never `403`** — a 403 confirms the run exists.

Two existing scoping holes to close as part of v2:

- **`config/mappings.xlsx` has no `org_id` concept whatsoever** (§5). Every provider/location/payer/department mapping is global. Because departments drive JE coding, this is a cross-tenant correctness bug, not just an isolation bug.
- **`_RUN_OVERRIDES` is org-keyed but process-local** (`src/qb_usa_payroll_roster.py:142`). Correct on one worker; with `gunicorn -w 4`, run-only roster answers are invisible to whichever worker runs the export, and the run books with the wrong coding. Moving them into `process_runs.run_state` fixes the tenancy and the correctness problem at once, and keeps the "must not outlive the booking session" contract (clear on terminal state, plus a TTL sweep).

`GET /api/v2/me` never returns another org's data, and the org cannot be selected by request parameter — it comes from the membership row, as it does now.

---

## 9. Rate limiting

Two changes to how limits are keyed, before per-endpoint numbers matter:

1. **`get_remote_address` is wrong behind the Next.js rewrite proxy.** Every request arrives from the Next.js server's IP, so all users share one bucket — one accountant uploading trips the limit for the whole firm. Key on `f"{g.org['org_id']}:{g.user['id']}"` with an IP fallback for unauthenticated routes, and put `ProxyFix` in front with a trusted-proxy count so `X-Forwarded-For` is usable where IP is still wanted.
2. **`storage_uri="memory://"` is per-process.** With N workers the effective limit is N×. Move to Redis, or accept and document the multiplier.

| Class | Endpoints | Limit | Rationale |
|---|---|---|---|
| Public | `/api/v2/health` | `60/minute` per IP | Monitoring |
| Session | `/api/v2/me`, `/api/v2/csrf` | `120/minute` per user | Called on every SPA mount |
| Read | `GET` runs list/detail, config reads, artifacts list | `120/minute` per user | Cheap, cached |
| Poll | `GET …/runs/{id}` while `running`, `…/events` | `240/minute` per user; max **2** concurrent SSE streams per user | A 2 s poll is 30/min per tab; allows several tabs without opening a DoS |
| Create (upload) | `POST …/runs` | `10/minute`, `60/hour` per user | Matches today's `@limiter.limit("10/minute")`; the hourly cap is new and bounds storage |
| Mutation | `POST …/review`, `…/declarations` | `30/minute` per user | Matches today's review limit |
| Execute | `POST …/execute`, `…/retry` | `10/minute`, `40/hour` per user | Each one books journal entries |
| Download mint | `POST …/download-url`, `…/bundle` | `30/minute`, `200/hour` per user | Each mint creates a bearer URL and an audit row |
| Config write | `POST /api/v2/config/*` | `30/minute` per user | Unblocking a run legitimately means several in a row |

`429` returns the §4 envelope plus `Retry-After`. The generated client retries only `RATE_LIMITED` and `CSRF_INVALID`, once, with jitter — never `execute`, which is not idempotent without an `Idempotency-Key`.

---

## 10. OpenAPI + TypeScript toolchain

### 10.1 Where pydantic fits — and where it must not

```
HTTP ─▶ [pydantic request model] ─▶ plain dict/dataclass ─▶ existing src/* processors
                                                                    │
HTTP ◀─ [pydantic response model] ◀── adapter ◀────────── dataclasses (RunResult,
                                                            GateResult, PersonPrompt…)
```

**Pydantic lives at the HTTP edge only, in `src/api/v2/schemas/`.** It does not enter `src/qb_usa_payroll_processor.py`, `src/qb_usa_payroll_roster.py`, or any other processor. Those use plain dataclasses, are unit-tested against a P07 oracle, and run offline from CLI scripts; making them depend on a web framework's validation library would be exactly the over-engineering the codebase has been pruning. The bridge is a thin `to_response(run_result) -> RunEnvelope` adapter per process.

Three jobs, and only three:

1. **Request validation** — replaces the hand-rolled `int(request.form.get(...))` / `try: … except ValueError: flash(...)` blocks. The 0–14 accrual bound, the 1–12 period bound, the `variant ∈ VALID_VARIANTS` check, `Literal` enums for `entity`/`variant`. Validation errors map to `422` with `field_errors` derived from `ValidationError.errors()`.
2. **Response serialisation** — `model_dump(mode='json')` gives stable `Decimal`→string/float and `date`→ISO handling. Money fields are `Decimal` with `json_encoders` to a 2-dp string, so `412300.55` never becomes `412300.5500000001` in a JE total.
3. **Schema source** — `model_json_schema()` is what generates OpenAPI, which generates the TypeScript. One definition, three artefacts.

Discriminated unions carry the per-process differences:

```python
RunEnvelope = Annotated[
    Union[QBRevenueRun, MXPayrollRun, QBUSAPayrollRun],
    Field(discriminator="process"),
]
Blocker = Annotated[
    Union[
        UnmappedProviderBlocker,
        UnmappedFacilityBlocker,
        UnmappedPayerBlocker,
        UndeclaredGatesBlocker,
    ],
    Field(discriminator="code"),
]
```

These become TypeScript discriminated unions, so `if (run.process === 'qb-usa-payroll')` narrows to a type that actually has `gates`. That is the single biggest day-to-day payoff of the whole toolchain.

### 10.2 Pipeline

```
src/api/v2/schemas/*.py   (pydantic v2)
        │  spectree/flask-pydantic-spec decorates each v2 view
        ▼
scripts/generate_openapi.py  →  openapi/meridian-v2.json     (checked in)
        │  npx openapi-typescript
        ▼
web/src/lib/api/schema.d.ts                                  (checked in, generated)
        │  openapi-fetch
        ▼
web/src/lib/api/client.ts   →  typed createClient<paths>()
```

- **New dependencies** (need approval per project rules): `pydantic>=2.6` and one of `spectree` / `flask-pydantic-spec`. If a new Flask dependency is unwanted, `scripts/generate_openapi.py` can walk a hand-maintained `ROUTES` registry of `(rule, method, request_model, response_model, permission)` tuples and emit the same document from `model_json_schema()` with no runtime dependency beyond pydantic. That is the lighter option and probably the right one for a three-process API.
- **`openapi-typescript` + `openapi-fetch`** on the Next.js side. No axios, no hand-written types, no runtime codegen. `openapi-fetch` is ~2 KB and gives full path/method/body/response inference from `schema.d.ts`.
- **CI gate:** regenerate both artefacts and `git diff --exit-code`. A Flask handler whose response shape drifts from the checked-in TypeScript fails the build. This is the mechanism that keeps the contract honest once both sides move independently.
- **Runtime response validation in dev only** — validating every response in production doubles serialisation cost for money-sized payloads. Enable under `FLASK_ENV=development` and in tests.
- **Contract tests:** for each of the ~30 endpoints, one test asserting the real response validates against its declared model. Cheaper than an integration suite and catches exactly the drift that breaks the SPA.
- **`mcp__supabase__generate_typescript_types`** already exists for DB row types. Keep those separate from API types: DB types are internal, API types are the contract. Do not let a Supabase column rename silently become an API break.

---

## 11. Pagination and filtering for run history

`GET /api/v2/{process}/runs` — replaces v1's hard `LIMIT 20` (and the index page's `LIMIT 10`).

**Keyset (cursor) pagination**, not offset. `import_batches` already carries `idx_import_batches_qb_usa_payroll ON (org_id, fiscal_year, period, created_at DESC)`; `process_runs` gets `(org_id, process, created_at DESC, run_id DESC)`. Keyset is stable while new runs are being created — offset paging would show the same run twice, and a run history that duplicates a booking is worse than useless.

**Query parameters**

| Param | Type | Default | Notes |
|---|---|---|---|
| `limit` | int 1–100 | 25 | |
| `cursor` | opaque | — | base64 of `{created_at, run_id}`; `IDEMPOTENCY`-style opaque, never parsed client-side |
| `state` | csv of states | all | `?state=completed,superseded` |
| `fiscal_year` | int | — | |
| `period` | int 1–12 | — | |
| `created_by` | uuid \| `me` | — | |
| `from` / `to` | date | — | on `created_at` |
| `has_declared_gates` | bool | — | qb-usa only; the audit question "which periods were booked with a known discrepancy" |
| `q` | string | — | prefix match on input filename |
| `sort` | `created_at` \| `period` | `created_at` | always `desc` |

Unsupported filter on a process (e.g. `has_declared_gates` on `qb-revenue`) → `422 VALIDATION_ERROR` naming the parameter, rather than silently ignoring it.

**Response**

```jsonc
{ "data": [
    { "run_id":"3f1a…", "state":"completed", "step":"results",
      "period":7, "fiscal_year":2026, "batch_id":1421,
      "input_file":"register_2026-07-15.csv, register_2026-07-31.csv, …",
      "record_count":9, "total_amount":"1284920.44",
      "counts": { "journals":9, "gates":6, "gates_failed":2, "gates_declared":2, "blockers":0 },
      "created_by": { "id":"…","email":"controller@…" },
      "created_at":"2026-08-01T09:12:00Z", "processed_at":"2026-08-01T09:13:41Z" }
  ],
  "page": { "next_cursor":"eyJjcmVhdGVkX2F0IjoiMjAyNi0wOC0w…", "has_more":true, "limit":25 },
  "meta": { "total_estimate": 214 } }
```

`total_estimate` is an estimate (`reltuples`-style or a capped count), and is labelled as one. An exact `COUNT(*)` on every page load of a growing audit table is not worth it, and a UI that promises an exact number then shows a different one is worse than a UI that says "214+".

`gates_declared > 0` should render a visible badge in the list. Migration 021 exists precisely to answer "why did this go to QuickBooks with a known discrepancy" — the history list is where that question gets asked.

---

## 12. Where the uniform runs model does **not** fit

Honest list. Each item says what to do instead.

### 12.1 Two of the three processes have no human step at all

`qb-revenue` and `mx-payroll` are one-shot: `POST` → thread → poll → results. They never enter `needs_input`. Only `qb-usa-payroll` has `roster_review` and `preview`. All three can pause in `blocked` and be retried (§2.2; mx-payroll since 2026-09-25).

**Do:** keep one state machine, but make `review`/`preview`/`declarations` **optional sub-resources advertised in `links` and `available_actions`**, returning `404` where they don't exist. The SPA reads `available_actions`; it never assumes a wizard has three steps. Do **not** invent a no-op review step for the other two just to make the diagram symmetrical — an empty confirmation screen between "upload" and "processing" is a worse product.

### 12.2 `blocked` is reached from `running`, not before it

The revenue blocker is discovered *during* enrichment (45% progress), not at upload. So `blocked` is not a pre-execution review state — it is a mid-run pause. And qb-usa's equivalent (roster prompts) *is* pre-execution.

**Do:** allow `running → blocked → running`. Keep `blockers[]` as a shared vocabulary across both, but accept that they occupy different points in the lifecycle. This is why `step: "mapping_fix"` is reachable from `blocked` and `step: "roster_review"` is reachable from `needs_input`.

### 12.3 `run_id` and `batch_id` are not the same thing, and never line up

- qb-usa: a `session_id` UUID at upload; `batch_id` only allocated inside the worker at export; the results page is addressed by `batch_id`, and the code aliases the session dict under the batch id to paper over the switch.
- qb-revenue / mx-payroll: `batch_id` is created inside `process_in_background`; the job is addressed by `job_id` until then.

**Do:** `run_id` is server-issued at create and never changes. `batch_id` is a **nullable attribute** of the run, not its identity. Every SPA URL uses `run_id`. Keep `GET /api/v2/{process}/runs?batch_id=N` for links from existing Jinja pages and any external bookmark during the migration.

### 12.4 `params` cannot be uniform

qb-revenue takes `bank_deposits` keyed by 11 clinic groups, `generate_unposted`, `je_date`, and `'auto'` sentinels for period/fiscal year. qb-usa takes `period`, `year`, `accrual_days`, `accrual_days_prefill`. mx-payroll takes nothing.

**Do:** `params` is a discriminated union on `process`, not a shared object. Uniformity applies to the *envelope*, not the payload. Trying to unify `bank_deposits` and `accrual_days` under a generic `options: Record<string, unknown>` would throw away the typing that is the whole reason to generate TypeScript.

### 12.5 `period` / `fiscal_year` are unknown at create for two processes

qb-usa requires them up front. qb-revenue accepts `'auto'` and derives them from the fiscal calendar. mx-payroll parses them out of the sheet name or the title row and **fails the whole run** if it cannot (`PERIOD_UNDETECTABLE`).

**Do:** `period` and `fiscal_year` are nullable on the envelope until `state` reaches `needs_input`/`running`. The history list must render "—" for a run that failed before period detection. Do not force a period into the create request for processes that legitimately don't know it.

### 12.6 qb-usa can have prompts with *no* result at all

`process_qb_usa_payroll` may **raise**, with `prompts`/`alerts` hung off the exception (`_qb_usa_run` recovers them via `getattr` on `exc` and `exc.resolution`). So "parsing succeeded" and "the run has journal entries" are different facts, and a run can sit in `needs_input` with zero journals and zero gates. This is deliberate — `RunResult`'s docstring: booking the people we understand and dropping the rest produces JEs that balance perfectly and are wrong.

**Do:** `counts.journals` and `counts.gates` are `0`, and the envelope carries an explicit `has_result: false`. `GET …/preview` returns `409 ROSTER_PROMPTS_OUTSTANDING`, never an empty-but-successful preview. The client must not treat "200 with an empty journal list" as a valid preview — that is precisely the misreading that would book a partial payroll.

### 12.7 Artifacts are only in Supabase Storage for one of the three

qb-usa uploads every output to the `outputs` bucket under `{org_id}/{batch_id}/…` and records `storage_path` per journal. qb-revenue and mx-payroll write to local `OUTPUT_FOLDER` and their results/download routes `glob()` the filesystem (`JE_Revenue_*_{period}_{year}_QB.csv`, `JE_Payroll_*_QB.csv`).

**Do:** the uniform `/artifacts` + signed-URL contract **requires migrating those two to Supabase Storage first.** Until then their artifacts endpoint would have to stream bytes through Flask, which means two different download contracts behind one URL shape — the worst of both. Sequence the work: storage migration, then v2 artifacts. On Render's ephemeral disk those globs already lose files across deploys, so this is a pre-existing bug the SPA would merely make visible.

Second-order: the revenue results page computes its tie-out (`balanced` per `*JournalNo`, `unmapped_total` from bare-number `*AccountName`) by **re-parsing the CSVs with pandas on every page view**. That belongs in the worker at export time, persisted alongside the batch, not recomputed in a request handler. Otherwise `GET …/artifacts` gets slower with every JE and depends on files that may not be local.

### 12.8 `retry` is the way out of `blocked`, for every process

**Superseded 2026-09-25 (Andres: "every process blocks and gives an error code, and can be re-run").** It used to exist for qb-revenue only. Now all three manifests declare a `retry` job from `blocked` and `supports_retry`, and `POST …/runs/{id}/retry` is served for each: qb-revenue and mx-payroll re-run the export from `process_runs.params` and the recorded upload; qb-usa re-reads its recorded uploads (the parse, `JobSpec.working_state = "parsing"`) and lands on the review or the preview — `file_hash = session_id` is unchanged, a NEW run is still a new batch. `retry` is advertised in `available_actions` only from `blocked`; anywhere else it is `409 RUN_STATE_INVALID`. Re-parsing with different roster answers is still `POST …/review`: `retry` is not offered from `needs_input`.

### 12.9 Idempotency semantics contradict each other

Revenue hashes the input file (`hashlib.md5`) and has a `--force` reprocess concept. qb-usa sets `file_hash = session_id`, so every run of the same period is a new batch by design.

**Do:** standardise on an `Idempotency-Key` request header on `POST …/runs` and `POST …/execute`. Content-hash dedupe becomes a **warning**, not a block: `warnings: [{code: "DUPLICATE_INPUT", previous_run_id: "…"}]`, which the SPA shows as "you booked this file on Aug 1 — continue?". Silently refusing a rerun and silently allowing one are both wrong; showing the prior run and asking is right.

**Built (Phase 11 E3, RDS only).** The header on `execute`/`retry` is described in §3.2. The warning's
shape is the envelope's `Warning`: `{code: "DUPLICATE_INPUT", message, details: {previous_run_id,
previous_run_on}}` (the id sits in `details`, because `warnings[]` items are `{code, message, details}`).
"The same input" is the multiset of sha256s recorded in `inputs.object_versions` (Phase 11 C1), compared
through revision 0018's `app.input_digest`; "before" means the newest earlier run of the same org and
process in `running`, `blocked`, `completed` or `superseded`. It is added when the input is executed — at
create for qb-revenue and mx-payroll (create is execute, §12.1), at `execute` for qb-usa-payroll — and is
stored in `run_state.warnings`, so every later poll shows it. A lookup that fails adds nothing and blocks
nothing.

### 12.10 `superseded` is defined but never set

Migration 021 added `'superseded'` to `import_batches.status` explicitly so a re-run doesn't orphan the prior run's row — and nothing sets it.

**Do:** on `completed`, mark any earlier `completed` run for the same `(org_id, process, fiscal_year, period)` as `superseded`, on both `process_runs` and `import_batches`, and link forward via `superseded_by_run_id`. Without this, the run history shows two completed bookings of P07 and no indication which one went to QuickBooks — the exact ambiguity the migration was written to prevent.

### 12.11 Permission level splits *within* a single wizard

`qb_usa_payroll_review`/`preview`/`process` need `payroll:access`; `results`/`download` need `payroll:results`. A user can therefore run a booking and then be unable to see or download what they produced.

**Do:** keep the split (it's deliberate), but make it visible: the run envelope carries `viewer: { can_execute: true, can_view_results: false }` so the SPA warns *before* the upload rather than showing a 403 after the money has been booked. This is a product bug the current Jinja flow also has, and v2 is the moment to surface it.

---

## 13. Migration sequencing

Ordered by dependency; each step is shippable behind the existing Jinja UI.

1. **Fix `_wants_json` in `require_auth` + `require_permission`** (§6.2). Standalone, low risk, unblocks everything.
2. **Move config mappings from `config/mappings.xlsx` to org-scoped Supabase tables** (§5). Correctness and tenancy fix; the blocked flow depends on it.
3. **Migration 022: `process_runs` + `artifact_downloads`;** move `_RUN_OVERRIDES` and the four in-memory job dicts into it (§1.1, §8).
4. **Migrate qb-revenue and mx-payroll outputs to Supabase Storage** (§12.7); persist the tie-out at export time.
5. **`src/api/v2/` blueprint + pydantic schemas;** cross-cutting endpoints first (`/me`, `/processes`, `/csrf`, config reads).
6. **`qb-usa-payroll` runs resource** — richest, so it validates the contract. Rename `qb_payroll` → `mx-payroll` in the same pass.
7. **OpenAPI + TS generation + CI drift gate** (§10).
8. **Next.js wizard screens**, one process at a time; Jinja routes stay live until each is replaced.
9. **Signed-URL downloads + audit** (§7.2); retire the byte-streaming routes.
10. Set `superseded` (§12.10); add the `has_declared_gates` history filter (§11).
