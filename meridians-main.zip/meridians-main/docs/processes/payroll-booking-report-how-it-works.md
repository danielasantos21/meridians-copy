# Payroll Booking Report — How It Works

**File:** `MASO TEST/SM - P02-2026 Payroll Booking Report (0201-0220) v5.xlsx`

---

## Overview

The workbook consolidates two ADP pay periods (e.g. 02/06 and 02/20) into structured journal entries ready for NetSuite upload. All source data is ADP exports — pasted in as raw values.

---

## Sheet Inventory

| Sheet | Type | Purpose |
|-------|------|---------|
| `Detail Mapping` | Static reference | Lookup table for Insperity upload — companies, locations, departments. All manually entered, no formulas. |
| `Employee Master` | Dynamic hub | 256 employees — core data (name, location, dept, subsidiary) + XLOOKUP enrichment from Detail sheet |
| `02.06.2026 Detail` / `02.20.2026 Detail` | ADP raw export | 111 employees × 63 columns — earnings, deductions, taxes. Header row 5, data row 6+. |
| `02.06.2026 Health Inv` / `02.20.2026 Health Inv` | ADP raw export | Health company (HW3) invoice — gross, service fees, payroll taxes, benefit deductions per employee |
| `02.06.2026 MSO Inv` / `02.20.2026 MSO Inv` | ADP raw export | LLC company invoice — same structure as Health Inv |
| `SM Health Benefits` | ADP raw export | ~450 rows — one row per employee × benefit plan (medical/dental/vision/life/LTD/STD) with TOTAL/EMPLOYER/EMPLOYEE costs |
| `PV Benefit` | Pivot table | Aggregates SM Health Benefits into one row per employee (Sum of TOTAL COST). Two side-by-side pivots: HW3 (Health) and DJ8 (LLC). |
| `02.06 SMH - Salaried` / `02.20 SMH - Salaried` | JE output | Final NetSuite journal entries — Health Inc salaried employees |
| `02.06 SMLLC - Salaried` / `02.20 SMLLC - Salaried` | JE output | Final NetSuite journal entries — LLC salaried employees |
| `02.06 SMLLC - hourly and sal` / `02.20 SMLLC - hourly` | JE output | Final NetSuite journal entries — LLC hourly employees |
| `03.14 SMH - Bonus` / `03.14 SMLLC - Bonus` | JE output | Bonus period journal entries |

---

## Data Flow

```
ADP Detail Export  ──────────────────────────────────────────┐
                                                              ↓ XLOOKUP
ADP Health Invoice (left cols A–AF, raw) ──→ Health Inv right side (AH–BJ)
                                              ↑ XLOOKUP
ADP MSO Invoice   (left cols A–AF, raw) ───→ MSO Inv right side (AH–BJ)
                                              ↑ XLOOKUP
                                         Employee Master (I, J, W, X cols)
ADP Benefits Export ──→ SM Health Benefits ──→ PV Benefit (pivot refresh)
                                              ↑ VLOOKUP (col AX)
                                                    ↓ copy-paste values
                                         Salaried Output Sheets (A–R)
                                                    ↓
                                         NetSuite JE Upload
```

---

## Step-by-Step Manual Process Each Pay Period

### Step 1 — Paste ADP exports (raw values, no formulas)

- **Detail sheet**: Full ADP payroll export. 111 employees, headers on row 5.
- **Health Inv sheet** (left side A–AF): ADP Health company invoice — gross pay, service fees, payroll taxes, benefit deductions.
- **MSO Inv sheet** (left side A–AF): ADP LLC invoice — same structure.
- **SM Health Benefits**: ADP benefits carrier data — one row per employee × plan.

### Step 2 — Refresh PV Benefit pivot tables

The `PV Benefit` sheet has two side-by-side pivot tables sourced from `SM Health Benefits`:

| Pivot | Rows | Employees |
|-------|------|-----------|
| Left (cols A–E) | 4–33 | HW3 = Health Inc |
| Right (cols H–L) | 50–117 | DJ8 = LLC |

Columns: `NAME | EMPLOYEE ID | DEPT CODE | DEPT DESCRIPTION | Sum of TOTAL COST`

After refreshing, each employee has one row with their **total benefit cost** (all plans summed).

### Step 3 — Health/MSO Invoice right side auto-calculates

The right side of each invoice sheet (cols AH–BJ) uses formulas to enrich the raw data:

| Col | Formula | Source |
|-----|---------|--------|
| AM | `XLOOKUP(name → Employee Master!U → col W)` | Location |
| AN | `XLOOKUP(name → Employee Master!U → col X)` | Department |
| AO | `XLOOKUP(name → Detail!B → Detail!M)` | Salary amount |
| AP | `XLOOKUP(name → Detail!B → Detail!O)` | Overtime |
| AQ | `XLOOKUP(name → Detail!B → Detail!W)` | PTO |
| AR | `XLOOKUP(name → Detail!B → Detail!U)` | Variable Comp |
| AS | `XLOOKUP(name → Detail!B → Detail!S)` | ER Earnings |
| AT | `XLOOKUP(name → Detail!B → Detail!T)` | EDU Stipend |
| AU | `= SS + Medicare + FUTA + SUI` | Payroll taxes (from invoice left) |
| **AX** | **`VLOOKUP(name → PV Benefit col L or E)`** | **Total benefits cost from pivot** |
| AY | `= Medical + Dental + Vision deductions` | Benefits adjustments (from invoice left) |
| AZ | `0` (hardcoded) | Co-Emp Risk — currently unused |
| BA | `= J` (Service Fee Amount) | PEO Fees |
| BB | `= Z` (401k Match) | Safe Harbor match |
| BJ | `= BI + AX` | Grand Total (subtotal + benefits) |

**Health Inv** VLOOKUPs PV Benefit range `H4:L33` (Health Inc employees).
**MSO Inv** VLOOKUPs PV Benefit range `H50:L117` (LLC employees).

### Step 4 — Copy values into Salaried output sheets

The salaried sheets (`02.06 SMH - Salaried`, etc.) have:

- **Display cols A–R**: What gets uploaded to NetSuite
- **Hidden cols S–CO**: Source data pasted from invoice sheets

| Display Col | Value source |
|-------------|-------------|
| A (Date) | `=AQ8` — formula referencing hidden pay date col |
| B (Subsidiary) | Hardcoded static text |
| C (Location) | `XLOOKUP(name → Employee Master → Location)` |
| D (Department) | `XLOOKUP(name → Employee Master → Department)` |
| E–G (Salary/OT/PTO) | **Copy-pasted values** from invoice AO/AP/AQ |
| H (Bonus) | Copy-pasted |
| I (Payroll Taxes) | Copy-pasted |
| J (W/C & EPLI) | `=BR8` formula from hidden col |
| K (Benefits) | Copy-pasted |
| L (Co-Emp Risk) | `=BY8` formula from hidden col |
| M (PEO Fees) | Copy-pasted |
| N (401k Safe Harbor) | Copy-pasted |
| O (Regular Pay) | Copy-pasted |
| R (Total) | `=SUM(E8:Q8)` |

---

## Employee Master — Key Structure

| Col | Content | Formula |
|-----|---------|---------|
| A | Employee ID | Manual |
| C | Name | Manual |
| H | Subsidiary | Manual |
| I | Location | Manual |
| J | Department | Manual |
| M–O | Validation (Subsidiary/Loc/Dept) | `VLOOKUP` from external `[1]Employee Master Dec2025` file |
| Q–S | Match checks | `=H4=M4`, `=I4=N4`, `=J4=O4` (TRUE/FALSE validation) |
| U | Payroll Name | Manual — used as XLOOKUP key by 02.20 sheets |
| AA–AD | Cost codes from ADP | `XLOOKUP(name → Detail col B → Detail col D/E/F/G)` |

The 02.06 sheets look up by Employee Master col C (Name).
The 02.20 sheets look up by Employee Master col U (Payroll Name).

---

## Detail Sheet — Key Columns

Headers on row 5, data from row 6. 111 employees, 63 columns (A–BK).

| Col | Name | Used by |
|-----|------|---------|
| B | Payroll Name | XLOOKUP key in Health/MSO Inv |
| M | Regular Earnings Total | → Invoice AO (Salary) |
| O | Overtime Earnings Total | → Invoice AP |
| W | P_PTO_Earnings | → Invoice AQ |
| U | EV_Variable Comp_Earnings | → Invoice AR |
| S | ER_Earnings | → Invoice AS |
| T | ES_EDU Stipend_Earnings | → Invoice AT |
| R | EC_Car Allowance_Earnings | → Invoice BC |
| AZ | G_Eligible Comp_Memo | ADP 401k memo field (not from pivot) |
| BA | K1_Eligible Earns_Memo | ADP 401k memo field (not from pivot) |
| BF | Medicare - Employee Tax | Per-period tax |
| BG | Social Security - Employee Tax | Per-period tax |
| BH | FUTA Amount | Per-period |
| BI | Medicare Amount | **YTD cumulative — do NOT use for JEs** |
| BJ | Social Security Amount | **YTD cumulative — do NOT use for JEs** |
| BK | SUI Amount | Per-period |

> **Note:** Columns AZ and BA in the Detail sheet (`G_Eligible Comp_Memo` / `K1_Eligible Earns_Memo`) are ADP-native memo fields for 401k eligible compensation. They come directly from ADP — they are not derived from any pivot table.

---

## Subsidiary Variants

| ADP Code | Subsidiary | Booking Sheet |
|----------|-----------|---------------|
| HW3 | STELLA MATTINA HEALTH, INC. | SMH sheets |
| DJ8 | STELLA MATTINA, LLC (Salaried) | SMLLC Salaried sheets |
| — | STELLA MATTINA, LLC (Hourly) | SMLLC Hourly sheets |
