# NetSuite MCP Integration — Admin Setup Guide

This guide covers everything a NetSuite admin needs to do to enable automated Journal Entry posting from Meridian into NetSuite via the MCP API.

---

## Overview

We are connecting Meridian (our revenue automation system) to NetSuite so that Journal Entries are posted automatically instead of being imported manually via CSV. This uses Oracle's official **MCP Standard Tools SuiteApp** and OAuth 2.0 authentication.

---

## Step 1 — Install the MCP Standard Tools SuiteApp

1. Log into NetSuite as Administrator
2. Go to **Customization > SuiteBundler > Search & Install Bundles**
3. Search for: `MCP Standard Tools`
4. Click **Install**
5. Accept the terms and complete installation

> **Reference**: [Oracle Docs — MCP Standard Tools SuiteApp](https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/article_143403258.html)

---

## Step 2 — Create a Dedicated Integration Record (OAuth 2.0)

This generates the Client ID our application will use to authenticate.

1. Go to **Setup > Integration > Manage Integrations > New**
2. Fill in:
   - **Name**: `Meridian MCP Integration`
   - **State**: Enabled
   - **Authentication**: Check `Authorization Code Grant` (OAuth 2.0 PKCE)
   - **Redirect URI**: `http://localhost:3000/callback` *(used for initial auth only)*
3. Click **Save**
4. **Copy and save the Client ID** — you will only see it once

---

## Step 3 — Create a Custom Role for the Integration

Do NOT use the Administrator role for API access. Create a scoped role instead.

1. Go to **Setup > Users/Roles > Manage Roles > New**
2. Name it: `Meridian API Role`
3. Under the **Permissions** tab, add the following:

### Transactions
| Permission | Level |
|---|---|
| Journal Entries | Create |

### Reports
| Permission | Level |
|---|---|
| Financial Statements | View |

### Setup
| Permission | Level |
|---|---|
| REST Web Services | Full |
| User Access Tokens | Full |
| MCP Server Connection | Full |

4. Click **Save**

---

## Step 4 — Assign the Role to an API User

Create a dedicated API user (not a real employee account).

1. Go to **Lists > Employees > New** (or use an existing service account)
2. Name: `Meridian API User`
3. Under the **Access** tab:
   - Check **Give Access**
   - Assign role: `Meridian API Role`
4. Save the record

---

## Step 5 — Enable the MCP Feature on the Account

1. Go to **Setup > Company > Enable Features**
2. Under the **SuiteCloud** tab, confirm these are checked:
   - `REST Web Services`
   - `OAuth 2.0`
3. Save

---

## Step 6 — Gather the Internal IDs We Need

Once the above is set up, we need the NetSuite internal IDs for the following records so we can map our codes to NetSuite. Please export or provide a list of internal IDs for:

### Accounts (Chart of Accounts)
Codes we use: `41001`, `41002`, `41003`, `41004`, `43006`, `18099`, `21192`

Run this SuiteQL query in **Reports > SuiteAnalytics Workbook > New SuiteQL Query** to get them:
```sql
SELECT id, acctnumber, fullname
FROM account
WHERE acctnumber IN ('41001','41002','41003','41004','43006','18099','21192')
ORDER BY acctnumber
```

### Departments
Codes we use: `02 - OB/GYN - MD's`, `03 - OB/GYN - APP's`, `06 - Clinic - Managers`, `07 - Medical Assistants`, `08 - Medical Office Assistants`, `51 - Executive`, `52 - Operations`, `99 - Corporate`, `09 - MFM - MD`

```sql
SELECT id, name, fullname
FROM department
ORDER BY name
```

### Locations / Subsidiaries
```sql
SELECT id, name, fullname
FROM location
ORDER BY name
```

---

## Step 7 — Send Back to Developer

Once complete, please provide:

- [ ] Confirmation that the MCP Standard Tools SuiteApp is installed
- [ ] **Account ID** (found at Setup > Company Information — e.g., `1234567`)
- [ ] **Client ID** from the Integration record created in Step 2
- [ ] The internal ID mapping results from the SuiteQL queries in Step 6

---

## Notes

- No passwords or secrets need to be shared — authentication uses OAuth 2.0 PKCE (browser-based login flow)
- The API user only has permission to create Journal Entries — no other access
- All actions taken via the API will be logged in NetSuite's audit trail under the API user
