# MX Payroll Day Split — How It Works

## The Core Problem

Mexico payroll runs on a **calendar month** schedule (January, February, etc.), but each month has a different number of days. If you just divide salary proportionally by actual days, you get inconsistent amounts every month — the numbers never "settle" into a predictable pattern.

**Edgar's New Method** solves this by pretending every month has exactly the same length: **30.333 days** (which is 364 ÷ 12).

---

## The Magic Number: 30.333 Days

A year has **52 weeks × 7 days = 364 days** (NRF standard, not 365).
Divide that equally into 12 periods: **364 ÷ 12 = 30.333 days per period.**

Every month gets treated as if it were exactly 30.333 days long, no matter how many actual days it has.

---

## NRF Period Days vs. Calendar Days

In the NRF (National Retail Federation) 4-5-4 calendar, months alternate between:
- **28-day periods** (4 weeks) — most months
- **35-day periods** (5 weeks) — every quarter's middle month (Jan, Apr, Jul, Oct)

| Calendar Month | NRF Period Days | Normalized Days |
|---|---|---|
| January | 35 | 31.00 |
| February | 28 | 30.33 |
| March | 28 | 30.33 |
| April | 35 | 30.33 |
| May–December | 28 or 35 (repeating) | 30.33 |

> January uses **31.00** as its normalized days (a startup calibration for the fiscal year). Every other month uses **30.333**.

---

## Over Days: The Key Concept

Because 28 or 35 ≠ 30.333, each period has a "leftover" called **Over Days** — the days at the end of the period that belong to the *next* period's JE.

**Formula:**
```
Over Days[this month] = Over Days[last month] + Normalized Days - NRF Period Days
```

**Example chain for FY26:**

| Month | NRF Days | Normalized | Over Days Calc | Over Days |
|---|---|---|---|---|
| Dec (seed) | 28 | 31.00 | — | **5.00** (starting value) |
| Jan | 35 | 31.00 | 5.00 + 31 − 35 | **1.00** |
| Feb | 28 | 30.33 | 1.00 + 30.33 − 28 | **3.33** |
| Mar | 28 | 30.33 | 3.33 + 30.33 − 28 | **5.67** |
| Apr | 35 | 30.33 | 5.67 + 30.33 − 35 | **1.00** |
| May | 28 | 30.33 | 1.00 + 30.33 − 28 | **3.33** |
| ... | ... | ... | *repeats* | ... |

---

## Main Days vs. Provision Days

For each period:

```
Main Days     = Normalized Days − Over Days
Provision Days = Over Days
```

These always add up to exactly the normalized period (e.g., 27 + 3.33 = 30.33).

**What this means in the JE:**

| Field | Meaning |
|---|---|
| **Main Days** | Days of this month's salary booked *this period* |
| **Provision Days** | Days of this month's salary that "spill over" and are booked *next period* |
| **Calendar Days** | The normalized period (30.33) — used as the denominator for all calculations |

---

## How the JE Amount Is Calculated

```
Main JE Amount     = (Main Days ÷ Calendar Days) × Monthly Salary
Provision JE Amount = (Provision Days ÷ Calendar Days) × Monthly Salary
```

**Example — February (P02 FY26):**

| | Days | Ratio | Amount (on $149,193 salary) |
|---|---|---|---|
| Main | 27.00 | 27 ÷ 30.33 = 89.0% | $132,800 |
| Provision | 3.33 | 3.33 ÷ 30.33 = 11.0% | $16,393 |
| **Total** | **30.33** | **100%** | **$149,193** |

The provision amount ($16,393) is booked as an accrual dated in March. When March runs, those 3.33 days automatically show up as the "Previous" carryover — so March's total JE naturally includes salary from the end of February.

---

## The Fixed Lookup Table (in the code)

Rather than recalculating the chain every time, the system uses a **fixed table** with the correct values pre-computed for each calendar month:

| Month | NRF Days | Normalized | Main Days | Provision Days |
|---|---|---|---|---|
| 1 — January | 35 | 31.00 | 30.00 | 1.00 |
| 2 — February | 28 | 30.33 | 27.00 | **3.33** |
| 3 — March | 28 | 30.33 | 24.67 | 5.67 |
| 4 — April | 35 | 30.33 | 29.33 | 1.00 |
| 5 — May | 28 | 30.33 | 27.00 | 3.33 |
| 6 — June | 28 | 30.33 | 24.67 | 5.67 |
| 7 — July | 35 | 30.33 | 29.33 | 1.00 |
| 8 — August | 28 | 30.33 | 27.00 | 3.33 |
| 9 — September | 28 | 30.33 | 24.67 | 5.67 |
| 10 — October | 35 | 30.33 | 29.33 | 1.00 |
| 11 — November | 28 | 30.33 | 27.00 | 3.33 |
| 12 — December | 28 | 30.33 | 24.67 | 5.67 |

The pattern repeats every quarter: **3.33 → 5.67 → 1.00** for 28 / 28 / 35 week periods.

---

## Why This Was Broken Before

The old code chained forward month-by-month from a hardcoded anchor (November 2025, leftover = 0), using **actual calendar days** as the denominator. The result drifted over time and gave wrong provision values — for example, February was getting **Provision = 1 day** instead of the correct **3.33 days**.

The new fixed table eliminates that drift entirely by using the normalized 30.333 denominator, as Edgar's spreadsheet defines.

---

## What You See in the UI

After this fix, when you process a February file:

```
NRF Period Days:  30.33   ← normalized (not 28!)
Main Period:      27 days ← 89% of salary booked now
Provision:         3.33 days ← 11% accrued into next period
```
