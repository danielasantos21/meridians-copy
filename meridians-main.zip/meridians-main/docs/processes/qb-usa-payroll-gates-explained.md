# QB USA Payroll — the gates, and why some of them fail

**Who this is for:** whoever runs the QB USA Payroll booking and sees red on the
Preview screen and wants to know whether it's safe to keep going.

**The one-line version:** in P07-2026, 23 of 26 gates passed and 3 failed. All
three failures are fine to book. This document explains why, and — more
importantly — how to tell next month whether a failure is still fine.

---

## What a gate actually is

A gate is a subtraction.

ADP sends us the same payroll described in several different files: a
**register** (what each person earned), an **invoice** (what ADP is billing the
company), and a **carrier bill** (what UNUM or BCBS charged for benefits). Those
files are produced by different systems inside ADP and they don't reference each
other.

So a gate takes a number from one file and the matching number from another
file, subtracts them, and expects zero.

That's it. There is no cleverness in a gate. Its entire value is that the two
numbers came from **independent sources** — if someone uploaded the wrong
period, or a new pay code appeared, or a name got matched to the wrong person,
the two sides stop agreeing and you find out before it reaches QuickBooks
instead of during a year-end audit.

**These checks are ours, not ADP's.** They live in
`src/qb_usa_payroll_processor.py` and were written for this project. ADP does
not tell us anything is wrong. But the *disagreements* they surface are real —
every gate is comparing numbers ADP itself sent us.

### Vocabulary

| Term | Means |
|---|---|
| **Entity** | Which company. `HW3` = Stella Mattina Health, Inc. `DJ8` = Stella Mattina, LLC. |
| **Run** | One pay date. July 2026 has two: 07-10 and 07-24. |
| **Expected** | The number from the source we're checking *against*. |
| **Actual** | The number we booked. |
| **Variance** | `Actual − Expected`. Zero is the goal. |
| **Offenders** | The specific rows the gate is pointing at. Read the fine print in G5 below — this word is misleading there. |
| **Declared** | You ticked "I have reviewed this failure — export anyway". |

---

## The six gates

### G1 — gross wages: invoice vs register
Adds up **Gross Wages** on ADP's invoice and compares it to **Gross Pay** on
ADP's register, per company per pay date. Tolerance: half a cent.

This is the "did you upload the right files" check. If G1 fails, stop — almost
certainly a file from the wrong period got in. Nothing downstream is worth
reading until G1 is green.

### G2 — gross wages, person by person
Same idea as G1, but per employee instead of per company: each person's **GROSS**
on the invoice should equal what we booked into their earnings buckets (salary,
hourly, overtime, PTO, bonus, car allowance). Anyone off by a cent or more is
listed. Tolerance: one cent, per person.

**This is the gate that catches new ADP pay codes.** More on that below — it's
the most important section in this document.

### G3 — the actual bill
Everything we booked *except* the carrier benefits should equal the invoice's
**Total Amount** — the real number ADP is charging the company. Half a cent.

G1 checks wages; G3 checks the whole bill including taxes and PEO fees. G1 and
G3 both passing is strong evidence no ADP money went missing, even when G2
complains about an individual.

### G4 — the invoice against itself
The invoice lists employees one way (Table 3) and departments another way
(Table 5). Both should total the same. No register, no carrier file — this gate
only reads the invoice.

If G4 fails, the invoice file itself is damaged or was parsed wrong. That's a
file problem, not an accounting problem.

### G5 — benefit premiums vs the carrier's own total
Per company per carrier: the premiums we assigned to individual people should
add up to the carrier's control total on their bill. Half a cent.

### G6 — identity
Every person paid this run must resolve to exactly one identity. Catches two
people sharing a name, someone in the register with no match in Employee Master,
and carrier-bill names that match more than one paid employee.

G6 has no dollar tolerance because it isn't about dollars — it's about whether
we know *who* we're booking to. When it fails, those people are **left
unbooked** rather than guessed at, because putting real pay on the wrong person
is worse than leaving it out and telling you.

---

## The three failures in P07-2026

### G2, pay date 07-24: off by −2,057.14, one person

**Verdict: fine to book. Expected by design.**

One employee received **third-party sick pay** — pay from an insurance carrier,
not from the company. Their invoice line shows gross of 2,057.14, and then
immediately reverses it (`ADJ B6-ER 3PSP TAX −2,057.14`), leaving their actual
invoice total at **6.57**.

On the register side, their Gross Pay reads 2,057.14 but *every* earnings
column is blank — regular, overtime, PTO, all empty. The money came in under a
code that isn't one of the earnings columns we map.

So we book no wage expense for that person. **That is the correct answer.** The
insurer paid it, not the company; there is no employer wage expense to record.
And ADP isn't billing us for it either, which is why the invoice zeroes it out.

The proof this is benign rather than lost money: **G1 and G3 both pass for the
same company and the same date.** If 2,057.14 had genuinely gone missing, the
company-level totals would be off by 2,057.14 too. They aren't. The money is
accounted for; it simply isn't ours to expense.

> **One open question for the accountant — smaller than it first looks.**
> The register row shows Social Security, Medicare, FUTA and SUI figures next to
> this person, and no payroll tax is booked for them. It is tempting to read
> that as 1,491.45 of missing tax. It isn't: those register columns are
> **year-to-date balances**, not this check's tax. (Proof: the FUTA figure of
> 42.01 is the annual FUTA cap plus a cent of rounding — 0.6% of 7,000 is 42.00
> — and on other employees
> the register's SS figure is many times the invoice's per-check SS.) The
> processor correctly never reads them.
>
> The real question is smaller and still worth asking once. Third-party sick pay
> in the first six months of absence **is** subject to FICA. Where the insurer is
> not an agent of the employer — the usual arrangement — the insurer withholds
> the employee's share and, by timely notice, hands the **employer** share back
> to the employer. Here ADP TotalSource is the employer of record and would
> normally bill it, and on this invoice it billed nothing. If ADP never bills it,
> the exposure is roughly **157** (Social Security ~127.54 + Medicare ~29.83;
> FUTA and SUI are already at their annual caps) — not 1,491.45.
>
> **What to do:** keep booking taxes from the invoice — booking what the PEO
> actually bills is the right control. Ask ADP once whether employer FICA on
> third-party sick pay arrives on a later invoice or in the annual recap. If the
> answer is "never", accrue it manually. The answer applies every time this
> comes up.

### G5, UNUM, pay date 07-10: DJ8 +475.66 and HW3 −475.66

**Verdict: consolidated benefits are exactly right. The entity split is not.
Book it, with an intercompany note — but the reason is not what you'd guess.**

These two failures are equal and opposite, so they **net to zero**. Total
benefits expense across both companies matches UNUM's bill to the cent.

The cause is **two mechanisms stacked**, and it took three attempts to get this
right, so here is the actual arithmetic:

| | DJ8 | HW3 |
|---|---|---|
| UNUM billed (gate "expected") | 5,769.87 | 7,748.62 |
| Charges matched to people we paid | 5,295.69 | 7,578.86 |
| Unmatched charges left unbooked | −474.18 | −169.76 |
| Accountant overrides replacing the matched amount | **+949.84** | **−305.90** |
| **Booked (gate "actual")** | **6,245.53** | **7,272.96** |
| **Variance** | **+475.66** | **−475.66** |

**Mechanism one — unmatched charges (643.94 total).** Ten names on the UNUM
bill matched nobody we paid this run: leavers still being billed. Rather than
guess who should absorb their premium, the system leaves them unbooked and lets
G5 report it.

**Mechanism two — the override file, which is the bigger driver.**
`config/ts_benefit_overrides.local.json` holds the accountant's judgement calls
for this month: six DJ8 overrides totalling 1,452.37 replacing a matched base of
502.53, one HW3 override of 390.70 replacing 696.60, plus ten zero-overrides
suppressing the leavers' premiums entirely. An override *replaces* the matched
amount — it does not adjust it.

The two mechanisms happen to cancel exactly: the net override add-back (643.94)
equals the unmatched pool (643.94). That is **not** the code balancing itself —
it is a property of how the override file was written, evidently built from the
accountant's own reconciliation to re-book the whole bill. **It will stop
netting to zero the first month the overrides don't happen to absorb the
unmatched pool.** Don't read the symmetry as a safety property.

Net effect: **475.66 of benefits expense sits in DJ8 that UNUM's own entity
coding puts under HW3.** Two separate legal entities, so entity-level expense
and any intercompany balance are both off — but the amount is about 0.1% of
DJ8's period personnel cost, far below any sensible materiality threshold.
Book it and note the intercompany piece. Because this recurs monthly, it
deserves a standing policy rather than a fresh decision each period.

> **What is NOT happening, despite what the app currently tells you.** The
> Preview screen's explanation says a premium follows the employee's Employee
> Master entity rather than the entity the carrier billed, so someone who moved
> between companies shifts the cost. That code path is real — but in this period
> it moved **exactly 0.00**. Nobody moved. Following that explanation sends you
> looking for a person who does not exist. It is being corrected.

> **And the offender list is still misleading.** 66 offenders for DJ8, 29 for
> HW3 is **not 95 problems** — when G5 fails, the code lists everyone in that
> company carrying any premium, so the amounts sum to the booked total rather
> than the error. It shows the scope to search, not the cause. Given the real
> mechanism above, what you actually want listed is the per-person delta between
> booked and billed, which the code already has the data to produce.

## The part that matters next month

Here's the thing to internalise, because it's what will bite you:

> **The gate is a permanent tripwire. The explanation is not automatic.**

G2 doesn't understand third-party sick pay. It has no concept of it. All G2 knows
is *"this person's invoice gross doesn't match any earnings bucket I recognise."*

The reason that specific person's gross lands in no bucket is that the six
columns G2 sums are driven by a **fixed list of ADP column names** —
`REGISTER_COLUMNS` in `src/qb_usa_payroll_parsers.py`:

```
Regular Earnings Total, Overtime Earnings Total, EC_Car Allowance_Earnings,
ER_Earnings, ES_EDU Stipend_Earnings, EV_Variable Comp_Earnings,
F_BEREAVEMENT_Earnings, P_PTO_Earnings
```

The day ADP starts using a pay code that isn't on that list — a new stipend, a
new bonus type, a retro adjustment — that money lands in **no bucket**, and
**G2 fails in exactly the same shape as the sick-pay case.** Same gate, same
kind of number, same single offender.

And G2 cannot tell you which one you're looking at.

- **Sick pay** → booking nothing is correct. Tick the box, move on.
- **A new earnings code** → booking nothing means **someone's pay never reached
  QuickBooks.** That is a real error and must be fixed before export.

**How to tell them apart, every time, in under a minute:**

1. Open the offender's row in the **register** file (not the invoice).
2. Look across the earnings columns.
   - **All blank?** The gross arrived under an unmapped code. Now find out
     *which* code — look at what else is populated on that row. If it's a
     `B6`/3PSP-style sick-pay code, you're done. If it's a code you've never
     seen, someone must add it to `REGISTER_COLUMNS` before you book.
   - **A negative entry matching the gross?** That's a reversed or voided
     check. Booking nothing is right.
3. Either way, **confirm G1 and G3 passed** for the same company and date. If
   they did, no ADP money escaped. If they *also* failed, it isn't a coding
   question — something larger is wrong.

Every new ADP code costs exactly one human judgement call, once, and then the
code list gets updated and it never costs anything again. Budget for that; don't
be surprised by it.

---

## So when is it *not* safe to export?

The export refuses to write CSVs when a gate failed and nobody ticked the box.
That's deliberate — the tick is a record that a human looked. Here's what
"looking" should conclude:

| Situation | Safe? |
|---|---|
| G1 or G4 failed | **No.** Wrong or damaged file. Fix the input, re-run. |
| G3 failed | **No.** What we're booking doesn't equal ADP's actual bill. |
| G2, one person, register earnings all blank, code is known sick pay, G1+G3 green | **Yes.** |
| G2, one person, register earnings all blank, **unrecognised code** | **No.** Real pay would go unbooked. Map the code first. |
| G2, several people | **Almost certainly no.** A new earnings code usually hits more than one person. Investigate before booking. |
| G5, two entities, equal and opposite | **Yes, with a note.** Consolidated is right; the entity split isn't. Flag the intercompany piece. |
| G5, one entity failing alone | **No.** Nothing offsets it — real premium money is misstated. |
| G6 | **Depends.** Those people are unbooked. If that's a namesake collision, resolve it — their pay is currently missing from the JE entirely. |

The pattern: **a failure that nets to zero somewhere else is a disclosure
problem. A failure that nets to nothing is a real error.** Before ticking any
box, find the offset. If you can't find one, don't tick it.

---

## Privacy note

The **Gates** and **Gate Offenders** sheets of the generated workbook contain
real employee names — the G2 explanation renders the offender's name inline, and
the offender sheet listed 96 names for P07-2026. That's appropriate for an
internal review artifact, but it means **the workbook is not a document to email
around or paste into a ticket.** This README deliberately contains no names.
