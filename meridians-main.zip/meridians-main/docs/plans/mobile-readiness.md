# Mobile readiness — what a React Native client needs from Meridian

**Date:** 2026-09-24 · **Phase:** 12, task T16 (`docs/reports/phase-12-plan.md`) · **Status:** reference
document plus one open decision (§4). No mobile app exists; nothing here has been built for one.
**Grounded in:** `src/cognito.py`, `src/auth.py`, `api/deps.py`, `api/routers/auth.py`,
`src/api/v2/auth_routes.py`, `infra/meridian/stacks/auth.py`, `src/storage.py`; ADR 0003 (auth
model) and ADR 0021 (cookies for the browser, Bearer for everything else). Line numbers are as of
commit `12166bb`.

---

## 1. The short answer

A phone app can already **use** Meridian's API: every `/api/v2` endpoint accepts
`Authorization: Bearer <token>` and skips the browser-only CSRF check for it. What a phone app
**cannot do yet is get a token**: the sign-in endpoints hand tokens only to the browser, inside
cookies, and the server only accepts tokens minted for the web app's own Cognito client. §3 lists
the six gaps; §4 is the one decision needed to close the biggest of them.

Words used below, defined once:

| Term | Plain meaning |
|---|---|
| **Cognito** | Amazon's sign-in service. It checks passwords and the six-digit code, and issues tokens. |
| **Token** | A signed, time-limited string that proves "Cognito says this is user X". The **ID token** (60 minutes) is what Meridian accepts from a person. The **refresh token** (30 days) is traded for a new ID token without typing the password again. |
| **Bearer** | Sending the token in the `Authorization: Bearer <token>` header of each request, instead of in a cookie. Whoever *bears* the token is treated as its owner — which is why it must be stored carefully. |
| **App client** | A registration inside Cognito for one application. Each has an id; a *confidential* one also has a secret, which only a server can keep. A phone app is a *public* client: anything shipped inside it can be extracted, so it can hold no secret. |
| **`aud` (audience)** | The field in a token that says which app client it was issued to. |
| **MFA / TOTP** | Multi-factor authentication. Meridian uses TOTP: the six-digit code from an authenticator app that changes every 30 seconds. It is required for everyone. |
| **CSRF** | Cross-site request forgery: a hostile web page making the user's *browser* send a request with the user's cookies. It cannot happen to a Bearer request, because a browser never adds that header on its own. |
| **Pre-signed upload** | A short-lived URL (or form) from our server that lets the app send a file **straight to Amazon S3** without holding any AWS credentials. |
| **PHI** | Protected health information — patient identifiers and anything that could identify a patient. |
| **Keychain / Keystore** | The operating system's encrypted storage on iOS / Android, the only acceptable place for a refresh token on a phone. |

---

## 2. What already works for a non-browser client

| Capability | Where | What it means for a phone app |
|---|---|---|
| Bearer tokens accepted on every authenticated endpoint | `api/deps.py:131-138` (`_bearer_token`), `api/deps.py:141-169` (`resolve_identity` — the header is tried **before** cookies, line 153) | Send `Authorization: Bearer <ID token>`; no cookie needed. |
| Bearer requests skip CSRF | `api/deps.py:319-322` (`check_csrf` returns early when a Bearer header is present); ADR 0021 "Decision" | No `GET /csrf` dance, no `X-CSRFToken` header. |
| Tokens verified locally, no network call per request | `src/cognito.py:513-554` (`validate_token`), JWKS cache `src/cognito.py:433-510` | Fast; nothing extra for the app to do. |
| Roles and permissions read from Postgres on every request | `api/deps.py` `require_org` / `require_permission`; ADR 0021 "No roles… in any claim" | The app learns what the user may do from the API (`GET /api/v2/me`), never from the token. |
| Token lifetimes suited to a phone | `infra/meridian/stacks/auth.py:150` (ID token 60 min), `:157` (refresh 30 days), `src/cognito.py:107` | Sign in with password + code roughly once a month; silent refresh every hour. |
| Server-side refresh and revoke helpers | `src/cognito.py:322-355` (`refresh`), `src/cognito.py:358-376` (`revoke`) | The building blocks for §5.3 and §5.4 exist; only the HTTP endpoints are missing. |
| MFA challenge handled without exposing Cognito's session | `src/api/v2/auth_routes.py:305-390` (handle store), `:537-554` (`_challenge_response`) | The app gets an opaque handle, not the Cognito session. |
| Pre-signed **downloads** | `src/storage.py:533-553` (`get_signed_url`, `generate_presigned_url`) | Artifact downloads already go browser/app → S3 directly. |

---

## 3. The gaps

| # | Gap | Evidence | Fix |
|---|---|---|---|
| **G1** | **Sign-in never returns a token in the response body.** `POST /api/v2/auth/login` and `/mfa` put the ID and refresh tokens into HttpOnly cookies and return only `{user, org}`. A phone app has no way to read them. | `src/api/v2/auth_routes.py:504-534` (`_cognito_signed_in`: "No token is in the body"); `api/routers/auth.py:71-82` (`_sign_in_response` sets cookies) | §4 |
| **G2** | **The server accepts only the web client's tokens.** `validate_token` checks `aud == client_id()`, and `client_id()` is the one web app client. A token issued to a separate mobile app client would be refused. | `src/cognito.py:539` (`audience=client_id()`), `src/cognito.py:142` | Needed only under §4 option B: accept a short, configured list of audiences. |
| **G3** | **The only app client is confidential** — it has a secret and allows only `ADMIN_USER_PASSWORD_AUTH`, which needs AWS credentials. A phone cannot hold either. | `infra/meridian/stacks/auth.py:595-630` (`generate_secret=True`, `admin_user_password=True`, SRP off) | §4 decides whether a public client is added. |
| **G4** | **The MFA handle lives in one process's memory.** With two api tasks, the MFA step can land on the task that never saw the password step and fail. | `src/api/v2/auth_routes.py:317-322` (comment: "A second worker would strand some MFA attempts… they would fail closed") | Holds while there is one api task (Andres, 2026-09-22: keep one). If that changes, move the store to Postgres like ADR 0039's counters. |
| **G5** | **Two Cognito sign-in states have no answer**: `MFA_SETUP` (the user must enrol an authenticator before any token is issued) and `NEW_PASSWORD_REQUIRED`. Both answer `MFA_CHALLENGE_INVALID`. | `src/api/v2/auth_routes.py:579-591`; `docs/migration-tracker.md` row "Two Cognito sign-in challenges have no screen" | Must be closed for the browser anyway; the mobile flow reuses the same endpoints. |
| **G6** | **No pre-signed upload endpoint yet.** Uploads today are multipart posts through the api. | `docs/reports/phase-12-plan.md` §3.2 (`POST /api/v3/processes/{process}/uploads`, AFTER-P11), R12 | Phase 12 T18, after the Phase 11 manifest. §5.6 describes the target. |

Google and Microsoft sign-in are a seventh, smaller gap: today they are browser redirects
through the Cognito hosted page (`/auth/google`, `/auth/microsoft`, `src/cognito.py:651-739`).
On a phone they need the system browser and a return link into the app — only option B in §4
does that cleanly.

---

## 4. The one decision: how does a phone app get its tokens?

**Recommended default (proposed, not decided): Option A for email + password + TOTP users.**
Andres decides; nothing is built until a mobile app is actually planned.

| | **Option A — Meridian signs the user in and returns tokens** | **Option B — the app talks to Cognito directly** |
|---|---|---|
| How | New `/api/v3/auth/*` variants of login / mfa / refresh / logout that return `{id_token, refresh_token, expires_in}` in the body **only when the request says it is a native client** (for example a `Meridian-Client: native` header, with no cookies set). The server keeps using the existing confidential client and `ADMIN_USER_PASSWORD_AUTH` (`src/cognito.py:207-237`). | A new **public** Cognito app client for the app (no secret, SRP or authorization code + PKCE), called from the app with the AWS Amplify library; the server accepts that client's `aud` too (G2). |
| Strongest case for it | Nothing new in Cognito, no new dependency in the server, the rate limits (`LIMIT_LOGIN = "5/minute"`, `src/api/v2/limits.py:35`), MFA handle store, audit and error codes are the ones already tested; the secret never leaves the server. | The standard OAuth pattern for native apps (RFC 8252); the password never passes through Meridian's server; Google/Microsoft sign-in works through the system browser; no single-task caveat (G4). |
| Cost | ~1-2 days; tokens now appear in response bodies, so the "never log a token" lint (`scripts/lint_no_phi_logging.py`) and a test must cover those endpoints. | ~2-3 days plus a CDK change and a second audience in `validate_token`; Amplify added to the app. |
| Federated users | Not supported (they have no password). | Supported. |
| Trigger to switch | A federated-only user needs the app → add option B for them. | — |

Either way: the app must never embed a client secret, and the token it sends as Bearer is the
**ID token** (§5.2).

---

## 5. The flows a React Native client implements

Written for option A. Under option B, steps 1-2 are Amplify's `signIn` / `confirmSignIn` against the
public client, and steps 3-5 are the same.

### 5.1 Sign in and the MFA challenge

1. `POST /api/v3/auth/login` `{email, password}` (native variant).
2. The answer is one of exactly three things (`src/api/v2/auth_routes.py:555-591`):
   - **Signed in** → tokens (a user who somehow has no MFA; with MFA required this is rare).
   - **`{challenge: "mfa", session: <handle>}`** → show the six-digit code screen.
   - **`401`** → one generic "email or password is wrong" message. Never tell the user which one:
     the pool runs `PreventUserExistenceErrors`, and a different message per case would leak which
     addresses have accounts.
3. `POST /api/v3/auth/mfa` `{session: <handle>, code}` → tokens.
   - The handle is valid for **5 minutes** (`CHALLENGE_TTL_SECONDS = 300`,
     `src/api/v2/auth_routes.py:327`) and allows **3 wrong codes**
     (`MAX_CHALLENGE_ATTEMPTS = 3`, `:332`).
   - A wrong code does not retry against the same Cognito session — Cognito replaces the session
     on every answer (`src/cognito.py:248-251`) — so after a refusal the app goes back to the
     password screen.
4. **Enrolling an authenticator** (`POST .../mfa/setup`, then `.../mfa/verify`,
   `api/routers/auth.py:121-143`) requires the password again, on purpose
   (`src/api/v2/auth_routes.py:797-812`), and returns the setup key **once**. Show it, never store
   it. A `otpauth://` URI is returned too; the app can hand it to an authenticator app on the same
   phone.

### 5.2 Calling the API

- Send `Authorization: Bearer <ID token>` on every request.
- **The ID token, not the access token.** The server refuses any token whose `token_use` is not
  `id` (`src/cognito.py:99`, `:547`). This is deliberate: an access token is what a *machine*
  client holds, and a person must never be able to look like a machine or the other way round
  (ADR 0021; machine tokens go through a separate check, ADR 0037).
- No CSRF header, no cookies. If the app's HTTP library keeps a cookie jar, turn it off for
  Meridian so a stray cookie can never become a second credential.
- Learn who the user is and what they may do from `GET /api/v2/me` (later `/api/v3/me`) and the
  permissions it returns. Re-fetch it after every sign-in and refresh.

### 5.3 Refresh

- The ID token lives **60 minutes**; the refresh token **30 days** (ADR 0021 "Token lifetimes").
- Refresh a little before expiry (for example at 55 minutes) or on the first `401 AUTH_REQUIRED`,
  with one retry of the original request. Never loop.
- **A refresh returns a new ID token and NOT a new refresh token.** Keep the one you have
  (`src/cognito.py:325-329`, and line 354, which hands the original back so a caller that copies
  the result wholesale keeps working). Discarding it signs the user out an hour later.
- The server-side refresh needs the pool's username, which it reads from the *expired* ID token
  (`src/cognito.py:283-303`), so a native refresh request sends both the refresh token and the
  last ID token.
- When the refresh fails, the session is over: clear storage and show sign-in.

### 5.4 Sign out

`POST /api/v3/auth/logout` with the refresh token. The server revokes it at Cognito, which also
invalidates every ID token issued from it (`src/cognito.py:358-376`, ADR 0021 Codex G-H4). Then
delete the tokens from the Keychain / Keystore, whatever the answer. Revocation failing must never
keep the user signed in on the device.

### 5.5 Storing tokens

- **Refresh token:** Keychain (iOS) / Keystore-backed encrypted storage (Android) only — for
  example `react-native-keychain` or `expo-secure-store`. **Never** `AsyncStorage`, never a plain
  file, never a log, never a crash report.
- **ID token:** memory only; it is cheap to re-obtain from the refresh token.
- Optionally require device unlock (biometric) before the refresh token is read.

### 5.6 Uploading a workbook (target design, Phase 12 T18 — not built)

From `docs/reports/phase-12-plan.md` §3.2 and R12:

1. `POST /api/v3/processes/{process}/uploads` → a **pre-signed POST**: a URL plus form fields. The
   fields fix the maximum size and the content type (from the Phase 11 manifest), and the object key
   is `{org_id}/uploads/{upload_id}` in the `phi` bucket.
2. The app POSTs the file straight to S3 with those fields, within the URL's short life.
3. S3 malware scanning tags the object. Until it is tagged clean, starting a run answers
   `409 UPLOAD_NOT_SCANNED`; a rejected file answers `422 UPLOAD_REJECTED`. Poll with back-off.
4. `POST /api/v3/processes/{process}/runs` with the upload id and an **`Idempotency-Key`** header
   (a random UUID the app generates once per user action and re-sends on retry). Without it:
   `428 IDEMPOTENCY_KEY_REQUIRED`.
5. Downloads of results already work the same way in reverse: the API returns a short-lived
   pre-signed GET (`src/storage.py:533-553`; single files use a 120-second life,
   `src/storage.py:32`).

---

## 6. What a mobile client must never do

1. **Never read `custom:app_uid` (or `sub`) out of a token to decide who the user is.** The
   server's user id is `custom:app_uid` *or* `sub` (`src/cognito.py:45-52`, `:551`): migrated users
   carry their old Supabase id in `app_uid`, users created after the migration have none, and the
   pool's username is a third value again (`src/cognito.py:192-199`). The attribute is an internal
   bridge that disappears in meaning once the migration is over. The user's id is whatever
   `GET /me` returns. The app should not decode tokens at all, except to read `exp` for refresh
   timing.
2. **Never decide permissions from a token.** No roles, groups or permissions are in any claim
   (ADR 0003, ADR 0021); a claim that looks like one grants nothing
   (the planned `tests/security/test_idp_claims_not_authz.py`, plan §3.12).
3. **Never cache PHI.** No patient identifiers, no transaction-level rows, no downloaded workbooks
   or CSVs kept on the device after the screen that showed them closes: no offline database, no
   image cache of a report, no file left in the Documents folder, nothing in analytics or crash
   reports. The API is designed not to send PHI to anyone without `phi:read` (masked fields,
   ADR 0036), but the rule on the device does not depend on that. A downloaded file is opened from
   a temporary location and deleted.
4. **Never embed a client secret** or AWS credentials in the app. Anything in an app bundle can be
   extracted.
5. **Never send the access token as Bearer** (refused — §5.2) and never send a Cognito token
   anywhere but Meridian's API and Cognito.
6. **Never log** a password, code, token, email address or setup key — the same rule the server
   follows (`src/cognito.py:55-59`).
7. **Never put identifiers in URLs** (deep links, query strings, push-notification payloads). Push
   notifications, if ever added, carry a run id at most — the same "ids only" rule as webhooks
   (ADR 0038).

---

## 7. Before a mobile app can ship

| Item | Owner | Depends on |
|---|---|---|
| Decide §4 (A or B) | Andres | a mobile app actually planned |
| Native sign-in endpoints (A) **or** public app client + second audience (B) | Claude | the decision; T02 (done) |
| Close G5 (`MFA_SETUP`, `NEW_PASSWORD_REQUIRED`) | Claude | tracker row, before Phase 10 step 1 |
| Pre-signed uploads (G6) | Claude | Phase 11 manifest; T18 |
| Generated TypeScript client usable from React Native | Claude | T14 (`openapi-fetch` works outside the browser) |
| MFA handle store outside process memory | Claude | only if the api ever runs more than one task (G4) |
| Mobile rows in the control matrix (device storage, no PHI cache) and the pen test scope | Andres | the pen-test vendor decision (plan §6 decision 4) |
