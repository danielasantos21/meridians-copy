# /api/v2 + React — what's left

The §13 migration sequence in `docs/api-v2-contract.md` is complete: all 10
steps landed on 2026-08-24 (commits `f73372e` → `3af4cad`). Migrations 022,
023, 025 and 026 are applied to the live project.

This is the honest list of what did NOT get done, why, and what it costs to
leave it. Nothing here is blocking — the Jinja UI still books normally and the
React app runs alongside it.

## Blocks going further with React

**1. React covers 3 of the product's ~15 surfaces.**
26 components on 5 routes, against 96 Jinja templates and 169 Flask page
routes. The React app covers the qb-usa-payroll, qb-revenue and mx-payroll
wizards only. Login, dashboard, config, settings, ADP, booking v3–v5, wearbly,
invoices, admin and the public pages are still Jinja and are proxied through
the Next dev server. Making React the only front end means building those, then
deleting the Jinja routes per process. Much larger than the 10 steps were.

**2. qb-revenue and mx-payroll screens were never driven against live Flask.**
They typecheck, they render, and their endpoints answer — but only
qb-usa-payroll was walked end to end in a browser (upload → roster review →
gate declaration → book → results). Expect the first real qb-revenue run to
surface things tests did not.

## Correctness / completeness

**3. 12 of 17 run-state dicts are still process-local.**
`adp_v3`, `bkv4`, `bkv5`, `wearbly`, and the ADP/booking pairs in `web_app.py`.
Migration 022's `process` CHECK admits only `qb-revenue`, `mx-payroll` and
`qb-usa-payroll`, so migrating them needs a spec decision about what those
processes are called in §1.1 — not a mechanical follow-on. They fail visibly
(session not found) rather than silently, and single-worker behaviour is
unchanged, so this is safe to leave. It does block `gunicorn -w 4`.

**4. `patch_run_state` / `merge_run_override` are read-modify-write.**
Two workers patching different `run_state` keys in the same instant can lose
one. Tolerable at one worker; must become a `jsonb_set` RPC before multi-worker
is turned on — which is the deployment this whole migration exists for.

**5. No `expires_at` TTL sweep exists**, though three docstrings and migration
022's comment reference one. Abandoned reviews leave roster overrides — real
employee names and dollar amounts — in Postgres indefinitely. No cross-period
leak (overrides are keyed by run_id), but it is a documented control that isn't
implemented.

**6. The tie-out strip shows Journal total + Variance, not debits and credits.**
The run envelope carries no separate debit figure and the UI refused to
synthesise one. The signature element is showing less than designed until the
API carries both sides.

**7. `GET /api/v2/{process}/runs/{id}/downloads`** — the read-only audit
listing §7.2 asks for — does not exist. `artifact_downloads` rows are being
written; nothing reads them back.

**8. `q` and `sort` history filters answer 422 by name.**
Deliberate: `sort=period` would invalidate the created_at keyset cursor. Honest
rather than silently ignored, but still unimplemented.

**9. `SIGNED_URL_TTL` / `BUNDLE_URL_TTL` are duplicated** as literals in
`src/api/v2/oneshot_runs.py` and `qb_usa_runs.py`. `src/storage.py` is the
canonical home; those two were owned by another agent at the time.

**10. Rate limiting is IP-keyed, not org+user.**
flask-limiter evaluates `key_func` in `before_request`, which runs ahead of
`require_auth`, so `g.org`/`g.user` are unset. §9 warns this is wrong behind a
rewrite proxy — every user shares one bucket. The org+user branch is written
and activates when auth resolution moves into a `before_request` hook.

**11. `/api/v2/config/*` returns 503 in local SQLite mode.**
`get_database()` falls back to SQLite, which has no `org_id` column, so serving
config from it would hand one tenant another's mappings. Failing closed is
right; it means `DATABASE_MODE=local` dev gets 503s on those routes.

**12. Legacy preview still 404s for non-tie-out files.**
`/preview/<filename>` now falls back to Storage, but only for files recorded in
`qb_export_tie_out` (qb-revenue / mx-payroll JE CSVs). Legacy revenue workbooks
and validation `.xlsx` are not in that table and still vanish with the disk.

## Tests

**13. `tests/test_security.py::test_config_api_requires_config_permission`
has been failing the whole time** — it gets 400 (CSRF) instead of reaching the
403 permission check. Pre-existing, unrelated to this work, but it is the test
meant to prove the permission gate on the config routes, and those routes just
gained POST handlers that write org-scoped mappings. It is not currently
asserting what its name claims.

The other two long-standing failures (`test_adp_booking_v4::test_aggregate_benefits`,
`test_adp_v3::test_parse_benefits_invoice`) also predate this work.

## Environment

**14. `brew cleanup` will break the venv again.**
Homebrew upgraded `python@3.14` to 3.14.7 mid-session on 2026-08-24; its
`pyexpat` links against `/usr/lib/libexpat.1.dylib`, which does not exist on
this Mac, so `openpyxl` and everything downstream fails to import. Worked
around by pointing `venv/bin/python3.14` at the 3.14.6 build, which `brew
cleanup` will delete. Durable fix: `brew reinstall python@3.14`, or rebuild the
venv on python.org Python as CLAUDE.md already recommends for this machine.

**15. `SITE_URL` defaults to production.**
`web_app.py:1800` and `:1811` do
`os.environ.get('SITE_URL', 'https://www.meridiansgrp.com')`, so any
environment that forgets to set it sends SSO users to live Meridian. Failing
toward localhost is the cheaper mistake.

**16. Stray `/usage` line in `.env` (line 37)** breaks `source .env` for any
tool that does it. `scripts/dev_login.sh` parses around it; other tooling may
not.

**17. `npm run dev` defaults to port 3000**, which something else on this Mac
already occupies — it silently shadows the dev server. Verification ran on
3100.

## Live-account note

`meridianstest@meridiansgrp.com` was made **admin on Stella Mattina Health in
production** on 2026-08-24 for UI testing (`org_members.id`
`7c585068-aaf5-4e76-9932-b1c1dde4f7fc`). It can book and supersede real
periods. Remove it when testing is done.
