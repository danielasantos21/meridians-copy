# Plan — move the AI app into Meridian's AWS estate

**Date:** 2026-10-03 · **Status:** DRAFT, Phase 0 questions open · **Owner:** Andres

The LLM-assistant app at `ai.meridiansgrp.com` shares Meridian's AWS account. ADR 0001
describes it as another owner's application. **It is Andres's own app, for the same
company, and is meant to be HIPAA-compliant.** This plan moves it onto Meridian's shared
plumbing. Resource names and identifiers stay out of this file, for the same reason ADR 0001
gives; they are in the Obsidian vault note `NS_Proccess/2026-10-03 AI app move plan.md`.

## Goal

The AI app runs inside Meridian's **production** VPC, behind Meridian's ALB, CloudFront
WAF and ECS cluster. It keeps its **own** database, Cognito pool, KMS keys, buckets and
secrets. Its duplicate NAT gateway, ALB, web ACL and public IPv4 addresses are deleted
(≈ $60–70/month).

## Ownership rule

Each tool owns its own pieces, and neither ever edits the other's.

- **Meridian's CDK** owns the shared plumbing (VPC, subnets, ALB and HTTPS listener,
  CloudFront web ACL, ECS cluster). It publishes their identifiers to SSM Parameter Store
  under `/meridian/<env>/shared/*`.
- **The AI app's Terraform** owns everything that is only the AI app's: RDS, Cognito, KMS,
  buckets, secrets, its ECS service and task definition, its target group, its listener
  rule and its security groups. It reads the shared identifiers with `data
  "aws_ssm_parameter"` and creates none of them.

## Phase 0 — answers needed

1. Where the AI app's Terraform code lives.
2. What uses the AI app's Bedrock-only IAM user key. It was used on 2026-10-03 while the
   ECS service ran 0 tasks, so something other than the backend calls Bedrock with it.
3. Whether the app is in use, and whether 1–2 hours of downtime is acceptable.
4. Whether it holds PHI today or is only built to be HIPAA-ready.

## Phase 1 — now, independent of Meridian

| # | Change | Why | ≈ $/mo |
|---|---|---|---:|
| 1 | Delete the `meridian-trial` EC2 instance (plan §2.6) | Default VPC, web ports open to the internet; already due at Phase 3 | −48 |
| 2 | Turn on MFA on the AI app's Cognito pool | HIPAA gap | 0 |
| 3 | Turn on ALB, CloudFront and S3 access logs | HIPAA gap: no record of who accessed what | +1 |
| 4 | Retire the AI app's own CloudTrail trail | `meridian-shared-cloudtrail-audit` covers the whole account | −2 |
| 5 | Run its Terraform through the Identity Center profile | `andres-cli`'s key was deactivated on 2026-10-03 | 0 |
| 6 | *Optional:* park the idle plumbing. Snapshot the DB, delete NAT, ALB, ACL and IPs until Meridian production exists | It bills while serving nothing (ECS at 0 tasks) | −70 |

## Phase 2 — Meridian side, built with Meridian's Phase 8 production stacks

1. Publish the shared identifiers to SSM.
2. Admit `ai.meridiansgrp.com`:
   - add it to the ALB certificate (SAN) and the CloudFront web ACL;
   - give the AI app's CloudFront distribution the origin-verify header, ADR 0018 §7;
   - decide whether it gets a secret version of its own or shares Meridian's.
3. Security groups:
   - AI tasks may reach only the AI database;
   - Meridian's database admits no AI security group;
   - the AI database admits no Meridian security group.
4. Update ADR 0001 (the app is ours) and `docs/migration-tracker.md`.

## Phase 3 — rehearsal on Meridian staging (optional, recommended)

Restore a snapshot of the AI database into staging, run the AI backend there, and test it
end to end. The staging VPC's CIDR (10.20.0.0/16) is the same as the AI app's current VPC.
That only matters if the two networks are peered, and a snapshot-and-restore move never
connects them.

## Phase 4 — the move (1–2 h AI-app downtime)

1. Stop the AI service. Take a final RDS snapshot, encrypted with the AI app's own KMS key.
2. Restore it into a new DB subnet group in production's DB subnets (10.30.0.0/16). If
   wanted, upgrade Postgres 16 → 17 at the same time (`rds.force_ssl=1` stays on).
3. Deploy the AI backend as its own ECS service in Meridian's cluster, with new names
   (`ai-*`, never `meridian-*`).
4. **Replace the Bedrock IAM-user key with an ECS task role** that grants
   `bedrock:InvokeModel` on the models it uses. No long-lived key remains.
5. Add the listener rule (host `ai.meridiansgrp.com` → AI target group), then repoint the AI
   CloudFront origin at Meridian's ALB.
6. Smoke test: sign-in with MFA, one AI request, logs arriving.

**Rollback:** point the CloudFront origin back at the old ALB. The old estate is untouched
until Phase 5.

## Phase 5 — cleanup, 1–2 weeks after a quiet move

- Delete the old VPC, NAT gateway, ALB, ACL, IPs and old RDS instance. Keep the final
  snapshot.
- Delete the Bedrock IAM-user key.
- `terraform state rm` or remove anything Terraform no longer owns.
- Ask first for each deletion (`docs/aws-migration-prompt.md`: deleting anything is a
  stop-and-ask).

## Timing

- **Phase 1:** any time.
- **Phase 2:** alongside Meridian's Phase 8.
- **Phases 3–4:** after Meridian's cutover has settled (ideally after its first clean
  close on AWS), so that two risky changes never overlap.

## Money

| | ≈ $/month |
|---|---:|
| Trial server deleted | −48 |
| Duplicate NAT, ALB, ACL and IPs removed | −60 to −70 |
| Duplicate trail removed | −2 |
| **Total** | **≈ −110 to −120** |
