# Language Toggle (English / Español–México) — Implementation Plan

**One-paragraph answer.** Add a two-option toggle to the Settings → Appearance section that switches the **signed-in dashboard** between English and Mexican Spanish. Store the choice on the user's profile so it is remembered for good — a `language` field added to the existing `PATCH /api/v2/me`, landing in Supabase Auth `user_metadata`, so there is no new table and no migration — and mirror it into a `meridian.lang` cookie so the root layout can read it server-side and there is no flash of English on first paint. No new dependency. Translation itself is a plain `en.ts` / `es.ts` dictionary behind a `useT()` hook, because the expensive part of this project is extracting ~1,900 hardcoded strings out of 49 files, and no library makes that part cheaper. The hard boundary of the whole feature: **nothing that leaves Meridian as a file gets translated.** JE CSVs, Excel workbooks and invoice PDFs are import contracts with QuickBooks/NetSuite and stay English forever, in both languages.

---

## 1. Scope

**In scope — the signed-in dashboard only:**

| Area | Files |
|---|---|
| Shell | `components/shell/` — sidebar, tab-bar, nav-sheet, page-header, live-regions, test-mode-banner |
| UI primitives | `components/ui/` — 30+ files; banner, toast, modal, data-table, pagination, dropzone, empty-state, wizard-stepper, money, command-palette |
| Wizard screens | `components/screens/` — 12 files (upload, parsing, preview, results, roster-review, mapping-fix, failure, expired, superseded, …) |
| Routes | `dashboard/`, `runs/`, `processes/[process]/`, `config/`, `settings/`, `pnl-provider/`, `help/[process]/`, `onboarding/org/`, `login/` |
| Root states | `app/error.tsx`, `app/loading.tsx`, `app/not-found.tsx` |
| Copy tables in lib | `lib/run-view.ts`, `lib/dashboard-layout.ts`, `lib/run-badge.ts`, `lib/format.ts`, `lib/api/*.ts` fallback messages |

**Out of scope, by your call and by judgement:**

- **`app/(marketing)/`** — the public site, features, pricing, privacy, security, terms. Your decision. (Also the densest legal prose in the repo; translating a Terms of Service is a legal question, not an engineering one.)
- **`templates/` (legacy Jinja, ~50 files)** — the old Flask UI is being replaced by this SPA. Translating a screen twice, once in each stack, is the definition of wasted work.
- **Everything generated as a file.** See §2.

## 2. The hard line: what must stay English

This is the most important section of the plan. Getting it wrong corrupts accounting data, not just copy.

**Never translated, in either language mode:**

1. **Journal-entry output.** `src/exporters.py:1600` `je_headers = ['Date','Subsidiary','Location','Department','Account','Debit','Credit','Line Description',…]` and the identical `fieldnames` at `src/unposted_generator.py:560`. These are the column names QuickBooks/NetSuite matches on import. A translated header is a failed import, silently, at close.
2. **Line-description text.** `{Period} - {FiscalYear} - Cash Sales - {LocationName} {PayerType}` is a string the accountant greps in the ledger. It stays byte-identical.
3. **Every NetSuite/QuickBooks identifier**: location names (`001 Bishop`, `Hospital WSC`), department names (`02 - OB/GYN - MD's`), account codes and names (`41001`, `18099 Clearing Account`), the subsidiary path, clinic-group names, payer types.
4. **Fiscal codes.** `FY26`, `P07`, `FY25_P12`. The *caption* around them translates; the code does not.
5. **Excel workbook sheet names and tab structure** — the accountant's muscle memory and any downstream formula referencing a sheet name.
6. **Invoice and service-agreement PDFs** (`templates/invoice/`, `templates/agreement/`) — these go to a US LLC billing a US LLC.
7. **Transactional email** (`src/email_service.py`) — deliberately deferred; see §9.
8. **Data from Supabase**: employee names, provider names, payer names, org names, file names.

**Suggested UI affordance:** when the language is Spanish, the download/export panel carries one line — *"Los archivos generados (pólizas, Excel, PDF) se emiten en inglés porque QuickBooks los importa así."* Say it once, up front, rather than letting someone discover it and file a bug.

## 3. Where the setting lives — on the user, cached in a cookie

**Decision: the language is a field on the user's profile. The cookie is a cache of it, not the record.**

Requirement that settles this: *set it once and it is remembered.* A cookie alone is not remembered — it survives quitting the browser and restarting the Mac, but it is lost by clearing browsing data, a private window, a different browser, or a different computer, and it silently expires after a year. Any of those puts the app back in English with no explanation.

| Option | Cost | Verdict |
|---|---|---|
| `localStorage`, like the existing nav-position preference (`useSectionNavPosition` in `settings/section-shell.tsx`) | Zero backend | **Rejected** — read only after hydration, so every page load flashes English before switching. Tolerable for nav position; not for the whole UI. Same durability problem as the cookie. |
| Cookie alone | Zero backend | **Rejected as the record** — see above. Kept as the cache. |
| **Profile field + cookie cache** | One field, one route, a regen | **Chosen.** |

**Storage.** A `language` field (`"en" \| "es"`, default `"en"`) added to the profile schema at `src/api/v2/schemas.py:1385` and served through the existing `PATCH /api/v2/me`. It lands in Supabase Auth `user_metadata`, the same place `GET /api/v2/me` already reads `dashboard_preferences` from — **no table, no migration.** Then `openapi/meridian-v2.json` is regenerated and `npm run generate:types` refreshes `web/src/lib/api/schema.d.ts`.

**Why the cookie stays.** `app/layout.tsx` is a server component that renders before `GET /api/v2/me` has returned, so without a cookie the first paint is always English and then snaps to Spanish. The flow:

1. Toggle saved → `PATCH /api/v2/me` (the record) **and** write `meridian.lang` (the cache).
2. Page load → `layout.tsx` reads the cookie, sets `<html lang>` and the provider's initial value. First painted byte is correct.
3. `SessionProvider` gets `/me`; if `user.language` disagrees with the cookie — new device, cleared cookies — the profile wins and rewrites the cookie.

So the cookie is always disposable and the user record is always the truth. On a fresh machine there is one brief English paint on the very first load, and never again.

`meridian.lang` is non-`HttpOnly`, holds `en` or `es`, `SameSite=Lax`, one-year expiry. It carries no identity and needs no CSRF handling — a hostile value falls back to `en`, and the profile corrects it a moment later.

> `ponytail:` one scalar on an existing endpoint, no new resource and no migration. The cookie is a render cache, not a second source of truth.

**Where this lands in the phasing:** the profile field is part of **Phase 0**, not deferred. §9 and §10 are written accordingly.

## 4. Mechanism — no new dependency

```
web/src/lib/i18n/
  ├── en.ts          flat dictionary, the source of truth for keys
  ├── es.ts          same keys, es-MX values
  ├── keys.ts        type Key = keyof typeof en  (compile-time safety)
  ├── provider.tsx   <LanguageProvider lang>  — client context
  └── use-t.ts       useT() → t(key, vars?)
```

- `app/layout.tsx` (server) reads the cookie, sets `<html lang={lang}>`, wraps children in `<LanguageProvider lang>`.
- 85 of 99 non-test `.tsx` files already carry `"use client"`, so a React context reaches essentially everything. The handful of server files take a `getServerT(lang)` variant reading the same dictionaries.
- `t()` is typed against `keyof typeof en`, so a typo'd key is a TypeScript error, not a blank screen.
- Interpolation: `t("runs.showing", { n: 25 })` against `{n}` placeholders. Plurals via native `Intl.PluralRules` — no library.

**Why not `next-intl`.** Its value is routed locales (`/en/…`, `/es/…`), server-component message loading, and ICU tooling. Routed locales are actively wrong here — the language is an account preference, not part of the URL, and putting it in the path would break every existing link and bookmark. The extraction labour, which is 95% of the work, is identical either way. Add it later if plural/date ICU formatting becomes painful; the `t()` call sites do not change.

## 5. The Spanish-specific trap: never concatenate

Spanish articles and adjectives agree in gender and number with their noun. English composes fragments safely; Spanish does not.

```ts
// ✗ Unfixable in Spanish — "el archivo" but "la póliza"; "listo" vs "lista"
<>{t("common.the")} {noun} {t("common.ready")}</>

// ✓ One key per whole sentence
t("upload.fileReady")     // "El archivo está listo."
t("je.entryReady")        // "La póliza está lista."
```

**Rule for the whole project: one dictionary entry per complete sentence or complete label.** Never build a sentence from parts, never interpolate a translated noun into a translated frame. This is a code-review checklist item, not a suggestion.

Related: Spanish runs **15–25% longer** than English. Every button, tab, table header and badge must be checked for overflow — sidebar labels and `wizard-stepper.tsx` step names are the likely first casualties.

## 6. Locale-aware formatting

`web/src/lib/format.ts` is already the single source of truth for money and dates, and `components/ui/money.tsx` delegates every figure to it. It hardcodes `"en-US"` in five places (lines 79, 110, 145, 159, plus the English literals in `periodLabel`).

**The good news: es-MX uses the same separators as en-US.** `1,234.56` in both. So `splitAmount`, `Money`, and the entire figure-rendering contract survive untouched — no thousands-separator swap, no decimal-comma migration, no risk to any reconciliation screen.

What actually changes:

| Helper | en-US | es-MX |
|---|---|---|
| `formatDay` | `Dec 28, 2025` | `28 dic 2025` (lowercase month — correct Spanish) |
| `formatDate` | `Dec 28, 2025, 3:04 PM` | `28 dic 2025, 15:04` (24-hour) |
| `periodLabel` | `P07 · FY26 — ends Jul 31, 2026` | `P07 · FY26 — termina el 31 jul 2026` |
| `formatInteger` | `1,234` | `1,234` (unchanged) |

Implementation: `format.ts` takes the locale as an argument (or reads a module-level value the provider sets), and the eleven scattered call sites that bypass it get routed through it — `lib/next-url.ts:39`, `lib/run-badge.ts:70`, `components/ui/data-table.tsx:243`, `components/ui/dropzone.tsx:446`, `app/dashboard/page.tsx:126`, `app/pnl-provider/{report,account-editor,reference-section,tree-editor,preview-section}.tsx`. Several of those already call bare `toLocaleString()` with no locale, which silently follows the browser — inconsistent today, and fixing it is a free win.

**Currency recommendation.** `$` means *peso* in Mexico City. `Money` currently renders no symbol (USD is implicit). In Spanish mode, label the column or stat tile **`USD`** explicitly — `Ingresos (USD)` — rather than adding a symbol. Cheap, and removes a genuinely dangerous ambiguity on a revenue screen.

## 7. Server-supplied English reaching the UI

Three sources send English from Flask straight into React. None should be translated on the server; the server keeps emitting stable machine values and English fallbacks, and the frontend maps them.

1. **API errors — 118 `ApiError(...)` sites across `src/api/`.** They already carry machine `code` values (`PERMISSION_DENIED`, `VALIDATION_ERROR`, `PERSISTENCE_UNAVAILABLE`, …). Translate client-side off `code` in `lib/api/errors.ts`; keep `message` as the fallback when a code has no Spanish entry. **Do not translate `src/api/**` — a Spanish message in a server log helps nobody.**
2. **Server-supplied labels rendered verbatim** — `config_routes.py:124-168` (`"provider mapping"`, `"location mapping"`, `"payer mapping"`, `"department"`, `"QuickBooks provider code"`), `qb_usa_runs.py:1360-1363` (alert choices `"Keep X"` / `"Use X this run only"` / `"Use X from now on"`), `user_routes.py:459` `PROCESS_LABELS`, `auth_routes.py:128/228/279/485`. These need a frontend lookup keyed on the stable value. **Open item:** confirm each of these sends something stable enough to key on; where it does not, the backend should send a key alongside the label.
3. **`humanise()` in `format.ts`** turns backend gate names (`gross_pay_crossfoot`) into English sentences by capitalising snake_case. There is no algorithmic Spanish equivalent. It needs an explicit `es` lookup table of gate names, with `humanise()` as the English-only fallback. Enumerate the gate names from `src/qb_usa_payroll_*.py` when this phase starts.

## 8. es-MX glossary — the deliverable that matters most

Register: **formal (`usted`)**, Mexican accounting vocabulary, never Iberian Spanish. Locked before any translation begins; every later string is checked against it.

| English | es-MX | Note |
|---|---|---|
| Journal entry | **Póliza** (contable) | Mexican standard. *Asiento* is Iberian/South American — do not use. |
| Journal entry (the file) | Archivo de póliza | |
| Post / booked | **Registrar / registrado** | Not *postear*. |
| Close the period | **Cerrar el periodo** | *Periodo*, no accent, is the accepted Mexican spelling. |
| Fiscal year | Ejercicio fiscal | `FY26` itself stays. |
| Run (a process run) | **Ejecución** | Not *corrida*. |
| Start a run | Iniciar una ejecución | |
| Upload | **Cargar** | Not *subir* in a business UI. |
| Download | **Descargar** | |
| Preview | **Vista previa** | |
| Draft | Borrador | |
| Settings | **Configuración** | |
| Mapping | **Asignación** / *mapeo* | Prefer *asignación*; `mapping_table` identifiers stay English. |
| Payer | **Pagador** | Insurance payer. |
| Provider (clinician) | **Proveedor** (clínico) | Disambiguate from vendor. |
| Location | **Ubicación** | The NetSuite value stays English. |
| Department | **Departamento** | |
| Account (GL) | **Cuenta** | |
| Debit / Credit | **Cargo / Abono** | Mexican accounting. *Débito/crédito* reads like a bank card. |
| Clearing account | Cuenta puente | |
| Revenue | **Ingresos** | |
| Payroll | **Nómina** | |
| Gross pay | Sueldo bruto | |
| Benefits | Prestaciones | Not *beneficios*. |
| Reconciliation / tie-out | **Conciliación** / cuadre | |
| Unposted | **Sin registrar** | |
| Failed | **Con errores** | Softer and more accurate than *fallido*. |
| Superseded | **Reemplazada** | Feminine — agrees with *ejecución*. |
| Expired | Caducada | Feminine, same reason. |
| Save / Cancel / Reset | Guardar / Cancelar / Restablecer | |
| Test mode | **Modo de prueba** | |
| Organization | Organización | |
| Role / Permission | Rol / Permiso | |

**Terms deliberately left in English inside Spanish sentences:** QuickBooks, NetSuite, Meridian, CSV, Excel, PDF, the account codes, and the location/department strings.

## 9. Phasing

| Phase | Work | Why here |
|---|---|---|
| **0** | Lock the glossary (§8). Add the `language` profile field + `PATCH /api/v2/me`, regen OpenAPI and TS types. Build `lib/i18n/`, the cookie cache, the layout wiring, the Settings toggle. Translate the Settings page only, end to end. | Proves the whole mechanism on one screen, including the toggle switching itself and surviving a sign-in from a second browser. |
| **1** | The shell + UI primitives — `components/shell/`, `components/ui/`, `error.tsx` / `loading.tsx` / `not-found.tsx`, and the copy tables in `lib/` (`run-view.ts`, `dashboard-layout.ts`, `run-badge.ts`, `format.ts`). | Highest visible-surface per string in the codebase. After this the app *feels* Spanish. |
| **2** | `format.ts` locale plumbing + the eleven scattered `toLocaleString` call sites. | Small, mechanical, and unblocks every figure and date downstream. |
| **3** | `dashboard/` and `runs/`. | The two screens opened most. |
| **4** | `components/screens/` (12 files) + `processes/[process]/` + `create-run-form.tsx`. | The wizards — the actual work of the product. |
| **5** | Error/label mapping from §7: `ApiError` codes, server labels, gate names. | Needs the wizards done first to know which messages people actually hit. |
| **6** | `config/`, `pnl-provider/` (~16 files, `report.tsx` alone is the largest English source in the app), `help/[process]/`. | Deepest, least-visited, most prose. Last on purpose. |
| **7** | Guard rail: a lint rule or test that fails on new hardcoded JSX text. | Without it, phase 1's work rots within a month. |

Phases 1–6 are independently shippable — a partially translated app degrades to English on untranslated screens, which is ugly but never broken.

**Deferred, needs its own decision later:** transactional email (`src/email_service.py`). It is per-recipient, not per-viewer, so it must read the recipient's stored `language` rather than the sender's. Phase 0 puts that field on the user record, so the data will be there — what is deferred is translating the email templates themselves, and whether an invite to someone who has never signed in (and so has no stored language) should follow the inviter's language or default to English. Do it if and when email matters.

## 10. Costs and risks you should know about before saying yes

- **~1,900 strings across 49 files.** Densest: `pnl-provider/report.tsx` (~84), `settings/page.tsx` (~44), `create-run-form.tsx` (~25), `runs/page.tsx` (~24), `screens/preview-screen.tsx` (~15). Extraction is the project; the toggle is an afternoon.
- **36 test files assert on English strings** (`getByText`, `getByRole({name})`). Mitigation: tests render inside `LanguageProvider` pinned to `en`, so they keep passing unchanged. Only the deliberate Spanish snapshot tests use `es`.
- **A dictionary that drifts is worse than no translation.** Guard: a test asserting `Object.keys(en)` and `Object.keys(es)` are identical sets. Cheap, and it catches the one failure mode that produces blank labels in production.
- **Accessibility strings are easy to miss** — `aria-label`, `components/shell/live-regions.tsx` (screen-reader announcements), and the "Skip to main content" link in `layout.tsx`. A screen reader announcing English inside a Spanish page is a real defect, not a cosmetic one.
- **Who reviews the Spanish?** Machine-translated financial UI copy is how *cargo* becomes *carga*. This plan assumes a fluent Mexican Spanish reader signs off on the glossary in §8 and spot-checks each phase. **Owner: you.**

## 11. Verification

- Key-parity test between `en.ts` and `es.ts`.
- One rendered snapshot per phase in `es`, asserting no English leaked and no label overflows its container.
- **The one that matters:** an existing JE-export test, run with the language set to `es`, asserting the generated CSV is byte-identical to the English run. That is the §2 contract, enforced.
