# QuickBooks Online API — sandbox JE push test plan

project: NS_Proccess_QB (Meridian)
status: plan, 2026-09-01

## Where we stand
- Every QB feature today writes **CSV** for QBO's Journal Entry import (`src/revenue_qb_exporter.py`,
  `src/qb_usa_payroll_exporter.py`, `src/payroll_qb_exporter.py`). Nothing posts to the API.
- The only Intuit HTTP code is `scripts/qb_fetch_accounts.py` (read-only, token from Mergio's
  AWS secret). We will not touch that secret — it belongs to a third party.
- No OAuth flow, no token storage. `httpx` is already installed (via supabase); no new libs needed.

## What Andres uploads / provides (put in `.env`, never in code or the vault)
| Item | Where to get it | `.env` key |
|------|-----------------|------------|
| Client ID (Development keys) | developer.intuit.com → your app → Keys & credentials → Development | `QBO_CLIENT_ID` |
| Client Secret (Development) | same page | `QBO_CLIENT_SECRET` |
| Redirect URI registered | same page → add `http://localhost:3000/api/v2/qbo/connection/callback` (production: `https://www.meridiansgrp.com/api/v2/qbo/connection/callback`) | `QBO_REDIRECT_URI` (optional: defaults to `SITE_URL` + that path) |
| Sandbox company | API Docs & Tools → Sandbox → Add a sandbox company (QBO Plus, US) | — |
| Realm ID | shown on the sandbox list, and returned on the OAuth callback | `QBO_REALM_ID` |
| Environment | `sandbox` for now | `QBO_ENVIRONMENT=sandbox` |

Shortcut for step 1 only: the dashboard's **OAuth 2.0 Playground** hands you an access token,
refresh token and realmId with no code. Good for a first curl; not for the real flow.

In the sandbox company turn on **Gear → Account and settings → Advanced → Categories →
Track classes (one per row) + Track locations**. Our JEs carry Location and Class per line.

## Phases (GSD)
1. **OAuth connect** — the QuickBooks card in Settings (decision D18; it replaced the Flask
   `/qbo/connect` + `/qbo/callback` routes): `POST /api/v2/qbo/connection/connect` answers the
   `https://appcenter.intuit.com/connect/oauth2` URL (scope `com.intuit.quickbooks.accounting`),
   and Intuit returns to `/api/v2/qbo/connection/callback`, which exchanges the code at
   `https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer` (Basic auth client_id:secret). Store access/refresh token + realm + expiry in a new Supabase
   table `qbo_connection` (migration 035). Refresh when access token (1 h) is stale; always save
   the rotated refresh token (100-day life).
2. **Reference lookup** — `src/qbo_client.py`: `query("select * from Account")`, Class,
   Department, Preferences. Base URL by env: `sandbox-quickbooks.api.intuit.com` vs
   `quickbooks.api.intuit.com`, always `?minorversion=75`. Confirm class/location tracking
   prefs are on.
3. **CSV → JSON adapter** — one function that turns an existing QBO-CSV journal (already
   balanced, already tied out in `qb_export_tie_out`) into a `JournalEntry` body:
   `Line[]` with `Amount`, `DetailType=JournalEntryLineDetail`, `PostingType`, `AccountRef`,
   `DepartmentRef`, `ClassRef`; `DocNumber`=JournalNo, `TxnDate`, `PrivateNote`. Names in the
   CSV must be resolved to QBO Ids from phase 2.
4. **Push one JE to sandbox** — `POST /v3/company/{realm}/journalentry`. Record returned `Id`
   and `SyncToken` next to the tie-out row so a later reversal/void is possible (open question
   in `.planning/ROADMAP.md:587`). Manual test: open the sandbox UI, confirm the JE and totals.
5. **Wire into the React run flow** — a "Post to QuickBooks" button on the qb-revenue /
   qb-usa-payroll results screen, gated on the existing preview/gates passing. React only.

## Not doing yet
- Production keys: require Intuit's app-assessment questionnaire + HTTPS redirect, EULA and
  privacy URLs on meridiansgrp.com. Do after sandbox is proven.
- SDKs (`intuit-oauth`, `python-quickbooks`): `httpx` (already installed via supabase) covers two token calls + REST; `requests` is not a dependency here.

## Sources
- OAuth / redirect URIs: https://developer.intuit.com/app/developer/qbo/docs/develop/authentication-and-authorization/oauth-2.0
- Playground: https://developer.intuit.com/app/developer/qbo/docs/develop/authentication-and-authorization/oauth-2.0-playground
- Sandboxes: https://developer.intuit.com/app/developer/qbo/docs/develop/sandboxes/manage-your-sandboxes
- JournalEntry: https://developer.intuit.com/app/developer/qbo/docs/api/accounting/all-entities/journalentry
- minorversion 75: https://developer.intuit.com/app/developer/qbo/docs/learn/explore-the-quickbooks-online-api/minor-versions
- Production keys: https://developer.intuit.com/app/developer/qbo/docs/go-live/publish-app/get-production-keys
