# P&L-per-Provider Dashboard — v2 spec

**Status: spec, not code.** Supersedes parts of the v1 plan, `docs/pnl-provider-dashboard-plan.md`, which was removed on 2026-09-29 (read it with `git show 239060d:docs/pnl-provider-dashboard-plan.md`) — §12 at the bottom says exactly which parts, and which v1 sections still stand.

**One-paragraph answer.** v1 answers one question ("who earned what this period"). v2 makes the screen answer the five questions a CFO actually asks at close, using only data that already exists: **payer mix** (which insurers the money comes from — the biggest dimension v1 throws away), **trend** (this period against the five behind it, per provider and in total), **specialty** (MD vs APP vs MFM production, from the roster field v1 ignores), **concentration** (how much of the money rides on the top five people), and the existing **attribution honesty meter**, kept. No costs exist in the database, so there is still no margin, no cost, no profitability anywhere on the screen — the warning banner stays until the QuickBooks cost import is a real project. Everything below ships with **zero backend changes**: the multi-period trend is N parallel `/pnl/preview` calls with the current period never blocked on the older ones. The Phase-3 summary endpoint stays on the roadmap as an optimisation, not a prerequisite.

Jargon used below, defined once:

- **Payer mix** — the split of revenue by who pays it: Medicaid, Medicare, private insurance, or the patient themselves ("self pay"). It matters because the same visit pays very differently depending on the payer, and a practice heavy in one payer is exposed to that payer's rate cuts.
- **Concentration** — how much of the revenue depends on a small number of providers. "Top 5 = 60%" means losing one of five people could take a big bite out of revenue.
- **Attribution** — whether a dollar carries a specific provider's name. Unattributed ("pooled") revenue is real money the ledger could not pin on a person.
- **wRVU** (work relative value unit) — the standard unit for measuring physician work volume, payer-independent. Mentioned only in §10; this data does not have it.
- **Median** — the middle value of a group; half the group is above it, half below. Used for "vs. specialty median" because one huge earner drags an *average* up and makes everyone else look underwater.

---

## 1. The CFO's questions, ranked

In the CFO's own words, for a multi-site physician group closing a fiscal period:

| # | Question | Can this data answer it? |
|---|---|---|
| 1 | "What did we book this period — and is that number normal for us?" | **Yes, today.** Current preview + the five trailing previews (N parallel calls). |
| 2 | "Who are my top producers, and who's up or down against last period?" | **Yes, today.** Same fetches; per-provider delta is a client-side subtraction. |
| 3 | "What's our payer mix — how dependent are we on Medicaid, overall and per provider?" | **Yes, today.** The GL code on every fact *is* the payer type (41001–41004, 43006). v1 sums it away; v2 keeps it. |
| 4 | "Are the MDs, the APPs, the MFM line each pulling their weight?" | **Yes, today.** `specialty` is populated on the roster (`/config/pnl-providers`); join facts to roster on `provider_code`. |
| 5 | "How exposed are we if Dr. X leaves?" | **Yes, today.** Top-5 share of attributed revenue, plus each provider's share on their row. |
| 6 | "What does each provider *cost* me, and what's their margin?" | **No. Blocked on the cost import** (QuickBooks P&L-by-Class → Supabase, the v1 plan's Phase 4). Nothing in the database holds a cost. The screen must keep saying so. |
| 7 | "What's our revenue per visit / per wRVU?" | **No.** No visit counts, no wRVUs in any response. Drivers exist only as *configuration* (`structure.generated.ts`); no actuals arrive from the API. Needs new backend work (an eCW/Cobalt counts feed) before it can be honest — flagged in §10, not designed here. |

One new endpoint would make Q1/Q2 cheaper (`/pnl/summary`, §9) but nothing on this list *requires* it. Q6 and Q7 are the only genuinely blocked questions, and both are blocked on data, not on UI.

**Assumption, marked as such:** the reader of this screen is the CFO/controller at month-end close, comparing the period just closed against recent history and deciding where to look harder. It is not a real-time operations screen and not a compensation calculator (see §10).

---

## 2. The screen, top to bottom

Shell unchanged from v1: `PageHeader` + `CONTAINER` (1120px), sections separated by a hairline rule (`--border-keyline` step up to `--border-section` between regions) and `--s-8`/`--s-10` of air. No cards, no shadows, tokens only. All bars are the `booked-by-period.tsx` idiom: 6px `aria-hidden` track (`--fill-track`) + fill, width via the shared `barPercent`, every fact in text.

### At 1280px, in order

1. **Header.** `PageHeader`, title "P&L by Provider", meta "`P07 FY26 · revenue only`". Actions, right-aligned: **Export** (primary position, top-right — house rule), Refresh, Configure link. Export = `window.print()` over a print-only report (§8).

2. **Banner + period picker.** The cost-gap `Banner tone="warning"` stays, verbatim from v1. Beside the period `Select`, nothing else — the clinic filter stays down at the leaderboard where it acts.

3. **Tile row** — `StatTileGrid columns={4}`:
   - **Revenue** — period total (`Money`, `metric` size). **`delta`: vs. prior period** ("+4.2% vs P06"), `meaning: "neutral"` — revenue being down is not an error and must not be red (stat-tile.tsx's own rule). Delta renders only once the prior period's preview has resolved; until then the tile shows no delta rather than a placeholder.
   - **Named to a provider** — attributed cents, context "`87% of revenue`" (`metric-sm`). The honesty meter, kept as a tile (§7).
   - **Top 5 providers** — their share of *attributed* revenue, as a figure ("`62%`", `metric-sm`), context "`of named revenue`". Attributed, not total, because the pooled money by definition belongs to nobody and diluting the ratio with it understates the risk.
   - **Providers billing** — "`14 of 18`", unchanged from v1.

   That is the whole glance: how much, how sure are we who earned it, how concentrated, how many hands. Each tile answers a ranked question (Q1, attribution, Q5, Q2's denominator). Nothing here is a tile because dashboards have tiles.

4. **Revenue by period** — the "is this normal?" section (Q1). The `BookedByPeriod` shape exactly: six rows, oldest first, mono period label, bar, `Money`, current period's bar in `bg-accent` and the rest `bg-[var(--slate-300)]`, selected-period row marked in words. Rows for trailing periods still loading render the label + a `Skeleton` in the money column; a trailing period with **no current batch** renders "`no batch`" in `--text-tertiary` with an empty track (muted, not zero — zero is a claim). This section never blocks the ones above or below it; it fills in as the parallel fetches land (§6).
   - New component `web/src/app/pnl-provider/revenue-by-period.tsx`; do **not** import `BookedByPeriod` itself (its rows are a different API shape) but do import `barPercent` from it, as v1 already does.

5. **Payer mix** — Q3, full solution in §3. A five-row bar table (Medicaid / Medicare / Private insurance / Self pay / Unposted), amount + share of revenue per row. Scoped by the clinic filter like everything else.

6. **Provider leaderboard** — the body, extended:
   - Controls row above it: the existing clinic `Select`, plus a `SegmentedControl` (`segmented.tsx`): **Providers | Specialties** (§4).
   - Columns at ≥lg: **Provider** (row header, now a real `<button>` for drill-down selection, ≥48px) · **bar** · **Revenue** · **vs prior** (signed percent, `tabular-nums text-tertiary`, "—" when the prior period has no batch or the provider had no revenue then; never coloured — same neutral-delta rule as the tile) · **Medicaid %** (that provider's Medicaid share of their own revenue — the one per-provider payer figure that changes decisions in a Texas OB/GYN group; the full 5-way mix lives in the drill-down) · **Clinics**.
   - Below md: Provider + Revenue only, exactly as v1 (bar and extra columns hide; the ranked money column is the comparison).
   - Pooled row stays last, in the table, measured against the same max. Unchanged.
   - "Specialties" mode: same table, one row per specialty (§4) — no selection, no drill-down, no Medicaid column collapse needed (it stays; a specialty's Medicaid share is just as real).

7. **Provider detail** (drill-down; renders under the leaderboard when a row is selected). Heading = provider name + specialty as plain text (not a `Badge` — a specialty is not a status). Three compact pieces, each a mini bar-table or `DataTable density="compact"`:
   - **Payer mix for this provider** — the same five payer rows, this provider only. This is where the full per-provider mix lives (§3).
   - **By clinic** — where their revenue came from, one row per clinic.
   - **Trend** — their last six periods, one row each, same shape as section 4, from the same cached fetches. Below the table, one sentence: "`P07: $412,300 — specialty median $305,100 (+35%)`" — the benchmark line (§4). Muted "—" cells while trailing periods load.
   - Selection semantics: `aria-pressed` on the row button, clear on second click or on "All providers"; panel `aria-labelledby` its heading. Same-page panel, no modal, no sub-route — facts are already in memory.

8. **Unnamed-codes banner** — unchanged from v1, stays last.

9. **URL state.** `?fy=2026&p=7&clinic=…&provider=…&by=specialty` via `useSearchParams` + `router.replace`. A pasted link reproduces the view — that is what makes it shareable with the accountants.

### At 375px

- Tiles 2×2 (`StatTileGrid` does it).
- Every bar column hides below md (house idiom, reason documented in `booked-by-period.tsx:71`); the money columns carry the comparison. "vs prior" survives below md (it is one short cell and it is Q2); Medicaid % and Clinics hide.
- Leaderboard row buttons ≥48px (`mobile.test.tsx` will assert it).
- Drill-down `DataTable`s use the built-in mobile card list.
- Controls (period, clinic, segmented) wrap; Export stays visible in the header, not buried.
- No horizontal scroll anywhere; tables that would need it lose columns instead.

**Cut, deliberately:** no donut/pie anything, no sparklines in tiles (`stat-tile.tsx:55` forbids them), no per-row stacked payer strips (§3 says why), no map of clinics, no "insights" prose. Each would be a section because dashboards have one.

---

## 3. Payer mix — the hard visual problem, solved

**Decision: payer mix is a table of figures with bars — the house idiom — not a stacked bar. One hue. No new tokens.**

Three forms were considered:

1. **Stacked 100% strip per provider (or one big one)** — the classic answer, rejected. Four-plus segments need four distinguishable fills. The palette is monochrome plus one accent; a raw hex in a `.tsx` is a review rejection (DESIGN.md §7), and while a 4-step slate ramp (`slate-800/500/300/150`) *could* be aliased into legal tokens, adjacent grey segments in a 6px strip are indistinguishable at the sizes this design allows, demand a legend (a legend is the admission that the picture failed), and fail the moment two mid-greys sit side by side on a projector. DIRECTION.md's whole thesis is "the figures are the content"; a stacked strip hides the figures to draw a picture of them.
2. **Hand-rolled inline SVG** (no library — the middle path the design system leaves open). Judged and declined *for this*: SVG earns its keep when geometry carries meaning a table cannot (a flow, a distribution curve). A 5-way share has no such geometry — it is five numbers — and introducing the first hand-rolled SVG in the codebase for it sets the precedent at the weakest possible use case. If a real case appears later (e.g. a dense 13-period trend), make it then, as its own decision.
3. **The bar table** — chosen. It is already how this app compares magnitudes, it needs zero new colour, every figure is text, and it survives greyscale, mobile, and print for free.

Concretely, two placements:

**Section 5 (all providers, scoped by clinic filter):** `web/src/app/pnl-provider/payer-mix.tsx`, heading "Where the money comes from". Five fixed rows in fixed order — Medicaid, Medicare, Private insurance, Self pay, Unposted — each: label · bar (`bg-accent`, vs. the largest payer) · `Money` · share ("`38%`", `tabular-nums text-tertiary`). Rows render even at $0 (a payer at zero is news). A sixth muted row "Other accounts" appears only if facts carry a 4xxxx code outside the five (e.g. 43002 Discounts–Refunds exists in the chart) — money is never dropped to keep the table tidy. Unposted (43006) gets a `--text-secondary` label and a one-line caption: it is revenue not yet posted to a payer, not a payer.

**Labels** come from a small local map in `summary.ts` derived from `structure.generated.ts`'s income node labels (41001 → "Medicaid", etc.), trimmed for display. Not a fetch: `qb_payer_label_map`/`config_payers` exist server-side, but the five codes are stable business facts documented in CLAUDE.md, the labels are already in the shipped generated structure, and a network dependency for five strings is cost without benefit. If a sixth payer account ever appears, it lands in "Other accounts" with its raw code — visibly, so someone adds the label.

**Per provider:** the same component, reused with the drill-down's filtered facts (§2.7), plus the single **Medicaid %** column on the leaderboard. One column, not five, because five percent-columns is a spreadsheet and the ranking drowns; Medicaid share is the single mix figure that drives payer-strategy decisions here (**assumption:** Medicaid is this group's watched payer — it is the usual one for Texas OB/GYN; the column header is one word to change if the CFO watches Medicare instead).

Reduction (in `summary.ts`):

```ts
payerMix(facts: PlFact[]): { code: string; label: string; cents: number; share: number | null }[]
// fixed order, zero rows kept, "other" bucket appended only when nonzero
medicaidShare(facts: PlFact[]): number | null   // per-provider column; null when provider total ≤ 0
```

---

## 4. Specialty — group, filter, or benchmark?

**Decision: a leaderboard view toggle (group) plus one benchmark sentence in the drill-down. No specialty filter.**

- **Group:** `SegmentedControl` "Providers | Specialties". In Specialties mode the same bar table shows one row per specialty (revenue, vs prior, Medicaid %, provider count in place of clinics). This answers Q4 directly — "is the APP line growing?" — and costs one reduction, not a new section. A filter was rejected: with ~4–6 specialties and ~18 providers, filtering hides the comparison that is the whole point; the grouped view *is* the comparison.
- **Benchmark:** in the drill-down, "`vs specialty median: +35%`" — median, not mean (one star MD makes every other MD look underwater against a mean). Computed only when the specialty has ≥3 billing providers; below that a median is gossip, and the line does not render.
- **Join:** facts → roster on `provider_code` (both come from the same QuickBooks code space; `pnl_roster` and `provider_by_code` resolve from the same maps), falling back to name match, else the row groups under "No specialty on file" — shown, never dropped.

Reductions: `specialtyRows(facts, roster)`, `specialtyMedian(facts, roster, specialty)`.

---

## 5. Comparison and trend

**What a provider is compared against, in priority order:**

1. **Prior period** (the "vs prior" column and the Revenue tile's `StatTileDelta`). It is the close-time question and the cheapest honest one. Always the immediately prior period; if that period has no current batch, the delta is "—", never a stretch to the nearest older one (a "vs P04" figure in a "vs prior" column is a lie waiting to be read).
2. **Their own six-period trend** (drill-down table). Trailing average was considered as the delta baseline and rejected: a smoothed baseline hides the very step-change a close review exists to catch. The six raw figures *are* the trailing average, visible.
3. **Their specialty's median, this period** (drill-down sentence, §4).

Prior-**year** comparison is out of v2: `recentPeriods` deliberately clamps at P01 of the fiscal year, crossing FY boundaries needs fiscal-calendar knowledge the client does not have, and P07-vs-P06 answers the close-time question. Revisit alongside the summary endpoint (§10).

**Fetch strategy — decision: N parallel `/pnl/preview` calls now; the Phase-3 `/pnl/summary` endpoint later, as an optimisation.**

Why: the summary endpoint saves ~10s of *background* loading and one round of backend work, schemas, and tests — but the screen must not wait on trailing periods either way, so the endpoint buys latency nobody is staring at. Ship the frontend-only version, measure, then build §9's endpoint if the background lag annoys in practice. (This inverts the v1 plan's Phase-3 ordering on purpose: v1 assumed trend *required* the endpoint; it does not.)

Mechanics, spelled out:

- New hook `usePeriodFacts` (in the page or a colocated `use-period-facts.ts`): a `Map<periodId, PreviewState>` where `PreviewState = loading | ready(PlPreview) | no-batch | error`. On period change: fetch the **selected** period first (existing v1 path, existing dim-not-skeleton refetch behaviour), and fire the five trailing periods **in parallel** immediately after, each independently settling into the Map. Cache is keep-forever for the session (a closed period's facts do not change under you; Refresh clears the whole Map and refetches).
- **The current period is never held hostage:** tiles, payer mix, leaderboard, and drill-down (minus its trend rows) all render from the selected period's response alone. Only the delta figures, the by-period section, and the drill-down trend depend on siblings, and each shows its own local loading state ("—" / `Skeleton` row) until its period resolves.
- A trailing fetch that **fails** degrades to "—" with the by-period row reading "`unavailable`" in tertiary text — never an `ErrorPanel`, never a toast. Six background requests must not be able to put six error banners on a healthy screen. A trailing 400 no-batch is the designed "`no batch`" row.
- Concurrency: five parallel calls at ~2s each is fine for one user; do not build a queue for it.
- `StatTileDelta` gets its first real use: `{ label: "+4.2% vs P06", direction: "up", meaning: "neutral" }`. `meaning: "correctness"` is never used on this screen — no direction here means *wrong*.

---

## 6. Concentration and risk

**Decision: a tile and a sentence, not a section.**

- The **Top 5 providers** tile (§2.3): top-5 share of attributed revenue.
- In the drill-down heading area, one sentence: "`18% of named revenue this period`" — the "what if they leave" number, attached to the person you are looking at.

A full concentration section (Herfindahl indices, cumulative-share curves) was considered and cut: with ~18 providers the leaderboard *is* the concentration picture — the bars literally draw it — and a CFO who wants the tail can read it off the table. The tile states the one number worth repeating in a board deck; anything more is a chart looking for a reason.

Reduction: `topShare(rows, n = 5): number | null` (null when attributed ≤ 0).

---

## 7. The attribution honesty meter

**Keep, at v1's prominence — tile #2 plus the pooled row in the table. Add one escalation: below 80% named, a `Banner tone="warning"` above the leaderboard: "`Only 64% of this period's revenue is named to a provider — this ranking covers barely two-thirds of the money`", linking to Setup.**

Rationale: at healthy attribution (v1's observed ~87%+) the tile and pooled row already tell the truth without shouting. But the spec's own premise — a 60%-covered ranking is a *different object* — means the screen must change register when it becomes that object, not rely on the reader noticing a percentage. 80% is a judgment call (**assumption**), set as a named constant with a comment, trivially movable. Not promoted higher than that: the meter must not outrank the money on a healthy period. The unnamed-codes banner stays as the actionable half.

---

## 8. Export

**Decision: print-to-PDF for v2. XLSX deferred until asked for.**

- The house pattern already exists: the setup screen's preview prints a hidden `<PlReport>` (`report.tsx`) via `window.print()`. v2 adds a print-only dashboard report — `web/src/app/pnl-provider/dashboard-report.tsx` — rendered hidden and shown under `@media print`: header (period, scope, generated-at, "Revenue only — costs not imported"), the four figures, by-period table, payer mix, the full leaderboard (bars omitted; figures are the content), and the drill-down if one is open. The attribution rate prints; the honesty travels with the document.
- Why not XLSX: a board packet is a *document* — fixed layout, the caveats attached. XLSX invites re-deriving figures downstream, needs a new backend route (openpyxl lives server-side) styled to the house Excel standard, and duplicates every reduction in Python. When the accountants ask for one, it is its own small feature: `GET /api/v2/pnl/export.xlsx?fiscal_year&period`, built with the `src/exporters.py` constants, title at B2, table at B8, Arial 10, `#F2F2F2` alternating fill, orange summary tab per the tab-colour standard. Not in v2.

---

## 9. The build, in order

Every item through #9 needs **no backend work**. Gate for each: `npm run typecheck && npm test` (from `web/`).

1. **Reductions + labels.** `summary.ts`: add `payerMix`, `medicaidShare`, `topShare`, `specialtyRows`, `specialtyMedian`, `deltaPercent(current, prior): number | null`, and the payer-label map (from `structure.generated.ts` labels). Tests in `summary.test.ts`: fixed row order, zero-payer rows kept, "other" bucket, negative/zero totals → null shares, median needs ≥3, specialty fallback bucket, delta null on missing prior.
2. **Multi-period fetch.** `use-period-facts.ts` (colocated hook): Map cache, selected-first, five parallel trailing fetches, per-period `loading | ready | no-batch | error`, Refresh clears all. Tests in `page.test.tsx`: current period renders before trailing resolve; trailing failure degrades to "—" with zero error panels; cache prevents refetch on flip-back (assert mock call counts). Mock `@/lib/api/config`, never fetch.
3. **Tile row v2.** `page.tsx`: swap to `columns={4}`, add Top-5 tile, wire `StatTileDelta` on Revenue (neutral, only when prior ready). Tests: delta absent while prior loading, present after, never `text-critical`.
4. **Revenue by period.** New `revenue-by-period.tsx` (imports `barPercent`). Rows: skeleton / no-batch / unavailable / figure; selected period accent + marked in words. Tests: all four row states, order oldest-first.
5. **Payer mix.** New `payer-mix.tsx`, used in section 5 (clinic-scoped) and inside the drill-down (provider-scoped). Tests: five rows always, other-bucket row conditional, unposted caption, sr-only caption names the scope.
6. **Leaderboard v2.** `provider-leaderboard.tsx`: row-header becomes a ≥48px `<button>` with `aria-pressed`; new "vs prior" and "Medicaid %" columns (≥lg; "vs prior" survives below md); `SegmentedControl` Providers|Specialties above. Tests: selection semantics, column visibility at 375/1280 (`setViewport`), specialty mode rows + no selection, pooled row untouched.
7. **Drill-down.** New `provider-detail.tsx`: payer mix, clinic split, six-period trend, specialty-median + share-of-revenue sentences. Tests: totals tie to the leaderboard row figure; median line absent under 3 peers; trend cells load independently.
8. **URL state.** `?fy&p&clinic&provider&by` sync (`useSearchParams` + `router.replace`; mock `next/navigation`). Tests: round-trip both ways.
9. **Export + suites.** `dashboard-report.tsx` + print CSS + Export button; extend `web/src/__a11y__/routes.axe.test.tsx` (violations still `[]` — the new tables need sr-only captions, the segmented control its kit label), `mobile.test.tsx` (48px row buttons), `behaviour.test.tsx`, `contrast.test.ts` (no new pairs expected — tokens only).

**Flagged separately — backend, optional, later:**

10. **`GET /api/v2/pnl/summary?fiscal_year=2026&from=2&to=7`** — only if the parallel-fetch background lag proves annoying. Route beside `pnl_preview` in `src/api/v2/config_routes.py`, permission `pnl_provider:access`; new `provider_period_totals(db, fiscal_year, periods, org_id)` in `src/pnl_facts.py` looping `current_batches` + `revenue_facts` server-side and discarding account/clinic grain; schema `PlSummaryOut` in `src/api/v2/schemas.py`; response `{fiscal_year, periods: [{period_id, batch_ids, providers: [{provider_code, provider, amount_cents}], pooled_cents}]}`; tests beside the preview's; regenerate `openapi/meridian-v2.json` types. `use-period-facts.ts` is the only frontend file that changes.
11. **Cost import (the v1 plan's Phase 4)** — unchanged, separately scoped, still the gate for margin. Nothing in v2 paints it into a corner: the tile grid, the drill-down, and the payer-mix table all extend to cost rows when facts gain them.

---

## 10. Deliberately left out

- **Margin, cost per provider, compensation ratio, profitability ranking** — no cost data exists anywhere in the database. Any such figure would be invented. The banner stays until the import is real.
- **Revenue per visit, wRVU productivity, capacity/FTE utilisation** — no visit, wRVU, or FTE *actuals* in any API response (drivers are config only). Needs a counts feed (eCW via Cobalt was the sketch) before it can be honest. This is the highest-value future addition after costs — say the word and it gets its own plan.
- **Collections vs. charges, denial rates, AR days** — the facts are booked revenue from billing exports; there is no charge, adjudication, or aging data. A CFO will eventually ask; this system cannot answer from what it stores.
- **Prior-year (P07 FY26 vs P07 FY25)** — cross-FY period math needs fiscal-calendar knowledge the client lacks; pairs naturally with the summary endpoint (#10).
- **Payer detail beyond the five account codes** — `payer_original`/`payer_type` exist on `transactions` but are not selected into facts; per-plan mix (which Medicaid MCO, which commercial plan) would need a facts change. Real, but a different grain of question.
- **Budget vs. actual** — no budget data exists in the system.
- **Department dimension** — always `None` on the database path; a column of blanks is not a feature.
- **Charts requiring a library, and hand-rolled SVG** — §3. The former is the user's dependency decision if ever; the latter waits for a problem tables cannot carry.

---

## 11. States, a11y, and the frozen gates (delta from v1)

v1's handling stands (skeleton first paint, dim-not-skeleton refetch, `no-batch` EmptyState, `ErrorPanel` on real failure, roster failure degrades the denominator only). New in v2: trailing-period failures are **local and quiet** (§5); every new table gets an `sr-only` caption naming its scope; bars stay `aria-hidden` with all facts in text; the leaderboard's selectable rows are real buttons (Tab + Enter for free) with `aria-pressed`; the drill-down is `aria-labelledby` its heading; heading order stays h1 → h2. All colour via existing tokens — no new contrast pairs, no raw hex.

## 12. What this supersedes in the v1 plan (`git show 239060d:docs/pnl-provider-dashboard-plan.md`)

- **§4 (screen) and Phase 1** — superseded by §2 here: the tile row changes composition (Top-5 in, Pooled-as-tile stays out — the pooled row in the table carries it), and four new sections exist.
- **Phase 2 (drill-down, URL state, Export)** — absorbed into v2 (§2.7, §2.9, §8) with the drill-down enlarged (payer mix, trend, benchmark).
- **Phase 3 (trend)** — the *ordering* is reversed: trend ships frontend-only via parallel previews (§5); the summary endpoint becomes optional item #10. The v1 plan's endpoint shape and `pnl_facts.py` sketch remain the reference when it is built, as does its §7 materialised-view escape hatch.
- **Phase 4 (costs)** and the v1 plan's honesty stance (§2), IA decision (§3), state handling (§8), and a11y notes (§9) — **stand unchanged**.
