# Runbook — onboard a partner (or one of our own scripts) as an API client

**When:** an outside company's system, or a script of ours, needs to call `/api/v3` without a
person signed in.
**Who:** an org admin of the organization the client will belong to **requests** it;
**a superadmin approves** — a DIFFERENT person from the requester in staging and production
(self-approval is refused there by default since 2026-09-25, ADR 0037 decision 2 as amended;
allowed only in development). A reason is required, and the quarterly access review flags any
self-approval.
**Time:** about 30 minutes of ours, plus whatever the partner needs to build.
**Status:** written in Phase 12 (T17) and **never executed** against a deployed environment.

## Words used here

| Word | Meaning |
|---|---|
| **API client** | A program that calls `/api/v3` with no person present: one row in `public.api_clients`, backed by one Cognito **app client** holding its id and secret. |
| **Scope** | A named permission such as `runs:read`. The client may only do what its granted scopes allow; the api refuses the rest with `403 SCOPE_INSUFFICIENT`. |
| **Client credentials** | How a machine signs in: it sends its id and secret to Cognito's `/oauth2/token` and gets a 15-minute **access token**, which it sends on every call. |
| **BAA** | Business Associate Agreement — the HIPAA contract a partner must sign before it may receive PHI. Recorded in `public.partner_baas`. |
| **mTLS** | Mutual TLS: the client also presents a certificate. Required, with a BAA, for any client allowed to read PHI (ADR 0042). |
| **Webhook** | Meridian calling the partner's URL when something happens (`run.completed`), instead of the partner asking over and over. Signed so they can prove it came from us (ADR 0038). |
| **Sandbox** | The fake "Sandbox" organization in staging, filled with generated data, where a partner practises before touching production (ADR 0041). |

## 0. Before you start — three stops

1. **Is the API switched on?** `/api/v3` exists only where `MERIDIAN_API_V3` is on and the
   database is Postgres (`src/settings.py`), and machine clients need the platform deployed:
   `cdk deploy … -c enableApiPlatform=true` (resource-server scopes, the api's Cognito
   permissions, the webhook plumbing — `infra/README.md`). **That flag is a cost-approval
   item** (`docs/reports/phase-1-cost-estimate.md` §3b). If it is not deployed, stop here.
2. **Does the client need PHI (`phi:read`)?** Then it needs a **signed BAA** recorded in
   `partner_baas`, an **mTLS certificate subject**, and the partner mTLS ingress (T25,
   ADR 0042) — **none of which exists yet**: there is no screen to record a BAA, `phi:read` is
   not on the Cognito resource server, and the api refuses the grant without both
   (`src/api_clients.validate_grant`). **Stop and ask Andres**; this is a T25 build and a cost
   decision, not an onboarding step. Everything below is for clients that do **not** read PHI.
3. **Sandbox first.** An outside partner practises in the staging Sandbox org (§6) before a
   production client is created. Our own scripts may skip it.

## 1. Agree what the client may do — the least it needs

Pick scopes from this list and nothing else (`src/api_scopes.MACHINE_GRANTABLE_SCOPES`, the
catalogue on the Cognito resource server `meridian-api`):

| Scope | Lets the client |
|---|---|
| `runs:read` | Read process runs and their outputs' metadata |
| `processes:run` / `processes:execute` | Start a run / execute a finished one (booking). *The v3 process endpoints arrive after Phase 11 (plan T18).* |
| `artifacts:download` | Download a run's output files |
| `journal-entries:read` | Read generated journal entries |
| `mappings:read` / `mappings:write` | Read / change payer, location and provider mappings |
| `employees:read`, `allocations:read`, `revenue:read` | Read those collections |
| `webhooks:manage` | Manage its own webhook subscriptions |

`runs:read`, `processes:*`, `artifacts:download` and `journal-entries:read` are
**per process**: also list the processes (`revenue`, `payroll`, …) the client may touch. A
machine can **never** hold `org:admin`, `clients:manage`, `settings:admin`, `audit:read`,
`superadmin`, `profile:self` or `dashboard:self` — the request is refused.

Ask the partner for the **addresses** their calls come from. An IP allowlist
(`ip_allowlist`, up to 20 networks such as `198.51.100.0/24`) makes a stolen secret useless
from anywhere else. Leave it empty only for a client whose address genuinely changes, and
write down why.
It also keeps the partner working when its address is shared (a cloud NAT, an office
gateway): ten failed sign-ins from that address by anybody lock the ADDRESS out for
15 minutes, and only a client whose allowlist admits the address is let through it
(ADR 0039 §6).

## 2. Request the client

In the admin screen (**Admin → API clients → Request a client**, `web/src/app/admin/api/`,
Phase 12 T13) — stepped: name and kind → scopes and processes → IP allowlist → preview →
submit. Until that screen ships, the same call by API (bearer flow: `docs/plans/mobile-readiness.md`):

```bash
BASE=https://api.meridiansgrp.com/v3            # staging: https://staging-api.meridiansgrp.com/v3 (ADR 0050)
curl -sS -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"Acme nightly export","kind":"partner",
       "scopes":["runs:read","journal-entries:read"],"processes":["revenue"],
       "ip_allowlist":["198.51.100.0/24"]}' \
  "$BASE/admin/api-clients"
```

`kind` is `partner` (outside company), `internal` (our script) or `sandbox` (practice, staging
only). The answer is `201` with `"status": "pending_approval"`. **Nothing exists in Cognito
yet** and the client cannot authenticate.

## 3. Approve it — the secret appears once

Andres, in the screen (**Approve**, reason required) or:

```bash
curl -sS -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"reason":"Acme export, contract 2026-10"}' \
  "$BASE/admin/api-clients/<client id>/approve"
```

This creates the Cognito app client (client-credentials only, 15-minute tokens, allowed
scopes = the grant), writes the audit row, and returns
**`cognito_client_id` and `secret` in this response only** (`Cache-Control: no-store`). The row
keeps a short fingerprint, never the secret; there is no way to see it again. If it is lost,
rotate (§7).

## 4. Hand the credentials over — safely

* **Client id + secret** go by a channel that is not email: a password manager share with
  expiry, or read out on a call. **Never** in a ticket, a chat, a commit or a vault note.
* **Token URL:** `https://<the pool's hosted domain>/oauth2/token` — the `HostedDomainPrefix`
  output of `meridian-<env>-auth`, as `https://<prefix>.auth.us-east-1.amazoncognito.com`.
* **Scope string:** the granted scopes prefixed with the resource server, space-separated:
  `meridian-api/runs:read meridian-api/journal-entries:read`.
* **The OpenAPI document** (`openapi/meridian-v3.json`) and the generated client for their
  language (ADR 0043; both are Phase 12 T14 and may not be in the repository yet). It is not
  served live; they receive it here.
* **Two rules for their code:** cache the access token until ~60 seconds before it expires
  (each token costs us $0.00225 — ADR 0037; the generated clients do this), and back off on
  `429 QUOTA_EXCEEDED` using `Retry-After` (300 calls a minute per client; job starts —
  `execute`, `retry` — one per process per 30 seconds and 30 an hour for the organization; the
  edge also blocks an address sending more than 1,500 `/api/v3` requests in 5 minutes).

## 5. Webhooks (optional)

If the partner wants to be told when a run finishes rather than polling:

1. They give us an **`https://` URL on port 443** with a public hostname. Private,
   loopback, link-local (including `169.254.169.254`), carrier-grade NAT and our own VPC range
   are refused, at subscribe time **and** at every delivery (`src/webhooks/ssrf.py`). A refused
   URL answers one generic `422 WEBHOOK_URL_REJECTED` whatever the reason.
2. The client (with `webhooks:manage`) or an org admin creates the subscription:

   ```bash
   curl -sS -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
     -d '{"url":"https://hooks.acme.example/meridian","event_types":["run.completed","run.failed"]}' \
     "$BASE/webhooks/subscriptions"
   ```

   The **signing secret is in this response only** — hand it over like the client secret.
3. Tell them how to verify (ADR 0038): headers `Meridian-Event-Id` and
   `Meridian-Signature: t=<unix>,v1=<hex>`, where `v1` is HMAC-SHA256 of `"<t>.<event id>.<raw
   body>"` with the secret. Reject if `|now − t| > 300` seconds; de-duplicate on the event id
   (a retry or a redrive carries the same one). The event id is **unique per subscription**: two
   subscriptions to one endpoint each get their own id for the same run event, so one replay
   cache serves both safely; to act once per run whichever subscription told them, key on
   `data.run_id` + `type`. The id they received is the delivery's `id` in the delivery log.
   During a secret rotation two `v1=` values arrive for 24 hours — accept either. The
   generated clients ship a verify helper.
4. **Test it:** `POST $BASE/webhooks/subscriptions/<id>/test` sends a `webhook.test` event
   through the real path (at most one per subscription per 30 seconds and 60 per org per hour;
   past that `429 QUOTA_EXCEEDED` with `Retry-After`). `GET $BASE/webhooks/deliveries?subscription_id=<id>` shows it
   `delivered`, or `failed` with our reason code (`HTTP_ERROR`, `TIMEOUT`, `SSRF_BLOCKED`, …).

Bodies carry ids only (`run_id`, `process`, `state`) — never names, amounts or PHI; the
partner fetches details through the API with its own scopes.

## 6. The sandbox (outside partners, before production)

Staging's Sandbox org is fake data only, and staging must hold **nothing else** while a
partner practises (ADR 0041). Andres runs, in this order:

1. `python3 scripts/staging_wipe.py --confirm-env staging --dry-run`, then without
   `--dry-run` — empties staging (database recreated from Alembic, both buckets, stray app
   clients) and writes the wipe record.
2. Creates the org **"Sandbox"** in the superadmin console, then requests and approves a
   `kind=sandbox` client in it (§2-§3) with `mappings:read`, `mappings:write` and whatever the
   partner will practise. A sandbox client can never hold `phi:read`.
3. `python3 scripts/seed_sandbox_org.py --confirm-env staging --base-url
   https://staging-api.meridiansgrp.com --dry-run`, then without `--dry-run` — posts the example
   mappings through `/api/v3` as that client and writes a synthetic revenue workbook to a
   temp directory. It refuses unless the newest wipe is newer than the newest restore.
4. Hands the sandbox credentials over (§4) with the **staging** token URL and base URL.

At session end: revoke the sandbox client (`docs/runbooks/revoke-api-client.md`) — Cognito
app clients cost nothing idle, but a live sandbox client **blocks any restore into staging**
(`scripts/restore_guard.py`, `docs/runbooks/data-load.md` step 0) — then tear staging down
(`docs/runbooks/staging-teardown.md`).

## 7. Rotating a client secret later

Zero downtime, because a Cognito app client may hold **two** secrets at once:

1. `POST $BASE/admin/api-clients/<id>/rotate-secret` — adds a second secret, returned once.
   Both work.
2. The partner switches to the new one and confirms.
3. `POST $BASE/admin/api-clients/<id>/rotate-secret/complete` — deletes the old one.

A second rotation before completing the first is `409` (Cognito's two-secret limit).

## 8. Record it

* The **quarterly access review** (`scripts/api_access_review.py --actor <id> --out
  <audit evidence location>`) lists every client with scopes, approver, self-approval, last
  use and BAA status. The new client appears there from the next run.
* A vault note under `NS_Proccess/` (no ids, no secrets): who, what scopes, why, and the date.

## If something goes wrong

| Symptom | Likely cause | Fix |
|---|---|---|
| `422` on request | a human-only scope, an unknown scope or process, a malformed network | Read the field errors in the body; fix the request. |
| `503 IDENTITY_PROVIDER_UNAVAILABLE` on approve | the api could not reach Cognito, or lacks the permission (`enableApiPlatform` not deployed) | Nothing changed; the row is still pending. Fix and approve again. |
| Partner gets `401` with a fresh token | wrong pool/token URL, client disabled or revoked, token issued before a disable, or their address is outside the allowlist | `GET …/usage` and the client's status. The `401` never says which, deliberately. |
| Partner gets `403 SCOPE_INSUFFICIENT` | the token's `scope` claim lacks it, or the grant does | They must request the scope in the token call **and** we must grant it (`PATCH …/<id>` with `scopes`). |
| Deliveries `dropped` with `CLIENT_INACTIVE` | the owning client was disabled/revoked | `docs/runbooks/revoke-api-client.md` §5. |
