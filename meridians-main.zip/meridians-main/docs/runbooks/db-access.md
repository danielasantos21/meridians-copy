# Runbook — reach the database from a laptop

**Covers:** running `psql` (or any client) against a private RDS instance with **no open
ports anywhere**.
**Arrives:** Phase 2 (the path); usable from Phase 3 (when there is a database).
**Executed:** _not yet._

## The shape of it

The database is in an isolated subnet with no route to the internet, and its security
group admits port 5432 from exactly two sources: the application tasks, and the `ops`
security group. The `ops` group has **zero ingress rules** — nothing can connect *to*
the ops instance either.

That works because AWS Systems Manager Session Manager is an **outbound** connection:
the instance's SSM agent dials the SSM service, and your session rides back down that
connection. So there is no bastion with port 22 open, no key pair to lose, and every
session is a CloudTrail event against your named identity.

```
your laptop ──(AWS API, your SSO credentials)──► SSM ──(agent's outbound tunnel)──►
   ops instance (t4g.nano, private-app subnet, 0 ingress rules)
      └──► RDS :5432   (the ops SG is one of the two the database admits)
```

## Before you start

- **SSO signed in:** `aws sso login --profile <your profile>`. Never a long-lived access
  key (`docs/runbooks/identity-center-bootstrap.md`).
- **The Session Manager plugin installed:** `session-manager-plugin --version`. If not:
  `brew install --cask session-manager-plugin`.
- **The ops instance exists.** It is on by default in staging only. Production opts in
  with `-c createOpsInstance=true` at deploy time, or uses ECS Exec (below).

## 1. Find the instance and the database endpoint

```bash
ENV=staging   # or production

INSTANCE_ID=$(aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=meridian-$ENV-ec2-ops" \
            "Name=instance-state-name,Values=running" \
  --query 'Reservations[0].Instances[0].InstanceId' --output text)

DB_HOST=$(aws rds describe-db-instances \
  --db-instance-identifier meridian-$ENV-rds-main \
  --query 'DBInstances[0].Endpoint.Address' --output text)

echo "$INSTANCE_ID -> $DB_HOST"
```

## 2. Open the port-forwarding session

```bash
aws ssm start-session \
  --target "$INSTANCE_ID" \
  --document-name AWS-StartPortForwardingSessionToRemoteHost \
  --parameters "{\"host\":[\"$DB_HOST\"],\"portNumber\":[\"5432\"],\"localPortNumber\":[\"55432\"]}"
```

Leave it running. `AWS-StartPortForwardingSessionToRemoteHost` is the document that
forwards to a host *the instance can reach*, rather than to a port on the instance
itself — which is why the ops box needs nothing installed on it.

Port `55432`, not `5432`, so it cannot collide with a local Postgres or with the
Supabase stack.

## 3. Connect, in another terminal

```bash
# The credentials come from Secrets Manager. They are never typed and never stored.
export PGPASSWORD=$(aws secretsmanager get-secret-value \
  --secret-id meridian-$ENV-secret-db-app \
  --query SecretString --output text | python3 -c 'import json,sys;print(json.load(sys.stdin)["password"])')

psql "host=127.0.0.1 port=55432 dbname=meridian user=meridian_app sslmode=verify-full sslrootcert=$HOME/.postgresql/rds-ca.pem"
unset PGPASSWORD
```

**`sslmode=verify-full`, not `require`.** `require` encrypts but does not authenticate
the server, so it defends against nobody. Download the CA bundle once:

```bash
mkdir -p ~/.postgresql && curl -o ~/.postgresql/rds-ca.pem \
  https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem
```

## 4. Which role to connect as

| Role | Use it for | Sees PHI? |
|---|---|---|
| `meridian_app` | Everything normal. It has **zero grants on the `phi` schema** (ADR 0012). | No |
| `phi_access` | A PHI investigation you can justify in writing. Every use is an `audit.phi_access` row. | Yes |

Default to `meridian_app`. Connecting as `phi_access` "to have a look" is an access
event under 45 CFR 164.312(b), and it is recorded as one.

## 5. When you are done

Close `psql`, then `Ctrl-C` the session. Confirm nothing is left:

```bash
aws ssm describe-sessions --state Active \
  --query 'Sessions[?Target==`'"$INSTANCE_ID"'`]' --output table
```

## The alternative: ECS Exec (no instance at all)

From Phase 5a there is a cluster, and a one-off task can do the same job for $0 and
with nothing to patch:

```bash
aws ecs execute-command --cluster meridian-$ENV-ecs-main \
  --task <task-id> --container api --interactive --command "/bin/sh"
```

The task already sits in the `app` security group, which the database admits, so `psql`
from inside it needs no tunnel. It requires the task role to allow
`ssmmessages:*` and the service to have `enableExecuteCommand` — Phase 5a's work.
When that lands, an environment can drop the instance with
`-c createOpsInstance=false`.

## When it fails

| Symptom | Cause | Fix |
|---|---|---|
| `TargetNotConnected` | The SSM agent has not registered — usually the instance has no route out (the NAT), or the role lost `AmazonSSMManagedInstanceCore`. | `aws ssm describe-instance-information` — if the instance is absent, check the NAT gateway and the instance role. |
| Session opens, `psql` times out | The database security group does not admit the `ops` group, or you used the wrong endpoint. | `aws ec2 describe-security-groups --group-names meridian-$ENV-sg-data` and check the two ingress rules. |
| `SSL error: certificate verify failed` | Missing or stale CA bundle. | Re-download it (step 3). Do **not** "fix" it by dropping to `sslmode=require`. |
| `permission denied for schema phi` | You are `meridian_app`, and that is correct (ADR 0012). | If you genuinely need it, connect as `phi_access` and expect the audit row. |
