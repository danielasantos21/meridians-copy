# Runbook — email cutover: Resend → SES

**Phase 7.** ADR 0014 (why SES), ADR 0025 (how), plan §3 Phase 7.
**Owner:** Andres. **Duration:** about 30 minutes, plus 24 hours of watching.
**Runs after Phase 9, on ECS.** Not on Render — see the note under the switch below.
**Written 2026-09-16. NEVER EXECUTED** — until it has been run once and the date recorded
here, it is a plan, not evidence (`docs/runbooks/README.md`).

The whole cutover is one environment variable:

```
EMAIL_BACKEND=resend   →   EMAIL_BACKEND=ses
```

and the rollback is the same variable, the other way.

**When it happens: after Phase 9, on ECS — never on Render** (ADR 0025 §3, decided in the
Phase 7 critic round 1). SES reads no key: it takes a signed request from whatever AWS
identity the process runs as, and on Render there is no such identity. Giving it one means
creating a long-lived IAM user with `ses:SendEmail`, putting its access key in a Render
dashboard, and then remembering to delete both at cutover — a static credential outside AWS
for a provider the migration exists to stop needing, bought for a few weeks. The task role
on ECS is the credential, it rotates itself, and it is already written
(`infra/meridian/stacks/compute.py`). So Resend stays live until the application is on ECS,
and the "flip" is then something the task definition has already done.

There is **no dual-send mode** and there must never be one: two transports for one invite is two emails, with two copies of a
one-time code, to a person who was invited once (ADR 0025 §2).

---

## 0. Before you start — what must already be true

Every box below is checked **on the day**, not remembered from Phase 1. Each has a command
whose output you can read without interpreting it.

### 0.1 Production access granted (the long-lead item)

The SES **sandbox** only delivers to verified addresses, at 200 messages a day. An invite
to a new employee from a sandboxed account silently goes nowhere.

```bash
aws sesv2 get-account --region us-east-1 \
  --query '{ProductionAccess:ProductionAccessEnabled,SendQuota:SendQuota,Enforcement:EnforcementStatus}'
```

Required: `ProductionAccess: true` and `Enforcement: HEALTHY`. **If it is false, stop here**
— the request is a support case with a 1-2 business-day turnaround (opened in Phase 1; see
`docs/runbooks/dns-nameserver-switch.md`). This is a human item on
`docs/migration-tracker.md`; nothing in this runbook can work around it.

### 0.2 The identity is verified, and DKIM is signing

```bash
aws sesv2 get-email-identity --email-identity meridiansgrp.com --region us-east-1 \
  --query '{Verified:VerifiedForSendingStatus,Dkim:DkimAttributes.Status,MailFrom:MailFromAttributes}'
```

Required: `Verified: true`, `Dkim: SUCCESS`, `MailFrom.MailFromDomain:
mail.meridiansgrp.com` with `MailFromDomainStatus: SUCCESS`.

### 0.3 DNS answers — checked at the nameservers, not at a cache

The three Easy DKIM CNAMEs (the three selector tokens come from the command in 0.2,
`DkimAttributes.Tokens`):

```bash
for token in <token1> <token2> <token3>; do
  dig +short CNAME "${token}._domainkey.meridiansgrp.com" @ns-<one-of-the-four>.awsdns-<xx>.com
done
```

Each must answer `<token>.dkim.amazonses.com`.

The same `@ns-…` applies to every check below: a `dig` with no `@` answers from whatever
resolver the laptop is using, which during a nameserver change is as likely to be holding a
GoDaddy answer as a Route 53 one. Ask the zone's own nameservers (`dig +short NS
meridiansgrp.com` lists the four).

The MAIL FROM MX and its SPF:

```bash
dig +short MX  mail.meridiansgrp.com @ns-<one-of-the-four>.awsdns-<xx>.com
dig +short TXT mail.meridiansgrp.com @ns-<one-of-the-four>.awsdns-<xx>.com
```

Expected: `10 feedback-smtp.us-east-1.amazonses.com.` and `"v=spf1 include:amazonses.com ~all"`.

DMARC — unchanged, and it is what makes the subdomain align with the apex:

```bash
dig +short TXT _dmarc.meridiansgrp.com @ns-<one-of-the-four>.awsdns-<xx>.com
```

Expected: `"v=DMARC1; p=quarantine; adkim=r; aspf=r; rua=mailto:dmarc_rua@onsecureserver.net;"`.
**`adkim=r` is load-bearing.** SES signs as `mail.meridiansgrp.com`; under strict alignment
that would fail DMARC on every message.

The apex SPF must be **unchanged** — SES is not in it and must not be added (ADR 0017):

```bash
dig +short TXT meridiansgrp.com @ns-<one-of-the-four>.awsdns-<xx>.com
```

Expected to still contain `include:_spf-usg2.ppe-hosted.com` (Proofpoint) and no
`include:amazonses.com`.

### 0.4 The configuration set exists, with its event destination

```bash
aws sesv2 get-configuration-set --configuration-set-name meridian-shared-ses-default --region us-east-1
aws sesv2 get-configuration-set-event-destinations \
  --configuration-set-name meridian-shared-ses-default --region us-east-1
```

Required: `DeliveryOptions.TlsPolicy: REQUIRE`, `ReputationOptions.ReputationMetricsEnabled:
true`, `SuppressionOptions.SuppressedReasons: [BOUNCE, COMPLAINT]`, and one enabled
destination named `meridian-shared-ses-events` with `MatchingEventTypes` =
`BOUNCE, COMPLAINT, REJECT, RENDERING_FAILURE`.

### 0.5 Somebody actually receives the bounce notifications

```bash
aws sns list-subscriptions-by-topic --region us-east-1 \
  --topic-arn arn:aws:sns:us-east-1:<account-id>:meridian-shared-sns-email-events
```

Required: at least one subscription whose `SubscriptionArn` is a real ARN and **not**
`PendingConfirmation`. AWS will not confirm it for you: a human clicks the link in the
confirmation email. An unconfirmed topic means every bounce fires into an empty room, and
the only symptom is silence.

### 0.6 The suppression list is empty

```bash
aws sesv2 list-suppressed-destinations --region us-east-1 --query 'SuppressedDestinationSummaries[].Reason'
```

Expected: `[]`. An entry here is an address SES will refuse to send to, silently as far as
the application is concerned. Do **not** clear entries in bulk to make this pass — an entry
comes off only after the address has been confirmed with its owner by another channel
(ADR 0025 §4), one at a time:

```bash
aws sesv2 delete-suppressed-destination --email-address <address> --region us-east-1
```

### 0.7 One real message has been sent, **from inside the api task**

Not "from a machine with the task's permissions" — there is no such machine, and a laptop
with an admin session proves the identity and the DNS but not the one thing this step is
for: that the **task role's** `ses:FromAddress` condition matches the `From` the code sends.
So the smoke test runs in an ECS Exec session on a running api task, which is the same
process, the same role and the same environment the real send will use:

```bash
aws ecs execute-command --region us-east-1 \
  --cluster meridian-production-cluster \
  --task <task-id> \
  --container api --interactive \
  --command "python scripts/ses_smoke.py --to <your-own-address> --i-know"
```

(`enable_execute_command=True` is already set on the service, and every Exec session is
logged — `infra/tests/test_compute.py`. `--i-know` is required because `APP_ENV` inside that
task names a deployed environment.) The three `MERIDIAN_SES_*` values are already in the task
environment; do not pass them on the command line, or the test proves the values you typed
rather than the values the service has.

It prints one message id and nothing else. Open the message and check the headers:
`Authentication-Results` shows `dkim=pass` for `meridiansgrp.com` and `spf=pass` for
`mail.meridiansgrp.com`, and `dmarc=pass`. A `dkim=pass` for `amazonses.com` instead means
the MAIL FROM MX is not answering and SES fell back (`USE_DEFAULT_VALUE`) — mail still goes
out, but 0.3 is not actually satisfied; fix it before the flip.

Against a deployed environment the script refuses without `--i-know`; that flag exists so
nobody smoke-tests production's sending reputation by reflex.

---

## 1. The flip

**Prerequisite: Phase 9 has cut over and the application is serving from ECS.** Before that
there is nothing to flip — Render has no AWS identity, and the alternative (an IAM user, an
access key pasted into a dashboard, and two things to remember to delete) is refused in
ADR 0025 §3. Until then `EMAIL_BACKEND=resend` is the correct value everywhere, including
the Render dashboards, and this section does not run.

1. **Not during a close, and not on a Friday.** An invite that does not arrive is noticed
   by the person who was invited, on their first day.
2. There is **no variable to set by hand.** `EMAIL_BACKEND=ses`, `MERIDIAN_SES_FROM_EMAIL`,
   `MERIDIAN_SES_CONFIGURATION_SET` and `AWS_REGION` are all in the api task definition
   (`infra/meridian/stacks/compute.py`), and the task role is the credential. Confirm it
   reads `ses` on the revision that is actually running, rather than on the one in the
   template:

   ```bash
   aws ecs describe-task-definition --region us-east-1 \
     --task-definition meridian-production-api \
     --query "taskDefinition.containerDefinitions[?name=='api'].environment[?name=='EMAIL_BACKEND']"
   ```

   If it says `resend`, the last compute deploy was a §2 rollback
   (`-c emailBackend=resend`). The flip is the same deploy **without** that flag —
   `cdk deploy meridian-production-compute --exclusively` — and a new service revision,
   not a dashboard edit.
3. Roll the service (`aws ecs update-service --force-new-deployment`) and watch it come up.
   A missing `MERIDIAN_SES_*` value raises at startup with the variable's name in the
   message (`web_app.py`'s startup guard), so a crash-loop here names its own cause.
4. Send one **real** invite from the application to an address you control, and redeem it.
   The smoke script proves SES works; only the real path proves the application's code path
   does.
5. Record the date in this file and in `docs/migration-tracker.md`.

## 2. Rollback

**It is one context flag and one deploy: `-c emailBackend=resend`** (tracker T:143,
`infra/meridian/stacks/compute.py`). With it the api task definition gets
`EMAIL_BACKEND=resend`, `RESEND_FROM_EMAIL=no-reply@meridiansgrp.com`, and
`RESEND_API_KEY` in its `secrets:` block, read by the execution role from a secret named
**`meridian-production/resend-api-key`**. Any other value of the flag is refused at synth.

1. **Put the key into Secrets Manager first** — once; skip this if the secret already
   exists from an earlier rollback. CDK only *references* it by name: a secret CDK
   created in the same deploy would be empty when the task started, and an empty key is
   Resend's "not configured, skipping email" — silence. Created on the environment's
   `logs` CMK, which is the only key the execution role may decrypt it with. Paste the
   key from the Render dashboard (or the Resend console); never put it in a file or in
   shell history:

   ```bash
   read -rs RESEND_KEY    # paste, then Enter; nothing echoes
   aws secretsmanager create-secret --region us-east-1 \
     --name meridian-production/resend-api-key \
     --kms-key-id alias/meridian-production-kms-logs \
     --secret-string "$RESEND_KEY"
   unset RESEND_KEY
   ```

   A later rotation is `put-secret-value` on the same name, then a service restart.
2. **Deploy compute with the flag**, from the same sha that is running, with the same
   context the last production compute deploy used (the image tags above all):

   ```bash
   cd infra && npx cdk deploy meridian-production-compute --exclusively \
     -c env=production -c emailBackend=resend \
     -c apiImageTag=<running sha> -c webImageTag=<running sha>
   ```

   If the secret does not exist, the new task cannot start (`ResourceNotFoundException`
   in the stopped-task reason), the deployment circuit breaker puts the previous revision
   back, and SES keeps sending. That is the loud failure, deliberately preferred to a task
   that starts and sends nothing.
3. Confirm the running revision reads `resend` (the `describe-task-definition` command in
   §1 step 2) and send one real invite to an address you control.

Rolling **forward** again is §1: the same deploy without `-c emailBackend=resend`. The
secret can stay until the phase is accepted, then it is deleted with the rest of Resend
(ADR 0025 §6). Nothing else changes — the Resend key, the dependency and the account are
all still there until then. Rollback is safe at any point: the two transports share the
same templates, so a message sent either way is the same message. The SES permission on
the task role is not removed by the flag, so neither direction is an IAM change.

The one thing rollback does **not** undo is a suppression-list entry SES created while it
was live. Those persist and are handled per 0.6.

## 3. What to watch for 24 hours

| What | Where | What is wrong |
|---|---|---|
| Bounce rate | Alarm `meridian-production-alarm-ses-bounce-rate`; SES console → Reputation | Over **5 %** is AWS's review threshold; over 10 % risks sending being paused. Any bounce at all on a list this small is worth reading. |
| Complaint rate | Alarm `meridian-production-alarm-ses-complaint-rate`; same console | Over **0.1 %**. On our volume that is one complaint. |
| `REJECT` events | The SNS topic | SES refused the message outright — usually a virus verdict or malformed content. |
| `RENDERING_FAILURE` | Alarm `meridian-<env>-alarm-ses-rendering-failure`, and the SNS topic for the detail | A template broke. Nothing was sent and nothing bounced; this event is the only signal. |
| Suppression list | 0.6's command | A new entry means a hard bounce happened and that address is now blocked until someone acts. |
| Application errors | The api logs | `SES send failed: <Code>` — the code, never the address (ADR 0025). `MessageRejected` usually means the `From` does not match the IAM condition; `AccountSuspended` means stop and open a support case. |

The three alarms (tracker T:39, `infra/meridian/stacks/observability.py` `_ses_alarms`,
`docs/runbooks/alerts.md` §9) page `meridian-<env>-sns-alerts` — which only reaches a person
once that topic's subscription has been confirmed. Until it has, and for the first day
regardless, read this table by hand at the end of day 1: an alarm that has never fired is not
yet evidence that it can.

## 4. Closing the phase

Only after the flip has held for the 24 hours above:

1. Remove `RESEND_API_KEY` / `RESEND_FROM_EMAIL` from `render.yaml`, the dashboards and
   `.env`; drop `resend` from `requirements.txt` and re-lock.
2. Delete the Resend transport from `src/email_service.py`, with a test proving nothing
   imports it.
3. **Andres:** close the Resend account.
4. Close the tracker rows, and note in `docs/compliance/baa-register.md` that the Resend
   row is retired and the Track C "does Resend ever carry PHI" trace closes as moot.
