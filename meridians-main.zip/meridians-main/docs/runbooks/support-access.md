# Runbook — Meridians support access (support mode) and superadmins

**What this is for:** a Meridians superadmin needs to work inside a customer organization
(fix a mapping, invite a user, check a run), or the set of superadmins has to change.
**Decision record:** ADR 0051. **Schema:** Alembic `0035_superadmin_control`.

## 1. Enter an organization (support mode)

1. Sign in with your authenticator code (support mode needs an MFA sign-in; on a development
   laptop with the auth bypass there is no sign-in and nothing is checked).
2. Sidebar → **Superadmin** (ADMIN & SETTINGS). Not shown during "View as role".
3. Pick the organization → **Enter org** (on its row, or on its page).
4. Write the reason — 10 to 500 characters, in plain words. **The organization's admins will
   read it** in Settings → Security → *Meridians support access*.
5. Leave **Also open patient-level data (PHI)** unticked unless the work needs patient
   identifiers. If it does, tick it and give that its own reason.
6. You land on the org's dashboard as its **admin**. A red bar on every screen says
   `Support mode: <Org> — <reason> — ends in 1h 42m`, with a **PHI access** badge if you opened
   it. Use the org's own screens (Settings → Users / Roles, Mappings, runs).
7. **Exit** (on the red bar) when done. It also ends by itself after two hours, or when you
   enter another org.

What is recorded: one `audit.superadmin_access` row per request (with the reason and the
session id), one `audit.support_session` row per start / PHI grant / end / expiry / PHI
refusal, and the session row the org reads. Patient-level data without the PHI grant is
refused (403) and the refusal is recorded.

Need PHI mid-session? `POST /api/v2/superadmin/support-session/phi {"phi_reason": "…"}` (the
grant cannot be taken back in that session; Exit and re-enter without it if it was a mistake).

## 2. Create a customer organization

Superadmin → **New organization**: name, short name, modules. You are **not** made a member.
Then **Enter org** → Settings → Users → **Invite** the customer's first admin. Exit.

## 3. Add or remove a superadmin (two-person rule)

Superadmin → **Superadmins** → **Add superadmin** (their sign-in address — they must have
signed in once — or their user id) with a reason. A **second** superadmin opens the same page
and presses **Approve**. Removing works the same way; the last superadmin can never be removed.
On a development laptop your own request is applied at once.

### Bootstrap: only one superadmin exists

The app refuses (`SECOND_APPROVER_REQUIRED`) because nobody could approve. Use the script, with
the **owner** database credential (staging/production: through `docs/runbooks/db-access.md`;
never commit it, never put it in `.env` in the repo):

```bash
MERIDIAN_DATABASE_URL='<owner DSN>' python3 scripts/add_superadmin.py \
    --user-id <uuid> --reason "Second superadmin for the two-person rule" --dry-run
MERIDIAN_DATABASE_URL='<owner DSN>' python3 scripts/add_superadmin.py \
    --user-id <uuid> --reason "Second superadmin for the two-person rule"
```

It writes the `superadmins` row and an `audit.superadmin_change` row (`bootstrap_added`, the
reason, and the database login) in one transaction. `--remove` removes (never the last one).
On the Supabase backend there is no audit table: the script prints the record — paste it into
the change ticket.

## 4. Reviewing access (monthly activity review, 164.308(a)(1)(ii)(D))

```sql
-- Support sessions in the last 30 days, ONE org at a time: the table has FORCE RLS, so even
-- the owner sees an org's rows only with that org set (or read the org's own log in the app).
SET app.org_id = '<org id>';
SELECT s.started_at, s.user_id, s.actor_email, s.reason, s.phi_access,
       s.phi_reason, s.ended_at, s.end_reason
  FROM public.support_sessions s
 WHERE s.org_id = '<org id>' AND s.started_at > now() - interval '30 days'
 ORDER BY s.started_at;
RESET app.org_id;
-- The audit tables have no RLS: every org at once.
SELECT * FROM audit.support_session WHERE at > now() - interval '30 days' ORDER BY id;
SELECT * FROM audit.superadmin_change ORDER BY id;
SELECT user_id, org_id, count(*) FROM audit.superadmin_access
 WHERE support_session_id IS NOT NULL AND at > now() - interval '30 days'
 GROUP BY 1, 2;
```

Look for: PHI grants (each needs a believable reason), sessions with no matching ticket,
`phi_refused` rows, any `bootstrap_*` row, and superadmin changes nobody remembers.

## 5. Local development

`scripts/local_db_bootstrap.sh` + `scripts/seed_local_dev.py`: the built-in dev identity
(`dev@localhost`) is a superadmin and can enter **Synthetic Second Clinic** from
`/superadmin`. "Sign in as" a non-superadmin to see the console 404, or as Synthetic Second
Clinic's admin to read the support log.
