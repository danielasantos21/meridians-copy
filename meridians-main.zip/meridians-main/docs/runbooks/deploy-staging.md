# Runbook — deploy staging from GitHub Actions

**Covers:** dispatching `.github/workflows/deploy.yml` to build, scan, push and roll out the
`api` and `web` images to the staging ECS services.
**Arrives:** Phase 5a. **Run by:** whoever is deploying.
**Time:** ~25 minutes end to end (tests ~12, arm64 build ~8, deploy and wait ~5).
**Executed:** _never. The workflow has not been run once. It stays `workflow_dispatch`-only
until the cost approval in §1, and this line is where the first run's date goes._

> **This runbook is for staging.** The workflow's only environment option is `staging`, and
> the deploy command carries `--exclusively`, so CDK deploys `meridian-staging-compute` and
> nothing it depends on. Production is deployed by hand, one stack at a time, with the
> runbook open.
>
> **What that boundary is, precisely** (critic P5AR3-03, 2026-09-16). This runbook used to
> say the IAM role "has CloudFormation permission on `meridian-staging-compute` and nothing
> else", and that is not the protection it sounds like. `cdk deploy` assumes
> `cdk-hnb659fds-deploy-role`, which `cdk bootstrap` created account-wide and which passes
> `cdk-hnb659fds-cfn-exec-role` — bootstrapped here with `AdministratorAccess`. So the
> role's own one-stack CloudFormation statement is not the path a deploy takes. Two things
> genuinely hold the line today, and both are in tracked files you can read before you
> dispatch:
>
> 1. **`--exclusively`** on the `npx cdk deploy` line in `.github/workflows/deploy.yml`.
> 2. **The trust policy**: `meridian-shared-iam-github-deploy` can only be assumed by a job
>    of this repository that runs in the **`staging` GitHub Environment** (OIDC subject
>    `repo:andressbj45/meridians:environment:staging`), for one hour, with
>    `sts.amazonaws.com` as the audience. Only `deploy.yml`'s `push` and `deploy` jobs
>    declare that environment; any other workflow — on any branch, in a fork, on a tag or
>    a pull request — gets a `ref:` subject and is refused. The Environment's
>    deployment-branch policy (repository settings → Environments → staging) admits only
>    `aws-migration` and `main`, so the branch restriction still holds, one level up.
>
> `docs/migration-tracker.md` carries the row that closes the gap: bootstrap a staging-only
> qualifier with scoped `--cloudformation-execution-policies` and point this role at those
> bootstrap roles. It is owned by Andres and due **before the first dispatch**, so if you are
> reading this to run the workflow for the first time, check that row first.

> **By hand (`scripts/staging_deploy.sh compute`):** the hand-created secrets
> `meridian-staging/qbo-oauth` and `meridian-staging/ecw-db` are wired into the api only
> with `-c qboOAuth=true` / `-c ecwDb=true`. The script adds each flag whenever its secret
> exists, so a by-hand deploy never drops QuickBooks or eCW. With `qbo-oauth` it also passes
> `-c qboEnvironment=production`: that secret holds Daniela's production Intuit keys, so staging
> connects the real companies (redirect URI `https://staging-app.meridiansgrp.com/api/v2/qbo/connection/callback`
> must be registered in her Intuit app). This workflow does not yet:
> pass both flags in `deploy.yml` before dispatching it once those secrets exist.
> These flags alone do not let a P&L run on AWS: `require_ecw()` (`src/api/v2/pnl_routes.py`)
> also needs `ECW_ORG_ID`, and refuses on the RDS backend until eCW reads are audited there.

---

## 1. Preconditions — all four, in this order

**a. The cost approval exists.** A running staging environment is ~$129/month taxed, about
half the ~$250 account ceiling (plan §5). `docs/aws-migration-prompt.md` is explicit: no
billable resource is created before Andres approves it. Nothing in this file may be run
until that approval is recorded in the phase report. This is why the workflow has no
`push:` trigger and why it will not get one.

**b. `meridian-staging-edge` is up.** The compute stack registers its two ECS services into
the edge stack's ALB target groups (ADR 0020, ADR 0022). If `edge` was torn down at the end
of the last session, the deploy fails on a missing CloudFormation import — loudly, before
it changes anything, which is the intended failure. Bring the transient stacks up first:

```bash
scripts/staging_session.sh up
```

That deploys `edge`, `compute`, `api` and `observability` in dependency order and starts
the database, which stops itself nightly (D-15). Confirm:

```bash
aws cloudformation describe-stacks --stack-name meridian-staging-edge \
  --query 'Stacks[0].StackStatus' --output text
```

`CREATE_COMPLETE` or `UPDATE_COMPLETE`. Anything else — fix that first.

**c. The four repository variables are set.** Settings → Secrets and variables → Actions →
**Variables** (not Secrets — none of these is secret, and a masked value in a CDK diff is a
log nobody can read). They are variables rather than committed values because an account id
and a zone id are identifiers, and no identifier is committed (ADR 0001).

| Variable | What | Where to get it |
|---|---|---|
| `AWS_DEPLOY_ROLE_ARN` | `meridian-shared-iam-github-deploy` | `aws iam get-role --role-name meridian-shared-iam-github-deploy --query Role.Arn --output text` |
| `AWS_ACCOUNT_ID` | Composes the ECR registry hostname | `aws sts get-caller-identity --query Account --output text` |
| `MERIDIAN_CF_PREFIX_LIST_ID` | Needed at **synth** time — the whole app synthesizes even for a one-stack deploy | `infra/README.md`, "Identifiers passed with `-c`" |
| `MERIDIAN_HOSTED_ZONE_ID` | Same | Same |

The role itself is created by `meridian-shared-foundation`; if it does not exist, deploy
that stack first.

**d. The commit is the one you mean.** The workflow tags both images `${{ github.sha }}`, and
both ECR repositories are `IMMUTABLE`. There is no floating tag to correct afterwards: the
sha you dispatch from is the sha that runs.

---

## 2. Dispatch

Actions → **deploy** → Run workflow.

1. **Use workflow from** — the branch you are deploying. Only `aws-migration` and `main` can
   assume the role; any other branch fails at `configure-aws-credentials` with an
   `AssumeRoleWithWebIdentity` error, which is the trust policy working.
2. **environment** — `staging`. It is the only option.
3. **confirm** — type `deploy-staging`, exactly. Anything else fails the `guard` job and
   nothing is built, pushed or deployed.

From the CLI instead:

```bash
gh workflow run deploy.yml --ref aws-migration \
  -f environment=staging -f confirm=deploy-staging
gh run watch
```

---

## 3. What each job is proving

| Job | Proves | If it fails |
|---|---|---|
| `guard` | The confirm string was typed. | Nothing happened. Re-dispatch. |
| `test` | `pytest tests` passes on this commit, with the CI backends (`sqlite`/`local`/`disabled`) and the skip audit. | Fix the commit. Do not dispatch again to "see if it passes". |
| `build` | Both images build for `linux/arm64`. | Usually a Dockerfile change. An amd64 image would start and then die with `exec format error`, which is why the platform is pinned. |
| `scan` | Trivy finds no HIGH or CRITICAL in either image. | Bump the base image or the package. If it genuinely cannot be fixed, it goes in `.trivyignore` with a CVE, a reason, an owner and an expiry — reviewed in a diff, not typed into the workflow. |
| `push` | Both images reach ECR under the commit sha. | An `ImageTagAlreadyExists` here means this sha was pushed before: nothing to do, the images are already there, and you can re-run just the `deploy` job. |
| `deploy` | `cdk deploy --exclusively` on the compute stack, then `aws ecs wait services-stable`. | See §4. |

**The wait is the real gate.** CDK returns when CloudFormation returns, and CloudFormation
returns when the service update is *accepted*, not when the new tasks pass health checks.
Without the wait, a container that crash-loops on a bad image is a green workflow and a
broken environment.

**`api` runs exactly one task** until Phase 11 (`compute.py` module docstring), so every api
deploy is 3–6 minutes of hard downtime. Deploy outside business hours, and **never during a
close**.

---

## 4. When the deploy fails

**The service never stabilizes.** The deployment circuit breaker rolls the service back to
the previous task definition on its own; the `wait` step then fails, which is how you hear
about it. Read why:

```bash
aws ecs describe-services \
  --cluster meridian-staging-ecs-main \
  --services meridian-staging-ecs-svc-api \
  --query 'services[0].events[:10]'

aws logs tail /meridian/staging/ecs/api --since 15m
```

A task that starts and immediately dies is almost always the image (wrong architecture, a
missing native library) or a secret the execution role cannot read. A task that starts and
fails health checks is the app.

**The stack is stuck in `UPDATE_ROLLBACK_FAILED`.** Do not dispatch again — the concurrency
group would queue behind a stack CloudFormation will not let anyone touch. Continue the
rollback by hand and then dispatch the previous good sha:

```bash
aws cloudformation continue-update-rollback --stack-name meridian-staging-compute
```

---

## 5. Rollback

**There is no rollback button, and that is on purpose.** A rollback here is a deploy of a
different, already-tested commit.

1. **Redeploy the previous sha.** Dispatch this workflow again with **Use workflow from** set
   to the last good commit. Its images are already in ECR (the repositories keep the last 10),
   so `build`, `scan` and `push` are cheap or idempotent, and `deploy` points the task
   definitions back at that tag.
2. **Or destroy.** If the environment is wedged and nobody needs it, `scripts/staging_session.sh
   down` destroys the four transient stacks, takes one on-demand backup and stops the
   database. The VPC, the data stack and the auth pool survive — that is the whole of
   ADR 0020. Then bring it back with `up` and dispatch a known-good sha.

Either way, **record what happened in the phase report**. A deploy that had to be rolled back
is the most useful thing a phase report can contain.

---

## 6. What this workflow deliberately does not do

- **It does not deploy `meridian-staging-auth`.** That stack's User Migration Lambda bundles a
  gitignored snapshot of the legacy users that must be regenerated the same day
  (`-c requireLegacySnapshot=true`, `docs/runbooks/cognito-user-migration.md`). A runner has
  neither the snapshot nor the Supabase credentials to make one, so a CI deploy of it would
  ship a Lambda that fails every sign-in closed. `--exclusively` keeps it out, and the role's
  CloudFormation permission is scoped to the compute stack so the boundary holds twice.
- **It does not deploy `data`, `vpc` or the shared stacks.** Same reason, same two mechanisms.
- **It does not run migrations.** Alembic is `docs/runbooks/migrations.md`, run deliberately,
  with the load-order rules that runbook carries.
- **It does not push a floating tag.** No `latest`, no `staging-latest`. Immutable tags are
  what make "which code is running" answerable from the task definition alone.

---

> **Ask Meridian (T:254).** The api task calls Amazon Bedrock. Before the first Ask works in an
> account/region, model access must be enabled by hand in the Bedrock console (region
> `us-east-1`, or the `-c bedrockRegion` value) for Claude Haiku 4.5, Claude Sonnet 5.5 and
> Claude Sonnet 4.6. Andres does this; IAM alone is not enough, and the app shows "not
> available for this account" until it is done. The $10/month cap is the app's own estimate.

## 7. Smoke tests after a green deploy

Two checks the workflow cannot make for you. Run both the first time staging comes up,
and the first one after any change to the edge.

### 7.1 The app answers through CloudFront

```bash
curl -s -o /dev/null -w '%{http_code}\n' https://staging-app.meridiansgrp.com/
curl -s -o /dev/null -w '%{http_code}\n' https://staging-app.meridiansgrp.com/api/v1/health
```

Both 200. A 403 on the second is the origin-verify control working and the request not
having come through CloudFront — check where you sent it.

### 7.2 A forged `CloudFront-Viewer-Address` does not reach the api

**What this proves.** `api.deps.client_address` prefers `CloudFront-Viewer-Address` over
walking `X-Forwarded-For`, because CloudFront writes it about the viewer's own socket. That
is only safe because **CloudFront replaces any `CloudFront-*` header the viewer sent** — AWS's
documented behaviour, which no test in this repository can exercise. This is the check that
turns it from a claim into a verified fact (P5AR5-04).

Send one, from a machine with a known public address:

```bash
MY_IP=$(curl -s https://checkip.amazonaws.com)
echo "this machine is $MY_IP"

# Spend a rate limit deliberately: the credential limiter buckets on the caller.
for i in $(seq 1 6); do
  curl -s -o /dev/null -w '%{http_code} ' \
    -H 'CloudFront-Viewer-Address: 203.0.113.9:1' \
    -H 'Content-Type: application/json' \
    -d '{"email":"nobody@example.test","password":"wrong"}' \
    https://staging-app.meridiansgrp.com/api/v2/auth/login
done; echo
```

- [ ] The sixth response is **429**, not 401. The limiter bucketed on *this machine*, so the
      forged address was not what the api keyed on — it never arrived.
- [ ] The api log line for those requests names `$MY_IP` (or the viewer address CloudFront
      wrote), never `203.0.113.9`:

      ```bash
      aws logs tail /meridian/staging/ecs/api --since 5m | grep -c 203.0.113.9   # must print 0
      ```

If a `203.0.113.9` ever appears, **stop**: the edge is forwarding a viewer-sent
`CloudFront-*` header and the rate limiter is choosable by the caller. The fix is the origin
request policy (`edge.py`), and until it is deployed `client_address` must be made to ignore
the header.
