# Runbook — download the production database to the PHI drive

**What:** a copy of the production `meridian` database as one `pg_dump` file on
`/Volumes/MeridianPHI`. The file is PHI: it never leaves that drive.
**Prerequisites:** `phi-mount` done; `aws sso login --profile meridians-admin`;
`session-manager-plugin`, `pg_dump` installed; `~/.postgresql/rds-ca.pem` present (`db-access.md`).

## 1. Make sure the ops instance exists (turn it on if absent)
```bash
export AWS_PROFILE=meridians-admin AWS_REGION=us-east-1
OPS_ID=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=meridian-production-ec2-ops" \
  "Name=instance-state-name,Values=running" --query 'Reservations[0].Instances[0].InstanceId' --output text)
echo "$OPS_ID"      # i-... = fine; "None" = deploy it (next block)
```
If `None`, from `infra/` (AWS write; diff first with `cdk diff ... --no-change-set`, same flags):
```bash
npx cdk deploy meridian-production-edge --exclusively --no-rollback -c env=production \
  -c cloudfrontPrefixListId=pl-3b927c52 -c hostedZoneId=Z0621688X1CV6X15E2QH \
  -c originVerifyActiveVersion=AWSCURRENT \
  -c originVerifyCloudFrontVersionId=2fd2fe21-06ef-62b6-6f10-08bb677a8806 -c createOpsInstance=true
```
Never drop a `-c` flag (see Blocker B2 in `practice-cutover-1.md`).

## 2. Open the tunnel (background) and dump
```bash
DB_ID=meridian-production-rds-main; CA=~/.postgresql/rds-ca.pem; PORT=55432
DB_HOST=$(aws rds describe-db-instances --db-instance-identifier $DB_ID --query 'DBInstances[0].Endpoint.Address' --output text)
aws ssm start-session --target "$OPS_ID" --document-name AWS-StartPortForwardingSessionToRemoteHost \
  --parameters "{\"host\":[\"$DB_HOST\"],\"portNumber\":[\"5432\"],\"localPortNumber\":[\"$PORT\"]}" </dev/null >/dev/null 2>&1 &
TUN=$!; sleep 8; nc -z 127.0.0.1 $PORT && echo tunnel up

# password into the environment only (never printed)
export PGPASSWORD=$(aws secretsmanager get-secret-value --secret-id "$(aws rds describe-db-instances \
  --db-instance-identifier $DB_ID --query 'DBInstances[0].MasterUserSecret.SecretArn' --output text)" \
  --query SecretString --output text | python3 -c 'import json,sys; print(json.loads(sys.stdin.read())["password"])')

OUT=/Volumes/MeridianPHI/Meridian/db-download-$(date +%F); mkdir -p "$OUT" && chmod 700 "$OUT"
pg_dump -Fc -f "$OUT/meridian-$(date +%Y%m%d-%H%M).dump" \
  "host=$DB_HOST hostaddr=127.0.0.1 port=$PORT dbname=meridian user=meridian_migrator sslmode=verify-full sslrootcert=$CA"
chmod 600 "$OUT"/*.dump; shasum -a 256 "$OUT"/*.dump
```
Success: a non-empty file and a hash; `pg_restore -l <file> | head` lists tables.
Add `--exclude-schema=mart --exclude-schema=analytics` to the `pg_dump` line: they are a rebuildable copy of the outside eCW mart (`ecw-mart.md` §5) and hold patient-level rows; refill them with the nightly loader after a restore.
Note the `phi` schema is included (no `--schema` flag), so this is full PHI.

## 3. Close the tunnel
```bash
pkill -P $TUN; kill $TUN; unset PGPASSWORD
```
Optional: remove the ops instance again (about $3.70/month if left on) by redeploying with
`-c createOpsInstance=false`.

## Alternative (two lines)
RDS snapshot export to S3 (`aws rds start-export-task`, Parquet in an encrypted bucket) needs no tunnel
but produces Parquet, not a restorable dump, and lands PHI in S3. Use it only for analytics, not for a copy you restore.
