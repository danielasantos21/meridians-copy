# Runbook — moving `meridiansgrp.com` nameservers from GoDaddy to Route 53

**Arrives:** Phase 1 (the zone), executed before Phase 9 (the cutover).
**Owner:** Andres — step 4 can only be done in the GoDaddy account.
**Reversible:** yes, completely, for as long as the GoDaddy zone is left alone. See §6.
**Related:** ADR 0017 (why a Route 53 zone), ADR 0014 (SES),
`docs/architecture/dns.md` (what the records are), `infra/meridian/stacks/dns.py`
(the zone as code).

---

## 0. What this actually does, in one paragraph

A domain has two separate things: a **registrar** (who you rent the name from — GoDaddy,
and that is not changing) and **nameservers** (the four servers that answer "what is the IP
of meridiansgrp.com?"). Today GoDaddy answers. After this runbook, Route 53 answers. The
switch is instantaneous at the registry but takes up to 48 hours to reach every resolver on
the internet, during which **some** of the world asks GoDaddy and **some** asks Route 53. If
the two zones do not give identical answers, whatever differs breaks for a random half of
the world — and the first thing anyone notices is email.

So the whole risk of this procedure is concentrated in one requirement: **the two zones must
answer identically before you switch.** §3 is that check, and it is not optional.

## 1. Preconditions

- [ ] `meridian-shared-dns` is deployed (`npx cdk deploy meridian-shared-dns
      --parameters EmailEventsAddress=<mailbox>`), and `cdk deploy` printed
      `NameServer1`–`NameServer4`. Write them down.
- [ ] You can sign in to the GoDaddy account that holds `meridiansgrp.com`.
- [ ] `dig` is available (`dig -v`). It is on macOS by default.
- [ ] Nobody is mid-close and no payroll or revenue run is scheduled in the next 48 hours.
- [ ] A weekday morning, not a Friday afternoon. The tail is up to two days long and you
      want to be around for it.

## 2. Lower the TTLs first — **at least 24 hours before the switch**

TTL is how long a resolver caches an answer. A record with a 3600-second TTL can keep
serving the old answer for an hour after you change it, which is an hour you cannot shorten
once you have started. Lowering TTLs ahead of time is what buys you a fast rollback.

The records the CDK creates already carry a 300-second TTL on the two that move at cutover
(apex `A`, `www` `CNAME`). **The ones you must lower by hand are at GoDaddy**, because those
are the answers currently in caches:

1. GoDaddy → My Products → `meridiansgrp.com` → DNS → Manage Zones.
2. For **every** record in the zone, set TTL to the lowest GoDaddy offers (600 seconds /
   "1/2 hour"; some record types allow "custom" → 300).
3. Note the time. **Wait at least as long as the *old* TTL was** (typically 1 hour, up to a
   day if anything was set to 86400) before going further, so that the long-cached answers
   have expired and everyone is now holding a short-lived one.

Also lower the **registrar-level NS TTL** if GoDaddy exposes it (it usually does not — it is
typically 3600 at the registry and cannot be changed). If you cannot, that is the floor on
your rollback speed: about an hour.

## 3. Verify every record against the Route 53 nameservers — **before** switching

`dig @<nameserver>` asks one specific server directly, bypassing caches and bypassing
whoever is currently authoritative. This is how you read the Route 53 zone while the world
is still being served by GoDaddy.

Set the first Route 53 nameserver from the `cdk deploy` output:

```bash
NS=ns-XXX.awsdns-XX.com          # NameServer1 from the stack output
```

**The list of records to check is not in this runbook, and deliberately so.** It is
`infra/dns/meridiansgrp.com.zone.json` — a `dig` export of the live GoDaddy zone, checked
in, and asserted entry-by-entry against the synthesized template by
`infra/tests/test_dns.py`. A list written out in prose here would be a second copy to keep
in sync, and the first version of this runbook proved that: it listed five records while
the zone actually served **sixteen**. Eleven were missing from the stack entirely — the
Microsoft 365 CNAMEs, the Skype SRV records, GoDaddy's `_domainconnect`, and `ai`, which
is the *other* owner's production application (ADR 0001) — and every one of them would
have gone dark at the switch. Two of the sixteen were found not by the export at all but
by the candidate-name sweep in §3a, which is why that sweep exists.

So the loop reads the file:

```bash
cd infra                                          # the export lives here
ZONE=dns/meridiansgrp.com.zone.json

python3 -c '
import json, sys
for r in json.load(open(sys.argv[1]))["records"]:
    if not r.get("self_delegation"):   # staging-* NS: Route 53 answers those names itself
        print(r["type"], r["name"].rstrip("."))
' "$ZONE" | while read -r type name; do
  echo "== $type $name"
  echo "  godaddy : $(dig +short @ns25.domaincontrol.com "$type" "$name" | sort | tr '\n' ' ')"
  echo "  route53 : $(dig +short @"$NS"                  "$type" "$name" | sort | tr '\n' ' ')"
done
```

Every line must show **identical** answers, modulo order (DNS does not guarantee order —
hence the `sort`). Two exceptions, both expected:

- **TTLs may differ** and that is fine. `+short` does not print them anyway. The apex `A`
  and `www` `CNAME` are 300 s in Route 53, against GoDaddy's 600 and 3600 respectively, on
  purpose: they are the records that move at the Phase 9 cutover. A TTL difference cannot
  break the switch; only a *value* difference can. (The export records GoDaddy's own TTL
  in a `godaddy_ttl` field, so `scripts/dns_zone_diff.py` compares like with like.)
- **`mail.meridiansgrp.com` and the DKIM tokens** are Route 53-only. See below.

The rows that will hurt most if they differ:

| Query | Expected answer | If this is wrong |
|---|---|---|
| `MX meridiansgrp.com` | `0 mx1-usg2.ppe-hosted.com.` and `mx2`, `mx3` | **Inbound mail stops.** This is the worst failure in the runbook. |
| `TXT meridiansgrp.com` | the SPF string **and** `NETORGFT20419956.onmicrosoft.com` | Outbound mail starts failing SPF; Microsoft 365 loses domain verification. |
| `TXT _dmarc.meridiansgrp.com` | `v=DMARC1; p=quarantine; adkim=r; aspf=r; rua=...` | Mail that fails alignment gets quarantined instead of reported — or the reverse. |
| `CNAME autodiscover.meridiansgrp.com` | `autodiscover.outlook.com.` | **Every Outlook profile in the company stops configuring itself.** The symptom is "Outlook keeps asking for my password". |
| `CNAME selector1._domainkey…` and `selector2` | `selector{1,2}-meridiansgrp-com._domainkey.netorgft20419956.n-v1.dkim.mail.microsoft.` | Microsoft 365's outbound DKIM breaks. It presents as "our mail is going to spam", not as a DNS fault, so it can run for days before anyone connects it to the switch. |
| `CNAME lyncdiscover`, `sip`, `msoid` · `SRV _sipfederationtls._tcp`, `_sip._tls` | as exported | Teams / Skype for Business sign-in and federation break. |
| `CNAME email.meridiansgrp.com` | `email.secureserver.net.` | GoDaddy webmail stops resolving. |
| `A meridiansgrp.com` | `216.24.57.1` | The website goes down at the bare domain. |
| `CNAME www.meridiansgrp.com` | `meridian-web-c2sv.onrender.com.` | The website goes down at `www`. |
| `CNAME ai.meridiansgrp.com` | `d159v1qnwsd8mk.cloudfront.net.` | **The *other* owner's production application goes down** (ADR 0001) — an outage we caused in somebody else's product. See §3d. |
| `CNAME _domainconnect.meridiansgrp.com` | `_domainconnect.gd.domaincontrol.com.` | Nothing, after the switch. Copied so the zone stays a byte-for-byte copy. |

Then the records only Route 53 has, which GoDaddy will *not* answer — that asymmetry is
expected and fine, because nothing depends on them yet:

```bash
dig +short @"$NS" MX  mail.meridiansgrp.com     # 10 feedback-smtp.us-east-1.amazonses.com.
dig +short @"$NS" TXT mail.meridiansgrp.com     # "v=spf1 include:amazonses.com ~all"
dig +short @"$NS" CNAME <token1>._domainkey.meridiansgrp.com   # three of these
```

The three DKIM token names come from the SES console (Verified identities →
`meridiansgrp.com` → DKIM) or `aws sesv2 get-email-identity --email-identity
meridiansgrp.com --query 'DkimAttributes.Tokens'`.

### 3a. Sweep the other direction — GoDaddy → the export

Everything above asks "does Route 53 answer what the export says?". That check cannot
find a record that is live at GoDaddy and **in neither file**, and that is the record
that goes dark. So the sweep runs the other way, twice, by two different mechanisms.

**Why twice.** A zone-file export contains the records GoDaddy chose to write into it;
a name sweep contains the names somebody thought of. Neither alone is complete. Running
both on 2026-09-15 is what turned fourteen record sets into **sixteen** — the first
export had missed `ai` (the *other* owner's application, ADR 0001) and `_domainconnect`
(GoDaddy's own Domain Connect record).

**(a) Export the GoDaddy zone file and diff it.**

1. GoDaddy → My Products → `meridiansgrp.com` → **DNS** → Manage Zones.
2. The **⋮** (vertical dots) menu, top right of the record table → **Export Zone File**.
   You get a BIND-format `.txt` download.
3. Diff it against the checked-in export:

```bash
venv/bin/python scripts/dns_zone_diff.py ~/Downloads/meridiansgrp.com.txt
```

It exits **0** when the two agree and **1** with every difference printed. `--help`
explains the options; `--ignore-ttl` reports only value differences, which is the
weaker check — use it only when a TTL difference is already understood and recorded
as a `godaddy_ttl` field.

Two things it does that are easy to assume it does not (finding M-J): it compares
hostnames **case-insensitively**, because GoDaddy's form preserves whatever case was
typed and `AutoDiscover.Outlook.COM.` is the same record as `autodiscover.outlook.com`;
and it **does** compare `NS` records below the apex. Only the apex `NS` set and the
`SOA` are skipped, because those are the nameservers themselves. An `NS` record on a
subdomain is a delegation — `status.meridiansgrp.com` pointed at a status-page
provider, say — and it goes dark at the switch exactly like a CNAME. `TXT` values keep
their case: a DKIM key is base64 and its case is load-bearing.

**(b) Sweep candidate names straight at the GoDaddy nameservers.**

A zone file can be stale or partial. This asks the authoritative server about a list of
names that commonly exist and commonly get forgotten — mail plumbing, Microsoft 365
discovery, SaaS verification records, and the obvious application hostnames.

**Run it with `bash`, not `zsh`.** This is not style. zsh does **not** word-split an
unquoted `$NAMES`, so under the default macOS shell the loop runs once, on the whole
string, `dig`s one nonsense name, finds nothing, and prints a clean empty result that
looks exactly like "no forgotten records". Either start the sweep with `bash -c` as
below, or use `${=NAMES}` in zsh.

```bash
bash <<'SWEEP'
GD=ns25.domaincontrol.com

# Mail plumbing, Microsoft 365 discovery, SaaS verification names, and the obvious
# application hostnames. NS is swept too: a subdomain NS record is a delegation to
# somebody else's nameservers and goes dark at the switch like any other record.
NAMES="www mail ai api app staging autodiscover selector1._domainkey \
selector2._domainkey email lyncdiscover sip msoid _dmarc _sipfederationtls._tcp \
_sip._tls ftp webmail smtp imap pop calendar portal admin dev test blog shop cdn \
static assets docs help status m remote vpn ns1 ns2 _acme-challenge \
enterpriseenrollment enterpriseregistration _github-challenge _domainconnect \
s1._domainkey s2._domainkey google._domainkey k1._domainkey default._domainkey \
mail._domainkey _mta-sts _smtp._tls _dnsauth _atlassian-domain-verification \
_amazonses _acme-challenge.www"

for n in $NAMES; do
  for t in A AAAA CNAME TXT MX SRV NS; do
    out=$(dig +time=3 +tries=2 +noall +answer @"$GD" "$n.meridiansgrp.com" $t)
    case "$out" in
      *"timed out"*) echo "RETRY $n $t" ;;   # a timeout is NOT an empty answer
      "")            ;;
      *)             echo "$out" ;;
    esac
  done
done | sort -u

# The apex itself, which has no label to sweep.
for t in A AAAA MX TXT CAA; do dig +noall +answer @"$GD" meridiansgrp.com $t; done
SWEEP
```

**Every line of output must correspond to an entry in
`infra/dns/meridiansgrp.com.zone.json`.** A hit that is not in the export **fails this
check** — it is a live record that would go dark at the switch. A `RETRY` line is not a
pass: re-run that name before believing the result.

**Why the twelve names at the end of the list** (added 2026-09-15, finding L-F). They
are the verification and mail-authentication names that get created once, by a tool, and
then forgotten by everyone: `s1`/`s2._domainkey` (SendGrid, Zoho),
`google._domainkey` (Google Workspace), `k1._domainkey` (Mailchimp/Mandrill),
`default._domainkey` and `mail._domainkey` (the two most common self-hosted DKIM
selectors), `_mta-sts` and `_smtp._tls` (MTA-STS and TLS reporting),
`_dnsauth` (Microsoft), `_atlassian-domain-verification`, `_amazonses` (a *second* SES
identity in another account would own one), and `_acme-challenge.www` — the `www`
variant, which is a different name from the apex `_acme-challenge` already on the list
and is the one a Let's Encrypt renewal for `www` depends on.

*Recorded result, 2026-09-15 (re-run):* the sweep returned the same **sixteen** record
sets that are in the export, and **none of the twelve new candidate names resolved**.
Nothing was added to `infra/dns/meridiansgrp.com.zone.json`. `mail` is deliberately
absent at GoDaddy — it is the SES MAIL FROM subdomain and exists only in Route 53. The
apex `NS` set answers `ns25`/`ns26.domaincontrol.com`, which is expected and is the one
thing the switch is *meant* to change.

**Add the list to, do not replace it.** When a new SaaS tool is introduced, add its
verification name to `NAMES` here so the next run covers it.

### 3c. What to do with anything either sweep finds

Anything live at GoDaddy and not in the export must be:

1. added to `infra/dns/meridiansgrp.com.zone.json` (name, type, ttl, values, and a `why`
   line saying what breaks without it);
2. added to `infra/meridian/stacks/dns.py`;
3. proved by `../venv/bin/python -m pytest tests/test_dns.py -q` — the parametrized test
   fails until the stack matches the export;
4. deployed, and re-verified through the loop in §3.

**Copy it even when it looks pointless.** `_domainconnect` is inert the moment GoDaddy
stops being authoritative, and it was copied anyway. Deciding which live records "do not
matter" is exactly how a record goes dark, and the cost of being wrong is asymmetric.

**Before you continue.** Do not hand-add it in the Route 53 console: the zone is code, and
a console edit is silently deleted by the next `cdk deploy`.

### 3d. The record that is not ours

`ai.meridiansgrp.com` is a CNAME to a CloudFront distribution belonging to **the other
owner's application** in the shared AWS account (ADR 0001). It is in the zone, in the
export and in `dns.py` for one reason: the switch must not take it down.

- **Never** repoint, shorten, remove or "tidy" it.
- It is in the Phase 2 roll-back checklist and in §5 below: **confirm
  `ai.meridiansgrp.com` still serves afterwards.**
- Its target is public DNS — anyone can `dig` it — so it is written down here without
  any secrecy problem.

**Gate: do not proceed past this point until every row above matches, both sweeps are
clean, and `dns_zone_diff.py` exits 0.**

### 3e. SES cannot verify before the switch — and you may not want to wait

`meridian-shared-dns` writes the three Easy DKIM CNAMEs and the MAIL FROM `MX` and `TXT`
records **into the Route 53 zone**. Nobody is asking Route 53 yet, so SES sits at
`Pending` / `DkimAttributes.Status: PENDING` until §4 happens. That is expected, not a
fault — but it blocks Phase 4 (Cognito sends through SES) and Phase 7, and SES
production access (§7) has its own 1–2 day lead time on top.

There are two ways out and **Andres picks one** — there is a tracker row for the
decision:

**Option A — switch the nameservers early.** Do this runbook now rather than close to
Phase 9. It is the cleaner option: one set of records, in code, in one place. The cost is
that the 48-hour propagation tail happens now, and every subsequent DNS change is a
`cdk deploy` rather than a GoDaddy form.

**Option B — hand-add five records at GoDaddy as an interim.** SES verifies against
whoever is authoritative, so the same five values added at GoDaddy verify the identity
today, with no nameserver switch. They then exist in both zones, which is harmless
because they are identical, and they are deleted from GoDaddy after the switch.

Get the values from the deployed stack, never from a screenshot:

```bash
# The three DKIM tokens. Each becomes:
#   name : <token>._domainkey.meridiansgrp.com
#   type : CNAME
#   value: <token>.dkim.amazonses.com
aws sesv2 get-email-identity --email-identity meridiansgrp.com \
  --query 'DkimAttributes.Tokens' --output text

# The MAIL FROM subdomain's two records, on `mail.meridiansgrp.com`:
#   MX  10 feedback-smtp.<region>.amazonses.com      (priority 10)
#   TXT "v=spf1 include:amazonses.com ~all"
aws sesv2 get-email-identity --email-identity meridiansgrp.com \
  --query 'MailFromAttributes' --output json
```

Add them at GoDaddy → DNS → Manage Zones → Add. Then:

```bash
aws sesv2 get-email-identity --email-identity meridiansgrp.com \
  --query '{Verified:VerifiedForSendingStatus,Dkim:DkimAttributes.Status,MailFrom:MailFromAttributes.MailFromDomainStatus}'
```

`SUCCESS` on all three, usually within 15 minutes and up to 72 hours.

**Three cautions.**

1. **Add them to `infra/dns/meridiansgrp.com.zone.json` as soon as you add them at
   GoDaddy**, or §3a's zone-file diff will flag five "missing from the checked-in export"
   rows at the worst possible moment. Mark them `"ses_interim": true` so it is obvious
   they are duplicates of what the stack already writes, not new GoDaddy-only records.
2. **Delete them at GoDaddy after the switch**, and remove those entries from the export.
   The Route 53 copies — written by CDK, never typed — are the ones that survive.
3. **Do not hand-type a DKIM token.** Copy from the CLI output. A single wrong character
   fails verification silently and looks exactly like "it has not propagated yet".

## 4. Switch the nameservers at GoDaddy

1. GoDaddy → My Products → `meridiansgrp.com` → **Nameservers** → Change.
2. Choose **"I'll use my own nameservers"** (custom / "Enter my own nameservers").
3. Paste `NameServer1`–`NameServer4` from the `cdk deploy` output, one per box. Do not
   include a trailing dot.
4. Save. GoDaddy may email a confirmation; complete it.

**Do not delete the GoDaddy DNS zone.** It stops being consulted but stays intact, and it is
the entire rollback plan. GoDaddy keeps it for a switched-away domain.

Note the exact time. The TTL tail starts now.

## 5. Verify propagation

Immediately, and then again after 1 hour, 4 hours and 24 hours:

```bash
# Which nameservers does the registry now publish?
dig +short NS meridiansgrp.com @a.gtld-servers.net

# What does a public resolver that does not know us answer?
dig +short MX meridiansgrp.com @1.1.1.1
dig +short MX meridiansgrp.com @8.8.8.8
```

Done looks like: the NS answer lists the four `awsdns` names, and MX/A/CNAME from the public
resolvers match §3's table.

Then the two functional checks that matter more than any `dig` output:

- [ ] **Send a mail to a `@meridiansgrp.com` address from an outside account** (a personal
      Gmail). It arrives. Inbound mail is the thing this runbook can break.
- [ ] Load `https://meridiansgrp.com` and `https://www.meridiansgrp.com`. Both load, no
      certificate warning.
- [ ] **Confirm `ai.meridiansgrp.com` still serves.** It is the other owner's application
      (ADR 0001, §3d) and it is the record most likely to be broken by us and noticed by
      somebody else. `dig +short ai.meridiansgrp.com @1.1.1.1` must return the CloudFront
      hostname in the export, and `curl -sI https://ai.meridiansgrp.com` must answer.
- [ ] Microsoft 365 admin centre → Domains → `meridiansgrp.com` still shows **Healthy**.
- [ ] SES: `aws sesv2 get-email-identity --email-identity meridiansgrp.com` shows
      `VerifiedForSendingStatus: true` and `DkimAttributes.Status: SUCCESS`. This is the
      first moment it *can* succeed — until now the DKIM CNAMEs were being served by a
      nameserver nobody was asking.
- [ ] `MailFromAttributes.MailFromDomainStatus: SUCCESS`.

If SES still says `PENDING` after an hour, re-run the DKIM `dig` checks from §3 against a
public resolver rather than against `$NS`.

## 6. Rollback

**The GoDaddy zone was never modified, so rolling back is one change and no data loss.**

1. GoDaddy → `meridiansgrp.com` → Nameservers → Change → **"Use GoDaddy nameservers"**
   (or re-enter `ns25.domaincontrol.com` / `ns26.domaincontrol.com`).
2. Save.
3. Wait out the registry NS TTL — typically one hour, up to 48 hours for stragglers.
4. Re-run §5's checks, expecting GoDaddy's answers.

During the tail, both zones are answering, which is exactly why §3 insisted they agree: a
rollback in the middle of a mixed state is harmless if the answers were identical, and is
a second outage if they were not.

**Do not `cdk destroy meridian-shared-dns` as a rollback.** The zone is
`RemovalPolicy.RETAIN` precisely so this cannot happen by accident; destroying it deletes
every record including the SES DKIM CNAMEs, and re-creating it later produces *four new
nameservers*, so the whole switch has to be redone.

**When rollback is the right call:** inbound mail is failing, or the site is down for a
subset of users, and the cause is not obvious within ~15 minutes. A DNS problem you are
still diagnosing at minute 20 should be rolled back and diagnosed with the GoDaddy zone
serving.

---

## 7. SES production access — request it separately, and early

This is not part of the nameserver switch, but it is the other half of Phase 1 step 3 and it
has the longest lead time in the phase.

**Where SES starts.** Every new SES account is in the **sandbox**: at most 200 messages per
24 hours, at most 1 per second, and — the binding one — **only to email addresses you have
separately verified**. That is fine for testing and useless for a password-reset flow.

**Leaving the sandbox needs AWS to approve a request, and takes 1–2 business days.** Cognito
(Phase 4) and the Resend replacement (Phase 7) both wait on it, which is why the plan starts
it in Phase 1.

> **Do not file this request as part of a build task.** It commits Meridian, in writing, to
> statements about what mail it sends and how it handles bounces. Andres files it, or
> approves the exact wording first.

**The request, by CLI:**

```bash
aws sesv2 put-account-details \
  --production-access-enabled \
  --mail-type TRANSACTIONAL \
  --website-url https://www.meridiansgrp.com \
  --contact-language EN \
  --use-case-description "Meridian is a private, invite-only revenue-automation \
application for one healthcare client. SES sends only transactional mail to named \
application users: sign-in verification and password-reset codes (via Amazon Cognito), \
user invitations, and run-completion notices. There is no marketing mail and no mailing list; \
recipients are created by an administrator inside the application, so there is no \
opt-in form and nothing to unsubscribe from. Bounces and complaints are published to an \
SNS topic and monitored, and the SES account-level suppression list is enabled for both \
bounces and complaints. Expected volume is under 200 messages per month." \
  --additional-contact-email-addresses <ops-mailbox>
```

Or in the console: **SES → Account dashboard → Request production access**, same answers.

**What AWS will ask about if the description is thin:** how recipients are obtained
(answer: created by an administrator, invite-only — P-6), how bounces and complaints are
handled (answer: the SNS topic this stack creates, plus the suppression list), and what
happens to a repeatedly bouncing address (answer: suppression list, automatically).

**Verify it landed:**

```bash
aws sesv2 get-account --query '{Production:ProductionAccessEnabled,Quota:SendQuota}'
```

`ProductionAccessEnabled: true` and a `Max24HourSend` well above 200 means you are out.

**If it is rejected** — it happens, usually for a vague use-case description — reply in the
same support case with specifics: the application name, that it is invite-only, the volume,
and the bounce handling. Do not open a second case.
