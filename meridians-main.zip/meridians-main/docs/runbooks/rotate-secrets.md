# Runbook — rotating the data tier's secrets

**Covers:** the four secrets in `meridian-<env>-data`, and the one that must not be rotated.
**Arrives:** Phase 3. **Run by:** Andres. **Cadence:** quarterly, and on any suspected
exposure.
**Not covered here:** the origin-verify header, which has its own two-deploy procedure —
`docs/runbooks/rotate-origin-verify-secret.md`.

---

## 0. The five credentials, and who rotates each

| Secret | Role | Rotated by | Cadence |
|---|---|---|---|
| RDS-managed (`rds!db-…`) | `meridian_migrator` — the schema owner Alembic runs as | **RDS itself, internally** | automatic |
| `meridian-<env>-secret-db-app` | `meridian_app` — the application | **this runbook, §2** | quarterly |
| `meridian-<env>-secret-db-phi` | `phi_access` — reads patient identifiers | **this runbook, §3** | quarterly |
| `meridian-<env>-secret-phi-hmac-key` | not a login: the `patient_ref` HMAC key | **§4, and almost never** | never, without a plan |
| `meridian-<env>-secret-origin-verify` | the CloudFront → ALB header | `rotate-origin-verify-secret.md` | on exposure |

### Why two of these are a runbook and not a rotation schedule

A Secrets Manager rotation schedule means a rotation Lambda. That Lambda has to reach the
database, which is in an isolated subnet, so it has to run **in** the VPC — and in the VPC
it reaches Secrets Manager only through the NAT gateway, which lives in the transient
`meridian-<env>-edge` stack and is absent for most of a staging month (ADR 0020 §2). ADR
0009 declined to buy the interface endpoint that would be the alternative.

A rotation that silently stops working whenever staging is torn down is worse than one
performed deliberately with the runbook open. **Phase 5a is when this changes:** an ECS
task is already in the VPC with egress, and the same three commands below become a
scheduled task. Until then, a calendar entry.

The master credential is different and is the reason it is RDS-managed: RDS rotates it
internally, with no Lambda and no network path of ours, so it keeps working while the rest
of the environment is torn down.

---

## 1. Before you rotate anything

1. **Not during a close.** A failed password change is a failed close.
2. **Know what reads the secret.** Today: the Phase 5a task definition (via a
   `secretsmanager` dynamic reference) and `alembic` when it runs `0003`. Nothing caches it
   on disk. If that stops being true, this list has to change with it.
3. **Have a second terminal open with a working `psql` session** through the ops instance
   (`docs/runbooks/db-access.md`). If the rotation goes wrong, an already-authenticated
   session is the difference between a fix and a lockout.

---

## 2. Rotating `meridian_app` (`…-secret-db-app`)

**The order is: change the database first, then the secret.** The other way round leaves a
window in which the stored value is wrong for every reader.

```bash
ENV=staging                       # never production without reading §5 first
SECRET="meridian-$ENV-secret-db-app"

# 1. Generate a new password with the same constraints the stack uses (ADR 0020 §9 —
#    no URL-breaking characters, because MERIDIAN_DATABASE_URL is a URL).
NEW=$(aws secretsmanager get-random-password --password-length 48 \
        --exclude-characters ' "'"'"'\\/@:?#%&=[]{}<>|`^~,;' \
        --require-each-included-type --query RandomPassword --output text)

# 2. Change it in PostgreSQL, as meridian_migrator, over the port-forwarding session.
psql "$MIGRATOR_URL" -c "ALTER ROLE meridian_app PASSWORD '$NEW';"

# 3. Store it, preserving the JSON shape the stack generated.
aws secretsmanager put-secret-value --secret-id "$SECRET" \
  --secret-string "$(jq -nc --arg p "$NEW" \
     '{username:"meridian_app", engine:"postgres", password:$p}')"

unset NEW
```

`ALTER ROLE … PASSWORD` does **not** disconnect existing sessions — they keep their
connection until it closes. So there is no outage at step 2; the cutover happens when the
tasks are next redeployed and pick up the new value:

```bash
aws ecs update-service --cluster meridian-$ENV-ecs-main \
  --service meridian-$ENV-ecs-svc-api --force-new-deployment     # Phase 5a onward (the service is `ecs-svc-api`; `ecs-api` is the task family)
```

**Verify:** a fresh connection with the new value succeeds, and one with the old value
fails. If the second still succeeds, step 2 did not run against the instance you think it
did.

`put-secret-value` moves `AWSCURRENT` to the new version and `AWSPREVIOUS` to the old one,
so the previous password is recoverable for as long as that version exists — which is the
rollback.

---

## 3. Rotating `phi_access` (`…-secret-db-phi`)

Identical to §2 with `phi_access` and `meridian-<env>-secret-db-phi`, plus one extra step,
because this is the role that can read patient identifiers (ADR 0012):

```sql
-- After the rotation, confirm the grant boundary is still exactly where it was.
SELECT has_schema_privilege('meridian_app', 'phi', 'USAGE');   -- must be FALSE
SELECT has_schema_privilege('phi_access',   'phi', 'USAGE');   -- must be TRUE
```

And note the rotation in `audit.phi_access`'s operational record — not in the table itself,
which is for reads; in the phase report. A credential to PHI changing hands is an event
worth being able to date.

---

## 4. The PHI HMAC key — read this before touching it

**`meridian-<env>-secret-phi-hmac-key` has no rotation schedule, and that is deliberate.**

`patient_ref = HMAC-SHA256(key, patient_id)` is stored on every row of
`public.transactions` and is the link between a tokenized row and
`phi.transaction_identity` (ADR 0012). Rotating the key does not invalidate a session or a
token and produces no error. It silently makes every stored `patient_ref` stop matching a
freshly computed one, so duplicate detection — the only consumer — starts returning nothing
while continuing to look like it works. ADR 0012 names this a **backup-critical** secret:
losing it is losing the join.

### The key format

**`^[A-Za-z0-9+/=_-]{32,}$`** — at least 32 characters from the base64url / standard-base64
alphabet. `scripts/split_phi.py` refuses anything else before it connects, and never echoes
the value.

The alphabet is not squeamishness about escaping, it is the transport: the key is handed to
`psql` as a libpq startup option (`PGOPTIONS="-c meridian.phi_hmac_key=..."`), and libpq
splits that string on **spaces** and unescapes **backslashes**. Neither character is in the
alphabet, so there is nothing to escape and nothing to get subtly wrong. 32 characters of
it is about 190 bits, comfortably past what HMAC-SHA256 uses.

**The secret the infrastructure generates already satisfies this.**
`infra/meridian/stacks/data.py`'s `_phi_hmac_secret` mints
`meridian-<env>-secret-phi-hmac-key` as **64 characters, alphanumeric**
(`exclude_punctuation=True`) — a strict subset of the alphabet, twice the minimum length.
If you ever mint one by hand, `openssl rand -base64 48 | tr -d '\n'` is in the alphabet;
anything with a space, a quote or a backslash in it is not.

### Where the key goes, and where it does not

The key is **never** in a statement. It travels in libpq's startup packet and
`scripts/split_phi.sql` reads it with `current_setting('meridian.phi_hmac_key', true)`.
`log_statement`, `log_min_error_statement` and pgaudit all log statement TEXT, and RDS runs
with `pgaudit.log = 'ddl,role,write'` — so an earlier version of this script, which
substituted the key client-side with a psql `\set`, wrote it into
`/aws/rds/instance/<id>/postgresql`: a 400-day log group that is itself a PHI store (ADR
0020 §3d). `tests/test_split_phi.py` proves the absence against a real server log, after a
successful run and after a forced mid-statement failure.

If you run the SQL by hand, export `PGOPTIONS` — do not reintroduce a `\set`, and do not
paste the key into a `psql` prompt, where it lands in `~/.psql_history` as well.

### The fingerprint

`phi.hmac_key_fingerprint` holds one row: `sha256(key)` in hex for the key that wrote every
`patient_ref`, computed server-side by `scripts/split_phi.sql` and asserted by revision
0005. Re-running the split with a **different** key raises rather than rewriting the
tokens. That refusal is the guard rail, and `python scripts/split_phi.py --rotate` is the
documented way past it — it rewrites both the tokens and the fingerprint, and it is step 3
below, not a shortcut around this section.

If it genuinely has to change (a confirmed exposure, nothing less), this is the plan, and
it is a scheduled change with a rollback, not a `put-secret-value`:

1. **Out of close, with a fresh snapshot taken first.** The old key stays where it is: the
   `AWSCURRENT` version in Secrets Manager (`AWSPREVIOUS` once step 4 moves the label).
   Never copy it into a file or a note. Step 3 reads it from there, because the rotation
   refuses to start unless it can name the key it is replacing.
2. Generate the new key and store it as a **new version** — do not move `AWSCURRENT` yet.
3. Recompute `patient_ref` for every row from `phi.transaction_identity` under the new key,
   **in one transaction**, in the migration load window (`docs/runbooks/migrations.md`).
   Which command depends on where the database is:

   | Where the database is | Command |
   |---|---|
   | Still at revision 0003, inside the split window (a load in progress, never production) | `python scripts/split_phi.py --rotate --database-url ...` |
   | **At head — this is the production case** | `python scripts/split_phi.py --rotate --at-head --database-url ...` |

   Both keys come from Secrets Manager into the environment with command substitution,
   never typed on the command line (the shell history file is durable):

   ```bash
   export MERIDIAN_PHI_HMAC_KEY="$(aws secretsmanager get-secret-value --secret-id meridian-<env>/phi-hmac-key --version-stage AWSPENDING --query SecretString --output text)"
   export MERIDIAN_PHI_HMAC_KEY_OLD="$(aws secretsmanager get-secret-value --secret-id meridian-<env>/phi-hmac-key --version-stage AWSCURRENT --query SecretString --output text)"
   ```

   `unset` both when done.

   `--at-head` exists because `scripts/split_phi.sql` refuses any revision but 0003 and
   because at head `public.transactions.patient_id` is gone — so the ordinary `--rotate`
   could only ever re-key a database caught mid-load, which production never is. It used to
   say "at head it is the same `UPDATE` written out by hand", which left the operator to
   rediscover `PGOPTIONS`, the per-organization `SET app.org_id` that FORCE row-level
   security makes necessary, and the fingerprint update — and the hand path never mentioned
   the last one at all.

   What `--at-head` does, in one transaction:

   * refuses unless `--rotate` was given, revision 0005 has run, both keys are present and
     different, and `phi.hmac_key_fingerprint` holds the **old** key's `sha256` — that last
     check is why step 1 keeps the old value;
   * loops over `public.organizations`, sets `app.org_id` for each, and recomputes
     `patient_ref` as `HMAC(new key, phi.transaction_identity.patient_id)` joined on the
     transaction id. The identifier lives in `phi` now, which is why the old key is not
     needed to compute anything. `app.org_id` is not optional: revision 0004's FORCE row-level
     security applies to `meridian_migrator` too, and an unscoped `UPDATE` matches zero rows
     and reports success;
   * refuses, per organization, if any transaction has no `phi.transaction_identity` row;
   * rewrites the fingerprint row with the new key's `sha256` **in the same transaction**.

   Both keys travel in `PGOPTIONS` (`meridian.phi_hmac_key`, `meridian.phi_hmac_key_old`),
   so neither is in `ps`, in the statement text or in the PostgreSQL log. Both must satisfy
   the key policy above.
4. Verify **before** moving the secret: the command prints the number of transactions
   re-tokenised and the new fingerprint prefix. Then, out of band, check
   `count(*) WHERE patient_ref IS NULL` is 0 and that a sample of rows recomputes to the
   stored value under the new key.
5. Move `AWSCURRENT` to the new version.
6. Keep the old version until the next close has run clean. It is the rollback — and
   rolling back is the same command with the two keys swapped.

The tokens and the fingerprint are one transaction for a reason: a half-rekeyed table is a
table where duplicate detection is wrong for some rows and right for others, which is
undetectable from the outside; and tokens written by the new key under a fingerprint that
still names the old one would make the next legitimate rotation refuse and an illegitimate
one pass.

---

## 5. Production

Everything above applies, with three additions:

- **Announce it.** Two people use this system; both should know.
- **Do it at the start of a working day**, not the end. A rotation that goes wrong at 17:30
  is an evening.
- **Do not script the whole thing.** Run it command by command with the output visible. The
  failure mode being defended against is "the `ALTER ROLE` ran against staging and the
  `put-secret-value` against production", which a script makes easier, not harder.

---

## 6. What this runbook does not rotate

| Credential | Where |
|---|---|
| Origin-verify header | `docs/runbooks/rotate-origin-verify-secret.md` — two deploys, and the reason why |
| `meridian_migrator` master password | RDS, internally (ADR 0020 §3a). Forcing one: `aws secretsmanager rotate-secret --secret-id <the MasterUserSecret ARN> --rotate-immediately` |
| Cognito app-client secrets | Phase 4 |
| QuickBooks OAuth client (`meridian-<env>/qbo-oauth`) | Created **by hand before the first `-c worker_enabled=true` deploy**, JSON `{"client_id": "...", "client_secret": "..."}` from developer.intuit.com, on the environment's `logs` CMK: `aws secretsmanager create-secret --name meridian-<env>/qbo-oauth --kms-key-id alias/meridian-<env>-kms-logs --secret-string file://<a file you delete afterwards>`. Rotating = regenerate the secret at Intuit, `put-secret-value` with both fields, then force a new deployment of the api and worker services (the ECS agent reads secrets at task start). Mapped into `QBO_CLIENT_ID`/`QBO_CLIENT_SECRET` of both tasks (critic Stage 1 M-10); the redirect URI registered at Intuit is `https://<public host>/api/v2/qbo/connection/callback` |
| eCW data mart login (`meridian-<env>/ecw-db`) | Created **by hand**, JSON `{"host": "...", "dbname": "...", "user": "...", "password": "..."}` (the read-only `ECW_DB_*` login), on the `logs` CMK the same way as `qbo-oauth`. Mapped into the api's `ECW_DB_*` only with `-c ecwDb=true`; `scripts/staging_deploy.sh compute` adds the flag whenever the staging secret exists. The data mart is in another AWS account and admits only allowlisted addresses, so the environment's NAT address must be on its list. Rotating = `put-secret-value`, then force a new api deployment |
| Break-glass credentials | `docs/runbooks/break-glass.md` — rotated **after every use**, not quarterly |
| KMS CMKs | Not rotated by hand. All five have `EnableKeyRotation`, which rotates the backing material annually and keeps every prior version, so old ciphertext stays readable. |

---

## 7. The record

| Date | Environment | Secret | By | Notes |
|---|---|---|---|---|
| _(pending — first rotation is Phase 5a)_ | | | | |
