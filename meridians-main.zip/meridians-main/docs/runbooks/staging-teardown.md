# Runbook — tear staging down, and bring it back

**Covers:** ending a staging session (D-15 / ADR 0008) and starting the next one.
**Arrives:** Phase 2. **Run by:** whoever finishes the session.
**Time:** ~5 minutes to destroy, ~15 minutes to redeploy.
**Executed:** _not yet — this is a draft until the first real teardown, and the date is
recorded here when it happens._

Staging exists only while a staging session is running. A standing staging environment
costs ~$129/month taxed and would use half the ~$250 ceiling on its own (plan §5); torn
down it costs **~$13/month** — the `data` stack's stopped database, buckets, keys, secrets
and backup vault, plus the `vpc` stack, which costs nothing at all. The teardown is also
the rehearsal: every session re-proves the whole CDK app from empty, which is exactly what a future account split needs.

> **This runbook is for staging.** Never run any of it against production. The wrapper
> script refuses.

---

## 1. Before you destroy

1. **Is anything mid-flight?** A running process, an open wizard, a colleague using the
   environment. Destroying takes the ALB and the tasks with it.
2. **Is anything worth keeping in `output/` or the artifacts bucket?** The `data` stack
   survives, so S3 objects and the database survive with it. Anything on the ops
   instance's disk does **not** — it is a scratch box, and nothing should be there.
3. **`git status` is clean and pushed.** A teardown with uncommitted CDK changes means
   the next deploy does not rebuild what you just destroyed.

---

## 2. Destroy, in this order

```bash
cd infra
npx cdk destroy -c env=staging \
  meridian-staging-observability \
  meridian-staging-api \
  meridian-staging-compute \
  meridian-staging-edge
```

**`meridian-staging-edge`, not `meridian-staging-network`.** Phase 3 split that stack in
two (ADR 0020): `meridian-staging-vpc` holds the VPC, the subnets, the gateway endpoints
and the four security groups — all free, all persistent — and `meridian-staging-edge` holds
everything billed by the hour. The split is what lets the RDS instance live in the `data`
stack and still persist, because `data` now depends on `vpc`, which nobody destroys.

**The order is reverse-dependency order** and CDK enforces it anyway when the stacks are
given in one command: `observability` reads the others' resources, `api` runs on
`compute`, and `edge` holds the load balancer they attach to. Given separately and out of
order, the destroy fails with "export in use" and you have to start again.

**What is destroyed:** the NAT gateway and its two routes, the load balancer, CloudFront,
the WAF web ACL, the ACM certificate, the ops instance, the flow-log group, both log
buckets (their objects are auto-deleted in staging), the ECS cluster and services, the task
definitions, the alarms and dashboards.

**What is NOT destroyed, and used to be:** the VPC and its subnets. They cost nothing, and
`meridian-staging-data` — the database — depends on them. Trying to destroy
`meridian-staging-vpc` while the data stack exists fails with "export in use", which is the
protection working; see §2c.

**What persists, and must not be touched:**

| Stack | Why |
|---|---|
| `meridian-staging-vpc` | The VPC, six subnets, two gateway endpoints and the four security groups. **$0/month** — nothing in it is billed by the hour — and `meridian-staging-data` imports its subnets and the `data` security group, so it cannot be destroyed while the database exists (ADR 0020). |
| `meridian-staging-data` | The five CMKs, the four secrets, **the RDS instance**, the three S3 buckets and the locked backup vault. Destroying it schedules the keys for deletion, and a scheduled key deletion is how encrypted backups quietly become unreadable. Everything in it is `RemovalPolicy.RETAIN`, so this is structural, not a promise. The database stops itself nightly (§2c). |
| `meridian-staging-auth` | The Cognito user pool. Recreating it invalidates every test account. |
| `meridian-shared-*` | Account-level: foundation, DNS, identity. Deployed once, never per session. |

### 2a. There is no secret to free any more

Earlier versions of this runbook had a step here that force-deleted
`meridian-staging-secret-origin-verify`, because Secrets Manager keeps a deleted secret
— **and its name** — for a recovery window, so the next session's deploy failed with
"a secret with this name is scheduled for deletion".

**That step is gone, and so is the reason for it.** The secret now lives in
`meridian-staging-data` (finding L-6), which this runbook never destroys. Two things
follow, and the second is the one that mattered:

1. The name is never taken out of circulation, so the next `up` cannot collide with it.
2. **The secret's version history survives.** `rotate-origin-verify-secret.md` depends
   on `AWSCURRENT` and `AWSPREVIOUS` pointing at two different versions; a force-delete
   threw that away, so the first rotation after a teardown had no previous version to
   fall back to.

A step in a script is a step that can be skipped. Removing the need for it is the fix.

### 2b. Confirm it is gone

```bash
aws cloudformation describe-stacks --stack-name meridian-staging-edge 2>&1 | grep -q "does not exist" && echo "edge: gone"
aws ec2 describe-nat-gateways --filter Name=tag:Environment,Values=staging \
  --query 'NatGateways[?State!=`deleted`]' --output text          # must be empty
```

A NAT gateway left running is $37.50/month of nothing.

### 2c. The data stack persists — and, since Phase 3, partly cannot be undone

The `data` stack is not merely "not on the destroy list". Three of the things in it now
resist deletion on purpose, and it is better to know that before deploying than after:

* **The RDS instance stops itself, nightly, for ever.** An EventBridge Scheduler rule calls
  `rds:StopDBInstance` at 02:00 America/Chicago (D-15). It is nightly rather than one-off
  because **RDS restarts a stopped instance by itself after seven days** — a single manual
  stop lasts a week and then quietly resumes billing. There is no scheduled *start*:
  `scripts/staging_session.sh up` starts it, because that is the only moment anyone wants
  it running.

      aws rds start-db-instance --db-instance-identifier meridian-staging-rds-main

  Starting takes a few minutes. A `cdk deploy` of the other stacks does not start it.
* **The backup vault is Vault Lock, compliance mode.** After a three-day cooling-off window
  the lock cannot be removed by anyone, including the account root user and AWS Support,
  and the vault cannot be deleted while it holds a recovery point — up to 35 days.
* **Staging has no scheduled backup plan, so `down` takes one by hand.** The daily plan is
  in **production only** (ADR 0020 §7b): a 05:00 UTC job against an instance the 02:00
  schedule stopped three hours earlier fails every night, and a job expected to fail makes
  every real failure unreadable. `scripts/staging_session.sh down` therefore starts one
  on-demand job into the locked vault *before* it stops the database, and that recovery
  point is what `docs/runbooks/restore-drill.md` exercises. By hand:

      aws backup start-backup-job \
        --backup-vault-name meridian-staging-backup-vault \
        --resource-arn "$(aws rds describe-db-instances \
            --db-instance-identifier meridian-staging-rds-main \
            --query 'DBInstances[0].DBInstanceArn' --output text)" \
        --iam-role-arn "arn:aws:iam::<account>:role/meridian-staging-iam-backup" \
        --lifecycle DeleteAfterDays=35

  `DeleteAfterDays=35` is required — the vault lock bounds are [35, 400] days and a job
  outside them is refused. Wait for `COMPLETED` before stopping the instance. **Skipping
  this is not a disaster:** the 7-day PITR window is unaffected by a stopped instance and
  is the recovery anyone actually uses. What it costs is the vault-path drill.
* **The `audit` bucket is Object Lock, compliance mode, seven years.** Nothing written there
  can be deleted or overwritten for that period. This is the one thing in the estate that a
  `cdk destroy` genuinely cannot undo, and it is what plan §7 item 13's six-year retention
  rests on.

None of that costs much (~$13/month idle, §5 of the cost estimate), but all of it means
**abandoning a staging environment now has a tail.** Deploy `meridian-staging-data`
deliberately.

---

## 3. Bring it back at the start of the next session

**Name the four stacks. Never `--all`.** `--all` includes
`meridian-shared-foundation`, `meridian-shared-dns`, `meridian-shared-identity`,
`meridian-staging-vpc`, `meridian-staging-data` and `meridian-staging-auth` — the six
things this runbook spends its second half telling you not to touch. It also drags in the deploy-time
CloudFormation parameters the shared stacks require (`AlertEmail`,
`EmailEventsAddress`), so the most likely outcome is a failed deploy; the *worse*
outcome is a successful one that re-renders `meridian-shared-identity` without the
Identity Center identifiers and deletes the permission sets.

```bash
cd infra
npx cdk deploy --exclusively -c env=staging \
  -c cloudfrontPrefixListId=pl-... \
  -c hostedZoneId=Z... \
  -c originVerifyCloudFrontVersionId=<version id> \
  meridian-staging-edge \
  meridian-staging-compute \
  meridian-staging-api \
  meridian-staging-observability

# `--exclusively` is why the four stacks named above are the only ones that move:
# the persistent `vpc`, `data` and `auth` stacks are dependencies of these, and
# without the flag CDK would re-synthesize them at this command's context and
# undo exactly the things the second half of this runbook tells you not to touch.

# ...and start the database, which stopped itself overnight (D-15).
aws rds start-db-instance --db-instance-identifier meridian-staging-rds-main
```

If `infra/cdk.context.json` does not carry `ssoInstanceArn`, add
`-c allowNoIdentityCenter=true`. It is not a deploy waiver — it only lets the app
*synthesize*, and none of the four stacks above is the identity stack.
`scripts/staging_session.sh` adds it automatically when the file lacks the value.

`originVerifyCloudFrontVersionId` is the secret version CloudFront sends. Get it from
the last deploy's `OriginVerifyCloudFrontVersion` output, or:

```bash
aws secretsmanager list-secret-version-ids \
  --secret-id meridian-staging-secret-origin-verify \
  --query "Versions[?contains(VersionStages, 'AWSCURRENT')].VersionId" --output text
```

Leaving it off is not fatal — CloudFront falls back to the `AWSCURRENT` label and
`cdk synth` warns — but it silently re-arms the outage the rotation runbook exists to
prevent.

**~15 minutes**, most of it the CloudFront distribution and the ACM certificate's DNS
validation. The two `-c` values are identifiers and are never committed (ADR 0001) —
keep them in your shell history or a local note, not in the repo. Look them up with:

```bash
aws ec2 describe-managed-prefix-lists \
  --filters Name=prefix-list-name,Values=com.amazonaws.global.cloudfront.origin-facing \
  --query 'PrefixLists[0].PrefixListId' --output text

aws cloudformation describe-stacks --stack-name meridian-shared-dns \
  --query "Stacks[0].Outputs[?OutputKey=='HostedZoneId'].OutputValue" --output text
```

**Leaving `cloudfrontPrefixListId` off does not open the load balancer** — the stack
synthesizes with a placeholder id that does not exist, and CloudFormation refuses it.
Fail closed.

---

## 4. The check that makes this a rehearsal rather than a chore

```bash
npx cdk diff -c env=staging -c cloudfrontPrefixListId=pl-... -c hostedZoneId=Z... \
  meridian-staging-edge meridian-staging-compute \
  meridian-staging-api meridian-staging-observability
```

(`cdk diff` is read-only, so `--all` is harmless here — but the four stacks are what
this session rebuilt and the rest is noise.)

**It must report no changes.** An empty diff means the environment that came back is
the environment the code describes — which is the whole claim CDK makes and the only
way to know it is still true. A non-empty diff after a fresh deploy means either
something was changed in the console (which the foundation stack alarms on) or the code
does not describe what it deploys. Stop and find out which, before building on it.

---

## 5. When a step fails

| Symptom | What it means | Do this |
|---|---|---|
| `Export ... cannot be deleted as it is in use` | A stack was destroyed out of order, or you named `meridian-staging-vpc` or `meridian-staging-data` by mistake — both have live consumers. | Destroy the consumer first. Never delete the export by hand. If the stack you named was `vpc` or `data`, the refusal is the protection: stop. |
| `Cannot connect to the database` at the start of a session | It stopped itself overnight (§2c). | `aws rds start-db-instance --db-instance-identifier meridian-staging-rds-main`, then wait a few minutes. |
| `The bucket you tried to delete is not empty` | The auto-delete custom resource failed (it is a Lambda; it can be throttled). | Re-run the destroy. If it persists, empty the bucket with `aws s3 rm s3://... --recursive` and re-run. |
| `A secret with this name is already scheduled for deletion` | A leftover from before L-6: an old teardown force-deleted the secret and the recovery window has not closed. It cannot recur — the secret is in the data stack now. | `aws secretsmanager restore-secret --secret-id meridian-staging-secret-origin-verify`, then deploy. Restore, do not force-delete: the version history is what the rotation procedure needs. |
| Destroy hangs on the VPC | Something outside CDK has an ENI in the subnets — usually a Lambda or a manually created endpoint. | Find it: `aws ec2 describe-network-interfaces --filters Name=vpc-id,Values=vpc-...`. Do not delete anything you did not create (ADR 0001). |
| Certificate stuck in `PENDING_VALIDATION` on redeploy | `hostedZoneId` was not supplied, so ACM has nowhere to write the validation record. | Cancel, redeploy with the zone id. |

---

## 6. The wrapper

`scripts/staging_session.sh` does all of the above with confirmation prompts, a
`--dry-run` that prints the commands without running them, and a hard refusal to
operate on production:

```bash
scripts/staging_session.sh up   --dry-run
scripts/staging_session.sh down --dry-run
scripts/staging_session.sh down
```

It is a convenience, not a substitute: when something fails, come back to this file.
