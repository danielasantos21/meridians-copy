# Runbook — decommissioning Supabase and Render (Phase 10)

**What this covers:** turning off the old platform, in the one order that keeps a way back until
the last possible moment: close the auth fallback, archive the database somewhere nothing can
delete it from, then cancel Supabase, then delete Render, then clean the DNS, the secrets and
the documentation. Plan `docs/aws-migration-plan.md` Phase 10, §6, ADR 0020 §5-6, ADR 0021,
D-06.

**What it does not cover:** the cutover itself (`cutover.md`, Phase 9, two to three months
before this), and removing Flask, the Jinja wizards or `web_app.py` — **those are Phase 11 and
nothing here touches them.**

> **This runbook has not been executed yet**, and by construction it can be executed only once.
> Steps 1, 2 and 6 rehearse cleanly; step 5 does not rehearse at all.

> **Read this before anything else.** Step 5 is the only genuinely irreversible act in the whole
> migration (plan §6, Point of No Return #3). Everything up to it can be undone. Nothing after
> it can. The archive from steps 3-4 is what stands between "we cancelled a subscription" and
> "we destroyed the only copy of the pre-migration database", and it is why those steps come
> first and are verified before anything is cancelled.

---

## The order, and why it is this order

```
  1  auth cut-off     dual acceptance off, trigger detached, Lambda deleted
  2  STOP + archive   final pg_dump → the Object-Locked `meridian-production-s3-archive`
  3  verify archive   restore it into a scratch PG 17 and count
  4  disable          Supabase Auth off; project paused (still recoverable)
  5  🛑 CANCEL        delete the Supabase project — IRREVERSIBLE
  6  Render           suspend → one week → delete
  7  DNS              remove the records that pointed at Render
  8  secrets          rotate everything Supabase or Render ever held
  9  code + docs      SUPABASE_* gone, BAA register and inventory updated
```

Three constraints fix it:

1. **The archive is verified before anything is cancelled.** An archive nobody has restored is a
   file, not a backup. Step 3 exists so that step 5's irreversibility is survivable.
2. **The auth cut-off comes first because it is the only reversible thing left.** Until
   `AUTH_ACCEPT_SUPABASE_TOKENS=false` lands and the trigger is detached, Supabase Auth is a
   live dependency of production sign-in. Cancelling the project with the fallback still wired
   is an outage, not a decommission.
3. **Render is deleted after Supabase, not before.** Render is the only remaining thing that can
   serve the old application against the old database. While Supabase exists, a suspended Render
   service is still a (slow, awkward) way back.

---

## Before you start

| | |
|---|---|
| **Who** | Andres. Every destructive step needs him in the room; most need him in the vendor's dashboard, where Claude cannot go. |
| **When** | **Two full close cycles after Flip 2** (plan Phase 10 preconditions), roughly two to three months. Not during a close. |
| **Access** | The Supabase project owner account; the Render account; the GoDaddy account (registrar records, if any remain); the AWS deploy role. |
| **Tools** | `pg_dump`/`pg_restore` ≥ 17.6, `psql`, `aws`, Docker (for the scratch restore), the repo venv. |
| **Where the archive goes** | `s3://meridian-production-s3-archive/` — Object Lock, compliance mode, **seven years**, on the **`phi`** CMK. **Not the `audit` bucket** (see step 2). Not the encrypted laptop volume alone, not Downloads, not this repository. |

### Placeholders

`<project-ref>` the Supabase project reference · `<pool-id>` the Cognito user pool ·
`<zone-id>` the Route 53 hosted zone · `<account-id>` the AWS account · `<render-hostname>` the
Render service hostname · `<phi-cmk-arn>` the `phi` CMK, which is the archive bucket's key.
**No real value for any of these belongs in this file.**

---

## Preconditions — all of them

- [ ] **Two full close cycles completed on AWS** since Flip 2, both tied out to the cent against
      what NetSuite/QuickBooks received.
- [ ] **The Cognito completion criterion is met**: every `auth.users` row that has an org
      membership exists in Cognito with a matching `custom:app_uid`, and the migration
      percentage is 100% of active users — **or** the cut-off date (Flip 2 + 60 days) has
      passed, in which case each straggler gets an `AdminCreateUser` and a password reset
      (D-06). Run the weekly report one last time and file it:
      ```bash
      python3 scripts/cognito_migration_report.py --pool-id "<pool-id>"
      ```
      It prints counts and a domain breakdown, never an address.
- [ ] **Both `meridiansgrp.com` and `www` resolve through CloudFront**, and nothing in DNS or in
      the repository points at Render. Check the apex specifically: it pointed at Render right
      up to Phase 9 and was removed by **cutover step 7a** (`renderRecords=false` on
      `meridian-shared-dns`), so a Render apex here means that step was reverted or never ran —
      and deleting Render with a stale apex record takes the bare domain dark.
- [ ] The restore drill has been re-run against production RDS with its time recorded
      (`restore-drill.md`).
- [ ] The two unhandled Cognito challenges (`MFA_SETUP`, `NEW_PASSWORD_REQUIRED`) have screens —
      `docs/migration-tracker.md` names this as due **before** dual acceptance is switched off,
      because after step 1 a user who hits either has no way through and no fallback.
- [ ] Phase 11 has started in parallel. It does not wait for this runbook, and this runbook does
      not wait for it.

---

### 1. The auth reversibility cut-off

**What this destroys:** the ability for a Supabase-issued token to authenticate anyone, and the
ability for a Supabase-era password to be migrated on first sign-in. After this step, a user who
never signed in since Flip 1 cannot bring their old password across — they get an administrator
reset instead. **Point of No Return #2 ends here** (plan §6): Flip 1 stops being reversible.

**This step is reversible in itself** — redeploy with the flag back on and re-attach the trigger
— for exactly as long as the Supabase project still exists. Step 5 is what makes it permanent.

## 🛑 STOP — ask Andres

> *"After this, nobody can sign in with their old Supabase password any more. `<n>` people have
> already migrated and `<m>` have not. The ones who have not get a reset email from me instead.
> Go ahead?"*

Then, in this order:

**Both halves of this step are CDK deploys.** Nothing here is typed at a vendor dashboard and
nothing here is an `aws` write command. The CLI appears below only to *verify* — a runbook that
changes infrastructure by hand produces drift that the next `cdk deploy` silently undoes, and
this is the one step where "silently undone" means Supabase authentication comes back.

**Every `cdk deploy` below carries `--exclusively`, including the ones in the rollback.**
Without it CDK deploys the named stack *and its dependencies*: `compute` pulls in `vpc`, `data`
and `edge`, and `auth` pulls in `data` (the `logs` CMK) and `meridian-shared-dns` (the SES
identity Cognito mails through). None of those are passed the context they read here
(`hostedZoneId`, `cloudfrontPrefixListId`, `renderRecords`), so they would re-synthesize at
their defaults — which by this point in the cutover means deleting the production aliases and
writing the CloudFront prefix-list placeholder into the ALB's security group, from a command
whose only intended effect was an environment variable. `--exclusively` deploys the named stack
and nothing else; its dependencies already exist. **If you ever drop `--exclusively` from a
command that pulls in `meridian-shared-dns` after the flip, it must also carry
`-c renderRecords=false`** — the flag defaults to true, and a default-context `dns` synth
re-creates the Render records the flip removed. **That caveat covers the `auth` deploys on this
page too**, not only the `compute` ones: `auth` depends on `meridian-shared-dns`, so a
deploy of `meridian-production-auth` with the flag dropped is exactly such a command.

**The one way `--exclusively` bites you** is a dependency that is not deployed: the stack
synthesizes with an `Fn::ImportValue` nothing exports, CloudFormation fails the change set with
`No export named meridian-…` and rolls the deploy back. Before the first exclusive deploy here,
confirm the dependencies exist — `aws cloudformation describe-stacks --stack-name
meridian-production-data --query 'Stacks[0].StackStatus'`, and the same for
`meridian-production-vpc`, `meridian-production-edge` and `meridian-shared-dns`; each must read
`CREATE_COMPLETE` or `UPDATE_COMPLETE`.

```bash
# 1a. Close dual acceptance. `AUTH_ACCEPT_SUPABASE_TOKENS` is a plain environment
#     variable in the api task definition, written by
#     `_api_environment()` in infra/meridian/stacks/compute.py and read by
#     `src/settings.accept_supabase_tokens()` (ADR 0021). Default "true";
#     `-c acceptSupabaseTokens=false` is what closes it.
npx cdk deploy meridian-production-compute --exclusively \
    -c env=production -c imageTag="<sha>" \
    -c acceptSupabaseTokens=false \
    --require-approval never
aws ecs wait services-stable --cluster meridian-production-ecs-main \
    --services meridian-production-ecs-svc-api meridian-production-ecs-svc-web

# Verify it actually landed, from the running task definition:
aws ecs describe-task-definition --task-definition meridian-production-ecs-api \
  --query "taskDefinition.containerDefinitions[0].environment[?name=='AUTH_ACCEPT_SUPABASE_TOKENS']"

# 1b + 1c. Remove the User Migration trigger, its Lambda, its log group and the
#          Supabase credential secret — ALL of it, in ONE deploy, from the stack
#          that created them. `legacyMigration` defaults to true; this is the
#          only thing that ever sets it false.
#          Every OTHER flag this stack was last deployed with has to be repeated on
#          the same line, or this deploy deletes what those flags created: dropping
#          `-c googleIdp`/`-c entraIdp` deletes the identity providers, dropping
#          `-c googleSignIn`/`-c entraSignIn` removes the federated sign-in buttons,
#          and dropping `-c authCallbackUrls` falls back to the per-environment
#          default host. They are the flags from
#          `docs/runbooks/cognito-user-migration.md` steps 2-3.
#          `-c requireLegacySnapshot` is NOT on this line: with `legacyMigration=false`
#          no Lambda is built, so the snapshot guard never runs and the flag is inert
#          (it creates nothing, so leaving it off deletes nothing). Tracker T:146.
npx cdk deploy meridian-production-auth --exclusively -c env=production \
    -c legacyMigration=false \
    -c googleIdp=true -c entraIdp=true \
    -c googleSignIn=true -c entraSignIn=true \
    -c authCallbackUrls=https://app.meridiansgrp.com/auth/callback \
    --require-approval never
```

Precondition on 1b/1c: `npx cdk diff meridian-production-auth --exclusively -c env=production
-c legacyMigration=false -c googleIdp=true -c entraIdp=true
-c googleSignIn=true -c entraSignIn=true
-c authCallbackUrls=https://app.meridiansgrp.com/auth/callback` — **with `--exclusively`, so
the diff is of the stack you are about to deploy and not of its dependencies at default
context** — must propose the removal of the `UserMigration` Lambda, its log group,
its role, **the `LegacySupabaseAuthSecret`** and the `LambdaConfig` on the pool — **and nothing
about the pool's users, its MFA configuration, its app clients or the Google/Entra secrets.**
All five leave the *stack*; two of them do not leave the *account*, which is what 1d is about. Anything else in that diff is
unrelated drift riding along, and this is a pool with `deletion_protection=True` for a reason.
**One app-client change is expected, and only one:** if the pool was still carrying the
pre-cutover pair of callbacks (`www` and `app`, `cognito-user-migration.md` § "`<host>`"), the web
client's `CallbackURLs` / `LogoutURLs` shrink to the `app` one. `www` only redirects since the
cutover (ADR 0050), so nothing signs in through it any more.

**Why not `update-user-pool --lambda-config '{}'`.** Because that command replaces the *whole*
`LambdaConfig`, so the literal empty object removes every trigger the pool has, not just this
one — a pre-token-generation or custom-message trigger disappears silently and nobody notices
until an email stops arriving. The advice "read the current config first and send back the rest"
is correct and is still a hand-written JSON document typed under time pressure into the one API
call that can break every sign-in. The deploy above changes only the key CDK wrote, leaves any
other alone, and is reviewable as a diff beforehand. **Delete the CLI mutation from your muscle
memory; it is not in this runbook any more.**

```bash
# Verification only — no writes. The pool should now report no LambdaConfig at all:
aws cognito-idp describe-user-pool --user-pool-id "<pool-id>" \
  --query 'UserPool.LambdaConfig'

# And the function should be gone:
aws lambda get-function --function-name meridian-production-lambda-user-migration \
  || echo "gone, as expected"
```

**1d. Two resources are now orphaned, and they are why the rollback is not three deploys.**
Both the secret and the Lambda's log group are `RemovalPolicy.RETAIN`
(`infra/meridian/stacks/auth.py`, `LegacySupabaseAuthSecret` and `UserMigrationLogGroup`), so
`legacyMigration=false` removes them from the stack and **leaves them in the account, under
their fixed names**:

| Orphan | Name | Why RETAIN |
|---|---|---|
| Secrets Manager secret | `meridian-production/legacy-supabase-auth` | It is a credential somebody pasted in by hand; CDK must not be able to delete it by accident |
| CloudWatch log group | `/aws/lambda/meridian-production-lambda-user-migration` | It is the **evidence** of who migrated and when — 400-day retention, CMK-encrypted. Do not change this policy to `DESTROY`; deleting the evidence to make a redeploy convenient is the wrong trade |

Both names are fixed, not generated. **That is the trap in the rollback**: re-deploying with
`legacyMigration` back at its default asks CloudFormation to *create* a secret and a log group
that already exist, and CloudFormation fails the stack update with
`ResourceAlreadyExistsException` / `The specified log group already exists` and rolls it back.
The rollback below deletes both first, for that reason.

Delete the secret deliberately, after the deploy, with the 30-day window:

```bash
aws secretsmanager delete-secret --secret-id meridian-production/legacy-supabase-auth \
    --recovery-window-in-days 30
```

Thirty days is not a formality: it is the window in which 1a and 1b are still reversible, and
restoring the secret is part of that rollback. **Leave the log group where it is** — it is
evidence, it costs cents, and the rollback deletes it only if a rollback actually happens.

**1e. Delete every copy of `legacy_users.json` from every machine.** It is the snapshot of the
old identities. Find it before you claim it is gone; it was copied around during Phase 4.

**Evidence:** the final migration report (counts only); `cdk diff` output for both deploys; the
pool's `LambdaConfig` before and after (from `describe-user-pool`, read-only); the
`describe-task-definition` query showing `AUTH_ACCEPT_SUPABASE_TOKENS=false`; the
`delete-secret` confirmation with its scheduled deletion date; a line in the log naming each
machine `legacy_users.json` was removed from.
**Rollback — and it is NOT three deploys, because of the two RETAINed orphans in 1d.**
Re-deploying `meridian-production-auth` at the default `legacyMigration=true` recreates a secret
and a log group whose names are already taken, and CloudFormation fails the update rather than
adopting them. So both have to leave the account first, and the secret's contents have to be
re-pasted afterwards — `restore-secret` is **not** enough on its own if the delete has already
completed, and adopting the old secret back into the stack is not something CDK can do here.

```bash
# 1. Re-open dual acceptance. No flag: `acceptSupabaseTokens` defaults to true.
npx cdk deploy meridian-production-compute --exclusively \
    -c env=production -c imageTag="<sha>" \
    --require-approval never

# 2. Get the credential values BACK IN HAND before deleting anything.
#    SKIP `restore-secret` if 1d was not run: a secret that was never scheduled for
#    deletion is not "deleted", and restore-secret on it is a no-op at best and a
#    confusing error at worst. Read it directly in that case. Inside the 30-day
#    window a secret that *was* scheduled is still readable once restored:
aws secretsmanager restore-secret --secret-id meridian-production/legacy-supabase-auth
aws secretsmanager get-secret-value --secret-id meridian-production/legacy-supabase-auth \
    --query SecretString --output text     # paste into a password manager, not a file

# 3. Clear both fixed names out of the account. --force-delete-without-recovery is
#    required: a secret merely *scheduled* for deletion still owns its name, so the
#    redeploy in step 4 would still collide. There is no undo after this line, which
#    is exactly why step 2 comes first.
aws secretsmanager delete-secret --secret-id meridian-production/legacy-supabase-auth \
    --force-delete-without-recovery

# 3b. The migration log group is the record of who migrated and when. Export it
#     and CONFIRM the export before the delete below — the delete is the point
#     of no return for that evidence (Codex CX-INF-05).
TASK=$(aws logs create-export-task \
    --log-group-name /aws/lambda/meridian-production-lambda-user-migration \
    --from 0 --to $(($(date +%s) * 1000)) \
    --destination meridian-production-s3-archive \
    --destination-prefix cognito-user-migration/$(date +%F) \
    --query taskId --output text)
until [ "$(aws logs describe-export-tasks --task-id "$TASK" \
        --query 'exportTasks[0].status.code' --output text)" = COMPLETED ]; do sleep 10; done
aws s3 ls "s3://meridian-production-s3-archive/cognito-user-migration/$(date +%F)/" --recursive \
    | grep -q . || { echo "export produced no objects — STOP, do not delete"; exit 1; }
# Only now:
aws logs delete-log-group \
    --log-group-name /aws/lambda/meridian-production-lambda-user-migration

# 4. Now the stack can recreate them. `legacyMigration` defaults to true, so it needs
#    no flag -- but every OTHER flag this stack was last deployed with does have to be
#    repeated, or this deploy deletes what they created. Re-run
#    `docs/runbooks/cognito-user-migration.md` steps 1-3 THAT DAY: step 1 regenerates
#    `lambda/user_migration/legacy_users.json` (it is a photograph of `auth.users` and
#    anyone added since it was taken cannot be migrated), and steps 2-3 are this same
#    deploy carrying `-c googleIdp=true -c entraIdp=true -c googleSignIn=true
#    -c entraSignIn=true -c authCallbackUrls=...`. Dropping those deletes the identity
#    providers and every federated sign-in with them.
#    `-c requireLegacySnapshot=true` makes synth FAIL if the snapshot is missing, which
#    is the only thing standing between a stale laptop and a Lambda that fails every
#    sign-in closed. The full flag set is written out below -- type it as it stands.
npx cdk deploy meridian-production-auth --exclusively -c env=production \
    -c requireLegacySnapshot=true \
    -c googleIdp=true -c entraIdp=true \
    -c googleSignIn=true -c entraSignIn=true \
    -c authCallbackUrls=https://app.meridiansgrp.com/auth/callback \
    --require-approval never

# 5. Re-paste the credentials. CDK recreates the secret with its PLACEHOLDER body
#    (`LEGACY_AUTH_SECRET_TEMPLATE`), not the old values — the Lambda would fail
#    every sign-in closed until this is done.
aws secretsmanager put-secret-value --secret-id meridian-production/legacy-supabase-auth \
    --secret-string '<the JSON from step 2>'
```

Then verify: `describe-user-pool --query 'UserPool.LambdaConfig'` names the function again, and
one real sign-in by a user who has not yet been migrated succeeds.

**Step 3 destroys the migration log group, and with it the record of who migrated and when.**
Step 3b above exports it into `meridian-production-s3-archive` and refuses to continue until
the export task reports `COMPLETED` and the prefix holds at least one object. File the
prefix name with the day's evidence.

Possible only while Supabase Auth still exists — i.e. until step 4 — and only within the
secret's 30-day window (after which step 2 returns nothing and the credentials have to come from
the Supabase dashboard instead).

---

### 2. The archive — the final dump, into the Object-Locked bucket

**What this destroys:** nothing. This step only creates.

This dump is **the long-term archive, not a rollback convenience** (plan §6). It is the only
record of: the pre-migration database; the gitignored seed data
(`supabase_migrations/seeds/017_qb_provider_map.sql`, which exists on one laptop and carries
real provider names); `qgenda_workspaces`, deliberately excluded from the RDS load (P-4); and
the `auth` schema, which nothing on AWS holds.

```bash
STAMP=$(date +%Y%m%d)
# Everything, this time: no --exclude-table, and THREE schemas.
#   public   the application data
#   auth     Supabase's identity tables — nothing on AWS holds these
#   storage  the object METADATA: storage.buckets and storage.objects. The
#            objects' bytes are NOT in here; see the custody table.
pg_dump --no-owner --no-privileges -Fc \
        -n public -n auth -n storage \
        -f /secure/meridian-final-archive-$STAMP.dump "$SUPABASE_URL"

sha256sum /secure/meridian-final-archive-$STAMP.dump \
  | tee /secure/meridian-final-archive-$STAMP.sha256
```

`-n storage` is the addition, and it is cheap: it is a few thousand metadata rows, and without
it the archive cannot answer "what objects existed on the day we cancelled, with what sizes and
what mime types". That question is the first one asked when a download 404s eighteen months
from now.

Note the difference from `cutover.md` step 3: **that** dump was `--data-only` and excluded
`qgenda_workspaces`, because it was feeding a schema Alembic already owned. This one is the
whole thing, schema and all, including the tables Meridian deliberately does not run.

Put it where nothing can delete it — **and that is not the `audit` bucket.**

> **Why the archive has its own bucket, and why this was worth a code change.** The first draft
> of this runbook sent a PHI dump to `meridian-production-s3-audit`. That bucket is
> `DataClassification=internal` and is encrypted with the **`logs`** CMK, which ADR 0020 §4
> deliberately keeps away from PHI so that "who may read the record of what happened" and "who
> may read the data" are two different grants. Putting 17,606 patient identifiers and the whole
> `auth` schema in it would collapse that distinction — **irreversibly**, because compliance-mode
> Object Lock means the mistake cannot be undone by deleting the object, for seven years, by
> anybody, including AWS. So `infra/meridian/stacks/data.py` now creates a fourth bucket,
> `meridian-<env>-s3-archive`: same seven-year compliance lock, same versioning, same TLS-only
> and KMS-only denies, but on the **`phi`** CMK and tagged `DataClassification=phi`. It exists in
> both environments and is empty until this step. ADR 0020 §5 carries the dated note.

```bash
aws s3 cp /secure/meridian-final-archive-$STAMP.dump \
    "s3://meridian-production-s3-archive/supabase-archive/$STAMP/meridian-final-archive.dump" \
    --sse aws:kms --sse-kms-key-id "<phi-cmk-arn>"

aws s3 cp /secure/meridian-final-archive-$STAMP.sha256 \
    "s3://meridian-production-s3-archive/supabase-archive/$STAMP/meridian-final-archive.sha256" \
    --sse aws:kms --sse-kms-key-id "<phi-cmk-arn>"

# Prove the lock actually applied to the object, not just to the bucket:
aws s3api get-object-retention \
    --bucket meridian-production-s3-archive \
    --key "supabase-archive/$STAMP/meridian-final-archive.dump"
```

That last command must come back `COMPLIANCE` with a retain-until date seven years out. Getting
the `--sse-kms-key-id` wrong does not quietly succeed: the bucket policy's `DenyWrongKmsKey`
statement turns a put under any other key into a 403, which is the same protection every other
bucket in the estate has. Seven years is HIPAA's six-year documentation retention (45 CFR
164.316(b)(2)) plus slack.

**Retention and custody, written down, not implied:**

| | |
|---|---|
| **Custodian** | Andres, named. |
| **Retention** | Seven years from the upload date, enforced by Object Lock — not by policy, not by intention. |
| **Disposal** | Per Track C, after the retention expires. |
| **The sentence that must never be written here** | *"delete after verification"*. The plan says so in as many words: that sentence and this step cannot both be true. This archive is the only record of the pre-migration database and it is **retained**. (The *cutover* dump is the opposite — a working copy, shredded after the first close. Two files, two obligations; `cutover.md` step 3 says so at the other end.) |
| **Contents** | PHI: 17,606 patient identifiers, the `auth` schema and the `storage` metadata. Treat every copy as PHI, including the laptop's. |
| **Where the objects' record is** | **Not in this dump.** The dump carries `storage.objects` — names, sizes, mime types — and none of the bytes. The objects themselves were copied to S3 at cutover and their record of custody is the **versioned, KMS-encrypted `meridian-production-s3-artifacts` and `meridian-production-s3-phi` buckets**, whose evidence is `cutover.md` step 4's `sync` output and its zero-`MISSING` `head_object` sweep, filed with the Phase 9 report. That is deliberate: those buckets are live, backed up and versioned, so freezing a second copy of every artifact under a seven-year lock would double the PHI footprint to protect something already protected. What this archive adds is the *index* — enough to prove what existed on the day. |

**Shred the laptop copy once the S3 object and its checksum are confirmed** — the S3 object is
the archive; a second copy on a laptop is a second thing that can leak.

**Evidence:** the sha256 file, the `get-object-retention` output, the object's version id, and
the custody table above transcribed into `docs/compliance/evidence/`.
**Rollback:** n/a — nothing was removed. (And note that the object cannot be deleted for seven
years even deliberately; if it turns out to contain the wrong thing, upload the right thing
beside it and document which is which.)

---

### 3. Verify the archive restores — **before** cancelling anything

**What this destroys:** nothing.

```bash
# The password has to be reachable afterwards, so capture it rather than
# generating it inline — the old version of this step threw it away and then
# used a $SCRATCH_URL it had never defined.
SCRATCH_PW=$(openssl rand -base64 24 | tr -d '/+=')
# The data directory is tmpfs — RAM, never the Docker volume store or a laptop
# backup (Codex PS-13). Size it for the dump; the final archive is well under 2G.
docker run -d --name meridian-archive-check \
    -e POSTGRES_PASSWORD="$SCRATCH_PW" \
    -e POSTGRES_DB=archive_check \
    --tmpfs /var/lib/postgresql/data:rw,size=4g \
    -p 127.0.0.1:55432:5432 \
    postgres:17

# Loopback only. A container that publishes 5432 on 0.0.0.0 is a PHI database
# on every network this laptop joins for as long as it runs.
export SCRATCH_URL="postgresql://postgres:$SCRATCH_PW@127.0.0.1:55432/archive_check"

# Pre-create the four roles Supabase's dump references as grantees. Without
# them every GRANT in the dump errors, and a restore that reports two hundred
# errors is one nobody reads.
for role in authenticated anon service_role supabase_auth_admin; do
  psql "$SCRATCH_URL" -c "CREATE ROLE \"$role\" NOLOGIN;" || true
done

# Same idea for the extensions. Supabase installs pgcrypto and uuid-ossp into a
# schema called `extensions`, and the dump's DDL says `extensions.gen_random_uuid()`
# and `extensions.uuid_generate_v4()` in column defaults. Stock `postgres:17` has
# neither the schema nor the extensions, so --exit-on-error stops on the first
# table that has such a default. Create them BEFORE the restore: an extension
# cannot be added retroactively to a half-restored schema.
psql "$SCRATCH_URL" -c 'CREATE SCHEMA IF NOT EXISTS extensions;'
psql "$SCRATCH_URL" -c 'CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;'
psql "$SCRATCH_URL" -c 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;'

# 3a. Restore the ARCHIVE, not the laptop copy step 2 already shredded (Codex
#     PS-16): download the recorded S3 version, verify the checksum step 2 logged,
#     and restore that file. This is the only step that proves the retained,
#     Object-Locked, KMS-encrypted copy can actually be read back.
aws s3api get-object --bucket meridian-production-s3-archive \
    --key "supabase-final/meridian-final-archive-$STAMP.dump" \
    --version-id "<the VersionId step 2 logged>" \
    /secure/restore-check-$STAMP.dump >/dev/null
[ "$(shasum -a 256 /secure/restore-check-$STAMP.dump | cut -d' ' -f1)" = "<the sha256 step 2 logged>" ] \
    || { echo "checksum mismatch — STOP"; exit 1; }

# --exit-on-error: a restore that limps to the end with errors is not evidence.
pg_restore --no-owner --no-privileges --exit-on-error -d "$SCRATCH_URL" \
           /secure/restore-check-$STAMP.dump
```

**If `--exit-on-error` stops the restore**, do not just drop the flag and re-run. There are
three causes, and only the last one is the archive's fault:

1. **A missing role** — `role "..." does not exist`. Add it to the loop above, drop the
   database, start again.
2. **A missing extension** — `schema "extensions" does not exist`, or `function
   extensions.gen_random_uuid() does not exist`, or `type "..." does not exist` for a
   Supabase-installed type. Same fix: add the `CREATE EXTENSION` for whatever the dump names
   (`pgjwt`, `pg_stat_statements` and `pg_graphql` can all show up depending on what the
   project had enabled), drop the database, start again. `pg_restore -l
   /secure/meridian-final-archive-$STAMP.dump | grep EXTENSION` lists them in advance.
3. **A genuinely damaged dump** — which is what this step exists to find. If, after a documented
decision, the restore is run without `--exit-on-error`, then **the error count is the evidence**:

```bash
pg_restore --no-owner --no-privileges -d "$SCRATCH_URL" \
           /secure/meridian-final-archive-$STAMP.dump 2>&1 \
  | tee /secure/archive-restore-$STAMP.log
grep -c '^pg_restore: error' /secure/archive-restore-$STAMP.log
```

That number goes in the log with an explanation of each distinct error, or the archive is not
verified. Then the counts:

```bash
psql "$SCRATCH_URL" -At -c \
  "SELECT table_schema||'.'||table_name||'='||
          (xpath('/r/c/text()', query_to_xml(
             format('SELECT count(*) AS c FROM %I.%I', table_schema, table_name),
             false, false, '')))[1]::text
     FROM information_schema.tables
    WHERE table_schema IN ('public','auth','storage') AND table_type='BASE TABLE'
    ORDER BY 1;"
```

Compare that list against the same query run on live Supabase. **Every count must match**, and
`auth.users`, `storage.objects` and `qgenda_workspaces` must all be present and non-empty —
`auth.users` and `qgenda_workspaces` exist nowhere else after step 5, and `storage.objects` is
the index of what was in the bucket on the day.

Then destroy the scratch container **and its volumes** (`docker rm -fv meridian-archive-check`;
the `-v` is what removes an anonymous volume, and `docker volume ls -q | xargs -r docker volume
inspect | grep archive` afterwards must print nothing). The data directory was tmpfs, so
stopping the container is what erases it — but check, do not assume. Then `rm -f` the
downloaded archive copy from step 3a.

**Evidence:** the two count lists, side by side, in the log, with the row for `auth.users` and
`qgenda_workspaces` circled.
**Rollback:** n/a. If the counts do not match, **stop the whole phase** and go back to step 2.
A mismatch here means the archive is wrong, and the archive is the only thing making step 5
survivable.

---

### 4. Disable Supabase Auth, then pause the project

**What this destroys:** the ability for anyone to sign in *to Supabase* — which, after step 1,
nothing in Meridian does. It also ends Point of No Return #2 in practice.
**Pausing is recoverable**: a paused Supabase project can be restored. This is the last step
with a way back.

## 🛑 STOP — ask Andres

> *"Turning off Supabase Auth and pausing the project. Nothing in Meridian uses either any more
> — I closed the last dependency in step 1 and the archive verified. A paused project can still
> be brought back; the next step after this cannot. Go ahead?"*

1. Supabase dashboard → Authentication → disable the Google and Microsoft providers, then
   disable email/password sign-in.
2. Wait 24 hours with Auth off and the project still live. This is cheap and it is the window in
   which an unnoticed dependency announces itself.
3. Supabase dashboard → Settings → **Pause project**.
4. Wait a further week paused. Watch the AWS dashboard and the support inbox.

**Evidence:** the provider list showing all disabled; the pause confirmation with its date; a
clean week of production alarms after each of 2 and 4.
**Rollback:** re-enable the providers; restore the paused project from the dashboard. Minutes to
hours.

---

### 4b. Export what the project deletion destroys and the dump does not carry

The step 2 dump is the database. It is **not** the auth event log, the API/PostgREST logs or
the storage access log, all of which the project deletion in step 5 erases (Codex PS-17). Before
step 5: Supabase dashboard → Logs → export each of *Auth*, *API* and *Storage* for the full
retention window to `/secure/supabase-logs-$STAMP/`, then `aws s3 cp --recursive` them into
`meridian-production-s3-archive` under `supabase-final/logs/` and record the object versions
in the log. **Evidence:** the three object listings. **Rollback:** n/a — additive.

### 5. Cancel the Supabase project — **IRREVERSIBLE**

**What this destroys:** the project, its database, its storage, its auth users, its logs, its
backups and its history — permanently, for everyone, with no undo, no support ticket and no
recovery window. Users created after Flip 2 cannot recover old passwords because the old
password hashes cease to exist. **After this, the S3 archive from step 2 is the only record of
the pre-migration database**, and restoring from it means standing a new PostgreSQL up and
pointing something at it: hours to days, not minutes.

This is plan §6 Point of No Return #3, and it is the only one in the whole migration with no
procedural way back.

## 🛑 STOP — ask Andres

Do not paraphrase this one. Read it out:

> *"This deletes the Supabase project for good. Two closes have run on AWS and tied out. The
> archive is in `meridian-production-s3-archive` under a seven-year Object Lock and I
> restored it into a scratch
> database and matched every table count. After I do this, the only copy of the old database is
> that archive, and getting anything back from it takes a day, not five minutes. There is no
> undo and no support ticket that reverses it. Do you want me to cancel the project?"*

Wait for an explicit yes, in words, on the day. Then:

- Supabase dashboard → Settings → General → **Delete project**, and type `<project-ref>` when it
  asks.

**Evidence:** the deletion confirmation, the date and time, and the name of the person who said
yes, in the log and in `docs/reports/phase-10-report.md`.
**Rollback:** **none.** The archive is the rollback and it is not a rollback, it is a recovery
project.

---

### 6. Render: suspend, wait a week, delete

**What this destroys:** the last environment that can serve the old application. Suspension
destroys nothing and is reversible; deletion removes the services, their environment variables
and their deploy history.

## 🛑 STOP — ask Andres (before the delete, not before the suspend)

> *"Both Render services have been suspended and quiet for a week. Deleting them removes the
> services and everything configured on them, including any environment variable that was only
> ever set in that dashboard. Go ahead?"*

**They have been in maintenance mode since the cutover, and that is the state to find them in.**
`cutover.md` step 9 leaves both services running, warm, and serving the maintenance banner, for
the whole two-close wait. If they are *not* in maintenance when you get here, something took
them out of it — find out what and when before going any further, because a Render that has been
serving has been writing to Supabase, and the archive in step 2 is only as good as the last
write it captured.

1. **Suspend** both services (`meridian-api`, `meridian-web`). Do not delete. Suspending is the
   step that finally makes them cold; until now they were warm on purpose.
2. **Wait one full week, suspended and not deleted.** A week is long enough for a monthly-ish
   task or a forgotten webhook to fail loudly.
3. Before deleting, **copy out anything that exists only there**: the environment-variable names
   (names, not values — the values are rotated in step 8 anyway), any deploy configuration
   not already in `render.yaml`, **and the deploy history and the last 90 days of service logs**
   (`render deploys list`, the dashboard's log export) into `meridian-production-s3-archive`
   under `render/` — they are the only record of what ran in production before the flip
   (Codex PS-17). The live services were provisioned outside the blueprint, so
   `render.yaml` is not a faithful record of them.
4. **Delete** both services. Then delete the Render account if nothing else uses it.
5. Delete `render.yaml` from the repository. It already describes services that never matched
   the live ones, which is exactly why it is going.

**Evidence:** the suspension date, the quiet week (no alarms, no support mail), the exported
variable-name list, the deletion confirmations.
**Rollback:** until step 4, un-suspend. After step 4, re-creating the services is possible but
pointless — by then they have no database to talk to.

---

### 7. DNS cleanup

**What this destroys:** the records that pointed at Render. Getting this wrong takes a hostname
dark, so check what each record is before removing it.

**The two big ones are already gone, and they went in code.** `cutover.md` step 7a removed
`ApexToRender` and `WwwToRender` by deploying `meridian-shared-dns` with `-c
renderRecords=false`; the constants `RENDER_APEX_IP` and `RENDER_WWW_HOST` are still in
`infra/meridian/stacks/dns.py`, unused, behind that flag. **This step does not touch them and
must not remove them from the console.** They come out of the source in step 9, together with
the flag itself, once Render is deleted and there is nothing left to point at — that is a code
change with a `cdk diff` and a test, not a DNS edit.

First, confirm the apex and `www` really are aliases and really are absent from Render:

```bash
aws route53 list-resource-record-sets --hosted-zone-id "<zone-id>" \
  --query "ResourceRecordSets[?Name=='meridiansgrp.com.'||Name=='www.meridiansgrp.com.'].\
{Name:Name,Type:Type,Alias:AliasTarget.DNSName,Values:ResourceRecords[].Value}"
```

Four rows, every `Alias` ending `.cloudfront.net.`, every `Values` null. If any row still has
`ResourceRecords`, the cutover's step 7 did not complete or someone re-added it by hand —
**stop and fix that before deleting Render**, because deleting Render with a live apex A record
pointing at its IP takes the bare domain dark.

What remains for this step is any *other* record still naming `<render-hostname>` — typically an
old `CNAME` or a validation record from Render's certificate issuance:

```bash
aws route53 list-resource-record-sets --hosted-zone-id "<zone-id>" \
  --query "ResourceRecordSets[?ResourceRecords[?contains(Value, '<render-hostname>')]]"
```

For each hit: confirm what it is, confirm nothing resolves it — `dig` it at the zone's own
nameservers, and check the CloudFront and ALB access logs for the name — then remove it with a
`change-resource-record-sets` `DELETE`.

```bash
# The zone's first nameserver, for the `dig` above.
NS=$(aws route53 get-hosted-zone --id "<zone-id>" \
       --query 'DelegationSet.NameServers[0]' --output text)
dig +noall +answer @"$NS" "<the record being removed>"
```

**Also sweep GoDaddy**, not just Route 53. The registrar's own zone is no longer authoritative
after the Phase 1 nameserver move, but records left behind there are a trap for anyone who ever
switches the nameservers back, and `dns-nameserver-switch.md` §6 keeps that as the rollback for
the *nameserver* move. Leave the GoDaddy zone intact **unless** Andres has decided the
nameserver move is permanent — in which case removing the Render records there is tidy-up, and
it is his call, in his account.

**Do not remove:** the SES DKIM/MAIL FROM records, the Microsoft 365 records, the SRV records,
`_domainconnect`, the ACM validation records, or `ai` — `infra/dns/meridiansgrp.com.zone.json`
and `scripts/dns_zone_diff.py` are the inventory, and the Phase 1 runbook explains each one.

**Evidence:** the record list before and after; a `dig` for the apex, `www` and any removed name.
**Rollback:** re-create the record from the `before` list. Seconds, plus the TTL.

---

### 8. Rotate every secret Supabase or Render ever held

**What this destroys:** nothing that is still in use — but assume any value that lived in a
vendor dashboard is now outside your control, because a deleted dashboard is not a shredded one.

Rotate, do not merely delete:

The names below are the real ones, taken from `infra/meridian/stacks/data.py`
(`resource_name(env, "secret", …)` → `meridian-<env>-secret-<purpose>`, with hyphens) and
`auth.py` (the two IdP secrets and the legacy one are `meridian-<env>/<purpose>`, with a slash —
the inconsistency is real, and guessing between the two forms is how a rotation silently
targets nothing).

| Secret | Why |
|---|---|
| Supabase service-role key and anon key | They were in Render's environment and in local `.env` files. Dead with the project, but record them as retired. |
| **The Supabase JWT secret** | The HS256 key every Supabase-issued token was signed with. It is not "dead with the project": any token minted before cancellation is still verifiable by anything that kept a copy of this value, and it sat in Render's environment and in `.env`. Step 1 stopped Meridian accepting those tokens; this row records the signing key itself as retired, and checks that no `.env`, no vault note and no CI secret still carries it. |
| Google and Microsoft OAuth client secrets | They were created for Supabase's redirect URIs and re-used by Cognito. **Rotate at the identity provider, then update `meridian-production/google-idp` and `meridian-production/entra-idp` and redeploy `meridian-production-auth`** — this one is live and matters. |
| The database password Supabase issued | Gone with the project; confirm nothing on AWS reuses it. |
| `RESEND_API_KEY` / `RESEND_FROM_EMAIL` | The Resend account is closed in Phase 7; if anything is left, close it now and revoke the key. |
| Any Render-only value | Deploy hooks, webhook signing secrets, third-party keys set in that dashboard and nowhere else. |
| **GitHub Actions secrets** | `.github/workflows/` authenticates to AWS by OIDC, so there is no long-lived key to rotate there — but any repository or environment **secret** that carried a Supabase URL, service key or Render deploy hook is a copy of a retired credential sitting in a third system. List them (`gh secret list`, names only) and delete the dead ones. |
| **GitHub Actions variables** | Same sweep, different store: a `SUPABASE_URL` or `RENDER_SERVICE_ID` left in `gh variable list` is not a secret but it is a stale fact that a future workflow will act on. Delete them with the secrets. |
| Application secrets in AWS | `meridian-production-secret-db-app`, `meridian-production-secret-db-phi`, `meridian-production-secret-origin-verify` — rotate per `rotate-secrets.md` and `rotate-origin-verify-secret.md`. (There is no `app-env` secret and no `db-phi-access`; both names were invented. The database master credential is `meridian-production-secret-db-master` and rotates on its own 30-day schedule.) |
| **`meridian-production-secret-phi-hmac-key`** | **Do NOT rotate this here.** It decides every `patient_ref` in the database; rotating it rewrites every token and needs the re-keying plan in `rotate-secrets.md` §4. |

**Evidence:** a dated list of what was rotated and what was retired, by **name only** — no
values, ever, in this file, in the log, in a commit or in the vault.
**Rollback:** re-rotate. A rotation is never the thing you undo.

---

### 9. Code, configuration and documentation

**What this destroys:** the code paths that could talk to Supabase. After this the repository
cannot reach it even if someone restored it.

```
src/database.py            DatabaseSupabase — delete
src/storage.py             the Supabase branches — delete
src/auth.py                the Supabase token path (already dead after step 1) — delete
tests/legacy_supabase/     delete
requirements.txt           the `supabase` dependency — remove
deploy/aws-trial/          delete, if Phase 3 did not
render.yaml                deleted in step 6
the `.sb` aliases          delete
every SUPABASE_* env var   .env.example, render.yaml, docs, task definitions
```

And the two Render facts that are still in the infrastructure, which step 7 deliberately did
**not** touch from a console:

```
infra/meridian/stacks/dns.py   RENDER_APEX_IP, RENDER_WWW_HOST, RENDER_RECORDS_FLAG
                               and the `if self.render_records:` branch — delete all four
infra/tests/test_dns.py        the three renderRecords tests and the two imports — delete
infra/dns/*.zone.json          re-export, so the checked-in zone matches the live one
```

Deleting the flag makes the two records unconstructable rather than merely off, which is the
point: by now Render does not exist, so a `renderRecords=true` deploy would re-create an A
record pointing at an IP somebody else owns. Do it as one commit with a `cdk diff` that shows
**no change at all** (the records are already absent from the live zone), and re-run
`scripts/dns_zone_diff.py`.

`infra/meridian/stacks/compute.py`'s `acceptSupabaseTokens` flag and
`infra/meridian/stacks/auth.py`'s `legacyMigration` flag stay for now — see "Open items".

Add a test that proves nothing imports any of it — the same shape as the Phase 7 test that
proved nothing still called Resend. A deletion without that test is a deletion that comes back.

Then the documents:

- [ ] `CLAUDE.md` (local, gitignored) — the "all data in Supabase" rule is already replaced
      (D-01); make sure nothing in it still names Supabase or Render as live.
- [ ] `README.md` — the architecture paragraph.
- [ ] `docs/architecture/` — the data-flow diagram and the inventory. Supabase and Render come
      out of both.
- [ ] `docs/compliance/` — **the BAA register**. Remove Supabase and Render as business
      associates, with the termination date; record that the archive holds their data and where.
      A BAA register that still lists a vendor you deleted is wrong in the direction auditors
      care about.
- [ ] `docs/compliance/control-matrix.md` — the termination-procedure row still describes the
      dual-acceptance window (Flip 1 → cut-off). That window closed in step 1; rewrite the row
      to say `AdminDisableUser` is now sufficient on its own.
- [ ] `docs/runbooks/README.md` — mark the retired rows.
- [ ] `docs/migration-tracker.md` — **lists only Phase 11 and Phase 12 items** when this phase
      closes. That is the exit criterion, not a nicety.
- [ ] `CHANGELOG.md` — one plain-language entry.
- [ ] The Obsidian vault, under `NS_Proccess/` — a short note, no secrets.

**Evidence:** the commit; the "nothing imports Supabase" test, green; the BAA register diff.
**Rollback:** `git revert`. The code is the one thing here that is always reversible.

---

## Evidence to keep

| Artifact | Where |
|---|---|
| Final Cognito migration report (counts only) | `docs/reports/phase-10-report.md` |
| Pool `LambdaConfig` before and after step 1 | The log |
| Archive sha256, S3 version id, `get-object-retention` output | `docs/compliance/evidence/` |
| The custody table (custodian, retention, disposal) | `docs/compliance/evidence/`, and Track C |
| Step 3's two count lists, side by side | `docs/reports/phase-10-report.md` |
| Supabase deletion confirmation, date, and who said yes | `docs/reports/phase-10-report.md` |
| Render suspension date, the quiet week, deletion confirmations | The log |
| DNS record list before and after | The log |
| Rotated-secret list, **names only** | `docs/compliance/evidence/` |
| BAA register diff | `docs/compliance/` |

---

## Open items

* **`AUTH_ACCEPT_SUPABASE_TOKENS` is read by `src/settings.accept_supabase_tokens()` and
  defaults to `true`.** It is now written into the api task definition by
  `_api_environment()` in `infra/meridian/stacks/compute.py`, behind
  `-c acceptSupabaseTokens`; step 1 deploys it false. It should stop being a setting at all in
  Phase 12, along with `src/auth.py`'s two-issuer branch and the CDK flag. Tracker row.
* **`-c legacyMigration=false` leaves the flag in `auth.py`.** Once the Supabase project is
  cancelled the Lambda can never work again, so the flag, the `_migration_lambda` /
  `_legacy_auth_secret` methods, `lambda/user_migration/` and the two tests are all dead code
  kept only because deleting them during the phase would mean no rollback. Phase 12 removes
  them, and until it does, `legacyMigration=true` is a deploy that re-creates a Lambda holding
  a secret nothing can fill. Tracker row.
* **The two unhandled Cognito challenges** (`MFA_SETUP`, `NEW_PASSWORD_REQUIRED`) must have
  screens before step 1, not after — the tracker already carries this with that deadline, and
  after step 1 there is no fallback for a user who hits either.
* **`qgenda_workspaces` exists only in the archive after step 5** (P-4). If it turns out to be
  Meridian's, it comes back as a new Alembic revision restored from the archive — which is a
  day's work, and the reason step 3 checks that table by name.
* **Four local branches and two retired GitHub repositories** still carry commit `1b4f8d9`, whose
  tree contains bank and payroll workbooks. `docs/migration-tracker.md` has both rows with
  "Before Phase 10" as the deadline and **Andres** as the owner. They are not Supabase or Render,
  so this runbook does not act on them — but Phase 10 does not close with those rows open.
* **The Resend account** (Phase 7's tracker row) is closed by Andres, not by this runbook; step 8
  only revokes the key if it is still live.
* **`docs/reports/phase-10-report.md` does not exist yet.** Several evidence rows above point at
  it. It is written as the phase closes, like every other phase report.

## Related

`cutover.md` (Phase 9 — everything here assumes it ran two closes ago) ·
`cognito-user-migration.md` §7 (the cut-off, in the auth runbook's own words) ·
`restore-drill.md` (the precondition) · `rotate-secrets.md` (step 8, and §4 for the HMAC key
that must **not** be rotated) · `rotate-origin-verify-secret.md` ·
`dns-nameserver-switch.md` (the Route 53 zone and the GoDaddy fallback) ·
`docs/adr/0016-cloudtrail-second-trail.md` and `docs/adr/0020-data-tier.md` §5 (the Object-Locked
`meridian-production-s3-archive` bucket) · `docs/adr/0021-auth-cognito-sessions.md` (dual acceptance and its off switch).
