# Runbook — revoke (or pause) an API client

**When:** a machine client's secret has leaked or may have; a partner relationship ends; a
client is behaving badly; the quarterly access review finds a client nobody can explain.
**Who:** an org admin of the client's organization can revoke or disable. Re-enabling needs
a superadmin (Andres).
**Time:** two minutes. The client is refused from its **next request** — well inside the
one-minute promise (ADR 0037).
**Status:** written in Phase 12 (T17) and **never executed** against a deployed environment.
It becomes evidence once T24 runs it on staging with the timestamps recorded
(`docs/runbooks/README.md`).

## Words used here

| Word | Meaning |
|---|---|
| **API client** / **machine client** | A program (our script, a partner's system) that calls `/api/v3` with no person present. One row in `public.api_clients`, backed by one Cognito **app client**. |
| **App client** | The object in the Cognito user pool that holds the client's id and secret. The program trades them at Cognito's `/oauth2/token` for a **15-minute access token**. |
| **Access token** | What the program sends on every call (`Authorization: Bearer …`). Cryptographically valid until it expires, even after we decide to cut the client off. |
| **`revoked_epoch`** | A timestamp on the client's row. Any token **issued before** it is refused. Because the api re-reads the row on every request (`src/api_clients.authorize`, `api/v3/deps.py`), setting it cuts off tokens that have not expired yet. |
| **Revoke** | Permanent: `status='revoked'`, `revoked_epoch=now()`, then the Cognito app client is deleted so no new token can be minted. There is no un-revoke; a new client is a new request and approval. |
| **Disable** | Reversible: `status='disabled'`, `revoked_epoch=now()`. The app client stays. Tokens minted before the disable stay dead even after a re-enable. |

**Revoke** when the secret may be in someone else's hands or the relationship is over.
**Disable** when you want the client off *for now* (a partner's bug flooding us, a paused
integration) and expect to turn it back on.

## 1. Find the client

The admin screen (**Admin → API clients**, `web/src/app/admin/api/`, Phase 12 T13) lists
every client of your organization with its status, scopes, last use and last IP. Until that
screen ships, use the API — it is the same code path (`api/v3/routers/admin_clients.py`):

```bash
BASE=https://api.meridiansgrp.com/v3            # staging: https://staging-api.meridiansgrp.com/v3 (ADR 0050)
TOKEN=<your own ID token>                        # the bearer flow: docs/plans/mobile-readiness.md
curl -sS -H "Authorization: Bearer $TOKEN" "$BASE/admin/api-clients?limit=50"
curl -sS -H "Authorization: Bearer $TOKEN" "$BASE/admin/api-clients/<client id>/usage"
```

`/usage` shows when and from which address the client last authenticated (written at most
once a minute). Note `last_used_at` and `last_used_ip` for the write-up. **Never paste the
response into a chat or a ticket** — it carries the client's name, which may be a partner's.

A client of **another** organization answers `404 NOT_FOUND`, exactly like one that does not
exist (object-level authorization). If you need to revoke across organizations, that is a
superadmin acting inside that organization, not a cross-org call.

## 2. Revoke it (or disable it)

```bash
# permanent
curl -sS -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"reason":"secret exposed in partner ticket 2026-10-01"}' \
  "$BASE/admin/api-clients/<client id>/revoke"

# reversible
curl -sS -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"reason":"partner loop flooding runs:read"}' \
  "$BASE/admin/api-clients/<client id>/disable"
```

`reason` is required (3-500 characters) and lands in `audit.api_client_change`. Write *why*,
never a secret, a token or a person's details.

What happens, in order (`src/api_clients.revoke`):

1. The row commits: `status='revoked'`, `revoked_epoch=now()`, and one audit row
   (`action='revoke'`, scopes before → none). **From this moment every request the client
   makes is `401`**, whatever token it holds.
2. The api deletes the Cognito app client (`DeleteUserPoolClient`), so the program cannot
   even get a new token.

**If step 2 fails** (Cognito unreachable, a permission problem) the answer is still `200` —
the row already refuses everything — and the api logs
`api client revoked but its Cognito app client was not deleted`. Go to §4 and delete the
orphan by hand.

`409 API_CLIENT_STATE_INVALID` means the client is already revoked (or, for disable, not
active). `503 IDENTITY_PROVIDER_UNAVAILABLE` on revoke does not happen — see above; on
approve or rotate it means Cognito could not be reached and nothing changed.

## 3. Confirm it is refused — within one minute

1. **Status.** `GET $BASE/admin/api-clients/<client id>` shows `"status": "revoked"` (or
   `disabled`).
2. **A real call is refused.** If you hold a test token for the client (staging), any `/api/v3`
   call with it now answers `401 AUTH_REQUIRED` — the same plain answer as an unknown client,
   deliberately. Record the time of the revoke and the time of the first refused call.
3. **The audit trail** (as the owner role through `docs/runbooks/db-access.md`; `meridian_app`
   may only *insert* into `audit.*`):

   ```sql
   SELECT at, action, reason FROM audit.api_client_change
    WHERE api_client_id = '<client id>' ORDER BY id;
   SELECT at, route, status FROM audit.api_request
    WHERE api_client_id = '<client id>' AND at > now() - interval '1 day' ORDER BY at DESC;
   ```

   The last `api_client_change` row is `revoke`/`disable`. After it, `api_request` should show
   no `2xx` for that client.
4. **The machine-token alarm.** A partner still retrying with the dead client shows up as
   `meridian-<env>-alarm-machine-auth-failures` (`docs/runbooks/alerts.md` §8). Expected for a
   while after a revoke; it clears when they stop.

## 4. Check Cognito has no orphan

```bash
python3 scripts/api_access_review.py --actor <your superadmin user id> --check-cognito --dry-run
```

Any row of kind `cognito-only` is an app client in the pool with no live `api_clients` row —
a revoke whose step 2 failed. Delete it (read the id from that row; never touch
`meridian-<env>-auth-web`, the web sign-in client):

```bash
aws cognito-idp delete-user-pool-client --user-pool-id <pool id> --client-id <app client id>
```

The pool id is the `UserPoolId` output of `meridian-<env>-auth`.

## 5. Webhooks the client owned

A revoked or disabled client's webhook subscriptions stop receiving on their **next attempt**:
every delivery re-checks that the owning client is active with `webhooks:manage`
(`src/webhooks/engine.py`, reason code `CLIENT_INACTIVE`, delivery status `dropped`). Nothing
to do unless the client comes back — then see `docs/runbooks/alerts.md` §8, "Redrive".

## 6. Tell the partner (revoke only)

Short, factual, no internal detail: the client id (not our internal row id), the time it
was revoked, and that a replacement needs a new request (`docs/runbooks/onboard-partner.md`).
If the reason is a leaked secret, ask them where it leaked; a secret that leaked once
will leak again from the same place.

If the leak could have exposed **PHI** — only possible for a client holding `phi:read`, which
no client does today (ADR 0042) — this is an incident: `docs/runbooks/incident-response.md`.

## 7. Bring a disabled client back

`POST $BASE/admin/api-clients/<client id>/enable` with a `reason`, **as a superadmin** — it is a
re-approval (`src/api_clients.enable`). Tokens issued before the disable stay refused; the
program simply fetches a new one. A **revoked** client cannot come back.

## The idle sweep does this for you, gently

`scripts/disable_idle_api_clients.py` **disables** (never revokes) every client unused for 90
days, with reason `unused for 90 days`. With `-c enableApiPlatform=true` and
`-c apiIdleSweepActor=<superadmin id>` it runs daily at 06:15 US Central as a one-off api task
(`infra/meridian/stacks/api.py`); otherwise run it by hand, `--dry-run` first. A client it
disabled comes back through §7.
