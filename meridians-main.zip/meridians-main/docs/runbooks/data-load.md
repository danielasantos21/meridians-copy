# Runbook — data load, PHI split and parity (Phase 3 step 11)

**What this covers:** moving the Meridian data out of Supabase and into RDS, splitting the
patient identifiers into the `phi` schema, and proving — in numbers — that nothing changed on
the way. Plan `docs/aws-migration-plan.md` Phase 3 step 11, §2.3, and §6 "Parallel run and
reconciliation".

**What it does not cover:** the schema itself (`migrations.md`), the storage/object move,
DNS, or the cutover sequence (`cutover.md`, Phase 9).

> **Staging: run `scripts/staging_data_load.sh`, not the commands below by hand.** A review
> before its first run (2026-10-05) found these steps wrong as written: the source is
> `SUPABASE_DB_URL` (session pooler, port 5432), not `SUPABASE_URL`; the dump must be
> `--schema=public` (a whole-database dump carries `auth`, `storage` and more, which the target
> does not have); the `setval` SQL below raises on tables without an `id` (use the script's
> loop); step 0 cannot run on an empty database (it needs head and a superadmin row); and
> `--at head` parity compares only the tables both schemas share, since later revisions add
> and drop tables. The script does all of that and keeps the dump and reports on
> `/Volumes/MeridianPHI`.
>
> **This runbook has not been executed yet.** Until it has been run end to end once, with the
> date and the timings recorded in the table below, it is a plan and not evidence. The
> rehearsal happens on staging; the real run happens during the Phase 9 freeze.

---

## Before you start

| | |
|---|---|
| **Roles** | `meridian_migrator` on the target (the RDS master user). A read-only role on the source — `CONNECT` plus `SELECT` on `public` is enough, and it needs **no privilege on any sequence**: `sequence_ahead_of_max` is judged on the target alone (see step 5). Never the application role. |
| **Access** | The target is private: `psql` goes through SSM port-forwarding — see `db-access.md`. |
| **Secrets** | `MERIDIAN_PHI_HMAC_KEY` from Secrets Manager. It goes in the environment only — not argv, not a file, not the shell history, and **not the PostgreSQL log**. See "The key" below. |
| **Freeze** | For the real run, writes to Supabase are frozen first. For a rehearsal they are not, and the parity numbers will drift while you work — that is expected, and it is why the rehearsal proves the *procedure* and the real run proves the *data*. |
| **Tools** | `psql`, `pg_dump`/`pg_restore` (same major version as the target or newer), the repo's venv. |

### The key

`public.transactions.patient_ref` is `HMAC-SHA256(patient_id, key)`, hex. The key decides
every token in the database.

* Put it in the environment, not on a command line: `read -rs MERIDIAN_PHI_HMAC_KEY && export MERIDIAN_PHI_HMAC_KEY`.
* **Key policy:** at least 32 characters from `A-Z a-z 0-9 + / = _ -`
  (`^[A-Za-z0-9+/=_-]{32,}$`). `scripts/split_phi.py` refuses anything else and never
  prints the value back. The secret the infrastructure mints
  (`meridian-<env>-secret-phi-hmac-key`, 64 alphanumeric characters) satisfies it.
* **It never reaches the PostgreSQL log, and that is a fix, not an assumption.** The
  wrapper passes the key to `psql` as a libpq **startup option**
  (`PGOPTIONS="-c meridian.phi_hmac_key=..."`) and the SQL reads it back with
  `current_setting('meridian.phi_hmac_key', true)`. Startup options are in the startup
  packet, which `log_statement`, `log_min_error_statement` and pgaudit never see; they log
  the statements a session runs, and the text of every statement in `split_phi.sql`
  contains that function call and nothing else.

  This replaced a psql `\set`, which substituted client-side and so put the key **into the
  `UPDATE`** — and RDS runs `pgaudit.log = 'ddl,role,write'` and
  `log_min_error_statement = error`, both of which write statement text into
  `/aws/rds/instance/<id>/postgresql`: a 400-day PHI log group (ADR 0020 §3d). If you ever
  run the SQL by hand, **do not** reintroduce a `\set`; export `PGOPTIONS` instead.
* **A different key means different tokens, and the script now refuses one.**
  `phi.hmac_key_fingerprint` holds `sha256(key)` for the key that wrote every
  `patient_ref`. A second run with a different key raises. `--rotate` is the deliberate
  re-keying and it rewrites every token — read `rotate-secrets.md` §4 first.

---

## The order, and why it is this order

```
  1  dump        pg_dump --data-only from Supabase
  2  schema      alembic upgrade 0003_rds_adaptations   on the empty RDS database
  3  restore     pg_restore --data-only                  into the target at 0003
  4  split       python scripts/split_phi.py             (the PHI split, one transaction)
  5  parity #1   python scripts/verify_parity.py --at 0003
  6  migrate     alembic upgrade head                    (0004 RLS, then 0005 drops columns)
  7  parity #2   python scripts/verify_parity.py --at head
```

Three constraints fix that order and none of them is negotiable:

1. **The load window is between 0003 and 0004.** Revision 0004 turns on `FORCE ROW LEVEL
   SECURITY`, and `FORCE` applies to the table **owner** as well. After 0004 the migrator
   sees zero rows without `app.org_id`, so a `pg_restore --data-only` fails and an `UPDATE`
   silently matches nothing. (`tests/test_migrations.py` asserts both halves of this.)
2. **The split has to read the identifier columns, and 0005 drops them.** So the split runs
   before `upgrade head`, and 0005 refuses to drop anything unless it can see that the split
   ran — every row tokenised, `phi.transaction_identity` the same size as
   `public.transactions`. If it did not run, the upgrade fails loudly and changes nothing.
3. **Alembic revisions are linear.** There is no arrangement in which 0005 comes before
   0004; step 6 applies both, in that order, in one command.

---

## The steps

### 0. Staging only — the restore guard (Phase 12, ADR 0041)

**Before any restore into STAGING**, and before step 2 touches the target, run this against
the staging database as it is now:

```bash
python3 scripts/restore_guard.py --confirm-env staging --actor <your superadmin user id> --dry-run
python3 scripts/restore_guard.py --confirm-env staging --actor <your superadmin user id>
```

**`scripts/staging_data_load.sh` does not run this for you** — it drops and recreates the
database, and the guard has to read the one that is there *before* that. So, by hand, first:

* **Staging already has a `meridian` database** (any re-load, i.e. `--fresh`): open the tunnel
  from `db-access.md` §2 (port 55432), point the guard at it as `meridian_app` the way the load
  script addresses the tunnel —
  `POSTGRES_URL="postgresql://meridian_app@<rds-endpoint>:55432/meridian?hostaddr=127.0.0.1&sslmode=verify-full&sslrootcert=$HOME/.postgresql/rds-ca.pem"`
  (`src/settings.postgres_dsn` refuses anything weaker than `verify-full` outside development),
  `PGPASSWORD` from `meridian-staging-secret-db-app`, and `MERIDIAN_STAGING_ACCOUNT_ID` in the
  environment or `.env` — and run the two commands above, dry run first. `--actor` is a row of
  `public.superadmins` **in staging**. Then **close that tunnel**
  (`pkill -f session-manager-plugin`): the load script opens its own on the same port and stops
  if 55432 is taken. Then `scripts/staging_data_load.sh --fresh`.
* **Staging has no `meridian` database** (the first load, or after `staging-teardown.md`): there
  is no `api_clients` table, so no sandbox client can exist, and the guard cannot run — it fails
  closed (exit 2) because it cannot read the table. Write `restore guard: skipped, no staging
  database, <time>` in the log. Then, **as soon as the load finishes** (the database is at head),
  run the guard once for real (no `--dry-run`, with a superadmin row present —
  `scripts/add_superadmin.py` if the script said none was copied) so the restore record exists;
  without it, an older wipe record would still let `scripts/seed_sandbox_org.py` open a sandbox
  next to the real data.

It **refuses (exit 3)** while any API client with `kind='sandbox'` and `status='active'` exists
in any organization — a partner's practice credentials must never be one org id away from real
data. End the sandbox session first: revoke those clients
(`docs/runbooks/revoke-api-client.md`), then run it again. If it cannot read `api_clients` at all
it refuses too (it fails closed). When it allows the restore it writes a **restore record** to
the audit bucket, and from then on `scripts/seed_sandbox_org.py` refuses to open a sandbox until
`scripts/staging_wipe.py` has emptied staging again. Exit 2 means a guard refused (wrong
`--confirm-env`, wrong account, the database is not staging's) — stop and read the message.

A restore into **production** (the cutover) does not run it: there is no sandbox in production.

### 1. Dump the source

```bash
# scripts/staging_data_load.sh's flags and folder. SUPABASE_DB_URL is the session pooler
# (port 5432), not the HTTPS SUPABASE_URL; --schema=public keeps auth/storage out.
pg_dump --schema=public --data-only --no-owner --no-privileges \
        --exclude-table=public.alembic_version \
        --exclude-table=public.trial_migrations \
        --exclude-table=public.qgenda_workspaces \
        -Fc -f /Volumes/MeridianPHI/Meridian/meridian-$(date +%Y%m%d).dump "$SUPABASE_DB_URL"
```

The dump file **is PHI**. It lives on an encrypted volume, it is never copied to Downloads or
Desktop, and it is shredded when the load is signed off.

### 2. Bring the target to 0003

```bash
MERIDIAN_DATABASE_URL="$RDS_URL" python -m alembic -c migrations/alembic.ini \
    upgrade 0003_rds_adaptations
```

Check: `SELECT version_num FROM alembic_version;` → `0003_rds_adaptations`.

### 3. Restore

```bash
pg_restore --data-only --no-owner --disable-triggers \
           -d "$RDS_URL" /Volumes/MeridianPHI/Meridian/meridian-YYYYMMDD.dump
```

Then set every sequence past its table's maximum — `pg_restore --data-only` does not carry
sequence state, and parity check `sequence_ahead_of_max` is there to catch it if you forget:

```sql
SELECT setval(pg_get_serial_sequence(quote_ident(c.relname), 'id'),
              coalesce((xpath('/table/row/v/text()',
                  query_to_xml(format('SELECT max(id) AS v FROM public.%I', c.relname),
                               false, false, '')))[1]::text::bigint, 1))
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE n.nspname = 'public' AND c.relkind = 'r'
   AND pg_get_serial_sequence(quote_ident(c.relname), 'id') IS NOT NULL;
```

### 4. The PHI split

```bash
python scripts/split_phi.py --dry-run                 # read it once, then
python scripts/split_phi.py --database-url "$RDS_URL"
```

One transaction: copy `(id, org_id, patient_id, claim_no, encounter_id)` into
`phi.transaction_identity`, write `patient_ref`, NULL the three columns, verify, commit.
Anything that goes wrong rolls the whole thing back. It is safe to run twice.

Two things worth knowing before you run it:

* **`pgcrypto`.** `hmac()` lives there and **revision 0003 creates the extension**
  (`CREATE EXTENSION IF NOT EXISTS pgcrypto`, trusted since PostgreSQL 13, so the RDS master
  user may install it without being a superuser). The script only *finds* it — a database
  restored from a Supabase dump has it in the `extensions` schema rather than in `public`, so
  the script puts whichever schema it is in on the `search_path`. It used to create it, which
  meant a fresh environment built by `alembic upgrade head` alone did not have it; DDL is the
  chain's (ADR 0019).
* **Rows with no `patient_id`** are tokenised as the HMAC of the empty string, so that
  `patient_ref` can be `NOT NULL`. One stable "no patient" token, the same for all of them.
  **`''` and `NULL` fold together (L-4):** a row whose `patient_id` was the empty string
  gets the *same* token as a row whose `patient_id` was NULL, because
  `coalesce(patient_id, '')` cannot tell them apart. Neither is a real patient, so the
  collision is between two kinds of "no patient" and not between two people — but if a
  count of "rows with no patient" ever matters, count it in
  `phi.transaction_identity`, where the original NULL and `''` are both preserved, not by
  grouping on `patient_ref`.
* **The key fingerprint.** `phi.hmac_key_fingerprint` is created by revision 0003; the first
  run of the script writes its one row, `sha256(key)`. Revision 0005 later asserts that table
  exists with exactly one row
  on any database that has transactions — so a `patient_ref` written by something other
  than this script stops the chain instead of being dropped over.

### 5. Parity, global

```bash
python scripts/verify_parity.py --at 0003 \
    --source-url "$SUPABASE_DB_URL" --target-url "$RDS_URL" \
    --json > reports/parity-0003-$(date +%Y%m%d).json
```

What it compares, per plan step 11:

| Check | What it is |
|---|---|
| `table_count` | `count(*)` for every table in the source `public` schema (`alembic_version`, `trial_migrations` and `qgenda_workspaces` excluded) |
| `table_checksum` | `md5(string_agg(ROW(...)::text, '|' ORDER BY <pk>))` per table |
| `journal_entries` | `sum(debit)`, `sum(credit)`, `count(*)` `WHERE NOT is_test`, overall… |
| `journal_entries_by_batch` | …and again per `batch_id` |
| `transactions_by_batch` | `count(*)` per `batch_id` |
| `qb_usa_payroll_gate` | `sum(variance)` and row count |
| `qb_export_tie_out` | `sum(debits)`, `sum(credits)`, `sum(line_count)`, row count |
| `sequence_ahead_of_max` | every `id` sequence's `last_value >= max(id)` — **target only** (see below) |
| `phi_split` | `patient_ref IS NULL` count is 0, and `phi.transaction_identity` has as many rows as `public.transactions` (target only) |
| `phi_identity` | `md5` of `(transaction id, patient_id, claim_no, encounter_id)` over every row — read from `public.transactions` on the source and from `phi.transaction_identity` on the target. This is the check that proves the identifiers arrived **unaltered**, not merely in the right number |
| `constraints` | `md5` of `conname:definition` per table, so a unique or foreign key the Alembic chain did not rebuild is found before the first duplicate insert. Excluded by design: anything naming the identifier columns (revision 0005), not-null constraints (PostgreSQL 15 vs 17), and anything `REFERENCES auth.` — revision 0003 drops the three live `auth.users` keys and the target cannot have them |
| `null_org_rows` | `count(*) WHERE org_id IS NULL` per table. It must be **zero on both sides**; an equal non-zero count is not a match, it is the same orphan row on both sides about to become invisible to every role at head |

**The `transactions` checksum is narrower than the others, on purpose.** `patient_id`,
`claim_no`, `encounter_id` and `patient_ref` are excluded from **every** checksum, because
the first three exist only on the source and the fourth only on the target. What that
checksum proves is "every non-identifier column of every transaction survived". The
identifiers themselves are proved by `phi_identity`, which hashes their VALUES across the
move — the row counts alone would only say the right number of them arrived. Write that
sentence next to the number when you record it.

**`sequence_ahead_of_max` is judged on the target alone.** `pg_sequences.last_value` is NULL
for a role without `USAGE`/`SELECT` on the sequence, and the read-only role on the source has
neither — so a two-sided comparison read false for every source sequence and failed the whole
run. The question is a target question anyway: were the sequences `setval`'d after the
data-only restore. `verify_parity.py` discards the source's answers and requires the target's
to be true.

**Nothing this script prints is a row value** — counts, rounded sums, md5s and booleans only,
with table names, sequence names and `batch_id`s as labels. It is safe to paste into this
runbook and keep as evidence.

### 6. Migrate to head

```bash
MERIDIAN_DATABASE_URL="$RDS_URL" python -m alembic -c migrations/alembic.ini upgrade head
```

0004 applies RLS; 0005 checks the split, drops `patient_id` / `claim_no` / `encounter_id`
from `public.transactions`, and makes `patient_ref` `NOT NULL`.

If 0005 raises *"N of M public.transactions rows have a NULL patient_ref"*, the split did not
run on this database. Nothing has been dropped — the migration's transaction rolled back. Go
back to step 4.

### 7. Parity, per-org

```bash
python scripts/verify_parity.py --at head \
    --source-url "$SUPABASE_DB_URL" --target-url "$RDS_URL" \
    --json > reports/parity-head-$(date +%Y%m%d).json
```

Same checks, run once per row of `public.organizations` with `app.org_id` set and an explicit
`org_id` predicate, and added up. A global run at head would come back all zeros and "match",
because `FORCE` RLS applies to the migrator too — which is why `--at head` exists as a
separate mode and why the global run has to happen at step 5, before 0004.

---

## The abort rule

**Any difference aborts the load.** Not "investigate and continue" — abort.

* Parity exits `1` and prints `ABORT: the load is not a parity match. Do not cut over.`
* Drop the target database, fix the cause, and start again at step 2. A partially
  reconciled database is not a starting point for anything.
* The one class of difference that is expected is the `phi_split` rows, which exist on the
  target only. They are evaluated as expectations (must be true / must be zero), never as a
  mismatch.
* On a *rehearsal* against unfrozen Supabase, counts will drift while you work. Record what
  drifted and re-run; do not edit the target to make the numbers agree.

## The point of no return

The load itself is reversible: the target is a new database and dropping it costs nothing.
**The first write on AWS is not.** That is Phase 9, `cutover.md`, and it happens after this
runbook, not inside it. Until then Supabase stays authoritative and this target is a copy.

---

## Port gate — the JE byte-diff after the data layer (Phase 5a)

**This has not been run.** It is the plan's gate on the `DatabaseSupabase` →
`DatabasePostgres` port — "after `database.py` and again after `web_app.py`, restore
production into the fixture, re-run a booked period, and run `scripts/diff_je_output.py`.
Byte-identical or the port is wrong" — and it needs two things that are **not on the
development machine**: a production dump and the workbooks that produced the booked period
being re-run. The commands below are exact, and `docs/migration-tracker.md` carries the row
with a person's name on it. **Do not mark the port verified on the strength of the unit
tests**; they prove each method does what the Supabase one did, not that a whole period
comes out the same.

Prerequisites, all of them on the encrypted volume, none of them in this repository:

* a production dump, taken by step 1 above (it **is PHI**);
* the input workbook for a period that is already closed and posted, and the journal-entry
  CSVs that were actually sent to NetSuite/QuickBooks for it — the `expected` side of the
  diff;
* `MERIDIAN_PHI_HMAC_KEY`, **the same key** that wrote `patient_ref` in the dump. A
  different key produces tokens that join to nothing, and `phi.hmac_key_fingerprint` is
  what proves which one it was (step 4).

```bash
# 0. A throwaway PostgreSQL with the chain at 0003, loaded from production.
#    Steps 1-7 above, unchanged, against a LOCAL target rather than RDS:
export MERIDIAN_DATABASE_URL="postgresql://meridian_migrator@127.0.0.1:5432/meridian_gate"
python -m alembic -c migrations/alembic.ini upgrade 0003_rds_adaptations
pg_restore --data-only --no-owner --no-privileges --disable-triggers \
           -d "$MERIDIAN_DATABASE_URL" /Volumes/MeridianPHI/Meridian/meridian-YYYYMMDD.dump
PGOPTIONS="-c meridian.phi_hmac_key=$MERIDIAN_PHI_HMAC_KEY" \
    python scripts/split_phi.py --database-url "$MERIDIAN_DATABASE_URL" --apply
python -m alembic -c migrations/alembic.ini upgrade head

# 1. Re-run the closed period through the PostgreSQL backend.
export DATABASE_BACKEND=postgres STORAGE_BACKEND=local AUTH_BACKEND=disabled
export POSTGRES_URL="postgresql://meridian_app:...@127.0.0.1:5432/meridian_gate"
python scripts/run_port_gate.py --org-id "$GATE_ORG_ID" \
                                --period P12 --year FY25 \
                                --input /Volumes/MeridianPHI/Meridian/rehearsal/FY25_P12_source.xlsx \
                                --out   /Volumes/MeridianPHI/Meridian/rehearsal/actual

# 2. Diff every journal entry against what was actually posted.
#    The CLI is positional: OLD_DIR (what was posted) then NEW_DIR (this run).
python scripts/diff_je_output.py \
    /Volumes/MeridianPHI/Meridian/rehearsal/FY25_P12/journal_entries \
    /Volumes/MeridianPHI/Meridian/rehearsal/actual/P12_FY25_*/journal_entries
```

**Step 1 is `scripts/run_port_gate.py` and not `process_revenue.py`** (2026-09-16,
critic P5AR2-04). It used to be the latter, and that command could never have gated
anything: `process_revenue.py` builds `Database("data/revenue.db")` directly — the frozen
SQLite class the legacy CLI keeps — and never calls `get_database()`, so it never reaches
`DatabasePostgres` no matter what `DATABASE_BACKEND` says. The export on the line above it
changed nothing. `run_port_gate.py` drives the same `web_app.WebProcessor` with
`db = get_database(org_id, user_id)` that a real booking goes through, and it **refuses to
start** unless `DATABASE_BACKEND=postgres`, so a gate that would have proved the wrong
thing now proves nothing loudly instead of something falsely.

`$GATE_ORG_ID` is the organization the restored dump's booked period belongs to; read it
out of the target with `SELECT id FROM public.organizations` before you start. The
`--out` folder is on the encrypted volume with the rest of the rehearsal, never in the
repository's own `output/`.

Pass is **byte-identical, all 15 files**. `scripts/diff_je_output.py` exits non-zero on any
difference and names the file, line and field; a difference is the port being wrong, not
the diff being fussy. Record the run in the timings table below with `Outcome = port gate`,
and shred the dump and the rehearsal folder afterwards.

Two differences are expected to be *absent* and are worth checking explicitly if the diff
does fail, because both were found by reading rather than by running:

* an empty spreadsheet cell must still be an empty string in the description line, not
  NULL — `PgSession.copy_records` was folding the two together (ADR 0022, 2026-09-16);
* `transactions.amount` is `double precision` and `DEC2FLOAT` keeps it a `float`; a
  `Decimal` anywhere in the aggregation changes the last cent.

The second half of the gate — the same procedure after `web_app.py` is ported — is a
separate run and a separate tracker row.

---

## Timings — fill this in

One row per execution. The rehearsal rows are what the freeze window is budgeted from.

| Date | Env | Rows (transactions / journal_entries) | 1 dump | 3 restore | 4 split | 5 parity | 6 migrate | 7 parity | Total | Outcome |
|---|---|---|---|---|---|---|---|---|---|---|
| | staging | | | | | | | | | |
| | staging | | | | | | | | | |
| | prod | | | | | | | | | |

Record the parity JSON alongside each row (`reports/parity-*.json`); the timing without the
evidence is not a record of anything.

---

## Open items

* **`public.source_transactions` has not been moved into `phi`.** Plan P-3 has it moving
  as-is (`ALTER TABLE ... SET SCHEMA phi`, not a 167k-row copy) and revision 0005
  deliberately does not do it. Three things have to change first: `src/database.py` writes
  and reads that table as `meridian_app`, which has no grant of any kind on `phi`, so the
  move breaks upload the moment it lands; `scripts/tenant_tables.txt` is checked against both
  the committed Supabase dump and a database at head, and those two cannot both pass across a
  relocation until `scripts/gen_tenant_tables.py` knows about it; and `scripts/lint_org_scope.py`
  reads the same list. Until then the table stays in `public` and is covered by the ordinary
  per-table count and checksum.
* **Duplicate detection still keys on `Claim No` (P-1).** `src/exporters.py`
  `_detect_duplicates` builds its key from the spreadsheet's `Claim No` column, which is the
  same identifier this split quarantines. If that check is ever moved to work off the
  database instead of the workbook, `claim_no` has to be tokenised **with the same key** —
  two different keys means two tokens for one claim and the duplicate check silently stops
  finding anything. Nothing in `src/` was changed here.
* **`patient_ref` is not backfilled by the application.** Anything writing a transaction to
  the RDS target after 0005 must compute the token itself; the column is `NOT NULL`.
* **`src/database.py` cannot write a transaction to the target at all after 0005 (H-3).**
  Its inserts name `patient_id`, `claim_no` and `encounter_id` and never `patient_ref`;
  0005 drops the first three and makes the fourth `NOT NULL`, so the first upload against
  RDS fails with `UndefinedColumn`. **This is not a reason to delay 0005** — nothing writes
  to the target during the load, and Supabase stays authoritative until `cutover.md`. It is
  a hard prerequisite for cutover: **Phase 5a**'s repository layer computes `patient_ref`
  with the same key (`src/phi.py`, `MERIDIAN_PHI_HMAC_KEY`) and routes the three
  identifiers to `phi.transaction_identity` through the `phi_access` role. Tracked in
  `docs/migration-tracker.md`.
* **`null_org_rows` must be zero before you go any further.** The global (`--at 0003`)
  parity pass counts rows with `org_id IS NULL`, per table, and **fails on any non-zero
  count even when the two sides agree**. That is the only pass that can see them: from
  revision 0004 on, `FORCE ROW LEVEL SECURITY` hides a NULL-org row from every role
  including the owner, so a row that reaches head with no `org_id` is unreachable for
  ever. Fix them on the source and restart the load; there is no way to fix them
  afterwards.
* **The split/parity suites are not in the `migrations` CI job (L-3).**
  `tests/test_split_phi.py` and `tests/test_verify_parity.py` need `psql` and the
  ephemeral PostgreSQL fixture, and they run in the ordinary backend job, where a machine
  without a Postgres backend skips them. They belong in the `migrations` job, which sets
  `MERIDIAN_PG_REQUIRED=1` and therefore cannot skip them silently.
  `.github/workflows/backend.yml` was out of scope for the change that added them; carried
  in `docs/migration-tracker.md`.

## Related

`migrations.md` (the chain), `db-access.md` (getting a `psql` to a private RDS),
`rotate-secrets.md` (the HMAC key), `restore.md` (getting back), `cutover.md` (Phase 9).
