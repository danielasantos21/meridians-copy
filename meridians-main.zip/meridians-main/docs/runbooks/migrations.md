# Runbook — database migrations

Jargon, once: a **migration** is a script that changes the database's shape.
**Alembic** is the Python tool that keeps them in order and records which ones a
given database has had. A **revision** is one such script. The chain of them,
replayed from an empty database, is the only definition of Meridian's schema.

Everything lives in `migrations/` at the repository root. `supabase_migrations/`
is history — see its own README.

---

## The chain today

| Revision | What it is |
|---|---|
| `0001_baseline_supabase` | Replays the 37 files in `supabase_migrations/migrations/` verbatim. |
| `0002_reconcile_live_drift` | Closes the measured gap so the result **equals** live Supabase. |
| `0003_rds_adaptations` | Strips Supabase; creates `phi`, `audit`, `meridian_app`, `phi_access` and the grant matrix. |
| `0004_rls_app_org_id` | `FORCE ROW LEVEL SECURITY` + the `app.org_id` policies on every tenant table in `public` **and `phi`**, and RDS-era policies replacing the `auth.uid()` ones on `organizations` / `superadmins`. |
| `0005_drop_txn_identifiers` | Moves the patient identifiers out of `public.transactions` (ADR 0012). |
| `0006_user_profiles` | `public.user_profiles` — display name, avatar, language, dashboard layout — with per-USER policies. |
| `0007_invoice_numbers` | `public.invoice_counters` and the unique index behind one-statement invoice numbering. |
| `0008_process_runs_unique` | `UNIQUE (run_id, org_id)` on `public.process_runs` — the conflict target the upsert names. |
| `0009_org_members_user_policy` | Three SELECT policies for the reads that happen **before** an org id is known: own membership (`org_members`), the orgs you belong to (`organizations`), and the one invite whose code the session declares (`invite_codes`). |
| `0010_superadmin_org_list` | A fourth SELECT policy on `organizations` — "the session is in `superadmins`" — because a superadmin who is a member of nothing matched neither 0004's nor 0009's, so the console was blank. Plus `audit.superadmin_access`, `audit.phi_access`'s sibling: INSERT-only for `meridian_app`, one row per organization `src/pg.with_superadmin` visits (ADR 0011). |
| `0011_process_runs_worker` | Phase 11 D2. Lease columns on `process_runs` (`lease_owner`, `lease_expires_at`, `attempts`, `last_job_id`) and the worker's three pre-tenant `SECURITY DEFINER` functions: `app.authorize_job` (re-reads the run before any `app.org_id` is set; refuses with a reason code), `app.claim_run` (the lease; one winner) and `app.expire_stale_runs` (the TTL sweeper). Owned by the NOLOGIN role `meridian_job_control`, which holds column grants plus `USING (true)` policies that apply to it alone; the migrator is a member WITHOUT inherit, so FORCE RLS still binds the owner. |
| `0012_job_idempotency` | Phase 11 E1. `public.job_idempotency` — the ledger written BEFORE a remote call (`run.execute`, `qbo.journal`), a tenant table with FORCE RLS and no DELETE for `meridian_app`; its run reference is `(run_id, org_id)` so it cannot point across orgs. Plus `qb_export_tie_out.qbo_request_id`. Only writer: `src/idempotency.py`. |
| `0013_api_platform` | Phase 12 T04 (re-pointed onto Phase 11's 0012 when Phase 11 merged second). Also grants `meridian_job_control` the three columns `app.authorize_job` reads for a machine-client actor. `api_clients`, `partner_baas`, `webhook_subscriptions`, `webhook_deliveries`, `api_events` (tenant tables, FORCE RLS); `api_quota_window`; `audit.api_request` and `audit.api_client_change` (INSERT-only plus an append-only trigger); `roles.can_read_phi`; and `app.api_client_for_token`, the one pre-tenant read of `api_clients`, owned by the NOLOGIN role `meridian_api_lookup`. |
| `0014_webhook_delivery_history` | Phase 12 T11. `webhook_deliveries.created_at` / `last_attempt_at` and the `(org_id, created_at DESC, id DESC)` index the delivery log pages on. |
| `0016_api_client_admin_gaps` | Phase 12 T12 gaps. `api_clients.rotation_started_at` (the "Finish rotation" flag), `partner_baas.revoked_by` / `revoked_reason` + a keyset index, and `app.api_client_usage` / `app.api_client_recent_ips`: aggregate-only reads of `audit.api_request` for one client of the session's org, ≤ 90 days, owned by the NOLOGIN role `meridian_usage_reader` (the app still cannot read a raw audit row). |
| `0017_auth_state` | Auth work (tracker T:83, T:86). `public.auth_pending_challenge` — half-finished Cognito sign-ins, keyed by sha256(handle), the record sealed under a key only the handle can derive, five-minute TTL (not a tenant table: nobody has an org before signing in) — and `audit.invite_redeemed`, append-only, one row per invite code spent, written in the same transaction as the membership; and `meridian_profile_org_admin_select` on `user_profiles` (T:114) — in a session scoped to an org, an ADMIN of that org reads its members' profile rows, SELECT only. The FastAPI rate limiter needs no table: it counts in 0013's `api_quota_window` under an `rl:` prefix. |
| `0018_push_claim_and_input_digest` | Phase 11 E2 prerequisite + E3. `app.claim_post_completion`: the lease for a job that starts from a FINISHED run — only `(qbo_push, completed)`, any other kind is an error — owned by `meridian_job_control` like 0011's definers (`claim_run` still refuses every terminal run). `app.input_digest(inputs)`: an IMMUTABLE sha256 of the sorted input hashes in `inputs.object_versions`, with the expression index `idx_process_runs_input_digest` that the `DUPLICATE_INPUT` warning probes. `job_idempotency.qbo_request_id_history`: the Intuit requestids a definite failure superseded (ADR 0032). |
| `0019_outbox_sweep` | Phase 12 T19. `app.unpublished_api_events(min_age_seconds, limit)`: the outbox sweep's one cross-org read — ids of `api_events` rows still unpublished after the grace period, oldest first, bounded (≤ 1 day grace, ≤ 1000 rows) — owned by `meridian_job_control`, which gains `SELECT (id, org_id, occurred_at, published_at)` on `api_events` and a `USING (true)` SELECT policy that applies to it alone (0011's shape). The sweep then publishes each event under its own org's `with_org`. |
| `0022_redeliverable_jobs` | Phase 11 D4 (written beside 0020/0021; its `down_revision` is re-pointed onto `0021_qbo_connection_audit` at the merge). `app.redeliverable_jobs(queued_grace_seconds, limit)`: the in-process transport's one cross-org read — jobs no live worker holds: a `parsing`/`running` run whose lease lapsed after 1 or 2 claims (at 3 the sweeper fails it), or a job the api queued (`attempts` 0, `last_job_id` set, no owner) and nobody claimed within the grace; ids, process, state and attempt count only, oldest first, bounded (≤ 1 day grace, ≤ 1000 rows). Owned by `meridian_job_control` (0011's grants already cover every column it reads). Adds the partial index `idx_process_runs_queued_job` on `lease_expires_at` WHERE `attempts = 0 AND last_job_id IS NOT NULL`. |
| `0023_qbo_token_envelope` | ADR 0044. `public.qbo_connection` gains `access_token_ct`, `refresh_token_ct`, `token_dek` (wrapped) and `token_kek_id`; the plaintext token columns become NULLable; CHECK `qbo_connection_token_form` (legacy plaintext XOR fully sealed) and `qbo_connection_token_ct_shape`; trigger `qbo_connection_no_new_plaintext` refuses any new plaintext token. **No backfill** (the migration holds no key): after deploying, run `scripts/encrypt_qbo_tokens.py --actor <superadmin> --dry-run`, then without `--dry-run`, as a one-off api task. Downgrade refused while any row is sealed. |
| `0040_bi_saved_content` | BI saved content (renumbered from main's 0038 after `0039_run_inputs`). `bi_collections` (folders), `bi_cards` (saved questions) and `bi_card_revisions` (earlier versions). Tenant tables, FORCE RLS; a private folder is visible only to its owner. |
| `0041_bi_discover` | BI search and reuse: `bi_bookmarks`, `bi_views` ("recently viewed") and `bi_snippets` (named SQL pieces admins reuse). Tenant tables, FORCE RLS. |
| `0042_bi_dashboards` | BI dashboards: `bi_dashboards`, `bi_dashboard_tabs`, `bi_dashcards` (a saved question placed on a page) and `bi_dashboard_revisions`. Tenant tables, FORCE RLS. |
| `0043_bi_drill_audit` | `bi_drill_audit`, the log written before any BI run returns individual rows (no row written means no rows returned). `meridian_app` can only INSERT. Creates the NOLOGIN role `bi_audit_reader`, which can only SELECT this table. **The downgrade refuses while `bi_drill_audit` holds rows**, and `bi_audit_reader` is a cluster-wide role the downgrade does not drop. |
| `0044_bi_ask_usage` | `bi_ask_usage`: AI tokens used by Ask Meridian per organization and month, no question text. Tenant table, FORCE RLS. |
| `0045_bi_ask_log` | `bi_ask_log`: what people asked Ask Meridian and what it built, for Meridian staff to improve it. Tenant table, FORCE RLS. |
| `0046_bi_models_metrics` | BI models, metrics and segments: `bi_segments`, `bi_segment_revisions`, `bi_table_meta` (admin-written table and column descriptions), and a wider kind list on `bi_cards`. Tenant tables, FORCE RLS. The head after the merge of main into aws-migration. |
| `0049_bi_exec_tables` | The Executive Report's shared Highlights and Initiatives rows: `bi_exec_tables` (one JSONB document per organization, period and table, compare-and-set on `version`; `meridian_app` has SELECT, INSERT, UPDATE and no DELETE) and `bi_exec_table_revisions` (append-only: SELECT and INSERT only). Tenant tables, FORCE RLS. **The downgrade drops both and destroys the saved rows; back up first.** |
| `0051_bi_exec_notes` | The Executive Report's typed Notes boxes: `bi_exec_notes` (one row per organization, period and note id, last save wins; `meridian_app` has SELECT, INSERT, UPDATE and no DELETE). Tenant table, FORCE RLS. Numbered 0051 because `feat/daily-report-speed` holds 0050: re-chain `down_revision` when they meet. **The downgrade drops it and destroys the saved notes; back up first.** |

Design decisions: **ADR 0019**. What 0001 leaves out, statement by statement:
`migrations/baseline/SKIPPED.md`.

---

## Running it

Alembic reads the connection string from `MERIDIAN_DATABASE_URL`. There is no
URL in `alembic.ini` on purpose. Run as the **owner / migration role**, never as
`meridian_app` — that role is a non-owner with no `BYPASSRLS` and cannot create
anything.

```bash
export MERIDIAN_DATABASE_URL='postgresql://OWNER@HOST:5432/meridian'
export MERIDIAN_APP_DB_PASSWORD=...   # revision 0003 reads these
export MERIDIAN_PHI_DB_PASSWORD=...   # from Secrets Manager, never a literal
export MERIDIAN_MART_OWNER_DB_PASSWORD=...    # revision 0048 (eCW mart copy); secret
export MERIDIAN_MART_READER_DB_PASSWORD=...   # meridian-<env>-secret-db-mart-owner / -reader

alembic -c migrations/alembic.ini current        # where is this database?
alembic -c migrations/alembic.ini history        # the chain
alembic -c migrations/alembic.ini upgrade head   # apply everything
alembic -c migrations/alembic.ini upgrade head --sql > plan.sql   # dry run
```

If the passwords are unset the roles are still created, with a random password
nobody holds, and a warning is printed. That is deliberate: a role you cannot
log into is a better failure than a role with a guessable password.

Revision 0048 (`meridian_mart_owner`, `meridian_mart_reader`) follows the same
rule, with one trap: **a set variable re-passwords the role every time that step
runs, and an unset one replaces the password with a random one nobody holds.**
Export both mart variables before ANY later `alembic upgrade` that re-runs a
role step (a downgrade to before 0048 and back up, for instance), or the
loader and the api lose their logins. A bare upgrade in CI (backend.yml) only
creates throwaway roles on a throwaway database; it touches no real secret.
The `mart` and `analytics` schemas are a rebuildable copy of the external eCW
mart (ADR 0053): leave them out of `pg_dump`s taken for downloads, cutover
rehearsals and restore drills (`--exclude-schema=mart --exclude-schema=analytics`),
and refill them with the nightly loader after any restore.

**Run as the RDS master user, and note what it is not.** The master user is
`NOSUPERUSER` and `NOBYPASSRLS`; it has `rds_superuser`, which gives it
`CREATEROLE` and `CREATEDB`, and that is all 0003 needs. `tests/pg_fixture.py`
creates a role with exactly that shape (`meridian_migrator`) and migrates as it,
so anything the master user cannot do fails on a laptop rather than on RDS. Two
consequences you will meet:

* `ALTER ROLE ... NOSUPERUSER` is refused even when it changes nothing, so 0003
  only ever sets a password on an existing role, and *checks* the attributes.
* `FORCE ROW LEVEL SECURITY` applies to the owner. See **Loading data** below —
  this is not a footnote, it decides the order of the whole cutover.

### Offline mode (`--sql`)

`upgrade head --sql` never connects, which two revisions have to know about:

* **0003** does not emit the role-creation statements. A generated script is a
  file, and a file with a password in it is a leak; the script carries a comment
  naming the two `CREATE ROLE` statements to run by hand with the Secrets
  Manager values, and everything after them assumes the roles exist.
* **0004 refuses to run offline at all.** It reads `pg_policies` to find the
  inherited Supabase policies it must drop, and their names are not knowable
  from the repository. Generate the script up to 0003, apply it, then run 0004
  with a live connection:

```bash
alembic -c migrations/alembic.ini upgrade 0003_rds_adaptations --sql > plan.sql
# review plan.sql, create the two roles by hand, apply plan.sql
alembic -c migrations/alembic.ini upgrade head          # 0004, online
```

### 0009 and the `app.invite_code` setting

0009 is ordinary DDL: it runs online or under `--sql`, needs no data, and its
downgrade drops the three policies. One thing about it is worth knowing at a
`psql` prompt, because it looks like a bug otherwise:

`public.invite_codes` now has a second SELECT policy keyed on a **session
setting**, not on `app.org_id`:

```sql
-- as meridian_app, with no app.org_id: zero rows, which is correct
SELECT count(*) FROM public.invite_codes;

-- the session states the code it is holding, and sees exactly that row
SET app.invite_code = 'AAAA-BBBB-CCCC';
SELECT org_id, expires_at FROM public.invite_codes;
RESET app.invite_code;
```

`RESET` it when you are done, exactly as you would `app.org_id`:
`src/pg.py`'s release path does not yet reset this one
(`docs/migration-tracker.md`), so a connection you leave it set on can still
read that invite. It is SELECT-only — redeeming a code is a write, and a write
still needs `app.org_id`.

### `scripts/run_migrations.py`

Still in the tree, still the mechanism that produced today's drift: it hardcodes
three file names and records nothing about what it ran. **Do not use it.** It is
deleted as part of the Phase 3 cutover step that retires `supabase_migrations/`
(plan step 2); until then it stays only so the aws-trial history keeps making
sense. Nothing in CI calls it.

---

## Loading data

**The order is not negotiable, and it is not the obvious one.**

```bash
alembic -c migrations/alembic.ini upgrade 0003_rds_adaptations   # 1. schema
pg_restore --data-only --disable-triggers -d "$MERIDIAN_DATABASE_URL" live.dump
psql "$MERIDIAN_DATABASE_URL" -f scripts/split_phi.sql           # 2. the PHI split
alembic -c migrations/alembic.ini upgrade head                   # 3. RLS on
```

**Why.** Revision 0004 turns on `FORCE ROW LEVEL SECURITY`, which deliberately
does *not* exempt the table owner, and the RDS master user is `NOBYPASSRLS`. At
head, PostgreSQL refuses a bulk load outright:

```
ERROR:  COPY FROM not supported with row-level security
HINT:  Use INSERT statements instead.
```

`pg_restore` uses `COPY`, so the whole data load fails. Setting `app.org_id`
does not rescue it: the dump holds every organization's rows and the setting
names one. Loading between 0003 and 0004 is therefore the *load window* — the
last point at which the owner is still exempt (the Supabase-era `ENABLE` is
there, `FORCE` is not yet), and it is proved by two tests,
`test_the_migrator_can_copy_into_a_tenant_table_at_0003` and
`test_the_migrator_cannot_copy_into_a_tenant_table_at_head`.

**The rule this leaves behind, for every revision from 0005 on:**

> A revision never touches rows without a documented `SET app.org_id` — either a
> single `SET` naming the one organization the revision is for, or an explicit
> loop over organizations with the `SET` inside it. If a revision needs to touch
> every tenant's rows at once, it does not belong in a revision; it belongs in a
> load script that runs in the window above, with its own verification step.

Write that `SET` in the revision, in the `upgrade()` body, where a reviewer sees
it. A revision that quietly relies on being run before 0004 is a revision that
breaks the first time somebody replays the chain in order.

### The third option, and its conditions (added by 0007)

There is one shape the rule above does not cover: a revision that has to READ
every organization's rows to derive something — not to change them. Revision
`0007_invoice_numbers` is the first. It seeds one counter row per organization
from the invoice numbers each has already used, and it cannot name an
organization because it is for all of them.

A load script is the wrong home for that: the counter only makes sense beside
the table and the unique index that are created in the same revision, and a
separate script is a step somebody forgets on the first replay that matters.

So the revision brackets its own work:

```sql
ALTER TABLE public.invoices NO FORCE ROW LEVEL SECURITY;   -- the owner can read
-- guard, create, index, backfill
ALTER TABLE public.invoices FORCE ROW LEVEL SECURITY;      -- put it back
```

DDL is transactional in PostgreSQL, so both statements are in the revision's own
transaction and there is no moment at which a concurrent session sees the table
with the backstop off.

**Three conditions, and a revision that cannot meet all three uses the load
window instead:**

1. It only **reads** across organizations. A cross-org WRITE still belongs in the
   load window, where it is visible and verifiable.
2. The `FORCE` is restored in the **same** `upgrade()`, unconditionally, with
   nothing between the two statements that can leave the transaction open.
3. The docstring says which table and why, in those words, so the next reader
   does not have to work out whether it was deliberate.

Without the bracket the failure is silent rather than loud: the revision reads
**zero rows**, the guard finds no duplicates and the backfill seeds nothing,
and everything reports success. That is the failure mode this note exists to
prevent.

---

## Adding a revision

1. ```bash
   alembic -c migrations/alembic.ini revision \
       --rev-id 0005_short_description -m "short_description"
   ```
   **`--rev-id` is not optional.** Without it Alembic mints a random hex id and
   the chain stops being readable in a directory listing; every revision here is
   `NNNN_slug`, and the next number is the one after the highest on disk.
   **Not `--autogenerate`.** There are no SQLAlchemy models (ADR 0005), so
   autogenerate produces an empty revision and a false sense of safety.
2. Write the SQL by hand in `upgrade()`. Write `downgrade()` too if undoing it
   is a real operation; raise `NotImplementedError` with a reason if it is not.
3. If the revision adds a table with an `org_id`, **in `public` or in `phi`**:
   - regenerate the table list: `python scripts/gen_tenant_tables.py`
     (schema-qualified entries — `phi.transaction_identity`, not
     `transaction_identity`)
   - add `ENABLE` + `FORCE ROW LEVEL SECURITY` and a policy in the same
     revision, in the shape 0004 uses (`org_id = app.current_org_id()`, as both
     `USING` and `WITH CHECK`).
   CI fails otherwise, in three places: `gen_tenant_tables.py --from-dump
   --check`, `gen_tenant_tables.py --check` against the migrated database, and
   `tests/test_migrations.py::test_every_tenant_table_forces_rls_and_has_a_policy`
   plus its complement `::test_the_list_accounts_for_every_org_scoped_table_at_head`.
4. If the revision touches **rows**, it carries its own `SET app.org_id`, and a
   comment saying which organization(s) and why. See **Loading data** above.
5. Run it against a throwaway database before anything else:
   `pytest tests/test_migrations.py -q`.
6. Never put a tenant's rows in a revision. Seeds go to
   `supabase_migrations/seeds/` (gitignored, with a committed `*.example.sql`
   twin).

---

## Rules that are not negotiable

**Never `alembic stamp` to skip 0001–0003.** `stamp` tells Alembic "pretend
these ran". It is the single fastest way to get a database that nobody can
rebuild: the chain stops being a definition of the schema and becomes a story
about it. If a database already has the schema and you are tempted to stamp it,
what you actually want is to rebuild it from empty and load the data.

**Staging is rebuilt from empty every session** (D-15). The `network`,
`compute`, `api` and `observability` stacks are destroyed at the end of a
staging session and redeployed at the start of the next, and the database is
rebuilt with `alembic upgrade head` from nothing. Every session therefore
re-proves the chain. That is the point, not a chore.

**Never edit `supabase_migrations/`.** Revision 0001 asserts the folder still
holds exactly 37 files and fails the migration if it does not.

**No test in a default run reaches a live database** (tracker T:72, closed
2026-09-24). The P&L RLS proof that used to connect to live Supabase is
`tests/test_pnl_rls_pg.py` on `pg_fixture`; `tests/conftest.py` disables `.env`
loading, drops the database connection variables and refuses any non-loopback
`psycopg2.connect`. A test that genuinely needs a live database is marked
`@pytest.mark.live` and runs only with `MERIDIAN_LIVE_DB_TESTS=1`.

---

## Upgrading a production database

Four steps, in order, and the first one is not optional.

1. **Snapshot.** `aws rds create-db-snapshot --db-instance-identifier
   meridian-prod-rds --db-snapshot-identifier meridian-prod-premigration-$(date
   +%Y%m%d-%H%M)`, and **wait for `available`**. Automated backups give
   point-in-time recovery, but a named snapshot you took on purpose is the one
   you can find at 2am.
2. **Review.** `alembic -c migrations/alembic.ini current` (where is it?) then
   `upgrade head --sql > plan.sql` and read `plan.sql`. Anything surprising
   stops here. Note the offline-mode caveats above: if 0004 is in the range,
   the script stops at 0003 and 0004 is applied online.
3. **Upgrade.** `alembic -c migrations/alembic.ini upgrade head`, as the RDS
   master user, with `MERIDIAN_APP_DB_PASSWORD` / `MERIDIAN_PHI_DB_PASSWORD`
   and (from revision 0048) `MERIDIAN_MART_OWNER_DB_PASSWORD` /
   `MERIDIAN_MART_READER_DB_PASSWORD` exported from Secrets Manager. It runs in a transaction per revision; a
   failing statement stops the chain with nothing half-applied from that
   revision.
4. **Verify.** `alembic current` shows the expected revision; `python
   scripts/gen_tenant_tables.py --check` is clean; one tenant-scoped read as
   `meridian_app` with `app.org_id` set returns its rows and with it unset
   returns none; `scripts/verify_parity.sql` if this upgrade moved data.

**Rolling back** is restoring the snapshot, not `alembic downgrade`. Only 0004
has a meaningful `downgrade()`; 0001–0003 do not, and a restore is a known
quantity where a partial downgrade is not.

---

## If live Supabase changes before cutover

The baseline dump and revision 0002 describe Supabase **as it was on the day it
was dumped**. If somebody adds a column there before the cutover, the chain no
longer reproduces production and `test_replayed_schema_equals_live_baseline`
goes red. That test going red is the system working.

Do this, and nothing else:

1. **Take a new dump.** `python3 scripts/dump_live_schema.py` writes
   `migrations/baseline/supabase_public_schema_<today>.sql`.
2. **Delete or rename the old dump.** `latest_baseline()` in
   `scripts/diff_baseline_schema.py` picks the newest file by name, and two
   dumps in that directory means the next person has to guess which one is the
   baseline. Move the old one out of `migrations/baseline/` entirely (it is in
   git history; that is where superseded evidence lives).
3. **Write a NEW revision** — `0005_…`, `0006_…` — closing the new gap.
   ```bash
   python3 scripts/diff_baseline_schema.py --revision 0005_<slug>
   ```
4. **Never edit 0002.** It is the record of what was true at baseline, and
   editing it makes every database already built from this chain unreproducible
   — including the staging database that was rebuilt from empty last session.
   The same goes for 0001.

---

## How the baseline was built (2026-09-15)

1. **One read-only dump of live Supabase.**
   ```bash
   python3 scripts/dump_live_schema.py
   # -> migrations/baseline/supabase_public_schema_2026-09-15.sql
   ```
   `pg_dump --schema-only --no-owner --no-privileges --no-comments -n public`,
   client 18.3. `SUPABASE_DB_URL` comes from `.env` via `python-dotenv` and is
   never printed; a libpq error is redacted before it reaches stderr. Schema
   only — no rows. The file was grepped for 36-character UUIDs and for tenant
   names before being committed; both came back clean.

2. **Replay 0001 into a scratch PostgreSQL and diff.**
   ```bash
   python3 scripts/diff_baseline_schema.py --revision 0001_baseline_supabase
   # -> migrations/baseline/drift_2026-09-15.diff   (242 differing statements)
   ```
   The scratch database is `tests/pg_fixture.py`: Docker `postgres:17` where a
   daemon is reachable, otherwise a local `initdb`/`pg_ctl` instance. Both sides
   are normalised — comments and dump preamble dropped, whitespace collapsed,
   every `CREATE TABLE` exploded into one fact per column so that column *order*
   is not compared (ADR 0019 §4).

3. **Write 0002 from the diff, and drive it to zero.**
   ```bash
   python3 scripts/diff_baseline_schema.py --revision 0002_reconcile_live_drift \
       --out migrations/baseline/drift_after_0002_2026-09-15.diff
   ```
   15 statements remain, all of them the three intended objects
   (`alembic_version`, `trial_migrations`, `qgenda_workspaces`).

4. **Lock the result in a test.**
   `tests/test_migrations.py::test_replayed_schema_equals_live_baseline` asserts
   that set exactly, in both directions.

Redo any step at any time; the scripts are idempotent and step 1 is the only one
that touches Supabase.

---

## Two things that were found doing this, and matter

**The old replay proof was not one.** `deploy/aws-trial/apply_migrations.py` (on
the `aws-trial` branch) wrapped every statement in `except Exception: WARN;
continue`. It reported success on a replay in which statements failed. Two of
them fail on a database built from empty — `012`'s `SET NOT NULL` and all of
`014`'s work on `clients`/`invoices`. The Alembic replay is strict: a statement
that errors stops the migration.

**`027_invite_codes_email.sql` IS applied live.** `invite_codes.email` is in the
dump. The plan, this repo's README and the data-layer inventory all said it
never was. Corrected in both READMEs.

---

## Troubleshooting

| Symptom | Cause |
|---|---|
| `MERIDIAN_DATABASE_URL is not set` | By design — there is no URL in `alembic.ini`. |
| `permission denied` creating a table | You are connected as `meridian_app`. Use the owner role. |
| `22P02 invalid input syntax for type uuid` from inside a policy | A predicate is reading `app.org_id` directly instead of through `app.current_org_id()`. That helper returns NULL for an unset *and* a malformed setting; a raw `NULLIF(current_setting(...), '')::uuid` only handles the unset one. |
| A query returns nothing and you expected rows | `app.org_id` is not set on that connection. That is RLS working. |
| `supabase_migrations/ holds N .sql files, expected 37` | Somebody edited closed history. Revert it. |
| Tests skip with "no ephemeral Postgres backend" | Neither Docker nor `initdb`/`pg_ctl` is available. In CI this is an error instead: the `migrations` job sets `MERIDIAN_PG_REQUIRED=1`. |
| `COPY FROM not supported with row-level security` | You are loading data at head. See **Loading data**: load between 0003 and 0004. |
| `permission denied to alter role` running 0003 | The role already exists and something wants to change an attribute the RDS master user may not change. 0003 only sets the password; check what else ran. |
| `0004 cannot run in offline mode` | `--sql` cannot enumerate the policies to drop. Script to 0003, apply, then run 0004 online. |
