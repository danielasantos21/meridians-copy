# DNS move audit — `meridiansgrp.com`, GoDaddy → Route 53 (2026-10-12)

**What this is:** a read-only check, done before anyone touches the nameservers, of every
record GoDaddy serves today against what Route 53 would serve the moment the nameservers
switch. It complements `docs/runbooks/dns-nameserver-switch.md` (the procedure); this file
is the result of running its §3 checks on 2026-10-12.

**Nothing was changed.** No DNS, GoDaddy, Route 53 or AWS resource was touched. Sources:

- The GoDaddy zone file Andres exported on 2026-10-12 20:29 (BIND format, **31 record
  sets**, SOA serial `2026100500`) — the source of truth for "what GoDaddy serves".
- `dig` straight at GoDaddy (`ns25.domaincontrol.com`) and straight at Route 53
  (`ns-124.awsdns-15.com`), bypassing every cache.
- Read-only AWS: `route53 list-resource-record-sets` on zone `Z0621688X1CV6X15E2QH`,
  `cloudformation get-template` on `meridian-shared-dns`, `sesv2 get-email-identity`.
- `scripts/dns_zone_diff.py` run against the export (it exits 1, as expected — see §5).

## 1. Bottom line

**Do not switch yet. Route 53 is missing 7 record sets that GoDaddy serves today.** Three
of them carry the production app's live email (Resend), two keep the other owner's `ai`
application reachable and its certificates renewing, one is GoDaddy payment links.
Everything else — Microsoft 365, Proofpoint inbound mail, SPF, DMARC, SES DKIM and MAIL
FROM, the website at the apex and `www` — already answers identically from Route 53.

No blockers beyond those 7 records: DNSSEC is off, there is no CAA record on either side,
and SES is already verified.

## 2. The comparison, record by record

"GoDaddy" = the exported zone file, confirmed by `dig @ns25.domaincontrol.com`. "Route 53"
= what `dig @ns-124.awsdns-15.com` answers today, which matches the deployed
`meridian-shared-dns` template (default `renderRecords=true`) plus the records
`meridian-staging-edge` writes. TTLs in seconds.

| # | Record | GoDaddy value (TTL) | Route 53 value (TTL) | Status |
|---|---|---|---|---|
| 1 | `A @` | `216.24.57.1` (600) | `216.24.57.1` (300) | same (TTL shorter on purpose) |
| 2 | `MX @` | `0 mx1/mx2/mx3-usg2.ppe-hosted.com` (3600) | same three (3600) | same |
| 3 | `TXT @` | SPF `v=spf1 include:_spf-usg2.ppe-hosted.com include:secureserver.net ~all` + `NETORGFT20419956.onmicrosoft.com` (3600) | same two values (3600) | same |
| 4 | `TXT _dmarc` | `v=DMARC1; p=quarantine; adkim=r; aspf=r; rua=mailto:dmarc_rua@onsecureserver.net;` (3600) | same (3600) | same |
| 5 | `CNAME www` | `meridian-web-c2sv.onrender.com` (3600) | same (300) | same (TTL shorter on purpose) |
| 6 | `CNAME autodiscover` | `autodiscover.outlook.com` (3600) | same (3600) | same |
| 7 | `CNAME lyncdiscover` | `webdir.online.lync.com` (3600) | same (3600) | same |
| 8 | `CNAME sip` | `sipdir.online.lync.com` (3600) | same (3600) | same |
| 9 | `CNAME msoid` | `clientconfig.microsoftonline-p.net` (3600) | same (3600) | same |
| 10 | `CNAME selector1._domainkey` | `selector1-meridiansgrp-com._domainkey.netorgft20419956.n-v1.dkim.mail.microsoft` (3600) | same (3600) | same |
| 11 | `CNAME selector2._domainkey` | `selector2-…` (3600) | same (3600) | same |
| 12 | `SRV _sip._tls` | `100 1 443 sipdir.online.lync.com` (3600) | same (3600) | same |
| 13 | `SRV _sipfederationtls._tcp` | `100 1 5061 sipfed.online.lync.com` (3600) | same (3600) | same |
| 14 | `CNAME email` | `email.secureserver.net` (3600) | same (3600) | same |
| 15 | `CNAME _domainconnect` | `_domainconnect.gd.domaincontrol.com` (3600) | same (3600) | same |
| 16 | `CNAME ai` (**not ours**) | `d159v1qnwsd8mk.cloudfront.net` (3600) | same (3600) | same |
| 17 | `CNAME acy2kjacqx2eeqsf3z3xqx4rixb7ajck._domainkey` (SES) | `…dkim.amazonses.com` (3600) | same (1800) | same |
| 18 | `CNAME oouyzhyypjpjytmwwa5c36xdgckktilh._domainkey` (SES) | `…dkim.amazonses.com` (3600) | same (1800) | same |
| 19 | `CNAME unxjmommttf4tbbgow2jhktsct3fxdyv._domainkey` (SES) | `…dkim.amazonses.com` (3600) | same (1800) | same |
| 20 | `MX mail` (SES MAIL FROM) | `10 feedback-smtp.us-east-1.amazonses.com` (3600) | same (1800) | same |
| 21 | `TXT mail` (SES MAIL FROM) | `v=spf1 include:amazonses.com ~all` (3600) | same (1800) | same |
| 22 | `CNAME origin.ai` (**not ours**) | `meridian-alb-1064237917.us-east-1.elb.amazonaws.com` (3600) | — | **MISSING in R53** |
| 23 | `CNAME _3a76167a4347ecb50f0bea492dd6aa2f.ai` (**not ours**, ACM validation) | `_b9610c27c74ff69ce86addc7198b7f5d.jkddzztszm.acm-validations.aws` (3600) | — | **MISSING in R53** |
| 24 | `CNAME _ca552b8e33c5217aaad223574627efd0.origin.ai` (**not ours**, ACM validation) | `_9ae19446168f1d5e485a014dbb89c097.jkddzztszm.acm-validations.aws` (3600) | — | **MISSING in R53** |
| 25 | `CNAME pay` | `paylinks.commerce.godaddy.com` (3600) | — | **MISSING in R53** |
| 26 | `MX send.updates` (Resend) | `10 feedback-smtp.us-east-1.amazonses.com` (3600) | — | **MISSING in R53** |
| 27 | `TXT send.updates` (Resend) | `v=spf1 include:amazonses.com ~all` (3600) | — | **MISSING in R53** |
| 28 | `TXT resend._domainkey.updates` (Resend DKIM) | `p=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC5h9ruwN6G+QDw1Ej7TZ8B5a2Vqw8/gEu78kaUP9w64hb36NkZDI+YGPO3ccxbwLg4KKxQu0xy8yQx5MYJySX3dUKk5fnPuy8S03BZXzFIPIJ/Eg8mo0fAS1p14MrOPJfZrp82P1zg30TQdwj2KT2ItWUWRafV7TR/FxDGhqIQNQIDAQAB` (3600) | — | **MISSING in R53** |
| 29 | `NS staging-app` | delegation to `ns-124/614/1297/1990.awsdns-*` (3600) | answered directly: `A`/`AAAA` ALIAS → `d7mk6qffayx7f.cloudfront.net` | differs **by design** — do NOT copy (§4) |
| 30 | `NS staging-api` | same delegation (3600) | answered directly: `A`/`AAAA` ALIAS → same CloudFront | differs **by design** — do NOT copy |
| 31 | `NS origin-staging` | same delegation (3600) | answered directly: `A` ALIAS → `meridian-staging-alb-edge` | differs **by design** — do NOT copy |
| — | `NS @`, `SOA @` | `ns25/ns26.domaincontrol.com` | `ns-124.awsdns-15.com`, `ns-614.awsdns-12.net`, `ns-1297.awsdns-34.org`, `ns-1990.awsdns-56.co.uk` | the thing the switch changes |
| — | `AAAA @`, `CAA @` | none | none | same |

Route 53-only records, harmless (nobody asks for them at GoDaddy except via the delegations
above): the three ACM validation CNAMEs under `staging-app`, `staging-api`,
`origin-staging`, written by `meridian-staging-edge`.

Names checked and **absent at GoDaddy** (so nothing to copy): `app`, `api`,
`enterpriseregistration`, `enterpriseenrollment`, `_autodiscover._tcp`, `_sip._tcp`,
`ftp`, `webmail`, `smtp`, `imap`, `pop`, `cpanel`, `webdisk`, `mta-sts`, `_mta-sts`,
`_smtp._tls`, `google`/`s1`/`s2`/`k1`/`default`/`mail`/Proofpoint `_domainkey` selectors,
`_acme-challenge` (apex, `www`, `app`, `api`), and ~60 other common names. No wildcard
record exists.

## 3. The 7 missing record sets — what each one does and what breaks without it

| Record | What it is | What breaks at the switch if it is missing |
|---|---|---|
| `TXT resend._domainkey.updates` | DKIM key for Resend, which sends the **production app's** mail today (invites, password resets) from the `updates.meridiansgrp.com` subdomain. Resend stays the live transport until after Phase 9 (tracker T:41). | Resend mail stops passing DKIM → lands in spam or is rejected; Resend flags the domain as unverified. Looks like "invites stopped arriving", not like DNS. |
| `MX send.updates` | Resend's bounce/return-path (Resend runs on SES under the hood, hence the `amazonses.com` host). | Bounces stop being processed; Resend may stop sending for the domain. |
| `TXT send.updates` | SPF for that return path. | SPF fails on every Resend message. |
| `CNAME origin.ai` | The **other owner's** assistant app — its load balancer origin (ADR 0001). Off-limits to change, but must be copied. | Their app's origin hostname goes dark — an outage we caused in their product. |
| `CNAME _3a76…​.ai` | ACM certificate DNS validation for `ai.meridiansgrp.com` (other owner). | Nothing on day one; their certificate **fails to auto-renew** months later. |
| `CNAME _ca55…​.origin.ai` | ACM validation for `origin.ai` (other owner). | Same: silent renewal failure later. |
| `CNAME pay` | GoDaddy Payments "pay links" (`pay.meridiansgrp.com`). | Any payment link using that hostname stops loading. |

**Why the earlier sweep missed them.** The 2026-09-15 export and the runbook's
candidate-name sweep had 16 record sets; the zone has grown to 31 since (SOA serial
`2026100500`). A name sweep can only find names someone thought to list — `pay`,
`origin.ai` and `send.updates` were not on it. The zone-file export is the only reliable
source, which is why the runbook requires both.

## 4. Exactly what to add to Route 53 before the switch (described, not done)

Add them **as code** in `infra/meridian/stacks/dns.py`, not in the Route 53 console, so
the zone stays reproducible and `infra/tests/test_dns.py` guards it. Use TTL 3600 to match
GoDaddy (`MAIL_TTL`).

1. **`EXISTING_CNAMES`** — append four tuples:
   - `("origin.ai", "meridian-alb-1064237917.us-east-1.elb.amazonaws.com")`
   - `("_3a76167a4347ecb50f0bea492dd6aa2f.ai", "_b9610c27c74ff69ce86addc7198b7f5d.jkddzztszm.acm-validations.aws")`
   - `("_ca552b8e33c5217aaad223574627efd0.origin.ai", "_9ae19446168f1d5e485a014dbb89c097.jkddzztszm.acm-validations.aws")`
   - `("pay", "paylinks.commerce.godaddy.com")`

   and add `CNAME_COMMENTS` entries marking the three `ai` ones "NOT MERIDIAN — the other
   account owner's application. Never repoint or delete." Construct ids come from
   `_construct_id`, so they are stable new ids (no existing record is recreated).
2. **New Resend block** (one `MxRecord` + two `TxtRecord`s, TTL 3600):
   - `MX send.updates` → priority 10, `feedback-smtp.us-east-1.amazonses.com`
   - `TXT send.updates` → `v=spf1 include:amazonses.com ~all`
   - `TXT resend._domainkey.updates` → the `p=MIGf…IDAQAB` value from row 28, copied from
     the export file, never retyped. It is 218 characters, under TXT's 255-per-string
     limit, so one string is fine.

   Comment them "Resend — live production mail transport until the Phase 7 flip after
   Phase 9 (T:41). Remove when the Resend account closes."
3. **`infra/dns/meridiansgrp.com.zone.json`** — re-export to the 2026-10-12 state: add the
   7 records above, the 5 SES records now also at GoDaddy (rows 17–21, mark them
   `"ses_interim": true` per runbook §3e), and the 3 `NS` delegations with a flag such as
   `"self_delegation": true` so the test and the diff script skip them.
4. **Do not add the three `NS` delegations to Route 53.** They exist only so GoDaddy hands
   `staging-*` queries to this same Route 53 zone. Once Route 53 is authoritative for the
   whole domain it answers those names directly; an `NS` record at `staging-app` inside the
   zone would turn it into a delegation pointing back at itself and break staging.
5. **Fix `scripts/dns_zone_diff.py`**: it reads GoDaddy's owner name `_sip._tls.@` as
   `_sip._tls.@.meridiansgrp.com`, reporting the two SRV records as both missing and extra
   (4 false differences). `<label>.@` should resolve to `<label>.<origin>`. It also needs to
   honour the `self_delegation` flag from step 3.
6. Run `cd infra && ../venv/bin/python -m pytest tests/test_dns.py -q` and `npx cdk synth
   meridian-shared-dns`, then the independent-agent check required by `CLAUDE.md`, then
   Andres deploys `meridian-shared-dns` (same `EmailEventsAddress` parameter as before).
   The change only **adds** 7 records; nothing existing is replaced.

## 5. Risks

- **Email, Microsoft 365 via GoDaddy (NETORGFT tenant).** GoDaddy-sold Microsoft 365 does
  **not** require GoDaddy DNS — every record it needs (MX via Proofpoint, autodiscover,
  SPF, tenant TXT, `selector1/2` DKIM, Skype/Teams CNAMEs and SRVs) is already identical in
  Route 53. Two side effects: GoDaddy's M365 / email dashboard may show a "DNS not managed
  by GoDaddy" or "domain setup incomplete" warning (cosmetic), and any record GoDaddy would
  have added automatically through Domain Connect in future must now be added by hand in
  Route 53. Check Microsoft 365 admin → Domains → `meridiansgrp.com` shows Healthy after.
- **Proofpoint "Advanced Email Security".** Inbound runs entirely on the 3 MX records and
  the SPF include, both identical. If GoDaddy ever changes the Proofpoint MX hosts (e.g.
  a region move), it will no longer do it for you.
- **Resend (production mail today).** The 3 Resend records are missing — the single
  biggest real-world risk in this audit. After adding them, send a test invite from
  production and check the Resend dashboard still shows the domain verified.
- **Render custom domains.** Render validates by checking the apex `A` and `www` `CNAME`
  resolve to it; both are identical. No `_acme-challenge` records exist, so its Let's
  Encrypt renewals do not depend on anything else in the zone.
- **SES.** Already `VerifiedForSendingStatus: true`, DKIM `SUCCESS`, MAIL FROM `SUCCESS`
  (verified via the interim GoDaddy copies). Route 53 serves the same values, so it stays
  verified through the switch. Delete the 5 GoDaddy copies only after the switch settles.
- **DNSSEC: off.** `whois` says `DNSSEC: unsigned`, the `.com` registry has no `DS`
  record, GoDaddy serves no `DNSKEY`. Nothing to disable first. (If it had been on, the
  switch would have broken the whole domain for validating resolvers.)
- **CAA: none** on either side, so any certificate authority (ACM, Let's Encrypt) can issue.
- **TTLs.** GoDaddy record TTLs are mostly 3600 (1 hour); apex `A` is 600. Lower every
  record at GoDaddy to 600 (GoDaddy's minimum) at least a day before. The `.com` registry
  `NS` TTL is **172800 (48 hours)** and cannot be lowered — that is the real propagation
  tail and the floor on rollback speed.
- **Registrar lock.** `whois` shows `clientUpdateProhibited` (GoDaddy's standard lock).
  GoDaddy lifts it automatically when you change nameservers in its UI; if Domain
  Protection is on, expect an extra identity/2-step check. Not a blocker.
- **Rollback.** Change the nameservers back to GoDaddy's. Safe only if the GoDaddy zone is
  left untouched — **do not delete or edit it** for at least two weeks. During the 48-hour
  tail both zones answer, which is why they must agree first.
- **Same-records rule after the switch.** From switch day on, every DNS change (a new
  Microsoft or SaaS verification, a new Resend/Proofpoint record) goes into `dns.py`, not
  GoDaddy. Changes made at GoDaddy afterwards silently do nothing.

## 6. Step list for Andres (plain language)

1. **Export the zone file** — done 2026-10-12. Where it is, for next time: GoDaddy → sign
   in → **My Products** → next to `meridiansgrp.com` click **DNS** → on the DNS Records
   tab, the **⋮ / "Actions"** menu at the top right of the record table → **Export Zone
   File**. Re-export the day before the switch in case something was added since.
2. **Lower the TTLs at GoDaddy** (same DNS page → edit each record → TTL **½ hour / 600
   s**). Do it at least 24 hours before step 5. This only changes how long other
   computers remember an answer, not the answer itself.
3. **Claude adds the 7 missing records** (§4) in code; tests + synth + the independent
   checker run; you deploy `meridian-shared-dns`.
4. **Verify against Route 53 directly, before switching.** `dig @ns-124.awsdns-15.com
   <name> <type> +short` for every row in §2 must equal `dig @ns25.domaincontrol.com …`.
   Claude can run the script used for this audit; the gate is **zero DIFF lines** except
   the three `staging-*` rows, and `scripts/dns_zone_diff.py` exiting 0 after the §4 fixes.
5. **Switch the nameservers** — GoDaddy → `meridiansgrp.com` → **DNS** → **Nameservers**
   tab → **Change Nameservers** → **"I'll use my own nameservers"** → enter
   `ns-124.awsdns-15.com`, `ns-614.awsdns-12.net`, `ns-1297.awsdns-34.org`,
   `ns-1990.awsdns-56.co.uk` (no trailing dot) → Save. Weekday morning, not mid-close.
   **Do not delete the GoDaddy DNS records.**
6. **Verify** right away, then at 1 h, 4 h and 24 h:
   `dig +short NS meridiansgrp.com @a.gtld-servers.net` lists the 4 `awsdns` names; send a
   mail from a personal Gmail to a `@meridiansgrp.com` address and it arrives; send a test
   invite from the production app and it arrives (Resend); `https://www.meridiansgrp.com`
   and `https://meridiansgrp.com` load; `https://ai.meridiansgrp.com` still answers;
   Microsoft 365 admin shows the domain Healthy; SES still `SUCCESS`.
7. **Rollback if needed** — if inbound mail or the site fails and the cause isn't clear in
   ~15 minutes: GoDaddy → Nameservers → Change → **"Use GoDaddy nameservers"
   (default)** → Save. Expect up to 48 hours for every resolver to follow.
8. **Two weeks later**, once stable: delete the 5 SES interim records at GoDaddy (runbook
   §3e) and update the checked-in export.
