# Runbook — alerts: what each one means and what to do first

**Who is paged: Andres.** There is one person, one topic per environment
(`meridian-<env>-sns-alerts`), and one mailbox. Every alarm in this document notifies on
**both** transitions — you get the alarm and you get the recovery — so a page with no
follow-up email means it is still broken.

> ## Step 0 — this does not work until you confirm the subscription
>
> **Nothing below reaches anybody until a human subscribes to the topic and clicks the
> confirmation link in the email AWS sends.** AWS requires that click; it cannot be
> automated and CDK cannot do it. Until it is done, every alarm here fires into an empty
> topic and the only symptom is silence.
>
> ```bash
> # once per environment, after the observability stack is deployed
> aws sns subscribe \
>   --topic-arn "$(aws cloudformation describe-stacks \
>     --stack-name meridian-staging-observability \
>     --query "Stacks[0].Outputs[?OutputKey=='AlertsTopicArn'].OutputValue" --output text)" \
>   --protocol email --notification-endpoint "you@example.com"
> # then open the mail and click Confirm subscription
>
> # prove it worked — PendingConfirmation must be false
> aws sns list-subscriptions-by-topic --topic-arn "<arn>" \
>   --query "Subscriptions[].[Endpoint,SubscriptionArn]" --output table
> ```
>
> `docs/migration-tracker.md` carries this as an open row with Andres as the owner. It is
> the single most important step in Phase 6.

## How to read this document

Alarms are grouped by what they are actually telling you, not by AWS service, because at
3am the question is "what is broken" and not "which namespace". Each row gives the alarm
name as it appears in the email, what it means, and **the first thing to do** — not the
whole diagnosis, just the next action.

**Alarms marked 🔇 are silent by construction today.** They are derived from log metric
filters, and the application does not emit structured JSON logs yet (ADR 0024 §4). Those
metrics have **no datapoints at all** — not a flat zero: a metric filter that carries the
`Environment` dimension cannot also carry a default value, so an empty graph is what you
see, and an empty graph is not evidence of health. When the formatter lands, delete these
marks.

**Every `Meridian/App` metric is dimensioned `Environment=staging|production`.** One
account, two environments, one namespace: if you build a graph or an alarm on one of these
by hand and forget the dimension, you are reading both environments added together.

Three general rules before any specific one:

1. **Check whether a deploy is running first.** Every alarm here is sized so a rolling
   deployment does not trip it, but a *failed* deploy trips several at once. `aws ecs
   describe-services --cluster meridian-<env>-ecs-main --services <svc>` and read the
   `deployments` and `events` arrays before anything else.
2. **Several alarms at once is one fault, not several.** The order below is roughly the
   order to believe them in: the database causes the latency which causes the 5xx.
3. **Never paste a log line into a ticket, a chat, or a review tool.** 400-day retention
   and a shared account; `docs/compliance/phi-classification.md` §5.

---

## 1. The site is down

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-alarm-api-no-healthy-host` | No healthy target in the `api` target group. API requests are failing. **It waits 7 of 8 minutes on purpose** — an api deploy has 3–6 minutes of zero healthy hosts *by design* (`min_healthy_percent=0`, one task until Phase 11: ADR 0022, ADR 0024 §2c), so a faster alarm would page on every deploy and be muted within a month. | **Check for a running deployment first.** `aws ecs describe-services --cluster meridian-<env>-ecs-main --services meridian-<env>-ecs-svc-api` — if `deployments` shows one in progress this is the deploy and it is about to clear. Otherwise read `events` for a task that will not start, then the `api` log group's last stream for a crash on boot. |
| `meridian-<env>-alarm-web-no-healthy-host` | Same for `web`, but **3 of 5 minutes** rather than 7 of 8: `web` runs `min_healthy_percent=100` and never drops to zero during a rollout, so it can be fast. The site itself is down. | As above with `svc-web`. If `api` is healthy and `web` is not, suspect the last `web` image, not the database. |
| `meridian-<env>-alarm-api-task-count` / `-web-task-count` | Fewer running tasks than desired. Usually the deployment circuit breaker rolled back (ADR 0022) or the task cannot pull its image. | Read the service's `deployments` array. `rolloutState: FAILED` means the circuit breaker fired — the previous version is running and you have time. |
| `meridian-<env>-alarm-canary-failed` | The health endpoint is unreachable **from the public internet**. The ALB health check can be green while this is red. | Check in this order: DNS, the certificate expiry, CloudFront, the WAF, the origin-verify header (`docs/runbooks/rotate-origin-verify-secret.md`). If the ALB alarms are all quiet, it is one of those five and not the application. |

## 2. The site is up and wrong

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-alarm-alb-5xx` | The **load balancer** returned 5xx: it had no healthy target, or the target closed the connection. | Check §1 first — this is usually a symptom. If §1 is quiet, look for tasks being killed: memory alarm, or `stopTimeout` during a slow shutdown. |
| `meridian-<env>-alarm-target-5xx` | The **application** answered 5xx. Infrastructure is fine; the code is not. | 🔇 `UnhandledExceptions` on the dashboard gives the request ids. Until the formatter lands, read the `api` log group directly and filter by time. |
| `meridian-<env>-alarm-cloudfront-5xx` | More than 5% of CloudFront responses are 5xx. | If the ALB alarms are quiet, suspect the origin-verify header: a rotation that moved one end and not the other returns 403 at the ALB and 5xx at CloudFront. `docs/runbooks/rotate-origin-verify-secret.md`. |
| `meridian-<env>-alarm-alb-latency-p95` | 95% of requests are slower than 2s. | Almost always the database. Go straight to §3, then Performance Insights for the statement holding the single burstable vCPU. |
| 🔇 `meridian-<env>-alarm-pool-timeout` | A request could not get a database connection from the pool. | Check `rds-connections` next. A pool timeout with connections *low* is a leak in the application; with connections *high* it is the ceiling. |

## 3. The database

Staging's instance is stopped every night by the D-15 schedule, so **in staging** these six
alarms are `MISSING` on absent data — they hold their last state rather than clearing. A
staging alarm that looks stuck overnight is working correctly.

**In production they are `BREACHING`**, because the production instance is never stopped:
there, RDS going silent is not a cost control, it is the database being unreachable. If one
of these fires in production with no metric behind it, treat the database as gone and start
at the instance, not at the metric.

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-alarm-rds-free-storage` | Under 4 GiB free. Autoscaling has a cooldown and a period close can outrun it. A full volume takes the database **read-only**. | Do not wait. `aws rds modify-db-instance --allocated-storage` upward, then find what grew. |
| `meridian-<env>-alarm-rds-connections` | Above 80% of `max_connections` (112 on `t4g.micro`, 225 on `t4g.small`). | The repository layer pools, so this is a **leak** — a connection not returned on an error path — long before it is load. Past the ceiling, new connections are refused and that includes the migration runner. `SELECT state, count(*) FROM pg_stat_activity GROUP BY 1;` |
| `meridian-<env>-alarm-rds-cpu` | Above 80% for 15 minutes on a burstable. | It is spending CPU credits it will want during the next period close. Performance Insights → top SQL. |
| `meridian-<env>-alarm-rds-freeable-memory` | Under 200 MiB. The page cache is being evicted and every query is about to get slower at once. | Usually follows the connection alarm — each connection has a work_mem allocation. Treat the connection count first. |
| `meridian-<env>-alarm-rds-read-latency` / `-write-latency` | Above 50ms average. gp3 at this size answers in single-digit milliseconds. | Contention or burst-balance exhaustion, not a slow disk. Check `rds-cpu` and the EBS burst balance. |

## 4. Correctness and data integrity

These are the ones that do not look urgent and are.

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-alarm-api-scaled-beyond-one` | **More than one healthy `api` task.** `api` runs exactly one task by design until Phase 11 (ADR 0022): two tasks can each pick up the same revenue run and **book the same journal entry twice**. | Scale it back to 1 — `aws ecs update-service --desired-count 1` — then find out who changed it and whether a run happened while it was 2. This alarm waits half an hour precisely so that it is never a deploy. |
| 🔇 `meridian-<env>-alarm-phi-audit-write-failed` | An `audit.phi_access` row could not be written. **PHI was accessed and the audit trail for it does not exist** — 45 CFR 164.312(b). | Treat as an incident, not a bug: `docs/runbooks/incident-response.md`. Record the time window; the affected accesses have to be reconstructed from pgaudit and CloudTrail. |
| `meridian-<env>-alarm-stop-dlq-unconsumed` (staging only) | A message has sat in the stop-schedule dead-letter queue for six hours, so the EventBridge Pipe that drains it is not running. A *real* stop failure would now go unreported. | Check the Pipe's state: `aws pipes describe-pipe --name meridian-staging-pipe-stop-dlq`. This is **not** a depth alarm and must not be turned into one — ADR 0020 §7c. |
| `meridian-staging-rule-stop-dlq-unexpected` (staging only) | A stop-schedule invocation dead-lettered for a reason that is **not** the expected `InvalidDBInstanceState`, or with no error code at all. The nightly database stop is not working. | The message body is in the mail. The same event is in `meridian-staging-logs-stop-schedule`, which `scripts/staging_session.sh up` also reads. Fix it before leaving staging up — ADR 0024 §5. |
| 🔇 `meridian-<env>-alarm-structured-logs-silent` (only exists with `-c structuredLogsLive=true`) | **No `Meridian/App` datapoint in 24 hours.** This is the one alarm here that fires on the *absence* of a metric: the log pipeline has stopped — no JSON formatter, a renamed field, a missing `env` dimension — and while that is true every 🔇 alarm above reads OK and cannot fire. | Confirm the `api` task is actually emitting JSON (`aws logs tail meridian-<env>-logs-api`) before assuming traffic was quiet. It counts every request, ALB health checks included, so a quiet day does not trip it — a stopped `api` task does. |

**About `meridian-<env>-alarm-structured-logs-silent`.** It does not exist by default.
Every other log-derived alarm treats missing data as `NOT_BREACHING`, which is correct
while the application emits no JSON logs and is also a hole: if the formatter never ships,
or ships and later regresses, all of them read OK for ever. This one is the inverse —
`SampleCount` on `HttpRequests` (one per `http_request` line, health checks included), below
1, `BREACHING` on missing — so an absent metric is an ALARM. It used to read
`FiveXxResponses`, which a 5xx-free day left empty (tracker T:138). It is armed with `-c structuredLogsLive=true` **in the same deploy that ships
the JSON formatter**, not before, because until then the absence it watches for is the
expected state and it would page continuously. Tracker row 46 carries the deadline.

**A note on the stop-schedule check.** `scripts/staging_session.sh up` no longer treats an
empty `meridian-staging-logs-stop-schedule` as a failure on its own. A dead letter is
written only when a stop is *refused* (the instance was already stopped); a stop that
**succeeds** writes nothing there, so the script also reads `aws rds describe-events
--source-identifier meridian-staging-rds-main --source-type db-instance --duration 2160
--event-categories availability` and takes `"DB instance stopped"` as the positive
confirmation. Either one is a pass; it warns only when neither exists. ADR 0024 §5.

## 5. Security

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-alarm-waf-blocked-spike` | The WAF blocked more than 100 requests in five minutes. Background internet noise is a trickle; this is somebody working through the rule set. | The WAF log group, filtered by source IP and terminating rule. A single source is a scanner; many sources hitting one path is not. |
| 🔇 `meridian-<env>-alarm-auth-failure-spike` | More than 50 auth/authz failures in five minutes. | Check the WAF log group for a single source **before** assuming it is real users mistyping passwords. |
| 🔇 `meridian-<env>-alarm-unusual-export-volume` | More than 100 artifact downloads in **each of three consecutive** five-minute windows — about three hundred files in a quarter of an hour. A period close pulls a burst and stops; a sustained rate does not. CC6.7. | Find the org and the actor in the `api` log group for that window. Treat it as a possible disclosure until it is explained, not as a busy afternoon: `docs/runbooks/incident-response.md`. |
| `meridian-production-rule-guardduty-finding` | GuardDuty High or Critical. | Account-scoped and the account is shared (ADR 0001) — it may not be ours. Triage per `docs/runbooks/incident-response.md`. |
| `meridian-production-rule-securityhub-finding` | A Security Hub HIGH/CRITICAL finding became active. | The HIPAA conformance pack and CIS both feed this. A finding here is also an **evidence** gap, not only a control gap. |
| `meridian-production-rule-config-non-compliant` | An AWS Config rule went NON_COMPLIANT. | Same: the conformance pack is what the control matrix points at as evidence. |

These three exist **only in production**, on purpose: the services are enabled once for the
whole account, so a rule in each environment would send two emails for one finding, and a
rule living only in staging would disappear with the next teardown. ADR 0024 §6.

## 6. Backups and secrets

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-rule-backup-job-failed` | An AWS Backup job failed, aborted or expired. | The recovery point for that window does not exist. Check the vault, then re-run the plan on demand. `docs/runbooks/restore-drill.md`. |
| `meridian-<env>-rule-backup-copy-failed` | The cross-region copy into the `us-west-2` vault failed. | The local recovery point may be fine; the DR one is not. ADR 0020 §8. |
| `meridian-<env>-rule-secret-rotation-failed` | A Secrets Manager rotation failed or was abandoned. | The old value still works **until it does not**. A database credential rotation that failed halfway leaves the app on `AWSPREVIOUS`. `docs/runbooks/rotate-secrets.md`. |
| `meridian-production-alarm-backup-age-rds` / `-artifacts` / `-phi` | The newest COMPLETED recovery point for that resource in the local vault is older than 26 h. **No job failed** — the two rules above would have said so — so the plan did not run at all: disabled, its selection tag changed, or S3's AWS Backup opt-in switched off (T:160, Codex G-M1). | `aws backup list-backup-plans`, then the plan's selections and the resource's tags (`Project`, `Environment`, `DataClassification` must all match). For a bucket, `aws backup describe-region-settings` (S3 opt-in). Then run the plan on demand. |
| `meridian-production-alarm-backup-age-dr` | The newest copy in the `us-west-2` vault is older than 32 h. | The copy action or the DR vault — `backup-copy-failed` should have fired if a copy ran; if it did not, check the plan rule's `copy_actions` and that `meridian-production-dr` is deployed. ADR 0020 §8. |
| `meridian-production-alarm-backup-pitr-lag` | RDS's `LatestRestorableTime` is more than an hour behind: point-in-time recovery cannot reach the last hour (the RPO, ADR 0007). | `aws rds describe-db-instances --db-instance-identifier meridian-production-rds-main --query 'DBInstances[0].LatestRestorableTime'`. Usually transaction-log upload trouble; open an AWS support case if it persists. |
| `meridian-production-alarm-backup-missing` | A protected resource (or the DR vault, or the PITR edge) has **no** recovery point at all. | The checker's log line (`/aws/lambda/meridian-production-lambda-backup-freshness`) names which. Treat as the age alarm above, but for a resource that was never backed up. |
| `meridian-production-alarm-backup-checker-silent` | The freshness checker has not completed a run in 24 hours, so every age alarm above is reading nothing. | The function's errors (`aws logs tail /aws/lambda/meridian-production-lambda-backup-freshness`) and the `meridian-production-rule-recovery-point-ages` schedule rule. |

## 7. Saturation

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-alarm-api-cpu` / `-web-cpu` | Above 85% CPU for 15 minutes. Fargate does not burst — this is the ceiling, not a warning shot. | If it is `api` during a period close, it is expected and the task is undersized. Otherwise look for a loop. |
| `meridian-<env>-alarm-api-memory` / `-web-memory` | Above 85% memory for 15 minutes. | The next step is an OOM kill, which looks like a random 502 to a user. Check for an unbounded DataFrame read. |
| `meridian-<env>-alarm-user-migration-errors` | The Cognito User Migration Lambda errored. It fails closed, so **every error is a person who was told sign-in is unavailable**. | `docs/runbooks/cognito-user-migration.md`. Usually Supabase — the function calls it over the public internet. |
| `meridian-<env>-alarm-user-migration-duration` | p99 within a second of Cognito's hard 5-second trigger budget. Past 5s Cognito abandons the sign-in and nothing in the Lambda's own metrics calls that an error. | Same runbook. Suspect Supabase latency before the function. |

## 8. The API platform — machine clients and webhooks (Phase 12)

These two alarms live in `meridian-<env>-api`, not `observability`, and exist **only when that
stack was deployed with `-c enableApiPlatform=true`** (`infra/meridian/stacks/api.py`). They
are not on the golden-signals dashboard yet. Written in Phase 12 (T17) and never tripped.

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-alarm-machine-auth-failures` | At least 20 machine bearer tokens refused at `/api/v3` in five minutes (metric `Meridian/App` → `MachineTokenRefused-<env>`, counted from the api's plain-text line `v3 machine token refused`, so it is **not** silent the way the 🔇 rows are). One misconfigured client makes a steady trickle — one refusal per call; someone guessing makes a wall. The api's own progressive lockout (`api/v3/quotas.py`) already refuses a source from its tenth failure; this is the human page. | In the `api` log group for the window, read the refusal lines' reason codes (never a token — none is logged). A client you revoked or disabled recently is the usual answer and needs nothing: it clears when the partner stops retrying (`revoke-api-client.md` §3). Otherwise find the client and its last address with `GET /api/v3/admin/api-clients/<id>/usage`, and if the traffic is not the partner's, revoke (`revoke-api-client.md`). |
| `meridian-<env>-alarm-webhook-dlq` | A webhook delivery message is sitting in `meridian-<env>-sqs-webhooks-dlq`. Either the engine gave up after 8 attempts (≈ 1.3 days of retries — the delivery row is `dead`), or the sender Lambda crashed on the same message 8 times and the queue's redrive policy moved it. **A partner has not received a run event it subscribed to.** | Webhook DLQ triage, below. |

### Webhook DLQ triage

The DLQ holds messages for 14 days, and the alarm stays in ALARM while **any** message is
visible, so triage ends with the message deleted. A message is ids only — never a URL, a
body or a name (`src/webhooks/ports.Message`):

```json
{"delivery_id": "<uuid>", "kind": "delivery", "org_id": "<uuid>"}
```

(`kind: "fanout"` with an `event_id` instead means fan-out itself crashed eight times — a bug
in our code, not a partner problem; go to step 2 and read the Lambda's errors.)

1. **Read the messages without deleting them.**

   ```bash
   DLQ=$(aws cloudformation describe-stacks --stack-name meridian-<env>-api \
     --query "Stacks[0].Outputs[?OutputKey=='WebhookDlqUrl'].OutputValue" --output text)
   aws sqs receive-message --queue-url "$DLQ" --max-number-of-messages 10 \
     --visibility-timeout 300 --attribute-names All
   ```

   Keep each `ReceiptHandle` for step 5. (They become visible again after five minutes.)

2. **Why did it die?** The delivery row says, as the org's admin (humans with org admin hold
   `webhooks:manage`):

   ```bash
   curl -sS -H "Authorization: Bearer $TOKEN" \
     "$BASE/webhooks/deliveries?status=dead&limit=50"
   ```

   `last_error_code` / `last_status_code` on the matching `delivery_id`:

   | Code | Meaning | Whose problem |
   |---|---|---|
   | `HTTP_ERROR` + a 4xx/5xx | the partner's endpoint answered and refused | theirs — tell them the status and time, never our internal ids beyond the delivery id |
   | `TIMEOUT` / `NETWORK_ERROR` | their endpoint was down or slow (> 10 s) | theirs |
   | `REDIRECT_NOT_FOLLOWED` | their URL answers with a redirect; we never follow one | theirs — they must give the final URL |
   | `SSRF_BLOCKED` | their hostname resolved to a private, link-local or our own VPC address on every attempt | theirs, unless it happens for many partners at once — then suspect our resolver |
   | no row, or the row is not `dead` | the Lambda crashed on this message (redrive-policy path) | **ours** — `aws logs tail /aws/lambda/meridian-<env>-lambda-webhook-sender --since 2d` |

   If the subscription is now `paused`, five deliveries died in a row
   (`src/webhooks/engine.AUTO_PAUSE_AFTER`) and nothing further is being sent to it.

3. **Fix the cause.** The partner fixes their endpoint; or we fix the Lambda and deploy. A
   paused subscription is resumed with `PATCH $BASE/webhooks/subscriptions/<id>`
   `{"status": "active"}` once they confirm the endpoint works — send a test ping first
   (`POST …/subscriptions/<id>/test`).

4. **Redrive.** Only through the API — it puts the row back to `pending` and enqueues the id,
   and the engine re-runs the tenant re-check, so a redrive can never send what a fresh
   attempt would not:

   ```bash
   curl -sS -X POST -H "Authorization: Bearer $TOKEN" \
     "$BASE/webhooks/deliveries/<delivery id>/redrive"
   ```

   `202` = queued; `409 WEBHOOK_STATE_INVALID` = it is not `dead` or `dropped`, or
   (`details.reason`) it was redriven 3 times already (`REDRIVE_LIMIT`) or its event is older
   than 7 days (`EVENT_TOO_OLD`); `429 QUOTA_EXCEEDED` = a redrive on the same
   subscription already in this 30-second window (one per window; `Retry-After` says how many
   seconds are left). Those bounds are deliberate (each redrive re-sends up to 8 signed
   requests to a third party): past them the partner re-reads the run over the API instead.
   Every call, allowed or refused, is an `audit.api_request` row. **Do not use
   the SQS console's "Start DLQ redrive"**: it moves the message back, the engine finds the
   row still `dead`, acknowledges it and sends nothing — the alarm clears and the partner
   still has no event. A redriven delivery's event id is unchanged (it is the delivery's own
   id, unique per subscription), so a receiver that de-duplicates is safe.

5. **Delete the DLQ message** (the row, not the message, is the record of what happened):

   ```bash
   aws sqs delete-message --queue-url "$DLQ" --receipt-handle "<ReceiptHandle>"
   ```

   The alarm returns to OK within five minutes of the queue being empty. If the partner is
   gone for good, skip step 4 and delete the subscription instead
   (`DELETE $BASE/webhooks/subscriptions/<id>` — a soft delete; the delivery log is kept).

## 9. Email (SES)

Tracker T:39. They replace the manual 24-hour watch in `docs/runbooks/email-cutover.md` §3.
The two reputation alarms are **production only**: the rates are the account's (shared, ADR
0001) and AWS acts on them account-wide, so one alarm, not one per environment.

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-alarm-ses-rendering-failure` | SES could not render a message — a template or its data is broken — and the email was never sent. There will be no bounce and no complaint; this is the only signal. Counted per environment from the `env` message tag (`meridian-shared-ses-metrics` destination). | The `RENDERING_FAILURE` event on `meridian-shared-sns-email-events` names the template. Reproduce with `scripts/ses_smoke.py` against staging. If a deploy just changed the template, roll the api back (`email-cutover.md` §2 does not help: Resend renders the same template). |
| `meridian-production-alarm-ses-bounce-rate` | The account's `Reputation.BounceRate` is above 5 %, AWS's review line; above 10 % AWS may pause sending for the whole account. | Read the BOUNCE events on the email-events topic: whose sends are they (the account is shared)? A burst of hard bounces from one invite batch means a bad address list — stop inviting, fix the list. `email-cutover.md` §3. |
| `meridian-production-alarm-ses-complaint-rate` | The account's `Reputation.ComplaintRate` is above 0.1 %. On this volume that can be one complaint. | Read the COMPLAINT event; the address is now on the suppression list (`email-cutover.md` §0.6). Confirm with the person by another channel before anything else is sent to them. |

## 10. The job worker (Phase 11)

These five exist **only when `compute` and `observability` were deployed with
`-c worker_enabled=true`** (`infra/meridian/stacks/worker.py`, tasks H1/H2). They are in the
dashboard's alarm carpet with the rest. Written 2026-09-24 and never tripped — H3 (staging)
is where each is tripped once and the mail kept.

**A job message is ids and codes, and its storage keys end in the uploaded file's name.**
Treat a DLQ message body like a log line: read it in the console or the CLI, never paste it
anywhere (a billing export can be named after a person). That is also why both queues are
on the `phi` CMK and only `meridian-<env>-*` roles can decrypt them.

| Alarm | What it means | First action |
|---|---|---|
| `meridian-<env>-alarm-jobs-dlq` | A message is in `meridian-<env>-sqs-jobs-dlq`. Either the worker **refused** it (the `reason` message attribute is a code — table below) or it was received three times without finishing and SQS moved it (no `reason` attribute). **Someone's run did not happen**, or a sweep tick was refused. | Job DLQ triage, below. |
| `meridian-<env>-alarm-jobs-age` | The oldest message on `meridian-<env>-sqs-jobs` is more than 15 minutes old. A job **in flight** counts too, so one run that has been working for 15 minutes trips it. | Is `worker-task-count` also red? Then it is the worker, not the job. Otherwise `aws logs tail /meridian/<env>/ecs/worker --since 30m` and look for `run is leased by another delivery` (a stuck lease — it expires on its own), `heartbeat found the lease gone`, or one `job started` with no end (a slow handler: note the run id, let it finish). |
| `meridian-<env>-alarm-worker-task-count` | Fewer than one running `svc-worker` task. Nothing is taking jobs off the queue; runs sit in `running`/`parsing` until the sweeper fails them. | `aws ecs describe-services --cluster meridian-<env>-ecs-main --services meridian-<env>-ecs-svc-worker` — read `deployments` (circuit breaker rolled back?) and `events`. A task that stops at once is usually its environment: `aws logs tail /meridian/<env>/ecs/worker --since 15m` shows the `RuntimeError` naming the missing variable. |
| `meridian-<env>-alarm-sweep-stalled` | No `sweep done` line from the worker for an hour; the sweep should run every 15 minutes. Expired drafts are not expiring and lapsed runs are not being failed. **Staging treats "no data" as no change** (its database is stopped overnight), so this pages from production only. | If `sweep-dropped` or `worker-task-count` is also red, follow that one. Otherwise the worker is receiving the tick but the sweep fails: look for `sweep could not run; left for redelivery` (the database) or a `job refused` with `sweep_not_enabled` (the worker is not on RDS — `DATABASE_BACKEND` in the task definition). By hand, safely: `python -m workers.sweep --dry-run` through ECS Exec on the api task. |
| `meridian-<env>-alarm-sweep-dropped` | EventBridge Scheduler gave up on a sweep tick after two retries: the send to the job queue was refused. The group holds both ticks — the 15-minute run sweep and, with the api platform on, the 5-minute webhook outbox tick (`meridian-<env>-schedule-outbox-sweep`, decision D17) — through the same role, so either can trip it. The role (`meridian-<env>-iam-sweep-scheduler`), the `phi` key or the queue is wrong. | `aws scheduler get-schedule --group-name meridian-<env>-schedule-worker --name meridian-<env>-schedule-sweep-runs` and compare its target with the queue ARN; then the role's policy. A key or queue recreated by a teardown is the usual cause — redeploy `compute`. |

### Job DLQ triage

The DLQ keeps messages for 14 days and the alarm stays red while **any** is visible, so
triage ends with the message deleted. The run row, not the message, is the record.

1. **Read without deleting.**

   ```bash
   DLQ=$(aws cloudformation describe-stacks --stack-name meridian-<env>-compute \
     --query "Stacks[0].Outputs[?starts_with(OutputKey,'WorkerJobsDlqUrl')].OutputValue" \
     --output text)
   aws sqs receive-message --queue-url "$DLQ" --max-number-of-messages 10 \
     --visibility-timeout 300 --message-attribute-names All
   ```

   Keep each `ReceiptHandle`. The body names `run_id`, `org_id` and `kind`; the attribute
   `reason` says why (absent = three receives, see the last row).

2. **What the reason means:**

   | `reason` | Meaning | Whose problem |
   |---|---|---|
   | `run_not_found` | No such run in that org — deleted, or the message named another org's run (refused without saying which) | nobody's if the run was deleted; otherwise a bug in whatever enqueued it |
   | `actor_mismatch` / `actor_not_member` / `actor_unknown` | The run was started by someone else, the starter has since left the org, or the actor is unknown | expected after a removal; otherwise a bug |
   | `process_mismatch` / `inputs_mismatch` | The message's process or input versions are not what the run recorded — a stale or forged message | ours: never replay it |
   | `state_not_allowed` | The run is not in a state this job may start from (cancelled, expired, or already finished by another delivery) | usually nobody's |
   | `unknown_process` / `unknown_job` / `no_handler` | The worker has no handler for it. **`no_handler` is expected** while a process is still on the in-process thread (its handler lands with B1-B3) and a message was sent anyway — `WORKER_PROCESSES` should not list it | ours: fix the allowlist, not the message |
   | `malformed_message` | The body is not a v1 job message at all. **After a rollback to an image older than decision D17** every `outbox_sweep` tick lands here (that image has no such kind): disable the tick first — `aws scheduler update-schedule` on `meridian-<env>-schedule-outbox-sweep` in group `meridian-<env>-schedule-worker` with `--state DISABLED` (repeat its target and flexible time window) — and run `python -m workers.outbox_sweep` by hand until the newer image is back. No run or row is affected | ours |
   | `sweep_not_enabled` | A sweep tick reached a worker that is not on RDS | the task definition |
   | `outbox_sweep_not_enabled` | The 5-minute webhook outbox tick (decision D17, `kind: outbox_sweep`) reached a worker that is not on RDS | the task definition |
   | *(none)* | Three receives, never finished: the worker died or lost its lease three times. `app.expire_stale_runs` fails the run on the next sweep (`attempts >= 3`) | ours: the worker log for that `run_id` |

3. **Fix the cause, then let the person re-run it** from the app (a retry or a new run —
   never by moving the message back: the SQS console's "Start DLQ redrive" re-delivers a
   message the worker already judged, and for most reasons it is refused again).

4. **Delete the DLQ message:** `aws sqs delete-message --queue-url "$DLQ"
   --receipt-handle "<ReceiptHandle>"`. The alarm clears within five minutes of the queue
   being empty.

## The dashboard

`meridian-<env>-dashboard-golden-signals` — latency, traffic, errors, saturation, then the
Lambda, backups and a security row, and an alarm carpet at the bottom showing every alarm's
current state in one place. Start there, not in the alarm list.

**No widget shows a log line body**, deliberately: a dashboard is the most-screenshotted
surface in the estate. The log-derived numbers on it are counts, which carry no text.

**There is no Security Hub widget and there will not be one** — Security Hub has no
CloudWatch namespace, it publishes findings to EventBridge, and the widget that used to be
here drew an empty graph under a security heading for ever. The GuardDuty widget appears
only when the dashboard is synthesized with `-c guardDutyDetectorId=<id>`, because
`FindingCount` is per-detector and returns nothing without it. Read findings in the Security
Hub and GuardDuty consoles, or wait for the `meridian-production-rule-*-finding` mail.

## What is still owed here

Per the plan's verify list, **every alarm must be tripped deliberately once on staging and
the SNS mail kept as evidence.** None has been. Two things in this document that a redeploy
is a prerequisite for:

* **`meridian-<env>-data` must be redeployed before anything here can page.** The alerts
  topic's resource policy and the `logs` CMK's key policy both changed (ADR 0024 §6): the
  topic policy is now written out in full rather than being appended to by a construct,
  and `events.amazonaws.com` gained the KMS grant it never had. Without that redeploy every
  EventBridge-sourced notification — backups, rotation, findings, the stop schedule — fails
  inside SNS with the rule showing as invoked.
* **The stop-schedule check moved out of SQS.** `scripts/staging_session.sh up` reads
  `meridian-staging-logs-stop-schedule` now; the queue is drained by the Pipe and a manual
  `receive-message` will find it empty whether or not anything is wrong. Until that is done this runbook is a draft
and the control-matrix rows that point at it are pointing at a plan
(`docs/runbooks/README.md`: a procedure nobody has run is not evidence).
