# Runbook — Flip 2, the production cutover (Phase 9)

**What this covers:** moving production traffic off Render and Supabase and onto ECS, RDS and
S3, in one freeze window, with the data proven identical before any of it serves a request.
Plan `docs/aws-migration-plan.md` Phase 9, §6 "The points of no return", D-20, ADR 0013.

**What it does not cover:** the schema (`migrations.md`), the mechanics of the load itself
(`data-load.md` — this runbook calls it, it does not repeat it), the auth flip (that was Flip 1,
Phase 4, `cognito-user-migration.md`), or switching anything off afterwards
(`decommission-supabase-render.md`, Phase 10, months later).

> **This runbook has not been executed yet.** It is a plan until it has been run end to end —
> twice on staging as rehearsals, once in production for real — with the dates and timings in
> the table at the bottom. A control-matrix row pointing here is pointing at a draft.

> **Rehearsal 2 is run without editing this file.** If you have to change a step mid-rehearsal,
> the rehearsal has failed: fix the file, and run rehearsal 2 again from the top. A runbook that
> was corrected while it was being followed has not been proved.

---

## The shape of the day, in one paragraph

Writes stop on Supabase. The data is dumped, restored into RDS, split, and proved equal to the
cent. The storage objects are copied and every one of them is checked to exist. Production ECS
is deployed with `DATABASE_BACKEND=postgres` and `STORAGE_BACKEND=s3`. **Nothing has moved
yet** — the site is still Render, and every single thing up to this point is thrown away by
deleting an RDS database. Then a read-only smoke test runs **through the CloudFront
distribution** on `https://app.meridiansgrp.com` — a name that has pointed at CloudFront since
the edge was first deployed with the zone id (ADR 0050), so no DNS has to move for it. Then,
and only then, the apex and `www` flip, and the first write that lands on RDS is the point of
no return. Render stays running, paid, **in maintenance** and untouched behind you.

**The addresses after this day (ADR 0050):** `www.meridiansgrp.com` is the public website
only, and every app path requested there is a 308 to the same path on
`app.meridiansgrp.com`, where Meridian lives; the bare domain is a 301 to `www`;
`api.meridiansgrp.com/v3/...` is the partner API. So a bookmark to `www…/login` keeps working
— it lands on `app…/login`.

```
  1  STOP gate          Andres says go
  2  freeze             Render in maintenance; prove no run is in flight; STOP the api
  3  load               data-load.md steps 1-7 against production RDS
  4  storage            copy objects; head_object every storage_path
  5  deploy             production ECS on postgres + s3   (still no traffic)
  6  smoke, READ-ONLY   through CloudFront, with --resolve; no DNS moves
  7  STOP gate          Andres says flip
  8  DNS, TWO DEPLOYS   dns: renderRecords=false  →  edge: createDnsAliases=true
  9  watch              one hour at the console, then 24 hours, then one close
```

Steps 1-6 are reversible by doing nothing. Step 8 is reversible for as long as nobody has
written. After the first write it is a day of manual re-entry (§ "Rollback matrix").

---

## Before you start

| | |
|---|---|
| **Who** | Andres, at a keyboard, for the whole window. One other person reachable by phone. |
| **Roles** | `meridian_migrator` (RDS master) for the load; the deploy role for CDK; the Route 53 zone for the flip. Never the application role for any of it. |
| **Access** | RDS is private — `psql` goes through SSM port-forwarding (`db-access.md`). |
| **Secrets** | `MERIDIAN_PHI_HMAC_KEY` from Secrets Manager, **the same key that wrote `patient_ref` in the rehearsals**. In the environment, never argv (`data-load.md` § "The key"). |
| **Tools** | `psql`, `pg_dump`/`pg_restore` ≥ 17.6, `aws`, `dig`, the repo venv, `npx cdk`. |
| **Where the dump goes** | The encrypted volume. **Never inside this repository, never Downloads, never Desktop.** It is PHI. It is a **working copy**, shredded after the first close — the long-term archive is the Phase 10 dump (`decommission-supabase-render.md` step 2), not this one. |
| **Timebox** | Budget from the rehearsal 2 timings below. If step 3 is not clean by the time you are half way through the budget, **abort** — the freeze is cheap, a half-loaded database is not. |

### Placeholders used below

`<zone-id>` the Route 53 hosted zone id · `<account-id>` the AWS account · `<pool-id>` the
Cognito user pool · `<render-hostname>` the Render service hostname the `www` record points at
today · `$SUPABASE_DB_URL` / `$RDS_URL` Postgres connection strings read from Secrets Manager
or `.env` — `SUPABASE_DB_URL` is the **session pooler, port 5432** (what
`scripts/staging_data_load.sh` uses); `SUPABASE_URL` is the HTTPS API URL, which `psql` and
`pg_dump` cannot use and only step 4a's mirror script reads · `$CUT` the day's folder on the
encrypted volume, set in step 1.
**No real value for any of these belongs in this file.**

---

## Preconditions — every box, or the window does not open

Nothing here is a judgement call. If a box is empty, the answer is "not this month".

### A. The phase reports' "Not yet run" lists are closed

Each phase report carries a list of checks that were written but never executed. Every one of
them is a cutover precondition, because the cutover is the first time any of it carries real
traffic.

| Report | Item | Evidence that closes it |
|---|---|---|
| Phase 0 | One real revenue run and one real payroll run on Render, byte-identical to the previous run | `diff_je_output.py` output, dated |
| Phase 0 | A commit to `main` produces no Render deploy | Auto-Deploy = No on both services, screenshot |
| Phase 1 | MFA enrolled for both workforce members; IAM triage complete in order; long-lived key inactive | `identity-center-bootstrap.md` §6-8 signed off |
| Phase 1 | SES out of the sandbox; Security Hub standards on; budgets exist | The SES production-access case, closed |
| Phase 1 | **Cost estimate approved in writing** | Andres's written approval, filed |
| Phase 2 | All six deploy-time checks (`cdk diff` clean twice, tag filter, direct-ALB curl rejected, CloudFront reaches the ALB, SSM with zero ingress, destroy + redeploy < 20 min) | The staging session log |
| Phase 3 | Rehearsal load with timings; the ~50-object storage copy with `head_object`; **the restore drill with an elapsed time**; `pgaudit` loaded; a non-KMS `put-object` fails; the vault is locked | `data-load.md` § Timings; `restore-drill.md` |
| Phase 4 | A Supabase-era password signs in through the Lambda; MFA round-trip; one Microsoft and one Google link; the Lambda's p99 inside budget | `cognito-user-migration.md` §4-5 |
| Phase 4 | **Flip 1 is already live in production** — `AUTH_BACKEND=cognito` on Render, watched for an hour, not rolled back | The Render dashboard, and a week of sign-ins |
| Phase 5a | **The port gate**: production restored into the fixture, a booked period re-run, JE CSVs byte-identical, all 15 files — twice (after `database.py`, after `web_app.py`) | `data-load.md` § Port gate; `docs/je-diff-procedure.md` |
| Phase 5a | The full verify list: a revenue run and a QB USA payroll run on staging, upload/download round trips, a forced task replacement mid-run | The staging session log |
| Phase 5b | `next.config.mjs`'s `jinja` array is **empty, full stop** | The file, read on the day |
| Phase 6 | Every alarm tripped once on staging with the mail kept; the SNS subscription **confirmed**; one `phi` read producing exactly one `audit.phi_access` row and one pgaudit line, neither carrying an identifier; the `data` stack redeployed so EventBridge-sourced alerts can publish | `alerts.md` step 0 and the kept emails; the audit/pgaudit lines, redacted |
| Phase 7 | SES out of the sandbox; one `scripts/ses_smoke.py` send from staging with `dkim=pass`, `spf=pass`, `dmarc=pass` in the received headers (`email-cutover.md` §0.7); the `meridian-shared-sns-email-events` subscription **confirmed**. **Not** "SES live in production": the flip is a side effect of this cutover (the ECS task already carries `EMAIL_BACKEND=ses`, ADR 0025 §3), and Resend stays on Render until Render goes | The support case, the smoke-send headers, the subscription's `SubscriptionArn` |
| Phase 8 | Every control-matrix row points at an artifact that exists; the DR test's RTO/RPO written into the contingency plan | `docs/compliance/control-matrix.md` |

> **Resolved 2026-09-24.** The Phase 6 and Phase 7 rows above were first written from the
> plan's verify lists because the reports did not exist yet. Both reports exist now, and the
> two rows were re-read against their "Not yet run" and "Needs a human" sections.

> **The Phase 5b row used to read "empty except the three process wizards". It was wrong on
> both counts, and the correction matters for step 2.** `web/next.config.mjs`'s `jinja` array
> is empty except for the two entries behind the `MERIDIAN_JINJA_AUTH=1` rollback hatch, which
> a normal build does not set. There is no Jinja process wizard in it and no ALB path pattern
> for one, so after the flip `/qb-revenue`, `/mx-payroll` and `/qb-usa-payroll` are **not
> reachable from `www` at all**: the ALB claims `/api/*`, `/auth/*` and `/static/*` for the api
> container and everything else goes to Next. The React `processes/[process]` screens drive
> those runs over `/api/v2`, and their state is in `public.process_runs` via
> `src/run_store.py` — which is why step 2's query can see them. What it still cannot see is
> the **three** families that remain module-level dicts in the api process:
> `adp_payroll_session`/`adp_payroll_job_status`, `booking_payroll_*` and `adp_v3_job_status`
> (all three in `web_app.py`; line numbers move, so find them with `grep -n 'adp_payroll_job_status = \|booking_payroll_\|adp_v3_job_status = ' web_app.py`). That is what the phone call in step 2 is for, and it is
> three, not five.

### B. The rehearsals

- [ ] **Rehearsal 1** — full dress on staging from a fresh Supabase dump. Clean on
      `scripts/verify_parity.py` and `scripts/diff_je_output.py` for both rehearsal periods.
- [ ] **Rehearsal 2** — timed, from a clean RDS, following **this file** literally, **with no
      edits to it**. Same two clean results. Its timings are what the freeze window is budgeted
      from.
- [ ] The two rehearsal periods are named and their input workbooks are findable
      (`docs/je-diff-procedure.md` § "Rehearsal periods": MX payroll FY26-P09, batch 91, and
      QB USA payroll FY26-P09, batch 89 — both payroll; revenue has no stored input).

#### Payroll JE comparison (rehearsal)

Run this in each rehearsal, around the staging data load. It is the JE half of parity.

**Same-day, never against the stored old output.** The two periods are the only ones with both
a stored input and a stored output (`docs/je-diff-procedure.md` § "Rehearsal periods"), but
`main`'s payroll code has changed since they ran: MX books by department since 2026-10-05, and
QB USA books negatives as credits and splits leftover UNUM/BCBS charges. Diffing today's
output against September's would fail on those known changes, and the diff has no allowlist.
So the OLD side is a fresh run on production (Render) and the NEW side is staging, the same
day, from the same input files and the same roster and config.

**(a) Fetch the inputs onto the PHI volume.** `scripts/mirror_supabase_storage.py` copies the
whole `uploads` bucket (T:249) but filters only by `--since` and bucket, not by run, so for two
named runs fetch just their folders as below. The inputs are in the **`uploads`** bucket, where
`src/storage.persist_to_storage` has written every Render-era upload since v1.2.0, at
`{org_id}/{process}/{YYYY-MM-DD}/{name}` (MX: one workbook named
`{YYYYMMDD_HHMMSS}_{8 hex}_{original name}`; QB USA: the run's folder,
`{run_id}/{the 8 CSVs}`). First find the day and the names:

```bash
RH=/Volumes/MeridianPHI/Meridian/je-rehearsal-$(date +%F)
mkdir -p "$RH"/{inputs,old,new} && chmod 700 "$RH"

psql "$SUPABASE_DB_URL" -XA -F' | ' -c \
  "SELECT b.id, b.batch_type, b.org_id, b.created_at::date AS day, b.input_file,
          r.process, r.run_id
     FROM public.import_batches b
     LEFT JOIN public.process_runs r ON r.batch_id = b.id AND r.org_id = b.org_id
    WHERE b.id IN (89, 91)
    ORDER BY b.id;"
```

Then pull those day folders (repo root, the repo venv; `SUPABASE_URL` and
`SUPABASE_SERVICE_KEY` come from `.env`, never argv). The upload is written a few minutes
before the batch row, so if a folder comes back empty try the day before:

```bash
venv/bin/python - "$RH/inputs" \
    "<org_id>/mx-payroll/<day of batch 91>" \
    "<org_id>/qb-usa-payroll/<day of batch 89>/<run_id of batch 89>" <<'PY'
import os, sys
from pathlib import Path
from dotenv import load_dotenv
from supabase import create_client

load_dotenv(".env")
store = create_client(os.environ["SUPABASE_URL"], os.environ["SUPABASE_SERVICE_KEY"]).storage.from_("uploads")
dest = Path(sys.argv[1])

def walk(prefix):
    for e in store.list(prefix, {"limit": 1000}) or []:
        key = f"{prefix}/{e['name']}"
        yield from (walk(key) if e.get("id") is None else [key])

for prefix in sys.argv[2:]:
    for key in walk(prefix.rstrip("/")):
        (dest / key).parent.mkdir(parents=True, exist_ok=True)
        (dest / key).write_bytes(store.download(key))
        print("fetched", key)
PY
```

The MX day folder can hold several uploads (the superseded batches 87, 88 and 90 are the same
period); batch 91's is the one whose name ends with `input_file`'s file name (as
`secure_filename` wrote it: spaces become `_`). The QB USA folder
must hold **8 CSVs**; fewer means the wrong `run_id`.

**(b) OLD: run each input on production, without booking.** On `https://www.meridiansgrp.com`,
`/processes/mx-payroll/new` and `/processes/qb-usa-payroll/new`: upload the fetched file(s),
period FY26-P09, and write every parameter you enter (exchange rate, accrual days, …) in the
log, because (c) must use the same values. Run it, **do not press Book**, and download the
JE CSVs into `$RH/old/mx-payroll/` and `$RH/old/qb-usa-payroll/`. An unbooked run expires on
its own (`process_runs.expires_at`), so it leaves nothing for the close. Do not open a
QuickBooks posting screen. Do this **before** the rehearsal dump and the same day, and let
nobody edit the roster, mappings or settings between (b) and the dump.

**(c) NEW: the same inputs on staging, right after the rehearsal data load.** On
`https://staging-app.meridiansgrp.com`, the same two screens, the same files, the same
parameters from the log. Download the JE CSVs into `$RH/new/mx-payroll/` and
`$RH/new/qb-usa-payroll/`. Staging now holds the roster and config the dump carried, which is
what Render read in (b).

**(d) Diff.** The CLI is positional, `OLD_DIR NEW_DIR`:

```bash
venv/bin/python scripts/diff_je_output.py "$RH/old/mx-payroll"    "$RH/new/mx-payroll";    echo "exit $?"
venv/bin/python scripts/diff_je_output.py "$RH/old/qb-usa-payroll" "$RH/new/qb-usa-payroll"; echo "exit $?"
```

**Pass is exit 0 on both.** Exit 1 is a difference or a missing file on either side: the
rehearsal has failed, whatever else was green. The report redacts names and identifiers (a
salted digest per run), so it may be pasted into the log and the phase report; the CSVs
themselves stay in `$RH` and are shredded with it after sign-off.

*QB USA roster caveat:* 29 `qb_usa_employee` rows changed on 2026-10-02 at 20:35 UTC, after
batch 89 ran. That is one more reason the stored batch-89 output cannot be the OLD side; it
does not touch a same-day comparison, because (b) and (c) both read today's roster.

*Revenue:* no stored inputs exist, so there is no revenue comparison unless Andres supplies the
original billing exports for a closed period. If he does, it is the same procedure on
`/processes/qb-revenue/new`, with those files in `$RH/inputs`.

### C. The platform

- [ ] Production stacks deployed and smoke-tested (Phase 8); production cost inside the
      approved estimate.
- [ ] **The pipeline is green at the cutover sha.** Decided (T:124): production is never
      deployed by `deploy.yml` — it offers `staging` only and accepts only
      `confirm: deploy-staging`, and its header says why. So this check is: the full workflow
      green for staging at this sha (tests, both images built, Trivy clean, both services
      stable), **and** the production stacks deployed by hand, one at a time, `--exclusively`,
      from that same sha.
- [ ] The Phase 8 restore drill **re-run against production RDS**, with its elapsed time written
      down. The RTO number in the contingency plan is the one from this run, not from staging.
- [ ] `createDnsAliases` is still **false** in production and `renderRecords` is still **true**,
      i.e. no live traffic has moved yet. Prove it from Route 53, not from memory — the apex and
      `www` must have **no `AliasTarget`**:
      ```bash
      aws route53 list-resource-record-sets --hosted-zone-id "<zone-id>" \
        --query "ResourceRecordSets[?Name=='meridiansgrp.com.'||Name=='www.meridiansgrp.com.'].\
      {Name:Name,Type:Type,Alias:AliasTarget.DNSName,Values:ResourceRecords[].Value}"
      ```
      Every `Alias` must be `null` and the values must be `<render-hostname>` / the Render IP.
- [ ] `origin-production.meridiansgrp.com` resolves and serves the new stack. **`app.` and
      `api.meridiansgrp.com` already resolve to the production distribution** — the edge
      creates them whenever it is deployed with `hostedZoneId`, independent of
      `createDnsAliases` (ADR 0050) — and `staging-app.` / `staging-api.` did the same for
      the rehearsals. Nothing links to `app.` yet, so it carries no traffic; do not announce
      it before step 7.
- [ ] **Every external registration names the app host** (ADR 0050 § "Who has to be told"):
      the production Intuit app lists
      `https://app.meridiansgrp.com/api/v2/qbo/connection/callback` as a redirect URI, and the
      Cognito web client's callback/logout URL is `https://app.meridiansgrp.com/auth/callback`
      (the default in `infra/meridian/stacks/auth.py`). Google and Microsoft Entra need no
      change — they redirect to the Cognito hosted domain, not to Meridian.
- [ ] **The origin-verify context set from the last production edge deploy is written down**, by
      name and value, because step 8 has to pass the identical set. Take it from the deploy log
      or from `docs/runbooks/rotate-origin-verify-secret.md`'s record:
      `originVerifyActiveVersion`, `originVerifyPreviousVersion`,
      `originVerifyCloudFrontVersionId`. An edge deploy that omits one of them does not just
      fail to move DNS — it re-resolves the secret and can hand CloudFront a value the ALB does
      not accept, which is a 403 on every request the moment the aliases exist.
- [ ] **The CloudFront managed prefix list id is written down too**, for the same reason and in
      the same place: `cloudfrontPrefixListId`. It is the fourth `-c` value every production
      `meridian-production-edge` deploy carries (`docs/runbooks/rotate-origin-verify-secret.md`
      §"Rotate", and the ALB ingress rule in `infra/meridian/stacks/edge.py`). Omit it and the
      deploy does not fail — it **re-renders the ALB security group without the CloudFront
      ingress rule**, which takes the site off the air just as thoroughly as a wrong
      origin-verify version, and does it in the same deploy that moves DNS. Get it from the
      last deploy log, or:
      ```bash
      aws ec2 describe-managed-prefix-lists --region us-east-1 \
        --filters Name=prefix-list-name,Values=com.amazonaws.global.cloudfront.origin-facing \
        --query 'PrefixLists[0].PrefixListId' --output text
      ```

- [ ] **`public.source_transactions` has moved to `phi`** (`ALTER TABLE … SET SCHEMA phi`, the
      P-3 revision), `meridian_app` holds no grant on it, and the only reader is `src/phi.py`
      — `scripts/verify_parity.sql` row `phi.source_transactions` matches Supabase's count
      (Codex PS-1). Not "later".

### D. DNS

- [ ] `meridiansgrp.com` is on the Route 53 nameservers (`dns-nameserver-switch.md`, done in
      Phase 1).
- [ ] **TTL on the apex and `www` is 300 s and has been for ≥ 24 hours.** Check it, do not
      assume it:
      ```bash
      dig +noall +answer @"$(aws route53 get-hosted-zone --id "<zone-id>" \
            --query 'DelegationSet.NameServers[0]' --output text)" \
          meridiansgrp.com A www.meridiansgrp.com CNAME
      ```
      The number in the fourth column is the TTL. If it reads anything above 300, lower it and
      come back tomorrow — that number is how long a rollback takes.

      **Both records are CDK-managed, so a TTL above 300 is fixed in code, not in the
      console.** `CUTOVER_TTL` in `infra/meridian/stacks/dns.py` is `Duration.seconds(300)` and
      both the apex A and the `www` CNAME already carry it; `infra/tests/test_dns.py`
      asserts it. If the live value disagrees, something edited the zone by hand — that is
      drift, and the fix is to redeploy `meridian-shared-dns`, not to retype 300 in the
      console. **After the flip the TTL stops being ours**: an ALIAS record to CloudFront has
      no TTL of its own and Route 53 answers it with CloudFront's, currently 60 seconds. So
      the 300 seconds below is what a rollback costs *going back to Render*, and the 60 is
      what a viewer waits to see the new stack.

- [ ] **≥ 24 hours before the flip: lower the zone's SOA so the dark window is 60 s, not
      900 s.** The gap between 7a and 7c is an NXDOMAIN, and how long a resolver caches an
      NXDOMAIN is *not* the record's TTL — it is **`min(SOA record TTL, the SOA MINIMUM
      field)`** (RFC 2308 §5). Route 53's defaults are a 900 s SOA TTL and an 86400 s
      MINIMUM, so the default negative cache is **900 s = 15 minutes**, and it is the real
      length of 7b for a resolver that asks during the window.

      **The SOA is not CDK-managed** — Route 53 writes it when the zone is created, `dns.py`
      contains no SOA record (`grep -c SOA infra/meridian/stacks/dns.py` → `0`), and
      `scripts/dns_zone_diff.py` ignores the type outright (`ALWAYS_IGNORED_TYPES =
      frozenset({"SOA"})`). So this is an `UPSERT` by hand, it will not show up as drift in
      `cdk diff`, and **nothing will put it back for you**. Read the current value first and
      paste it into the log, because the restore in step 8 retypes it:

      ```bash
      ZONE=<zone-id>
      NS=$(aws route53 get-hosted-zone --id "$ZONE" \
             --query 'DelegationSet.NameServers[0]' --output text)
      dig +noall +answer @"$NS" meridiansgrp.com SOA    # record the TTL and all 7 fields
      ```

      Then UPSERT it with the same seven fields, changing only the record TTL to 60 and the
      last field (MINIMUM) to 60. Keep the serial, and bump it if the current one is not
      being bumped for you:

      ```bash
      aws route53 change-resource-record-sets --hosted-zone-id "$ZONE" --change-batch '{
        "Comment": "cutover: shrink negative caching for the 7a-7c dark window",
        "Changes": [{"Action": "UPSERT", "ResourceRecordSet": {
          "Name": "meridiansgrp.com.", "Type": "SOA", "TTL": 60,
          "ResourceRecords": [{"Value":
            "ns-<n>.awsdns-<nn>.com. awsdns-hostmaster.amazon.com. <serial> 7200 900 1209600 60"}]
        }}]}'
      ```

      Verify from the zone's own nameserver, not from your resolver — your resolver may still
      be holding the old SOA for up to 900 s, which is the very thing being shortened:

      ```bash
      dig +noall +answer @"$NS" meridiansgrp.com SOA
      # expect: ... 60 IN SOA ... 7200 900 1209600 60
      ```

      **Then wait out the old 900 s before you rely on it**, which the "≥ 24 hours" already
      covers. Restore both values after the flip (step 8) — a 60 s MINIMUM left in place makes
      every NXDOMAIN in the zone a fresh query on the nameservers forever.

### E. The business

- [ ] **Not during a close.** Periods are 4-5 weeks; pick the widest gap. Check
      `fiscal_calendar` for the period end date before you pick the day.
- [ ] Not a Friday. Not the day before Andres is unreachable.
- [ ] The BAA position is confirmed in writing: the AWS BAA is active on the account, and the
      Stella Mattina ↔ Meridians Logic BAA (D-03) is signed and filed under
      `docs/compliance/evidence/`.
- [ ] Cost approval covers the production steady state, not just the migration
      (`docs/reports/phase-1-cost-estimate.md`).

---

- [ ] **The incident-response and contingency procedures are signed operating documents**, not
      drafts: who is called, in what order, with what authority to roll back or fix forward, and
      the tested emergency delegate from `alerts.md` (Codex PS-18, ADR 0026 §3.4 as amended).
      Attorney polish can follow the cutover; a signed version cannot.
- [ ] **The regional RPO is decided in writing** — accept ≈ 24-30 h from the daily cross-region
      copy, or the replica is funded and running (ADR 0007 as amended; readiness §13).

## 🛑 STOP — ask Andres (gate 1: open the window)

**Plan prompt § "Stop and ask only for these", item 1.** Do not start step 2 without a "yes"
from Andres on the day.

Show him: the precondition tables above with every box ticked, the rehearsal 2 timings, the
budgeted freeze length, and the one sentence that matters —

> *"After step 8, the first write anyone makes lands on RDS, and going back means re-entering
> that work by hand. Before step 8, going back costs five minutes. And if the parity check
> comes back with a single difference, I will drop and reload the production database — that
> is the abort rule, not a judgement call, and it can happen more than once in the window.
> Shall I start the freeze?"*

---

## The steps

### 1. Announce and open the log

Start a plain-text log on the encrypted volume: one line per step with a wall-clock timestamp.
Every "Evidence" line below goes into it as you go, not afterwards from memory. The day's
folder is the same shape `scripts/staging_data_load.sh` uses (set it once; a new shell needs
the same line again, with the same date):

```bash
CUT=/Volumes/MeridianPHI/Meridian/cutover-$(date +%F)   # run `phi-mount` first if it is absent
mkdir -p "$CUT" && chmod 700 "$CUT"
touch "$CUT/cutover.log"
```

**Evidence:** the log file, with a first line naming the sha being deployed and the two
rehearsal period ids.
**Rollback:** n/a.

---

### 2. Write freeze, and prove it

Put Render into maintenance so the banner is what a user gets rather than a half-written batch.

```bash
# Render dashboard: both services → maintenance mode on.
# Then prove nothing is mid-flight. THE COLUMN IS `state`, NOT `status`, and the
# values are the ones in migration 022's CHECK constraint:
psql "$SUPABASE_DB_URL" -c \
  "SELECT run_id, org_id, process, state, step, created_at
     FROM public.process_runs
    WHERE state IN ('parsing','ready','running','blocked')
    ORDER BY created_at;"

# And the other half of in-flight work, from migration 002. That column IS
# `status`, and 'processing' is the value src/database.py writes on insert:
psql "$SUPABASE_DB_URL" -c \
  "SELECT id, org_id, batch_type, status, created_at
     FROM public.import_batches
    WHERE status = 'processing'
    ORDER BY created_at;"
```

**Both must return zero rows.** They are two different tables with two different column names,
which is exactly the kind of thing a runbook gets wrong once and then repeats: `process_runs`
has `state` (022) and `import_batches` has `status` (002). A query against the wrong column
does not error — `status` does not exist on `process_runs`, so that one errors, but the reverse
mistake (`state = 'processing'`) returns zero rows for a reason that has nothing to do with the
freeze.

**Zero rows is necessary and not sufficient, for two reasons.**

*First*, `process_runs` is blind to the three run families that are still module-level dicts in
the api process — `adp_payroll_session` / `adp_payroll_job_status`, `booking_payroll_*` and
`adp_v3_job_status` (all three in `web_app.py`; line numbers move, so find them with `grep -n 'adp_payroll_job_status = \|booking_payroll_\|adp_v3_job_status = ' web_app.py`). **So the second half of this step is a
phone call**: ring the other user, ask "are you in the middle of anything?", and write the
answer in the log with the time.

*Second — and this is the one maintenance mode does not solve — **maintenance mode stops
requests, not threads.*** Render's maintenance banner is served in front of the application;
the process behind it keeps running, and a background job that was already started keeps
writing to Supabase. A dump taken while one of those is mid-transaction is a dump of a
half-written run. So, after the two queries come back empty:

```bash
# Render dashboard: SUSPEND `meridian-api` (not just maintenance mode). `meridian-web`
# can stay up serving the banner. Then wait for the processes to actually be gone —
# Render reports the service suspended before the last container exits.
```

**If suspending is not acceptable** — it is the thing that has to be un-done first on any
rollback, and un-suspending takes a cold start — the alternative is to *prove quiet* instead:
re-run both queries plus

```bash
psql "$SUPABASE_DB_URL" -At -c \
  "SELECT max(updated_at) FROM public.process_runs
   UNION ALL SELECT max(created_at) FROM public.import_batches
   UNION ALL SELECT max(updated_at) FROM public.qbo_connection;"
```

three times, **ten minutes apart**, and require all three values unchanged across the whole
window. `qbo_connection.updated_at` is in there because a QuickBooks token refresh is a write
nobody initiated and nothing on the screen shows; it is also why step 6 must not open a
QBO-connected screen.

Suspending is the better answer and is what rehearsal 2 should time. Say in the log which of
the two was done.

**Evidence:** both query outputs (zero rows each), the maintenance banner, the `meridian-api`
suspension time **or** the three timestamped quiet checks, and the logged phone call with a
name and a time.
**Rollback:** un-suspend `meridian-api`, maintenance mode off. Nothing has changed.

---

### 3. The final data load

This is `data-load.md` steps 1-7, run against **production** RDS, with two differences: the
source is frozen, so the parity numbers must be exact rather than "drifting as expected"; and
the dump you take here is kept.

```bash
# 3a. Final dump. This file is PHI. It is a WORKING COPY, not the archive —
#     see the note below before you file it anywhere. The flags are
#     scripts/staging_data_load.sh's, unchanged: --schema=public, because a
#     whole-database dump carries auth, storage and more, which the target lacks.
DUMP="$CUT/meridian-cutover-$(date +%Y%m%d-%H%M).dump"
pg_dump --schema=public --data-only --no-owner --no-privileges \
        --exclude-table=public.alembic_version \
        --exclude-table=public.trial_migrations \
        --exclude-table=public.qgenda_workspaces \
        -Fc -f "$DUMP" "$SUPABASE_DB_URL"
chmod 600 "$DUMP"
shasum -a 256 "$DUMP" | tee -a "$CUT/cutover.log"    # macOS: shasum, not sha256sum
```

3c restores **this** file (`"$DUMP"`), not a dated name typed by hand.

**This dump is a working copy, and it is destroyed at the end of the phase.** The plan used to
call it "the §6 long-term archive"; that is the **Phase 10** dump, taken at decommissioning,
which is the full schema plus `auth` and goes into an Object-Locked bucket with a named
custodian (`decommission-supabase-render.md` step 2). This one is `--data-only`, excludes
`qgenda_workspaces`, and exists to feed `pg_restore` in 3c and to be re-runnable if the load
aborts. **Shred it after the first close on AWS** — by then RDS has been backed up nightly for
weeks, the first period has tied out, and a stray `--data-only` dump of 17,606 patient
identifiers on an encrypted volume is a second copy of PHI that nothing needs. Record the
shred in the log with its date. There is **no custody table for this file**; custody text
belongs only on the Phase 10 archive, and duplicating it here is what made two different files
look like the same obligation.

Then, unchanged from `data-load.md`, with every parity run's JSON written where the evidence
table expects it:

| | `data-load.md` step | What it is | Command |
|---|---|---|---|
| 3b | 2 | Alembic to the load revision on the empty production database | `alembic upgrade 0003_rds_adaptations` |
| 3c | 3 | Restore, then `setval` every sequence | `pg_restore --data-only --disable-triggers` |
| 3d | 4 | The PHI split, one transaction | `python scripts/split_phi.py` |
| 3e | 5 | **The global pass; the only one that can see `null_org_rows`** | `python scripts/verify_parity.py --at 0003 --json > reports/parity-0003-$(date +%Y%m%d-%H%M).json` |
| 3f | 6 | 0004 RLS, then 0005 drops the identifier columns | `alembic upgrade head` |
| 3g | 7 | Per-org, summed | `python scripts/verify_parity.py --at head --json > reports/parity-head-$(date +%Y%m%d-%H%M).json` |
| 3h | — | **Backfill `run_inputs` (revision 0039): every earlier run's inputs, plus an exchange-rate history derived from the loaded payroll.** Dry run first (default; writes nothing, prints the counts), then `--apply`. Then re-run 3g: its `run_inputs_covered` rows (runs with params and no input row, per process) must be `0`. | `python scripts/backfill_run_inputs.py` then `python scripts/backfill_run_inputs.py --apply --derive-fx-from-payroll` (needs `MERIDIAN_DATABASE_URL`, the owner URL; prints counts only) |

3h is not a comparison with Supabase (`run_inputs` exists only on AWS) and is not part of the abort rule's
source/target diff; its only gate is `run_inputs_covered = 0`. It is idempotent (`ON CONFLICT DO NOTHING`),
so running it twice, or after the first live runs have written their own rows, inserts nothing twice.
Derived rates (`source = 'derived'`, no run) skip a payroll date whose pesos/dollars ratio is 1.0 or whose rows
look malformed; the skipped counts are printed.

`--json` is not a nicety: the table form is for reading on the day and the JSON is what the
evidence set keeps. It emits counts, sums, md5s and booleans — no row values — which is why it
is safe in the repository's `reports/` folder.

**Delta strategy: there is no delta.** This is a full dump of a frozen source into an empty
database, not an incremental top-up of the rehearsal's data. Drop whatever the rehearsal left
behind and start from 3b. An incremental load would have to reason about rows that changed
between two dumps, with no change-tracking column to reason from, and `pg_restore --data-only`
into a populated table fails on the primary key anyway. The rehearsals exist to make the full
load fast enough that a delta is never worth its risk.

**The abort rule is `data-load.md`'s, unchanged: any difference aborts.** Not "investigate and
continue". Drop the target, take maintenance mode off, and go home. Supabase is still
authoritative and nothing has been lost. Two specific ones to expect and not to argue with:

* `null_org_rows` non-zero on either side — fix it on the source and start again. From revision
  0004 a NULL-org row is invisible to every role for ever.
* 0005 raising *"N of M rows have a NULL patient_ref"* — the split did not run on this database.
  Nothing was dropped. Go back to 3d.

**Evidence:** both parity JSONs (`reports/parity-0003-*.json`, `reports/parity-head-*.json`) —
counts, sums, md5s and booleans only, no row values — the dump's sha256, and every step's
elapsed time in the timings table.
**Rollback:** `DROP DATABASE` on the target and redeploy it empty. It has never served a
request. Cost: nothing.

---

### 4. Storage: copy the objects, then prove each one is there

Supabase has **three** buckets and **every object in every one** comes across (T:249).
`templates` is empty. The other two hold three key shapes (inventory 2026-10-12, 158 objects):

| Supabase bucket | Key shape | Objects (2026-10-12) | Written by | S3 bucket |
|---|---|---|---|---|
| `outputs` | `{org}/{batch_id}/journal_entries/{file}` | 67 | tie-out publish (QB CSVs), `qb_usa_payroll_journal` | `artifacts` |
| `outputs` | `{org}/{batch_id}/reports\|bundle\|data/{file}` | 11 | review workbooks, bundles | `phi` |
| `outputs` | `{org}/{process}/{YYYY-MM-DD}/{output folder}/{subfolder}/{file}` | 16 (4 MX runs) | `persist_to_storage`, main v1.2.0 | `phi` |
| `uploads` | `{org}/{process}/{YYYY-MM-DD}/{file}` or `.../{run_id}/[adp/]{file}` | 64 (MX, QB USA) | `persist_to_storage`, main v1.2.0 — raw inputs | `phi` |

The S3 bucket is decided the way the AWS app decides it, so the app finds each object where it
looks: for `outputs`, `src/storage.bucket_for()` of the key's **third** segment (the rule
`S3StorageManager._subfolder_of` reads by) — `journal_entries` → `artifacts`, every other
subfolder → `phi`, and a third segment that is a *date* is an unknown subfolder, so the
`persist_to_storage` copies fail closed to `phi`. Everything from `uploads` (raw billing and
payroll exports) goes to `phi` whatever its key says.

**Keep the key exactly.** The key is the identity —
`artifact_id = 'a_' + sha256(path)[:12]`, so a renamed prefix is a broken artifact id, not a
moved file. Copy only what appeared since the last sync.

**What old runs can download on AWS.** Every link an old run shows on AWS is a
`{org}/{batch_id}/{subfolder}/{file}` key — the tie-out's and `qb_usa_payroll_journal`'s
`storage_path` (all 67 present in Supabase on 2026-10-12), the review workbooks and bundles the
QB USA screens list by prefix — and all of them land at that key in the bucket the app reads.
The date-layout copies are **retained, not linked**: the AWS run screens list a run's files from
`run_state.published_outputs`, which Render never wrote, so the 8 NetSuite JE CSVs of the four
Render-era MX runs (the other 8 objects there are byte-identical copies of tie-out CSVs that
*are* linked) have no download button on AWS. That is no regression — on Render the same
buttons read the task's disk, which every redeploy wiped — and the bytes are in `phi` at their
original key if anyone asks. The raw uploads are never linked by the app; they are kept for the
7-year re-prove rule (ADR 0020 §5b) and tagged for it in 4b.

**4a. Pull Supabase into the mirror.** There is no `supabase storage` CLI path this estate has
ever depended on, so the pull is a script that lists each bucket recursively (Supabase's
`list(prefix)` is non-recursive; the script descends every folder, at any depth). It writes
`$MIRROR/artifacts/<key>` and `$MIRROR/phi/<key>` — the first folder **is** the S3 bucket — and
stops before writing anything if two objects would land on the same S3 key. It is a **dry run
by default**, and the dry run ends with one count per key shape and destination: check those
against the table above before `--apply`.

```bash
# One mirror, kept between syncs (not per day): --since makes each pull incremental.
# A mirror made before T:249 (rooted at the org id) is refused: start a new directory.
MIRROR=/Volumes/MeridianPHI/Meridian/storage-mirror-v2

# What would be copied, and the per-shape counts. Writes nothing.
python3 scripts/mirror_supabase_storage.py --dest "$MIRROR" --since <last-sync-date>

# Then, for real. Every download is checked against Supabase's MD5 before it is written
# (a mismatch prints DOWNLOAD-MISMATCH, is not written, and exits 1 — re-run). This also
# writes "$MIRROR/.manifest.json" (source bucket, key, S3 bucket, size, MD5, SHA-256 of
# every object THIS run selected), which 4b and 4d read:
python3 scripts/mirror_supabase_storage.py --dest "$MIRROR" \
    --since <last-sync-date> --apply
```

The script refuses a `--dest` inside the repository, under `Downloads` or under `Desktop`: the
`phi` half of this tree is raw billing exports. `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` come
from the environment, never argv.

**4b. Push the mirror into the two buckets, then tag the raw uploads.** The split was made in
4a, so each sync is one folder to one bucket with no `--include`/`--exclude` filter to get wrong.
The `--sse-kms-key-id` must be the destination bucket's **own key ARN** — the bucket policy
denies a put that is not `aws:kms`, and one under any other key (an alias is not the ARN the
policy compares):

```bash
ART_KEY=$(aws kms describe-key --key-id alias/meridian-production-kms-artifacts \
  --query 'KeyMetadata.Arn' --output text)
PHI_KEY=$(aws kms describe-key --key-id alias/meridian-production-kms-phi \
  --query 'KeyMetadata.Arn' --output text)

aws s3 sync "$MIRROR/artifacts/" "s3://meridian-production-s3-artifacts/" \
    --sse aws:kms --sse-kms-key-id "$ART_KEY" --checksum-algorithm SHA256

aws s3 sync "$MIRROR/phi/" "s3://meridian-production-s3-phi/" \
    --sse aws:kms --sse-kms-key-id "$PHI_KEY" --checksum-algorithm SHA256
```

`--checksum-algorithm SHA256` is what makes 4d possible: an SSE-KMS object's ETag is **not**
the MD5 of its bytes, so the stored SHA-256 is the only content proof S3 hands back without a
download. (`.manifest.json` sits beside the two folders, so neither sync picks it up.)

The app tags every raw upload it stores (`src/process_inputs.py`, `RAW_UPLOAD_TAG`) so the
`phi` bucket's 7-year rule expires it; `aws s3 sync` cannot tag. Tag the objects that came from
Supabase's `uploads` bucket from the manifest (the 7 years then count from the copy, a few weeks
long — over-retention, not under):

```bash
python3 - "$MIRROR/.manifest.json" <<'PY' | tee -a "$CUT/cutover.log"
import json, subprocess, sys
n = bad = 0
for o in json.load(open(sys.argv[1])):
    if o['source_bucket'] != 'uploads':
        continue
    loc = ['--bucket','meridian-production-s3-phi','--key',o['key']]
    # Merge, never replace: put-object-tagging overwrites the whole set, and GuardDuty's
    # scan-result tag may already be on the object.
    n += 1
    got = subprocess.run(['aws','s3api','get-object-tagging',*loc,'--output','json'],
                         capture_output=True, text=True)
    if got.returncode:
        bad += 1
        print('TAG-FAILED phi', o['key'])
        continue
    tags = [t for t in json.loads(got.stdout)['TagSet'] if t['Key'] != 'meridian:content']
    tags.append({'Key': 'meridian:content', 'Value': 'raw-upload'})
    r = subprocess.run(['aws','s3api','put-object-tagging',*loc,
                        '--tagging',json.dumps({'TagSet': tags})],
                       capture_output=True, text=True)
    if r.returncode:
        bad += 1
        print('TAG-FAILED phi', o['key'])
print('tagged', n - bad, 'of', n, 'raw uploads')
PY
```

**4c. The `head_object` sweep.** Every non-null stored path in the database must resolve to an
object that exists. Read the paths out, and check each one:

```bash
psql "$RDS_URL" -At -c \
  "SELECT storage_path FROM qb_export_tie_out WHERE storage_path IS NOT NULL
   UNION ALL
   SELECT storage_path FROM qb_usa_payroll_journal WHERE storage_path IS NOT NULL" \
| while IFS= read -r key; do
    sub=$(printf '%s' "$key" | awk -F/ 'NF>=4{print $3}')
    case "$sub" in journal_entries) b=artifacts ;; *) b=phi ;; esac
    aws s3api head-object --bucket "meridian-production-s3-$b" --key "$key" \
      >/dev/null 2>&1 || echo "MISSING $b $key"
  done | tee -a "$CUT/cutover.log"
```

**4d. Content, not just presence (Codex PS-10)** — every object in the manifest, against the
SHA-256 S3 stored in 4b and the byte count. The bucket is the manifest's `dest`, the one 4a
decided, so this check cannot disagree with the sync about where an object went:

```bash
python3 - "$MIRROR/.manifest.json" <<'PY' | tee -a "$CUT/cutover.log"
import base64, json, subprocess, sys
objs = json.load(open(sys.argv[1]))
bad = 0
for o in objs:
    b = o['dest']
    r = subprocess.run(['aws','s3api','head-object','--bucket',f'meridian-production-s3-{b}',
                        '--key',o['key'],'--checksum-mode','ENABLED','--output','json'],
                       capture_output=True, text=True)
    want = base64.b64encode(bytes.fromhex(o['sha256'])).decode()
    head = json.loads(r.stdout) if r.returncode == 0 else {}
    if head.get('ChecksumSHA256') != want or head.get('ContentLength') != o['size']:
        bad += 1
        print('CONTENT-MISMATCH', b, o['key'])
print('checked', len(objs), 'manifest objects;', bad, 'mismatched')
PY
```

A `ChecksumSHA256` ending in `-<n>` is a multipart upload's checksum-of-parts and reads as a
mismatch; nothing live is near the CLI's 8 MB multipart threshold (largest object 0.6 MB on
2026-10-12), so if one appears, check that object by hand rather than trusting it.

**A single `DOWNLOAD-MISMATCH`, `TAG-FAILED`, `MISSING` or `CONTENT-MISMATCH` line stops the cutover.** The manifest check is
also the evidence the Phase 10 decommission leans on when it deletes the Supabase bytes. A path in the database with no object behind it
is a download button that 404s for a user, found by them instead of by you. Note that
`src/qb_export_artifacts.py` historically swallowed a failed put and recorded
`storage_path = None`, so this sweep proves the rows that *do* have a path; it cannot find an
artifact that was never recorded.

**`uniform_orders` is not in the sweep.** Revision 0037 drops the five Wearbly `uniform_*`
tables (owner's decision 2026-10-09, T:245, no export), so at head there is no table to read
and no path that could point at a missing object.

**Evidence:** 4a's per-shape counts (dry run and `--apply`), the sync output, the tagging line,
the sweep output with zero `MISSING` lines, 4d's `0 mismatched`, and the object count per bucket.
**Rollback:** the objects are additive and versioned; leaving them costs cents. Nothing to undo.

---

### 5. Deploy production on the new backends — still carrying no traffic

The three switches are already `postgres` / `s3` / `cognito` in `infra/meridian/stacks/compute.py`
as the task definition's environment; there is no dashboard to edit. Deploying the compute stack
at the cutover sha is what makes them live.

**Every `cdk deploy` in this runbook carries `--exclusively`, and that is not decoration.**
Without it CDK deploys the named stack *and everything it depends on* — for `compute` that is
`vpc`, `data` and, through the edge's imports, `edge`. Those stacks read context this command
does not pass (`hostedZoneId`, `cloudfrontPrefixListId`), so they would re-synthesize at their
defaults and the deploy would quietly delete the aliases or write the CloudFront prefix-list
placeholder into the ALB's security group. `--exclusively` means "this stack only"; its
dependencies must already be deployed, and at this point in the cutover they are.

**The one way `--exclusively` bites you** is a dependency that is *not* already deployed: the
stack synthesizes with an `Fn::ImportValue` nothing exports, CloudFormation fails the change set
with `No export named meridian-…` and rolls the deploy straight back. So before the first
exclusive deploy of the day, confirm each dependency exists and is settled —
`aws cloudformation describe-stacks --stack-name meridian-production-vpc
--query 'Stacks[0].StackStatus'`, and the same for `meridian-production-data`,
`meridian-production-edge` and `meridian-shared-dns`; each must read `CREATE_COMPLETE` or
`UPDATE_COMPLETE`.

```bash
npx cdk deploy meridian-production-compute --exclusively \
    -c env=production -c imageTag="<sha>" --require-approval never

aws ecs wait services-stable \
    --cluster meridian-production-ecs-main \
    --services meridian-production-ecs-svc-api meridian-production-ecs-svc-web
```

`services-stable` is the step that makes a bad deploy visible: CDK returns when the service
*update* is accepted, not when the new tasks are healthy. The circuit breaker rolls the service
back on its own; this wait is what reports it.

**`meridian-production-ecs-svc-api` runs `desiredCount: 1` until Phase 11**, with
`maximumPercent: 100` and `minimumHealthyPercent: 0`, so a deploy of **that service** stops the
only task before it starts the replacement: 3-6 minutes of hard downtime on the api. It costs
nothing today, because the new stack is not serving anyone yet. It is the reason a deploy after
the flip has to be scheduled and never run during a close.

`meridian-production-ecs-svc-web` is **not** under that constraint — it runs two tasks in
production and rolls normally. Every "downtime" and "desired count" statement in this runbook
and in the watch list below is about `svc-api` specifically; saying "the services" was what made
`desiredCount = 2` read like an aspiration instead of an alarm.

**Evidence:** `services-stable` returned 0; both target groups healthy; the task definition
revision number in the log.
**Rollback:** redeploy the previous task-definition revision. No user has touched this stack.

---

### 6. Smoke test — **read-only, and that is a rule, not a preference**

D-20 makes the point of no return "the first write of any kind on AWS". That is what makes the
rollback a clean DNS flip instead of an archaeology exercise, and it only stays true if this
step writes nothing.

**Not against `origin-production.meridiansgrp.com`.** That hostname is the ALB, and the ALB's
listener rules reject anything that does not carry the origin-verify header CloudFront adds —
so every request to it is a 403 and the smoke test proves nothing. It is also the wrong
hostname for sign-in: the Cognito app client's callback URL is the `app` one, so a browser
flow started anywhere else fails at the redirect.

**So go through the distribution on the app's own name — no pin needed** (ADR 0050).
`app.meridiansgrp.com` has resolved to this distribution since the edge was deployed with the
zone id, while the apex and `www` still resolve to Render. TLS SNI, `Host:` and the Cognito
callback all say `app`, CloudFront adds the origin-verify header, and the rest of the internet
still reaches Render at `www`.

```bash
# The distribution's own domain, from the edge stack's outputs.
CF_DOMAIN=$(aws cloudformation describe-stacks --stack-name meridian-production-edge \
  --query "Stacks[0].Outputs[?OutputKey=='DistributionDomainName'].OutputValue" --output text)

BASE=https://app.meridiansgrp.com
CURL="curl -sS"

# Prove the name reaches CloudFront, not Render, before trusting anything it returns.
dig +short app.meridiansgrp.com | head -3        # CloudFront addresses
dig +short "$CF_DOMAIN" | head -3                # the same set
$CURL -o /dev/null -w '%{http_code} %{remote_ip}\n' "$BASE/api/v1/health"
$CURL -sI "$BASE/" | grep -i '^x-cache\|^via'     # CloudFront's own headers
```

`app.` must answer with the distribution's addresses and never with `<render-hostname>`'s — a
smoke test against the old stack passes beautifully, so check that first.

**The browser checks (6a, 6c-6g)** are an ordinary browser on `https://app.meridiansgrp.com`.
No `/etc/hosts` entry, so nothing to forget to remove after a rollback.

| # | Check | Passes when |
|---|---|---|
| 6a | Sign in as each of the two workforce users | Cognito issues a token; MFA challenge answered |
| 6b | `GET $BASE/api/v2/me` | 200, correct `org_id`, correct permissions |
| 6c | Open a completed run from the list | The results screen renders with the same totals as Render shows for the same run |
| 6d | Download one artifact of each kind (a JE CSV from `artifacts`, a workbook from `phi`) | The bytes arrive; `Content-Disposition: attachment` |
| 6e | *(retired 2026-10-09: the in-app invoice feature was removed 2026-09-28; nothing to render)* | — |
| 6f | Open the config screens (mappings, settings, fiscal calendar) | They render from Postgres with the values Supabase holds |
| 6g | A cross-org read as one user against the other org's id | Zero rows / 404. RLS is on |

**Do not open a QuickBooks-connected screen.** Anything that reaches QBO refreshes the token and
**writes `public.qbo_connection`** — a new `access_token`, `access_expires_at` and `updated_at`,
via `save_connection()`'s upsert. That is a write nobody sees, it is not re-appliable to
Supabase, and on a rollback it leaves the *old* stack holding a refresh token QuickBooks has
already rotated away from, which is a broken QBO connection on the system you just rolled back
to. So: no QuickBooks card in Settings (`/settings#quickbooks`, which replaced `/qbo/connect`), no QBO posting screen, and 6c must open a **completed** run's results
rather than anything that re-contacts QuickBooks. If one is opened by accident, say so in the
log — the rollback then includes re-authorizing QuickBooks on Render.

**The deliberate writes, named as D-20 requires.** There is no `process_runs` heartbeat row; the
api writes nothing to `process_runs` on startup and `process_runs` has no `process_type` column
(it is `process`, and the CHECK constraint allows only `qb-revenue`, `mx-payroll` and
`qb-usa-payroll`). The claim was invented, and inventing an exception is worse than having one.

The real writes this smoke test makes are the **`public.artifact_downloads` rows from 6d**. One
row is written per signed URL minted (migration 022), so downloading one artifact of each kind
writes two rows, each carrying `org_id`, `user_id`, `user_email`, `ip` and `user_agent` — the
person doing the smoke test, not a customer.

> **On rollback, export those rows to `$CUT/cutover-smoke-downloads.csv` first (they are a
> record of a real PHI workbook being opened, operator or not — Codex PS-17), then delete
> exactly those rows and re-apply nothing to Supabase:**
> ```sql
> DELETE FROM public.artifact_downloads WHERE created_at > '<smoke start, UTC>';
> ```
> Write the smoke-test start time into the log **before** 6a, to the second, so that predicate
> has a value on the day. They record that the operator pressed download during a rehearsal;
> they are not a record of anything a user did, and re-creating them on Supabase would be
> falsifying an audit table.

Anything else that turns out to write — a session row, a last-seen timestamp — goes in this list
before the next rehearsal, not after. "Read-only" is a claim with a written exception list or it
is not a claim.

**Evidence:** each row above ticked in the log with a timestamp, the smoke-test start and end
times, the `/etc/hosts` pin added and removed times, and the `artifact_downloads` row count before
and after.
**Rollback:** none needed — you have not moved traffic. If anything above fails, go to step 3's
rollback: drop the database, maintenance off, and the day ends with Supabase authoritative.

---

## 🛑 STOP — ask Andres (gate 2: flip the DNS)

**This is the gate.** Everything before it is reversible by walking away; the next step is the
one the plan calls Point of No Return #1.

Tell him, in these terms:

> *"Parity is clean, the objects are all there, the new stack passes the read-only smoke test.
> The flip is two deploys with a three-to-five minute gap where the bare domain answers with
> nothing. Anyone who *asks* during that gap is told "no such name", and their resolver
> remembers that for another 60 seconds — 15 minutes if we skipped lowering the SOA. That
> part is unavoidable, and Render stays in maintenance either way. If I flip now,
> the next thing anyone saves goes to the new database. Until someone saves something I can put
> it back in about ten minutes plus the TTL. After that, putting it back means re-entering that
> person's work by hand. Flip?"*

Do not flip on silence, on a thumbs-up in passing, or on "sounds good" from a week ago. Get it
on the day, in words.

---

### 7. Flip DNS — **two deploys, in this order, with a dark window between them**

**This is not one command, and the reason is a Route 53 rule rather than a preference.** The
apex and `www` cannot be two things at once: Route 53 refuses a second A record set at the apex,
and a `www` CNAME cannot coexist with a `www` A/AAAA alias at all. The Render records live in
`meridian-shared-dns` (`infra/meridian/stacks/dns.py`, `ApexToRender` / `WwwToRender`) and the
CloudFront aliases live in `meridian-production-edge` behind `createDnsAliases`. Deploying edge
with the Render records still in place **fails the stack**, mid-cutover, at the worst moment.

They were not merged into one stack, and the reasoning is in `dns.py` next to
`RENDER_RECORDS_FLAG`: `EdgeStack` deliberately does not depend on `DnsStack` (it reads the zone
by `-c hostedZoneId` and creates *no* records without it), and `DnsStack` is the checked-in,
byte-for-byte copy of the GoDaddy zone that the nameserver switch rests on. So the sequence is
explicit instead.

**7a. Remove the Render records.**

```bash
npx cdk deploy meridian-shared-dns --exclusively \
    -c env=production \
    -c renderRecords=false \
    --require-approval never
```

Precondition: `npx cdk diff meridian-shared-dns -c env=production -c renderRecords=false` shows
**only two record sets being deleted** — the apex `A` and `www` `CNAME`. If it proposes to touch
the MX, the TXT/SPF, `_dmarc`, the Microsoft CNAMEs or the SRV records, **stop**: that is not
this flag, it is drift or an unrelated edit riding along, and it takes the company's mail down.

**7b. The dark window opens here.** Between 7a and 7c the apex and `www` have no record at all,
so a resolver with a cold cache gets NXDOMAIN. It is short and it is bounded:

* resolvers that already have the answer keep serving Render for up to **300 s** (`CUTOVER_TTL`),
  so most viewers see nothing;
* resolvers that do not, see NXDOMAIN until 7c finishes propagating — **budget 3-5 minutes**, and
  time it in rehearsal 2 rather than trusting that figure;
* **and that NXDOMAIN is itself cached, for longer than the window.** Negative caching is
  `min(SOA record TTL, SOA MINIMUM)` (RFC 2308 §5); on Route 53's defaults that is
  `min(900, 86400)` = **900 s, 15 minutes** — not 300 s, which is the *positive* TTL on the
  records and has nothing to do with it. A resolver that asks once at second 10 of the window
  keeps saying "no such name" for a quarter of an hour after 7c has finished. Precondition D
  lowers the SOA to 60/60 at least 24 hours earlier precisely so this reads **60 s**; if that
  step was skipped, say 15 minutes at gate 2 and mean it.

This is why 7c is typed and ready before 7a is run, and why the two are back to back.

Say this to Andres as part of gate 2, not as a surprise here. Run 7a and 7c back to back.

**7c. Create the CloudFront aliases.**

```bash
npx cdk deploy meridian-production-edge --exclusively \
    -c env=production \
    -c hostedZoneId="<zone-id>" \
    -c cloudfrontPrefixListId="<from precondition C>" \
    -c createDnsAliases=true \
    -c originVerifyActiveVersion="<from precondition C>" \
    -c originVerifyPreviousVersion="<from precondition C>" \
    -c originVerifyCloudFrontVersionId="<from precondition C>" \
    --require-approval never
```

**All four of those context values must be byte-identical to the last production edge deploy's** —
the three origin-verify ones and `cloudfrontPrefixListId`.
They are not decoration: `EdgeStack._origin_verify_versions` resolves the secret from them, and
omitting one changes which value CloudFront sends and which values the ALB accepts. Get that
wrong while the aliases go live and every request is a 403 — on the public hostname, with
traffic on it, with the Render records already gone.

Precondition, and it is a hard one: run

```bash
npx cdk diff meridian-production-edge -c env=production -c hostedZoneId="<zone-id>" \
    -c cloudfrontPrefixListId="pl-..." \
    -c createDnsAliases=true -c originVerifyActiveVersion="..." \
    -c originVerifyPreviousVersion="..." -c originVerifyCloudFrontVersionId="..."
```

and confirm it proposes **only the four new record sets** (A and AAAA for the apex, A and AAAA
for `www`). The `app` and `api` records already exist and must show **no** change. Any change to
the distribution, the host-router function, the listener rules, the WAF, the ALB security group
or the origin-verify header means one of the four values is wrong. Fix the values; do not deploy
through it.

Then watch it actually move:

```bash
NS=$(aws route53 get-hosted-zone --id "<zone-id>" \
       --query 'DelegationSet.NameServers[0]' --output text)
for n in meridiansgrp.com www.meridiansgrp.com app.meridiansgrp.com api.meridiansgrp.com; do
  echo "$n -> $(dig +short @"$NS" "$n" | tr '\n' ' ')"
done
```

All four must answer with the CloudFront distribution, not `<render-hostname>`. Then the
redirects (ADR 0050) — each line is one `curl -sI`, and the status and `location` are the check:

```bash
curl -sI https://meridiansgrp.com/pricing | grep -i '^HTTP\|^location'      # 301 -> https://www.meridiansgrp.com/pricing
curl -sI https://www.meridiansgrp.com/    | head -1                          # 200, the public website
curl -sI https://www.meridiansgrp.com/login | grep -i '^HTTP\|^location'    # 308 -> https://app.meridiansgrp.com/login
curl -sI https://app.meridiansgrp.com/    | grep -i '^HTTP\|^location'      # 302 -> /dashboard
curl -s  https://api.meridiansgrp.com/v3/health -o /dev/null -w '%{http_code}\n'  # the v3 liveness route, not 404
curl -s  https://api.meridiansgrp.com/login -o /dev/null -w '%{http_code}\n'      # 404
```

Confirm the apex and `www` are real aliases, not copies of an address:

```bash
aws route53 list-resource-record-sets --hosted-zone-id "<zone-id>" \
  --query "ResourceRecordSets[?Name=='meridiansgrp.com.'||Name=='www.meridiansgrp.com.'].\
{Name:Name,Type:Type,Alias:AliasTarget.DNSName}"
```

Four rows, each with an `Alias` ending `.cloudfront.net.`, and no `ResourceRecords`.

**Render stays in maintenance. Do not take it out.** The old draft said to lift maintenance
here, and that is backwards: a Render that is serving again is a Render that can take a write
against Supabase — from a bookmarked tab, a retried form, a resolver still holding the old
answer for the next 300 seconds — and that write lands in the database this cutover just forked
away from. **Taking Render out of maintenance is the FIRST act of a rollback, never a
housekeeping step after a successful flip.** It stays running, warm, paid and in maintenance
until Phase 10, months from now (step 9).

**Evidence:** the `dig` output before and after; the `AliasTarget` query above; the time of each
of 7a and 7c to the minute (the rollback matrix is measured from 7c); the dark window's measured
length; the first request id served by CloudFront; a line saying Render is still in maintenance.

**Rollback — in code, and in the reverse order:**

```bash
# 1. Remove the aliases.
npx cdk deploy meridian-production-edge --exclusively -c env=production \
    -c hostedZoneId="<zone-id>" \
    -c cloudfrontPrefixListId="pl-..." \
    -c createDnsAliases=false <the three originVerify values> --require-approval never

# 2. Re-add the Render records. `renderRecords` defaults to true, so this is the
#    plain deploy — no flag.
npx cdk deploy meridian-shared-dns --exclusively -c env=production --require-approval never

# 3. Take Render OUT of maintenance. This is what restores service.
```

Then 300 seconds of TTL. Note the asymmetry: step 3 is the one that matters to a user and it is
the fastest of the three, so **do it first if the site is down and the cause is unclear** —
maintenance off on Render costs nothing while the two deploys run.

**`app.` and `api.` do not roll back with the apex and `www`** (ADR 0050): they are not behind
`createDnsAliases` and keep pointing at the AWS stack. That is harmless only while nobody uses
them, and after a rollback somebody might — an invite e-mailed from AWS links to `app.`, and a
browser that followed the `www` → `app` 308 keeps it for up to an hour (every host redirect
carries `Cache-Control: max-age=3600` for exactly this). So as part of the rollback, put the
AWS api in maintenance (scale `meridian-production-ecs-svc-api` to 0) and tell the users in
words: "use www.meridiansgrp.com".

**The Route 53 console is not the rollback path, even though it is faster.** Setting the records
back by hand leaves both stacks believing something the zone does not, so the next `cdk deploy`
of either one silently re-applies the flip, and `scripts/dns_zone_diff.py` starts reporting a
difference nobody can explain. That is drift, and the cost of it is paid later by someone
without the context. If the console is genuinely used — a real outage, deploys failing, no time
— then it is an incident action: write it in the log, and the **first** thing done afterwards is
re-deploying both stacks with the flags that match reality.

---

### 8. Watch

**Put the SOA back — gated on the first human write, not on a clock.** Precondition D lowered the zone's SOA record TTL
and MINIMUM field to 60 to shrink the dark window. The window is over, and a 60 s MINIMUM left
in place sends every NXDOMAIN in the zone — typos, stale subdomains, scanners — back to the
Route 53 nameservers a hundred times more often than it needs to, forever. UPSERT the seven
fields recorded in precondition D, restoring the TTL to 900 and MINIMUM to 86400:

```bash
aws route53 change-resource-record-sets --hosted-zone-id "$ZONE" --change-batch '{
  "Comment": "post-cutover: restore default negative caching",
  "Changes": [{"Action": "UPSERT", "ResourceRecordSet": {
    "Name": "meridiansgrp.com.", "Type": "SOA", "TTL": 900,
    "ResourceRecords": [{"Value":
      "ns-<n>.awsdns-<nn>.com. awsdns-hostmaster.amazon.com. <serial> 7200 900 1209600 86400"}]
  }}]}'
dig +noall +answer @"$NS" meridiansgrp.com SOA   # expect 900 ... 1209600 86400
```

**Do not do this before the rollback window in the matrix below has closed** — a rollback
re-opens a dark window of its own, and it wants the 60 s value. The only trigger is the first
real write by a human on the new stack: until that has landed, a rollback is still on the table
and the short MINIMUM is still earning its keep. There is no deadline here — leaving the SOA at
60 for an extra day costs a little extra query volume, restoring it an hour too early costs a
slow rollback. It will never show up in `cdk diff`: the SOA is not
CDK-managed and `scripts/dns_zone_diff.py` ignores the type.

**First hour, at the keyboard.** `meridian-production-dashboard-golden-signals`: latency,
traffic, errors, saturation, the sign-in helper, backups, the security row, and every alarm's
state at the bottom. Plus:

| Watch | Where | Bad looks like |
|---|---|---|
| 5xx from the application | `meridian-production-alarm-target-5xx` | Any sustained non-zero. Infrastructure is fine and the code is not |
| Sign-ins | Cognito + the Lambda's `Invocations`/`Errors`/`Duration` | A password that worked on Render failing here |
| Database connections | RDS connection count vs the limit | Climbing and not falling — a leak under real traffic |
| `desiredCount` on `svc-api` | ECS | **2 is an alarm**, not good news: two api tasks can each pick up the same run. `svc-web` running 2 in production is correct and is not this row |
| Origin errors | CloudFront 502/504 | The origin-verify header or the ALB rules |
| Downloads | The artifact endpoints | 404 — an object the sweep in step 4 should have caught |

**First 24 hours.** Add: one real upload end to end; one real download by the other user; one
password reset; the nightly RDS backup ran; AWS Backup's copy landed; no alarm fired into an
unconfirmed SNS topic (`alerts.md` step 0 — if the subscription was never confirmed, the whole
watch list above is silent by construction).

**The first close on AWS.** This is the real test and it is weeks away. Before booking:
`sum(debit)`, `sum(credit)` for the new batch balance and match the run's own tie-out. After
booking: the QuickBooks/NetSuite import totals match **to the cent**; all 45 sequences advanced;
three JE lines spot-checked back to source transactions through `phi.transaction_identity`. Plan
§6 "Parallel run and reconciliation" is the authority; this runbook is not finished until that
close is.

**Evidence:** the hourly dashboard screenshots, the 24-hour checklist ticked, and the first
close's tie-out figures filed with the period.
**Rollback:** the matrix.

---

## Rollback matrix — what is reversible, and until when

Measured from the DNS flip (step 7). **The point of no return is not a clock, it is an event:
the first write on RDS by a human.** The hours below are what that event typically follows.

| When | What has happened | Rollback | Cost |
|---|---|---|---|
| Any time before step 7 | Data loaded, stack deployed, no traffic | Drop the RDS database, un-suspend `meridian-api`, maintenance off | Minutes. Nothing lost |
| Between 7a and 7c | The Render records are gone, the aliases do not exist, the bare domain answers with nothing | Re-deploy `meridian-shared-dns` with no flag (`renderRecords` defaults true), maintenance off | 3-5 min + the negative-cache TTL — **60 s** if precondition D lowered the SOA, **900 s** on Route 53's defaults. **Nothing lost** |
| 0 min – first write | DNS moved; only the smoke test's `artifact_downloads` rows written | Maintenance off on Render first; then `createDnsAliases=false`, then re-deploy `meridian-shared-dns`; then export and delete the smoke rows (step 6) | 10-15 min + 300 s TTL. **Nothing lost** |
| **The first write on RDS of any kind — Point of No Return #1** | Someone, or something, saved something. A background run that posted to QuickBooks counts exactly as much as a person (Codex PS-9) | Still possible, no longer clean | See the rows below |
| First write – 1 h | A handful of writes; probably config edits or one upload | **Freeze AWS first**: `aws ecs update-service --desired-count 0` on the api service so nothing on RDS moves while you look; **then** DNS back and Render out of maintenance; then the ledger, then re-apply by hand | An hour or two. **The ledger is `audit_log` (every insert/update/delete carries the actor and the row), `process_runs`, `import_batches` and `qb_export_tie_out` — read them by `created_at`/`updated_at` **and** by the S3 `ListObjectVersions` of both buckets since the flip, because `created_at` alone misses an update, a delete, a settings change and every object put.** Rehearsal 2 must have produced this ledger once, or the row is a hope |
| 1 h – 24 h | A working day's writes; possibly a booked batch | DNS back, then re-apply. For bookings, document the affected `import_batches.id` values and **re-enter each one** | Assume a day. Not during a close |
| 24 h – first close | Days of work on RDS | Technically the same procedure, practically a project | Days. At this point the honest answer is usually "fix forward" |
| After the first close on AWS | A period has been booked from RDS to NetSuite/QuickBooks | **Do not roll back.** Fix forward | Rolling back a booked period means re-booking it from the other database, which is two sources of truth for `import_batches.id` — exactly what migrations 024/026/028 were written to prevent |

**Two things are *not* rolled back by any row above**, because they were reversed earlier or are
reversed later:

* **Flip 1 (`AUTH_BACKEND=cognito`)** is independent and stays reversible on its own —
  `auth.users` is never mutated, Cognito users are copies. Its reversibility ends at the Phase
  10 cut-off (cutover + 60 days), not here.
* **Supabase and Render are untouched.** Step 9.

---

### 9. Leave Render and Supabase alone

**Render keeps running — not scaled to zero, not deleted — and stays in maintenance mode.**
Supabase stays live, paid and untouched. Both stay that way for **two full close cycles**, which
is roughly two to three months. They are the rollback.

Two things that sound contradictory and are not:

* `meridian-api` was **suspended** in step 2 so that no background thread could write during the
  dump. Un-suspend it now — a suspended service takes a cold start to come back, and the whole
  point of keeping Render is that the way back is minutes. It comes back **into maintenance
  mode**, serving the banner, with nothing reaching the application.
* **Maintenance mode stays on until somebody decides to roll back.** Render in maintenance is
  warm: the containers are up, the environment is intact, the database is attached, and turning
  it off is one toggle. That is a rollback you can reach in five minutes. Render *serving* is a
  second live system writing to a database that has been forked, which is not a rollback, it is
  a split brain.

So the state to leave at the end of the day is: **both services running, both in maintenance,
`meridian-api` un-suspended, Supabase live.** Write that sentence in the log.

Turning either of them off is Phase 10 and has its own runbook, its own gates and its own
stop-and-ask. Nothing in this runbook deletes anything.

**Evidence:** a line in the log saying both were left running, with the date the two-close clock
started.
**Rollback:** n/a.

---

## Evidence to keep from the day

| Artifact | Where it goes |
|---|---|
| The cutover log (one line per step, wall clock) | Encrypted volume, then `docs/reports/phase-9-report.md` in summary |
| `reports/parity-0003-*.json` and `reports/parity-head-*.json` | The repo's report folder — safe: counts, sums, md5s, no row values |
| The dump's sha256, its location, and the date it was shredded | The log. **Not the dump itself, and not its path in a commit** |
| The `artifact_downloads` count before and after the smoke test | The log |
| The two zero-row freeze queries, and the api suspension time | The log |
| The dark window's measured length between 7a and 7c | The phase report |
| The `head_object` sweep output | The log |
| `services-stable` result and the task-definition revision | The log |
| The smoke-test table, ticked, with times | The phase report |
| `dig` before and after; the flip time to the minute | The phase report |
| First-hour dashboard screenshots | Evidence set (they show no log bodies by construction) |
| The first close's tie-out figures | Filed with the period |
| Timings (below) | This file |

---

## Timings — fill this in

One row per execution. The rehearsal 2 row is what the real window is budgeted from.

| Date | Env | Rows (transactions / journal_entries) | 2 freeze | 3 load (total) | 4 storage | 5 deploy | 6 smoke | 7 DNS | Window total | Outcome |
|---|---|---|---|---|---|---|---|---|---|---|
| | staging (rehearsal 1) | | | | | | | | | |
| | staging (rehearsal 2, timed, no edits) | | | | | | | | | |
| | **production** | | | | | | | | | |

Record the parity JSONs alongside each row. A timing without its evidence is not a record of
anything.

---

## Open items

* ~~"`deploy.yml` green on production"~~ — **settled 2026-09-24 (T:124):** production is never
  deployed by the workflow, by decision, and precondition C says what "green" means instead.
  `infra/tests/test_workflows.py` fails if `deploy.yml` grows a production target without
  this runbook and the tracker being changed with it.
* ~~**The Phase 6 and Phase 7 reports do not exist yet**~~ — **settled 2026-09-24:** both
  exist, and precondition A's two rows were re-read against them.
* ~~**The rehearsal periods are still unnamed**~~ — **named 2026-10-12:** MX payroll FY26-P09
  (batch 91) and QB USA payroll FY26-P09 (batch 89), compared same-day (§B "Payroll JE
  comparison (rehearsal)"). **Revenue is still open:** no revenue input was ever stored, so
  there is no revenue JE comparison until Andres supplies the original billing exports for a
  closed period.
* **`process_runs` cannot see three run families, and it is three, not five.**
  `adp_payroll_session`/`adp_payroll_job_status`, `booking_payroll_*` and `adp_v3_job_status` are
  still module-level dicts in the api process (all three in `web_app.py`; line numbers move, so find them with `grep -n 'adp_payroll_job_status = \|booking_payroll_\|adp_v3_job_status = ' web_app.py`); the other four
  (`processing_status`, `payroll_processing_status`, `qb_usa_payroll_sessions`,
  `qb_usa_payroll_jobs`) are `RunStore` instances and are in `process_runs` already. Step 2's
  freeze proof is two queries plus a phone call for exactly this reason, and it stays that way
  until Phase 11 serializes the last three out of process memory. Anyone reading this after
  Phase 11 should delete the phone call and say so. `docs/aws-migration-plan.md` Phase 9 step 1
  and `infra/meridian/stacks/compute.py`'s module docstring both still say five — the docstring
  is a Phase 11 correction, not this runbook's.
* **The Jinja process wizards have no route on the public hostname at all.** `next.config.mjs`'s
  `jinja` array is empty and the ALB claims only `/api/*`, `/auth/*` and `/static/*` for the api
  container, so after the flip `/qb-revenue`, `/mx-payroll` and `/qb-usa-payroll` 404 through
  Next. They are reached through the React `processes/[process]` screens over `/api/v2`. If any
  of them is still needed as a Jinja screen, that is a `next.config.mjs` change plus a Route
  Handler plus a re-generated ALB rule set, and it is not something to discover on cutover day.
* ~~**`source_transactions` may still be in `public`**~~ — **no longer an open item but a
  precondition** (C, below; Codex PS-1). Cutting over with a second copy of the identifiers
  readable by `meridian_app` outside `src/phi.py` is cutting over without the quarantine the
  compliance rows describe.
* **The storage sweep proves paths, not completeness.** An artifact whose put failed before the
  `raise` landed has `storage_path = None` and no object; nothing in step 4 can find it. If a
  user reports a missing download after cutover, that is the first place to look.

## Related

`data-load.md` (steps 1-7, called by step 3) · `restore-drill.md` (the precondition and the way
back) · `db-access.md` (`psql` to a private RDS) · `migrations.md` (the chain) ·
`cognito-user-migration.md` (Flip 1, already done) · `dns-nameserver-switch.md` (the Route 53
move, Phase 1) · `alerts.md` (the watch list's alarms) · `docs/je-diff-procedure.md` (the JE
gate) · `decommission-supabase-render.md` (Phase 10, months after this).
