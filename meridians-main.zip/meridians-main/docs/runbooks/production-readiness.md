# Runbook — production readiness (the Phase 8 checklist)

**Status: written in Phase 8, never executed.** Every step below is a plan until the date
column in §13 is filled in. A runbook nobody has run is not evidence — see
`docs/runbooks/README.md`.

**Owner:** Andres Santos (security official). **Delivers:** `docs/aws-migration-plan.md`
Phase 8 ("Security hardening and compliance evidence") and its verify list.

---

## 0. What this is, and how to use it

Phase 8 is the phase that turns a working system into one somebody else can be shown. The
engineering is mostly done by then; what Phase 8 produces is **evidence** — a dated record,
for each control, that a person carried out a procedure and what came back.

Each section below has the same four parts, because the control matrix asks the same four
questions of every row:

| Part | Means |
|---|---|
| **What** | The control, in one sentence. |
| **How** | The exact commands or clicks. Copy them; do not improvise. |
| **Evidence to keep** | The artifact filed in the Evidence set. A screenshot is evidence; a memory is not. |
| **Who** | **Andres** (a person must decide, sign, buy or click) or **Claude (Phase N)** (engineering). |

**Where evidence goes.** The Evidence set is a dated folder *outside this repository*, at
`~/Business/Meridians Logic/Company/Compliance/` (control matrix §"Evidence-location
shorthand"). Nothing in this repository ever holds a screenshot of an account, an ARN, an
account id or a finding that names a resource by identifier (ADR 0001). This file holds the
procedure; the folder holds the output.

**A step that cannot be done yet is not a step you skip.** Most of Phase 8 needs a deployed
account, and nothing is deployed until the cost approval exists. §12 lists exactly which
steps are deploy-time only, so that "not done" and "cannot be done yet" never look alike.

---

## 1. The Phase 8 checklist

The plan's Phase 8 steps, in the order they can actually be carried out. **Deploy?** = this
step needs a deployed AWS account and therefore cannot be done before the cost approval and
the foundation deploy.

| # | Step | Section | Who | Deploy? |
|---|---|---|---|---|
| 1 | Control matrix complete — every row points at an artifact that exists | `docs/compliance/control-matrix.md` | Andres + Claude | partly |
| 2 | Threat model refreshed for every surface added since Phase 0 | `docs/compliance/threat-model.md` §13 | Claude (Phase 8) | no |
| 3 | `cdk diff` runs in CI against the real account | §2 | Andres (sets the variable) | yes |
| 4 | Security Hub at zero unresolved HIGH/CRITICAL | §3 | Andres | yes |
| 5 | Config HIPAA conformance pack compliant, every exception argued | §4 | Andres | yes |
| 6 | GuardDuty and Inspector findings triaged to zero unresolved high | §5 | Andres | yes |
| 7 | ZAP dynamic scan against staging, clean | §6.4 | Andres | yes |
| 8 | Restore drill against a production-shaped snapshot, timed | §7 | Andres | yes |
| 9 | DR test — `data` stack from the cross-region copy into `us-west-2`, counts verified | §7.3 | Andres | yes |
| 10 | Every secret rotated once, through the runbook | §8 | Andres | yes |
| 11 | Backup vault lock verified (a delete is refused) | §9 | Andres | yes |
| 12 | In-transit encryption position paper (the ALB → task hop) | §10 | Andres (writes) | no |
| 13 | Pen-test prep package: scope, accounts, sandbox creds, diagram | §6 | Andres + Claude | partly |
| 14 | `needs-a-human` list consolidated, with an owner and a status each | §13 | Claude (Phase 8) | no |
| 15 | Production `vpc`, `data`, `auth`, `compute`, `api`, `observability` deployed with synthetic data | §11 | Andres | yes |
| 16 | The bill matches the Phase 1 estimate | §11.3 | Andres | yes |

---

## 2. The read-only `cdk diff` in CI

**What.** CI tells you that a pull request *synthesizes*. It could not tell you that the
pull request changes something **deployed** — the tracker row for that has been open since
Phase 2. Phase 8 closes it with a read-only identity.

**How.**

1. Deploy `meridian-shared-foundation` (it now creates `meridian-shared-iam-github-diff`).
2. Read the ARN and set it as a **repository variable**, not a secret:

   ```bash
   aws iam get-role --role-name meridian-shared-iam-github-diff \
     --query Role.Arn --output text
   ```

   GitHub → Settings → Secrets and variables → Actions → **Variables** →
   `AWS_DIFF_ROLE_ARN`. A variable, not a secret, for the same reason as the four in
   `deploy-staging.md` §1c: an ARN is an identifier, not a credential, and a masked value
   turns the diff log into something nobody can read.
3. Merge anything that touches `infra/` to `aws-migration` or `main`. The `infra-diff` job
   should run on that **push** and print a diff. Until the variable is set the job **skips**,
   and CI stays green — that is deliberate, and it is the only tolerated way for this job not
   to run.

   **It does not run on a pull request, and that is on purpose** (P8-03). `cdk diff` renders
   the branch's own Python on the runner with these credentials, and the lookup role it
   assumes is `ReadOnlyAccess` over the whole account — log content, Cognito user lists, RDS
   and secret metadata, every non-CMK S3 object. Giving that to pre-review code was the wrong
   trade. So the diff answers "what did this merge change" rather than "should we merge
   this"; if you want the second answer before merging, run `cdk diff` locally.

**What the role may do, and why that is the whole of it.** It may assume exactly one
bootstrap role, `cdk-hnb659fds-lookup-role`; read `meridian-*` stack templates
(`DescribeStacks`, `ListStackResources`, `GetTemplate`); and read the bootstrap version
parameter. It may **not** assume `cdk-…-deploy-role`, which is the one that passes an
`AdministratorAccess` execution role. Six tests in `infra/tests/test_foundation.py` assert
this from six directions, including "no write verb appears in any action".

**Two things that claim depends on, both easy to break.**

* **`--method=template` in the workflow** (P8-04). `cdk diff` defaults to
  `--method=auto`, which computes the diff by asking CloudFormation to CREATE A CHANGE
  SET — that needs `cloudformation:CreateChangeSet` and it assumes the **deploy** role. With
  the default, "only the lookup role is assumed" is false and the job degrades to a warning.
  If you ever see `CreateChangeSet` in an `AccessDenied` from this job, the flag has been
  dropped, not the permission forgotten.
* **The lookup role is `ReadOnlyAccess`, which is not nothing.** `cdk bootstrap` creates it
  with the AWS-managed read-only policy plus a deny on `kms:Decrypt`. That is account-wide
  read: CloudWatch Logs content, `cognito-idp:ListUsers`, `rds:Describe*`, secret names and
  metadata (not values), and every S3 object not under a CMK. The `kms:Decrypt` deny is what
  keeps the `phi` and `artifacts` buckets out of reach. This is why the job runs only on
  post-review pushes — see step 3 above and threat model §13.7.5.

**A known noise source, and what actually gates the job.** The job does not pass
`cloudfrontPrefixListId` or `hostedZoneId` (identifiers, ADR 0001), so `meridian-staging-vpc`
and `meridian-staging-edge` diff against their synth placeholders and show a change on
**every single run**. That noise is permanent until the tracker row is closed, and a job that
is always noisy is a job nobody reads — so the gate is not a person reading the log. It is
the **`No destructive change to a stateful resource`** step (P8-05): a grep over the diff
output that fails the job when a line removing (`[-]`) or replacing something names
`AWS::RDS::`, `AWS::KMS::`, `AWS::S3::Bucket`, `AWS::Cognito::UserPool` or
`AWS::Backup::BackupVault`. If that step goes red, **do not re-run it**: read the named
lines, and if the change is intended, deploy it by hand with §11 open.

**Evidence to keep.** A link to one `infra-diff` run showing a real diff, and one showing
none. **Who:** Andres sets the variable; the role and the job are code.

---

## 3. Security Hub — the score, and the triage

**What.** Three standards are enabled by `infra/meridian/stacks/foundation.py`
(`SECURITY_HUB_STANDARDS`): AWS Foundational Security Best Practices v1.0.0, NIST SP 800-53
Rev 5, and — added in Phase 8 — CIS AWS Foundations Benchmark **v3.0.0**. Default standards
are off; the set is chosen explicitly so that what is assessed is a decision, not a default.

There is **no HIPAA standard in Security Hub.** HIPAA is the AWS Config conformance pack in
§4. NIST 800-53 Rev 5 is the Security Hub standard a HIPAA assessment maps onto and stands
in for it; say that, rather than implying a HIPAA score exists.

**The target.**

| Standard | Target at the Phase 8 gate | Hard gate |
|---|---|---|
| FSBP | ≥ 90 % and **zero** unresolved CRITICAL or HIGH | Yes |
| CIS v3.0.0 | ≥ 90 % and **zero** unresolved CRITICAL or HIGH | Yes |
| NIST 800-53 Rev 5 | Score recorded, no target | No — it is the broadest set and its MEDIUMs are a reading list, not a gate |

A percentage on its own is not the gate. **Zero unresolved CRITICAL/HIGH is the gate**, and
"unresolved" has a precise meaning below: a finding is resolved when it is fixed, or when it
is suppressed with a written reason.

**How.**

```bash
# The score per standard.
aws securityhub get-enabled-standards \
  --query 'StandardsSubscriptions[].{arn:StandardsArn,status:StandardsStatus}'

# Every ACTIVE finding at HIGH or CRITICAL that nobody has suppressed, newest first.
aws securityhub get-findings \
  --filters '{"SeverityLabel":[{"Value":"CRITICAL","Comparison":"EQUALS"},
                               {"Value":"HIGH","Comparison":"EQUALS"}],
              "RecordState":[{"Value":"ACTIVE","Comparison":"EQUALS"}],
              "WorkflowStatus":[{"Value":"NEW","Comparison":"EQUALS"},
                                {"Value":"NOTIFIED","Comparison":"EQUALS"}]}' \
  --query 'Findings[].{title:Title,sev:Severity.Label,res:Resources[0].Id}' \
  --output table
```

**The triage procedure.** Each finding gets exactly one of three outcomes, and a dated line
in the triage log either way:

1. **Fix it in CDK.** The default. Nothing is clicked in the console (ADR 0006), so the fix
   is a commit to `infra/` and a deploy. Re-run the finding check after the deploy; a
   Security Hub control re-evaluates within 12 hours, or immediately via the control's
   "Re-evaluate" action.
2. **Suppress it, with a reason.** Set the workflow status to `SUPPRESSED` **and** write the
   reason in the triage log. A suppression with no written reason is the finding an auditor
   picks first.

   ```bash
   aws securityhub batch-update-findings \
     --finding-identifiers Id=<id>,ProductArn=<arn> \
     --workflow Status=SUPPRESSED \
     --note 'Text=<why, in a sentence>,UpdatedBy=andres'
   ```
3. **Accept it as a risk.** Only when it cannot be fixed and should not be hidden — it then
   becomes a row in `docs/migration-tracker.md` with an owner and a deadline, and a line in
   the risk register (Track C item 7). Set the workflow status to `NOTIFIED`, not
   `SUPPRESSED`: the difference is whether the finding keeps asking.

**Known findings to expect, so they are not a surprise.** A single-AZ RDS instance
(deliberate — ADR 0007), an ALB → target listener on HTTP inside the VPC (deliberate, and
the subject of the position paper in §10), and controls about resources owned by the other
account occupant (ADR 0001) which are not Meridian's to fix and are suppressed with that
reason.

**Evidence to keep.** The score per standard on the gate date; the exported finding list;
the triage log with one line per finding. **Who:** Andres.

---

## 4. AWS Config — the HIPAA conformance pack

**What.** `Operational-Best-Practices-for-HIPAA-Security` — about 130 AWS-authored rules,
vendored at `infra/conformance-packs/` and deployed as a CDK asset, so the control set that
deploys is the one in this repository and `cdk diff` sees it change.

**The target.** Every rule `COMPLIANT`, or `NON_COMPLIANT` with an argued exception in the
control matrix. Unlike Security Hub there is no percentage to quote: the pack is a list and
the gate is that every entry on it has been read once.

**How.**

```bash
aws configservice describe-conformance-pack-compliance \
  --conformance-pack-name Operational-Best-Practices-for-HIPAA-Security \
  --query 'ConformancePackRuleComplianceList[?ComplianceType==`NON_COMPLIANT`].ConfigRuleName' \
  --output table

# For one rule, which resources fail it:
aws configservice get-conformance-pack-compliance-details \
  --conformance-pack-name Operational-Best-Practices-for-HIPAA-Security \
  --filters ConfigRuleNames=<rule>,ComplianceType=NON_COMPLIANT
```

**Triage.** Same three outcomes as §3. Two extra notes specific to Config:

- The recorder runs with `AllSupported: true`, so it records the **other owner's** resources
  too (ADR 0001, and the cost line the Phase 1 estimate says to watch). Their resources
  failing a Meridian rule is expected; it is an exception with a reason, not a fix.
- A rule that is `INSUFFICIENT_DATA` is not a pass. It usually means the resource type does
  not exist in the account yet — true for most of the pack until production deploys.

**Evidence to keep.** The `NON_COMPLIANT` list on the gate date, and the argued exception
for each. **Who:** Andres.

---

## 5. GuardDuty and Inspector

**What.** GuardDuty watches behaviour (CloudTrail, VPC flow logs, DNS, and — the one extra
feature bought — S3 data events against the `phi` bucket). Inspector watches software: ECR
images **and, since Phase 8, Lambda functions**, which matters because the Cognito User
Migration Lambda sees a migrating user's password once.

**The target.** Zero unresolved HIGH or CRITICAL in either, on the gate date.

**How.**

```bash
# GuardDuty: HIGH and above (GuardDuty severity is numeric; 7.0+ is High).
DETECTOR=$(aws guardduty list-detectors --query 'DetectorIds[0]' --output text)
aws guardduty list-findings --detector-id "$DETECTOR" \
  --finding-criteria '{"Criterion":{"severity":{"Gte":7},"service.archived":{"Eq":["false"]}}}'
aws guardduty get-findings --detector-id "$DETECTOR" --finding-ids <ids> \
  --query 'Findings[].{type:Type,sev:Severity,res:Resource.ResourceType}'

# Inspector: both resource types, active only.
aws inspector2 list-findings \
  --filter-criteria '{"severity":[{"comparison":"EQUALS","value":"HIGH"},
                                  {"comparison":"EQUALS","value":"CRITICAL"}],
                      "findingStatus":[{"comparison":"EQUALS","value":"ACTIVE"}]}' \
  --query 'findings[].{sev:severity,title:title,type:resources[0].type}' --output table

# Inspector must be on for BOTH types — if `lambda` is not `ENABLED`, the custom
# resource in foundation.py did not run with LAMBDA in resourceTypes.
aws inspector2 batch-get-account-status --query 'accounts[0].resourceState'
```

**Triage.**

- **GuardDuty.** Every finding is about behaviour, so the first question is always "was that
  us?". If it was, archive it with a note (a break-glass drill and a restore drill both
  generate findings; so does the first `deploy.yml` dispatch). If it was not, it is an
  incident and `docs/runbooks/incident-response.md` takes over — do not archive it.
- **Inspector.** An image finding is fixed by rebuilding the image on a newer base and
  redeploying, not by suppressing. Trivy already fails the build on HIGH/CRITICAL *before*
  the push (`deploy.yml`), so an Inspector ECR finding on a deployed image means an advisory
  published after the build — which is exactly the case Inspector exists for. A Lambda
  finding on a CDK helper function is fixed by upgrading the CDK version.

**Evidence to keep.** Both finding lists on the gate date, the archive/fix note per finding,
and the `resourceState` output proving ECR **and** Lambda scanning are on. **Who:** Andres.

---

## 6. The penetration test

The test itself is bought, not built — it is `needs-a-human` item 16 in the control matrix.
Phase 8 produces the **prep package** so that the engagement can start the day it is funded.

### 6.1 Scope — what the tester is pointed at

| In scope | Out of scope |
|---|---|
| `https://staging-app.meridiansgrp.com` and `https://staging-api.meridiansgrp.com/v3` (ADR 0050) — the whole surface: CloudFront and its host router, WAF, ALB, the Next.js app and the FastAPI API | Production, until the staging findings are closed |
| `/api/v2/*` (FastAPI) **and** the paths still served by Flask through the WSGI mount | AWS's own infrastructure (covered by the AWS BAA and AWS's own testing) |
| Authentication: Cognito hosted sign-in, the session cookie, MFA enrolment, the invite flow | The other account occupant's resources (ADR 0001) — explicitly named as off-limits |
| Tenant isolation: two organizations, two users, the cross-org probe | Social engineering of the two workforce members |
| File upload and artifact download, including the presigned URL path | Physical testing (there is no facility) |
| The QBO integration's callback and webhook paths | Denial-of-service testing — WAF and Shield are in the path and a real flood is billable |

**Accounts to provide:** two ordinary users in two different organizations, one admin in
one of them, and one machine client with no `phi:read` scope. **No account with a PHI scope
is issued to a tester until a BAA with the testing firm is signed** — the tester is a
business associate the moment they can read PHI.

**Data:** staging carries synthetic data only. If a finding needs PHI-shaped data, it is
synthetic PHI-shaped data, generated for the engagement, never a copy of production.

**Architecture diagram to hand over:** `docs/compliance/data-flows.md` plus the plan's §2.5
diagram. Redact the account id (ADR 0001) — a tester needs the shape, not the identifier.

### 6.2 The OWASP ASVS checklist for the FastAPI surface

**ASVS** is the OWASP *Application Security Verification Standard*: a numbered list of
things an application must be shown to do, rather than a list of attacks. These are the
Level 2 items that apply to `api/` (ASVS v4.0.3 numbering), each with how to verify it here.
This is what the tester is asked to confirm, and what §6.3's tests assert in CI.

| ASVS | Requirement | How it is verified here | Today |
|---|---|---|---|
| 2.1 / 2.2 | Password policy and rate-limited authentication | Cognito pool policy (12 chars, all four classes); `api.deps.RateLimiter` on the credential paths; WAF rate-based rule | code (Phase 4/5a) |
| 3.2 | Session token is generated by the framework, not the application | Cognito issues; `src/auth.py` verifies against the cached JWKS and never mints | code |
| 3.4 | Session cookie is `Secure`, `HttpOnly`, `SameSite` | ADR 0021; **to be created at** `tests/security/test_session_cookie_flags.py` | **not yet evidenced** — the test is named, not written |
| 3.5 | No session identifier in a URL | Cookies and `Authorization` only; `scripts/lint_no_phi_logging.py` catches the log half | code |
| 4.1 | Access control enforced at a trusted layer, not in the browser | One dependency (`api/deps.py`), never ad hoc per handler; RLS underneath it | code |
| 4.2 | Object-level authorization on every id in a path | `org_id` predicate **and** RLS (ADR 0011); a cross-org read returns `404`, never `403` | code; the cross-org proof is the pen test's |
| 4.3 | Administrative interfaces need additional authorization | `require_role('admin')`; superadmin only through `src/pg.with_superadmin(user_id, reason)`, which writes an audit row | code |
| 5.1 | Input validation is positive (allowlist), not negative | pydantic models reject unknown fields; `RAW_ALLOWED_HEADERS` is an allowlist by construction | code |
| 5.3 | Output encoding / no injection | psycopg2 parameter binding everywhere; React escapes by default | code |
| 8.3 | Sensitive data is not sent in URL parameters or logged | The PHI-logging lint in CI and pre-commit; presigned URLs with opaque keys | code (source-side only — gap G-7) |
| 12.1 / 12.2 | Upload size and type limits; uploaded files are not trusted | `MAX_CONTENT_LENGTH` → `413`; presigned URLs with size and type limits; GuardDuty Malware Protection tags the object | **partly** — nothing reads the malware tag yet (tracker row) |
| 13.2 | The API rejects an unexpected HTTP method properly | Known gap: a wrong method on a ported path answers `404`, not `405` (tracker row) | **not yet evidenced** |
| 14.4 | Security headers on every response, strict CORS allowlist | Phase 12 step 8; **to be created at** `tests/security/test_security_headers.py` | **not yet evidenced** |
| — *(CSRF, not an ASVS row of its own at L2)* | State-changing requests require a token the attacker cannot read | Double-submit: `XSRF-TOKEN` cookie compared against the header (ADR 0023). Bearer-authenticated calls are exempt **because a cookie is not what authenticated them** | code |
| — *(RLS proof)* | Tenant isolation holds at the database, not only in the application | Two sessions, two organizations, the same query: `tests/test_run_isolation.py` and `tests/test_pnl_rls_pg.py`, plus the pen tester's own attempt | code; the *independent* proof is the pen test's |

**The RLS proof is the one to insist on.** Application-layer isolation can be argued from
code; RLS can only be *shown*. Ask the tester to demonstrate, with a real session, that
setting `app.org_id` to another organization's id under `meridian_app` returns nothing —
and that they cannot set it at all through the API.

### 6.3 What is fixed before the tester arrives

Everything in the table above marked **not yet evidenced** has a test named but not written.
Those tests are Phase 12's `tests/security/` suite, and Phase 12's exit criterion is that
each one has a known-bad control test that fails. A pen test run before them buys findings
that were already on the list.

### 6.4 The ZAP baseline scan (free, deploy-time)

An OWASP ZAP baseline scan against staging is not a pen test, but it is the part that costs
nothing and can be repeated. It is **not "run now"** — the earlier heading said so and §12
lists it as blocked on a running staging URL, which is the true one (P8-08). It is free and
it waits, like everything else in §12.

When staging is up: run it against `https://staging-app.meridiansgrp.com` with an authenticated
context, and keep the report. **Target: no HIGH alerts.** MEDIUMs are triaged into the
tracker.

**Evidence to keep.** The scope document, the ZAP report, the tester's report when it exists,
and the fix-verify record for each finding. **Who:** Andres (buys and scopes); Claude
(Phase 12) writes the tests.

---

## 7. Restore and DR drills

### 7.1 The cadence — D-14

`docs/runbooks/restore-drill.md` is the procedure. **It is run every phase from Phase 3
onward that touches data** — that is the D-14 commitment, and the reason it is per-phase is
that a yearly drill proves the backups worked once a year.

| Phase | Drill owed | Why that phase |
|---|---|---|
| 3 | PITR restore to a scratch instance, timed | The first data lands in RDS |
| 4 | PITR restore | The auth stack changes what a restored database must contain |
| 5a/5b | PITR restore | The repository layer and the ported API are what read it back |
| 6 | PITR restore | The backup-failure alarm has to have something to be right about |
| 7 | PITR restore | Smallest phase; the drill is the point of the cadence, not the phase |
| **8** | **Vault restore (35-day locked vault) + the full cross-region DR test** | This is the number the contingency plan carries |
| 9 | PITR restore **against production RDS**, before cutover | A Phase 9 precondition in the plan |
| 10-12 | PITR restore per phase that touches data | Unchanged |

**The log table is in `restore-drill.md` §7, not here.** One table, one place. It is the
compliance evidence for 164.308(a)(7)(ii)(D) and the source of the RTO figure, so it must
not exist in two files that can disagree. Append a row there after every drill:

| Date | Phase | Path (PITR / vault) | Restore minutes | Verify minutes | Total | Result | Findings |

**Pass** is defined in `restore-drill.md` §3: under 8 business hours end to end, identical
row counts, `sum(debit)`/`sum(credit)` identical to the cent, one journal entry traced back
to its source, and `pgaudit` / `rds.force_ssl` / the two roles / RLS all present.

### 7.2 The Phase 8 restore drill specifically

It differs from the per-phase drill in two ways: it restores from the **35-day locked vault**
rather than the 7-day PITR window, and it uses a **production-shaped snapshot** — the same
row counts and object counts as production, not staging's handful. Both differences exist
because the contingency plan's number has to be about the real thing.

### 7.3 The DR test (cross-region)

`restore-drill.md` §4 scopes it: restore `meridian-<env>-backup-dr` in `us-west-2` into a VPC
there and verify counts. There is no VPC, no subnet group and no ops instance in `us-west-2`,
so **building those is part of the measured time** — that is the honest number for a region
loss, and it is what makes this a bigger exercise than the per-phase drill.

**The gate:** total elapsed **≤ 8 business hours** (RTO, ADR 0007) and data loss **no older
than the newest cross-region copy** — ≈ 24-30 h with the daily copy, ≤ 1 hour only if the
cross-region replica in §13 row 44 is funded (RPO; ADR 0007 as amended 2026-09-16, Codex G-H1). If either is missed, the contingency plan carries the measured number and ADR 0007 is
revisited — the plan states what is true, not what was hoped.

**Evidence to keep.** The appended row in `restore-drill.md` §7 for each drill; for the DR
test, additionally the count comparison and the elapsed-time breakdown, filed in the Evidence
set. **Who:** Andres.

---

## 8. Secrets rotation evidence

**What.** Every secret rotated **once**, through `docs/runbooks/rotate-secrets.md` and
`docs/runbooks/rotate-origin-verify-secret.md`, so that the procedure is evidence rather than
a draft. The point is not that the old values were compromised; it is that the rotation
works and somebody has done it.

**How.** Follow each runbook literally, in this order (it is the order of blast radius,
smallest first):

| # | Secret | Runbook | Watch for |
|---|---|---|---|
| 1 | `…-secret-origin-verify` | `rotate-origin-verify-secret.md` | The two-step deploy. Skipping it drops every request at the ALB |
| 2 | `…-secret-db-app` (`meridian_app`) | `rotate-secrets.md` §2 | The JSON shape the stack generated must be preserved |
| 3 | `…-secret-db-phi` (`phi_access`) | `rotate-secrets.md` §3 | Same |
| 4 | RDS-managed master password | `rotate-secrets.md` §5 | RDS rotates it; you are verifying, not generating |
| 5 | **The PHI HMAC key** | `rotate-secrets.md` §4 — **read it first** | **Do not rotate it.** Rotating it re-keys every `patient_ref` and orphans every existing row. §4 has the re-keying plan; without that plan this one is a documented exception, not a rotation |

**Evidence to keep.** `rotate-secrets.md` §7's record table, a row per rotation, plus the
written exception for the HMAC key. **Who:** Andres.

---

## 9. Backup vault lock verification

**What.** The AWS Backup vault is **compliance-locked** (ADR 0020 §7): a recovery point
cannot be deleted before it expires, by anyone, including the account root. That property is
only evidence if somebody has tried.

**How.** Try to delete one recovery point and keep the refusal.

```bash
aws backup list-recovery-points-by-backup-vault \
  --backup-vault-name meridian-staging-backup \
  --query 'RecoveryPoints[0].RecoveryPointArn' --output text

aws backup delete-recovery-point \
  --backup-vault-name meridian-staging-backup \
  --recovery-point-arn <arn>
# EXPECTED: an error. "Vault lock is in effect" is the control working.

# And the lock's own configuration — min/max retention and whether the
# changeable window has closed.
aws backup describe-backup-vault --backup-vault-name meridian-staging-backup \
  --query '{lock:Locked,min:MinRetentionDays,max:MaxRetentionDays,until:LockDate}'
```

`Locked: true` with the changeable window expired is the state that matters: before that
date the lock can still be removed, so the control is not yet what it claims.

**Also verify the cross-region copy exists**, because a locked vault in one region is not a
DR control:

```bash
aws backup list-recovery-points-by-backup-vault \
  --backup-vault-name meridian-staging-backup-dr --region us-west-2 \
  --query 'length(RecoveryPoints)'
```

**Evidence to keep.** The refusal message, the `describe-backup-vault` output, and the
cross-region count. **Who:** Andres.

---

## 10. The in-transit encryption position paper

**What.** Browser → CloudFront → ALB is TLS. api → RDS is TLS-forced. api → S3/SES/Cognito
is TLS. **The ALB → ECS task hop is plaintext HTTP inside the VPC.** Encryption in transit
is an *addressable* specification under 45 CFR 164.312(e)(2)(ii) — addressable means
"implement it, or document why not and what you do instead", not "optional".

**What the paper must say**, in one page: the hop; that it is inside a VPC with no internet
gateway on the private subnets and a security group that admits only the ALB; that VPC
traffic between instances in the same VPC is encrypted at the physical layer by AWS's Nitro
system for supported instance types, and whether Fargate's are; the alternative considered
(TLS to the task, a certificate per task, and what it costs to operate); and the decision
with a trigger to revisit — a PHI-scoped external partner is the obvious one.

**Evidence to keep.** The paper, dated and signed, in the Evidence set; it is the evidence
cell of control-matrix row 312(e)(2)(ii). **Who:** Andres writes it; it is not engineering.

**Status 2026-09-24: a DRAFT exists** at `docs/compliance/in-transit-encryption.md`, written
from the CDK code with every claim cited, and two statements about AWS's own platform marked
**VERIFY** (whether Fargate traffic gets Nitro in-VPC encryption; whether an HTTPS target group
with a self-signed task certificate was considered). Andres checks those two against AWS's
documentation, corrects the rest, and signs; until then it is not evidence.

---

## 11. Production deploy, DNS and TLS

### 11.1 `deploy.yml` first-dispatch preconditions

`docs/runbooks/deploy-staging.md` §1 is the authority; this is the checklist form. All must
be true before the **first ever** dispatch:

- [ ] **Cost approval recorded** in the phase report. Nothing billable before it.
- [ ] **`meridian-staging-edge` is up** — `scripts/staging_session.sh up`, then
      `describe-stacks` shows `CREATE_COMPLETE` or `UPDATE_COMPLETE`.
- [ ] **The four repository variables are set**: `AWS_DEPLOY_ROLE_ARN`, `AWS_ACCOUNT_ID`,
      `MERIDIAN_CF_PREFIX_LIST_ID`, `MERIDIAN_HOSTED_ZONE_ID` (plus `AWS_DIFF_ROLE_ARN`
      from §2, which is new in Phase 8).
- [ ] **The CDK bootstrap qualifier is confirmed** — `meridian-shared-iam-github-deploy`
      pins `hnb659fds`. If this estate bootstrapped with another, the role's ARNs are wrong
      and the deploy fails at `sts:AssumeRole`. This is an open `needs-a-human` item.
- [ ] **The commit is the one you mean** — both images are tagged `${{ github.sha }}` into
      `IMMUTABLE` repositories. There is no floating tag to correct afterwards.
- [ ] **The `confirm` input is typed exactly** — `deploy-staging`. Anything else fails the
      `guard` job and nothing is built.
- [ ] **Not during a close**, and not inside business hours: `desiredCount: 1` means 3-6
      minutes of hard downtime per api deploy until Phase 11.

### 11.2 DNS and TLS checks

Run after the certificate is issued and before any traffic is flipped. `dig` and
`openssl` only — no browser, because a browser caches and forgives.

```bash
# The zone answers, from the zone's own nameservers rather than a resolver cache.
dig +short NS meridiansgrp.com
dig @<one of those NS> +short staging-app.meridiansgrp.com

# The certificate: issuer, subject alternative names, and the expiry.
echo | openssl s_client -connect staging-app.meridiansgrp.com:443 \
  -servername staging-app.meridiansgrp.com 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates -ext subjectAltName

# TLS 1.0 and 1.1 must be refused; 1.2 and 1.3 must work.
for v in tls1 tls1_1 tls1_2 tls1_3; do
  echo -n "$v: "
  echo | openssl s_client -connect staging-app.meridiansgrp.com:443 \
    -servername staging-app.meridiansgrp.com -"$v" 2>&1 | grep -qi 'Cipher is (NONE)\|handshake failure' \
    && echo refused || echo accepted
done

# HTTP must redirect to HTTPS, and HSTS must be present on the HTTPS response.
curl -sI http://staging-app.meridiansgrp.com/ | head -1
curl -sI https://staging-app.meridiansgrp.com/ | grep -i strict-transport-security
```

Expected: `tls1` and `tls1_1` **refused**; `tls1_2` and `tls1_3` accepted; the HTTP request
answers `301`/`308`; `Strict-Transport-Security` present. The ACM certificate's expiry is not
a thing to diary — ACM renews DNS-validated certificates itself **as long as the validation
CNAME is still in the zone**. Check that the CNAME is there; that is the failure mode.

### 11.3 The production deploy, and the bill

Deploy production `vpc`, `data`, `auth`, `compute`, `api`, `observability` — one stack at a
time, by hand, with the runbook open (production is deliberately not in `deploy.yml`). Load
**synthetic** smoke data only; production carries no real data until Phase 9.

Then, after a full billing day, compare against `docs/reports/phase-1-cost-estimate.md`:

```bash
aws ce get-cost-and-usage --time-period Start=<first>,End=<last> \
  --granularity DAILY --metrics UnblendedCost \
  --group-by Type=DIMENSION,Key=SERVICE
```

**The gate:** within the approved estimate's range. Outside it, the deploy is not "done" —
the difference is explained before Phase 9 starts, because Phase 9's preconditions include
"production cost within the approved estimate".

### 11.4 Smoke tests after a green deploy

`docs/runbooks/deploy-staging.md` §7 is the authority; both of its checks are part of the
Phase 8 gate and are repeated for production.

**§7.1 — the app answers through CloudFront.** Both `200`:

```bash
curl -s -o /dev/null -w '%{http_code}\n' https://staging-app.meridiansgrp.com/
curl -s -o /dev/null -w '%{http_code}\n' https://staging-app.meridiansgrp.com/api/v1/health
```

A `403` on the second means the request did not come through CloudFront — the origin-verify
control working. Check where you sent it.

**§7.2 — a forged `CloudFront-Viewer-Address` does not reach the api.** Send six failing
sign-ins with the header set to `203.0.113.9:1`; the **sixth must be `429`**, proving the
rate limiter bucketed on the real caller, and the api log must contain **zero** occurrences
of `203.0.113.9`. If it appears, stop: the edge is forwarding a viewer-sent `CloudFront-*`
header and the rate limiter is choosable by the caller. This is the one check that turns
AWS's documented header-replacement behaviour into a verified fact (P5AR5-04) — no test in
this repository can exercise it.

**Evidence to keep.** Both outputs, dated, per environment. **Who:** Andres.

---

## 12. What is deploy-time only

These cannot be done in a session with no deployed account, and saying so is part of the
record. Nothing here is "skipped"; it is queued behind the cost approval and the foundation
deploy.

| Item | Blocked on |
|---|---|
| Security Hub score and finding triage (§3) | Foundation deployed; the standards need ~24 h to evaluate |
| Config conformance-pack compliance (§4) | Foundation deployed; most rules read `INSUFFICIENT_DATA` until production exists |
| GuardDuty / Inspector triage (§5) | Foundation deployed; Inspector needs an image in ECR and a function deployed |
| `cdk diff` in CI actually running (§2) | The role deployed and `AWS_DIFF_ROLE_ARN` set. **The role and the job are code and are done** |
| ZAP baseline (§6.4) | A running staging URL |
| Restore drill and DR test (§7) | Data in RDS and a recovery point that exists |
| Secrets rotation (§8) | The secrets existing in Secrets Manager |
| Vault lock verification (§9) | A recovery point, and the lock's changeable window closed |
| DNS/TLS checks (§11.2) | The certificate issued and the zone live |
| Production deploy and the bill check (§11.3) | Cost approval |
| Smoke tests (§11.4) | A deployed environment |
| The pen test itself (§6) | Money, and a signed engagement |

**Not deploy-time, and therefore owed now:** the threat-model refresh, the control-matrix
rows, the position paper (§10), the pen-test scope and ASVS checklist (§6.1-6.2), this
runbook, and the consolidated `needs-a-human` list below. **2026-09-24:** the position paper
is a DRAFT awaiting Andres's verification and signature (§10), and the Supabase archive's
custody record exists as an unsigned template at
`docs/compliance/evidence/supabase-archive-custody-record.md` (signed before the Phase 10
archive is taken).

---

## 13. `needs-a-human`, consolidated across Phases 0-8

Every "Needs a human" item from `docs/reports/phase-*-report.md`, in one table, deduplicated,
with an owner and a status. This is the list the plan asks Phase 8 to produce.

**Status** is one of: **open** (nobody has done it), **partly** (started, not finished),
**standing** (it recurs — it is never "done"), or a note saying what closed it.

| # | Item | Owner | First raised | Status |
|---|---|---|---|---|
| 1 | **Cost estimate approved in writing** (`docs/reports/phase-1-cost-estimate.md`: ≈ $37/month now, ≈ $239 steady state). Every phase from 1 onward repeats it; nothing billable exists without it | Andres | Phase 1 | **open — blocks Phases 2-9** |
| 2 | Render **Auto-Deploy OFF** on both services, then set the three backend switches to `supabase` in both dashboards, **in that order** | Andres | Phase 0 | open |
| 3 | Confirm **PHI may land on AWS** from Phase 3's staging rehearsal onward (the AWS BAA is active since 2026-07-13) | Andres | Phase 0 | open |
| 4 | Collect and file the signed **Stella Mattina ↔ Meridians Logic BAA** (D-03) | Andres | Phase 0 | **signed BAA exists (Andres, 2026-09-22)**; a copy still has to be filed with the evidence set |
| 5 | **Designate the security official in writing** | Andres | Phase 0 (control matrix) | **decided 2026-09-22: Andres is the security official**; the signed one-page designation still goes into the evidence set |
| 6 | **Mount the PHI vault volume** and move the quarantined files off the laptop | Andres | Phase 0 | open |
| 7 | **GoDaddy → Route 53 nameserver switch**, or hand-add the SES DKIM/MAIL FROM records at GoDaddy | Andres | Phase 0/1 | open — has a tracker row of its own |
| 8 | **Recover the Google and Microsoft OAuth client secrets** from the Supabase dashboard | Andres | Phase 0 | open — blocks Phase 4 federation |
| 9 | **Per-provider MFA evidence before a federated sign-in is enabled — permanent, not interim** (Codex G-H3): Cognito cannot demand MFA of a federated user, so `-c entraSignIn=true` requires a screenshot of the Entra Conditional Access policy requiring MFA for the app, and `-c googleSignIn=true` requires the Google Workspace 2-Step Verification enforcement page; a password-only test account on each provider must be refused. Re-evidenced on every identity-policy change and at each access review | Andres | before Flip 1, then quarterly | open |
| 10 | Decide the **history purge**: `main` on GitHub, four local branches, two retired repositories | Andres | Phase 0 | open |
| 11 | **Obsidian vault access** — the session cannot read the vault, so no phase note has been filed there | Andres | Phase 0 | open |
| 12 | **`codex login`** so the Codex review pass can run for Phases 0-3 | Andres | Phase 0/3 | **done**: Codex reviewed the whole tree on 2026-09-16 (three areas, then a plan pass) and again 2026-09-17 (`critic-log.md`, "Codex"), which covers Phases 0-3's code. Left: the four 2026-09-17 area reports cut off by the usage limit are still owed a re-run |
| 13 | **Render / Supabase HIPAA-tier quotes in writing** (P-9), and **who owns the `ai.meridiansgrp.com` stack** (P-10) | Andres | Phase 0 | open |
| 14 | Decide **AWS Organization + Identity Center** vs the IAM-users + MFA fallback | Andres | Phase 1 | **decided 2026-09-22: Organization + Identity Center, MFA via Microsoft Authenticator (TOTP, a six-digit code that changes every 30 seconds)** |
| 15 | After the foundation deploy: **enrol MFA, run the IAM triage in order, file the SES production-access request, run the break-glass drill** | Andres | Phase 1 (SES access repeated by Phase 7 item 2) | open — SES access now gates the post-Phase 9 flip, not Phase 7 |
| 16 | The **CloudFront prefix-list id** and **hosted-zone id** — read once after the shared stacks deploy, then set as repository variables | Andres | Phase 2 | open |
| 17 | Name the **two rehearsal periods** and where their input workbooks are; without them the JE diff gate does not exist | Andres | Phase 3 | open — blocks the Phase 5a port gate. **2026-09-22: Andres does not have the input workbooks; an alternative source is needed** |
| 18 | **Trial instance teardown** — ask before deleting | Andres | Phase 3 | open |
| 19 | **Entra app registration**: Cognito's Microsoft provider must reuse Supabase's registration. Needs the external tenant admin | External admin, via Andres | Phase 4 | open |
| 20 | Fill `meridian-<env>/legacy-supabase-auth` with the production Supabase URL and anon key **before Flip 1** | Andres | Phase 4 | open |
| 21 | Hand-edit `.env.example` to add `cognito` and the `COGNITO_*` variables (the agent cannot write it) | Andres | Phase 4 | open |
| 22 | **Generate the user snapshot on the day of each auth-stack deploy** | Andres | Phase 4 | **standing** |
| 23 | **Approve Flip 1** when staging verification is clean and no close is running | Andres | Phase 4 | open |
| 24 | **Production dump + rehearsal workbooks** for the Phase 5a port gate | Andres | Phase 5a | open |
| 25 | **`a2wsgi`: yes or no** — a dependency decision, not a task | Andres | Phase 5a | **decided 2026-09-22: yes — added; `api/main.py` mounts Flask through `a2wsgi` (streams, no full-body buffering)** |
| 26 | **Wearbly: repair or retire** | Andres | Phase 5a | **decided 2026-09-22: retire.** Removing its code is a deletion and is asked for separately; row 39 becomes moot once it is removed |
| 27 | **Confirm the CDK bootstrap qualifier** before the first `deploy.yml` dispatch — Phase 8's report asks for the concrete fix: bootstrap a staging-only qualifier with scoped execution policies (tracker, P5AR3-03) | Andres | Phase 5a, 8 | open |
| 28 | **Confirm the SNS alert email subscription** — until someone clicks the link, every Phase 6 alarm fires into an empty topic | Andres | Phase 6 | open |
| 29 | **Phase 6's ≈ $4/month** for alarms, the dashboard and the Pipe — not inside the approved estimate | Andres | Phase 6 | open |
| 30 | **The health canary's cost decision** — built and switched off pending it | Andres | Phase 6 | open |
| 31 | **Amazon Macie: enable or write down why not** — decided in Phase 8, see §14 | Andres | Phase 3 → 8 | **decided — see §14** |
| 32 | **External penetration test** — scope and prep package exist (§6); the engagement is bought | Andres | control matrix | open |
| 33 | **SOC 2 auditor** (independent CPA firm), if a report is ever required | Andres | control matrix | open — not engaged, and Meridian never claims otherwise |
| 34 | **Partner BAAs** — one per future external client holding a `phi:read` scope | Andres | control matrix | standing |
| 35 | **Attorney engagement** for the Track C policy set and the BAA review | Andres | control matrix | open |
| 36 | The **Track C written policy set** — risk analysis, risk management, sanction, contingency, incident response, workforce, training, physical, evaluation | Andres | control matrix | open |
| 37 | **Confirm nobody reads `source_transactions.raw_data`** so it can stop being persisted (~85 % of stored PHI) | Andres | control matrix | open |
| 38 | **Redeploy the `data` stack after cost approval**, so the alerts topic's resource policy takes effect — until then the Phase 6 alarms have a topic that will not accept them | Andres | Phase 6 (report) | open — follows row 1 |
| 39 | **`normalize_size` on Supabase: decide before the next Wearbly order is generated** — the other open Wearbly row, separate from "repair or retire" (row 26) | Andres | Phase 5b (report) | open |
| 40 | **Two Cognito sign-in challenges have no screen** — `MFA_SETUP` and `NEW_PASSWORD_REQUIRED` come back from `InitiateAuth` and the API answers both with "ask an administrator". It is a dead end for the affected user, and the screens must exist **before the dual-acceptance window closes** at the Phase 10 cut-off, because after that there is no Supabase path to fall back to | Andres to schedule; Claude builds | Phase 5b (report) | **built 2026-09-24** (auth-hardening branch, tracker T:85 closed): both challenges now have React steps and `/api/v2/auth/challenge/*` endpoints; what remains is the Phase 4 step 9 staging check against a real pool |
| 41 | ~~**Invoice PDFs are written to local disk** (`output/invoices/`), which is ephemeral on Render and on ECS: a generated invoice is gone at the next deploy. Decide whether they move to S3 `artifacts` or stop being persisted at all~~ | Andres | Phase 5b (report) | **moot 2026-10-09:** the in-app invoice feature was removed 2026-09-28 (Alembic 0032 dropped its tables); invoices are built outside the app, so Meridian writes no invoice PDF |
| 42 | **Alert acknowledgement and an emergency delegate** (Codex G-M2): `alerts.md` ends at one mailbox and one person. Name a second channel (SMS via SNS is ≈ $1/month), an acknowledgement deadline per severity (P1 15 min, P2 4 h), one delegate with tested break-glass access, and run one absence drill; keep the acknowledgement in the log | Andres | before cutover | open |
| 43 | **Regional RPO decision** (Codex G-H1 / PS-12): accept ≈ 24-30 h in writing (ADR 0007 as amended), or fund a cross-region RDS read replica (≈ $25-40/month, outside the approved estimate) and Phase 8 builds it | Andres | before cutover | open |
| 44 | **Tenant retention and disposal** (Codex G-M3): no procedure returns or purges one customer's data across `public`, `phi`, both buckets (versions included) and the 35-day vault; the key-destruction procedure would take every tenant with it. Decide the contractual retention period; Phase 12 builds `scripts/tenant_purge.py` (dry-run inventory, hold flag, version-aware deletes, tombstones so a restore cannot resurrect a disposed tenant, disposal receipt) | Andres (period) / Claude (Phase 12) | Phase 12 | open |
| 45 | **Set `EMAIL_BACKEND=resend` on `meridian-api` in the Render dashboard** before this branch reaches `main` — unset raises at startup. Correct for the whole remaining life of the Render services | Andres | Phase 7 (report item 1) | open — tracker row, with the three Phase 0c switches (row 2) |
| 46 | **Confirm the SNS subscription on `meridian-shared-sns-email-events`** — bounces and complaints fire into an empty topic until a human clicks the link. Not the same topic as row 28 | Andres | Phase 7 (report item 3) | open |
| 47 | **Close the Resend account** — after the SES flip, which is after Phase 9 (ADR 0025 §3), not at the end of Phase 7 | Andres | Phase 7 (report item 4) | open — waits for the flip |
| 48 | **The SES bounce / complaint / rendering-failure alarms** (Phase 7 report item 5) | Claude built; Andres approves the spend (row 51) | Phase 7 | **built 2026-09-24** (tracker T:39 closed, Phase 8 infra pass); never tripped — the Phase 6 "no alarm has ever fired" row covers them |
| 49 | **Set the repository variables**: `AWS_DIFF_ROLE_ARN` (after the foundation deploy) and the four `deploy.yml` variables (`AWS_DEPLOY_ROLE_ARN`, `AWS_ACCOUNT_ID`, `MERIDIAN_CF_PREFIX_LIST_ID`, `MERIDIAN_HOSTED_ZONE_ID`; the last two are row 16) | Andres | Phase 8 (report) | open |
| 50 | **Required reviewers on the `staging` GitHub Environment** (Codex CX-INF-02 residual): a newly committed workflow declaring `environment: staging` on a trusted branch is the last path to the deploy role | Andres | Phase 8 | open — before the first `deploy.yml` dispatch |
| 51 | **Approve the Phase 8 infra pass's ≈ $3.10-3.70/month** (ten production alarms, seven `Meridian/Backup` metrics) — outside the approved estimate, like row 29 | Andres | Phase 8 (infra pass, local-first D14) | open |
| 52 | **Pin the RDS CA bundle**: run `scripts/pin_rds_ca_bundle.py` once and compare the printed fingerprints with AWS's published list; until then `Dockerfile.api` refuses to build (fail-closed) | Andres | Phase 8 (Codex CX-INF-03, local-first D13) | open — before the first `deploy.yml` dispatch |
| 53 | **Cognito identity backups into the seven-year Object-Locked bucket**: every address kept seven years — confirm that retention before the nightly export is scheduled | Andres | Phase 8 (Codex G-H2, local-first D15) | open |
| 54 | **Sign the in-transit encryption position paper** (§10) after checking its two VERIFY statements, and the **Supabase archive custody record** before the Phase 10 archive | Andres | Phase 8 | **drafts exist 2026-09-24**; unsigned |
| 55 | **Fund and schedule the pen test** (Phase 8 report) — the same item as row 32, repeated there | Andres | Phase 8 | open — see row 32 |

**Where rows 28-55 come from** (corrected in round 1, P8-09; completed 2026-09-24):
rows 28-30 and 38 are `docs/reports/phase-6-report.md`'s "Needs a human" section; rows
39-41 are `docs/reports/phase-5b-report.md`'s; rows 42-44 are Codex's plan-gap findings;
rows 45-48 are `docs/reports/phase-7-report.md`'s five items (its item 2, SES production
access, is row 15); rows 49-55 are `docs/reports/phase-8-report.md`'s four items (its Macie
item is row 31) and the four human items the 2026-09-24 Phase 8 infra pass left in the
tracker. Every phase report 0-8 has now been read for this table. Phases 11-12 keep their
open decisions in `docs/reports/local-first-plan-2026-09-24.md` (D1-D16) until their reports
exist.

---

## 14. Amazon Macie — the decision

**Decided in Phase 8: do not enable.** Recorded here and in `docs/migration-tracker.md` as
Andres's decision, closing the row that has been open since Phase 3.

**The argument for.** Macie is the only control that would *measure* rather than assert
"PHI is only in the `phi` bucket". It would catch PHI written into `artifacts` — where
`src/storage.py`'s `bucket_for` is supposed to send only de-identified exports — or into the
`audit` bucket.

**The argument against, and why it wins today — which is NOT the money** (corrected in round
1, P8-06). The plan's own cost table prices Macie at **≈ $2.00/month** for two buckets with
automated discovery **off**; on a ≈ $239/month estate that is 0.8 %, and calling it "real
money" would not survive being read next to the plan. The reason it wins is narrower and
harder to argue with: **Macie today would have nothing to classify.** Production holds no
data until Phase 9 and staging holds synthetic data, so the scan would read files we wrote
ourselves and the findings review would be time spent on our own fixtures. Two cost points
are true and neither is the reason: the ≈ $2.00 buys monitoring with discovery off — per-GB
*discovery*, the part that actually looks inside objects, is priced nowhere in the estimate —
and the Macie line is additive to the ≈ $239 rather than inside it.

**What stands in for it meanwhile.** The `bucket_for` code path and its tests; GuardDuty S3
data events on the `phi` bucket; GuardDuty Malware Protection on the upload bucket; the
PHI-logging lint. All of these are assertions about code except the GuardDuty pair, which is
the honest statement of the residual risk.

**The trigger to revisit — and it is a real one, not a formality.** Enable Macie, with one
automated discovery job scoped to `phi` and `artifacts` only, at the **first** of:

1. production carrying real data for one full period after Flip 2 (Phase 9), or
2. the first PHI-scoped external partner, or
3. any finding — from a pen test, an incident, or a code review — that PHI reached a bucket
   other than `phi`.

Until then the gap is stated rather than closed, which is the same thing the threat model
and ADR 0020 already say. **This decision is reviewed at the Phase 9 gate**, not "some day".

---

## 15. The record

Append a row after each Phase 8 gate item is completed. This table is what an auditor is
handed alongside the control matrix.

| Date | Section | Item | Result | Evidence filed at | By |
|---|---|---|---|---|---|
| _(pending)_ | | | | | |
