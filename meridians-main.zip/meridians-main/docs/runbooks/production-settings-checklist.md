# Production settings checklist

Every secret and setting the production AWS estate (`meridian-production-*`) needs before
cutover, where each value comes from, and whether it is filled. Written 2026-10-12 from the
code (`infra/meridian/stacks/*.py`, `src/settings.py` and every environment read in `src/`,
`api/`, `web_app.py`, `workers/`, `lambda/`), the README's environment table,
`production-readiness.md` and `cutover.md`, and a read-only look at staging's secrets.

**No value appears in this file, and none may ever be added.** Names only.

## Status on 2026-10-12

**No `meridian-production-*` stack exists yet**, so every production secret below is
*not created*. After the first production deploy, re-check each one with:

```bash
aws secretsmanager describe-secret --region us-east-1 --secret-id <name> \
  --query '{Created:CreatedDate,Changed:LastChangedDate,Versions:VersionIdsToStages}'
```

How to read it (it never shows the value):

- **Not found** → no stack created it and nobody created it by hand.
- **One version, `Changed` = `Created`** → either CloudFormation generated it (fine, for the
  "generated" rows) or it is still the **empty placeholder** CDK wrote (not fine, for the
  "must fill" rows).
- **Two versions (`AWSCURRENT` + `AWSPREVIOUS`), `Changed` later than `Created`** → someone
  put a value in by hand after the stack made it. That is "filled".

## How to fill a secret safely (all rows use this shape)

Never type a secret on the command line (it lands in shell history and `ps`). Write it to a
private temporary file, point the CLI at the file, delete the file:

```bash
umask 077
f="$(mktemp)"            # a private temp file, not in the repo, Downloads or Desktop
open -e "$f"             # paste the JSON shown in the row, save, close
aws secretsmanager put-secret-value --region us-east-1 \
  --secret-id <name> --secret-string "file://$f"
rm -P "$f"
```

For a secret **no stack creates** (marked *create by hand*), use `create-secret` instead,
on the environment's `logs` key:

```bash
aws secretsmanager create-secret --region us-east-1 \
  --name <name> --kms-key-id alias/meridian-production-kms-logs \
  --secret-string "file://$f"
```

A running ECS task reads its secrets only when it starts, so after changing one that a task
uses, force a new deployment of that service (`aws ecs update-service --cluster <cluster>
--service <service> --force-new-deployment`).

---

## 1. Must fill (or create) before cutover

| Name | What it's for | Where the value comes from | Needed for | How to fill it | Status (production) |
|---|---|---|---|---|---|
| `meridian-production/legacy-supabase-auth` | Lets the Cognito "user migration" Lambda check a Supabase-era password the first time each person signs in on AWS, so nobody has to reset their password | The live Supabase project's URL and **anon** key (never the service key). Same project staging was filled from, so: copy from `meridian-staging/legacy-supabase-auth`, or Supabase dashboard → Project Settings → API, or `.env` names `SUPABASE_URL` / `SUPABASE_ANON_KEY` | Cutover (Flip 1 on AWS). Created empty by the `auth` stack | File content `{"SUPABASE_URL":"...","SUPABASE_ANON_KEY":"..."}`, then `put-secret-value --secret-id meridian-production/legacy-supabase-auth --secret-string file://$f` | Not created (stack not deployed). Will exist **empty** after the `auth` deploy |
| Legacy user snapshot `lambda/user_migration/legacy_users.json` (a file, not a secret) | The list of Supabase users the migration Lambda is allowed to bring across; without it every first sign-in fails closed | `python3 scripts/snapshot_legacy_users.py` on the Mac, which reads `.env` names `SUPABASE_URL` / `SUPABASE_SERVICE_KEY`. Gitignored, so it only exists on the machine that generated it | Cutover. Generate **the same day** as the production `auth` deploy | Deploy `meridian-production-auth` with `-c requireLegacySnapshot=true` from the checkout that holds the file (`cognito-user-migration.md` §1-3) | Not generated for production |
| `meridian-production/qbo-oauth` | QuickBooks Online app's OAuth client id and secret, so "Connect QuickBooks" and the posting worker can talk to Intuit | developer.intuit.com → the Meridian app → **Production** keys (production uses `QBO_ENVIRONMENT=production`; staging would use the sandbox keys). Becomes `QBO_CLIENT_ID` / `QBO_CLIENT_SECRET` in the api and worker tasks | Any deploy with `-c worker_enabled=true` (the deploy **fails at task start** without it). Needed at cutover only if QuickBooks Connect must work on day one; Render has no QBO variables today | **Create by hand.** File content `{"client_id":"...","client_secret":"..."}`, then `create-secret --name meridian-production/qbo-oauth --kms-key-id alias/meridian-production-kms-logs --secret-string file://$f` | **No stack creates it.** Does not exist (staging has none either) |
| Intuit redirect URI (a setting at Intuit, not a secret) | Where Intuit sends the browser back after "Connect QuickBooks" | Must be registered at developer.intuit.com exactly as `https://app.meridiansgrp.com/api/v2/qbo/connection/callback`. CDK sets `QBO_REDIRECT_URI` to the same string | Same as `qbo-oauth`; a `cutover.md` precondition (C) | Intuit developer portal → Production → Redirect URIs | Unknown (check the portal) |
| SNS alerts subscription on `meridian-production-sns-alerts` (not a secret) | Without a confirmed email subscription every production alarm fires into an empty topic | Andres's alert mailbox | Cutover precondition (Phase 6 row) | `alerts.md` step 0: `aws sns subscribe ... --protocol email`, then click the link | Topic not created yet |
| SES production access (account setting) | Production sends invites and run notices through SES (`EMAIL_BACKEND=ses` is already in the task definition) | AWS support case | Cutover precondition (Phase 7 row) | `email-cutover.md` §0 | Open per `production-readiness.md` §13 row 15 |

### Code gap that blocks cutover: the PHI HMAC key never reaches the app

`meridian-production-secret-phi-hmac-key` will be **generated** by the `data` stack, and the
api task role is allowed to read it, but **no task definition injects it** and `src/phi.py`
reads `MERIDIAN_PHI_HMAC_KEY` from the environment only. Staging's api task (revision 7,
checked today) has no such variable. So on ECS `phi.token_for()` raises `PhiError` on the
first transaction insert, i.e. the first revenue upload. This is tracker **T:95, still open**:
`src/phi.hmac_key()` has to fetch the secret with boto3 (cached, never logged). Nothing to
fill by hand; it is a code change that must land before cutover.

---

## 2. Generated automatically (nothing to type)

All created by `cdk deploy`; `RemovalPolicy.RETAIN`, so they survive a stack delete.

| Name | What it's for | Where the value comes from | Needed for | How to fill it | Status (production) |
|---|---|---|---|---|---|
| `meridian-production-secret-db-app` | Password of `meridian_app`, the role the app connects as (`PGPASSWORD`) | Generated by CloudFormation (`data` stack); installed in Postgres by Alembic 0003 via `MERIDIAN_APP_DB_PASSWORD` | Empty deploy | Nothing. Read it into `MERIDIAN_APP_DB_PASSWORD` only for the migration (`data-load.md`) | Not created |
| `meridian-production-secret-db-phi` | Password of `phi_access`, the only role that can read patient identifiers | Generated (`data`); Alembic 0003 reads `MERIDIAN_PHI_DB_PASSWORD` | Empty deploy | Nothing | Not created |
| `meridian-production-secret-phi-hmac-key` | Key behind `patient_ref` (links each transaction to its patient identity). **Never rotate** without `rotate-secrets.md` §4. Replicated to us-west-2 | Generated (`data`) | Cutover: the data load's `split_phi` and the app (see the code gap above) | Nothing | Not created |
| `meridian-production-secret-flask-key` | `FLASK_SECRET_KEY`, signs the session cookie | Generated (`data`) | Empty deploy (the api refuses to start without it) | Nothing | Not created |
| `meridian-production-secret-origin-verify` | Shared header proving a request came through CloudFront; every ALB rule requires it | Generated (`data`) | Empty deploy. Record its version ids for every later `edge` deploy (`cutover.md` precondition C) | Nothing. Rotation: `rotate-origin-verify-secret.md` | Not created |
| `meridian-production/cognito-web-client` | `COGNITO_CLIENT_SECRET`, the web client's secret | Copied in by CloudFormation from the Cognito client (`auth` stack). "Never edit by hand" | Empty deploy | Nothing | Not created |
| `rds!db-<id>` (RDS-managed master) | Password of `meridian_migrator`, the schema owner used by Alembic and the data load | RDS creates and rotates it | Cutover (data load) | Nothing | Not created |

Not secrets but also automatic (set by CDK in the task definitions, listed so nobody hunts
for them): `APP_ENV`, `FLASK_ENV`, `PORT`, `DATABASE_BACKEND=postgres`, `STORAGE_BACKEND=s3`,
`AUTH_BACKEND=cognito`, `EMAIL_BACKEND=ses`, `AUTH_ACCEPT_SUPABASE_TOKENS`, `PGHOST`, `PGPORT`,
`PGDATABASE`, `PGUSER`, `PGSSLMODE`, `PG_SSLROOTCERT`, `COGNITO_USER_POOL_ID`,
`COGNITO_CLIENT_ID`, `COGNITO_REGION`, `COGNITO_DOMAIN`, `FORWARDED_ALLOW_IPS`, the four
`MERIDIAN_S3_*`, `MERIDIAN_SES_FROM_EMAIL`, `MERIDIAN_SES_CONFIGURATION_SET`,
`PUBLIC_APP_URL`; on `web`: `NODE_ENV`, `MERIDIAN_API_ORIGIN`, `PUBLIC_APP_URL`,
`PUBLIC_WWW_URL`. With `-c worker_enabled=true` also `QBO_ENVIRONMENT`, `QBO_REDIRECT_URI`,
`QBO_TOKEN_KMS_KEY_ARN`, `MERIDIAN_JOBS_QUEUE_URL`, `MERIDIAN_JOBS_DLQ_URL`.

### Deploy-time context values (not secrets, but every production `edge` deploy needs them)

`-c hostedZoneId`, `-c cloudfrontPrefixListId`, `-c originVerifyActiveVersion`,
`-c originVerifyPreviousVersion`, `-c originVerifyCloudFrontVersionId`. Omitting one does not
fail the deploy; it takes the site off the air (`cutover.md` precondition C). Write them down
after the first production `edge` deploy.

---

## 3. Not needed yet

| Name | What it's for | Where the value comes from | Needed for | How to fill it | Status (production) |
|---|---|---|---|---|---|
| `meridian-production/google-idp` | "Sign in with Google" through Cognito | Google Cloud console OAuth client (the one Supabase uses; its secret must be recovered, `production-readiness.md` §13 row 8). Redirect URI to add at Google: `https://meridian-production.auth.us-east-1.amazoncognito.com/oauth2/idpresponse` | Federated sign-in (Phase 4 step 3); only takes effect with `-c googleIdp=true` | File `{"client_id":"...","client_secret":"..."}`, `put-secret-value --secret-id meridian-production/google-idp --secret-string file://$f`, then deploy `auth` with `-c googleIdp=true` | Not created; will be an empty placeholder. Staging's is **still empty** |
| `meridian-production/entra-idp` | "Sign in with Microsoft" | The Entra app registration Supabase uses (needs the tenant admin, P-8). Same Cognito redirect URI as above | Same, with `-c entraIdp=true` | File `{"tenant_id":"...","client_id":"...","client_secret":"..."}`, same command shape | Not created; will be an empty placeholder. Staging's is **still empty** |
| `meridian-production/resend-api-key` | Email rollback from SES to Resend | Resend dashboard, or `.env` name `RESEND_API_KEY` | Only for a `-c emailBackend=resend` rollback (`email-cutover.md` §2) | **Create by hand**, `create-secret --name meridian-production/resend-api-key --kms-key-id alias/meridian-production-kms-logs --secret-string file://$f` | **No stack creates it.** Does not exist (by design) |
| `meridian-production-webhook-*` | One signing secret per partner webhook subscription | Created at runtime by the api (`src/webhooks/ports.py`) | API platform, `-c enableApiPlatform=true` (Phase 12) | Nothing by hand | Not created |
| `MERIDIAN_MTLS_ORIGIN_VERIFY` (env) | Lets a partner mTLS ingress vouch for a client certificate | Would come from Secrets Manager once T25 is built | Phase 12 T25 (not built). Unset = machine `phi:read` never effective, which is correct today | Nothing yet | **No stack creates it**; read by `src/settings.py`, intentionally unset |

## 4. Settings the app reads that production does **not** need

- **eCW database** (`ECW_DB_HOST`, `ECW_DB_NAME`, `ECW_DB_USER`, `ECW_DB_PASSWORD`): read only by
  `src/sm_ecw_connection/db.py`, which nothing in the app, api or worker imports. Not wired into
  AWS; nothing to create.
- **NetSuite**: no credentials anywhere. Meridian writes journal-entry CSVs that are imported by
  hand; the `NS_*` names in `src/` are code constants, not settings.
- **Anthropic / other LLM keys**: the app, api, worker and Lambdas read none.
- **Supabase app keys** (`SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `SUPABASE_ANON_KEY`,
  `SUPABASE_KEY`, `SUPABASE_DB_URL`): Render-only. Not in the ECS task, by design. Side effect
  worth knowing: `AUTH_ACCEPT_SUPABASE_TOKENS=true` on ECS has no Supabase URL to check a token
  against, so the fallback silently returns "not signed in". Harmless at cutover because a
  Supabase cookie for `www` is never sent to `app.`; only the Lambda (above) needs Supabase.
  `SUPABASE_DB_URL` from `.env` is still used on the Mac for the cutover dump (`data-load.md`).
- **QuickBooks script settings** (`QBO_SECRET_ID`, `QBO_CONFIG_SECRET_ID`, `QBO_REALM_ID`): only
  `scripts/qb_fetch_accounts.py` on the Mac.
- **Local-only**: `AUTH_MODE`, `LOCAL_DEV_ORG_ID`, `MERIDIAN_DATA_DIR`, `MERIDIAN_SQLITE_PATH`,
  `MERIDIAN_DEV_QBO_TOKEN_KEY`, `MERIDIAN_DEV_COGNITO_STORE`, `MERIDIAN_HOST`/`_PORT`/`_RELOAD`.
- **Optional tuning with safe defaults**: `PG_POOL_MIN`, `PG_POOL_MAX`, `PG_POOL_TIMEOUT`,
  `MERIDIAN_MAX_UPLOAD_BYTES`, `MERIDIAN_LOG_LEVEL`, `MERIDIAN_JSON_LOGS`,
  `EMAIL_FROM_DISPLAY_NAME`, `JOB_TRANSPORT`, `WORKER_PROCESSES`, `PROCESS_SUBMISSIONS_PAUSED`,
  `MERIDIAN_QBO_POSTING`, `MERIDIAN_SCRATCH_DIR`, `MERIDIAN_WORKER_ID`.

---

## Appendix: what staging needed (read-only check, 2026-10-12)

`list-secrets` / `describe-secret` metadata only; no value was read.

| Staging secret | Created | Last changed | Versions | Meaning |
|---|---|---|---|---|
| `meridian-staging-secret-origin-verify` | 2026-10-04 | 2026-10-04 | 1 | Generated |
| `meridian-staging-secret-phi-hmac-key` | 2026-10-04 | 2026-10-04 | 1 | Generated |
| `meridian-staging-secret-db-phi` | 2026-10-04 | 2026-10-04 | 1 | Generated |
| `meridian-staging-secret-db-app` | 2026-10-04 | 2026-10-04 | 1 | Generated |
| `rds!db-bfc51456-…` (staging master) | 2026-10-04 | 2026-10-12 | current + previous | RDS-managed, rotating |
| `meridian-staging/legacy-supabase-auth` | 2026-10-05 14:47 | 2026-10-05 14:48 | current + previous | **Filled by hand** — the only one staging needed |
| `meridian-staging/google-idp` | 2026-10-05 | 2026-10-05 | 1, never accessed | Still the empty placeholder |
| `meridian-staging/entra-idp` | 2026-10-05 | 2026-10-05 | 1, never accessed | Still the empty placeholder |
| `meridian-staging/cognito-web-client` | 2026-10-05 | 2026-10-05 | 1 | Copied by CloudFormation |
| `meridian-staging-secret-flask-key` | 2026-10-05 | 2026-10-05 | 1 | Generated |
| `meridian-staging/qbo-oauth` | — | — | — | **Absent**: staging has never run with `worker_enabled` |
| `meridian-staging/resend-api-key` | — | — | — | Absent (no rollback ever deployed) |

Staging's api task definition (`meridian-staging-ecs-api` revision 7) injects exactly three
secrets: `PGPASSWORD`, `COGNITO_CLIENT_SECRET`, `FLASK_SECRET_KEY`. No worker task definition
exists, and no SSM parameters are used (the only one in the account is CDK's bootstrap
version). The other secrets in the account (`meridian/assistant-db-app`,
`meridian/business-db-app`, the July `rds!db-30c24748-…`) are not created by these stacks.
