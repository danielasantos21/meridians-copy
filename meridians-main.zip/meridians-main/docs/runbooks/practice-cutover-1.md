# Runbook — Practice cutover #1 (production AWS, Supabase and Render untouched)

**What this is:** a full dress rehearsal of the Phase 9 data move, run against the **real
production AWS stack** instead of staging. You load a copy of Supabase into the empty
production RDS, copy the storage objects, sign in as yourself only, produce the same two
payroll journal entries on Render (old) and AWS (new), compare them line by line, and then
**reset production back to empty** so the real cutover starts clean.

**Source of truth for the real day:** `docs/runbooks/cutover.md`. This file is the
practice version of its steps 3-4 and 6 plus the payroll comparison in its §B. It does not
flip DNS, does not freeze or suspend Render, and does not email any real user.

**Written:** 2026-10-12 against `aws-migration` @ `89e85a57`. Every script, flag and AWS
name below was checked on that day (read-only). Anything not checked says so.

> **Who runs what.** Andres runs every command in this file. Anything that touches AWS or
> a live system is marked **[ANDRES]**. Nothing here is run by an assistant.

> **The three rules of the day**
> 1. Supabase and Render are only ever **read**. Nothing is written to either.
> 2. Only `--only <your own address>` is ever used with `invite_legacy_users.py --apply`.
>    Never run it without `--only`. Never run `reissue_pending_invites.py`.
> 3. PHI (dump, mirror, payroll inputs and outputs) lives only under `/Volumes/MeridianPHI`.

---

## Blockers found while writing this (read first)

| # | Blocker | Why | What to do |
|---|---|---|---|
| B1 | **There is no production ops instance.** `meridian-production-ec2-ops` does not exist; the only ops instance (`i-039e10786dcded5d5`) is staging's and sits in the staging VPC, so it cannot reach the production database. Production RDS is private (`PubliclyAccessible=false`, only `sg-app` and `sg-ops` may connect). | Without it your laptop cannot run Alembic, `pg_restore`, `split_phi` or `verify_parity` against production. | Step 1: deploy the `meridian-production-edge` stack once with `-c createOpsInstance=true`. It is a **decision** for Andres (see "Decisions"). The alternative, ECS Exec into the api container, cannot carry a 100 MB dump from your laptop and the image has no `pg_dump`. |
| B2 | **`infra/cdk.context.json` holds STAGING's origin-verify version id** (`558742ff-...`). CDK reads that file automatically. A production edge deploy that does not override it on the command line builds the ALB rules and CloudFront header from the wrong secret version and returns 403 on every request. | Taking the site (including `app.meridiansgrp.com`) off the air. | Step 1 passes the production values explicitly with `-c`, which beats the file. Do not drop any of the `-c` flags. |
| B3 | **For the REAL cutover only (not this practice):** precondition C of `cutover.md` says `public.source_transactions` must be moved to the `phi` schema first. No migration does that yet (`0005` says so itself). The practice run does not need it; the real run does. | Cutover precondition. | Track it; not a practice blocker. |
| B4 | ~~`/Volumes/MeridianPHI` is not encrypted~~ **False alarm, corrected 2026-10-12.** `diskutil info` reports `Encrypted: No` for the inner volume of an encrypted sparsebundle; the encryption is on the disk image behind it. `hdiutil info` shows `image-encrypted : TRUE` for `~/MeridianPHI.sparsebundle`. | The runbook relies on encryption, not `rm`, to make deleting PHI safe. | Use the `hdiutil` check in Part 0.2 (`scripts/practice_cutover.sh` does it for you). |

Not blockers, but know them: the RDS database `meridian` does not exist yet
(`DBName` is empty on `meridian-production-rds-main`; Step 4 creates it); the laptop tools
are newer than the server (client 18.3, server 17.9), which is fine.

---

## Decisions Andres must make before starting

1. **Approve the ops instance in production (B1).** About $3.70/month (t4g.nano instance plus its 8 GB gp3 disk), zero open
   ports, reached only through AWS Systems Manager. It is also what the real cutover needs, so
   the recommendation is: deploy it now and keep it.
2. **Accept that practice PHI sits in production AWS for a few hours.** The restore puts a
   full copy of the data in production RDS and S3. After the reset the live objects are gone,
   but two copies cannot be erased: the **RDS automated backups** (7-day retention) and any
   **AWS Backup recovery points** (the vault is locked) taken during the window, and the
   Postgres log group `/aws/rds/instance/meridian-production-rds-main/postgresql`
   (400-day retention; pgaudit logs statements but by design carries no identifiers). The
   BAA covers this account, so it is allowed; it is a documented consequence, not a surprise.
3. **QuickBooks token risk.** `qbo_connection` is copied into RDS like every other table. If
   anything on AWS refreshed that token, QuickBooks would rotate it and the copy Render holds
   would go stale (broken QBO connection on Render). **Practice-only decision: Step 4.7 deletes
   those rows from the production copy right after parity, so the copy cannot refresh
   anything.** Parity is taken first, so it still sees the table. The real cutover decides
   this separately (it must carry the connection over, or have you reconnect on AWS).
   Rule for the day anyway: never open a QuickBooks screen on AWS and never press Book.
4. **Pick the day.** Not during a close; payroll P09 must already be final so the roster and
   mappings do not change between the old run and the dump.

---

## Time budget (estimates, nothing here has been timed yet)

The only real data point: the staging load on 2026-10-07 took about 15 minutes from first
tunnel to second parity report (dump 11 MB). Everything else is an estimate. **Write the real
times into the table at the bottom — that is half the point of a practice run.**

| Part | Estimate |
|---|---|
| 0 Prerequisites and shell setup | 15 min |
| 1 Ops instance (one edge deploy + checks) | 20-30 min |
| 2-3 Tunnel, database, Alembic to 0003 | 10 min |
| 4 Mirror pull + OLD payroll runs on Render | 30-45 min |
| 5 Dump, restore, split, parity 0003, head, parity head | 20-30 min |
| 6 Push storage to S3 and check it | 15-20 min |
| 7 Sign-in test (invite only you) | 10-15 min |
| 8 NEW payroll runs + JE diff | 30-40 min |
| 9 Reset production to empty | 20-30 min |
| **Total** | **about 3.5-4.5 hours, one sitting** |

---

## Part 0. Prerequisites (no AWS or live-system writes)

### 0.1 Tools — verified on this laptop 2026-10-12

| Tool | Found | Needed |
|---|---|---|
| `pg_dump`, `psql`, `pg_restore` | 18.3 (Homebrew) | at least the RDS version, which is **17.9** (`cutover.md` says 17.6 or newer) |
| `aws` | 2.35.21 | any v2 |
| `session-manager-plugin` | 1.2.835.0 | installed |
| `dig` | present | |
| venv | `/Users/andressantos/Desktop/work_in_progress/NS_Proccess_QB/venv` | alembic head in this branch is `0037_drop_wearbly_tables`; `psycopg2`, `dotenv`, `supabase`, `boto3` import fine |
| Node/`npx cdk` | not checked | needed only in Part 1 (run from `infra/`) |

### 0.2 PHI drive

```bash
phi-mount                       # if /Volumes/MeridianPHI is not already there
df -h /Volumes/MeridianPHI      # on 2026-10-12: 50 GiB, 11 MiB used
```
Success: the drive is listed with free space. The practice needs well under 1 GB.

**The drive must be encrypted, and `rm -rf` is NOT a shredder.** Deleting files on an SSD or
APFS volume only removes the directory entries; the bytes can survive. What makes deletion
safe is that the whole volume is encrypted, so the leftover blocks are unreadable without the
key. Check it before any PHI touches the drive:

```bash
hdiutil info | grep -B25 '/Volumes/MeridianPHI' | grep -E 'image-path|image-encrypted'
```
Success: the block for `MeridianPHI.sparsebundle` shows `image-encrypted : TRUE`. **STOP if it
says FALSE or prints nothing.** Do NOT use `diskutil info` for this: it prints `Encrypted: No`
for the inner volume of an encrypted sparsebundle (a false negative; the encryption is on the
disk image). `scripts/practice_cutover.sh` refuses to start unless this check passes.

**Browser downloads.** Steps 3.3, 7.3 and 8.1 download PHI files in a browser, and browsers
default to `~/Downloads`, which is not allowed. For the whole session set the browser's
download folder to `$PC/browser-downloads` (create it: `mkdir -p "$PC/browser-downloads"`):
Chrome: Settings, Downloads, Location, Change, and turn on "Ask where to save each file" as a
second safeguard; Safari: Settings, General, "File download location", Other. Restore the
setting after Part 9. If a file does land in `~/Downloads` anyway, move it to the drive and
delete the original immediately.

### 0.3 AWS sign-in **[ANDRES]**

```bash
aws sso login --profile meridians-admin
AWS_PROFILE=meridians-admin aws sts get-caller-identity --query Account --output text
```
Success: prints `486243787301`.

### 0.4 RDS CA bundle (one time; already present at `~/.postgresql/rds-ca.pem` on 2026-10-12)

```bash
shasum -a 256 ~/.postgresql/rds-ca.pem
cat infra/pins/rds-global-bundle.sha256     # the two hashes must match
```

### 0.5 The shell session block (paste into EVERY new terminal)

This reads secrets into the shell **without printing them**. It deliberately loads only the
`SUPABASE_*` names from `.env`, never the `AWS_*` keys that also sit in that file (those would
override your SSO login). Run from the worktree root.

```bash
cd /Users/andressantos/Desktop/work_in_progress/NS_Proccess_QB/.claude/worktrees/aws-migration
export AWS_PROFILE=meridians-admin AWS_REGION=us-east-1
unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN
export PATH=/Users/andressantos/Desktop/work_in_progress/NS_Proccess_QB/venv/bin:$PATH

PC=/Volumes/MeridianPHI/Meridian/practice-cutover-1-$(date +%F)   # same date all day
mkdir -p "$PC" && chmod 700 "$PC"; touch "$PC/practice.log"
MIRROR="$PC/storage-mirror"
RH="$PC/je"
CA="$HOME/.postgresql/rds-ca.pem"
DB_ID=meridian-production-rds-main
LOCAL_PORT=55432
POOL=us-east-1_ujocY5rc9                       # meridian-production-auth-users
ENVF=/Users/andressantos/Desktop/work_in_progress/NS_Proccess_QB/.env

# Supabase names only, values never echoed. Needs: SUPABASE_URL, SUPABASE_SERVICE_KEY, SUPABASE_DB_URL
eval "$(python3 - "$ENVF" <<'PY'
import shlex, sys
from dotenv import dotenv_values
for k, v in dotenv_values(sys.argv[1]).items():
    if k in ("SUPABASE_URL", "SUPABASE_SERVICE_KEY", "SUPABASE_DB_URL") and v:
        print(f"export {k}={shlex.quote(v)}")
PY
)"
case "$SUPABASE_DB_URL" in *:6543/*) echo "STOP: that is the transaction pooler; use the session pooler (port 5432)";; esac
```
Success: no output (no STOP line). Check the names exist without printing values:
`grep -o '^SUPABASE_[A-Z_]*=' "$ENVF"` should list `SUPABASE_URL=`, `SUPABASE_SERVICE_KEY=`,
`SUPABASE_DB_URL=`.

### 0.6 Prove Supabase is reachable and only read **[read-only on a live system]**

```bash
psql "$SUPABASE_DB_URL" -XAtqc 'select 1'
psql "$SUPABASE_DB_URL" -XAtqc 'select count(*) from auth.users'   # 14 invitable users on 2026-10-12
```
Success: `1`, then a small number. Your own login address must be among those users (Step 7
needs it); check by sending the address through `--only` in the dry run later, never by
printing the table.

### 0.7 Confirm production is the empty, healthy shape this run expects **[ANDRES, read-only]**

```bash
for s in dr vpc data edge auth compute observability; do
  printf '%-14s' $s; aws cloudformation describe-stacks --stack-name meridian-production-$s \
    --query 'Stacks[0].StackStatus' --output text --region us-east-1 2>&1 | tail -1
done
aws cloudformation describe-stacks --stack-name meridian-shared-dns --query 'Stacks[0].StackStatus' --output text
aws rds describe-db-instances --db-instance-identifier $DB_ID \
  --query 'DBInstances[0].[DBInstanceStatus,EngineVersion]' --output text
aws cognito-idp describe-user-pool --user-pool-id $POOL --query 'UserPool.EstimatedNumberOfUsers' --output text
```
Success: every stack `CREATE_COMPLETE` or `UPDATE_COMPLETE` (**`dr` lives in `us-west-2`**
and shows `meridian-production-dr` there — add `--region us-west-2` for that one), RDS
`available 17.9`, Cognito `0`. Verified 2026-10-12: all true.

---

## Part 1. Give your laptop a way into the private database (Blocker B1) **[ANDRES, AWS write]**

`db-access.md` is the method: AWS Systems Manager Session Manager through a zero-ingress
instance named `meridian-production-ec2-ops`. It lives in the **edge** stack behind
`createOpsInstance`, default **false** in production. The security group chain already exists
(`sg-02602527d160f3c08` "ops" is admitted by `sg-0fae022113f9f39da` "data" on 5432; verified).

### 1.1 Preview the change: it must add ONLY the ops instance

Run from `infra/`. The four values are verified: the hosted zone, the CloudFront prefix list,
and the production origin-verify version (the secret has exactly one version) — they are the
ones the 2026-10-12 first production deploy used (`rotate-origin-verify-secret.md`, "Production:
resolved version id").

```bash
cd infra
npx cdk diff meridian-production-edge -c env=production \
    -c hostedZoneId=Z0621688X1CV6X15E2QH \
    -c cloudfrontPrefixListId=pl-3b927c52 \
    -c originVerifyActiveVersion=AWSCURRENT \
    -c originVerifyCloudFrontVersionId=2fd2fe21-06ef-62b6-6f10-08bb677a8806 \
    -c createOpsInstance=true
cd ..
```
Success: the diff lists new resources named `Ops...` (an IAM role `OpsInstanceRole`, an
instance profile, a launch template named `OpsInstanceProductionLaunchTemplate`, and the
instance `OpsInstanceProduction`) **plus exactly one change to the CloudFront distribution**:
the `X-Origin-Verify` custom-origin header, whose value source moves from the `AWSCURRENT`
label to the explicit secret version id `2fd2fe21-06ef-62b6-6f10-08bb677a8806`. It is the
**same secret value** (the secret has one version), so CloudFront keeps sending the same header
and there is no outage; the distribution redeploys in a few minutes. (Checked 2026-10-12 by
synthesizing the template and diffing it against the live one: nothing else differs.) **Stop
if the diff shows anything else:** any other property of the distribution, the host-router
function, ALB listener rules, WAF, the ALB security group, a Route 53 record, or a header value
that is not that version id. That means a `-c` value is wrong or an edge flag from the first
deploy is missing; do not deploy through it. The launch template name is deliberately
production-specific: staging's edge stack already owns `OpsInstanceLaunchTemplate` in this
account and region, and reusing it would fail the create. (Per `CLAUDE.md`, a fresh no-context
reviewer should check this diff against the live account before you run 1.2.)

### 1.2 Deploy (2-5 min)

```bash
cd infra
npx cdk deploy meridian-production-edge --exclusively -c env=production \
    -c hostedZoneId=Z0621688X1CV6X15E2QH \
    -c cloudfrontPrefixListId=pl-3b927c52 \
    -c originVerifyActiveVersion=AWSCURRENT \
    -c originVerifyCloudFrontVersionId=2fd2fe21-06ef-62b6-6f10-08bb677a8806 \
    -c createOpsInstance=true --require-approval never
cd ..
```
Success: stack `UPDATE_COMPLETE` (CloudFront finishes redeploying a few minutes after), and
`curl -s -o /dev/null -w '%{http_code}\n' https://app.meridiansgrp.com/api/v1/health` still
prints `200` (it did on 2026-10-12).
**Rollback:** redeploy with `-c createOpsInstance=false`. That removes the ops resources; the
CloudFront header stays on the explicit version id (same value).

### 1.3 Find the instance and wait for it to register

```bash
OPS_ID=$(aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=meridian-production-ec2-ops" "Name=instance-state-name,Values=running" \
  --query 'Reservations[0].Instances[0].InstanceId' --output text); echo "$OPS_ID"
aws ssm describe-instance-information --query "InstanceInformationList[?InstanceId=='$OPS_ID'].PingStatus" --output text
DB_HOST=$(aws rds describe-db-instances --db-instance-identifier $DB_ID \
  --query 'DBInstances[0].Endpoint.Address' --output text); echo "$DB_HOST"
```
Success: an `i-...` id, `Online` (can take 2-5 minutes after the deploy), and the host
`meridian-production-rds-main.ck3i4mk8ogdk.us-east-1.rds.amazonaws.com`. If `TargetNotConnected`
later, see the troubleshooting table in `db-access.md`.

---

## Part 2. Open the tunnel and make the empty database **[ANDRES]**

### 2.1 Tunnel (leave this terminal running; do everything else in a second terminal)

```bash
aws ssm start-session --target "$OPS_ID" \
  --document-name AWS-StartPortForwardingSessionToRemoteHost \
  --parameters "{\"host\":[\"$DB_HOST\"],\"portNumber\":[\"5432\"],\"localPortNumber\":[\"$LOCAL_PORT\"]}"
```
Success: "Waiting for connections...". It must stay open for Parts 2-6 and 9. If port 55432
is already taken: `pkill -f session-manager-plugin`.

### 2.2 In the second terminal: paste the 0.5 block, then the database secrets

These stay in the shell's environment only; never print them, never put them on a command
line.

```bash
secret_pw() { aws secretsmanager get-secret-value --secret-id "$1" --query SecretString --output text \
  | python3 -c 'import json,sys; s=sys.stdin.read().strip()
try: print(json.loads(s)["password"])
except Exception: print(s)'; }

DB_HOST=$(aws rds describe-db-instances --db-instance-identifier $DB_ID --query 'DBInstances[0].Endpoint.Address' --output text)
PGPASSWORD="$(secret_pw "$(aws rds describe-db-instances --db-instance-identifier $DB_ID --query 'DBInstances[0].MasterUserSecret.SecretArn' --output text)")"
MERIDIAN_APP_DB_PASSWORD="$(secret_pw meridian-production-secret-db-app)"
MERIDIAN_PHI_DB_PASSWORD="$(secret_pw meridian-production-secret-db-phi)"
MERIDIAN_PHI_HMAC_KEY="$(secret_pw meridian-production-secret-phi-hmac-key)"
export PGPASSWORD MERIDIAN_APP_DB_PASSWORD MERIDIAN_PHI_DB_PASSWORD MERIDIAN_PHI_HMAC_KEY
unset POSTGRES_URL DATABASE_URL

# host = the RDS name (so verify-full checks the right certificate); hostaddr = the tunnel.
kv() { echo "host=$DB_HOST hostaddr=127.0.0.1 port=$LOCAL_PORT dbname=$1 user=meridian_migrator sslmode=verify-full sslrootcert=$CA"; }
TARGET="$(kv meridian)"
export MERIDIAN_DATABASE_URL="postgresql://meridian_migrator@$DB_HOST:$LOCAL_PORT/meridian?hostaddr=127.0.0.1&sslmode=verify-full&sslrootcert=$CA"
export MERIDIAN_SOURCE_URL="$SUPABASE_DB_URL" MERIDIAN_TARGET_URL="$TARGET"
psql "$(kv postgres)" -XAtqc 'select current_user, version()'
```
Success: `meridian_migrator` and `PostgreSQL 17.9`. Failure `certificate verify failed`: redo
0.4; never lower `sslmode` (rule from `db-access.md`).

### 2.3 Create the `meridian` database (it does not exist yet)

```bash
psql "$(kv postgres)" -XAtqc "select count(*) from pg_database where datname='meridian'"   # expect 0
psql "$(kv postgres)" -Xqc 'create database meridian'
```
Success: `CREATE DATABASE`. (If the first query says `1`, a previous attempt left one:
that is a reset case, go to Part 9.2, then come back.)

### 2.4 Alembic to 0003 (about 2 min)

```bash
python3 -m alembic -c migrations/alembic.ini upgrade 0003_rds_adaptations
psql "$TARGET" -XAtqc 'select version_num from alembic_version'
```
Success: `0003_rds_adaptations`. This revision creates the app roles from
`MERIDIAN_APP_DB_PASSWORD` / `MERIDIAN_PHI_DB_PASSWORD` and the `pgcrypto` extension.
Log the time in `$PC/practice.log`.

---

## Part 3. Freeze nothing, but pull the inputs and make the OLD payroll JEs **[read-only on Render/Supabase]**

On the real day Render is frozen. In the practice it is **not**: Render keeps serving, so the
parity numbers can drift if anyone saves anything. Tell the other user not to edit the
roster, mappings or settings, and not to book, until Part 5 is finished.

### 3.1 Dry-run the storage mirror, then pull it (read-only on Supabase)

```bash
python3 scripts/mirror_supabase_storage.py --dest "$MIRROR"             # dry run: writes nothing
python3 scripts/mirror_supabase_storage.py --dest "$MIRROR" --apply     # downloads (a few minutes)
```
Success: the dry run ends with one count per key shape; on 2026-10-12 the inventory was 158
objects (outputs 67 + 11 + 16, uploads 64). `--apply` prints no `DOWNLOAD-MISMATCH` and writes
`$MIRROR/.manifest.json`. Layout: `$MIRROR/artifacts/<key>` and `$MIRROR/phi/<key>`. The
script refuses a `--dest` inside the repo, Desktop or Downloads; your path is fine.

### 3.2 Find the two rehearsal inputs

The uploads bucket goes to `$MIRROR/phi/`. Find the org and day with the query from
`cutover.md` §B(a) (read-only):

```bash
mkdir -p "$RH"/{old,new}/{mx-payroll,qb-usa-payroll}
psql "$SUPABASE_DB_URL" -XA -F' | ' -c \
  "SELECT b.id, b.batch_type, b.org_id, b.created_at::date AS day, b.input_file, r.process, r.run_id
     FROM public.import_batches b
     LEFT JOIN public.process_runs r ON r.batch_id = b.id AND r.org_id = b.org_id
    WHERE b.id IN (89, 91) ORDER BY b.id;"
find "$MIRROR/phi" -path '*mx-payroll*' -o -path '*qb-usa-payroll*' | sort | head -40
```
Success: batch 91 is MX payroll FY26-P09; its workbook is the file in
`$MIRROR/phi/<org_id>/mx-payroll/<day>/` whose name ends with `input_file` (spaces became
`_`). Batch 89 is QB USA FY26-P09; its run folder `<org_id>/qb-usa-payroll/<day>/<run_id>/`
must hold **8 CSVs** (fewer means the wrong `run_id`; the upload can sit on the day before).
The superseded MX batches 87, 88, 90 are the same period — use 91's file.

### 3.3 OLD side: run both on Render, do NOT press Book

On `https://www.meridiansgrp.com`, screens `/processes/mx-payroll/new` and
`/processes/qb-usa-payroll/new`: upload the files from 3.2, period **FY26-P09**, and write
every parameter you type (exchange rate, accrual days...) in `$PC/practice.log`, because 3.8
must use the same ones. Run it. Download the JE CSVs (the browser saves to `$PC/browser-downloads`, see 0.2) and move them into
`$RH/old/mx-payroll/` and `$RH/old/qb-usa-payroll/`. An unbooked run expires on its own. Do not open any QuickBooks
screen.
Success: CSV files in both `old` folders. Do this before Part 4's dump and the same day (the
diff compares same-day runs on purpose: payroll code changed since September).

---

## Part 4. Dump Supabase (read-only), restore, split, parity **[ANDRES]**

### 4.1 Dump (about 1-2 min; 11 MB on staging day)

```bash
DUMP="$PC/meridian-practice-$(date +%Y%m%d-%H%M).dump"
pg_dump --schema=public --data-only --no-owner --no-privileges \
        --exclude-table=public.alembic_version \
        --exclude-table=public.trial_migrations \
        --exclude-table=public.qgenda_workspaces \
        -Fc -f "$DUMP" "$SUPABASE_DB_URL"
chmod 600 "$DUMP"; shasum -a 256 "$DUMP" | tee -a "$PC/practice.log"
```
The dump is `--schema=public`, so `mart` and `analytics` are already excluded; keep them
out of any other dump (`--exclude-schema=mart --exclude-schema=analytics`): they are a
rebuildable copy of the outside eCW mart, refilled by the nightly loader (`ecw-mart.md` §5).
Success: a file of several MB and a hash line. **This file is PHI.** It never leaves the
drive. Same flags as `scripts/staging_data_load.sh` (the proven path).

### 4.2 Restore (one transaction; about 2-4 min)

```bash
RESTORE_OPTS=""
psql "$TARGET" -XAtqc 'set session_replication_role = replica' >/dev/null 2>&1 \
  && RESTORE_OPTS="-c session_replication_role=replica"
echo "restore mode: ${RESTORE_OPTS:-triggers on}"
PGOPTIONS="$RESTORE_OPTS" pg_restore --data-only --no-owner --no-privileges \
  --single-transaction --exit-on-error -d "$TARGET" "$DUMP"
```
Success: no error. Any error rolls the whole restore back; nothing is left half-loaded. If
`pg_restore` reports a duplicate key, the database was not empty: Part 9.2, then redo from 2.3.

Then set every sequence past its table maximum (copy of the staging script's loop):

```bash
psql "$TARGET" -Xq -v ON_ERROR_STOP=1 <<'SQL'
DO $$
DECLARE r record; seq text; mx bigint;
BEGIN
  FOR r IN
    SELECT c.relname FROM pg_class c
      JOIN pg_namespace n ON n.oid = c.relnamespace
      JOIN pg_attribute a ON a.attrelid = c.oid AND a.attname = 'id' AND a.attnum > 0
       AND NOT a.attisdropped AND a.atttypid IN ('int2'::regtype, 'int4'::regtype, 'int8'::regtype)
     WHERE n.nspname = 'public' AND c.relkind = 'r'
  LOOP
    seq := pg_get_serial_sequence(format('public.%I', r.relname), 'id');
    IF seq IS NOT NULL THEN
      EXECUTE format('SELECT coalesce(max(id), 1) FROM public.%I', r.relname) INTO mx;
      PERFORM setval(seq, mx);
    END IF;
  END LOOP;
END $$;
SQL
```
Success: `DO`, no error.

### 4.3 PHI split (about 1 min)

`MERIDIAN_PHI_HMAC_KEY` is already in your environment from 2.2 (the production secret — the
**same key the real cutover will use**, so patient tokens are identical).

```bash
python3 scripts/split_phi.py --dry-run --database-url "$TARGET"     # prints SQL, connects to nothing
python3 scripts/split_phi.py --database-url "$TARGET"
```
Success: it finishes with no error and no key in the output. Safe to run twice.

### 4.4 Parity at 0003, global (about 3-6 min)

```bash
python3 scripts/verify_parity.py --at 0003 --json > "$PC/parity-0003.json"; echo "exit $?"
```
Success: **exit 0**. Any non-zero exit prints
`ABORT: the load is not a parity match. Do not cut over.` On the practice, a small difference
in the tables people write to (`import_batches`, `process_runs`, `audit_log`, `artifact_downloads`)
means someone used Render during the run: note it, and redo from Part 9.2 once the other
user has stopped. A difference anywhere else is a real finding; stop and read
`python3 scripts/verify_parity.py --at 0003 --failures-only`.
`null_org_rows` must be zero on both sides.

### 4.5 Alembic to head (about 1-2 min; **this is the schema change of the day**)

```bash
python3 -m alembic -c migrations/alembic.ini upgrade head
psql "$TARGET" -XAtqc 'select version_num from alembic_version'
```
Success: `0037_drop_wearbly_tables`. It applies RLS (0004), drops the identifier columns after
checking the split ran (0005), then 0006-0037. If 0005 says "N of M rows have a NULL
patient_ref" the split did not run on this database: nothing was dropped, go back to 4.3.
Revision 0032 refuses if Supabase still has rows in `clients/invoices/invoice_counters`
(checked 2026-10-07 staging; check again: `select count(*) from public.invoices` on Supabase).

### 4.6 Parity at head, per organisation (about 3-6 min)

```bash
python3 scripts/verify_parity.py --at head --json > "$PC/parity-head.json"; echo "exit $?"
```
Success: **exit 0**. (Copy both JSONs to the repo `reports/` folder only if you want them
as evidence; they hold counts, sums, md5s and booleans, no row values.)

### 4.7 Remove the QuickBooks connection from the production COPY (practice only)

Run this **after** 4.6, never before: parity compares row counts and sums, and
`qbo_connection` is one of the compared tables. This step exists only because the practice
copy sits on a live AWS stack; **the real cutover decides this separately** (it has to keep the
connection or have you reconnect, and a deleted connection means reconnecting QuickBooks).

What exists (checked in `migrations/` and `supabase_migrations/` 2026-10-12):
`public.qbo_connection` is the only table holding QuickBooks tokens. There is no QBO webhook
table. The OAuth `state` handle is parked in `public.auth_pending_challenge`, which Supabase
never had, so the dump cannot have filled it. `audit.qbo_connection_change` is created fresh
on RDS and is append-only (a delete there is refused by design); it is empty after the copy.

`qbo_connection` has `FORCE ROW LEVEL SECURITY` since revision 0004, and `FORCE` applies to
the table owner too, so `meridian_migrator` sees **zero rows** unless `app.org_id` is set. The
block below sets it for each organization in turn (transaction-local), deletes, and prints the
counts. `public.organizations` is exempt from `FORCE` (it is the tenant itself), so the loop
can read it.

```bash
psql "$TARGET" -X -v ON_ERROR_STOP=1 <<'SQL'
DO $$
DECLARE o record; n bigint; total bigint := 0;
BEGIN
  FOR o IN SELECT id FROM public.organizations LOOP
    PERFORM set_config('app.org_id', o.id::text, true);   -- true = this transaction only
    DELETE FROM public.qbo_connection WHERE org_id = o.id;
    GET DIAGNOSTICS n = ROW_COUNT;
    total := total + n;
  END LOOP;
  RAISE NOTICE 'qbo_connection rows deleted: %', total;
END $$;
SQL
# verify it is empty for every org (same loop, read-only)
for org in $(psql "$TARGET" -XAtqc 'select id from public.organizations'); do
  PGOPTIONS="-c app.org_id=$org" psql "$TARGET" -XAtqc 'select count(*) from public.qbo_connection'
done
```
Success: `NOTICE: qbo_connection rows deleted: N` (N is the number of QuickBooks connections,
probably 1) and a `0` for every org in the check. Log N in `$PC/practice.log`. This touches only
the AWS copy; Supabase and Render are untouched, so Render's QuickBooks connection is exactly
as it was.

### 4.8 Webhooks: nothing to remove (checked, with a safety check)

`webhook_subscriptions`, `api_events` and `webhook_deliveries` are created by Alembic revision
0013, **on RDS only**; they do not exist in Supabase (`supabase_migrations/` and the baseline
dump have no such table), so the dump carries no subscriptions and no events. A subscription
only exists if a partner creates one through the partner API with an API client, and no API
client was copied. The webhook worker is not deployed in production (the cluster has only the
`api` and `web` services). So a payroll run on AWS cannot publish to a real partner endpoint.
Prove it rather than assume it:

```bash
for org in $(psql "$TARGET" -XAtqc 'select id from public.organizations'); do
  PGOPTIONS="-c app.org_id=$org" psql "$TARGET" -XAtqc \
    "select (select count(*) from public.webhook_subscriptions), (select count(*) from public.api_clients)"
done
```
Success: `0|0` for every org. If a subscription ever shows up, delete it the same way as 4.7
(`DELETE FROM public.webhook_subscriptions WHERE org_id = o.id`, inside the loop) before running
any payroll on AWS. Runs on AWS write `api_events` rows (ids only); they are deleted with the
database in Part 9.2.

---

## Part 5. Push the storage mirror to the production buckets **[ANDRES, AWS write]**

Buckets and keys verified: `meridian-production-s3-artifacts`, `meridian-production-s3-phi`,
KMS aliases `alias/meridian-production-kms-artifacts` and `alias/meridian-production-kms-phi`.
Both buckets are versioned and the policy **denies any put that is not KMS-encrypted with the
bucket's own key**, which is why the key ARN is passed.

```bash
ART_KEY=$(aws kms describe-key --key-id alias/meridian-production-kms-artifacts --query 'KeyMetadata.Arn' --output text)
PHI_KEY=$(aws kms describe-key --key-id alias/meridian-production-kms-phi --query 'KeyMetadata.Arn' --output text)

aws s3 sync "$MIRROR/artifacts/" s3://meridian-production-s3-artifacts/ \
    --sse aws:kms --sse-kms-key-id "$ART_KEY" --checksum-algorithm SHA256
aws s3 sync "$MIRROR/phi/" s3://meridian-production-s3-phi/ \
    --sse aws:kms --sse-kms-key-id "$PHI_KEY" --checksum-algorithm SHA256
```
Success: one `upload:` line per object, no errors. (`aws s3 sync` already ran with your SSO
login; the GuardDuty marker object `malware-protection-resource-validation-object` already in
the phi bucket is not yours — leave it.)

**5.1 Tag the raw uploads and sweep (all three blocks below are self-contained).** Each prints
a success line; any `TAG-FAILED`, `MISSING` or `CONTENT-MISMATCH` line means stop and look.
The commands are `cutover.md` 4b, 4c and 4d with this run's values filled in; the AWS flags
(`s3api get-object-tagging` / `put-object-tagging` with `--bucket --key --tagging`, `head-object
--checksum-mode ENABLED`) were checked against `--help` on 2026-10-12.

**5.1a Tag the objects that came from Supabase's `uploads` bucket** (so the phi bucket's
7-year rule treats them as raw uploads; `aws s3 sync` cannot tag). It merges with any existing
tags, because `put-object-tagging` replaces the whole set and GuardDuty may have added one:

```bash
python3 - "$MIRROR/.manifest.json" <<'PY' | tee -a "$PC/practice.log"
import json, subprocess, sys
n = bad = 0
for o in json.load(open(sys.argv[1])):
    if o['source_bucket'] != 'uploads':
        continue
    loc = ['--bucket', 'meridian-production-s3-phi', '--key', o['key']]
    n += 1
    got = subprocess.run(['aws', 's3api', 'get-object-tagging', *loc, '--output', 'json'],
                         capture_output=True, text=True)
    if got.returncode:
        bad += 1
        print('TAG-FAILED phi', o['key'])
        continue
    tags = [t for t in json.loads(got.stdout)['TagSet'] if t['Key'] != 'meridian:content']
    tags.append({'Key': 'meridian:content', 'Value': 'raw-upload'})
    r = subprocess.run(['aws', 's3api', 'put-object-tagging', *loc,
                        '--tagging', json.dumps({'TagSet': tags})],
                       capture_output=True, text=True)
    if r.returncode:
        bad += 1
        print('TAG-FAILED phi', o['key'])
print('tagged', n - bad, 'of', n, 'raw uploads')
PY
```
Success: `tagged N of N raw uploads` (N = 64 on 2026-10-12's inventory), no `TAG-FAILED`.

**5.1b `head-object` sweep: every stored path in the database must exist in S3.** The two
tables are under `FORCE` RLS at head, so the query runs once per organization with
`app.org_id` set through `PGOPTIONS` (without it the migrator reads zero rows and the sweep
would pass while checking nothing):

```bash
for org in $(psql "$TARGET" -XAtqc 'select id from public.organizations'); do
  PGOPTIONS="-c app.org_id=$org" psql "$TARGET" -XAtqc \
    "SELECT storage_path FROM public.qb_export_tie_out WHERE storage_path IS NOT NULL
     UNION ALL
     SELECT storage_path FROM public.qb_usa_payroll_journal WHERE storage_path IS NOT NULL"
done | tee "$PC/stored-paths.txt" | while IFS= read -r key; do
    sub=$(printf '%s' "$key" | awk -F/ 'NF>=4{print $3}')
    case "$sub" in journal_entries) b=artifacts ;; *) b=phi ;; esac
    aws s3api head-object --bucket "meridian-production-s3-$b" --key "$key" \
      >/dev/null 2>&1 || echo "MISSING $b $key"
  done | tee -a "$PC/practice.log"
wc -l < "$PC/stored-paths.txt"
```
Success: no `MISSING` line, and the `wc -l` count is greater than 0 (a 0 means the RLS setting
did not take and the sweep proved nothing: stop).

**5.1c Content check: every object in the manifest against the SHA-256 S3 stored at upload.**
(`--checksum-algorithm SHA256` in the sync above is what makes this possible; an SSE-KMS
object's ETag is not an MD5.)

```bash
python3 - "$MIRROR/.manifest.json" <<'PY' | tee -a "$PC/practice.log"
import base64, json, subprocess, sys
objs = json.load(open(sys.argv[1]))
bad = 0
for o in objs:
    b = o['dest']
    r = subprocess.run(['aws', 's3api', 'head-object', '--bucket', f'meridian-production-s3-{b}',
                        '--key', o['key'], '--checksum-mode', 'ENABLED', '--output', 'json'],
                       capture_output=True, text=True)
    want = base64.b64encode(bytes.fromhex(o['sha256'])).decode()
    head = json.loads(r.stdout) if r.returncode == 0 else {}
    if head.get('ChecksumSHA256') != want or head.get('ContentLength') != o['size']:
        bad += 1
        print('CONTENT-MISMATCH', b, o['key'])
print('checked', len(objs), 'manifest objects;', bad, 'mismatched')
PY
```
Success: `checked N manifest objects; 0 mismatched` (N about 158). A checksum ending in `-<n>` is a
multipart upload's checksum-of-parts and reads as a mismatch; the largest object is 0.6 MB, far
under the CLI's 8 MB multipart threshold, so if one shows, check that object by hand.

---

## Part 6. Confirm the running app sees the loaded database **[ANDRES, read-only checks]**

```bash
aws ecs describe-services --cluster meridian-production-ecs-main \
  --services meridian-production-ecs-svc-api meridian-production-ecs-svc-web \
  --query 'services[].[serviceName,desiredCount,runningCount,deployments[0].rolloutState]' --output text
curl -s -o /dev/null -w '%{http_code}\n' https://app.meridiansgrp.com/api/v1/health
```
Success: api `1 1`, web `2 2`, both `COMPLETED`, health `200` (all true 2026-10-12, before the
load). The tasks already run `DATABASE_BACKEND=postgres STORAGE_BACKEND=s3 AUTH_BACKEND=cognito
EMAIL_BACKEND=ses`, so **no redeploy is needed**: the running image `89e85a57` starts reading
the loaded database as soon as it is there. If the app complains about a stale connection,
force one new task: `aws ecs update-service --cluster meridian-production-ecs-main --service
meridian-production-ecs-svc-api --force-new-deployment` and wait with
`aws ecs wait services-stable ...` (3-6 min of api downtime; harmless, nobody uses it).

---

## Part 7. Sign in as yourself only — no real user is emailed **[ANDRES]**

Reality (verified): the production Cognito pool `meridian-production-auth-users`
(`us-east-1_ujocY5rc9`) has 0 users, sends mail through SES from `Meridian
<no-reply@meridiansgrp.com>` (SES is out of the sandbox, so a send really goes out), and MFA is
**on** (use an authenticator app for the TOTP).

### 7.1 Dry run — sends nothing (reads Supabase and the pool)

```bash
python3 scripts/invite_legacy_users.py --pool-id "$POOL"
```
Success: counts and domains only, `would invite` about 14, `MISMATCH 0`. **Do not run the
`--apply` form without `--only`.**

### 7.2 Invite only you

```bash
read -rs ADDRESS          # type YOUR own login address, press Enter (it is not echoed)
python3 scripts/invite_legacy_users.py --pool-id "$POOL" --only "$ADDRESS" \
    --apply --confirm-pool "$POOL"
unset ADDRESS
```
Success: `invited 1`, `failed 0`, `MISMATCH 0`. If it says no matching user, your address is not
in Supabase `auth.users` (re-type it, or use the address on your Supabase account). One email
arrives within a minute with a temporary password. It is valid 7 days; if it expired:
add `--resend` to the same command.

### 7.3 Sign in

Browser: `https://app.meridiansgrp.com/login`. Temporary password, then your name and a new
password, then set up the authenticator app (TOTP). Then:

| Check | Passes when |
|---|---|
| Land on the dashboard | You see your real org (not an empty "create organisation" page): this proves `custom:app_uid` matched your `org_members` row |
| `https://app.meridiansgrp.com/api/v2/me` (signed in) | 200, your `org_id` and role |
| Open a completed run from the list | Same totals Render shows for that run |
| Download one JE CSV and one workbook | The bytes arrive in `$PC/browser-downloads`, not `~/Downloads` (these write two `artifact_downloads` rows; they vanish in Part 9) |

Do not open any QuickBooks card or posting screen. If the mail never arrives: check spam,
then `aws sesv2 get-account --query ProductionAccessEnabled` (true on 2026-10-12).
Do not invite anyone else. Do not run `reissue_pending_invites.py` (it creates Cognito accounts
for every pending invitee).

---

## Part 8. NEW payroll runs and the line-by-line comparison **[ANDRES]**

### 8.1 NEW side: the same two inputs on AWS, do NOT press Book

On `https://app.meridiansgrp.com`, screens `/processes/mx-payroll/new` and
`/processes/qb-usa-payroll/new`: same files from `$MIRROR/phi/...`, period FY26-P09, **the
same parameters you logged in 3.3**. Download the JE CSVs (the browser saves to `$PC/browser-downloads`, see 0.2) and move them into
`$RH/new/mx-payroll/` and `$RH/new/qb-usa-payroll/`.
The roster and config the new side reads is the dump's copy of what Render read in 3.3, which
is why nobody may edit them between 3.3 and 4.1.

### 8.2 Diff (positional: OLD_DIR NEW_DIR)

```bash
python3 scripts/diff_je_output.py "$RH/old/mx-payroll"     "$RH/new/mx-payroll";     echo "exit $?"
python3 scripts/diff_je_output.py "$RH/old/qb-usa-payroll" "$RH/new/qb-usa-payroll"; echo "exit $?"
```
**Pass: exit 0 on both.** Exit 1 is a difference or a missing file on either side, and the
rehearsal has failed regardless of every green above: copy the redacted report (it holds a
salted digest per run, no names) into the log and do not reset until you have understood it,
because the data is what you will want to look at. The CSVs stay in `$RH` on the PHI drive.
Revenue has no stored input, so there is no revenue comparison (`cutover.md` open item).

---

## Part 9. RESET production to empty (so the real cutover starts clean)

**Is a reset needed? Yes, for the database.** `pg_restore --data-only` into a populated table
fails on the primary key, `alembic_version` would already be at head, and the real day's abort
rule is "drop and reload", never "top up". The S3 reset is strongly recommended (it keeps
practice PHI out of production and makes the 4c/4d counts on the real day mean something). The
Cognito delete is recommended (the real invite count then reads 14 invited, 0 already active).

**Irreversible items are marked [IRREVERSIBLE].** Everything deleted here is a copy of data
that Supabase and Render still hold untouched.

### 9.1 Do not reset until you have the evidence you need

Make sure `$PC` holds: both parity JSONs, the diff outputs, the practice log with times, and
your notes. Optionally copy the two parity JSONs to the repo `reports/` folder.

### 9.2 Empty the database **[ANDRES, IRREVERSIBLE on the copy]**

Stop the api so nothing is connected, drop and recreate (RDS stays; **deletion protection is
on and is not involved**, only the `meridian` database inside it is dropped). The roles
(`meridian_app`, `phi_access`, ...) are cluster-level and survive; Alembic 0003 re-creates what
it needs, as it did in the staging `--fresh` reloads.

```bash
aws ecs update-service --cluster meridian-production-ecs-main --service meridian-production-ecs-svc-api --desired-count 0
aws ecs wait services-stable --cluster meridian-production-ecs-main --services meridian-production-ecs-svc-api

psql "$(kv postgres)" -Xqc 'drop database meridian with (force)'
psql "$(kv postgres)" -XAtqc "select count(*) from pg_database where datname='meridian'"   # expect 0

aws ecs update-service --cluster meridian-production-ecs-main --service meridian-production-ecs-svc-api --desired-count 1
aws ecs wait services-stable --cluster meridian-production-ecs-main --services meridian-production-ecs-svc-api
```
Success: `DROP DATABASE`, count `0`, api back to `1 1`.

**Alarm and autoscaling check (read-only, 2026-10-12).** Setting the api to 0 does not trigger
autoscaling: no ECS service in `meridian-production-ecs-main` has an Application Auto Scaling
target (`describe-scalable-targets` for ECS returned nothing), so `desired-count` stays where
you put it. It does have one alarm: `meridian-production-alarm-api-task-count` (state `OK`,
wired to the alert topic) goes into alarm after **3 of 4 five-minute periods** with fewer than
1 running task, and a missing metric counts as breaching. So keep the api at 0 for **well under
15 minutes** (the three commands above take a few minutes) and an alert email will not fire; if
you stay at 0 longer it will, and it clears itself when the api is back. The worker service is
not deployed in production, so no worker alarm applies. The cutover runbook expects the
production api to run **exactly one** task until Phase 11 (two is an alarm), so make sure the
count you restore is 1. The database is gone, so the api returns 5xx on data routes until the
real load; `/api/v1/health` stays `200`. To end this exactly as you found it (a `meridian`
database does not exist), do **not** run `create database` now: Step 2.3 does that on the
real day.

### 9.3 Empty both buckets of the practice objects **[ANDRES, IRREVERSIBLE on the copy]**

Both buckets are versioned, so a plain delete leaves hidden versions with the PHI. This
removes every version and delete marker **except** the GuardDuty validation object
(`malware-protection-resource-validation-object` in the phi bucket, which is not yours).
Check the count first:

```bash
python3 - <<'PY'
import boto3
s3 = boto3.Session(profile_name="meridians-admin", region_name="us-east-1").client("s3")
KEEP = {"malware-protection-resource-validation-object"}
for b in ("meridian-production-s3-artifacts", "meridian-production-s3-phi"):
    n = 0
    for page in s3.get_paginator("list_object_versions").paginate(Bucket=b):
        objs = [{"Key": v["Key"], "VersionId": v["VersionId"]}
                for v in page.get("Versions", []) + page.get("DeleteMarkers", [])
                if v["Key"] not in KEEP]
        if objs:
            s3.delete_objects(Bucket=b, Delete={"Objects": objs, "Quiet": True})
            n += len(objs)
    print(b, "removed", n, "versions/markers")
PY
```
Then verify: both listings show 0 objects (phi shows only the one GuardDuty marker):
`aws s3api list-object-versions --bucket meridian-production-s3-phi --query 'length(Versions||`[]`)'`.
(Neither bucket has Object Lock; both policies allow deletes — verified. The dr-region copy is
not touched by this practice; check `meridian-production-s3-*` replicas in `us-west-2` only if
cross-region replication is on: `aws s3api get-bucket-replication --bucket meridian-production-s3-phi`.)

### 9.4 Remove your Cognito test user **[ANDRES, IRREVERSIBLE; recreated by the real invite]**

```bash
read -rs ADDRESS
aws cognito-idp admin-delete-user --user-pool-id "$POOL" --username "$ADDRESS"
unset ADDRESS
aws cognito-idp describe-user-pool --user-pool-id "$POOL" --query 'UserPool.EstimatedNumberOfUsers' --output text
```
Success: `0` (the count can lag a few minutes). Only your own user exists, so nothing else can
be deleted by this. (If you skip it, the real invite reports you as "already active" with
the password you set today; harmless, but the counts read differently.)

### 9.5 Clean the laptop **[IRREVERSIBLE]**

```bash
pkill -f session-manager-plugin            # closes the tunnel
rm -rf "$PC"                                # the dump, mirror, JE CSVs, parity JSONs, log
                                            # (rm only unlinks; the encrypted volume of 0.2 is what makes it safe)
unset PGPASSWORD MERIDIAN_APP_DB_PASSWORD MERIDIAN_PHI_DB_PASSWORD MERIDIAN_PHI_HMAC_KEY \
      SUPABASE_SERVICE_KEY SUPABASE_DB_URL MERIDIAN_DATABASE_URL MERIDIAN_SOURCE_URL MERIDIAN_TARGET_URL
aws ssm describe-sessions --state Active --query 'Sessions[].SessionId' --output text   # expect empty
```
Then confirm the browser never left a copy in the default folder, and put the browser's
download setting back:

```bash
ls -lt ~/Downloads | head -20     # no payroll CSV, workbook, JE or dump from today
find ~/Downloads -mtime -1 \( -iname '*payroll*' -o -iname '*JE_*' -o -iname '*.csv' -o -iname '*.xlsx' -o -iname '*.dump' \) -print
```
Success: the `find` prints nothing. Anything it lists from today: move it into `$PC` before the
`rm -rf` above (or delete it now), and empty the Trash. Also check the Trash for the same
files.

Do this only after you have copied the timings and conclusions to a safe place (the repo's
`docs/runbooks/cutover.md` timings table and `data-load.md` timings table: numbers only, no
PHI). Skip this if you want the dump kept as the dump for the real day: the real run takes a
fresh dump of a frozen source anyway, so keeping it has no value and only a second copy of PHI.

### 9.6 Prove production is back to the pre-practice state

```bash
aws ecs describe-services --cluster meridian-production-ecs-main \
  --services meridian-production-ecs-svc-api meridian-production-ecs-svc-web \
  --query 'services[].[serviceName,desiredCount,runningCount]' --output text      # api 1 1, web 2 2
aws cognito-idp describe-user-pool --user-pool-id $POOL --query 'UserPool.EstimatedNumberOfUsers' --output text   # 0
curl -s -o /dev/null -w '%{http_code}\n' https://app.meridiansgrp.com/api/v1/health                    # 200
```
The ops instance **stays** (the real cutover needs it): `meridian-production-ec2-ops`.
To remove it instead: redeploy `meridian-production-edge` with the same four `-c` values and
`-c createOpsInstance=false`.

---

## What can NOT be reset (the honest list)

* RDS automated backups taken during the window (7-day retention), and any AWS Backup recovery
  points from that day. The backup vault is under Vault Lock with a **minimum retention of 35
  days and a maximum of 400**, and the lock is past its 3-day cooling-off, so a recovery point
  cannot be deleted early by anyone, including root: it exists for at least 35 days. They
  expire on their own schedule.
* `/aws/rds/instance/meridian-production-rds-main/postgresql` log lines (400 days).
* CloudTrail and S3 access records of the practice.
* The ops instance (if you keep it, intentionally).

None of these is a new category of exposure: they are the same stores the real data will live
in after the real cutover.

---

## What this practice does NOT prove (do these on the real day)

* Render freeze, suspension of `meridian-api`, and the in-flight-run check (`cutover.md` step 2).
* The DNS flip (7a/7c), SOA lowering, redirects, the dark window.
* Parity on a **frozen** source: today Render stays live, so any difference in a table people
  write to is explained by drift, not by the procedure.
* `source_transactions` already living in `phi` (Blocker B3).
* Revenue JE comparison (no stored input).

---

## Timings — fill this in (then copy into `cutover.md` and `data-load.md`)

| Part | Start | End | Minutes | Notes |
|---|---|---|---|---|
| 1 ops instance | | | | |
| 2 tunnel, create db, 0003 | | | | |
| 3 mirror pull + OLD runs | | | | |
| 4.1 dump | | | | |
| 4.2 restore + setval | | | | |
| 4.3 split | | | | |
| 4.4 parity 0003 | | | | |
| 4.5 alembic head | | | | |
| 4.6 parity head | | | | |
| 5 S3 push + sweeps | | | | |
| 7 invite + sign-in | | | | |
| 8 NEW runs + diff | | | | |
| 9 reset | | | | |
| **Total** | | | | |

Rows loaded (transactions / journal_entries): ______  Parity 0003: pass / fail  Parity head: pass / fail
MX diff: exit __  QB USA diff: exit __
