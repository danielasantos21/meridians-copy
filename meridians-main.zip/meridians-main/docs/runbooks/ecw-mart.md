# Runbook — the eCW data mart on AWS (nightly copy into RDS)

**Covers:** putting the eClinicalWorks data mart's BI tables into our own RDS database
(schemas `mart` and `analytics`) so Reports & dashboards and Ask Meridian show numbers on AWS.
**Decision:** `docs/adr/0053-ecw-mart-on-rds.md`. **Tracker rows:** T:253, T:256, T:258.
**Executed:** _never. Code and infra are built and merged on the AWS branch; nothing below has
been run against a real account. The date of the first run goes here._

> **Every AWS command below is "Andres runs; independent checker reviews first."** Before you
> paste any deploy, `alembic` or `aws ecs run-task` line, a separate reviewer (no shared
> context) runs the infra tests and `cdk synth` and checks the synthesized template against the
> live account with read-only AWS calls (policy ARNs exist, no name collisions, context and
> region right, cost). Run staging first, production second, same steps.

Jargon, once: the **data mart** is the outside Postgres server that eClinicalWorks (eCW)
feeds; we may only read it. The **loader** is `scripts/sync_data_mart.py`, which copies 11
tables from it into schema `mart` of our database, with patient-identifying columns left out.
The **analytics views** (`sql/analytics/*.sql`, applied by `scripts/apply_analytics_views.py`)
are what the app actually queries. `meridian_mart_owner` is the login the loader uses;
`meridian_mart_reader` is the read-only login the api uses. An **allowlist** is the list of
addresses the data mart server accepts connections from.

## 1. What it is

* **Source:** the data mart named in the hand-made secret `meridian-<env>/ecw-db` (the same
  one `-c ecwDb=true` uses for the P&L run). Read-only, three ways (see the docstring of
  `scripts/sync_data_mart.py`).
* **Target:** RDS database `meridian`, schema `mart` (the 11 tables in
  `scripts/mart_target.py` `RDS_TABLES`, plus `mart._sync_log`) and schema `analytics`
  (views, plus today's `mart_snap_*` snapshot rows).
* **Logins** (Alembic `migrations/versions/0048_ecw_mart.py`): `meridian_mart_owner` (loader)
  and `meridian_mart_reader` (api). Passwords live in `meridian-<env>-secret-db-mart-owner`
  and `meridian-<env>-secret-db-mart-reader`, created by the data stack
  (`infra/meridian/stacks/data.py`).
* **Nightly job:** `meridian-<env>-ecs-mart-sync` (api image, ARM64, 0.5 vCPU / 1 GB), started
  by EventBridge Scheduler `meridian-<env>-schedule-mart-sync` at 05:00 Central
  (`infra/meridian/stacks/mart.py`). Logs: `/meridian/<env>/ecs/mart-sync`.
* **Audit:** every read of the mart by the app writes an `audit.phi_access` row with action
  `ecw_mart_read`.
* **Switch:** `-c ecwMart=true -c ecwOrgId=<uuid>` on the compute deploy
  (`infra/meridian/config.py`). Optional `-c ecwMartSourceSslMode=require` if the source
  server's certificate does not verify (default `verify-full`; nothing weaker is accepted).

## 2. Deploy order (staging first, then production)

Set the environment once per terminal (use `staging` or `production`):

```bash
export AWS_PROFILE=meridians-admin AWS_REGION=us-east-1 ENV=staging
```

### Step 1 — Confirm the NAT address with the data mart's owner

The data mart only accepts listed addresses. Ours is `meridian-<env>-eip-nat`; the mart owner
must have it on the allowlist (staging 34.192.149.110, production 34.197.50.9 as of 2026-10-18):

```bash
aws ec2 describe-addresses --filters "Name=tag:Name,Values=meridian-$ENV-eip-nat" \
  --query 'Addresses[].PublicIp' --output text
```

The proof that it works comes after step 4 (the P&L gate before step 5): the live api has no
`ECW_ORG_ID` until compute is deployed with the mart flags, so a P&L run cannot pass before then.

### Step 2 — Deploy the data stack (creates the two secrets)

Andres runs; independent checker reviews first. **The data deploy needs no mart flags**: the
data stack is identical whether or not `-c ecwMart=true` is used (it always exports the two
secret ARNs under fixed names, `meridian-<env>-data-DatabaseMart{Owner,Reader}SecretArn`, and
compute imports them by name only when the flag is on). So it can be deployed, and redeployed
later, without the flags; only the compute deploy carries them.

```bash
scripts/staging_deploy.sh data          # staging; production is by hand, one stack at a time
aws secretsmanager describe-secret --secret-id meridian-$ENV-secret-db-mart-owner  --query Name --output text
aws secretsmanager describe-secret --secret-id meridian-$ENV-secret-db-mart-reader --query Name --output text
```

Both names must print. The stack only adds two secrets; no role exists in Postgres yet.

### Step 3 — Snapshot, then Alembic to head (through the SSM tunnel)

**Run steps 3, 4 and 5 in one sitting.** On staging the database is normally STOPPED by the
schedule `meridian-staging-schedule-rds-stop` (02:00 UTC), so start it first and wait until it
is available (it stays up for the sitting; production is never stopped):

```bash
aws rds describe-db-instances --db-instance-identifier meridian-$ENV-rds-main \
  --query 'DBInstances[0].DBInstanceStatus' --output text
# staging, if it says "stopped":
aws rds start-db-instance --db-instance-identifier meridian-$ENV-rds-main
aws rds wait db-instance-available --db-instance-identifier meridian-$ENV-rds-main
```

Andres runs; independent checker reviews first. Take a manual RDS snapshot first so there is a
named recovery point:

```bash
aws rds create-db-snapshot --db-instance-identifier meridian-$ENV-rds-main \
  --db-snapshot-identifier meridian-$ENV-before-ecw-mart-$(date +%Y%m%d)
aws rds wait db-snapshot-available --db-snapshot-identifier meridian-$ENV-before-ecw-mart-$(date +%Y%m%d)
```

Open the tunnel as in `docs/runbooks/db-access.md` §2 (or `db-download.md` §2), then in a
second terminal export **both** mart passwords from the new secrets (values never printed) and
run Alembic as the owner/migration login, exactly as `docs/runbooks/migrations.md` "Running it":

```bash
export MERIDIAN_MART_OWNER_DB_PASSWORD=$(aws secretsmanager get-secret-value \
  --secret-id meridian-$ENV-secret-db-mart-owner --query SecretString --output text \
  | python3 -c 'import json,sys;print(json.load(sys.stdin)["password"])')
export MERIDIAN_MART_READER_DB_PASSWORD=$(aws secretsmanager get-secret-value \
  --secret-id meridian-$ENV-secret-db-mart-reader --query SecretString --output text \
  | python3 -c 'import json,sys;print(json.load(sys.stdin)["password"])')
# the migration login through the tunnel (port 55439 on this Mac, TLS checked against the RDS name),
# as practice-cutover-1.md does; <owner> is the RDS master user (meridian_migrator):
export MERIDIAN_DATABASE_URL="postgresql://<owner>@$DB_HOST:55439/meridian?hostaddr=127.0.0.1&sslmode=verify-full&sslrootcert=$HOME/.postgresql/rds-ca.pem"
# and the owner password as migrations.md says (PGPASSWORD from the RDS master secret, never printed)

alembic -c migrations/alembic.ini current      # note it: revisions 0039-0048 apply together
alembic -c migrations/alembic.ini upgrade head
```

Revisions 0039 to 0048 all apply in this one `upgrade head` if the database is behind. 0040
to 0047 need no environment variables; only 0048 needs the two mart password variables above.

**Trap (read before any later upgrade).** A set variable re-passwords the role every time
revision 0048's role step runs; an unset one replaces the password with a random one nobody
holds, and the loader and the api lose their logins. So export **both**
`MERIDIAN_MART_OWNER_DB_PASSWORD` and `MERIDIAN_MART_READER_DB_PASSWORD` before **any** later
`alembic upgrade` that could re-run that step (for example a downgrade to before 0048 and back
up). If it happens anyway, re-run the step with both variables set.

Login check (the passwords stay in the environment; a 1 means the login works):

```bash
PGPASSWORD="$MERIDIAN_MART_OWNER_DB_PASSWORD" psql \
  "host=<DB_HOST> hostaddr=127.0.0.1 port=55439 dbname=meridian user=meridian_mart_owner sslmode=verify-full sslrootcert=$HOME/.postgresql/rds-ca.pem" -c 'select 1'
PGPASSWORD="$MERIDIAN_MART_READER_DB_PASSWORD" psql \
  "host=<DB_HOST> hostaddr=127.0.0.1 port=55439 dbname=meridian user=meridian_mart_reader sslmode=verify-full sslrootcert=$HOME/.postgresql/rds-ca.pem" -c 'select 1'
```

Close the tunnel and `unset` the variables when done.

### Step 4 — Deploy compute with the mart switch on

First set the organization id as a GitHub Environment variable for **each** environment, so
CI deploys keep the mart on (the value is a non-secret uuid and is never committed; the
environments are `staging` and `production`, the `environment` input of `deploy.yml`):

```bash
gh variable set ECW_ORG_ID --env staging    --body <SM org uuid>
gh variable set ECW_ORG_ID --env production --body <SM org uuid>
# or in the UI: repo Settings > Environments > <env> > Environment variables > ECW_ORG_ID
```

Then build and push this commit's images, so the first-load task runs an image that contains
the loader (`scripts/sync_data_mart.py`). Staging: `scripts/staging_deploy.sh images`.
Production: there is no documented production image script yet (`deploy.yml` is staging-only);
build the two `linux/arm64` images from the commit exactly as `images` does in
`scripts/staging_deploy.sh` and push them to `meridian-production-ecr-api` and `-web` tagged with
the commit sha, with the checker reviewing the commands first. The compute deploy refuses a tag that is not in ECR.

Read the Stella Mattina org id with a read-only query (through the same tunnel, as
`meridian_app` per `db-access.md`; no secret is involved):

```bash
psql "<db-access.md connection string>" -c "select id, name from public.organizations order by name"
```

Then deploy compute **repeating every flag the environment already has** (a dropped flag
removes that feature: `-c qboOAuth=true`, `-c ecwDb=true`, `-c qboEnvironment=production`,
`-c bedrockRegion=...` if set, and the rest of the list in the previous deploy) and adding the
two new ones:

```bash
ECW_ORG_ID=<SM org uuid> scripts/staging_deploy.sh compute   # the script passes both mart flags
# production, by hand: the same `npx cdk deploy meridian-production-compute --exclusively ...` line with
# every existing -c flag plus -c ecwMart=true -c ecwOrgId=<SM org uuid>
```

`scripts/staging_deploy.sh` adds `qboOAuth` / `ecwDb` itself when their secrets exist, and
adds `ecwMart` + `ecwOrgId` when `ECW_ORG_ID` is exported (unset: it prints a reminder and the
mart stays off). `deploy.yml` does the same from the GitHub Environment variable `ECW_ORG_ID`
set above. A manual `cdk deploy` of compute must still repeat both flags, or the api loses
`MART_DB_*`, BI goes back to "eCW data isn't connected", and the schedule is deleted.
Wait for `aws ecs wait services-stable` as in `docs/runbooks/deploy-staging.md` §3.

**Do not deploy compute through the GitHub `deploy.yml` workflow yet**: it passes the mart flags
but not `-c qboOAuth=true -c ecwDb=true -c qboEnvironment=production`, so it would remove the
QuickBooks and eCW-login settings from the api. Use `scripts/staging_deploy.sh compute` (staging)
or the hand-run production line until `deploy.yml` passes them too.

### Gate before step 5 — one P&L run from AWS succeeds

Now that the api has `ECW_ORG_ID`, run one P&L from the AWS app. Success proves the NAT address
is on the mart's allowlist and the `ecw-db` login works from AWS. **Do not run step 5 until it
succeeds.** (Until then the 05:00 job fails harmlessly.)

### Step 5 — First load (do not wait for 05:00)

Andres runs; independent checker reviews first. Three one-off tasks of the `mart-sync` family,
in this order, each with a command override. Take the network settings from the running api
service so the task sits in the same subnets and security group:

```bash
CLUSTER=meridian-$ENV-ecs-main
NET=$(aws ecs describe-services --cluster $CLUSTER --services meridian-$ENV-ecs-svc-api \
  --query 'services[0].networkConfiguration' --output json)

run_mart () {   # $@ = the command, e.g. python3 scripts/sync_data_mart.py --target rds ...
  CMD=$(python3 -c 'import json,sys;print(json.dumps(sys.argv[1:]))' "$@")
  aws ecs run-task --cluster $CLUSTER --launch-type FARGATE \
    --task-definition meridian-$ENV-ecs-mart-sync --network-configuration "$NET" \
    --overrides "{\"containerOverrides\":[{\"name\":\"mart-sync\",\"command\":$CMD}]}" \
    --query 'tasks[0].taskArn' --output text
}

# 5a. the 11 tables (a --tables run skips snapshots on purpose)
run_mart python3 scripts/sync_data_mart.py --target rds --tables \
  report_measures_table,fact_follow_up_summary,report_pwt_pat,fact_encounters_detail,dim_visit_status,fact_open_notes,report_pct,fact_visits_detail,dim_visit_type,dim_general_visit_status,dim_resource_provider
# wait for it to stop, read the log, exit code 0:
aws logs tail /meridian/$ENV/ecs/mart-sync --since 30m

# 5b. the analytics views (needs the tables from 5a)
run_mart python3 scripts/apply_analytics_views.py --target rds

# 5c. today's snapshot rows (needs the views from 5b)
run_mart python3 scripts/sync_data_mart.py --target rds --snapshot-only
```

Do not start the next task until the previous one has stopped with exit code 0
(`aws ecs describe-tasks --cluster $CLUSTER --tasks <arn> --query 'tasks[0].containers[0].exitCode'`).
The biggest table (`fact_encounters_detail`, about 389 MB) takes most of the run time.

### Step 5d — Cobalt for Operations (ADR 0054)

Andres runs; independent checker reviews first. Needs steps 1-5 done for the environment.

1. On the Mac, the 04:00 Cobalt job has run today (`~/MeridianReports/logs/cobalt_nightly.log`).
2. `scripts/ecw_mart_staging/9-copy-cobalt.sh --dry-run` shows counts (about 39k appointments, 28k claims,
   76 / 75 / 74) and about 54 MB. Then run it without `--dry-run` and answer the y/N prompts. Production:
   `scripts/ecw_mart_production/10-copy-cobalt.sh`.
3. Apply the views (they read `mart.cobalt_latest` on RDS; skipped while the copy is empty):
   `run_mart python3 scripts/apply_analytics_views.py --target rds`, then `... --check --target rds`.
4. Open Operations as a user with `operations:access`: no "isn't connected". Audit check:
   `select object_name, count(*) from audit.phi_access where action = 'ecw_mart_read' and object_name like 'mart:operations.%' group by 1`.
   The claim, claim-line and appointment tables behind the views are precomputed (materialized views `fct_*_base`); the
   first apply builds them, and step 2 refreshes them after every copy (`scripts/refresh_cobalt_matviews.sql`, as the owner).
   If a copy finished but its refresh failed, run `run_mart python3 scripts/apply_analytics_views.py --refresh --target rds`. Re-applying
   the views rebuilds them and drops any view someone built on `fct_claim` / `fct_appointment`.
5. Refresh: rerun step 2 (and 3 only when the slimmed columns change). Rollback: `TRUNCATE mart.cobalt_rows` as the mart owner.

### Step 6 — /verify on the app

Run `/verify` against the deployed app (the project skill drives the running app). Pass means:
Reports & dashboards and Ask show numbers, not "eCW data isn't connected"; and a read-only
query shows the audit trail:

```sql
select action, count(*) from audit.phi_access where action = 'ecw_mart_read' group by action;
```

At least one `ecw_mart_read` row after you opened a dashboard. Also check the Executive Report
shows the red sample-data banner and a non-admin cannot open it.

### Step 7 — Seed the dashboards (T:258)

With the mart filled, seed the Daily Report dashboards on the new database:
`scripts/bi_seed_daily_reports.py` against RDS (through the tunnel, as the app login; read the
script's `--help` first). Closes T:258.

## 3. Rollback

* **Deploy compute again without `-c ecwMart=true`** (keep every other flag). The mart-sync
  task definition, its roles, log group and the schedule are removed; the api loses
  `MART_DB_*` and BI answers "eCW data isn't connected" again. Nothing else changes.
* **The schemas stay.** `mart` and `analytics` and the two logins remain in RDS; they are a
  rebuildable copy and harmless. Do not downgrade Alembic 0048 casually: its downgrade fails
  while the schemas hold data, on purpose.
* A bad deploy is also rolled back as in `docs/runbooks/deploy-staging.md` §5.

## 4. Nightly failure modes (05:00 Central)

* **Staging RDS is stopped.** `meridian-staging-rds-main` is stopped by schedule at 02:00 UTC,
  so the 05:00 Central staging run fails on those nights. That is expected, not a fault. After
  testing, either leave it (the failed runs are harmless) or deploy staging compute without
  the mart flag (unset `ECW_ORG_ID`, and remove the GitHub variable for `staging`). Production
  is never stopped.
* **Lock window.** Each table is truncated and reloaded in one transaction, so it is locked
  for the whole load (`fact_encounters_detail` about 389 MB). Any dashboard query that reads it
  during the load waits and may time out. That is why it runs at 05:00, before people arrive.
  If a morning dashboard is slow or fails around 05:00-05:30, look at the log first.
* **Source columns changed.** If the data mart changes a table's columns or types, the loader
  tries to drop and recreate that table. The analytics views depend on it, so the drop fails
  loudly (exit 1; the other tables still copy, and snapshots are skipped). Fix: as
  `meridian_mart_owner`, drop the dependent analytics views (`DROP VIEW analytics.<name>`, in
  dependency order), re-run the loader for that table (step 5a with `--tables <table>`), then
  re-run step 5b to rebuild the views, then 5c. Indexes on a recreated table are lost.
* **Source unreachable or login refused.** Exit 1 before any table is touched. Cause is almost always the
  NAT address leaving the allowlist (step 1) or a rotated `ecw-db` secret.
* **TLS to the source fails.** Redeploy compute with `-c ecwMartSourceSslMode=require`
  (plus every other flag).
* **Owner login refused.** The password was replaced, usually by an Alembic run without both
  mart variables exported (step 3 trap). Re-run the role step with both set.
* Check the last run: `aws logs tail /meridian/$ENV/ecs/mart-sync --since 24h`, and
  `select * from mart._sync_log order by 1 desc limit 20` as the owner.

## 5. Dumps, downloads and restore drills leave `mart` and `analytics` out

The two schemas are a rebuildable copy of an outside source (ADR 0053), and they hold
patient-level rows. **Exclude them from every dump** (`pg_dump --exclude-schema=mart
--exclude-schema=analytics`) taken for downloads, cutover rehearsals and restore drills, and
refill them after any restore with steps 5a-5c. The same line is in `db-download.md`,
`practice-cutover-1.md`, `restore-drill.md` and `migrations.md`.

## 6. Local development

The local app reads the Mac's `meridians_ecw` database instead of RDS. In `.env` (never
committed): `MART_DB_HOST` / `MART_DB_PORT` / `MART_DB_NAME=meridians_ecw` /
`MART_DB_USER=meridian_bi_reader` / `MART_DB_PASSWORD`, and `ECW_ORG_ID=<the org uuid>`. The
local loader needs no flag: `python3 scripts/sync_data_mart.py` (default mode copies into the
local database; it refuses every non-loopback target). `--target rds` is for the ECS task
only and reads its settings from the process environment, never `.env`.

## 7. Cost

About $2-3 per month: Fargate ~15 minutes a night (~$0.3), NAT data (~0.8 GB a night, ~$1),
two Secrets Manager secrets ($0.80), +~1 GB of RDS storage and backups (~$0.1). No new
always-on resource.
