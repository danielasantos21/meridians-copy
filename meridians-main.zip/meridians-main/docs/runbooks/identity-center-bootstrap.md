# Runbook — IAM Identity Center bootstrap and the IAM triage

**Arrives:** Phase 1 step 2. **This is a hard precondition of Phase 3** — no PHI lands in
the account until it is finished (plan §3, ADR 0001).
**Owner:** Andres. Every step here is run with the account's existing admin credentials.
**Related:** `infra/meridian/stacks/identity.py` (the CDK half),
`docs/runbooks/break-glass.md` (the other emergency path), ADR 0001.

> **Read §0 before running anything.** The first step is a decision about the shape of the
> AWS account, not a command, and it is the one step that is awkward to undo.

---

## 0. The decision: an AWS Organization, or no Identity Center

### What forced this

IAM Identity Center comes in two kinds, and only one of them can do what Phase 1 needs.

| | **Organization instance** | **Account instance** |
|---|---|---|
| Created by | Enabling Identity Center in the **management account of an AWS Organization** | `aws sso-admin create-instance`, on a standalone account |
| Permission sets (`AWS::SSO::PermissionSet`) | **Yes** | **No** |
| Sign in to the AWS console with it | **Yes** | **No** — application assignments only |
| Convert to the other kind | — | **No. Deleting it is the only way out.** |

Everything in `infra/meridian/stacks/identity.py` — both permission sets, both assignments,
the whole "replace the long-lived admin key with a short-lived console session" plan — is
an organization-instance feature. The account today is **standalone**, so running
`aws sso-admin create-instance` on it produces the wrong kind: it looks like it worked,
`list-instances` returns something, and then every `AWS::SSO::PermissionSet` fails at
deploy. That is the trap this section exists to avoid.

So there is a choice to make, and it is Andres's.

### Option A — create an AWS Organization with this account as the management account

```bash
aws organizations create-organization --feature-set ALL
```

- **Cost: none.** AWS Organizations is free. Resources in the member accounts are billed
  as they always were; this changes who receives the bill, not its size — and with one
  account, not even that.
- **No Service Control Policies yet.** `--feature-set ALL` *enables* SCPs, it does not
  apply any; the default `FullAWSAccess` policy leaves every permission exactly as it is.
  Nothing in the account's behaviour changes on the day you run this.
- **It makes the plan's future account split routine.** ADR 0001 anticipates production
  moving to its own account. Inside an organization that is `create-account` plus a CDK
  deploy. Outside one it is a migration.
- **It is the prerequisite for the Phase 1 controls as designed.** Organization-wide
  CloudTrail, Config aggregation, delegated Security Hub — all of them assume this shape.

**What it costs you in reversibility.** An organization is undone by *deleting* it, which
requires first removing every member account. With one account that is a two-command
afternoon today. It gets harder the more accounts exist — so the decision is cheap to
reverse now and progressively less so, which is an argument for deciding deliberately
rather than for deferring.

**One consequence worth stating plainly:** the management account becomes the account that
can, in principle, apply SCPs to every other account. We are not applying any. But the
shared-account caveat from ADR 0001 now has a second sentence — the other owner's
application sits in an account that is also, from today, an organization management
account. That is a governance fact to record in `docs/compliance/`, not a security
regression: nothing gains a permission it did not have.

### Option B — no Identity Center: IAM users with enforced MFA, assuming roles

The documented fallback, and it is a real option, not a consolation prize.

`meridian-shared-identity` already supports it, and unconditionally: the
`meridian-shared-iam-require-mfa` managed policy and the `meridian-shared-iam-humans`
group are created whether or not Identity Center exists. Under Option B they are the whole
mechanism:

- Each human has an IAM user in `meridian-shared-iam-humans`.
- That policy **denies every action** to a session that has not presented MFA, with a hole
  left open only for enrolling a device and calling `sts:GetSessionToken`.
- Day-to-day admin work is done by assuming a role with
  `aws sts get-session-token` + `aws sts assume-role`, not by using the user's own
  permissions — the same shape as the break-glass path in
  `docs/runbooks/break-glass.md`, which already works this way.
- Deploys still use GitHub OIDC. No long-lived key for CI either way.

**What you give up:** no portal, no 4-hour auto-expiring console sessions, no central place
to add or remove a person, and access keys still exist (MFA-gated, but they exist). Session
management becomes a habit rather than a property of the system. For two people this is
workable; it stops being workable at five.

**Under Option B, skip §1–§5 of this runbook.** Deploy the identity stack with
`-c allowNoIdentityCenter=true`, then go straight to §6 (the IAM triage), substituting
"assume the admin role with an MFA session" everywhere this runbook says "sign in to the
portal". Record the decision and the reason in `docs/compliance/`.

### The order, whichever option you pick

The account today has **long-lived IAM access keys with `AdministratorAccess`**. Those are
the single worst artefact in the inventory: a key in a file is a key that can be copied, and
it never expires. The end state is no long-lived keys anywhere — humans sign in through
Identity Center (or an MFA-gated assumed role), CI uses GitHub OIDC.

Getting there has exactly one safe order:

| # | Step | Why it cannot move |
|---|---|---|
| **a** | The replacement path exists, and **you have signed in with it successfully** | Until you have *used* it, it is a theory. |
| **b** | MFA enrolled on `andres-cli` and `meridian-app` | The old path, hardened, while it is still the working path. |
| **c** | `AdministratorAccess` removed from `andres-cli`, replaced by a role it assumes | Now the key is no longer an admin key even if it leaks. |
| **d** | **Only then** deactivate the long-lived access key | Doing this first, before (a) is verified, strands you on root-only recovery — a password reset to the root mailbox and an MFA device you may not have to hand. |

Nothing below reorders these. If a step fails, stop at that step; do not skip ahead to (d).

---

## 1. Create the organization, then enable Identity Center — by hand, once

*Option A only. Under Option B, skip to §6.*

```bash
# 1a. The organization. Free, no SCPs applied, this account becomes the management account.
aws organizations create-organization --feature-set ALL

# 1b. Confirm it, and confirm this account is the management account.
aws organizations describe-organization \
  --query '{Id:Organization.Id,FeatureSet:Organization.FeatureSet,Master:Organization.MasterAccountId}'
```

`FeatureSet` must read `ALL`. If it reads `CONSOLIDATED_BILLING`, Identity Center cannot be
enabled as an organization instance; the fix is
`aws organizations enable-all-features`, which for a single-account organization completes
immediately.

### Then enable Identity Center — in the console, because there is no API for it

**There is no CLI or CloudFormation call that enables an organization instance.**
`aws sso-admin create-instance` creates an *account* instance, which is the wrong kind
(see §0) — **do not run it.** The only supported path is one button:

> **AWS console → IAM Identity Center** (search "IAM Identity Center", or
> `https://console.aws.amazon.com/singlesignon/`) → make sure the **region selector reads
> the region you intend** → **Enable**.
>
> The page offers **"Enable with AWS Organizations"** — that is the one. Take it.

Two things about that page:

- **The region is permanent.** Identity Center lives in exactly one region and cannot be
  moved; changing it later means deleting the instance and re-enrolling every user. Pick
  the region the rest of the estate is in (`us-east-1`) and check the selector twice.
- If the page instead offers to "enable an account instance", the organization from step
  1a did not take. Go back and fix that first — do not accept the account instance.

### Verify you got the right kind

```bash
aws sso-admin list-instances
```

| You see | What it is | Do |
|---|---|---|
| `OwnerAccountId` set, **no** `Name` | **Organization instance.** Correct. | Continue. |
| a `Name`, **no** `OwnerAccountId` | **Account instance.** It cannot carry permission sets and cannot be converted. | `aws sso-admin delete-instance --instance-arn <arn>`, fix the organization, enable again from the console. |
| empty list | Nothing enabled. | The console step did not complete. |

Note the two identifiers it returns:

```bash
aws sso-admin list-instances \
  --query 'Instances[0].{InstanceArn:InstanceArn,IdentityStoreId:IdentityStoreId,Owner:OwnerAccountId}'
```

Expect `InstanceArn` of the form `arn:aws:sso:::instance/ssoins-XXXXXXXX` and an
`IdentityStoreId` of the form `d-XXXXXXXXXX`.

> **These are identifiers. They are not committed to this repository** (ADR 0001). Put them
> in `infra/cdk.context.json`, which is gitignored and which the CDK CLI reads
> automatically, and keep a copy in your password manager alongside the account id.

## 2. Create the two workforce users

Two people, per plan §2.1. Substitute the real names and mailboxes.

```bash
IDS=d-XXXXXXXXXX     # IdentityStoreId from §1

aws identitystore create-user \
  --identity-store-id "$IDS" \
  --user-name <username> \
  --display-name "<Full Name>" \
  --name 'GivenName=<First>,FamilyName=<Last>' \
  --emails 'Value=<mailbox>,Type=work,Primary=true'
```

The command prints a `UserId` (a UUID). That is the `PrincipalId` the CDK needs. Repeat for
the second member.

List them back at any time:

```bash
aws identitystore list-users --identity-store-id "$IDS" \
  --query 'Users[].{Id:UserId,Name:UserName}'
```

### Require MFA for Identity Center sign-in

The CDK's `meridian-shared-iam-require-mfa` policy binds **IAM users**, not Identity Center
sign-ins — they are two different identity systems. Identity Center's own MFA setting is
configured on the instance:

**IAM Identity Center console → Settings → Authentication → Multi-factor authentication →
Edit**, then:

- *Prompt users for MFA*: **Every time they sign in (always-on)**
- *If a user does not yet have a registered MFA device*: **Require them to register an MFA
  device at sign in**
- *Who can manage MFA devices*: users can add and manage their own

## 3. Deploy the permission sets and assignments

Now the identifiers exist, so the CDK half can run. Put them in `infra/cdk.context.json`
once — the CLI reads it on every command, so they stop being three things to retype:

```json
{
  "ssoInstanceArn": "arn:aws:sso:::instance/ssoins-XXXXXXXX",
  "ssoAdminPrincipalId": "<admin UserId>",
  "ssoReadOnlyPrincipalId": "<readonly UserId>",
  "ssoWritePrincipalId": "<write UserId>"
}
```

That file is gitignored (`infra/.gitignore`). Then:

```bash
cd infra
npx cdk deploy meridian-shared-identity
```

Or pass them explicitly, which is equivalent:

```bash
npx cdk deploy meridian-shared-identity \
  -c ssoInstanceArn=arn:aws:sso:::instance/ssoins-XXXXXXXX \
  -c ssoAdminPrincipalId=<admin UserId> \
  -c ssoReadOnlyPrincipalId=<readonly UserId> \
  -c ssoWritePrincipalId=<write UserId>
```

This creates:

| Resource | What it is |
|---|---|
| `meridian-shared-sso-admin` | `AdministratorAccess`, 4-hour sessions. The replacement for the long-lived admin key. |
| `meridian-shared-sso-readonly` | `ReadOnlyAccess` + `SecurityAudit`, 4-hour sessions. For reviews and evidence gathering — it can see IAM and credential reports, which plain `ReadOnlyAccess` withholds. |
| Two assignments | Each permission set granted to its user, on this account. |

**Every deploy of this stack needs the same values, and the stack now enforces that.**
CDK renders the whole template each time, so a deploy with `ssoInstanceArn` missing does
not skip the permission sets — it *removes* the ones already there, and both assignments,
signing you out of the account. Synth therefore fails with a message telling you exactly
this. The waiver, `-c allowNoIdentityCenter=true`, is for the genuine first pass, for CI,
and for Option B — never for "it complained, so I silenced it".

Omit only a principal id and just that one assignment is skipped; the permission sets stay.

## 4. (a) Verify sign-in — the gate

**Do not go further until this works.** The whole triage rests on this path being real.

1. Find the portal URL: IAM Identity Center console → Dashboard → **AWS access portal URL**
   (`https://d-XXXXXXXXXX.awsapps.com/start`).
2. Trigger a password for the admin user: Users → the user → **Reset password** → *Send an
   email to the user*.
3. In a private browser window, open the portal URL, sign in, enrol the MFA device when
   prompted.
4. You should see the account tile with **`meridian-shared-sso-admin`** and
   **`meridian-shared-sso-readonly`**.
5. Click through to the console. Confirm you are the permission-set role, not your old
   identity: top-right should read `AWSReservedSSO_meridian-shared-sso-admin_...`.
6. Set up the CLI as well, because that is what you will actually use:

```bash
aws configure sso
# SSO start URL:  https://d-XXXXXXXXXX.awsapps.com/start
# SSO region:     us-east-1
# profile name:   meridian-admin

aws sso login --profile meridian-admin
aws sts get-caller-identity --profile meridian-admin
```

`get-caller-identity` must return an assumed-role ARN containing
`AWSReservedSSO_meridian-shared-sso-admin`. **That output is the gate.** Repeat 2–5 for the
second workforce member.

> Keep this ARN shape in mind: it is also what the console-drift alarm
> (`meridian-shared-alarm-console-create-delete`) matches on. Creating something by hand
> from this session will, correctly, page you.

## 5. Where Option B rejoins

Under Option B there is no portal, so step (a) is instead: enrol MFA on your IAM user
(§6), then prove you can obtain an MFA session and assume an admin role —

```bash
aws sts get-session-token --serial-number <your-mfa-device-arn> --token-code <6 digits>
# export the three values, then:
aws sts get-caller-identity
```

— and only then continue to §7. The gate is the same gate: a *used* replacement path, not
a theoretical one.

## 6. (b) MFA on the remaining IAM users

Two IAM users remain: `andres-cli` (a human's CLI credentials) and `meridian-app` (the
application's). Check what exists:

```bash
aws iam list-users --query 'Users[].UserName'
aws iam list-mfa-devices --user-name andres-cli
aws iam list-access-keys --user-name andres-cli
```

Put every **human** IAM user in the group the CDK created. It carries
`meridian-shared-iam-require-mfa`, which denies every action to a session that has not
presented MFA — with a hole left open for exactly the calls needed to enrol a device and
call `sts:GetSessionToken` — and it also carries the grant that lets a member assume the
break-glass role:

```bash
aws iam add-user-to-group \
  --group-name meridian-shared-iam-humans \
  --user-name andres-cli
```

| User | Joins `meridian-shared-iam-humans`? |
|---|---|
| `andres-cli` | **Yes** — a human's credentials. |
| any second human IAM user | **Yes.** |
| `meridian-app` | **No.** It is an application identity; it cannot present MFA, and adding it would deny everything it does. Its long-lived key is retired a different way — see §8. |

Then enrol a virtual MFA device on `andres-cli` (console: IAM → Users → andres-cli →
Security credentials → Assign MFA device). Verify:

```bash
aws iam list-mfa-devices --user-name andres-cli   # must be non-empty
```

**Sanity-check the deny before you trust it:** with `andres-cli`'s plain key (no MFA
session), `aws s3 ls` should now fail with an explicit deny, while
`aws iam list-mfa-devices --user-name andres-cli` still works. If `aws s3 ls` succeeds, the
policy is not attached to a group this user is in — fix that before §7.

## 7. (c) Take `AdministratorAccess` off `andres-cli`

```bash
aws iam list-attached-user-policies --user-name andres-cli
aws iam detach-user-policy --user-name andres-cli \
  --policy-arn arn:aws:iam::aws:policy/AdministratorAccess
```

The user keeps only `meridian-shared-iam-require-mfa`. Anything administrative is now done
through the Identity Center profile from §4 (or, under Option B, the assumed role from §5),
which is short-lived and MFA-backed.

Confirm the new path still works and the old one no longer does:

```bash
aws sts get-caller-identity --profile meridian-admin     # works
aws iam list-users --profile <old andres-cli profile>    # expect AccessDenied
```

## 8. (d) Deactivate the long-lived key — last

Only once §4 (or §5) and §7 both passed.

```bash
aws iam list-access-keys --user-name andres-cli
aws iam update-access-key --user-name andres-cli \
  --access-key-id AKIA... --status Inactive
```

**Deactivate, do not delete, for the first week.** Reactivating is one command; recreating
means re-distributing a new key, which is the thing being eliminated. Delete it after a week
of `meridian-admin` working:

```bash
aws iam delete-access-key --user-name andres-cli --access-key-id AKIA...
```

`meridian-app`'s key is **not** retired here — the application still needs it until the
workload runs on ECS with a task role (Phase 5a). Track it, rotate it, and remove it when
the task role lands.

## 9. Done looks like

- [ ] The decision in §0 is recorded in `docs/compliance/`, with the date and the reason.
- [ ] *(Option A)* `aws organizations describe-organization` shows `FeatureSet: ALL` and this
      account as the management account.
- [ ] *(Option A)* `aws sso-admin list-instances` returns **one** instance with
      `OwnerAccountId` set and no `Name` — an organization instance.
- [ ] *(Option A)* Both workforce members have signed in to the portal and enrolled MFA.
- [ ] *(Option A)* `aws sts get-caller-identity --profile meridian-admin` returns an
      `AWSReservedSSO_meridian-shared-sso-admin` ARN.
- [ ] *(Option B)* Both workforce members can obtain an MFA session and assume the admin role.
- [ ] `aws iam list-mfa-devices --user-name andres-cli` is non-empty.
- [ ] `aws iam list-attached-user-policies --user-name andres-cli` no longer lists
      `AdministratorAccess`.
- [ ] `aws iam get-credential-report` (decoded) shows the `andres-cli` key `Inactive`.
- [ ] The break-glass drill has been run since the group grant was deployed
      (`docs/runbooks/break-glass.md`). It is the only test that the grant actually works.
- [ ] The date is recorded in Track C's evidence register, with the credential report
      attached as the evidence.

## 10. If you lock yourself out

In descending order of preference:

1. **The other workforce member's admin access** — this is the main reason there are two.
2. **The break-glass role** — `docs/runbooks/break-glass.md`. Assuming it fires a CloudTrail
   alarm and an SNS notification by design, and requires a written record afterwards. It
   works from an IAM user with MFA, which means it survives Identity Center being broken;
   that is the point of it.
3. **Root**, last. Root sign-in has its own alarm in the foundation stack. If it comes to
   this, the write-up is mandatory and the cause goes in the incident log.

The order in §0 exists so that (3) never happens. The failure mode it prevents is real:
deactivate the key before verifying the replacement path, discover the portal password
email went to a mailbox you cannot read, and root is all that is left.
