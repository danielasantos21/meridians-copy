# Runbook — Break-glass emergency access

**Control:** HIPAA Security Rule 45 CFR 164.312(a)(2)(ii), *Emergency access procedure* —
**required**, not addressable.
**Resource:** IAM role `meridian-shared-iam-breakglass`, created by
`infra/meridian/stacks/foundation.py`; the `sts:AssumeRole` grant that makes it reachable is
on the `meridian-shared-iam-humans` group in `infra/meridian/stacks/identity.py`.
**Alarm:** `meridian-shared-alarm-breakglass-assumed` → SNS topic
`meridian-shared-sns-security-alerts`.
**Status:** written in Phase 1. **Not yet exercised** — until the drill in step 7 has been
run and dated, this file is a draft, not evidence.

---

## What it is

A single IAM role with `AdministratorAccess`, which a member of
`meridian-shared-iam-humans` may assume **only with MFA**, for at most **one hour**. It
exists so that there is a documented, alarmed way to reach the system when the normal path
is gone — not so that there is a convenient one.

Two halves, in two stacks, and both are needed: the role and its MFA-conditioned trust
policy come from `foundation.py`; the `sts:AssumeRole` grant that makes that trust usable
comes from `identity.py`, on the humans group. Neither works alone.

**Every assumption fires an alarm and starts the write-up in step 6.** That is deliberate.
If using it feels like it costs something, it is working.

## When to use it — and when not to

Use it when **all** of these are true:

- Something is actually broken or actively harmful: production is down, PHI may be exposed,
  or a runaway resource is burning money.
- The normal path is unavailable — IAM Identity Center is down or your permission set is
  gone, the CDK deploy path cannot reach the resource, or the change has to happen faster
  than a deploy.
- You have already tried the normal path, or it is obviously unavailable.

**Do not use it for:**

| Situation | Use instead |
|---|---|
| A normal infrastructure change | `npx cdk deploy` from `infra/` |
| "CDK is slow / awkward for this" | CDK anyway. This is the console-drift the tripwire alarm exists to catch. |
| Reading something you lack permission for | Fix the permission set in Identity Center |
| A deploy failing on a permission error | Fix the CI role's policy in `infra/`, deploy, retry |
| You are not sure whether it is an emergency | It is not. Ask first. |

---

## Procedure

### 1. Confirm the normal path is genuinely unavailable

Try to sign in through IAM Identity Center and assume your usual permission set. Note what
failed and the exact error — it goes in the write-up.

### 2. Assume the role — two calls, in this order

**This is an IAM-user-plus-MFA path. It is not SSO, and that is deliberate.** Identity
Center being down or your permission set being gone is one of the reasons you are here, so
the emergency path must not depend on it. What it depends on instead is: an IAM user, in
`meridian-shared-iam-humans`, with an MFA device enrolled.

Two permissions have to line up, and they are separate things:

- the role's **trust policy** (foundation stack) trusts the account root principal *with
  MFA* — which in IAM means "any principal in this account that an IAM policy also allows".
  A trust policy on its own grants nothing.
- the **humans group's** policy (identity stack, `AssumeBreakGlassRole`) is that IAM
  policy. Membership of the group is the whole of who may break glass.

If you are not in the group, this fails with `AccessDenied` and your only remaining path is
root. `aws iam get-group --group-name meridian-shared-iam-humans` on a calm day is how you
find that out cheaply; the drill below is how you find it out on purpose.

**2a. Exchange your long-lived key for an MFA-bearing session.** Your plain access key
cannot call `sts:AssumeRole` at all — `meridian-shared-iam-require-mfa` denies every action
to a session without MFA, leaving a hole only for `sts:GetSessionToken`. So that call comes
first:

```bash
aws sts get-session-token \
  --serial-number "<your-mfa-device-arn>" \
  --token-code "<6-digit code>" \
  --duration-seconds 3600
```

`<your-mfa-device-arn>` is `arn:aws:iam::<account-id>:mfa/<your-user-name>` —
`aws iam list-mfa-devices --user-name <you>` prints it.

Export the three values it returns as `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY` and
`AWS_SESSION_TOKEN`. Everything from here runs as that session.

**2b. Assume the break-glass role with those temporary credentials.**

```bash
aws sts assume-role \
  --role-arn "arn:aws:iam::<account-id>:role/meridian-shared-iam-breakglass" \
  --role-session-name "breakglass-$(date +%Y%m%d-%H%M)-<your-name>" \
  --duration-seconds 3600
```

No `--serial-number`/`--token-code` on this second call: the credentials already carry
`aws:MultiFactorAuthPresent=true`, which is what the role's trust policy tests. Passing them
again is harmless but does nothing.

The account id is **not** in this repository (ADR 0001). It is in
`docs/aws-migration-plan.md` §1, or read it from the console, or from
`meridian-shared-identity`'s `BreakGlassRoleArn` output, which is the whole ARN ready to
paste.

Export the *new* three values over the previous ones. **Do not write them to a file,
`.env`, a note, or a chat message.** They expire in an hour; a copy of them does not.

*Under Option A of the identity-center runbook you will normally be signed in through
Identity Center rather than as an IAM user. That session can assume the role too — it is a
principal in the account with `AdministratorAccess` — but do not rely on it: the case this
runbook is written for is the one where that session does not exist.*

### 3. Expect the alarm

Within roughly five minutes, `meridian-shared-alarm-breakglass-assumed` fires and the
security alerts topic emails the mailbox on file. **If you are the only administrator, you
will be emailing yourself — read it anyway and keep it: it is the timestamped evidence that
the control worked.**

If the alarm does **not** arrive, that is itself an incident: either the trail stopped
delivering to CloudWatch Logs or the metric filter was changed. Open
`docs/runbooks/incident-response.md` after you have dealt with the emergency.

### 4. Do the smallest thing that ends the emergency

Restart the service, revoke the credential, stop the runaway resource, restore the snapshot.
**Nothing else.** You are an account administrator for the next hour and the account also
contains another owner's application (ADR 0001) — their resources are off-limits even now.

Write down every command you run, as you run it. You will not remember them accurately in
an hour.

### 5. Let the session expire

Do not renew it. One hour is the cap; if the emergency outlasts it, assume the role again —
which fires the alarm again, which is correct, because a second hour of emergency
administrator access is a second thing worth knowing about.

### 6. Write it up — same day, no exceptions

Append an entry to the break-glass register in `docs/compliance/` (create
`docs/compliance/break-glass-register.md` if this is the first one):

- Date, time (UTC), and who.
- What was broken, and how it was detected.
- Why the normal path could not be used, with the exact error from step 1.
- Every command run, in order.
- What changed as a result.
- **What was done in the console that now has to be brought back into `infra/`**, and the
  commit that does it. An emergency fix that stays only in the console is drift, and the
  drift tripwire will keep alarming on it until it is reconciled.
- Whether the alarm fired, and when.

### 7. Rotate afterwards

Within **one business day** of the session ending:

1. **Reconcile the infrastructure.** Anything changed by hand goes into `infra/` and is
   deployed, so that `npx cdk diff -c env=<env>` is clean again. Until that diff is clean,
   the emergency is not over.
2. **Rotate anything the session touched or could have read.** Any secret read or changed
   during the session is treated as exposed: rotate it per
   `docs/runbooks/rotate-secrets.md` — database credentials, the `patient_ref` HMAC key, the
   origin-verify header, QBO tokens, API client secrets, as applicable.
3. **Rotate your own MFA/credentials** if there is any chance the session credentials were
   captured (a shared screen, a recorded call, a terminal on a machine you do not control).
4. **Review the CloudTrail record of the session.** Filter on the session name from step 2
   and confirm it contains only what the write-up says it contains. This is the step that
   catches the case where the credentials were used by someone else.
5. **Re-check the alarm.** Confirm it returned to OK and that the metric filter is unchanged.

### 8. Ask whether it should have been necessary

If the same emergency could happen again, the fix is not "we have break-glass". File the
work that removes the need: the missing alarm, the missing permission in the CI role, the
missing runbook.

---

## Drill

**Exercise this once per year, and once now in Phase 1** — it is on the Phase 1 human
checklist in `infra/README.md` — on a day nothing is wrong:

1. Run **both** calls in step 2, with a session name starting `breakglass-drill-`.
2. Run one read-only command (`aws sts get-caller-identity`).
3. Confirm the alarm fires and the email arrives — **this is the part being tested**.
4. Let the session expire.
5. Record the drill in the register, marked as a drill, with the elapsed time from
   assumption to email.

**Three separate things pass or fail here, which is why the drill is not optional:**

- that a member of `meridian-shared-iam-humans` can actually assume the role. The grant is
  in a different stack from the role, and nothing else in the estate exercises it. An
  `AccessDenied` at step 2b means the group grant is missing or you are not in the group —
  a five-minute fix today, a root-recovery afternoon during a real emergency.
- that CloudTrail is still delivering to CloudWatch Logs, which is what the metric filter
  reads.
- that the SNS subscription is confirmed. An unconfirmed email subscription delivers
  nothing, silently, for ever.

A drill that does not produce the email is a failed drill. Fix the pipe, then re-run it.

## If the break-glass role itself is unavailable

The role is CDK-managed, so a bad deploy could remove it. The remaining path is the **account
root user** with its own MFA — which fires `meridian-shared-alarm-root-usage`, and whose use
is a reportable event in its own right. Root exists for exactly two things: recovering
access, and closing the account. Anything done as root goes in the same register, with the
same rotation afterwards.
