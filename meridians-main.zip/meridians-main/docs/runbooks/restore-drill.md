# Runbook — the restore drill

**Covers:** restoring the database to a scratch instance and proving it is correct.
**Arrives:** Phase 3 step 14. **Run by:** Andres.
**Repeat:** **every phase** from Phase 3 onward, quarterly after Phase 12 (D-14 / ADR 0007).
**Time:** budget half a day the first time; the whole point is to find out what it really is.
**Executed:** _not yet — this is a draft until the first real drill, and the date, the
elapsed time and the person go in §7 when it happens._

---

## Why this exists, in one paragraph

ADR 0007 says **RTO ≈ 8 business hours, RPO ≈ 1 hour in-region** (regional RPO is the age of the newest cross-region copy, ≈ 24-30 h, until Andres decides otherwise), and buys it with backups instead
of a standby: single-AZ RDS (D-14), 7-day point-in-time recovery, and a 35-day
compliance-locked AWS Backup vault with a copy in `us-west-2`. Those two numbers are
currently **claims**. HIPAA 164.308(a)(7)(ii)(D) asks for periodic testing of the recovery
procedure, and the plan (§6) records the drill as the evidence. A restore that has never
been performed is a restore that does not work — the failure modes are all in the parts
nobody thought about: the parameter group, the security group, the roles Alembic created,
the CA bundle, the KMS grant.

**Write down the elapsed time even when it is embarrassing.** A measured eleven hours is
useful; an unmeasured "should be fine" is not, and it is the number the contingency plan
has to carry.

---

## 1. Before the first drill — two prerequisites that are not in CloudFormation

Both are one-time, account-level, and neither can be expressed in CDK. Skipping either
produces a **silent** gap, not an error.

**a. Opt the account into S3 backups.**

```bash
aws backup update-region-settings \
  --resource-type-opt-in-preference S3=true,RDS=true \
  --region us-east-1
aws backup describe-region-settings --region us-east-1   # confirm both are true
```

Without it the RDS backups run and the S3 ones do not, and nothing says so.

**b1. Staging has no scheduled backup plan — take one on demand before stopping.**

The daily plan exists in **production only** (ADR 0020 §7b): a 05:00 UTC job against an
instance the 02:00 stop schedule turned off three hours earlier fails every night.
So a staging drill that means to exercise the **vault** path needs a recovery point to
exist first, and `scripts/staging_session.sh down` is what creates one:

```bash
aws backup start-backup-job \
  --backup-vault-name meridian-staging-backup-vault \
  --resource-arn "$(aws rds describe-db-instances \
      --db-instance-identifier meridian-staging-rds-main \
      --query 'DBInstances[0].DBInstanceArn' --output text)" \
  --iam-role-arn "arn:aws:iam::<account>:role/meridian-staging-iam-backup" \
  --lifecycle DeleteAfterDays=35
```

`DeleteAfterDays=35` is not optional: the vault lock bounds are [35, 400] days and a job
outside them is refused. Wait for `State: COMPLETED` in
`aws backup describe-backup-job --backup-job-id <id>` **before** stopping the instance —
a job against an instance that stops mid-flight fails. The PITR path (§2.1) needs none of
this and works on a stopped instance.

**b. Deploy the DR stack before the data stack.**

`meridian-<env>-data`'s copy action names the `us-west-2` vault by a **composed** ARN
(ADR 0020 §8) — there is no CloudFormation dependency to enforce the order, because there
is no cross-region reference. So:

```bash
cd infra
npx cdk deploy -c env=staging meridian-staging-dr      # us-west-2, first
npx cdk deploy -c env=staging meridian-staging-data    # us-east-1, second
```

`meridian-<env>-dr` is **always** in the stack list — it is pinned to `-c drRegion`
(default `us-west-2`) and its account stays unresolved like every other stack, so it
appears with or without credentials (ADR 0020 §8). If `cdk list` does not show it,
something is wrong with the app, not with your session.

**c. Know what you cannot undo.** Both vaults are **Vault Lock, compliance mode**, and
after the three-day cooling-off window the lock cannot be removed by anyone, including AWS
Support. A vault holding a recovery point cannot be deleted until that point expires (up to
35 days). Deploying these stacks is therefore a decision with a 35-day tail. That is the
control working; know it before, not after.

---

## 2. The drill, step by step

Time each step. A phone stopwatch is fine; what matters is that the numbers are real.

### 2.1 Pick the recovery point

```bash
# The 7-day PITR window — the fast path, and what an ordinary mistake would use.
aws rds describe-db-instances --db-instance-identifier meridian-staging-rds-main \
  --query 'DBInstances[0].LatestRestorableTime'

# The 35-day locked vault — the disaster path, and what an AZ or region loss would use.
aws backup list-recovery-points-by-backup-vault \
  --backup-vault-name meridian-staging-backup-vault \
  --query 'RecoveryPoints[].{Arn:RecoveryPointArn,Created:CreationDate,Status:Status}' \
  --output table
```

**Alternate between the two across drills.** The PITR path is the one used in practice; the
vault path is the one the RTO claim rests on, and it is slower and has more ways to go
wrong. Record which path this drill used.

### 2.2 Restore to a scratch instance — never over the original

```bash
aws rds restore-db-instance-to-point-in-time \
  --source-db-instance-identifier meridian-staging-rds-main \
  --target-db-instance-identifier meridian-staging-rds-drill \
  --restore-time <an ISO-8601 time inside the window> \
  --db-subnet-group-name meridian-staging-rds-subnets \
  --vpc-security-group-ids <the meridian-staging-sg-data group id> \
  --db-parameter-group-name <the meridian-staging data stack's parameter group> \
  --no-publicly-accessible \
  --no-multi-az
```

Four things that are easy to leave off and each of which invalidates the drill:

| Flag | Why it matters |
|---|---|
| `--db-parameter-group-name` | Without it the restore gets the **default** group: no `rds.force_ssl`, no pgaudit, no timeouts. A restore that is not configured like production has not proved anything about production. |
| `--vpc-security-group-ids` | Without it the restore lands in the VPC's default group, which `restrict_default_security_group` has emptied — you will not be able to connect, and it will look like the restore failed. |
| `--no-publicly-accessible` | It is a restore of PHI. |
| `--no-multi-az` | D-14. A Multi-AZ drill measures a configuration we do not run. |

From the vault instead, it is `aws backup start-restore-job` with the same metadata; the
restore job's `Metadata` is read from `aws backup get-recovery-point-restore-metadata` and
then **edited** — the same four fields, plus a new `DBInstanceIdentifier`.

**Restoring an S3 recovery point needs encryption metadata, or the bucket refuses it.**
Every Meridian bucket carries two `Deny` statements that refuse a `PutObject` which is not
SSE-KMS under *that bucket's* CMK (ADR 0020 §5). An AWS Backup S3 restore writes objects
with `PutObject`, so a restore job that does not name the encryption **fails partway
through with `AccessDenied`**, after it has already written some objects. The metadata is
not optional and it is not defaulted:

```bash
# The destination bucket's own key — restoring phi into artifacts' key is also denied.
KEY_ARN=$(aws kms describe-key --key-id alias/meridian-staging-kms-phi \
  --query 'KeyMetadata.Arn' --output text)

aws backup start-restore-job \
  --recovery-point-arn "<s3 recovery point arn>" \
  --iam-role-arn "arn:aws:iam::<account>:role/meridian-staging-iam-backup" \
  --resource-type S3 \
  --metadata "{
     \"DestinationBucketName\": \"meridian-staging-s3-phi-restore\",
     \"NewBucket\": \"true\",
     \"CreationToken\": \"drill-$(date +%Y%m%d)\",
     \"EncryptionType\": \"SSE-KMS\",
     \"KMSKey\": \"$KEY_ARN\",
     \"RestoreTime\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"
   }"
```

Three ways this goes wrong, in the order you will meet them:

1. **`EncryptionType` omitted** → the restore writes with the destination bucket default,
   which sends no `x-amz-server-side-encryption` header, and
   `DenyUnencryptedObjectUploads` returns 403.
2. **`KMSKey` pointing at the wrong environment's or the wrong bucket's CMK** →
   `DenyWrongKmsKey` returns 403. Staging cannot use a production key at all (§2.4).
3. **`NewBucket: "false"` into a live bucket** → objects are restored over the ones there
   now. Restore into a **new** bucket, compare, then copy across deliberately.

Delete the restore bucket when the drill is done; it holds PHI and it is not in the
lifecycle rules.

### 2.3 Wait, and record how long

```bash
aws rds wait db-instance-available --db-instance-identifier meridian-staging-rds-drill
```

**This is the bulk of the RTO.** For 20 GB of gp3 on a `t4g.micro` expect tens of minutes;
a vault restore is slower. Write the number down.

### 2.4 Connect

Through the ops instance, exactly as `docs/runbooks/db-access.md` describes — there is no
other path, and using one would be a drill of something we do not do:

```bash
aws ssm start-session --target <ops instance id> \
  --document-name AWS-StartPortForwardingSessionToRemoteHost \
  --parameters '{"host":["<drill endpoint>"],"portNumber":["5432"],"localPortNumber":["5433"]}'

psql "postgresql://meridian_migrator@localhost:5433/meridian?sslmode=verify-full&sslrootcert=./rds-ca.pem"
```

The password is in the RDS-managed master secret (ADR 0020 §3a):

```bash
aws secretsmanager get-secret-value --secret-id \
  "$(aws rds describe-db-instances --db-instance-identifier meridian-staging-rds-drill \
     --query 'DBInstances[0].MasterUserSecret.SecretArn' --output text)" \
  --query SecretString --output text
```

A failure here is a **finding**, not an inconvenience: the drill exists to discover that
the restored instance is unreachable before the day it matters.

### 2.5 Verify — counts, then one journal entry

> **Exclude `mart` and `analytics`** from counts and from any dump taken in the drill: they are
> a rebuildable copy of the outside eCW data mart (`ecw-mart.md` §5, ADR 0053). After a restore
> they are refilled by the nightly loader, not verified here.

**a. The parity suite.** `scripts/verify_parity.sql` (plan §3 Phase 3 step 11) is the
script that counts all 57 tables, sums `debit`/`credit` on `journal_entries`, checks all 45
sequences and asserts `patient_ref IS NULL = 0`.

> **It does not exist yet.** It is written in Phase 3 step 11, and the first drill may run
> before it does. Until it lands, do the four checks below by hand and say so in the record
> — a drill that verified less than the suite is still evidence, as long as the record says
> what it verified.

```sql
SELECT count(*) FROM public.transactions;               -- 76,132 at the Phase 3 load
SELECT count(*) FROM phi.transaction_identity;          -- 76,132 — the PHI split held
SELECT sum(debit), sum(credit), count(*) FROM public.journal_entries WHERE NOT is_test;
SELECT count(*) FROM public.transactions WHERE patient_ref IS NULL;   -- must be 0
```

`sum(debit)` and `sum(credit)` must be **equal and identical to the source, to the cent**.
These are the numbers posted to NetSuite and QuickBooks; a restore that cross-foots but
does not match is worse than one that visibly failed.

**b. Tie out one journal entry, end to end.** Pick a real JE line from a closed period and
walk it back: `journal_entries` → `import_batches` → `transactions` → through
`phi.transaction_identity` to the patient account number. One line, followed all the way,
finds things no aggregate does — a truncated join, a mis-restored sequence, a `phi` grant
that did not survive.

**c. Prove the controls came back with the data.** They are part of the restore, and they
are the part nobody checks:

```sql
SHOW shared_preload_libraries;          -- must include pgaudit
SHOW rds.force_ssl;                     -- 1
SHOW statement_timeout;                 -- 5min
SELECT rolname FROM pg_roles WHERE rolname IN ('meridian_app','phi_access');  -- both
SELECT relname, relrowsecurity, relforcerowsecurity
  FROM pg_class WHERE relname = 'transactions';      -- both true
```

RLS and the roles are *in* the database, so they restore with it — but `rds.force_ssl` and
pgaudit come from the **parameter group**, which is why §2.2 insists on passing it.

### 2.6 Delete the scratch instance

```bash
aws rds delete-db-instance --db-instance-identifier meridian-staging-rds-drill \
  --skip-final-snapshot --delete-automated-backups
```

`--skip-final-snapshot` is right here and **only** here: it is a scratch copy of data that
still exists in the original. Left running it is another ~$12/month, and another copy of
PHI.

---

## 3. What "pass" means

| Check | Threshold |
|---|---|
| Total elapsed, start to verified | **under 8 business hours** (ADR 0007) |
| Row counts | identical to source, every table |
| `sum(debit)` / `sum(credit)` | identical **to the cent** |
| The tied-out journal entry | traces back to its source transaction |
| `pgaudit`, `rds.force_ssl`, the two roles, RLS | all present |
| **The PHI HMAC key is readable in the DR region** (`aws secretsmanager get-secret-value --region us-west-2`) and `token_for()` on a known `patient_ref` reproduces the stored token | identical token (Codex G-H2 / PS-13) |
| **A user can sign in** to the restored stack and open one restored artifact, with `us-east-1` treated as unavailable — Cognito is regional, so this is the `cognito_export/` restore from `scripts/cognito_export.py` into a new pool with `scripts/cognito_import.py`, preserving `custom:app_uid` (steps below) | sign-in succeeds, artifact opens |

**The identity restore, for the sign-in row.** The auth stack exports the pool nightly
to `cognito_export/` (T:163); the drill still takes a fresh export first. `--kms-key-id`
must be the key ARN (the data stack's `KeyPhi` export): the Object-Locked archive bucket
refuses an alias.

```bash
# 1. Export the pool being "lost" (counts and domains print; no address does).
python3 scripts/cognito_export.py --pool-id <old pool id> \
  --s3-bucket meridian-<env>-s3-archive --kms-key-id <phi key ARN>
# 2. Deploy the auth stack into the recovery region with the providers present
#    (-c googleIdp=true / -c entraIdp=true, NOT the *SignIn flags yet), then rehearse:
python3 scripts/cognito_import.py --pool-id <new pool id> \
  --s3-uri s3://meridian-<env>-s3-archive/cognito_export/<stamp>.json --dry-run
# 3. For real — --confirm-pool repeats the id, and the SOURCE pool is refused:
python3 scripts/cognito_import.py --pool-id <new pool id> \
  --s3-uri s3://meridian-<env>-s3-archive/cognito_export/<stamp>.json \
  --confirm-pool <new pool id>
```

What the person on the other end sees: a **password user** is sent a reset code by Cognito
and must set a new password (no password can be exported); **everyone** re-enrolls TOTP
(no MFA secret can be exported); a federated user signs in with their provider as before.
Record the elapsed time of step 3 with the rest of the drill. The archive bucket is under
Object Lock for seven years (`data.py`), so an export written there is a seven-year record
of addresses — use it for the drill, not for experiments.

Any one of those failing means the drill failed, and the finding goes in the phase report
with the fix. **A failed drill is the drill doing its job.** The only wasted drill is one
that was not timed or not written down.

---

## 4. The cross-region half (Phase 8)

Phase 8's DR test restores from `meridian-<env>-backup-dr` in `us-west-2` into a VPC there,
and *that* measured number is the one the contingency plan carries for a region loss. It is
a bigger exercise — there is no VPC, no subnet group and no ops instance in `us-west-2` —
and it is deliberately not part of the per-phase drill. What the per-phase drill proves is
that the recovery points exist, are readable, and contain the right numbers.

---

## 5. When a step fails

| Symptom | What it means | Do this |
|---|---|---|
| `KMSKeyNotAccessibleFault` | The restoring principal cannot use the `rds` CMK, usually because the role name does not match `meridian-<env>-*`. | Check the key policy (`data.py` → `_cmk`). Do not widen it to `*`; use a role that matches. |
| Restore completes, `psql` times out | The instance is in the default security group, or you are not going through the ops instance. | Re-check §2.2's `--vpc-security-group-ids`, and that `meridian-staging-edge` is deployed — the ops instance is in it. |
| `SHOW shared_preload_libraries` has no pgaudit | The restore used the default parameter group. | Re-restore with `--db-parameter-group-name`. Modifying it afterwards needs a reboot and no longer measures a clean restore. |
| `Vault lock is in effect` on a delete | Working as designed (ADR 0020 §7). | Nothing. Recovery points expire on their own. |
| Copy job to `us-west-2` fails, "vault does not exist" | `meridian-<env>-dr` was not deployed first. | Deploy it, then re-run the plan or wait for the next nightly. §1b. |
| `sum(debit) != sum(credit)` | Stop. | This is not a restore problem. Do not proceed; it is a data-integrity finding and belongs in the phase report immediately. |

---

## 6. `psql` is not the only reader

The drill also proves the **objects** survived. After the row checks, spot-check two:

```bash
aws s3api head-object --bucket meridian-staging-s3-phi --key "<an org>/<a batch>/uploads/<file>"
aws s3api head-object --bucket meridian-staging-s3-artifacts --key "<a JE csv path>"
```

Every non-null `storage_path` in `qb_export_tie_out` should resolve (plan §3 Phase 3 step
13). A restored database pointing at objects that are not there is a restore that looks
complete and is not.

---

## 7. The record

Append a row here after every drill. This table **is** the compliance evidence for
164.308(a)(7)(ii)(D), and the source of the RTO figure in the contingency plan.

| Date | Phase | Path (PITR / vault) | Restore minutes | Verify minutes | Total | Result | Findings |
|---|---|---|---|---|---|---|---|
| _(pending)_ | 3 | | | | | | |
