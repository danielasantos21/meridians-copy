# Runbook — Cognito user migration (Phase 4, Flip 1)

**What this covers:** getting all fourteen legacy Supabase identities into the Cognito pool
without anyone being forced to reset a password, in the one order that works.

**Who runs it:** Andres, at a terminal with AWS credentials for the target account and the
Supabase service key in `.env`.

**When:** steps 1-3 on staging first, at any time. Steps 1-3 again on production **on the
morning of Flip 1**, then steps 4-6. Never during a close.

**The order is not negotiable, and it needs TWO deploys.** A link needs the provider to
exist on the pool (`AdminLinkProviderForUser` answers `InvalidParameterException`
otherwise), and a federated sign-in before the link exists auto-creates a brand-new empty
account with a fresh `sub` and no `custom:app_uid`. So:

1. deploy with `-c googleIdp=true -c entraIdp=true` — the providers exist, the web client
   still offers `COGNITO` only, so nobody can sign in with them;
2. create and link every federated-only identity (step 2), and verify;
3. deploy again adding `-c googleSignIn=true -c entraSignIn=true` — now the buttons appear.

The cleanup for getting this wrong is delete-and-relink, and the only superadmin is
Microsoft-only. (ADR 0003, plan §2.1, Phase 4 step 7.)

**Password users are NOT pre-created.** Cognito does not invoke the User Migration trigger
for a user that already exists, so an `AdminCreateUser` for a password user leaves them in
`FORCE_CHANGE_PASSWORD` — the forced reset this whole apparatus exists to avoid. They
migrate on their first sign-in. A user with a password *and* a provider (dual identity) is
therefore linked **afterwards**, with `--link-only` (step 2).

> **Cutover path (decisions 2026-10-09 and 2026-10-12, tracker T:250) — read this first.**
> 1. **Sign-in is EMAIL + PASSWORD ONLY** (Andres, 2026-10-09; the Google/Microsoft buttons
>    were removed from the web app in `2e0ae3e3`). **No identity provider is created on the
>    pool**, so everything in this runbook about IdPs, two deploys, `-c *Idp` / `-c *SignIn`,
>    `preprovision_cognito_users.py` and provider links (the order above, the IdP half of
>    step 2, step 3's sign-in flags, step 4 items 3-4) is **NOT USED**. It stays as history.
> 2. **Every user is RE-INVITED** (Andres, 2026-10-12) instead of relying on the Lambda to
>    carry Supabase passwords across: each `auth.users` row gets a Cognito account with
>    `custom:app_uid` = their Supabase UUID (so the ~30 tables keyed on it are still theirs)
>    and Cognito's own invitation email: a temporary password, then name + new password +
>    TOTP on first sign-in. Memberships are already in the loaded database, so no invite
>    code is redeemed. This replaces the "password users are not pre-created" rule below.
>    The Microsoft-only superadmin gets the invitation like everyone else.
>
> **The cutover order is step 2b.** The snapshot and the Lambda are optional: kept only as
> a fallback for anyone the invite run misses.

**Why a snapshot at all.** The User Migration Lambda has ~5 seconds before Cognito abandons
the trigger, and it must not be able to answer "does this address have an account?" for
anyone who can type into a login box. So the answer is a JSON file baked into the deployment
asset and the Lambda's decision is a dictionary lookup.

---

## 0. Preconditions

| Check | How |
|---|---|
| The auth stack is deployed and the pool exists | `aws cognito-idp describe-user-pool --user-pool-id "$POOL"` |
| Neither IdP is **offered as sign-in** yet | The stack was synthesized **without** `-c googleSignIn=true` / `-c entraSignIn=true`. The providers themselves (`-c googleIdp=true` / `-c entraIdp=true`) are created in step 2, before any link |
| **Entra: Cognito reuses Supabase's app registration** | An Entra OIDC `sub` is **pairwise** — a different value per app registration — so a subject recorded from Supabase only matches if Cognito's OIDC provider is configured with the **same** registration. Provisional decision: reuse it, and have the tenant admin add Cognito's redirect URI `https://meridian-<env>.auth.us-east-1.amazoncognito.com/oauth2/idpresponse` to it. **Needs an external tenant admin (P-8).** If a new registration is used instead, the subjects in the snapshot are worthless and the route is an attribute mapping onto the tenant-wide `oid`, which the snapshot also captures. Either way, **one Microsoft link must be verified on staging before production** |
| `meridian-<env>/legacy-supabase-auth` holds a real URL and **anon** key | Secrets Manager console. It is created empty by the stack. The **anon** key, never the service key |
| `.env` has `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` for the project being left | Local only; never committed |
| Not during a close | The fiscal calendar |

```bash
export POOL=<the pool id from the auth stack's UserPoolId output>
export AWS_REGION=us-east-1
```

---

## 1. Snapshot the legacy users

```bash
python3 scripts/snapshot_legacy_users.py
```

Writes `lambda/user_migration/legacy_users.json` (mode 0600, **gitignored** — it is keyed on
real email addresses) and prints counts and domains only.

**Done looks like:** `users: 14`, and the domain breakdown matches what you expect. A count
that is lower than the number of rows in `auth.users` means users without an address or
without an id were dropped; that is correct, but check which.

**If it fails:**

| Symptom | Cause | Fix |
|---|---|---|
| `refusing to run: APP_ENV/FLASK_ENV is 'production'` | You are inside a deployed environment | Run it from the laptop. `--i-know` exists but almost never applies |
| `refusing to write an empty snapshot` | Wrong project, or the service key is not a service key | Check `SUPABASE_URL` / `SUPABASE_SERVICE_KEY` |
| `RuntimeError: SUPABASE_URL and SUPABASE_SERVICE_KEY must be set` | `.env` not loaded | Run from the repository root |

**The file expires.** It is a photograph of `auth.users`. Anyone added to Supabase after it
was taken is not in it and cannot be migrated — they hit "sign-in is temporarily
unavailable" and stay on Supabase until it is retaken and the Lambda redeployed. Regenerate
it **the same day** as any `cdk deploy` of the auth stack (plan Phase 4 step 10).

---

## 2. Create the IdPs, then pre-provision the federated-only identities

> **NOT USED (T:250):** sign-in is email + password only and no IdP is created. This
> section is history; the cutover path is step 2b. Only the `custom:app_uid` spot-check
> below is still used.

**Every `cdk deploy` of the auth stack in this runbook carries `--exclusively`.** Without it
CDK also deploys what `auth` depends on, at whatever this command's context happens to be —
which is not the context those stacks are deployed with, so a deploy meant to add an identity
provider can rewrite DNS or a security group on the way past. `--exclusively` is "this stack
only"; its dependencies are already up.

**Check that they are.** `--exclusively` against a dependency that is *not* deployed fails on
the `Fn::ImportValue` — CloudFormation rejects the change set with `No export named meridian-…`
and rolls the deploy back. `auth` imports from `meridian-<env>-data` (the `logs` CMK) and
`meridian-shared-dns` (the SES identity), so before the first deploy run
`aws cloudformation describe-stacks --stack-name meridian-<env>-data --query
'Stacks[0].StackStatus'` and the same for `meridian-shared-dns`; each must read
`CREATE_COMPLETE` or `UPDATE_COMPLETE`.

**First deploy — the providers, no sign-in buttons:**

```bash
cd infra
npx cdk deploy meridian-<env>-auth --exclusively \
  -c env=<env> -c googleIdp=true -c entraIdp=true \
  -c requireLegacySnapshot=true \
  -c authCallbackUrls=https://<host>/auth/callback
cd -
```

**`<host>` — which callback URLs, and when (ADR 0050).** The callback is on the host the
*running* app builds it from (`PUBLIC_APP_URL`, else `SITE_URL`):

| Environment and moment | `-c authCallbackUrls=` |
|---|---|
| staging | leave it off — the default is `https://staging-app.meridiansgrp.com/auth/callback` |
| production, **before** the Phase 9 cutover (Render serves the app on `www`) | `https://www.meridiansgrp.com/auth/callback,https://app.meridiansgrp.com/auth/callback` — both, so Render keeps signing people in and the AWS stack can be smoke-tested on `app.` |
| production, **after** the cutover | leave it off — the default is `https://app.meridiansgrp.com/auth/callback`; `www` then only redirects (`decommission-supabase-render.md` step 1 drops it) |

The Google and Microsoft Entra registrations do not change with any of this: they redirect to
Cognito's hosted domain (`https://meridian-<env>.auth.us-east-1.amazoncognito.com/oauth2/idpresponse`),
never to Meridian.

The web client's `SupportedIdentityProviders` is still `["COGNITO"]` after this. That is the
point: the providers have to exist before anything can be linked to them, and nobody may
sign in through them before the links exist.

**Then create and link:**

```bash
python3 scripts/preprovision_cognito_users.py --pool-id "$POOL"            # dry run
python3 scripts/preprovision_cognito_users.py --pool-id "$POOL" --apply
```

It creates **only** the federated-only entries (`has_password: false` with a provider) with
`MessageAction=SUPPRESS` (no invitation email), `email_verified=true` and `custom:app_uid`
set to the legacy Supabase UUID, then links each federated identity with
`AdminLinkProviderForUser` on `Cognito_Subject`. Password users are counted under
`password users skipped` and left for the Lambda.

The link is made against the username **Cognito generated** (the pool has
`UsernameAttributes=['email']`, so the address is only an alias); the script reads it back
from `AdminCreateUser`, or from `AdminGetUser` when the user already exists. **Verify one
link on staging** before trusting the run — a link made against an alias silently links
nothing, and only a real pool says which it did.

Idempotent: a user that already exists is counted, not an error, and its providers are still
linked. Run it as many times as you like.

**Done looks like:** `users created` + `users existing` equals the number of federated-only
entries, `providers linked` + `already linked` equals the number of their federated
identities, and `password users skipped` accounts for everybody else (live data, 2026-08-29:
one Google-only, one Microsoft-only, and the Microsoft-only one is the superadmin).

**Dual-identity users (a password AND a provider)** are skipped here on purpose. After the
flip, once they have signed in with their password and the Lambda has migrated them, attach
their provider:

```bash
python3 scripts/preprovision_cognito_users.py --pool-id "$POOL" --link-only --apply
```

`--link-only` creates nothing: it looks each user up with `AdminGetUser` and links onto the
account that now exists. Anyone who has not signed in yet is counted as `not created yet` —
expected, and the reason it is re-runnable. **Until their link exists, their federated
sign-in would create a duplicate account**, so run it as soon as they appear in the weekly
report (step 6), not at the cut-off.

**Spot-check one user without putting an address in your shell history:**

```bash
read -rs ADDRESS                      # typed, not echoed, not saved
aws cognito-idp admin-get-user --user-pool-id "$POOL" --username "$ADDRESS" \
  --query "UserAttributes[?Name=='custom:app_uid'].Value" --output text
unset ADDRESS
```

That value must equal the user's Supabase UUID. If it does not, **stop**: a wrong
`custom:app_uid` silently points a person at somebody else's rows.

**If a link fails with `InvalidParameterException`, the run stops** (only the error code is
printed — a botocore message quotes the request, which carries an address and a provider
subject). It means the provider named in the link does not exist on the pool: the first
deploy above did not happen, or did not include both `-c *Idp=true` flags. Fix the deploy
and re-run; the users already exist, so only the links are attempted.

---

## 2b. Cutover day: re-invite every user (T:250 — THE cutover path)

**Order on cutover day:**

1. **Snapshot** (step 1) — only if the Lambda is kept as a fallback (see below).
2. **Auth deploy** — no IdP or sign-in flags:
   ```bash
   cd infra
   npx cdk deploy meridian-<env>-auth --exclusively -c env=<env> \
     -c requireLegacySnapshot=true \
     -c authCallbackUrls=https://<host>/auth/callback
   cd -
   ```
   (Drop `-c requireLegacySnapshot=true` only if you deliberately ship no snapshot: the
   Lambda then refuses every unknown address, which is fine when nobody depends on it.
   `<host>`: the callback table in step 2.)
3. **`AUTH_BACKEND=cognito`** — the app now signs in through Cognito. Not before: an
   invitation that arrives before the login it points at works is a support call, and the
   temporary password expires after **7 days**.
4. **Invite** — dry run, one test address, then everyone:
   ```bash
   python3 scripts/invite_legacy_users.py --pool-id "$POOL"                   # dry run

   read -rs ADDRESS                                                           # one test: your own address
   python3 scripts/invite_legacy_users.py --pool-id "$POOL" --only "$ADDRESS" \
     --apply --confirm-pool "$POOL"
   unset ADDRESS
   #   -> the email arrives; sign in: temporary password, name + new password, TOTP;
   #      /api/v2/me shows the same org and role as before.

   python3 scripts/invite_legacy_users.py --pool-id "$POOL" --apply --confirm-pool "$POOL"   # everyone
   ```
5. **Pending invite codes** — `reissue_pending_invites.py` (step 4.7), dry run first. AFTER
   step 4, so an invitee who already had a Supabase account is found in the pool with their
   own `custom:app_uid` instead of getting a new identity.
6. **Spot-check** one `custom:app_uid` (the `read -rs` block in step 2) and re-run the dry
   run: `MISMATCH 0`, `failed 0`.

The script reads Supabase `auth.users` read-only (the same `SUPABASE_URL` /
`SUPABASE_SERVICE_KEY` path as the snapshot) and prints counts and domains only. Dry run is
the default; it still reads the pool, so it says exactly what a real run would do.

**Per user** (the script's rules; re-running is always safe):

| Pool state | What it does |
|---|---|
| not in the pool | `AdminCreateUser`: email, `email_verified=true`, `custom:app_uid`, `DesiredDeliveryMediums=[EMAIL]` — Cognito sends the invitation |
| `FORCE_CHANGE_PASSWORD` (invited, never signed in) | nothing, counted `pending, not re-sent`; with `--resend` a fresh invitation (`MessageAction=RESEND`, new temporary password) |
| `CONFIRMED` | nothing, counted `already active` (signed in already, possibly through the Lambda) |
| any other status | nothing, counted by status name |
| `custom:app_uid` differs or is missing | **nothing**, counted `MISMATCH`, exit 1. It is immutable and never overwritten; a wrong one points a person at somebody else's rows. Fix: `admin-delete-user` that pool user and re-run (ask first — it is destructive) |

Skipped and counted: Supabase rows with no email or id, banned rows, and every row of an
address two Supabase ids share (case-insensitively) — which UUID is theirs is a human
decision.

**Done looks like:** `invited` + `already active` + `pending` = the invitable users (14 on
2026-10-12), `MISMATCH 0`, `failed 0`. `failed` prints the AWS error code only; re-run.

**Afterwards:**

- **Someone lost or let the email expire** (`ForgotPassword` does not work for a
  `FORCE_CHANGE_PASSWORD` user): `--only "$ADDRESS" --resend --apply --confirm-pool "$POOL"`.
- **Progress:** the dry run is the report — `pending, not re-sent` is invited and not
  signed in yet. `cognito_migration_report.py` (step 6) reads everyone as `migrated` the
  moment they are in the pool, so it no longer measures this.

**The Lambda and the snapshot are a fallback only.** Cognito never invokes the migration
trigger for a user who exists, so for everyone invited it never runs. Kept (snapshot taken,
deployed with `-c requireLegacySnapshot=true`), it still migrates, with their Supabase
password, anyone the invite run skipped or failed. Skipped, those people are simply invited
again (`--only`). An invited person who types their OLD Supabase password gets "incorrect
password" — the Lambda is not asked; they use the emailed temporary password.

---

## 3. Enable federated sign-in, and deploy the Lambda with a fresh snapshot

> **NOT USED (T:250):** no IdP, no `-c *Idp` / `-c *SignIn` flags. The auth deploy is
> step 2b.2. The Lambda facts below (cold start, 1024 MB, 5 s, no VPC) still hold if it is
> kept as a fallback.

Only after step 2's links exist and have been spot-checked:

```bash
cd infra
npx cdk deploy meridian-<env>-auth --exclusively \
  -c env=<env> -c googleIdp=true -c entraIdp=true \
  -c googleSignIn=true -c entraSignIn=true \
  -c requireLegacySnapshot=true \
  -c authCallbackUrls=https://<host>/auth/callback
```

Keep the `*Idp` flags on: dropping them would delete the providers. `*SignIn` without its
`*Idp` partner fails at synth, on purpose.

`-c requireLegacySnapshot=true` makes synth **fail** if `lambda/user_migration/legacy_users.json`
is missing. Pass it on every deploy of this stack: the file is gitignored, so a deploy from a
machine that has never generated it ships a Lambda that fails every sign-in closed — correct
behaviour, terrible morning. The default is off so CI, which deploys nothing, still
synthesizes.

The Lambda reads `SUPABASE_URL` and `SUPABASE_ANON_KEY` from the secret at **cold start**
(~100-250 ms in-region for the call, once per container) and caches them. It runs at
**1024 MB**: at the 128 MB default, importing boto3 alone took 3-5 s on a cold start and the
first sign-ins timed out (staging, 2026-10-08). Measure step 4's p99 over cold starts. Its environment variable holds
the secret **ARN**, never a credential — a Lambda environment variable is readable by anyone
with `lambda:GetFunctionConfiguration`.

**Done looks like:** the deploy succeeds, and

```bash
aws lambda get-function-configuration --function-name meridian-<env>-lambda-user-migration \
  --query '[Timeout,Runtime,VpcConfig]'
```

returns `5`, `python3.12`, and no VPC.

---

## 4. Verify on staging before production (plan Phase 4 step 9)

> **T:250:** items 3-4 (Microsoft / Google sign-in) are **NOT USED** — no IdP exists.
> Item 1 becomes: an invited user signs in with the emailed temporary password (name, new
> password, TOTP) and `admin-get-user` shows their Supabase UUID as `custom:app_uid`; a
> Supabase-era password matters only if the Lambda is kept as a fallback.

1. A Supabase-era password signs in, and `admin-get-user` shows the right `custom:app_uid`.
2. `GET /api/v2/me` returns the same org, role and permissions as before the flip.
3. **One Microsoft sign-in completes and lands on the pre-linked account** — not a new one.
   This is the pairwise-`sub` check from step 0: if Cognito's OIDC provider is not the same
   Entra app registration Supabase used, the subject in the snapshot matches nothing and
   this sign-in quietly creates a duplicate. Do it before production, every time.
4. A Google sign-in for a dual-identity user lands in the **same** account — no duplicate
   (they are linked with `--link-only` after they migrate, so this one is verified *after*
   their first password sign-in, not before).
5. A password reset completes end to end (Cognito's own email, through SES).
6. MFA enrols and challenges for both workforce members.
7. The 17 pending invite codes still redeem.
   An invitee who never created a Supabase account cannot sign in at all on Cognito
   (self sign-up is off and the migration Lambda refuses addresses it does not know), so
   their code is useless until they have an account. Right after the flip, reissue them:
   the script creates each pending invitee's Cognito account (Cognito emails the
   invitation) and redeems their existing code for it, the same path a new invite takes.
   Run it as a one-off command in an api task, dry run first:
   ```bash
   aws ecs execute-command --cluster meridian-<env>-ecs-main --task <api-task-id> \
     --container api --interactive \
     --command "python3 scripts/reissue_pending_invites.py --actor <superadmin-user-id> --dry-run"
   ```
   then the same without `--dry-run`. It prints counts only. Re-running is safe: a
   redeemed code is no longer pending. Rows with no email are counted and skipped; an
   admin re-invites those from the Users screen. Exit 1 means some rows failed: run again.
   Caution: an invitee who already HAD a Supabase account (invited to a second org) gets
   a new Cognito identity this way; check the dry-run count against what you expect.
8. **`ForgotPassword` for a stranger looks like `ForgotPassword` for a known user.** The
   Lambda refuses a stranger by raising, while a known user is created in `RESET_REQUIRED`
   and gets a real code — so compare the **API response** for both: HTTP status, body shape
   and latency (three runs each, an address that is in the snapshot and one that is not).
   ```bash
   read -rs ADDRESS
   time aws cognito-idp forgot-password --client-id "$CLIENT" --username "$ADDRESS"
   unset ADDRESS
   ```
   If they differ in any of the three, that is a user-enumeration oracle: record it in
   ADR 0021's "Residual risks" with the measured numbers before Flip 1, and raise it as a
   blocker if the difference is in the status or the shape rather than the latency.
9. The Lambda's **p99 fits inside 5 s**:
   ```bash
   aws cloudwatch get-metric-statistics --namespace AWS/Lambda --metric-name Duration \
     --dimensions Name=FunctionName,Value=meridian-<env>-lambda-user-migration \
     --start-time "$(date -u -v-7d +%FT%TZ)" --end-time "$(date -u +%FT%TZ)" \
     --period 604800 --extended-statistics p99
   ```
   Over ~4,000 ms, stop and re-measure before touching production: a trigger that times out
   is a failed sign-in, not a slow one.

---

## 5. Flip 1 preconditions (production)

Every one of these, on the day:

- [ ] Not during a close, and not on a Friday.
- [ ] Step 2b items 1-2 (snapshot if keeping the fallback, auth deploy) done **today**,
      against production. No IdP deploys, no `preprovision_cognito_users.py`.
- [ ] Step 4 passed on staging, including the p99.
- [ ] Both React screens are live: the MFA challenge and password reset.
- [ ] Both workforce members have enrolled MFA **on staging** and know the first sign-in may
      be slower.
- [ ] `meridian-production/legacy-supabase-auth` holds the production URL and anon key.
- [ ] Supabase Auth stays live and paid — it is the rollback, until the Phase 10 cut-off.

Then set `AUTH_BACKEND=cognito` on Render and redeploy; then step 2b items 4-6.

**Watch for an hour:** Lambda `Invocations`, `Errors` and `Duration`; 5xx on the app; one
real password reset; one invite redemption.

**Rollback:** `AUTH_BACKEND=supabase` and redeploy. `auth.users` is never mutated and Cognito
users are copies, so nothing is lost. Anyone created in Cognito during the window is
re-created in Supabase by hand (with two users, minutes). Reversibility ends at the Phase 10
cut-off (cutover + 60 days).

---

## 6. Weekly: the migration percentage

Every Monday until the cut-off:

```bash
python3 scripts/cognito_migration_report.py --pool-id "$POOL"
```

Prints `migrated`, `pending`, `federated-linked`, `unexpected` and a **domain** breakdown —
never an address. Paste the counts into the phase report and the Obsidian note under
`NS_Proccess/`.

`pending` is the manual work waiting at the cut-off: each of those people gets an
`AdminCreateUser` and a password reset. `unexpected` growing faster than new hires means
somebody is being created twice — check before it becomes two accounts with two sets of rows.

---

## 7. At the cut-off (Phase 10, cutover + 60 days)

Detach the trigger, delete the Lambda, delete `meridian-<env>/legacy-supabase-auth`, delete
every copy of `legacy_users.json` from every machine, and cancel Supabase Auth. Dual-token
acceptance goes in the same commit. After that, a straggler is a support request, not a
migration.
