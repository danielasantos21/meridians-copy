# Meridian → AWS Migration Prompt

Paste everything below the line into a fresh Claude Code session in this repo.

Companion documents: `docs/aws-migration-plan.md` (v3, on this branch — phases, cost model,
calendar, decisions; where it and this prompt disagree, the prompt wins on architecture; the plan
wins on effort, cost, phase order (decided: cutover-first, D-16), sequencing detail, data safety
and decisions) and
`docs/api-v2-contract.md`.

---

Migrate Meridian (this repo: `NS_Proccess_QB`) fully onto AWS.

**What the repo actually is today — do not restate it wrong:**

- **Backend:** Flask in `web_app.py` — the `/api/v2` blueprint (contract: `docs/api-v2-contract.md`),
  a legacy `/api/v1` surface (`web_app.py:7267+`, used by `render.yaml`'s health check), auth
  (`src/auth.py`), **78 `render_template()` Jinja screens**, and background workers that are
  `threading.Thread` inside the Flask process (~15–17 sites) running under `gunicorn --workers 1`.
- **Frontend:** Next.js + React in `web/`. `web/next.config.mjs` still proxies live paths to
  Flask's Jinja screens: invoice wizard, superadmin, profile, wearbly, mx-employees, signup,
  forgot/reset password, `/auth/google`, `/auth/microsoft`.
- **Business logic:** `src/`.
- **Data:** Supabase Postgres (37 SQL migrations in `supabase_migrations/` once `andres-try` is
  merged — `main` has 35; 94 RLS policies across 19 of them), Supabase Auth (email + Google +
  Microsoft), and Supabase Storage (`uploads` and `outputs` buckets, org-prefixed paths, signed
  URLs — `src/storage.py`). Data access is supabase-py PostgREST (~188 `.table()` call sites:
  `src/database.py` 63, `web_app.py` 47, `src/api/v2/*` 26, `src/auth.py` 11, the rest across 12
  small modules) **and** raw psycopg2 via `SUPABASE_DB_URL`.
- **Process registry already half-exists:** `src/process_runs.PROCESSES`,
  `role_permission_processes` (migrations 029/030), `src/api/v2/state_machine.py`,
  `/api/v2/processes`, contract §2 state machine.
- **Email:** Resend (`src/email_service.py`, `RESEND_API_KEY`).
- **External systems in production:** Intuit QuickBooks Online (`src/qbo_client.py`,
  migration `035_qbo_connection.sql`), Google/Microsoft sign-in, NetSuite where wired.
- **Hosting today:** Render (`render.yaml`).

The result must be HIPAA-compliant, SOC 2-ready, secure, fast, tidy, and production-ready. It
must make existing processes easy to serve and new ones easy to add, and expose a safe API for
our own systems and outside computers.

Benchmark against AWS Well-Architected (Security and Reliability pillars) and the AWS HIPAA
reference architectures. Do not copy proprietary code, branding, or text from anyone.

**Do NOT execute destructive steps — dropping data, cutover, deleting resources,
decommissioning Supabase — without asking me first.**

---

## MODELS & AGENTS

- **Lead / orchestrator: Fable** (`claude-fable-5-1`). Owns architecture, contracts,
  sequencing, and final decisions.
- **Specialist builders and researchers: Opus sub-agents** (`model: "opus"`).
- **Harsh critic for every phase: a separate Fable agent** that did not write the code.
- Define shared architecture, naming conventions, folder layout, IaC conventions, API
  contracts, and env/secret contracts **first**. All agents work from the same contracts.
- Tightly coupled work (network → data → auth → app → API) runs sequentially, not in
  uncontrolled parallel.
- Fan out sub-agents where work is genuinely independent; use `ultrathink` for design
  decisions.

Potential specialists: AWS architecture, PostgreSQL/data migration, identity & auth, API
design, API security, cybersecurity & compliance (HIPAA/SOC 2), process framework, frontend,
observability, testing, documentation.

---

## TECH STACK (fixed — do not substitute)

- **Frontend:** React + TypeScript (the existing Next.js app in `web/`). Strict TypeScript. No
  new work in `templates/`; existing Jinja screens are retired only as React replaces them
  (see Phase 5).
- **Mobile:** no phone app in this migration, but design for one. The API must support a
  future **React Native (TypeScript)** client with no redesign. Auth accepts **both**: the
  browser keeps today's HttpOnly cookie sessions + CSRF (`src/auth.py`, contract §6), and the
  same endpoints also accept `Authorization: Bearer` for mobile and machine clients. Write an
  ADR superseding contract §0/§6 before touching auth. Deliver `docs/plans/mobile-readiness.md`.
- **Backend:** Python with **FastAPI** (async), replacing Flask over time — not in one jump.
  Pydantic models for request/response, except where contract §10.1 says otherwise. OpenAPI
  generated from the code.
- **Database:** **PostgreSQL only** (Amazon RDS for PostgreSQL) as the canonical system of
  record. **Alembic** for schema, importing the 37 existing SQL migrations as the baseline —
  do not rewrite them. The migration folder does not match the live schema (two live tables have
  no file, 027 was never applied, declared `auth.users` foreign keys do not exist), so the
  baseline is three revisions: 0001 replays the 37 files verbatim, 0002 reconciles the diff
  against a `pg_dump --schema-only` of live Supabase, 0003 holds RDS adaptations (phi/audit
  schemas, roles). Data access: replace supabase-py calls with a thin **psycopg**
  repository layer (sync is acceptable; the workload is batch, not high-concurrency) that
  preserves the explicit `org_id` filter on every query (contract §8 layer 2). **No SQLAlchemy;
  psycopg2, which is already in use here; AWS CDK written in Python** (plan D-21). No MySQL, SQL Server, Oracle, Mongo, or Firebase; no
  SQLite in production. JSONB only where it fits.
- **Redis (ElastiCache):** caching, distributed locks, rate limiting only. Never the source of
  truth. Add only if something actually needs it.

---

## AWS-ONLY, HIPAA-ELIGIBLE SERVICES

- Use only services on the current **AWS HIPAA Eligible Services** list. Verify each before
  use; anything not eligible must never touch PHI.
- After cutover, no non-AWS **hosting, database, auth store, file storage, log, or email**
  provider. Explicitly allowed external calls, each with a data-flow entry stating exactly
  what leaves AWS: **Intuit QBO API** (`src/qbo_client.py`), **Google and Microsoft as Cognito
  federated identity providers**, **NetSuite** where wired. No PHI leaves AWS beyond what a
  journal entry legitimately requires.
- Default service map — challenge it if something fits better, and explain why:

| Concern | Service |
|---|---|
| Accounts | **Decided: start with one account** (the existing one — its id is in `docs/aws-migration-plan.md` §1, the single place it is written down), with staging and production isolated by separate VPCs, IAM boundaries, KMS keys, and tags. Design so a second account (prod split off from non-prod) can be added later by redeploying CDK stacks into it — no account id hard-coded anywhere, environment as a stack parameter, no shared state between environments. |
| Infrastructure as code | AWS CDK — every real resource in code, nothing clicked in the console |
| Compute | ECS Fargate (FastAPI service, Flask during transition, process worker, Next.js) behind ALB |
| Edge | CloudFront + AWS WAF + **Shield Standard** (never Shield Advanced without asking — it is $3,000/month) + ACM (TLS 1.2+). CloudFront in front of the ALB means two proxies: `ProxyFix(x_for=2)` and an origin-verify header are mandatory, and the ALB security group admits only CloudFront's managed prefix list. |
| API edge | ALB for the browser app and internal API; a separate **API Gateway** custom domain with an mTLS truststore **only** for partner clients holding PHI scopes. Settle this in a Phase 0 ADR. |
| Database | RDS for PostgreSQL — encrypted, private subnets, **single-AZ** (decided, plan D-14: RPO ≈ 1 h / RTO ≈ 8 business hours via 7-day point-in-time recovery plus a 35-day locked AWS Backup with cross-region copy; Multi-AZ only if a real outage costs more than the ~$28/month it saves) |
| Auth | Amazon Cognito (users + MFA; OAuth2 client-credentials for machines) |
| Files | S3 — SSE-KMS, block public access, versioning, Object Lock for audit data |
| Jobs / events | SQS (+ dead-letter queues) and EventBridge |
| Email | Amazon SES — replaces Resend |
| Secrets | AWS Secrets Manager + KMS customer-managed keys, rotation |
| Security | CloudTrail (org trail + log file validation), AWS Config (HIPAA conformance pack), GuardDuty (Malware Protection for S3 is per-bucket and billed per GB — scope it to upload buckets), Security Hub, Inspector, Macie, IAM Access Analyzer |
| Monitoring | CloudWatch — encrypted logs, retention set, alarms → SNS |
| Backups | AWS Backup with tested restores |
| Admin DB access | AWS SSM Session Manager only — no open ports anywhere (an SSM-managed instance with zero security-group ingress, or ECS Exec; SSM port-forwarding to RDS needs one of them) |

- The AWS **Business Associate Addendum (BAA)** must be accepted in AWS Artifact **before any
  PHI touches AWS**. Stop and ask me to confirm.
- **SES has lead time:** verify `meridiansgrp.com` (DKIM/SPF/DMARC) and request production
  access (sandbox exit needs AWS approval) in **Phase 1**, long before Phase 7 needs it. Keep
  the existing HTML email templates.
- **No billable resource is created until I approve a monthly cost estimate per environment**
  (Phase 1 exit criterion). Staging is **torn down between phases** (plan D-15): the `data` stack
  persists with RDS stopped, everything else is `cdk destroy`ed at the end of each staging
  session — about $13/month idle. A standing staging environment would blow the ~$250/month
  ceiling on its own.

---

## SECURITY & COMPLIANCE (top priority)

- Map every control to **HIPAA Security Rule** safeguards (administrative, physical,
  technical) and **SOC 2** Trust Services Criteria (Security, Availability, Confidentiality).
- Maintain a **control matrix**: control → implementation → evidence location.
- **Tenant isolation is two layers:** (a) the explicit `org_id` filter on every query, as
  today; plus (b) Postgres RLS enforced by setting `app.org_id` per request/transaction under
  a non-superuser app role, replacing `user_org_id()`, which read Supabase JWT claims — set on
  connection checkout and reset on return if the repository layer is autocommit, or `SET LOCAL`
  inside a per-request transaction; the Phase 0 auth/data ADR picks one and a test proves the
  setting never leaks between requests. Port
  the existing isolation tests (`test_run_isolation.py`, `test_pnl_rls_live.py`) to RDS. The
  Supabase service key bypassed RLS today — the new setup must not have an equivalent
  loophole in the app path.
- Required everywhere: least-privilege IAM (no wildcard app roles), no long-lived access keys,
  encryption at rest and in transit, private subnets for data, no public database, gateway VPC
  endpoints, audit logging of all PHI access, tamper-evident logs, MFA, session timeouts, rate
  limiting, input validation, dependency + container + secret scanning in CI, incident response
  runbook, backup/restore and DR with measured RTO/RPO.
- Never put secrets, ACH/bank numbers, client data, or PHI in code, commits, logs, test
  fixtures, prompts, or anything sent to an external review tool.
- Do not claim "HIPAA certified" or "SOC 2 certified." Goal: audit-ready controls with
  evidence, plus an explicit `needs-a-human` list (BAAs, written policies, auditor, pen test).

---

## PROCESS FRAMEWORK (easy to serve, easy to add)

Goal: adding a new Meridian process = **one folder plus business logic**, with no new
infrastructure and no hand-built auth, audit, or storage wiring.

- **Extend what exists. A second registry is a critic failure.** The manifest must build on
  `src/process_runs.PROCESSES`, `role_permission_processes` (migrations 029/030), contract §2's
  state machine, and `src/api/v2/state_machine.py`.
- **Process contract** — each process provides a **manifest** (id, name, color, input types +
  validation, wizard steps, outputs, required permissions/scopes, whether it touches PHI), a
  **processor** in `src/` (pure business logic, no AWS or web code), and **tests**.
- **Standard routes and a standard wizard shell are generated from the manifest.** A process
  may declare **custom steps and parameters** — contract §12.1–12.11 documents why the three
  existing processes do not fit one uniform wizard (different params, two have no human step,
  `blocked` is reachable from `running`, permissions split within one wizard). Custom steps
  are allowed; custom auth, audit, or storage is not.
- **Execution:** one generic worker service on ECS Fargate consumes SQS jobs; inputs/outputs
  in S3; run history and audit **extend** the existing `process_runs` and `artifact_downloads`
  (migration 022) tables — do not create parallel ones.
- **Worker state:** inventory the volatile keys in `src/run_store.py`. Today workers are
  threads sharing process memory (parsed DataFrames and results). Once API and worker are
  separate containers, every result a worker produces must be serialized to S3 or Postgres.
- **Idempotency:** jobs are safe to retry and must **never double-post a JE to QuickBooks** —
  persist an idempotency record before the QBO call, use Intuit's `RequestId`, and follow
  contract §12.9 (`Idempotency-Key` header plus duplicate-input warning, not a silent block).
- **Scaffold command:** `new-process <id>` generates folder, manifest, processor stub, tests.
- **Conformance suite** every process must pass: file validation, permissions, audit logging,
  idempotency, error handling, no PHI in logs. Failing = not registered.
- Migrate existing processes one at a time, comparing output against the current system (same
  JE files, same totals) before switching each.
- Deliver `docs/adding-a-process.md`.

---

## API PLATFORM (internal + external)

- **The new public API is `/api/v3`.** `/api/v1` is a live legacy Flask surface
  (`web_app.py:7267+`) and `/api/v2` is the current contract — retire either only once `/api/v3`
  covers it, with my sign-off. Decided for `/api/v1`: retired in the API-platform phase, with
  `/api/v1/health` kept working until `/api/v3/health` replaces it in the same commit (plan D-25).
- **API-first:** the React app, internal scripts, and external systems use the same versioned
  API. No backdoors that bypass auth, scopes, or audit.
- **No direct database access from outside, ever.**
- **Machine auth:** Cognito OAuth2 client-credentials; one client per external system;
  short-lived tokens; secrets in Secrets Manager. Human users: Cognito login + MFA, cookie
  session in the browser or bearer token elsewhere.
- **Authorization:** fine-grained scopes (`processes:run`, `runs:read`, `revenue:read`,
  `phi:read`, …) enforced server-side on every endpoint; org isolation enforced.
- **Data endpoints:** resource-based REST for core data (runs, journal entries, mappings,
  employees, allocations, …) with pagination, filtering, consistent errors.
- **Process endpoints:** generated from each manifest — upload input (S3 pre-signed URL),
  start run, get status, list runs, download outputs.
- **Webhooks:** subscribe to events (`run.completed`, `run.failed`, …); delivered via SQS with
  retries and a dead-letter queue; delivery history visible.
- **OpenAPI spec is the source of truth** (generated by FastAPI); generate the TypeScript
  client for `web/` and future React Native, and a Python client for scripts and partners.
- **Sandbox** = a synthetic org inside the staging environment (plan D-18) — no third stack, never
  real PHI.
- **Admin screen** in `web/`: create/revoke API clients, set scopes, rotate secrets, view usage
  and webhook delivery logs.

---

## API SECURITY (mandatory — the highest-risk surface)

- Design and test against the **OWASP API Security Top 10**; document each mitigation in the
  control matrix.
- **Object-level authorization on every request:** verify this caller may access this specific
  record and org, not merely that the token is valid. Tests must attempt ID-swapping and
  cross-org access and prove they fail.
- **Property-level authorization:** explicit schemas; reject unknown fields; return only fields
  the caller's scopes allow; PHI masked by default (HIPAA minimum necessary).
- **Credentials:** access tokens expire in ≤15 minutes; client secrets shown once, stored
  hashed, rotatable without downtime, instantly revocable; optional IP allowlist; **mutual TLS
  for any partner with a PHI scope**.
- **External PHI access gated:** no client gets a PHI scope until a signed BAA with that partner
  is recorded, admin-approved, and logged.
- **Input safety:** strict validation, size limits, content-type enforcement, parameterized
  queries only, no secrets or PHI in URLs or query strings.
- **File uploads:** short-expiry pre-signed URLs with size/type limits; GuardDuty Malware
  Protection scans every object; nothing is processed until marked clean.
- **Abuse protection:** WAF managed + rate-based rules, per-client quotas, progressive lockout
  on repeated auth failures.
- **Webhooks:** HTTPS only; block private/link-local/metadata IP ranges (SSRF); HMAC signature
  with timestamp and unique id (replay protection); no PHI in payloads — send ids only.
- **Errors** never leak stack traces, SQL, internal ids, or cross-org existence. Strict CORS
  allowlist. Security headers on every response.
- **Detection:** CloudWatch alarms on auth-failure spikes, unusual export volume, new client
  IPs, scope escalation; GuardDuty and Security Hub findings alert; every API call audited
  (client, user, scope, endpoint, record, result, IP) with no PHI in logs.
- **Lifecycle:** new API clients need admin approval; unused clients auto-disabled after 90
  days; quarterly access-review report.
- **Testing:** automated API security tests in CI (auth, object-level access, scopes, injection,
  rate limits, SSRF, replay, oversized payloads); dynamic scan against staging each phase;
  external penetration test before any real partner reaches production.

---

## KEEPING IT TIDY

**Phase 0 comes first and includes a safety sweep.** List every untracked file in the working
tree. Anything that is client data, PHI (for example `code_grader/uploads`, `code_grader/output`),
a root `.xlsx` report, an instance-identifying file (`deploy/**/.trial-env`), or another product
(`schdualer/`, `qgenda/`, `code_grader/`) is **moved out of the repo** to its proper
`~/Business/...` data folder — never committed, never sent to Codex or any external tool. Add
those paths to `.gitignore`. Then reconcile git: the working branch is `andres-try` with
in-flight QBO changes — commit or stash them, merge to `main`, then rebase `aws-migration` onto
`main` and work from there. The plan and this prompt describe `andres-try`'s inventory, not
`main`'s. Also settle the `aws-trial` branch's `deploy/aws-trial/**`: it is a rehearsal artifact,
not the production target — harvest the Dockerfiles and `apply_migrations.py`, tear the EC2
instance down by Phase 3 (ask first), and move `.trial-env` out of the repo.

**SCOPE — stay inside this repo.** All work happens in this repository and its git worktree.
Read, reference, and import only files inside it. Do not open, read, copy from, or modify
`schdualer/`, `qgenda/`, any other product, any other business folder, Desktop, or Downloads —
even if something useful appears to live there. If something outside is genuinely needed, stop
and ask me; then it gets copied into its proper place rather than referenced where it sits. No
absolute paths to anything outside the repo in code or config — use `.env` or settings.

**Repo layout** — document in `docs/architecture/repo-layout.md`:

```
infra/           AWS CDK app (foundation, network, data, auth, compute, api, observability)
src/             business logic only (shared by API, workers, CLI)
src/processes/   one folder per process (manifest + processor + tests)
api/             FastAPI layer (routes, schemas, auth, OpenAPI)
workers/         generic process worker
web/             Next.js app
migrations/      Alembic migrations (baselined from supabase_migrations/)
tests/           shared + conformance + security tests
docs/            architecture, ADRs, runbooks, compliance, API docs
scripts/         dev/ops scripts with header comment, --help, --dry-run
```

- Code and data stay separate: no generated output, exports, PDFs, databases, client files, or
  PHI in the repo. Outputs go to S3.
- Every folder gets a short README saying what lives there and what does not.

**Conventions**

- AWS resource naming: `meridian-<env>-<component>-<purpose>`.
- Every AWS resource tagged: `Project`, `Environment`, `Owner`, `DataClassification`
  (`phi|internal|public`), `CostCenter`, `ManagedBy=cdk`. CI fails on untagged resources.
- One formatter and linter per language, enforced by pre-commit and CI; type checking on in
  Python and TypeScript.
- Config: one typed settings module per app; values from environment / Secrets Manager. No new
  `config/*.json`; migrate legacy JSON config into Postgres when touched.
- Dependencies pinned; unused ones removed. Tests are `pytest tests/` and `cd web && npm test`;
  **the CI image must include LibreOffice** or `tests/conftest.py` skips tests silently.

**Decisions & docs**

- **ADRs** in `docs/adr/` for every significant choice — context, decision, consequences.
- **Runbooks** in `docs/runbooks/`: deploy, rollback, restore, rotate secrets, revoke API
  client, incident response, onboard partner, add a process.
- Control matrix and data-flow diagrams in `docs/compliance/`, updated every phase.
- `CHANGELOG.md` updated each phase in plain language.
- `CLAUDE.md` is **gitignored** — when its rules change (Supabase-only storage, "never remove
  `web_app.py`", `/gsd` workflow), update it locally **and** record the change in tracked docs
  (`README.md`, `docs/architecture/`).

**Removing the old**

- Nothing stays half-migrated: when something moves to AWS, the old path is removed in the same
  phase or tracked with an owner and deadline in `docs/migration-tracker.md`.
- Dead code, unused routes, retired Jinja templates (only once a React screen covers them and
  nothing in `next.config.mjs` points at them), legacy paths, stale env vars — removed with a
  test proving nothing depends on them.
- No duplicate implementations, no "v2-final" copies, no commented-out blocks.

**AWS hygiene**

- Drift detection: `cdk diff` in CI, plus CloudTrail alerts on console `Create*` calls by
  humans. (No managed Config rule does this — do not hand-roll a Lambda for it.)
- Log retention and S3 lifecycle rules on every log group and bucket, per documented HIPAA
  retention requirements.
- AWS Budgets and cost anomaly alerts per environment.

---

## PHASES — in this order

Phase order is **decided: cutover first** (plan D-16). Getting onto AWS comes before building the
process framework and the public API — same total work, live on AWS roughly six months sooner, and
a much shorter window of paying for and maintaining two systems.

0. **Inventory, safety sweep, threat model, baseline.** The untracked-file sweep and git
   reconcile above; every Supabase table, RLS policy, auth flow, storage bucket, env var, and
   external call; the full `next.config.mjs` Jinja-route list; existing process registry; PHI
   classification; data-flow diagram; target repo layout; ADRs for account topology, ALB vs API
   Gateway, and the auth model. Step 1 is the branch reconcile (plan D-23);
   `local_plugins.EXTRA_PROCESSES` is unverified-local and not a dependency (D-24).
1. **AWS foundation.** Single account with staging/production isolated by VPC, IAM, and KMS
   (structured so a second account can be split off later), SCPs where they apply, CloudTrail,
   Config, GuardDuty,
   Security Hub, KMS, tagging/naming, budgets, **cost estimate approved by me**, BAA
   confirmation, **SES domain verification and sandbox-exit request started**.
2. **Network & IaC.** CDK app, VPC, subnets, security groups, free gateway VPC endpoints for S3
   and DynamoDB only — no interface endpoints, since NAT cannot be removed anyway (plan D-19 has
   the comparison) — WAF.
3. **Data tier (staging only).** RDS Postgres, Alembic baselined from the 37 existing
   migrations, S3 buckets + KMS, RLS via `app.org_id` under a non-superuser role, rehearsal
   data load on staging with row counts and checksums. **Nothing in production writes to RDS
   yet.**
4. **Auth.** Cognito user pool, MFA, Google and Microsoft re-registered as federated IdPs.
   Roles, permissions, and invite codes stay in Postgres (migrations 027/029/030) — do not
   model them in Cognito groups. During transition the API accepts **both** Supabase and
   Cognito tokens. **Cognito goes live in production at the end of this phase (Flip 1)**, while
   data is still on Supabase — it does not wait for cutover, and it stays reversible until the
   decommission phase (Phase 10). One immutable custom attribute `custom:app_uid` carries the Supabase UUID so no
   user-id column is ever rewritten. Federated-only users (Google/Microsoft — including the only
   superadmin) are pre-created with `AdminCreateUser` and linked with
   `AdminLinkProviderForUser` **before** the IdPs are enabled; the Lambda never fires for them. **Password migration is decided: a Cognito User Migration Lambda** that
   verifies the password against Supabase Auth at first login and creates the Cognito user
   silently — nobody is forced to reset. Consequences that must be planned for, not
   discovered: Supabase Auth stays live until every active user has migrated (track a
   migration percentage and report it), the Lambda handles both the sign-in and
   forgot-password triggers, it never logs passwords, it fails closed on a Supabase outage
   with a clear error, it runs outside the VPC within a 5-second timeout (Cognito abandons the
   trigger at about 5s) with p99 measured on staging before the production flip, and the
   decommission phase sets a cut-off date (cutover + 60 days) after which unmigrated users get a
   password reset instead.
5a. **FastAPI alongside Flask.** Port `/api/v2` and the data layer to FastAPI with `src/` logic
   unchanged, running **beside** Flask, not instead of it. Containerize API and Next.js (the
   worker container arrives with the process framework, after cutover); CI/CD to staging ECS with
   image scanning.
5b. **The Jinja gap.** Every path in the `jinja` rewrite list in `next.config.mjs` gets a React
   screen or an explicit drop — `/wearbly` and `/signup` are dropped by plan decisions P-5 and
   P-6. That is an exit criterion.
6. **Observability & audit.** Logs, metrics, alarms, PHI access audit trail, dashboards. This
   comes **before** anything serves production traffic on AWS — never run a PHI system
   unmonitored.
7. **Email.** Replace Resend with SES (verification done back in Phase 1).
8. **Security hardening & production deploy.** Control matrix complete, scans clean, dynamic
   scan, restore drill, DR test, pen-test prep package, production stack deployed and ready.
9. **Cutover.** Write freeze, final migration of Postgres tables **and** Storage objects
   (preserving `{org_id}/{batch_id}/…` prefixes) with checksums, staging rehearsal first,
   rollback tested. **Ask me before cutover** — and never during a close. The point of no return
   is the first write on AWS (strict — plan D-20); the cutover smoke test is read-only. Render
   stays running and the Supabase project stays live for two full close cycles afterwards.
10. **Decommission Supabase and Render.** Gated by two clean closes on AWS. Completion assertion
    before Supabase is cancelled: every `auth.users` row with an org membership exists in Cognito
    with a matching `custom:app_uid`. That cancellation is the only irreversible step, so the
    final archive is restore-tested first. **Ask me before deleting anything.**
11. **Process framework.** Manifest extending the existing registry, generic worker container,
    scaffold command, conformance suite; migrate processes one by one with output comparison;
    serialize worker state out of process memory. This phase also retires Flask and `web_app.py`
    and lifts the single-task limit.
12. **API platform, API security & final cleanup.** `/api/v3`, scopes, machine auth, process
    endpoints, webhooks, OpenAPI + generated clients, admin screen, sandbox, full security tests,
    `docs/plans/mobile-readiness.md`; retire `/api/v1`; migration tracker empty; repo layout matches the
    doc.

---

## PHASE COMPLETION LOOP

`/loop` continuously. When a phase's exit criteria are met, write its phase report and **start the
next phase immediately** — do not stop to ask whether to continue, do not ask for approval of work
already specified here, and do not wait for me between phases. I will interrupt when I want an
update; silence means keep going.

**Stop and ask only for these** (everything else proceeds without me):

1. **Cutover** (Phase 9) and **decommissioning Supabase or Render** (Phase 10) — the two
   irreversible steps.
2. **Deleting or overwriting anything** — data, resources, branches, files I have not already
   agreed to remove.
3. **Spending beyond the approved estimate** — the Phase 1 cost approval, and any later change
   that raises the monthly bill above it.
4. **A decision this document and the plan do not already answer** — and only after checking
   both. If a reasonable default exists, take it, write it down as a provisional decision with
   the trigger that would change it, and keep moving.
5. **Anything that would send PHI, secrets, or client data outside AWS or to an external tool.**

Everything else — architecture inside the stated stack, refactors, migrations on staging, tests,
docs, commits, review cycles — is pre-approved. Fix problems, don't report them and wait.

Exit criteria for a phase:

- Every product feature in the phase works for real — no placeholder functionality, dead
  interfaces, or fake buttons. (Test doubles in tests are fine.)
- All tests pass: unit, integration, migration, `cdk synth`/`diff`, process conformance, and
  security tests (cross-org, unauthorized access, wrong scope — all must fail safely).
- **Fable critic review:** zero unresolved critical/high findings.
- **Codex (GPT) review** of the phase's changes: zero unresolved critical/high findings. Fix,
  then re-run both until clean. Never send PHI, secrets, client files, or `.env` contents to
  Codex.
- Tidy check: layout matches the doc, lint/format/type checks clean, resources tagged, no
  drift, no stray files, old paths removed or tracked.
- Control matrix, ADRs, runbooks, and `CHANGELOG.md` updated.
- Phase report: what was built, evidence, open risks, and the `needs-a-human` list.
- Short note added to the Obsidian vault under `NS_Proccess/`.

Items only a human can do — BAA, partner BAAs, written policies, penetration test, auditor —
go on the `needs-a-human` list and do **not** block phase exit.

---

## THE CRITIC

A separate Fable agent, deliberately harsh. It must reject:

- fake functionality, placeholder buttons, dead interfaces, mock persistence
- anything still on Supabase or another non-AWS provider after its phase, or a non-HIPAA-eligible
  service touching PHI
- secrets or client data in code, logs, or commits; PHI in logs, webhooks, or fixtures
- wildcard IAM, public database access, unencrypted storage, missing audit trails
- missing object-level authorization, weak org isolation, unscoped endpoints
- a second process registry instead of extending the existing one
- console-created or untagged AWS resources, `cdk diff` drift
- unindexed or unbounded queries, missing transactions, unsafe concurrency
- untested migrations, untested restores, untested rollback
- a JE that can be double-posted to QuickBooks on retry
- broken responsive or inaccessible UI, unhandled errors
- half-migrated paths, duplicate implementations, undocumented decisions

It keeps going until it would be comfortable putting this system in front of a HIPAA auditor and
a penetration tester.

---

## PRIORITIES, IN ORDER

1. security and compliance
2. correctness and data integrity
3. reliability
4. maintainability and tidiness
5. speed
6. usability
7. visual polish

---

## RULES FROM THIS REPO

- Follow `CLAUDE.md` and the global `CLAUDE.md`, except where this document supersedes them —
  and say so explicitly when it does.
- Business logic stays in `src/`. New UI work in `web/` only.
- Smallest change that works. Ask before adding dependencies.
- Explain changes to me in plain language and define jargon the first time you use it.
