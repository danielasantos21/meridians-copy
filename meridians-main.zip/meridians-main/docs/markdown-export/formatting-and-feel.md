# Meridian — Formatting & Feel (Design Spec)

> **Pages compared:** Home (`/`) and Features (`/features`)
> **Purpose:** Capture the *visual* formatting Markdown content-extraction throws away — colors, type, spacing, components, and per-page feel.
> **Source of truth:** the pages' Tailwind config + utility classes (server-rendered HTML).

---

## Screenshots

> **Note:** These are de-identified **mock** pages (fictional brand "Ledgerly", fully invented copy & data) built to illustrate the layout/feel — they intentionally contain no real branding or copy. The mock HTML source (`mock/`) was removed on 2026-09-29; the screenshots below are what remains (it is in git history at `239060d`).

### Home (mock)
![Ledgerly mock home page — angled browser mockup](assets/home-mockup.png)

### Features (mock)
![Ledgerly mock features page — angled browser mockup](assets/features-mockup.png)

<details><summary>Flat full-page captures</summary>

![Ledgerly mock home page](assets/home.png)
![Ledgerly mock features page](assets/features.png)

</details>

---

## Design Tokens (shared by both pages)

### Color palette
| Token | Hex | Role |
|---|---|---|
| `primary` | `#0f1729` | Brand navy — headings, buttons, dark sections, logo |
| `accent` | `#3b82f6` | Blue — highlights / interactive accents |
| `background-light` | `#f6f7f8` | Light page background |
| `background-dark` | `#14171e` | Dark background variant |
| (footer) | `#0f172a` | Near-navy footer block |

Tinted fills are derived from `primary` at low opacity — `bg-primary/5`, `bg-primary/[0.02]`, `bg-primary/[0.03]` — for soft, layered section bands.

### Typography
- **Font family:** `Inter` (weights 300–900), set as the `display` family. Single typeface across both pages.
- **Icons:** Material Symbols Outlined (the `check_circle`, `arrow_forward`, etc. ligatures seen as text in the content `.md`).
- **Type scale (Tailwind):** `text-xs → text-7xl`
  - Hero headline: `text-6xl`/`text-7xl`, bold/extrabold
  - Section titles: `text-4xl`/`text-5xl`
  - Body: `text-base`/`text-lg`
  - Labels & captions: `text-xs`/`text-sm`

### Shape & radius
| Radius | Value | Used for |
|---|---|---|
| `DEFAULT` | `0.75rem` (12px) | base cards |
| `lg` | `1rem` (16px) | larger cards |
| `xl` | `1.25rem` (20px) | feature cards |
| `full` | `9999px` | pills, buttons, badges |

### Spacing rhythm
- Sections breathe on a `py-24` / `py-32` vertical rhythm (≈96–128px), giving an airy, modern-SaaS cadence.
- Eyebrow labels sit in pill chips: `px-3 py-1 rounded-full bg-primary/5 border border-primary/10`.

### Buttons
- **Primary:** `bg-primary text-white px-5 py-2 text-sm font-bold rounded-full hover:bg-primary/90 transition-all` — navy pill, bold, subtle hover darken.
- **Secondary:** outlined / ghost variant of the same pill.

### Motion
- Hover/state transitions via `transition-all` / `transition-colors`.
- Home adds an `animate-pulse` (live/processing feel); Features uses no keyframe animation.

---

## Per-page feel

Both pages run the **same design system** (same font, palette, tokens, section rhythm), but tune it for a different mood:

| Trait | **Home (`/`)** | **Features (`/features`)** |
|---|---|---|
| Intent | Marketing landing page | Product spec / capability tour |
| Corners | Mostly `rounded-full` (pill-shaped, soft) | Mostly `rounded-xl` / `rounded-lg` (boxier cards) |
| Elevation | `shadow-xl` | `shadow-2xl` (deeper, more lifted cards) |
| Section backgrounds | Many tinted bands (`bg-primary/5`, `/[0.02]`) → layered, soft | Mostly flat `bg-white` → clean, clinical |
| Motion | `animate-pulse` present | None |
| Vertical rhythm | `py-24` + `py-32` (more dramatic, varied) | `py-24` (steadier, uniform) |

**Summary of feel:**
- **Home** — softer, warmer, more *persuasive*. Pill shapes, tinted layered sections, a live pulse animation, bigger spacing jumps. Reads like a polished marketing site.
- **Features** — flatter, crisper, more *informational*. White cards, deeper shadows, boxier corners, even rhythm. Reads like a precise product datasheet.

---

## Notes
- This file documents **visual formatting**, complementing the content exports `home.md` and `features.md` (which intentionally drop styling).
- Values are pulled from the live Tailwind config and utility classes; if the templates' styling changes, re-derive from `templates/public/home.html` and `templates/public/features.html` (+ shared `templates/public/base.html`).
