# Features — Meridians

> **Source:** http://localhost:5050/features
> **Converted:** MD-This-Page style (main content only, nav/footer stripped)

---

Platform Overview

# Powerful automation for every accounting workflow.

Modernize your ledger with precision-engineered tools designed for accuracy, speed, and absolute compliance.

[Go to Portal](/dashboard)
[View Pricing](/pricing)

auto\_awesome

## Automated JE Generation

Convert billing exports into perfectly balanced, NetSuite-ready journal entries. Meridians generates 15 location-specific JE files per run with correct account codes, departments, and fiscal dates.

- check\_circle
  Automatic debit/credit balancing
- check\_circle
  15 location-specific output files per run

JE\_Revenue\_Bishop\_P8\_FY25
BALANCED

Account

Description

Debit

Credit

41003

Private Insurance

-

$8,450.00

41001

Medicaid

-

$3,200.00

41002

Medicare

-

$1,850.00

18099

Clearing

$13,500.00

-

account\_tree

#### Mapping Configuration

Source Payer
BCBS\_TX\_PPO

trending\_flat

Account Code
41003 - Pvt Ins

Provider
DOE, jordandoe

trending\_flat

Department
09 - MFM - MD

Department follows the billing provider, not the facility. Provider "DOE" maps to dept 09 regardless of location.

account\_tree

## Smart Mapping Rules

Define payer classifications, provider-to-department assignments, and location codes in a single configuration file. Set the rules once and Meridians applies them consistently across every run.

"The automated mapping has eliminated our month-end classification errors entirely."

— Finance Team Lead

payments

## Revenue & Payroll

Handle billing exports, US payroll, and ADP payroll with automated department and location splits. Every dollar is attributed to the correct account, department, and location across all 15 facilities.

Revenue JEs
US Payroll
ADP Payroll
Unposted JEs

receipt\_long

#### Revenue Processing

15 JE files · 11 clinic groups

ACTIVE

groups

#### US Payroll

ADP exports · Role-based depts

ACTIVE

account\_balance\_wallet

#### ADP Payroll

Employee allocations · Multi-loc

ACTIVE

P8 — FY25
4-5 Week Cycle

Period Start
Jul 7, 2025

Period End
Aug 3, 2025

JE Date
Aug 3, 2025

Status
ACTIVE

event\_note

## Custom Fiscal Periods

Built for non-standard fiscal calendars. Meridians uses a 4-5 week period cycle running from late December to late December. Transaction dates are validated against the calendar, and JE dates use the period end date automatically.

13

Fiscal Periods

100%

Date Validation

history\_edu

## Full Audit Trail

Every processing run is tracked in SQLite with full history. Know exactly which file was processed, when, by whom, and what the output was. Reprocess any period with confidence.

[Explore the portal
arrow\_right\_alt](/dashboard)

#### Processing History

check\_circle

P8 FY25 — Revenue
Mar 15, 2025 at 2:14 PM

15 files

check\_circle

P8 FY25 — Payroll
Mar 15, 2025 at 3:02 PM

1 file

refresh

P7 FY25 — Revenue (Reprocess)
Mar 10, 2025 at 9:45 AM

15 files

## Ready to modernize your ledger?

Automate your journal entry workflows and eliminate manual data wrangling.

[Access Portal](/dashboard)
[View Pricing](/pricing)
