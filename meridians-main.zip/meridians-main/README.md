# Meridian — QuickBooks Revenue & Payroll

Accounting automation for **Stella Mattina Health, Inc.** Two processes:

| Process | Input | Output |
|---|---|---|
| **QB Revenue** (`/qb-revenue`) | billing system export (.xlsx) | QuickBooks Online journal-entry CSVs, one per clinic |
| **QB Payroll** (`/mx-payroll`) | Mexico payroll workbook (.xlsx) | QuickBooks Online payroll JE CSV |

Both are part of the NetSuite → QuickBooks Online migration. They reuse the existing
revenue/payroll pipelines and swap the exporter at the end, so the numbers are identical
to the NetSuite output — only the format and the account/class/location names change.

Live at https://www.meridiansgrp.com (login required). From the AWS cutover the app is
https://app.meridiansgrp.com, `www` is the public website only, and the partner API is
https://api.meridiansgrp.com/v3 (ADR 0050).

---

## Migration to AWS (2026-09 →)

Meridian is being moved off Render and Supabase onto AWS. Everything below this section
describes the system **as it runs today**; it is accurate, and it is not the target.

- **Where the migration is defined:** [`docs/aws-migration-plan.md`](docs/aws-migration-plan.md)
  (plan, effort, cost, decision register) and
  [`docs/aws-migration-prompt.md`](docs/aws-migration-prompt.md) (the executing instructions).
- **Where files go:** [`docs/architecture/repo-layout.md`](docs/architecture/repo-layout.md)
  — §5 carries the three binding rules below in full.
- **Why each choice was made:** [`docs/adr/`](docs/adr/README.md).
- **Anything half-migrated:** [`docs/migration-tracker.md`](docs/migration-tracker.md).

### The three rules that replace the `CLAUDE.md` rules for migration work

`CLAUDE.md` is gitignored, so a rule that only lives there does not survive a fresh clone.
These are recorded here and in `docs/architecture/repo-layout.md` §5. Where they conflict
with `CLAUDE.md`, **these win for all migration work.**

1. **Data and config live in AWS RDS PostgreSQL, not Supabase.** `CLAUDE.md`'s "all data
   and configuration must live in Supabase — no exceptions" is replaced (decision D-01).
   The `public` schema on RDS is managed by Alembic; patient identifiers and raw billing
   rows live in a separate `phi` schema reachable only through `src/phi.py`; object storage
   is S3. SQLite (`data/revenue.db`) stays frozen for the legacy CLI only.
2. **`web_app.py` stays until Phase 11 retires the last Flask path.** It is not the
   superseded Jinja app — it hosts the `/api/v2` Flask blueprint, auth and the background
   workers the React app proxies into. FastAPI is built *beside* it in Phase 5a; deleting
   it before Phase 11 takes production down.
3. **The API is `uvicorn api.main:app`, not `gunicorn web_app:app`.** Since Phase 5a
   (ADR 0023) the process is a FastAPI app with the Flask app mounted underneath it, so
   the two serve one origin. `python web_app.py` still runs Flask on its own and is the
   quickest loop for Jinja work, but it does **not** serve the ported paths
   (`/api/v1/health`, `/api/v2/auth/*`) — use `scripts/serve_api.sh` for the whole app.
   A path is removed from Flask in the same commit that lands it in FastAPI, never both.
4. **The migration's phase loop supersedes the `/gsd` workflow** for this work.
   `docs/aws-migration-prompt.md` defines the loop; `/gsd` remains the workflow for
   non-migration work in this repo.

---

## Tech stack

| Layer | What we use |
|---|---|
| Web app | **Flask 3** (`web_app.py`) + Jinja templates, server-rendered, **mounted under a FastAPI app** (`api/`) since Phase 5a |
| API | **FastAPI** (`api/`) — every `/api/v2` route and `/api/v1/health`; the remaining Flask rules (Jinja screens, legacy config routes) fall through to the mounted Flask app at the same origin (ADR 0023). **`/api/v3`**, the partner API (machine clients, scopes, webhooks), is built behind `MERIDIAN_API_V3` on the Postgres backend only (ADR 0035) |
| Server | **uvicorn** on **Render** (`render.yaml`, `uvicorn api.main:app`), health check `/api/v1/health` |
| Database | **Supabase** (hosted Postgres) — all data *and* all config today; **moving to Amazon RDS for PostgreSQL** (see above) |
| Auth | **Supabase Auth**: email/password, Google, Microsoft SSO. JWT in a cookie (`src/auth.py`) |
| Authorization | Postgres **RLS** + `roles`/`role_permissions`; every row scoped by `org_id` |
| File storage | **Supabase Storage** — private buckets `uploads`, `outputs`, path `{org_id}/...` |
| Excel | **pandas**, **openpyxl**, **xlsxwriter**, **rapidfuzz** (fuzzy provider/employee matching) |
| Email | **Resend** (invites, run notifications) today; **Amazon SES** behind `EMAIL_BACKEND=ses` — one switch, no dual-send (ADR 0014, ADR 0025, `docs/runbooks/email-cutover.md`) |
| Background jobs | **The generic worker** (`workers/`, ADR 0028): one `run_job` path, fed by SQS on AWS (`python -m workers`) or in-process locally (`JOB_TRANSPORT=inprocess`). Only on `DATABASE_BACKEND=postgres`, and only for the processes named in `WORKER_PROCESSES` |
| Tests | **pytest** (`tests/`, incl. `tests/conformance/` and `tests/security/`), `infra/tests/` (CDK assertions), **vitest** in `web/` |

Python 3.13 (what ships; `tests/test_python_version.py` holds the image, the lock file, CI and `render.yaml` to it) · deps in `requirements.txt`, pinned in `requirements.lock.txt` · secrets in `.env` (gitignored).

---

## The database

One hosted Supabase Postgres project — the system of record **until the Phase 9 cutover**,
after which it is RDS. **Everything lives here — data, mappings, settings. No JSON config
files, no SQLite for anything new.** Every table carries `org_id` and has RLS enabled, so a
single deployment serves multiple client organizations without them seeing each other's data.

The Supabase-era schema is **37 SQL files** in `supabase_migrations/migrations/` (see
[`supabase_migrations/README.md`](supabase_migrations/README.md)). Alembic (`migrations/`)
replays them verbatim as its baseline revision and carries every change since;
`alembic -c migrations/alembic.ini upgrade head` with `MERIDIAN_DATABASE_URL` set
(`docs/runbooks/migrations.md`). `scripts/run_migrations.py` is superseded and only the
retired aws-trial branch still imports it (migration tracker).

### 1. Who can see what

| Table | Rows | Tracks |
|---|---|---|
| `organizations` | 2 | the client companies |
| `org_members` | 7 | user ↔ org ↔ role |
| `roles` | 3 | role definitions (admin, user, …) |
| `role_permissions` | 14 | which process each role may open (`revenue`, `payroll`, …) |
| `invite_codes` | 30 | signup invites |
| `org_modules` | 4 | which processes are switched on per org |
| `superadmins` | 1 | cross-org access (us) |

The QB routes are gated by `@require_permission('revenue', 'access')` and
`@require_permission('payroll', 'access')` — they share permissions with the NetSuite versions.

### 2. Each processing run

| Table | Rows | Tracks |
|---|---|---|
| `uploads` | 36 | every uploaded file — name, MD5 hash, size, Storage path |
| `import_batches` | 15 | one row per run: period, fiscal year, status, totals |
| `source_transactions` | 166,819 | raw rows exactly as they came out of the billing export |
| `transactions` | 76,132 | the same rows after mappings are applied (payer type, account, location, department) |
| `journal_entries` | 1,228 | the generated JE lines |
| `unmapped_items` | 0 | anything the mappings couldn't resolve — your review queue |
| `processing_runs` | 17 | newer run-level audit trail |
| `processed_entries` | 1,305 | newer output-line audit trail |

Source rows are kept forever, so any JE can be traced back to the exact input row.

### 3. Revenue mappings (the old `mappings.xlsx`, now editable at `/config`)

| Table | Rows | Tracks |
|---|---|---|
| `config_payers` | 470 | payer name → payer type + revenue account |
| `config_locations` | 34 | facility name → location code + clinic group |
| `config_providers` | 71 | provider → department |
| `config_departments` | 7 | the managed department list |
| `config_clinic_groups` | 11 | the 11 clinic groups and their locations |
| `config_account_codes` | 4 | payer type → GL account (41001–41004) |
| `config_settings` | 2 | subsidiary path, clearing account (18099) |
| `config_fiscal_calendar` | 24 | period → JE date (the period **end** date) |
| `fiscal_calendar` | 6,209 | day-by-day: any date → its fiscal period |
| `config_history` | 0 | audit log of config edits |

### 4. Mexico payroll mappings

| Table | Rows | Tracks |
|---|---|---|
| `config_mx_employees` | 99 | MX employee roster → department, active flag |
| `mx_payroll_column_map` | 44 | payroll-workbook column → GL account |

### 5. NetSuite → QuickBooks translation (`qb_*`)

This is the layer that makes the two QB processes different from the NetSuite ones.
Seeded by migration 017 from the Python dicts in `src/qb_mappings.py` and
`src/qb_revenue_mappings.py`, which stay in the code as an **offline fallback** — if
Supabase is unreachable or a table comes back empty, the loaders log a warning and use
the hardcoded dicts, so a DB hiccup can never produce a broken JE.

| Table | Rows | Tracks |
|---|---|---|
| `qb_account_map` | 15 | NetSuite account number → full QB account path. `domain` column splits revenue vs payroll |
| `qb_department_map` | 18 | NetSuite department → QB **Class** (shared by both processes) |
| `qb_location_map` | 2 | NetSuite location → QB **Location** (payroll) |
| `qb_clinic_map` | 17 | location name → QB clinic Location (revenue); also holds the Buckner service-line split |
| `qb_provider_map` | 33 | provider name → QB provider code (e.g. `MEDOBG004`), used as the **Name** column |
| `qb_other_code_map` | 3 | service line → rollup/"Other" code (`MEDOBG999`, `MEDFAM999`, `MEDMFM999`) |
| `qb_payer_label_map` | 4 | payer type → the label used in the line description |

Loaded by `qb_mappings.load_payroll_maps()` and `qb_revenue_mappings.load_revenue_maps()`.

### 6. Also in the database (not part of these two processes)

`payroll_employees`, `employee_clinic_allocations`, `payroll_column_account_map`,
`bkv5_location_remap`, `config_mso_mappings`, `config_employees` (US/ADP payroll) ·
`uniform_*` (Wearbly) ·
`qgenda_workspaces`. Left in place, untouched by QB revenue/payroll.

---

## Code that matters

```
api/main.py                       # the app uvicorn serves: FastAPI, Flask mounted under it
api/routers/                      # /api/v2, one module per area
api/v3/                           # /api/v3, the partner API (MERIDIAN_API_V3)
workers/                          # the generic job worker (SQS or in-process) and the sweeps
web_app.py                        # the Flask half: Jinja screens and legacy routes until Phase 11 G5
│
src/
├── auth.py                       # Supabase Auth, @require_auth / @require_permission
├── storage.py                    # Supabase Storage / S3 upload/download
├── database.py                   # Supabase table accessors; DatabasePostgres (RDS, being ported)
├── pg.py                         # the psycopg2 repository layer: pool, with_org(), transaction()
├── phi.py                        # the ONLY module that touches the phi schema (ADR 0012)
├── settings.py                   # the backend switches and the connection/TLS configuration
├── config.py                     # loads the config_* mapping tables
│
├── REVENUE PIPELINE (shared with the NetSuite process)
│   ├── fiscal_calendar.py        # date → fiscal period, period validation
│   ├── enrichment.py             # apply payer / location / provider mappings
│   ├── hospital_enrichment.py    # fold hospital facilities into their parent clinic
│   ├── aggregation.py            # group by location × department × payer type
│   ├── je_generator.py           # build JE lines
│   ├── unposted_generator.py     # unposted revenue JEs (account 43006)
│   └── revenue_qb_exporter.py    # ← QB CSV output
│
├── PAYROLL PIPELINE (Mexico)
│   ├── payroll_processor.py      # read the workbook, detect period, map columns
│   ├── payroll_je_generator.py   # NRF day split, provision date, JE lines
│   └── payroll_qb_exporter.py    # ← QB CSV output
│
├── processes/                    # one folder per process: manifest.py + pure processor.py
│   ├── qb_revenue/  mx_payroll/  qb_usa_payroll/
│   └── manifest.py               # the registry /api/v2, /api/v3 and the worker read
├── process_runs.py               # the run store (public.process_runs)
├── process_inputs.py             # uploads kept by version; the GuardDuty malware gate
├── idempotency.py, qbo_posting.py  # the ledger that stops a QuickBooks journal posting twice
├── webhooks/                     # /api/v3 webhook outbox, signing, SSRF guard
│
├── qb_mappings.py                # payroll NS→QB dicts + load_payroll_maps()
├── qb_revenue_mappings.py        # revenue NS→QB dicts + load_revenue_maps(), qb_date()
└── exporters.py                  # shared Excel styles + CSV writing

migrations/versions/               # the Alembic chain (migrations/README.md lists it)
supabase_migrations/migrations/   # 37 SQL files — history, replayed by Alembic 0001
tests/conformance/                # every process manifest against the platform contract
tests/security/                   # the /api/v3 OWASP suite; `pytest --known-bad` must be all red
tests/golden/                     # byte-for-byte processor outputs from synthetic inputs
tests/test_pg.py                  # the pool, the org scope, autocommit, DEC2FLOAT
tests/test_phi.py                 # the token matches the SQL split; the role always resets

Dockerfile.api                    # the api image (Flask/FastAPI + WeasyPrint, ARM64)
web/Dockerfile                    # the Next.js image (standalone output)
.dockerignore                     # what must never reach an image - read it before COPY . .
```

---

## Running it

Two ways to run the app. **Local development** is the AWS-shaped stack on your Mac with
synthetic data only (PostgreSQL, the same roles and row-level security as RDS, local disk
for files, no sign-in). **Against Supabase** is how production runs until the Phase 9
cutover. Both serve the same app: FastAPI with Flask mounted under it on port 5050
(`scripts/serve_api.sh`, ADR 0023) and the Next.js app on port 3000.

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cd web && npm ci && cd ..
```

### Local development (AWS-shaped, synthetic data)

Needs Homebrew PostgreSQL (`brew install postgresql@17`; 18 also works) — or Docker, see
below. No client data and no PHI are involved: two made-up organizations are seeded from
the placeholder names in `config/mappings.example.xlsx`.

**1. Pick a home for the local database and choose passwords.** The cluster directory
must be outside the repo. Put these in your shell or in `.env` (the bootstrap reads `.env`
for any name you have not exported, and never prints a value). Use URL-safe values such as
`openssl rand -hex 24`.

```bash
export MERIDIAN_LOCAL_PGDATA="$HOME/Business/Meridians Logic/Products/<product>/data/local-pg"
export MERIDIAN_LOCAL_MIGRATOR_PASSWORD=...   # owner role (the RDS master user's shape)
export MERIDIAN_APP_DB_PASSWORD=...           # meridian_app, the role the api uses
export MERIDIAN_PHI_DB_PASSWORD=...           # phi_access
export MERIDIAN_PHI_HMAC_KEY=...              # any local-only random value
```

**2. Bootstrap.** Creates the cluster (once), starts it on `127.0.0.1:55432`, creates
`meridian_migrator` and `meridian_local`, runs `alembic upgrade head`, seeds the two
organizations, and writes the api's environment to `$MERIDIAN_LOCAL_PGDATA.env`
(mode 0600, beside the cluster). Safe to re-run. `--dry-run` shows the plan, `--no-seed`
skips the seed, `--stop` stops the cluster.

```bash
scripts/local_db_bootstrap.sh
```

**3. Run the api and the web app** (two terminals):

```bash
set -a; . "$MERIDIAN_LOCAL_PGDATA.env"; set +a
scripts/serve_api.sh                # http://localhost:5050
```

```bash
cd web && npm run dev               # http://localhost:3000
```

The env file sets the local mode:
`APP_ENV=development DATABASE_BACKEND=postgres STORAGE_BACKEND=local AUTH_BACKEND=disabled EMAIL_BACKEND=disabled MERIDIAN_API_V3=1`,
plus `POSTGRES_URL` (the `meridian_app` connection), `LOCAL_DEV_ORG_ID` and
`MERIDIAN_PHI_HMAC_KEY`. Exported values win over `.env`, so a Supabase `DATABASE_URL` in
`.env` cannot redirect it. With `AUTH_BACKEND=disabled` every request is the dev user
(`src.auth.LOCAL_DEV_USER_ID`), who is admin of "Local Dev" and a superadmin — unless you
pick a test user (below). "Local Dev" has production's shape: the modules and the three
roles (Member, Payroll, Revenue) live Stella Mattina has, with the same permission rows. A
second organization, "Synthetic Second Clinic", has its own admin. The synthetic revenue
workbook the seed writes (path printed at the end) is for uploading in the app. Check it
with:

```bash
curl -s localhost:5050/api/v3/health   # {"status":"ok","version":"3.0.0","database":"postgres"}
curl -s localhost:5050/api/v2/org      # Local Dev, member_count 5
```

**Sign in as a test user (see it the way each person does).** Open
<http://localhost:3000/login>. In local mode the page shows **Sign in as (local test
users)**; click a name and you land on the dashboard as that person. The server then answers
every request from that user's own rows — their organization, admin or role, the org's
modules, superadmin or not — exactly as it answers a real signed-in person, so hidden
screens, 403s and 404s are the real ones. A bar at the top says **Local test user: … —
Switch**; Switch (or Sign out) takes you back to the list. The users (all synthetic):

| Email | Who | What they see |
|-------|-----|---------------|
| `dev@localhost` | Admin of Local Dev + superadmin | everything (the default) |
| `admin@local.test` | Admin of Local Dev, not superadmin | all of Local Dev, no superadmin console |
| `payroll@local.test` | Local Dev, role Payroll | revenue, both payrolls, config (read) |
| `revenue@local.test` | Local Dev, role Revenue | revenue, config (read) |
| `member@local.test` | Local Dev, role Member | revenue, config (read) |
| `admin2@local.test` | Admin of Synthetic Second Clinic | only that clinic; Local Dev's runs are 404 |
| `noorg@local.test` | in no organization | the "no organization yet" screen |

After a pull (step 6) the list also has the pull's one-per-role users, and every user is
grouped under their organization with a label read from their rows, e.g. **Payroll — Stella
Mattina Health**. Any user in the local database with a profile can be chosen.

"View as role" (Settings → Roles) still works on top of it. This exists only with
`APP_ENV=development`, `AUTH_BACKEND=disabled` and `DATABASE_BACKEND=postgres`: anywhere
else (Render, staging, production) `/api/v2/dev/sign-in-as` answers 404 and the page shows
nothing. Re-run `scripts/seed_local_dev.py` (or the bootstrap) if the list is empty; it also
brings an older local database up to this shape.

**4. Background jobs (the worker), optional.** Nothing extra runs: on this stack the api
executes jobs itself on the in-process transport (`JOB_TRANSPORT=inprocess`, the default),
through the same `workers/run_job.py` the ECS worker uses. By default the processes still
run on today's thread path; to send them through the job path, export the process ids before
step 3:

```bash
export WORKER_PROCESSES=qb-revenue,mx-payroll,qb-usa-payroll
python -m workers.sweep --dry-run          # the TTL sweeper: what it would expire or fail
python -m workers.outbox_sweep --dry-run   # webhook events waiting to be re-published
```

`python -m workers` itself (the SQS receive loop) needs a real queue
(`MERIDIAN_JOBS_QUEUE_URL`, `JOB_TRANSPORT=sqs`), so it runs on ECS, not here. See
`workers/README.md`.

**5. The partner API (`/api/v3`).** On by default here (`MERIDIAN_API_V3=1` in the env file;
it only ever mounts on `DATABASE_BACKEND=postgres`). A signed-in person reaches it through the
same cookie; machine clients need Cognito tokens, so locally they are exercised by the tests
(`pytest tests/security`) rather than by hand. The contract is `openapi/meridian-v3.json`;
the Python client is `clients/python/`. A QuickBooks connect on the laptop also needs
`MERIDIAN_DEV_QBO_TOKEN_KEY` (32 random bytes, url-safe base64; ADR 0044) — and so does
`/api/v3` itself: webhook signing secrets are sealed with the same key into
`webhook_local_secrets`, so they survive a restart. `scripts/local_db_bootstrap.sh` writes one
into the env file (and keeps it on re-runs); without it the api refuses to start with v3 on.
Webhooks go out for real here: a drainer thread in the api delivers `/test` pings, run events
and retries to the subscribed HTTPS URL, and re-finds deliveries a restart interrupted.

**Tests:** `pytest -q` (everything; the RDS tests start a throwaway PostgreSQL through
`tests/pg_fixture.py`), `pytest tests/security --known-bad` (every breaker must fail),
`pytest infra/tests -q`, `cd web && npm test`. The gates CI also runs: `ruff check .`,
`ruff format --check .`, `mypy`, `python scripts/lint_no_phi_logging.py`,
`python scripts/lint_processor_purity.py`, `python scripts/lint_route_ownership.py`,
`scripts/check_api_drift.sh`.

To start over: `scripts/local_db_bootstrap.sh --stop`, then delete `$MERIDIAN_LOCAL_PGDATA`
and `$MERIDIAN_LOCAL_PGDATA.env` yourself.

**6. Test with the live organizations (`scripts/pull_live_data.py`).** Reads live Supabase
(`SUPABASE_DB_URL` in `.env`) in one read-only transaction and never writes to it. It prints
table names and counts only. Both modes keep the live organization ids, can be re-run (each
pulled organization's copied tables are replaced, nothing else changes), and end with a
live-vs-local check per table (row count + checksum, `OK`/`DIFF`). Try `--dry-run` first: it
counts what would be copied and lists the schema differences, and writes nothing.

- **Configuration only (the default; no patient data).** Into the normal local database from
  step 2 (same variables). Copies organizations (settings without tokens, ACH, keys or
  e-mails), roles, permissions, modules and every mapping/config table. No real person is
  copied: each (organization, membership type, role) becomes one synthetic user, for example
  "Payroll (Stella Mattina Health)". Employee rosters and all data tables are skipped.

  ```bash
  python scripts/pull_live_data.py --dry-run     # counts only
  python scripts/pull_live_data.py               # then run the api as in step 3
  ```

  **Order: bootstrap (step 2) → pull → (optional) seed re-run.** On your laptop
  `LOCAL_DEV_ORG_ID` is the live Stella Mattina id, so the pulled org and the seed's
  "Local Dev" are the same row. They no longer fight, and any order ends in the same
  database:
  - the pull marks each org it writes (`settings.local_pull`); a marked org holds **only
    live configuration** — live name, modules, roles, permissions and mappings;
  - the seed leaves a marked org alone: no rename, no modules or roles, none of its
    placeholder mappings and no qb-usa sample. It only keeps its test users (`dev@localhost`,
    `payroll@local.test`, …) as members, on the **live** roles of the same name (Member,
    Payroll, Revenue); it never creates a role there;
  - the pull does the mirror image: it removes the seed's sample rows from the org and puts
    the test users back on the live role of the same name;
  - "Synthetic Second Clinic" stays the seed's, with its synthetic mappings.

  Re-running either script, in either order, changes nothing further.

- **Everything, onto the PHI drive only (`--full`).** Adds employee rosters and the data
  tables (batches, transactions, source rows, run history), with patient identifiers split
  into the `phi` schema as production does. It is refused unless `/Volumes/MeridianPHI` is
  mounted. It builds a **separate** cluster in `/Volumes/MeridianPHI/Meridian/local-pg`
  (port 55433, via `local_db_bootstrap.sh --no-seed`), writes its env file beside it
  (`local-pg.env`, mode 0600) and logs each pull (date, mode, counts) to
  `/Volumes/MeridianPHI/Meridian/pull-log.txt`. Then start the api against it with the
  command it prints:

  ```bash
  python scripts/pull_live_data.py --full
  set -a; . "/Volumes/MeridianPHI/Meridian/local-pg.env"; set +a; scripts/serve_api.sh
  ```

  `--dev-org ORG_ID` picks the organization the no-sign-in dev user opens (default: the
  first by name); `--org ORG_ID` limits either mode to some organizations.

#### Sandboxes (a branch with its own copy of the live configuration)

A **sandbox** is for building or trying something (a new process, a mapping change)
against the real organizations' configuration without touching `meridian_local`, another
sandbox, or anything live. One name gives you three things: a git worktree on a new
branch `sandbox/<name>`, a database `sandbox_<name>` that is a copy of a **golden**
snapshot, and a folder beside the cluster (`$MERIDIAN_LOCAL_PGDATA.sandboxes/<name>/`,
outside the repo) with the sandbox's env file (mode 0600), its uploaded files, logs and
pid files. Everything it saves stays in that database and that folder.

```bash
scripts/sandbox.sh golden                 # once, and whenever you want fresh live config
scripts/sandbox.sh new revenue-v2         # branch from aws-migration (--from <branch-or-sha>)
scripts/sandbox.sh start revenue-v2       # migrates its DB with ITS code, starts api + web
#   -> http://127.0.0.1:31xx  (the port is printed; api on 51xx)
scripts/sandbox.sh list                   # name, branch, database, ports, phi?, running?
scripts/sandbox.sh stop revenue-v2
scripts/sandbox.sh refresh revenue-v2     # throw its data away: a fresh copy of golden
scripts/sandbox.sh drop revenue-v2        # stop, drop the DB, remove worktree and folder
```

- **golden** = the bootstrap (migrate + the seed's test users) into a separate
  `meridian_golden` database, then `pull_live_data.py --config-only --target-db
  meridian_golden` (read-only on live), then marked a template. It needs the same variables
  as steps 1 and 6; `--env-file` can be given more than once (e.g. `.env` for
  `SUPABASE_DB_URL` plus a secrets file with the role passwords), first wins. It refuses if
  the passwords you give are not the ones the cluster's roles already have, because
  building a database re-sets them cluster-wide.
- **Local only, enforced.** The env file sets `APP_ENV=development`, `AUTH_BACKEND=disabled`,
  `EMAIL_BACKEND=disabled`, `STORAGE_BACKEND=local` (the sandbox's own folder),
  `MERIDIAN_QBO_POSTING=off` (every QuickBooks journal create is refused before it is sent),
  no QuickBooks app credentials, `MERIDIAN_API_V3=0` (no webhook drainer) and no
  queue/bus/S3/Supabase names. Every organization in the copy is in **Test mode**, and its
  QuickBooks connections and webhook subscriptions are deleted. `start` (and
  `scripts/serve_api.sh` whenever `MERIDIAN_SANDBOX` is set) refuses to run if any
  database, storage or service URL in the environment is not this machine. The api and web
  get only a few shell basics plus the env file, and the worktree gets a comment-only
  `.env` so the app never reads the main checkout's.
- **Migrations are per sandbox.** `start` runs `alembic upgrade head` from the sandbox's
  own code against its own database, so a branch that adds a revision changes only that
  sandbox. Build golden from the newest code (`aws-migration`); a sandbox branched from an
  older commit than golden's schema cannot migrate.
- **`drop` asks first** (`--yes` skips the question), refuses a worktree with uncommitted
  changes unless `--force`, and deletes the branch only when it is merged (into its base,
  `aws-migration` or `main`); otherwise the branch is kept.
- **Patient data: `--phi`.** `scripts/sandbox.sh golden --phi` and `new <name> --phi` do the
  same on the PHI cluster (`/Volumes/MeridianPHI/Meridian/local-pg`, port 55433) built by
  `pull_live_data.py --full`: golden is a `--full` pull, and the sandbox's database, env
  file, storage and logs all live on the PHI volume. Refused unless the volume is mounted
  and that cluster exists. Without `--phi` a sandbox holds configuration only, never
  patient data.

**With Docker instead** (`docker-compose.local.yml`: PostgreSQL 17 on a named volume, a
one-shot migrate + seed job, the api and web images). Written and syntax-checked, **not yet
run** — Docker Desktop was off when it was written:

```bash
docker compose -f docker-compose.local.yml --env-file /path/outside/repo/meridian-local.env up --build
```

That env file needs `MERIDIAN_LOCAL_PG_SUPERUSER_PASSWORD` besides the four passwords above.

### Against Supabase (production today, until cutover)

`.env` (gitignored) holds the Supabase, OAuth, Resend and QuickBooks secrets; `.env.example`
lists their names. Set `DATABASE_BACKEND=supabase STORAGE_BACKEND=supabase
AUTH_BACKEND=supabase`, then `scripts/serve_api.sh` and `npm run dev` as above. The Supabase
schema is history (`supabase_migrations/`); new schema changes are Alembic revisions under
`migrations/` (`docs/runbooks/migrations.md`).

The legacy CLI (`process_revenue.py`) still reads the mapping files, which hold real
provider, payer and employee names, so the repo ships redacted `*.example.*` copies:

```bash
cp config/mappings.example.xlsx            config/mappings.xlsx
cp config/provider_maps.example.json       config/provider_maps.json
cp config/employee_allocations.example.json config/employee_allocations.json
cp config/mx_employee_roster.example.json  config/mx_employee_roster.json
```

`config/provider_maps.json` falls back to the example if missing, so imports and
tests work on a fresh clone — but journal entries will be wrong until it is real.

The CLI's frozen SQLite database defaults to `data/revenue.db` (under `MERIDIAN_DATA_DIR`
when that is set; gitignored either way). Set `MERIDIAN_SQLITE_PATH` to keep it somewhere
else — an absolute path is used as given, a relative one resolves under `MERIDIAN_DATA_DIR`.
`--db` on `process_revenue.py` still overrides both.

Next proxies `/api/*` to the backend so auth cookies stay first-party — no CORS. Point it at
a non-local backend with `MERIDIAN_API_ORIGIN`.

Tests: as in step 5 of local development above.

### Environment variables (names only)

Values live in `.env` (gitignored), the shell, or Secrets Manager — never in this repo.
`.env.example` is not the complete list; this is (decision D6 of the local-first plan).

| Group | Names |
|---|---|
| Backend switches | `APP_ENV` (`FLASK_ENV` is the older name), `DATABASE_BACKEND`, `STORAGE_BACKEND`, `AUTH_BACKEND`, `EMAIL_BACKEND`, `MERIDIAN_API_V3`, `AUTH_ACCEPT_SUPABASE_TOKENS`; legacy alias `AUTH_MODE` |
| Local development | `LOCAL_DEV_ORG_ID`, `MERIDIAN_DATA_DIR`, `MERIDIAN_SQLITE_PATH` (legacy CLI only), `MERIDIAN_LOCAL_PGDATA`, `MERIDIAN_LOCAL_PGPORT`, `MERIDIAN_LOCAL_PGSOCKET`, `MERIDIAN_LOCAL_DB`, `MERIDIAN_LOCAL_MIGRATOR_PASSWORD`, `MERIDIAN_LOCAL_PG_SUPERUSER_PASSWORD` (compose only) |
| PostgreSQL (RDS or local) | `POSTGRES_URL` or `DATABASE_URL`, or `PGHOST` `PGPORT` `PGDATABASE` `PGUSER` `PGPASSWORD` `PGSSLMODE`; `PG_SSLROOTCERT`, `PG_POOL_MIN`, `PG_POOL_MAX`, `PG_POOL_TIMEOUT` |
| Migrations | `MERIDIAN_DATABASE_URL` (owner role), `MERIDIAN_APP_DB_PASSWORD`, `MERIDIAN_PHI_DB_PASSWORD` |
| PHI | `MERIDIAN_PHI_HMAC_KEY` |
| Supabase (until Phase 10) | `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `SUPABASE_ANON_KEY`, `SUPABASE_KEY`, `SUPABASE_DB_URL` |
| Cognito | `COGNITO_USER_POOL_ID`, `COGNITO_CLIENT_ID`, `COGNITO_CLIENT_SECRET`, `COGNITO_DOMAIN`, `COGNITO_REGION` |
| Storage (S3) | `MERIDIAN_S3_ARTIFACTS_BUCKET`, `MERIDIAN_S3_KMS_KEY_ARN`, `MERIDIAN_S3_PHI_BUCKET`, `MERIDIAN_S3_PHI_KMS_KEY_ARN`, `MERIDIAN_MAX_UPLOAD_BYTES`, `AWS_REGION` |
| Email | `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, `MERIDIAN_SES_FROM_EMAIL`, `MERIDIAN_SES_CONFIGURATION_SET`, `EMAIL_FROM_DISPLAY_NAME` |
| App origin (links, OAuth and QuickBooks callbacks) | `PUBLIC_APP_URL`, else `SITE_URL`, else `https://www.meridiansgrp.com` (ADR 0050) |
| Job queue (Phase 11, RDS only) | `JOB_TRANSPORT` (`inprocess` default, `sqs`), `WORKER_PROCESSES` (process ids on the queue; empty = today's thread), `PROCESS_SUBMISSIONS_PAUSED` (process ids answering 503), `MERIDIAN_JOBS_QUEUE_URL`, `MERIDIAN_JOBS_DLQ_URL` (the worker, and the api when `JOB_TRANSPORT=sqs`), `MERIDIAN_WORKER_ID`, `MERIDIAN_SCRATCH_DIR` |
| Webhooks (`/api/v3`) | `WEBHOOK_QUEUE_URL`, `WEBHOOK_DLQ_URL`, `WEBHOOK_EVENT_BUS`, `WEBHOOK_SECRETS_KMS_KEY_ID` (all four required outside development whenever `MERIDIAN_API_V3` is on — the api refuses to start without them; CDK sets them together with `MERIDIAN_API_V3` under `-c enableApiPlatform=true`; unset on a laptop = the local queue, drainer and sealed secret store), `WEBHOOK_BLOCKED_CIDRS`, `MERIDIAN_MTLS_ORIGIN_VERIFY` |
| QuickBooks | `QBO_CLIENT_ID`, `QBO_CLIENT_SECRET`, `QBO_REDIRECT_URI`, `QBO_CALLBACK_PATH`, `QBO_REALM_ID`, `QBO_ENVIRONMENT`, `QBO_SECRET_ID`, `QBO_CONFIG_SECRET_ID`, `QBO_TOKEN_KMS_KEY_ARN` (AWS), `MERIDIAN_DEV_QBO_TOKEN_KEY` (laptop only) |
| Web server | `FLASK_SECRET_KEY`, `MERIDIAN_HOST`, `MERIDIAN_PORT`, `MERIDIAN_RELOAD`, `FORWARDED_ALLOW_IPS`, `MERIDIAN_LOG_LEVEL`, `MERIDIAN_JSON_LOGS` (JSON + redacted logs: on by default with `DATABASE_BACKEND=postgres`, off on Supabase/Render unless `1`) |
| Web app (`web/`) | `MERIDIAN_API_ORIGIN`, `MERIDIAN_JINJA_AUTH`, `PUBLIC_APP_URL` + `PUBLIC_WWW_URL` (both set and different = split www from app, ADR 0050) |

### Deploying

`render.yaml` defines both services. Every secret is `sync: false`, so set the
real values in the Render dashboard — never in this repo. The frontend's
`MERIDIAN_API_ORIGIN` must point at the backend service's URL.

**On AWS (staging, from Phase 5a)** the same two services are container images:
`Dockerfile.api` (built from the repo root) and `web/Dockerfile` (built from
`web/`), both `linux/arm64`, deployed to ECS Fargate by
`infra/meridian/stacks/compute.py`. Production is still Render until Phase 9.

---

## QuickBooks output format

QB Online JE import columns:

```
*JournalNo | *JournalDate | *AccountName | *Debits | *Credits | Description | Name | Location | Class
```

- `*JournalDate` is **day-first `DD/MM/YYYY`** (QB, not NetSuite) — the period end date.
- `Name` = provider code; `Location` = QB clinic; `Class` = QB department path.

### Revenue rules
- One **credit** row per unique (Location × Class × Name × AccountName).
- The single `18099 Sales Clearing` line per JE is the **debit** — inverted from normal
  revenue accounting, but each JE balances.
- Posted revenue (41xxx) and unposted revenue (43006) get **separate JournalNos**.
- Rolled-up and unposted lines use the "Other" provider code for their service line.
- Hospital locations fold into their parent clinic. Buckner splits by service line:
  OB/GYN + MFM → `OBG Buckner`, Primary Care → `FAM Buckner`.

### Payroll rules (Mexico)
- Every active department emits the **full standard account set**, including zero amounts:
  71215, 71218, 72033, 72032, 72012, 72065 (PEO fees come *after* taxes).
- Single balancing credit to `21192 Payroll Clearing MX`, with blank Class and Location.

---

## Business rules worth knowing

- **Fiscal year** runs late-Dec to late-Dec. Periods are 4–5 weeks, not calendar months.
  The JE date is always the period **end** date.
- **15 locations** in **11 clinic groups**.
- **Revenue accounts**: 41001 Medicaid · 41002 Medicare · 41003 Private Insurance ·
  41004 Self Pay · 43006 Unposted · 18099 Clearing.
- **Department follows the billing provider, not the facility.** An MFM doctor seeing
  patients at Merit books to the MFM department. That is correct, not a bug.

Frontend design tokens and UI conventions live in `web/DESIGN.md`.
