"""reconcile_live_drift — make the replayed schema equal the live Supabase schema.

Revision ID: 0002_reconcile_live_drift
Revises: 0001_baseline_supabase
Create Date: 2026-09-15

WHY THIS EXISTS
---------------
`supabase_migrations/` is a *description* of the live database, not its cause.
Most of the core tables were created ad hoc (originally by porting a SQLite
schema) and the migration file was written afterwards from memory. Replaying
the 37 files therefore produces a schema that is close to production but not
production. This revision closes the gap, measured — not guessed — by
diffing revision 0001's output against
`migrations/baseline/supabase_public_schema_2026-09-15.sql`, a
`pg_dump --schema-only --no-owner --no-privileges --no-comments -n public` of
the live database taken on 2026-09-15. The normalised diff is committed beside
it as `migrations/baseline/drift_2026-09-15.diff`; regenerate either with
`scripts/dump_live_schema.py` / `scripts/diff_baseline_schema.py`.

After `0001 + 0002` the two schemas are equal except for three objects, which
are intentional and asserted by `tests/test_migrations.py`:

  * `public.alembic_version` — Alembic's own ledger; live has no such table.
  * `public.trial_migrations` — the aws-trial replay ledger. Not Meridian's
    schema; it is dropped at cutover (docs/migration-tracker.md). NOT recreated.
  * `public.qgenda_workspaces` — no migration file, no owner established, its
    rows are excluded from the migration (plan P-4), and its only three
    policies are granted `TO authenticated`, a Supabase role that does not
    exist on RDS. **Decision: not recreated.** It stays in the retained
    Supabase archive, so nothing is lost if it turns out to be Meridian's; if
    it is, a later revision creates it with real policies. Recorded in
    ADR 0019.

WHAT THE DIFF ACTUALLY SHOWED (and where the earlier inventory was wrong)
-------------------------------------------------------------------------
1. **`double precision` live, `numeric(15,2)` in the files** — 21 money and
   quantity columns. This is the single largest drift and nobody had recorded
   it. It also explains why the port needs the `DEC2FLOAT` adapter
   (plan §2.2): live really is float.
2. **`timestamp without time zone DEFAULT CURRENT_TIMESTAMP` live,
   `timestamptz DEFAULT now()` in the files** — 22 columns. Also unrecorded.
3. **`auth.users` foreign keys: 3 live, 14 declared.** The inventory said
   "~12 do not exist live"; the true number is 11, and the three that DO exist
   are `org_members.user_id`, `org_members.invited_by` and
   `config_mx_employees.updated_by`. `superadmins.user_id` is a plain PK live,
   not an FK — so the inventory's worry about its primary key is moot.
4. **`ON DELETE CASCADE` is in the files and nowhere in live** — 20 foreign
   keys. A `DELETE FROM organizations` behaves completely differently on the
   two schemas. Reproducing live is the point of this revision; whether live's
   shape is *desirable* is a separate question for a later revision.
5. **`updated_by` / `changed_by` are TEXT live, UUID in the files** — five
   columns, not six: `config_mx_employees.updated_by` is genuinely `uuid` live
   (and keeps its FK). The `023`-over-`002` hybrid is real: the replayed
   `config_providers/locations/payers` carry `002`'s UUID column and `023`'s
   extra `location_code` / `facility_raw` columns, exactly as predicted.
6. **`027_invite_codes_email.sql` IS applied live.** `invite_codes.email`
   exists in the dump. The plan and both READMEs say it was never applied;
   that record is wrong and is corrected in
   `docs/compliance/inventory-data-layer.md` §7 and
   `supabase_migrations/README.md`.
7. **`payroll_column_account_map` matches** — `007` creates it and live agrees.
   No reconciliation needed.
8. **`fiscal_calendar` is live** (table, sequence, PK, FK, three indexes, RLS
   and an `org_isolation` policy), settling the contradiction in
   `015_document_unmigrated_tables.sql`'s comment. Created here.
9. **`superadmins` has RLS enabled and a `superadmins_self_only` policy live**;
   the replay has neither. Added here.
10. **`employee_clinic_allocations`'s unique key is NOT org-scoped live**
    (`UNIQUE (employee_normalized, location_code)`) while the file declares
    `(org_id, employee_normalized, location_code)`. Reproduced here because
    this revision's job is to equal live — and flagged: it means two
    organizations cannot hold the same employee/location pair. That is a
    tenant-isolation defect to fix in a later revision, not silently here.
11. Per-table column drift: `clients` (+email, +phone, org_id NOT NULL,
    -updated_at), `config_employees` (-job_category, `active` integer not
    boolean), `import_batches` (`user_id` not `created_by`, `overview_data`
    text not jsonb), `invite_codes` (four NOT NULLs, plus a `role_id` FK to
    `roles` with ON DELETE SET NULL that no file declares), `invoices`
    (-updated_at, four NOT NULLs, `total numeric(10,2)` with no default),
    `org_modules` (PK `(org_id, module)`, no `id`, `enabled` defaults FALSE,
    +updated_at, +updated_by, -created_at), `unmapped_items` (`resolved`
    integer not boolean), `uploads` (org_id nullable, `created_by` absent).

DOWNGRADE
---------
Not supported, for the same reason as 0001: this is part of the baseline, not
an incremental change. Rebuild from empty.
"""

from __future__ import annotations

from alembic import op

revision = "0002_reconcile_live_drift"
down_revision = "0001_baseline_supabase"
branch_labels = None
depends_on = None


# --- 1. what 0001 skipped from 014, now that 015 has created the tables ------
# 014's statements on public.clients / public.invoices were skipped by 0001
# because on a replay from empty they run before 015 creates those tables.
# Only the RLS enable is replayed here. 014's `org_isolation` policies are NOT:
# 015 sorts after 014 and re-creates both policies in its own `org_id IN
# (SELECT ... FROM org_members ...)` form, which is what the live dump shows.
# Re-applying 014's `user_org_id()` form here would leave the replay one
# revision AHEAD of live. 014's `ADD COLUMN IF NOT EXISTS org_id` is likewise
# redundant: 015's CREATE TABLE declares the column.
REAPPLY_014 = """
ALTER TABLE public.clients  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
"""

# --- 2. tables that exist live with no migration file ------------------------
FISCAL_CALENDAR = """
CREATE SEQUENCE public.fiscal_calendar_id_seq
    AS integer START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;

CREATE TABLE public.fiscal_calendar (
    id integer NOT NULL,
    org_id uuid,
    fiscal_year text NOT NULL,
    period integer NOT NULL,
    period_key text NOT NULL,
    date date NOT NULL
);

ALTER TABLE ONLY public.fiscal_calendar
    ALTER COLUMN id SET DEFAULT nextval('public.fiscal_calendar_id_seq'::regclass);
ALTER SEQUENCE public.fiscal_calendar_id_seq OWNED BY public.fiscal_calendar.id;

ALTER TABLE ONLY public.fiscal_calendar
    ADD CONSTRAINT fiscal_calendar_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.fiscal_calendar
    ADD CONSTRAINT fiscal_calendar_org_id_fkey
    FOREIGN KEY (org_id) REFERENCES public.organizations(id);

CREATE INDEX idx_fiscal_calendar_date   ON public.fiscal_calendar USING btree (date);
CREATE INDEX idx_fiscal_calendar_org    ON public.fiscal_calendar USING btree (org_id);
CREATE INDEX idx_fiscal_calendar_period ON public.fiscal_calendar USING btree (org_id, fiscal_year, period);

ALTER TABLE public.fiscal_calendar ENABLE ROW LEVEL SECURITY;
CREATE POLICY org_isolation ON public.fiscal_calendar
    USING ((org_id = public.user_org_id()));
"""

# --- 3. row-level security live has and the replay does not ------------------
SUPERADMINS_RLS = """
ALTER TABLE public.superadmins ENABLE ROW LEVEL SECURITY;
CREATE POLICY superadmins_self_only ON public.superadmins
    USING ((user_id = auth.uid()));
"""

# --- 4. `auth.users` foreign keys the files declare and live does not have ----
# 11 of the 14. The three live keeps (org_members.user_id, org_members.invited_by,
# config_mx_employees.updated_by) stay until revision 0003 removes them with the
# shim.
# clients / invoices have NO foreign key on org_id live -- 015 declares one with
# ON DELETE CASCADE and the live tables, created ad hoc, never had it.
DROP_ORPHAN_ORG_FKS = """
ALTER TABLE public.clients  DROP CONSTRAINT IF EXISTS clients_org_id_fkey;
ALTER TABLE public.invoices DROP CONSTRAINT IF EXISTS invoices_org_id_fkey;
"""

DROP_PHANTOM_AUTH_FKS = """
ALTER TABLE public.config_employees  DROP CONSTRAINT IF EXISTS config_employees_updated_by_fkey;
ALTER TABLE public.config_history    DROP CONSTRAINT IF EXISTS config_history_changed_by_fkey;
ALTER TABLE public.config_locations  DROP CONSTRAINT IF EXISTS config_locations_updated_by_fkey;
ALTER TABLE public.config_payers     DROP CONSTRAINT IF EXISTS config_payers_updated_by_fkey;
ALTER TABLE public.config_providers  DROP CONSTRAINT IF EXISTS config_providers_updated_by_fkey;
ALTER TABLE public.import_batches    DROP CONSTRAINT IF EXISTS import_batches_created_by_fkey;
ALTER TABLE public.invite_codes      DROP CONSTRAINT IF EXISTS invite_codes_created_by_fkey;
ALTER TABLE public.invite_codes      DROP CONSTRAINT IF EXISTS invite_codes_used_by_fkey;
ALTER TABLE public.invoices          DROP CONSTRAINT IF EXISTS invoices_created_by_fkey;
ALTER TABLE public.superadmins       DROP CONSTRAINT IF EXISTS superadmins_user_id_fkey;
ALTER TABLE public.uploads           DROP CONSTRAINT IF EXISTS uploads_created_by_fkey;
"""

# --- 5. ON DELETE CASCADE: in every file, in no live constraint --------------
# Each is dropped and re-added with live's referential action (NO ACTION).
_CASCADE_FKS = [
    ("config_employees", "config_employees_org_id_fkey", "org_id", "public.organizations(id)"),
    ("config_history", "config_history_org_id_fkey", "org_id", "public.organizations(id)"),
    ("config_locations", "config_locations_org_id_fkey", "org_id", "public.organizations(id)"),
    ("config_payers", "config_payers_org_id_fkey", "org_id", "public.organizations(id)"),
    ("config_providers", "config_providers_org_id_fkey", "org_id", "public.organizations(id)"),
    (
        "employee_clinic_allocations",
        "employee_clinic_allocations_org_id_fkey",
        "org_id",
        "public.organizations(id)",
    ),
    ("import_batches", "import_batches_org_id_fkey", "org_id", "public.organizations(id)"),
    ("journal_entries", "journal_entries_org_id_fkey", "org_id", "public.organizations(id)"),
    ("journal_entries", "journal_entries_batch_id_fkey", "batch_id", "public.import_batches(id)"),
    ("payroll_employees", "payroll_employees_org_id_fkey", "org_id", "public.organizations(id)"),
    (
        "payroll_employees",
        "payroll_employees_batch_id_fkey",
        "batch_id",
        "public.import_batches(id)",
    ),
    ("processed_entries", "processed_entries_org_id_fkey", "org_id", "public.organizations(id)"),
    ("processed_entries", "processed_entries_run_id_fkey", "run_id", "public.processing_runs(id)"),
    ("processing_runs", "processing_runs_org_id_fkey", "org_id", "public.organizations(id)"),
    ("processing_runs", "processing_runs_upload_id_fkey", "upload_id", "public.uploads(id)"),
    (
        "source_transactions",
        "source_transactions_org_id_fkey",
        "org_id",
        "public.organizations(id)",
    ),
    (
        "source_transactions",
        "source_transactions_upload_id_fkey",
        "upload_id",
        "public.uploads(id)",
    ),
    ("transactions", "transactions_org_id_fkey", "org_id", "public.organizations(id)"),
    ("transactions", "transactions_batch_id_fkey", "batch_id", "public.import_batches(id)"),
    ("unmapped_items", "unmapped_items_org_id_fkey", "org_id", "public.organizations(id)"),
    ("unmapped_items", "unmapped_items_batch_id_fkey", "batch_id", "public.import_batches(id)"),
    ("uploads", "uploads_org_id_fkey", "org_id", "public.organizations(id)"),
]

# --- 6. numeric(15,2) in the files, double precision live --------------------
#: (table, column, live default or None)
_FLOAT_COLUMNS = [
    ("import_batches", "total_amount", "0.0"),
    ("journal_entries", "debit", "0.0"),
    ("journal_entries", "credit", "0.0"),
    ("payroll_employees", "wages_71215", "0"),
    ("payroll_employees", "pto_71218", "0"),
    ("payroll_employees", "xmas_72033", "0"),
    ("payroll_employees", "food_72032", "0"),
    ("payroll_employees", "peo1_72065", "0"),
    ("payroll_employees", "taxes_72012", "0"),
    ("payroll_employees", "peo2_72065", "0"),
    ("payroll_employees", "indem", "0"),
    ("payroll_employees", "total_mxn", "0"),
    ("payroll_employees", "total_usd", "0"),
    ("processed_entries", "debit", "0.0"),
    ("processed_entries", "credit", "0.0"),
    ("processing_runs", "total_debits", "0.0"),
    ("processing_runs", "total_credits", "0.0"),
    ("source_transactions", "amount", "0.0"),
    ("transactions", "amount", None),
    ("unmapped_items", "total_amount", "0.0"),
    ("uploads", "total_amount", "0.0"),
]

# --- 7. timestamptz DEFAULT now() in the files, timestamp DEFAULT CURRENT_TIMESTAMP live
#: (table, column, has a default)
_NAIVE_TIMESTAMP_COLUMNS = [
    ("config_employees", "created_at", True),
    ("config_employees", "updated_at", True),
    ("config_history", "changed_at", True),
    ("config_locations", "created_at", True),
    ("config_locations", "updated_at", True),
    ("config_payers", "created_at", True),
    ("config_payers", "updated_at", True),
    ("config_providers", "created_at", True),
    ("config_providers", "updated_at", True),
    ("employee_clinic_allocations", "created_at", True),
    ("employee_clinic_allocations", "updated_at", True),
    ("import_batches", "created_at", True),
    ("import_batches", "processed_at", False),
    ("journal_entries", "created_at", True),
    ("payroll_employees", "created_at", True),
    ("processed_entries", "created_at", True),
    ("processing_runs", "started_at", True),
    ("processing_runs", "completed_at", False),
    ("source_transactions", "created_at", True),
    ("transactions", "created_at", True),
    ("unmapped_items", "created_at", True),
    ("uploads", "created_at", True),
    ("uploads", "updated_at", True),
]

# --- 8. updated_by / changed_by: UUID in the files, TEXT live ----------------
_TEXT_ACTOR_COLUMNS = [
    ("config_employees", "updated_by"),
    ("config_history", "changed_by"),
    ("config_locations", "updated_by"),
    ("config_payers", "updated_by"),
    ("config_providers", "updated_by"),
]

# --- 9. per-table column and constraint drift -------------------------------
PER_TABLE_DRIFT = """
-- clients: live carries contact details the file never declared, requires
-- org_id, and has no updated_at.
ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE public.clients DROP COLUMN IF EXISTS updated_at;
ALTER TABLE public.clients ALTER COLUMN org_id SET NOT NULL;
CREATE INDEX IF NOT EXISTS idx_clients_org_id ON public.clients USING btree (org_id);

-- invoices: four NOT NULLs, a narrower total, no default on it, no updated_at.
ALTER TABLE public.invoices DROP COLUMN IF EXISTS updated_at;
ALTER TABLE public.invoices ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.invoices ALTER COLUMN client_name SET NOT NULL;
ALTER TABLE public.invoices ALTER COLUMN invoice_date SET NOT NULL;
ALTER TABLE public.invoices ALTER COLUMN line_items SET NOT NULL;
ALTER TABLE public.invoices ALTER COLUMN line_items DROP DEFAULT;
ALTER TABLE public.invoices ALTER COLUMN total TYPE numeric(10,2);
ALTER TABLE public.invoices ALTER COLUMN total DROP DEFAULT;
CREATE INDEX IF NOT EXISTS idx_invoices_client_id  ON public.invoices USING btree (client_id);
CREATE INDEX IF NOT EXISTS idx_invoices_created_at ON public.invoices USING btree (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_invoices_org_id     ON public.invoices USING btree (org_id);

-- config_employees: no job_category live, and `active` is an integer flag.
ALTER TABLE public.config_employees DROP COLUMN IF EXISTS job_category;
ALTER TABLE public.config_employees ALTER COLUMN active DROP DEFAULT;
ALTER TABLE public.config_employees
    ALTER COLUMN active TYPE integer USING (CASE WHEN active THEN 1 ELSE 0 END);
ALTER TABLE public.config_employees ALTER COLUMN active SET DEFAULT 1;

-- import_batches: the actor column is `user_id`, and the overview blob is text.
ALTER TABLE public.import_batches DROP COLUMN IF EXISTS created_by;
ALTER TABLE public.import_batches ADD COLUMN IF NOT EXISTS user_id uuid;
ALTER TABLE public.import_batches ALTER COLUMN overview_data TYPE text;

-- invite_codes: four NOT NULLs the file leaves nullable, and a role_id foreign
-- key to public.roles that no migration file declares at all.
ALTER TABLE public.invite_codes ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE public.invite_codes ALTER COLUMN role SET NOT NULL;
ALTER TABLE public.invite_codes ALTER COLUMN created_by SET NOT NULL;
ALTER TABLE public.invite_codes ALTER COLUMN expires_at SET NOT NULL;
ALTER TABLE public.invite_codes
    ADD CONSTRAINT invite_codes_role_id_fkey FOREIGN KEY (role_id)
    REFERENCES public.roles(id) ON DELETE SET NULL;

-- org_modules: live is a plain (org_id, module) association table. The file
-- gives it a surrogate uuid id, a unique key and created_at instead.
ALTER TABLE public.org_modules DROP CONSTRAINT IF EXISTS org_modules_pkey;
ALTER TABLE public.org_modules DROP CONSTRAINT IF EXISTS org_modules_org_id_module_key;
ALTER TABLE public.org_modules DROP COLUMN IF EXISTS id;
ALTER TABLE public.org_modules DROP COLUMN IF EXISTS created_at;
ALTER TABLE public.org_modules ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone DEFAULT now();
ALTER TABLE public.org_modules ADD COLUMN IF NOT EXISTS updated_by text;
ALTER TABLE public.org_modules ALTER COLUMN enabled SET DEFAULT false;
ALTER TABLE public.org_modules ADD CONSTRAINT org_modules_pkey PRIMARY KEY (org_id, module);
-- Live has an org_isolation policy on org_modules; no migration file creates one.
DROP POLICY IF EXISTS org_isolation ON public.org_modules;
CREATE POLICY org_isolation ON public.org_modules USING ((org_id = public.user_org_id()));

-- unmapped_items: `resolved` is an integer flag live.
ALTER TABLE public.unmapped_items ALTER COLUMN resolved DROP DEFAULT;
ALTER TABLE public.unmapped_items
    ALTER COLUMN resolved TYPE integer USING (CASE WHEN resolved THEN 1 ELSE 0 END);
ALTER TABLE public.unmapped_items ALTER COLUMN resolved SET DEFAULT 0;

-- uploads: org_id is nullable live (rows predate multi-tenancy) and there is
-- no created_by column.
ALTER TABLE public.uploads ALTER COLUMN org_id DROP NOT NULL;
ALTER TABLE public.uploads DROP COLUMN IF EXISTS created_by;

-- employee_clinic_allocations: live's unique key is NOT org-scoped. Reproduced
-- because this revision's job is to equal live. It is a tenant-isolation
-- defect -- two organizations cannot hold the same (employee, location) pair --
-- and is tracked for a later revision, not fixed silently here.
ALTER TABLE public.employee_clinic_allocations
    DROP CONSTRAINT IF EXISTS employee_clinic_allocations_org_id_employee_normalized_loca_key;
ALTER TABLE public.employee_clinic_allocations
    ADD CONSTRAINT employee_clinic_allocations_employee_normalized_location_co_key
    UNIQUE (employee_normalized, location_code);
CREATE INDEX IF NOT EXISTS idx_employee_clinic_allocations_org
    ON public.employee_clinic_allocations USING btree (org_id);

-- qb_usa_employee: main's Supabase migrations 037 and 039 (after this history
-- closed) added these live. Measured: supabase_public_schema_2026-10-07.sql
-- differs from the 2026-09-15 dump by exactly these five columns.
ALTER TABLE public.qb_usa_employee
    ADD COLUMN IF NOT EXISTS qb_name text DEFAULT ''::text NOT NULL,
    ADD COLUMN IF NOT EXISTS adp_dept_code text,
    ADD COLUMN IF NOT EXISTS adp_dept_desc text,
    ADD COLUMN IF NOT EXISTS adp_cost_code text,
    ADD COLUMN IF NOT EXISTS adp_cost_desc text;
"""


def upgrade() -> None:
    op.execute(REAPPLY_014)
    op.execute(FISCAL_CALENDAR)
    op.execute(SUPERADMINS_RLS)
    op.execute(DROP_ORPHAN_ORG_FKS)
    op.execute(DROP_PHANTOM_AUTH_FKS)

    for table, name, column, ref in _CASCADE_FKS:
        op.execute(f"ALTER TABLE public.{table} DROP CONSTRAINT IF EXISTS {name}")
        op.execute(
            f"ALTER TABLE ONLY public.{table} ADD CONSTRAINT {name} "
            f"FOREIGN KEY ({column}) REFERENCES {ref}"
        )

    for table, column, default in _FLOAT_COLUMNS:
        op.execute(f"ALTER TABLE public.{table} ALTER COLUMN {column} DROP DEFAULT")
        op.execute(f"ALTER TABLE public.{table} ALTER COLUMN {column} TYPE double precision")
        if default is not None:
            op.execute(f"ALTER TABLE public.{table} ALTER COLUMN {column} SET DEFAULT {default}")

    for table, column, has_default in _NAIVE_TIMESTAMP_COLUMNS:
        op.execute(f"ALTER TABLE public.{table} ALTER COLUMN {column} DROP DEFAULT")
        op.execute(
            f"ALTER TABLE public.{table} ALTER COLUMN {column} TYPE timestamp without time zone"
        )
        if has_default:
            op.execute(
                f"ALTER TABLE public.{table} ALTER COLUMN {column} SET DEFAULT CURRENT_TIMESTAMP"
            )

    for table, column in _TEXT_ACTOR_COLUMNS:
        op.execute(f"ALTER TABLE public.{table} ALTER COLUMN {column} TYPE text")

    op.execute(PER_TABLE_DRIFT)


def downgrade() -> None:
    raise NotImplementedError(
        "0002 completes the baseline; it has no downgrade. Rebuild from empty."
    )
