"""bi_exec_notes - the Executive Report's "Notes to ..." boxes, shared per organization and period.

Revision ID: 0051_bi_exec_notes
Revises: 0050_mart_reader_jit_off
Create Date: 2026-10-19

WHY
---
Each statement slide of the Executive Report has a typed Notes box (`notes-pl`, `notes-cost`...).
Until now that text lived only in the browser (localStorage). Project rule: everything new that
stores data lives in AWS RDS, per organization, with RLS.

WHAT IT ADDS
------------
`public.bi_exec_notes`: one row per (organization, fiscal year, period or quarter edition, which
period, note id) holding the text. Last save wins (a note is one free-text box, so there is no
compare-and-set). The app role may SELECT, INSERT and UPDATE; it can NOT delete (a note is
cleared by saving empty text). Typed report text only: no PHI, no patient identifiers.

RLS: ENABLE + FORCE, policy `meridian_org_isolation` (same rule as 0049).
Plain Postgres 17 only.

NUMBERING
---------
Branch `feat/daily-report-speed` also adds a revision numbered 0050 (`0050_mart_reader_jit_off`).
This one is 0051; it chained to 0049 on its own branch and was pointed at
`0050_mart_reader_jit_off` when the two branches met (2026-10-19).

DOWNGRADE (read this first)
---------------------------
A downgrade DROPS the table and so DESTROYS every saved note. Back up first.
"""

from __future__ import annotations

from alembic import op

revision = "0051_bi_exec_notes"
down_revision = "0050_mart_reader_jit_off"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
POLICY = "meridian_org_isolation"
NOTES = "public.bi_exec_notes"

COMMENT = "typed report text only; no PHI, no patient identifiers"
_RULE = "(org_id = app.current_org_id())"

UPGRADE_SQL: list[str] = [
    f"""
CREATE TABLE {NOTES} (
    id          bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id      uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    fiscal_year int         NOT NULL CHECK (fiscal_year BETWEEN 2000 AND 2100),
    edition     text        NOT NULL CHECK (edition IN ('period', 'quarter')),
    which       int         NOT NULL CHECK (which BETWEEN 1 AND 12),
    note_id     text        NOT NULL CHECK (note_id ~ '^notes-[a-z0-9-]{{1,56}}$'),
    body        text        NOT NULL DEFAULT '' CHECK (char_length(body) <= 20000),
    created_by  uuid        NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_by  uuid        NOT NULL,
    updated_at  timestamptz NOT NULL DEFAULT now(),
    CHECK (edition <> 'quarter' OR which <= 4),
    UNIQUE (org_id, fiscal_year, edition, which, note_id)
)
""",
    f"COMMENT ON TABLE {NOTES} IS '{COMMENT}'",
    f"ALTER TABLE {NOTES} ENABLE ROW LEVEL SECURITY",
    f"ALTER TABLE {NOTES} FORCE ROW LEVEL SECURITY",
    f"CREATE POLICY {POLICY} ON {NOTES} USING {_RULE} WITH CHECK {_RULE}",
    # Revision 0003 set DEFAULT PRIVILEGES (full DML for the app role): take it away, grant exactly what is needed.
    f"REVOKE ALL ON {NOTES} FROM {PHI_ROLE}",
    f"REVOKE ALL ON {NOTES} FROM {APP_ROLE}",
    f"GRANT SELECT, INSERT, UPDATE ON {NOTES} TO {APP_ROLE}",
]

DOWNGRADE_SQL: list[str] = [f"DROP TABLE IF EXISTS {NOTES}"]


def upgrade() -> None:
    for statement in UPGRADE_SQL:
        op.execute(statement)


def downgrade() -> None:
    for statement in DOWNGRADE_SQL:
        op.execute(statement)
