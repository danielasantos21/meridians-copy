"""webhook_delivery_history — when a delivery was created and last tried.

Revision ID: 0014_webhook_delivery_history
Revises: 0013_api_platform
Create Date: 2026-09-24

Phase 12 task T11 (`docs/reports/phase-12-plan.md` §3.3, §3.7). The delivery
log (`GET /api/v3/webhooks/deliveries`) is a keyset list like every other v3
list, and §3.3 backs every list with an `(org_id, …, created_at DESC, id DESC)`
index. Revision 0013's `webhook_deliveries` has no `created_at`, so there is
nothing to order by but a random UUID. Two additive columns and one index:

* `created_at`      — when fan-out (or a test ping) created the row.
* `last_attempt_at` — when the sender last claimed it, shown in the log.

Additive only: no existing row changes meaning, `now()` fills `created_at` for
rows 0013 already holds (there are none outside a test database).

DOWNGRADE drops the index and both columns.
"""

from __future__ import annotations

from alembic import op

revision = "0014_webhook_delivery_history"
down_revision = "0013_api_platform"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        ALTER TABLE public.webhook_deliveries
            ADD COLUMN created_at      timestamptz NOT NULL DEFAULT now(),
            ADD COLUMN last_attempt_at timestamptz;
        CREATE INDEX idx_webhook_deliveries_history
            ON public.webhook_deliveries (org_id, created_at DESC, id DESC);
        """
    )


def downgrade() -> None:
    op.execute(
        """
        DROP INDEX IF EXISTS public.idx_webhook_deliveries_history;
        ALTER TABLE public.webhook_deliveries
            DROP COLUMN IF EXISTS last_attempt_at,
            DROP COLUMN IF EXISTS created_at;
        """
    )
