"""bi_dashboards — dashboards, tabs, dashboard cards and revisions for BI.

Revision ID: 0042_bi_dashboards
Revises: 0041_bi_discover
Create Date: 2026-10-13

WHY
---
BI Stage 5A lets a person lay saved questions out on a page (a "dashboard"),
group them in tabs, and add filters at the top that change the connected
questions. A dashboard is a fourth kind of saved item beside questions and
folders: it lives in a folder, can be trashed, bookmarked, pinned and searched.

WHAT IT ADDS
------------
1. `public.bi_dashboards` — the page itself: name, folder, its filter
   definitions (`parameters`), and the same trash / pin / revision columns that
   `bi_cards` has. Hidden when its folder is someone's private "My collection".
2. `public.bi_dashboard_tabs` — named tabs of a dashboard (in order).
3. `public.bi_dashcards` — one box on the grid: a saved question, or a text,
   heading or link box. Position and size are on a 24-column grid. Deleting a
   saved question for good leaves the box in place with `card_id` NULL (shown
   as a "removed question"); deleting a tab deletes the boxes on it.
4. `public.bi_dashboard_revisions` — a snapshot of the whole dashboard each time
   it changes (the application keeps the newest 50).
5. `bi_bookmarks` / `bi_views` may now point at a 'dashboard' (their
   `item_type` CHECK is widened from card/collection).
6. A small partial index for "what is pinned in this folder" on dashboards.

Definitions only: ids, names, positions and filter definitions. No query results,
no PHI.

RLS: ENABLE + FORCE on all four, policy `meridian_org_isolation`. Child tables
are hidden through an EXISTS on their (already filtered) dashboard.
Plain Postgres 17 only (identity columns, jsonb, CHECKs, a column list on
ON DELETE SET NULL which Postgres has had since 15).

DOWNGRADE (read this before running it)
---------------------------------------
A downgrade DESTROYS every dashboard, tab, dashboard box, revision and
dashboard bookmark/view. Back up first. To delete the dashboard rows out of
`bi_bookmarks` and `bi_views` (other people's private bookmarks are invisible
to a normal session) it briefly switches FORCE ROW LEVEL SECURITY off on those
two tables, deletes the rows whose item_type is 'dashboard', and switches
FORCE back on. It must be run by the table owner. After that it narrows the two
CHECKs back to card/collection and drops the four tables.
"""

from __future__ import annotations

from alembic import op

revision = "0042_bi_dashboards"
down_revision = "0041_bi_discover"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
POLICY = "meridian_org_isolation"
DASHBOARDS = "public.bi_dashboards"
TABS = "public.bi_dashboard_tabs"
DASHCARDS = "public.bi_dashcards"
REVISIONS = "public.bi_dashboard_revisions"
BOOKMARKS = "public.bi_bookmarks"
VIEWS = "public.bi_views"

# Same rule as bi_cards: hidden when the folder is someone else's private one.
_DASHBOARD_RULE = (
    "(org_id = app.current_org_id() AND (collection_id IS NULL OR EXISTS ("
    "SELECT 1 FROM public.bi_collections c "
    "WHERE c.org_id = bi_dashboards.org_id AND c.id = bi_dashboards.collection_id)))"
)


def _child_rule(table: str) -> str:
    return (
        "(org_id = app.current_org_id() AND EXISTS ("  # noqa: S608 (identifiers and constants only; values are bound parameters)
        "SELECT 1 FROM public.bi_dashboards d "
        f"WHERE d.org_id = {table}.org_id AND d.id = {table}.dashboard_id))"
    )


def _rls(table: str, rule: str) -> list[str]:
    return [
        f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY",
        f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY",
        f"CREATE POLICY {POLICY} ON {table} USING {rule} WITH CHECK {rule}",
        f"REVOKE ALL ON {table} FROM {PHI_ROLE}",
        f"GRANT SELECT, INSERT, UPDATE, DELETE ON {table} TO {APP_ROLE}",
    ]


COMMENT = "layout, ids and filter definitions only; no data, no results, no PHI"

CREATE_DASHBOARDS = f"""
CREATE TABLE {DASHBOARDS} (
    id                  bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id              uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    collection_id       bigint,
    name                text        NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 200),
    description         text        CHECK (char_length(description) <= 2000),
    parameters          jsonb       NOT NULL DEFAULT '[]'::jsonb
        CHECK (jsonb_typeof(parameters) = 'array'
               AND jsonb_array_length(parameters) <= 20
               AND octet_length(parameters::text) <= 32768),
    auto_apply_filters  boolean     NOT NULL DEFAULT true,
    width               text        NOT NULL DEFAULT 'fixed' CHECK (width IN ('fixed', 'full')),
    revision_no         int         NOT NULL DEFAULT 1,
    pinned_position     int,
    archived_at         timestamptz,
    archived_by         uuid,
    archived_with       bigint,
    created_by          uuid        NOT NULL,
    updated_by          uuid        NOT NULL,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id),
    FOREIGN KEY (org_id, collection_id) REFERENCES public.bi_collections (org_id, id)
)
"""

CREATE_TABS = f"""
CREATE TABLE {TABS} (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id       uuid   NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    dashboard_id bigint NOT NULL,
    name         text   NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 100),
    position     int    NOT NULL,
    UNIQUE (org_id, id),
    UNIQUE (org_id, dashboard_id, id),
    FOREIGN KEY (org_id, dashboard_id) REFERENCES {DASHBOARDS} (org_id, id) ON DELETE CASCADE
)
"""

CREATE_DASHCARDS = f"""
CREATE TABLE {DASHCARDS} (
    id                     bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id                 uuid   NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    dashboard_id           bigint NOT NULL,
    tab_id                 bigint,
    card_id                bigint,
    kind                   text   NOT NULL CHECK (kind IN ('card', 'text', 'heading', 'link')),
    row                    int    NOT NULL CHECK (row BETWEEN 0 AND 10000),
    col                    int    NOT NULL CHECK (col BETWEEN 0 AND 23),
    size_x                 int    NOT NULL CHECK (size_x BETWEEN 1 AND 24),
    size_y                 int    NOT NULL CHECK (size_y BETWEEN 1 AND 60),
    parameter_mappings     jsonb  NOT NULL DEFAULT '[]'::jsonb
        CHECK (jsonb_typeof(parameter_mappings) = 'array'
               AND octet_length(parameter_mappings::text) <= 8192),
    visualization_settings jsonb  NOT NULL DEFAULT '{{}}'::jsonb
        CHECK (jsonb_typeof(visualization_settings) = 'object'
               AND octet_length(visualization_settings::text) <= 16384),
    UNIQUE (org_id, id),
    CHECK (col + size_x <= 24),
    CHECK (kind = 'card' OR card_id IS NULL),
    FOREIGN KEY (org_id, dashboard_id) REFERENCES {DASHBOARDS} (org_id, id) ON DELETE CASCADE,
    -- the tab must belong to the SAME dashboard (a NULL tab_id is not checked)
    FOREIGN KEY (org_id, dashboard_id, tab_id) REFERENCES {TABS} (org_id, dashboard_id, id)
        ON DELETE CASCADE,
    FOREIGN KEY (org_id, card_id) REFERENCES public.bi_cards (org_id, id)
        ON DELETE SET NULL (card_id)
)
"""

CREATE_REVISIONS = f"""
CREATE TABLE {REVISIONS} (
    id           bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id       uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    dashboard_id bigint      NOT NULL,
    revision_no  int         NOT NULL,
    snapshot     jsonb       NOT NULL CHECK (octet_length(snapshot::text) <= 262144),
    message      text        NOT NULL CHECK (message IN
        ('created', 'edited_layout', 'edited_filters', 'edited_cards', 'renamed',
         'moved', 'reverted', 'trashed', 'restored')),
    is_creation  boolean     NOT NULL DEFAULT false,
    is_reversion boolean     NOT NULL DEFAULT false,
    reverted_to  int,
    changed_by   uuid        NOT NULL,
    created_at   timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, dashboard_id, revision_no),
    FOREIGN KEY (org_id, dashboard_id) REFERENCES {DASHBOARDS} (org_id, id) ON DELETE CASCADE
)
"""

# The 0041 CHECKs were written inline, so their names were generated. Look the
# real name up instead of guessing, then add a named replacement.
_DROP_ITEM_TYPE_CHECK = """
DO $do$
DECLARE r record;
BEGIN
  FOR r IN SELECT conname FROM pg_constraint
           WHERE conrelid = '%s'::regclass AND contype = 'c'
             AND pg_get_constraintdef(oid) LIKE '%%item_type%%'
  LOOP
    EXECUTE 'ALTER TABLE %s DROP CONSTRAINT ' || quote_ident(r.conname);
  END LOOP;
END
$do$
"""


def _widen(table: str, short: str) -> list[str]:
    return [
        _DROP_ITEM_TYPE_CHECK % (table, table),
        f"ALTER TABLE {table} ADD CONSTRAINT {short}_item_type_check "
        "CHECK (item_type IN ('card', 'collection', 'dashboard'))",
    ]


UPGRADE_SQL: list[str] = [
    CREATE_DASHBOARDS,
    f"""CREATE INDEX bi_dashboards_pinned ON {DASHBOARDS}
        (org_id, collection_id) WHERE pinned_position IS NOT NULL""",
    f"""CREATE INDEX bi_dashboards_collection ON {DASHBOARDS}
        (org_id, collection_id) WHERE archived_at IS NULL""",
    f"COMMENT ON TABLE {DASHBOARDS} IS '{COMMENT}'",
    *_rls(DASHBOARDS, _DASHBOARD_RULE),
    CREATE_TABS,
    f"CREATE INDEX bi_dashboard_tabs_dashboard ON {TABS} (org_id, dashboard_id, position)",
    f"COMMENT ON TABLE {TABS} IS '{COMMENT}'",
    *_rls(TABS, _child_rule("bi_dashboard_tabs")),
    CREATE_DASHCARDS,
    f"CREATE INDEX bi_dashcards_dashboard ON {DASHCARDS} (org_id, dashboard_id, tab_id)",
    f"CREATE INDEX bi_dashcards_card ON {DASHCARDS} (org_id, card_id) WHERE card_id IS NOT NULL",
    f"COMMENT ON TABLE {DASHCARDS} IS '{COMMENT}'",
    *_rls(DASHCARDS, _child_rule("bi_dashcards")),
    CREATE_REVISIONS,
    f"""CREATE INDEX bi_dashboard_revisions_dashboard ON {REVISIONS}
        (org_id, dashboard_id, revision_no DESC)""",
    f"COMMENT ON TABLE {REVISIONS} IS '{COMMENT}'",
    *_rls(REVISIONS, _child_rule("bi_dashboard_revisions")),
    *_widen(BOOKMARKS, "bi_bookmarks"),
    *_widen(VIEWS, "bi_views"),
]

# Order matters: the dashboard rows must go BEFORE the CHECKs are narrowed
# (or the narrower CHECK would refuse the existing rows).
DOWNGRADE_SQL: list[str] = [
    f"ALTER TABLE {BOOKMARKS} NO FORCE ROW LEVEL SECURITY",
    f"ALTER TABLE {VIEWS} NO FORCE ROW LEVEL SECURITY",
    f"DELETE FROM {BOOKMARKS} WHERE item_type = 'dashboard'",  # noqa: S608 (identifiers and constants only; values are bound parameters)
    f"DELETE FROM {VIEWS} WHERE item_type = 'dashboard'",  # noqa: S608 (identifiers and constants only; values are bound parameters)
    f"ALTER TABLE {BOOKMARKS} FORCE ROW LEVEL SECURITY",
    f"ALTER TABLE {VIEWS} FORCE ROW LEVEL SECURITY",
    f"ALTER TABLE {BOOKMARKS} DROP CONSTRAINT IF EXISTS bi_bookmarks_item_type_check",
    f"ALTER TABLE {VIEWS} DROP CONSTRAINT IF EXISTS bi_views_item_type_check",
    f"ALTER TABLE {BOOKMARKS} ADD CONSTRAINT bi_bookmarks_item_type_check "
    "CHECK (item_type IN ('card', 'collection'))",
    f"ALTER TABLE {VIEWS} ADD CONSTRAINT bi_views_item_type_check "
    "CHECK (item_type IN ('card', 'collection'))",
    "DROP INDEX IF EXISTS public.bi_dashboards_pinned",
    f"DROP TABLE IF EXISTS {REVISIONS}",
    f"DROP TABLE IF EXISTS {DASHCARDS}",
    f"DROP TABLE IF EXISTS {TABS}",
    f"DROP TABLE IF EXISTS {DASHBOARDS}",
]


def upgrade() -> None:
    for statement in UPGRADE_SQL:
        op.execute(statement)


def downgrade() -> None:
    for statement in DOWNGRADE_SQL:
        op.execute(statement)
