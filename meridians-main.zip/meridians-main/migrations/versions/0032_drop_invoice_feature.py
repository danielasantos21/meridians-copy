"""drop_invoice_feature — the in-app invoice wizard is gone, and so is what it stored.

Revision ID: 0032_drop_invoice_feature
Revises: 0031_queued_job_resend
Create Date: 2026-09-28

WHY
---
The invoice screen let Meridians Logic raise its own invoices to a client. It
was never part of the accounting processes, and it has been removed from the
app (React screen, `/api/v2/invoices`, `src/invoice_generator.py`). The two
one-off invoices are built by `scripts/build_meridians_invoices.py`, which reads
nothing from the database.

WHAT CHANGES
------------
* `public.org_modules` rows with `module = 'invoice'` are deleted.
* `public.role_permissions` rows with `process = 'invoice'` are deleted. The
  `role_permissions_process_check` CHECK still ALLOWS 'invoice': narrowing it
  needs the paired Supabase migration (`tests/test_registry_conformance.py`
  holds the two chains equal), and an allowed value nobody writes is harmless.
* The `invoice` block of each organization's `settings -> app_settings` is
  removed.
* `public.invoices`, `public.clients` and `public.invoice_counters` are dropped.
  Live Supabase held 0 rows in `invoices` and `clients` on 2026-09-28, checked
  before this revision was written.

THE GUARD
---------
The drop refuses if `invoices` or `clients` holds any row, and changes nothing:
an invoice is a document somebody was asked to pay against, and deleting one
is a decision for a person (export it first), not for a migration. The count
lifts FORCE ROW LEVEL SECURITY for its length — without that the migrator sees
zero rows on every tenant table and the guard would pass on a full table
(0005 and 0007 do the same). The same lift covers the two DELETEs. Everything
is in the one upgrade transaction, so a refusal rolls FORCE back with it.

DOWNGRADE
---------
Recreates the three tables as they stood at 0031 (columns, keys, indexes,
FORCE RLS, the org-isolation policy, the `meridian_app` grants), empty. The
deleted module, permission and settings rows are not re-inserted.
"""

from __future__ import annotations

from alembic import op

revision = "0032_drop_invoice_feature"
down_revision = "0031_queued_job_resend"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
POLICY = "meridian_org_isolation"
_ORG = "(org_id = app.current_org_id())"

#: Checked for rows before anything is dropped. `invoice_counters` is not: a
#: counter row states a number, not a document.
_GUARDED = ("public.invoices", "public.clients")
#: FORCE-RLS tenant tables the DELETEs below have to see every row of.
_DELETED_FROM = ("public.org_modules", "public.role_permissions")
#: Dropped in this order (`invoices` references `clients`).
_DROPPED = ("public.invoice_counters", "public.invoices", "public.clients")


def _lift_force(tables) -> None:
    for table in tables:
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY")


def _restore_force(tables) -> None:
    for table in tables:
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")


def upgrade() -> None:
    conn = op.get_bind()

    _lift_force(_GUARDED)
    counts = {
        table: conn.exec_driver_sql(f"SELECT count(*) FROM {table}").scalar()  # noqa: S608
        for table in _GUARDED
    }
    held = {table: n for table, n in counts.items() if n}
    if held:
        raise RuntimeError(
            "0032_drop_invoice_feature refuses to drop tables that hold rows: "
            + ", ".join(f"{t} has {n}" for t, n in held.items())
            + ". Export them, empty the tables by hand, then upgrade again."
        )

    _lift_force(_DELETED_FROM)
    op.execute("DELETE FROM public.org_modules WHERE module = 'invoice'")
    op.execute("DELETE FROM public.role_permissions WHERE process = 'invoice'")
    _restore_force(_DELETED_FROM)

    # `organizations` is ENABLE without FORCE (0004), so the owner sees every row.
    op.execute(
        "UPDATE public.organizations SET settings = settings #- '{app_settings,invoice}' "
        "WHERE settings -> 'app_settings' ? 'invoice'"
    )

    for table in _DROPPED:
        op.execute(f"DROP TABLE {table}")


def downgrade() -> None:
    op.execute(
        """
CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    address text,
    created_at timestamp with time zone DEFAULT now(),
    email text,
    phone text,
    CONSTRAINT clients_pkey PRIMARY KEY (id)
);
CREATE INDEX idx_clients_org ON public.clients USING btree (org_id);
CREATE INDEX idx_clients_org_id ON public.clients USING btree (org_id);

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    invoice_number text NOT NULL,
    client_id uuid,
    client_name text NOT NULL,
    client_address text,
    invoice_date date NOT NULL,
    due_date date,
    line_items jsonb NOT NULL,
    total numeric(10,2),
    notes text,
    pdf_filename text,
    status text DEFAULT 'draft'::text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT invoices_pkey PRIMARY KEY (id),
    CONSTRAINT invoices_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id)
);
CREATE INDEX idx_invoices_client_id ON public.invoices USING btree (client_id);
CREATE INDEX idx_invoices_created_at ON public.invoices USING btree (created_at DESC);
CREATE INDEX idx_invoices_number ON public.invoices USING btree (org_id, invoice_number);
CREATE INDEX idx_invoices_org ON public.invoices USING btree (org_id);
CREATE INDEX idx_invoices_org_id ON public.invoices USING btree (org_id);
CREATE UNIQUE INDEX invoices_org_number_key ON public.invoices
    USING btree (org_id, invoice_number) WHERE (invoice_number IS NOT NULL);

CREATE TABLE public.invoice_counters (
    org_id uuid NOT NULL,
    year integer NOT NULL,
    last_number integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT invoice_counters_pkey PRIMARY KEY (org_id)
);
"""
    )
    for table in reversed(_DROPPED):
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY {POLICY} ON {table} USING {_ORG} WITH CHECK {_ORG}")
        op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON {table} TO {APP_ROLE}")
