"""bi_models_metrics - models, metrics, segments and table/column metadata for BI.

Revision ID: 0046_bi_models_metrics
Revises: 0045_bi_ask_log
Create Date: 2026-10-15

WHY
---
BI Stage 6A adds (1) a data reference with admin-written names and descriptions
for tables and columns, (2) segments (named, saved filters), (3) metrics (named
numbers with their rules built in) and (4) models (a saved question treated like
a table). Metrics and models are kinds of saved card, so `bi_cards` is widened.

RENUMBER (read this if another migration also chains after 0045)
----------------------------------------------------------------
On main this was 0043, then 0045 after Ask Meridian landed. On the AWS branch the BI
chain is 0040-0046 (0039 is run_inputs), and this one chains after 0045_bi_ask_log.
Whoever merges SECOND renumbers: rename this file, then change `revision`,
`down_revision` and the `Revises:` line above, and re-run
tests/bi/test_alembic_one_head.py and the migration tests on a throwaway database.
Nothing here refers to the other session's tables.

WHAT IT ADDS
------------
* `public.bi_cards`: `kind` now accepts question / model / metric; new columns
  `result_metadata` (models only: column names and the staff's overrides),
  `source_tables` (stage-0 tables, for "questions about this table"),
  `ref_card_ids` / `ref_segment_ids` (what a saved item uses, for the
  "who depends on this" warning) and `seed_key` (built-in content, one per org).
  Existing builder questions get `source_tables` filled in.
* `public.bi_card_revisions.message`: three more codes (edited_metadata,
  converted_to_model, converted_to_question).
* `public.bi_segments`, `public.bi_segment_revisions`: saved filters and their
  history (a message is required for every edit).
* `public.bi_table_meta`: display names, descriptions, visibility, semantic type
  and foreign-key target set by org admins. DISPLAY ONLY: the query engine never
  reads this table to decide what is allowed.
All new tables: ENABLE + FORCE row level security with the policy
`meridian_org_isolation`, nothing for `phi_access`, full access for the app role.
Definitions and staff-written text only: no results, no PHI.

DOWNGRADE (read this first)
---------------------------
A downgrade DESTROYS every model, metric, segment and metadata edit. Back up
first. To delete model/metric cards and their bookmark / recently-viewed rows
it briefly switches FORCE row level security off on bi_cards, bi_card_revisions,
bi_bookmarks and bi_views (a plain table owner is otherwise blind to them), then
switches it on again. Revision rows that carry the three new codes are relabelled
`edited_query` so question history stays valid. Questions are kept.
Plain Postgres 17 only (identity columns, jsonb, NULLS NOT DISTINCT).
"""

from __future__ import annotations

from alembic import op

revision = "0046_bi_models_metrics"
down_revision = "0045_bi_ask_log"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
POLICY = "meridian_org_isolation"
CARDS = "public.bi_cards"
REVISIONS = "public.bi_card_revisions"
BOOKMARKS = "public.bi_bookmarks"
VIEWS = "public.bi_views"
SEGMENTS = "public.bi_segments"
SEG_REVISIONS = "public.bi_segment_revisions"
TABLE_META = "public.bi_table_meta"

COMMENT = "definitions and staff-written text only; no results, no PHI"
_KEY = "'^[a-z0-9_]{1,60}$'"
_IDENT = "'^[a-z][a-z0-9_]{0,62}$'"

_ORG_RULE = "(org_id = app.current_org_id())"
_SEG_REVISION_RULE = (
    "(org_id = app.current_org_id() AND EXISTS ("
    "SELECT 1 FROM public.bi_segments s "
    "WHERE s.org_id = bi_segment_revisions.org_id AND s.id = bi_segment_revisions.segment_id))"
)

OLD_CODES = (
    "created",
    "edited_query",
    "edited_chart",
    "renamed",
    "moved",
    "reverted",
    "trashed",
    "restored",
)
NEW_CODES = ("edited_metadata", "converted_to_model", "converted_to_question")


def _codes(codes) -> str:
    return ", ".join(f"'{c}'" for c in codes)


def _rls(table: str, rule: str) -> list[str]:
    return [
        f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY",
        f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY",
        f"CREATE POLICY {POLICY} ON {table} USING {rule} WITH CHECK {rule}",
        f"REVOKE ALL ON {table} FROM {PHI_ROLE}",
        f"GRANT SELECT, INSERT, UPDATE, DELETE ON {table} TO {APP_ROLE}",
    ]


# Look the generated CHECK name up instead of guessing it (0040 wrote them inline).
def _drop_check_like(table: str, needle: str) -> str:
    return f"""
DO $do$
DECLARE r record;
BEGIN
  FOR r IN SELECT conname FROM pg_constraint
           WHERE conrelid = '{table}'::regclass AND contype = 'c'
             AND pg_get_constraintdef(oid) LIKE '{needle}'
  LOOP
    EXECUTE 'ALTER TABLE {table} DROP CONSTRAINT ' || quote_ident(r.conname);
  END LOOP;
END
$do$
"""  # noqa: S608 (identifiers and constants only; values are bound parameters)


# (CASE, not AND: Postgres may evaluate AND parts in any order, and a length
# check on a non-array would then error.)
# Stage-0 source table plus every stage-0 join table, distinct and sorted. Only
# well-formed builder queries are touched; anything odd is skipped, never an error.
BACKFILL_SOURCE_TABLES = f"""
UPDATE {CARDS} SET source_tables = COALESCE((
    SELECT array_agg(DISTINCT t ORDER BY t) FROM (
        SELECT dataset_query #>> '{{query,stages,0,source-table}}' AS t
        UNION ALL
        SELECT j ->> 'source-table' FROM jsonb_array_elements(
            CASE WHEN jsonb_typeof(dataset_query #> '{{query,stages,0,joins}}') = 'array'
                 THEN dataset_query #> '{{query,stages,0,joins}}' ELSE '[]'::jsonb END) AS j
        WHERE jsonb_typeof(j) = 'object'
    ) s WHERE t IS NOT NULL AND t <> ''
), '{{}}'::text[])
WHERE CASE
    WHEN dataset_query ->> 'type' <> 'query' THEN false
    WHEN jsonb_typeof(dataset_query #> '{{query,stages}}') IS DISTINCT FROM 'array' THEN false
    WHEN jsonb_array_length(dataset_query #> '{{query,stages}}') = 0 THEN false
    ELSE jsonb_typeof(dataset_query #> '{{query,stages,0}}') = 'object'
  END
"""  # noqa: S608 (identifiers and constants only; values are bound parameters)

CREATE_SEGMENTS = f"""
CREATE TABLE {SEGMENTS} (
    id          bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id      uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    table_name  text        NOT NULL CHECK (table_name ~ {_IDENT}),
    name        text        NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 100),
    description text        CHECK (char_length(description) <= 2000),
    definition  jsonb       NOT NULL
        CHECK (jsonb_typeof(definition) = 'object' AND octet_length(definition::text) <= 8192),
    revision_no int         NOT NULL DEFAULT 1,
    seed_key    text        CHECK (seed_key ~ {_KEY}),
    archived_at timestamptz,
    archived_by uuid,
    created_by  uuid        NOT NULL,
    updated_by  uuid        NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id)
)
"""

CREATE_SEG_REVISIONS = f"""
CREATE TABLE {SEG_REVISIONS} (
    id          bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id      uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    segment_id  bigint      NOT NULL,
    revision_no int         NOT NULL,
    snapshot    jsonb       NOT NULL
        CHECK (jsonb_typeof(snapshot) = 'object' AND octet_length(snapshot::text) <= 16384),
    message     text        NOT NULL CHECK (char_length(btrim(message)) BETWEEN 1 AND 500),
    is_creation boolean     NOT NULL DEFAULT false,
    changed_by  uuid        NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, segment_id, revision_no),
    FOREIGN KEY (org_id, segment_id) REFERENCES {SEGMENTS} (org_id, id) ON DELETE CASCADE
)
"""

# column_name NULL means "the table itself"; NULLS NOT DISTINCT keeps that to one row.
CREATE_TABLE_META = f"""
CREATE TABLE {TABLE_META} (
    id              bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id          uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    table_name      text        NOT NULL CHECK (table_name ~ {_IDENT}),
    column_name     text        CHECK (column_name ~ {_IDENT}),
    display_name    text        CHECK (char_length(display_name) <= 100),
    description     text        CHECK (char_length(description) <= 2000),
    visibility_type text        CHECK (visibility_type IN ('normal', 'details-only', 'hidden')),
    semantic_type   text        CHECK (semantic_type ~ '^type/[A-Za-z]{{1,40}}$'),
    fk_target       jsonb       CHECK (jsonb_typeof(fk_target) = 'object'
                                       AND octet_length(fk_target::text) <= 512),
    updated_by      uuid        NOT NULL,
    updated_at      timestamptz NOT NULL DEFAULT now(),
    UNIQUE NULLS NOT DISTINCT (org_id, table_name, column_name)
)
"""

UPGRADE_SQL: list[str] = [
    # ---- bi_cards: kinds and bookkeeping columns
    _drop_check_like(CARDS, "%kind%"),
    f"ALTER TABLE {CARDS} ADD CONSTRAINT bi_cards_kind_check "
    "CHECK (kind IN ('question', 'model', 'metric'))",
    f"""ALTER TABLE {CARDS} ADD COLUMN result_metadata jsonb NOT NULL DEFAULT '[]'::jsonb
        CHECK (jsonb_typeof(result_metadata) = 'array'
               AND jsonb_array_length(result_metadata) <= 200
               AND octet_length(result_metadata::text) <= 65536)""",
    f"""ALTER TABLE {CARDS} ADD COLUMN source_tables text[] NOT NULL DEFAULT '{{}}'
        CHECK (cardinality(source_tables) <= 16)""",
    f"""ALTER TABLE {CARDS} ADD COLUMN ref_card_ids bigint[] NOT NULL DEFAULT '{{}}'
        CHECK (cardinality(ref_card_ids) <= 20)""",
    f"""ALTER TABLE {CARDS} ADD COLUMN ref_segment_ids bigint[] NOT NULL DEFAULT '{{}}'
        CHECK (cardinality(ref_segment_ids) <= 20)""",
    f"ALTER TABLE {CARDS} ADD COLUMN seed_key text CHECK (seed_key ~ {_KEY})",
    f"ALTER TABLE {CARDS} ADD CONSTRAINT bi_cards_kind_builder "
    "CHECK (kind = 'question' OR dataset_query ->> 'type' = 'query')",
    f"ALTER TABLE {CARDS} ADD CONSTRAINT bi_cards_metadata_models "
    "CHECK (kind = 'model' OR result_metadata = '[]'::jsonb)",
    f"ALTER TABLE {CARDS} ADD CONSTRAINT bi_cards_metric_one_stage "
    "CHECK (kind <> 'metric' OR jsonb_array_length(dataset_query #> '{query,stages}') = 1)",
    f"CREATE UNIQUE INDEX bi_cards_seed_key ON {CARDS} (org_id, seed_key) "
    "WHERE seed_key IS NOT NULL",
    f"CREATE INDEX bi_cards_source_tables ON {CARDS} USING gin (source_tables)",
    f"CREATE INDEX bi_cards_ref_card_ids ON {CARDS} USING gin (ref_card_ids)",
    f"CREATE INDEX bi_cards_ref_segment_ids ON {CARDS} USING gin (ref_segment_ids)",
    f"CREATE INDEX bi_cards_kind ON {CARDS} (org_id, kind) WHERE archived_at IS NULL",
    # ---- bi_card_revisions: three more message codes
    _drop_check_like(REVISIONS, "%message%"),
    f"ALTER TABLE {REVISIONS} ADD CONSTRAINT bi_card_revisions_message_check "
    f"CHECK (message IN ({_codes(OLD_CODES + NEW_CODES)}))",
    # ---- backfill (FORCE RLS would hide every row from a plain owner)
    f"ALTER TABLE {CARDS} NO FORCE ROW LEVEL SECURITY",
    BACKFILL_SOURCE_TABLES,
    f"ALTER TABLE {CARDS} FORCE ROW LEVEL SECURITY",
    # ---- new tables
    CREATE_SEGMENTS,
    f"CREATE UNIQUE INDEX bi_segments_live_name ON {SEGMENTS} "
    "(org_id, table_name, lower(name)) WHERE archived_at IS NULL",
    f"CREATE UNIQUE INDEX bi_segments_seed_key ON {SEGMENTS} (org_id, seed_key) "
    "WHERE seed_key IS NOT NULL",
    f"COMMENT ON TABLE {SEGMENTS} IS '{COMMENT}'",
    *_rls(SEGMENTS, _ORG_RULE),
    CREATE_SEG_REVISIONS,
    f"CREATE INDEX bi_segment_revisions_segment ON {SEG_REVISIONS} "
    "(org_id, segment_id, revision_no DESC)",
    f"COMMENT ON TABLE {SEG_REVISIONS} IS '{COMMENT}'",
    *_rls(SEG_REVISIONS, _SEG_REVISION_RULE),
    CREATE_TABLE_META,
    f"COMMENT ON TABLE {TABLE_META} IS '{COMMENT}'",
    *_rls(TABLE_META, _ORG_RULE),
]

# Order matters: rows that the narrower CHECKs would refuse go first.
DOWNGRADE_SQL: list[str] = [
    f"ALTER TABLE {CARDS} NO FORCE ROW LEVEL SECURITY",
    f"ALTER TABLE {REVISIONS} NO FORCE ROW LEVEL SECURITY",
    f"ALTER TABLE {BOOKMARKS} NO FORCE ROW LEVEL SECURITY",
    f"ALTER TABLE {VIEWS} NO FORCE ROW LEVEL SECURITY",
    f"UPDATE {REVISIONS} SET message = 'edited_query' WHERE message IN ({_codes(NEW_CODES)})",  # noqa: S608 (identifiers and constants only; values are bound parameters)
    *[
        f"DELETE FROM {t} WHERE item_type = 'card' AND item_id IN "  # noqa: S608 (identifiers and constants only; values are bound parameters)
        f"(SELECT id FROM {CARDS} WHERE kind <> 'question')"
        for t in (BOOKMARKS, VIEWS)
    ],
    f"DELETE FROM {CARDS} WHERE kind <> 'question'",  # noqa: S608 (identifiers and constants only; values are bound parameters)
    f"ALTER TABLE {CARDS} FORCE ROW LEVEL SECURITY",
    f"ALTER TABLE {REVISIONS} FORCE ROW LEVEL SECURITY",
    f"ALTER TABLE {BOOKMARKS} FORCE ROW LEVEL SECURITY",
    f"ALTER TABLE {VIEWS} FORCE ROW LEVEL SECURITY",
    "DROP INDEX IF EXISTS public.bi_cards_kind",
    "DROP INDEX IF EXISTS public.bi_cards_ref_segment_ids",
    "DROP INDEX IF EXISTS public.bi_cards_ref_card_ids",
    "DROP INDEX IF EXISTS public.bi_cards_source_tables",
    "DROP INDEX IF EXISTS public.bi_cards_seed_key",
    f"ALTER TABLE {CARDS} DROP CONSTRAINT IF EXISTS bi_cards_metric_one_stage",
    f"ALTER TABLE {CARDS} DROP CONSTRAINT IF EXISTS bi_cards_metadata_models",
    f"ALTER TABLE {CARDS} DROP CONSTRAINT IF EXISTS bi_cards_kind_builder",
    # Dropping a column drops the CHECK that was written inline on it.
    f"ALTER TABLE {CARDS} DROP COLUMN seed_key, DROP COLUMN ref_segment_ids, "
    "DROP COLUMN ref_card_ids, DROP COLUMN source_tables, DROP COLUMN result_metadata",
    f"ALTER TABLE {CARDS} DROP CONSTRAINT IF EXISTS bi_cards_kind_check",
    f"ALTER TABLE {CARDS} ADD CONSTRAINT bi_cards_kind_check CHECK (kind IN ('question'))",
    f"ALTER TABLE {REVISIONS} DROP CONSTRAINT IF EXISTS bi_card_revisions_message_check",
    f"ALTER TABLE {REVISIONS} ADD CONSTRAINT bi_card_revisions_message_check "
    f"CHECK (message IN ({_codes(OLD_CODES)}))",
    f"DROP TABLE IF EXISTS {SEG_REVISIONS}",
    f"DROP TABLE IF EXISTS {SEGMENTS}",
    f"DROP TABLE IF EXISTS {TABLE_META}",
]


def upgrade() -> None:
    for statement in UPGRADE_SQL:
        op.execute(statement)


def downgrade() -> None:
    for statement in DOWNGRADE_SQL:
        op.execute(statement)
