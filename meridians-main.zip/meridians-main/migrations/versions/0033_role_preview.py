"""role_preview — "View as role": an admin sees the product as one role would.

Revision ID: 0033_role_preview
Revises: 0032_drop_invoice_feature
Create Date: 2026-09-28

WHY
---
An org admin (or a superadmin) wants to check what a role can really see and
do before handing it to somebody. Settings -> Roles -> "View as this role"
starts a preview; while it lasts, `src.auth.org_context` answers every request
of THAT user in THAT org with the role's permissions intersected with the
user's own. It can only take rights away, never add them, and it is enforced by
the server on every surface (v2, the mounted Flask paths, v3 humans), so what
the admin sees is what the role would be allowed — not just hidden buttons.

WHAT IT ADDS
------------
1. `public.role_preview` — one row per (org, user) with a preview running:
   which role, and when it stops counting (`expires_at`, two hours after it was
   started). Server-owned state: nothing the browser sends can create, extend
   or change it except `POST|DELETE /api/v2/me/preview-role`, which validate
   the caller from the database first. A tenant table: `org_id`, FORCE RLS and
   the org-isolation policy like every other, plus the row must be the
   session's own user's (`user_id = app.current_user_id()`), so one admin's
   session can never read or end another admin's preview. `role_id` references
   `public.roles` with ON DELETE CASCADE: deleting the role ends the preview.

2. `audit.role_preview` — one append-only row per preview started or stopped,
   written in the same transaction as the `public.role_preview` change. Ids and
   the action only. INSERT for `meridian_app` and nothing else, plus
   `audit.refuse_change()` on UPDATE, DELETE and TRUNCATE (the 0017 pattern).

RDS-only: Supabase never runs Alembic. On the Supabase backend (one worker on
Render) the preview lives in the api process's memory and the audit fact is
the `role_preview` log event, which the service emits on both backends.

DOWNGRADE drops both tables (an in-flight preview simply ends).
"""

from __future__ import annotations

from alembic import op

revision = "0033_role_preview"
down_revision = "0032_drop_invoice_feature"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
PREVIEW_TABLE = "public.role_preview"
AUDIT_TABLE = "audit.role_preview"
ORG_POLICY = "meridian_org_isolation"
#: The org scope AND the session's own user: a preview is one person's state.
_OWN = "(org_id = app.current_org_id() AND user_id = app.current_user_id())"

PREVIEW = f"""
CREATE TABLE {PREVIEW_TABLE} (
    org_id      uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id     uuid        NOT NULL,
    role_id     uuid        NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
    started_at  timestamptz NOT NULL DEFAULT now(),
    expires_at  timestamptz NOT NULL,
    PRIMARY KEY (org_id, user_id),
    CHECK (expires_at > started_at)
);
COMMENT ON TABLE {PREVIEW_TABLE} IS
    'View-as-role previews: while a row is unexpired, that user''s requests in that '
    'org are answered with the role''s permissions (intersected with their own). '
    'Only ever reduces access. Server-owned; ids only.';
CREATE INDEX idx_role_preview_role ON {PREVIEW_TABLE} (role_id);
ALTER TABLE {PREVIEW_TABLE} ENABLE ROW LEVEL SECURITY;
ALTER TABLE {PREVIEW_TABLE} FORCE ROW LEVEL SECURITY;
CREATE POLICY {ORG_POLICY} ON {PREVIEW_TABLE} USING {_OWN} WITH CHECK {_OWN};
REVOKE ALL ON {PREVIEW_TABLE} FROM {PHI_ROLE};
GRANT SELECT, INSERT, UPDATE, DELETE ON {PREVIEW_TABLE} TO {APP_ROLE};
"""

AUDIT = f"""
CREATE TABLE {AUDIT_TABLE} (
    id             bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at             timestamptz NOT NULL DEFAULT now(),
    org_id         uuid        NOT NULL,
    actor_user_id  uuid        NOT NULL,
    role_id        uuid        NOT NULL,
    action         text        NOT NULL CHECK (action IN ('started', 'stopped'))
);
COMMENT ON TABLE {AUDIT_TABLE} IS
    'One row per role preview started or stopped, written in the transaction that '
    'changes public.role_preview. Ids only. Append-only.';
CREATE INDEX idx_role_preview_audit_org ON {AUDIT_TABLE} (org_id, at DESC);
REVOKE ALL ON {AUDIT_TABLE} FROM {APP_ROLE}, {PHI_ROLE};
GRANT INSERT ON {AUDIT_TABLE} TO {APP_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.role_preview_id_seq TO {APP_ROLE};
CREATE TRIGGER role_preview_append_only
    BEFORE UPDATE OR DELETE ON {AUDIT_TABLE}
    FOR EACH ROW EXECUTE FUNCTION audit.refuse_change();
CREATE TRIGGER role_preview_no_truncate
    BEFORE TRUNCATE ON {AUDIT_TABLE}
    FOR EACH STATEMENT EXECUTE FUNCTION audit.refuse_change();
"""


def upgrade() -> None:
    op.execute(PREVIEW)
    op.execute(AUDIT)


def downgrade() -> None:
    op.execute(f"DROP TABLE IF EXISTS {AUDIT_TABLE}")
    op.execute(f"DROP TABLE IF EXISTS {PREVIEW_TABLE}")
