"""process_runs — a UNIQUE constraint on (run_id, org_id).

Revision ID: 0008_process_runs_unique
Revises: 0007_invoice_numbers
Create Date: 2026-09-16

Phase 5a of `docs/aws-migration-plan.md` — "`src/process_runs.py` (0.5 day —
real `INSERT … ON CONFLICT (run_id, org_id)` closes an existing race)".

WHY IT EXISTS
-------------
`SupabaseRunStore.upsert` is a read-then-write: it calls `get()`, and inserts
when that answers `None` and updates when it does not. Two workers writing
progress for the same run in the same instant both read `None` and both insert,
and the second one fails on the primary key — which `_mark_superseded`
(`src/process_runs.py`) then swallows, so a run quietly loses the write that
retired it. PostgREST has no `ON CONFLICT … DO UPDATE` that returns the row, so
the race could not be closed from the application side; SQL can, in one
statement.

`INSERT … ON CONFLICT (run_id, org_id) DO UPDATE` needs a unique index on
**exactly** those two columns, and the baseline has none:
`process_runs_pkey` is `PRIMARY KEY (run_id)` alone
(`migrations/baseline/supabase_public_schema_2026-09-15.sql:3136`), and
`uq_process_runs_idempotency` is `(org_id, idempotency_key) WHERE
idempotency_key IS NOT NULL`. Hence this revision.

WHY (run_id, org_id) AND NOT run_id ALONE
------------------------------------------
`run_id` is already unique, so this constraint forbids nothing a row could
otherwise do — it adds no integrity. What it adds is a **conflict target that
names the tenant**, which is ADR 0022's rule for every upsert in this codebase:
the conflict target is always `(org_id, …)` and never the bare key, so that a
run id belonging to another organization can never be the row an upsert lands
on. With `ON CONFLICT (run_id)` a write for org B carrying org A's run id would
resolve to A's row and the `DO UPDATE` would be the thing deciding whether that
mattered. With this target it does not resolve at all: no conflicting row, and
the insert fails the `org_id` foreign key or is refused by row-level security,
which is the honest outcome.

It also makes the statement readable as layer (a) of ADR 0011 —
`scripts/lint_org_scope.py` and a human both see the organization named.

The redundancy is the cost, and it is one more btree index on a table that
holds one row per booking session. That is not a table whose write rate this
index can be felt on.

DOWNGRADE
---------
Supported and free: it drops the constraint. Nothing depends on it except the
`ON CONFLICT` target in `src/process_runs.py`, which would then raise
`InvalidColumnReference` rather than corrupt anything — a downgrade of the
schema without a downgrade of the code is a broken deployment either way, and
this one breaks loudly.
"""

from __future__ import annotations

from alembic import op

revision = "0008_process_runs_unique"
down_revision = "0007_invoice_numbers"
branch_labels = None
depends_on = None

TABLE = "public.process_runs"
CONSTRAINT = "uq_process_runs_run_org"

#: `ALTER TABLE ... ADD CONSTRAINT` has no `IF NOT EXISTS`, and this revision has
#: to be replayable over a database that already carries the constraint (a
#: rehearsal, a restored dump taken after it landed). A guarded `DO` block is the
#: idempotent spelling, and unlike `CREATE UNIQUE INDEX IF NOT EXISTS` it leaves a
#: named CONSTRAINT behind, which is what `pg_constraint` and a reader both look
#: for.
ADD_CONSTRAINT = f"""
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
         WHERE conname = '{CONSTRAINT}'
           AND conrelid = '{TABLE}'::regclass
    ) THEN
        ALTER TABLE {TABLE} ADD CONSTRAINT {CONSTRAINT} UNIQUE (run_id, org_id);
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(ADD_CONSTRAINT)


def downgrade() -> None:
    op.execute(f"ALTER TABLE {TABLE} DROP CONSTRAINT IF EXISTS {CONSTRAINT}")
