"""drop_wearbly_tables — the five `uniform_*` tables go, rows and all.

Revision ID: 0037_drop_wearbly_tables
Revises: 0036_pins_max_three
Create Date: 2026-10-09

WHY
---
Wearbly's code left Meridian on 2026-09-29 (tracker T:105): nothing reads or
writes `uniform_catalog`, `uniform_column_mappings`, `uniform_orders`,
`uniform_order_items` or `uniform_size_mappings` any more. Owner's decision,
2026-10-09 (T:245): drop all five, with NO export of their rows.

WHAT CHANGES
------------
`DROP TABLE` on the five, `uniform_order_items` before `uniform_orders` (its
`order_id` foreign key is the only one between them; nothing else references
any of the five). Their sequences are `OWNED BY` the `id` columns and their
policies, grants and indexes belong to the tables, so all of it goes with them.
No `CASCADE`: if a staging or production database has grown something on top of
these tables that this chain did not create, the upgrade stops and says so
rather than dropping it unseen.

NO ROW GUARD, UNLIKE 0032
-------------------------
0032 refused to drop invoice tables that held rows, because whether to keep an
invoice was a decision nobody had made. Here it has been made: the rows are
deleted on purpose, and live Supabase still holds them until it is retired. A
guard would only stop the cutover load, which restores those rows at 0003.

THE CUTOVER DATA LOAD NEEDS NO CHANGE
-------------------------------------
`scripts/staging_data_load.sh` (docs/runbooks/data-load.md) dumps every public
table from Supabase — these five included — restores at 0003, where the
baseline still has them, then upgrades to head, which drops them. Leaving them
in the dump was chosen over excluding them because it keeps `verify_parity.py
--at 0003` comparing the whole database as it stands. `--at head` already
copes with a table on one side only: `head_comparable()` keeps the per-table
checks (`table_count`, `null_org_rows`) only for tables both sides have, the
schema-shaped checks are not run at head, and `sequence_ahead_of_max` is judged
on the target alone — the same path 0032's three tables take.

`scripts/tenant_tables.txt` keeps the five, in the "dropped by a later
revision" section (`MIGRATION_DROPPED` in scripts/gen_tenant_tables.py),
because revision 0004 reads that file to decide which tables get FORCE RLS,
and at 0004 these still exist.

DOWNGRADE
---------
Recreates the five as they stood at 0036 — columns, defaults, the status CHECK,
sequences, keys, indexes, foreign keys, ENABLE + FORCE RLS, the org-isolation
policy and the `meridian_app` grants on each table and sequence — empty. The
rows are not coming back.
"""

from __future__ import annotations

from alembic import op

revision = "0037_drop_wearbly_tables"
down_revision = "0036_pins_max_three"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
POLICY = "meridian_org_isolation"
_ORG = "(org_id = app.current_org_id())"

#: Dropped in this order (`uniform_order_items.order_id` references `uniform_orders`).
_DROPPED = (
    "public.uniform_order_items",
    "public.uniform_orders",
    "public.uniform_catalog",
    "public.uniform_column_mappings",
    "public.uniform_size_mappings",
)


def upgrade() -> None:
    for table in _DROPPED:
        op.execute(f"DROP TABLE {table}")


def downgrade() -> None:
    op.execute(
        """
CREATE TABLE public.uniform_catalog (
    id bigserial NOT NULL,
    org_id uuid NOT NULL,
    item_type text NOT NULL,
    size text NOT NULL,
    gender text,
    brand text NOT NULL,
    cut text DEFAULT 'Regular'::text NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    sku text,
    vendor text,
    embroidery_logo_cost numeric(10,2) DEFAULT 0,
    embroidery_name_cost numeric(10,2) DEFAULT 0,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT uniform_catalog_pkey PRIMARY KEY (id),
    CONSTRAINT uniform_catalog_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id)
);
CREATE INDEX idx_uniform_catalog_org_lookup ON public.uniform_catalog
    USING btree (org_id, item_type, size, gender, brand, cut);

CREATE TABLE public.uniform_column_mappings (
    id bigserial NOT NULL,
    org_id uuid NOT NULL,
    source_header text NOT NULL,
    canonical_field text NOT NULL,
    confidence numeric(5,2),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT uniform_column_mappings_pkey PRIMARY KEY (id),
    CONSTRAINT uniform_column_mappings_org_id_source_header_key UNIQUE (org_id, source_header),
    CONSTRAINT uniform_column_mappings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id)
);
CREATE INDEX idx_uniform_column_mappings_org_header ON public.uniform_column_mappings
    USING btree (org_id, source_header);

CREATE TABLE public.uniform_orders (
    id bigserial NOT NULL,
    org_id uuid NOT NULL,
    created_by text,
    client_name text,
    status text DEFAULT 'processing'::text NOT NULL,
    subtotal numeric(12,2) DEFAULT 0,
    embroidery_total numeric(12,2) DEFAULT 0,
    grand_total numeric(12,2) DEFAULT 0,
    logo_embroidery_flag boolean DEFAULT false,
    name_embroidery_flag boolean DEFAULT false,
    options_json jsonb,
    pdf_storage_path text,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT uniform_orders_pkey PRIMARY KEY (id),
    CONSTRAINT uniform_orders_status_check
        CHECK ((status = ANY (ARRAY['processing'::text, 'complete'::text, 'failed'::text]))),
    CONSTRAINT uniform_orders_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id)
);
CREATE INDEX idx_uniform_orders_org_created ON public.uniform_orders
    USING btree (org_id, created_at DESC);

CREATE TABLE public.uniform_order_items (
    id bigserial NOT NULL,
    order_id bigint NOT NULL,
    org_id uuid NOT NULL,
    employee_name text,
    item_type text NOT NULL,
    brand text,
    original_size text,
    normalized_size text,
    gender text,
    cut text,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2),
    line_total numeric(12,2),
    sku text,
    vendor text,
    logo_embroidery boolean DEFAULT false,
    name_embroidery boolean DEFAULT false,
    embroidery_cost numeric(10,2) DEFAULT 0,
    lookup_status text,
    CONSTRAINT uniform_order_items_pkey PRIMARY KEY (id),
    CONSTRAINT uniform_order_items_order_id_fkey FOREIGN KEY (order_id)
        REFERENCES public.uniform_orders(id) ON DELETE CASCADE,
    CONSTRAINT uniform_order_items_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id)
);
CREATE INDEX idx_uniform_order_items_order_id ON public.uniform_order_items
    USING btree (order_id);

CREATE TABLE public.uniform_size_mappings (
    id bigserial NOT NULL,
    org_id uuid NOT NULL,
    input_pattern text NOT NULL,
    normalized_size text NOT NULL,
    item_type text,
    CONSTRAINT uniform_size_mappings_pkey PRIMARY KEY (id),
    CONSTRAINT uniform_size_mappings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id)
);
CREATE INDEX idx_uniform_size_mappings_org_pattern ON public.uniform_size_mappings
    USING btree (org_id, input_pattern);
CREATE UNIQUE INDEX uq_uniform_size_mappings_global ON public.uniform_size_mappings
    USING btree (org_id, input_pattern) WHERE (item_type IS NULL);
CREATE UNIQUE INDEX uq_uniform_size_mappings_typed ON public.uniform_size_mappings
    USING btree (org_id, input_pattern, item_type) WHERE (item_type IS NOT NULL);
"""
    )
    for table in reversed(_DROPPED):
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY {POLICY} ON {table} USING {_ORG} WITH CHECK {_ORG}")
        op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON {table} TO {APP_ROLE}")
        op.execute(f"GRANT SELECT, USAGE ON SEQUENCE {table}_id_seq TO {APP_ROLE}")
