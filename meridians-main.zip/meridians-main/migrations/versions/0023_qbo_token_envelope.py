"""qbo_token_envelope — QuickBooks OAuth tokens stored sealed, never in plaintext again.

Revision ID: 0023_qbo_token_envelope
Revises: 0022_redeliverable_jobs
Create Date: 2026-09-24

ADR 0044. RDS-only: Supabase never runs Alembic, and its path is unchanged.

WHY
---
`public.qbo_connection.access_token` / `refresh_token` are bearer credentials to
a client's books, and until now they sat in plaintext columns protected only by
the storage encryption every other column has (the D18 note). From this
revision the application seals them before they reach the database
(`src/qbo_token_crypto.py`: AES-256-GCM under a per-write data key wrapped by
KMS), so a snapshot, a dump, a replica or a `SELECT *` under the app role reads
ciphertext.

WHAT CHANGES
------------
* Four new columns: `access_token_ct`, `refresh_token_ct` (bytea, the sealed
  tokens), `token_dek` (bytea, the WRAPPED data key) and `token_kek_id` (text,
  which key wrapped it — a KMS key ARN or a local fingerprint, never a key).
* `access_token` / `refresh_token` become NULLable, and CHECK
  `qbo_connection_token_form` says a row is EITHER legacy plaintext (both
  plaintext columns, no sealed ones) OR sealed (all four sealed columns, both
  plaintext NULL) — never both, never neither.
* CHECK `qbo_connection_token_ct_shape`: a sealed token starts with the format
  byte 0x01 and is at least nonce + tag long, so a plaintext token written into
  a ciphertext column by mistake is refused.
* Trigger `qbo_connection_no_new_plaintext`: an INSERT with a plaintext token,
  or an UPDATE that sets one to anything but what the row already holds, is
  refused. Existing rows are left alone — that is the dual read.

WHY NO BACKFILL HERE
--------------------
Sealing needs the key, and a migration must never hold one. The existing
plaintext rows are re-saved THROUGH THE APPLICATION by
`scripts/encrypt_qbo_tokens.py` (an api task on AWS, with the KMS grant), which
also re-seals every row under a fresh data key with `--rotate-data-keys`. After
cutover the plaintext columns are dropped by a later revision (tracker row).

The data load (`pg_restore --data-only`) happens between 0003 and 0004, long
before this trigger exists, so it is not refused.

DOWNGRADE
---------
Refused while any row is sealed: the plaintext columns cannot be restored
without the key, and dropping the sealed columns would destroy the only copy of
those tokens. With no sealed row it drops the trigger, the function, the checks
and the columns, and restores NOT NULL.

The check itself (fixed 2026-09-25, critic L-5): the migrator owns the table,
but 0004's FORCE ROW LEVEL SECURITY applies to the owner too, and a migration
sets no `app.org_id`, so the original `IF EXISTS (SELECT ... FROM
qbo_connection ...)` saw no rows at all and never fired (the downgrade then
failed only by luck, on `SET NOT NULL` over a sealed row's NULL plaintext). The
check now runs with FORCE lifted for the owner inside the downgrade's own
transaction and put back straight after; a refusal rolls both back.
`tests/test_qbo_token_sealed_downgrade_pg.py` proves it fires.
"""

from __future__ import annotations

from alembic import op

revision = "0023_qbo_token_envelope"
down_revision = "0022_redeliverable_jobs"
branch_labels = None
depends_on = None

TABLE = "public.qbo_connection"

#: `src/qbo_token_crypto.py`: FORMAT_VERSION (1 byte) + NONCE_BYTES (12) + TAG_BYTES (16).
MIN_SEALED_BYTES = 1 + 12 + 16

UPGRADE = f"""
ALTER TABLE {TABLE}
    ADD COLUMN access_token_ct  bytea,
    ADD COLUMN refresh_token_ct bytea,
    ADD COLUMN token_dek        bytea,
    ADD COLUMN token_kek_id     text,
    ALTER COLUMN access_token  DROP NOT NULL,
    ALTER COLUMN refresh_token DROP NOT NULL;

ALTER TABLE {TABLE} ADD CONSTRAINT qbo_connection_token_form CHECK (
    (access_token IS NOT NULL AND refresh_token IS NOT NULL
     AND access_token_ct IS NULL AND refresh_token_ct IS NULL
     AND token_dek IS NULL AND token_kek_id IS NULL)
    OR
    (access_token IS NULL AND refresh_token IS NULL
     AND access_token_ct IS NOT NULL AND refresh_token_ct IS NOT NULL
     AND token_dek IS NOT NULL AND token_kek_id IS NOT NULL)
);

ALTER TABLE {TABLE} ADD CONSTRAINT qbo_connection_token_ct_shape CHECK (
    (access_token_ct IS NULL
     OR (octet_length(access_token_ct) >= {MIN_SEALED_BYTES}
         AND substring(access_token_ct FROM 1 FOR 1) = '\\x01'::bytea))
    AND
    (refresh_token_ct IS NULL
     OR (octet_length(refresh_token_ct) >= {MIN_SEALED_BYTES}
         AND substring(refresh_token_ct FROM 1 FOR 1) = '\\x01'::bytea))
    AND (token_kek_id IS NULL
         OR (length(token_kek_id) <= 2048 AND token_kek_id ~ '^(kms|local):[A-Za-z0-9:/_.-]+$'))
);

COMMENT ON COLUMN {TABLE}.access_token_ct IS
    'AES-256-GCM sealed access token (ADR 0044): 0x01 || nonce || ciphertext+tag.';
COMMENT ON COLUMN {TABLE}.refresh_token_ct IS
    'AES-256-GCM sealed refresh token (ADR 0044), same data key as access_token_ct.';
COMMENT ON COLUMN {TABLE}.token_dek IS
    'The data key, WRAPPED by the key named in token_kek_id. Never the plaintext key.';
COMMENT ON COLUMN {TABLE}.token_kek_id IS
    'Which key wrapped token_dek: kms:<key arn> or local:<fingerprint>. Never a key.';
COMMENT ON COLUMN {TABLE}.access_token IS
    'LEGACY plaintext, read only until scripts/encrypt_qbo_tokens.py re-seals the row; '
    'no new value may be written (trigger qbo_connection_no_new_plaintext). Dropped after cutover.';
COMMENT ON COLUMN {TABLE}.refresh_token IS
    'LEGACY plaintext; see access_token.';

CREATE FUNCTION app.qbo_connection_no_new_plaintext() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path = pg_catalog, pg_temp
AS $$
BEGIN
    IF (NEW.access_token IS NOT NULL
        AND (TG_OP = 'INSERT' OR NEW.access_token IS DISTINCT FROM OLD.access_token))
       OR (NEW.refresh_token IS NOT NULL
        AND (TG_OP = 'INSERT' OR NEW.refresh_token IS DISTINCT FROM OLD.refresh_token))
    THEN
        RAISE EXCEPTION 'qbo_connection tokens are written sealed only (revision 0023, ADR 0044)'
            USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END
$$;
REVOKE ALL ON FUNCTION app.qbo_connection_no_new_plaintext() FROM PUBLIC;

CREATE TRIGGER qbo_connection_no_new_plaintext
    BEFORE INSERT OR UPDATE ON {TABLE}
    FOR EACH ROW EXECUTE FUNCTION app.qbo_connection_no_new_plaintext();
"""

#: FORCE RLS binds the owning migrator too, and no `app.org_id` is set here, so
#: the owner reads the table only with FORCE lifted (module docstring, L-5).
REFUSE_SEALED_DOWNGRADE = f"""
ALTER TABLE {TABLE} NO FORCE ROW LEVEL SECURITY;
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM {TABLE} WHERE token_dek IS NOT NULL) THEN
        RAISE EXCEPTION 'refusing to downgrade 0023: sealed QuickBooks tokens exist and '
            'cannot be restored to plaintext without the key';
    END IF;
END
$$;
ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;
"""  # noqa: S608 DDL from module constants; no runtime input

DOWNGRADE = f"""
DROP TRIGGER IF EXISTS qbo_connection_no_new_plaintext ON {TABLE};
DROP FUNCTION IF EXISTS app.qbo_connection_no_new_plaintext();
ALTER TABLE {TABLE} DROP CONSTRAINT IF EXISTS qbo_connection_token_ct_shape;
ALTER TABLE {TABLE} DROP CONSTRAINT IF EXISTS qbo_connection_token_form;
ALTER TABLE {TABLE}
    DROP COLUMN IF EXISTS access_token_ct,
    DROP COLUMN IF EXISTS refresh_token_ct,
    DROP COLUMN IF EXISTS token_dek,
    DROP COLUMN IF EXISTS token_kek_id,
    ALTER COLUMN access_token  SET NOT NULL,
    ALTER COLUMN refresh_token SET NOT NULL;
COMMENT ON COLUMN {TABLE}.access_token IS NULL;
COMMENT ON COLUMN {TABLE}.refresh_token IS NULL;
"""


def upgrade() -> None:
    op.execute(UPGRADE)


def downgrade() -> None:
    op.execute(REFUSE_SEALED_DOWNGRADE)
    op.execute(DOWNGRADE)
