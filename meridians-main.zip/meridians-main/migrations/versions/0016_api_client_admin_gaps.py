"""api_client_admin_gaps — usage metrics, BAA revocation, rotation flag.

Revision ID: 0016_api_client_admin_gaps
Revises: 0015_create_organization
Create Date: 2026-09-24

Phase 12, the T12 gaps T13 found (`docs/reports/phase-12-plan.md` §3.8 items 5,
6 and 9). Three additive pieces:

1. `api_clients.rotation_started_at` — set when a second secret is added
   (`rotate-secret`), cleared when the older one is deleted
   (`rotate-secret/complete`). The admin screen shows "Finish rotation" only
   while it is set. Cognito stays the authority on how many secrets exist; this
   is what the screen can read without calling Cognito on every page.

2. `partner_baas.revoked_by` / `revoked_reason` — who revoked a BAA and why,
   on the row itself, beside the `approved_by` it already has. Plus the keyset
   index the BAA list needs (§3.3).

3. `app.api_client_usage(org, client, days)` and
   `app.api_client_recent_ips(org, client, days)` — requests per day, errors
   per day and the last addresses seen, for ONE client of THE SESSION'S org,
   over at most 90 days. `audit.api_request` is INSERT-only for `meridian_app`
   (0013) and stays that way: the application never reads a raw audit row.
   These two `SECURITY DEFINER` functions return aggregates only, and are owned
   by `meridian_usage_reader`, a NOLOGIN role created here holding SELECT on
   five columns of that table and nothing else (the `meridian_api_lookup`
   pattern from 0013). Both refuse to answer unless `p_org_id` is the session's
   `app.org_id` — the explicit predicate AND the session, as everywhere else —
   and both are bounded by `idx_api_request_client (api_client_id, at DESC)`.

DOWNGRADE drops the functions, the role, the index and the three columns.
"""

from __future__ import annotations

from alembic import op

revision = "0016_api_client_admin_gaps"
down_revision = "0015_create_organization"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
USAGE_ROLE = "meridian_usage_reader"

#: The widest window either function answers for. A larger `p_days` returns
#: nothing rather than scanning years of audit rows.
MAX_DAYS = 90

#: How many distinct addresses `api_client_recent_ips` returns at most.
MAX_IPS = 5

COLUMNS = """
ALTER TABLE public.api_clients
    ADD COLUMN rotation_started_at timestamptz;
COMMENT ON COLUMN public.api_clients.rotation_started_at IS
    'Set while a secret rotation is in progress (two secrets live); NULL otherwise.';

ALTER TABLE public.partner_baas
    ADD COLUMN revoked_by     uuid,
    ADD COLUMN revoked_reason text CHECK (length(revoked_reason) <= 500);
CREATE INDEX idx_partner_baas_org
    ON public.partner_baas (org_id, approved_at DESC, id DESC);
"""

CREATE_USAGE_ROLE = f"""
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{USAGE_ROLE}') THEN
        CREATE ROLE {USAGE_ROLE} NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB
            NOCREATEROLE NOINHERIT;
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input

USAGE_FUNCTIONS = f"""
GRANT USAGE ON SCHEMA audit TO {USAGE_ROLE};
GRANT SELECT (at, org_id, api_client_id, status, ip) ON audit.api_request TO {USAGE_ROLE};

CREATE FUNCTION app.api_client_usage(p_org_id uuid, p_client_id uuid, p_days integer)
RETURNS TABLE (day date, requests bigint, errors bigint)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
    SELECT (r.at AT TIME ZONE 'UTC')::date AS day,
           count(*)                                AS requests,
           count(*) FILTER (WHERE r.status >= 400) AS errors
      FROM audit.api_request r
     WHERE r.api_client_id = p_client_id
       AND r.at >= now() - make_interval(days => p_days)
       AND r.org_id = p_org_id
       AND p_org_id = app.current_org_id()
       AND p_days BETWEEN 1 AND {MAX_DAYS}
     GROUP BY 1
     ORDER BY 1
$fn$;
COMMENT ON FUNCTION app.api_client_usage(uuid, uuid, integer) IS
    'Requests and errors per UTC day for one machine client of the session''s org '
    '(Phase 12 T12 gaps). Aggregates only; at most {MAX_DAYS} days.';

CREATE FUNCTION app.api_client_recent_ips(p_org_id uuid, p_client_id uuid, p_days integer)
RETURNS TABLE (ip inet, last_seen timestamptz, requests bigint)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
    SELECT r.ip, max(r.at), count(*)
      FROM audit.api_request r
     WHERE r.api_client_id = p_client_id
       AND r.at >= now() - make_interval(days => p_days)
       AND r.org_id = p_org_id
       AND p_org_id = app.current_org_id()
       AND p_days BETWEEN 1 AND {MAX_DAYS}
       AND r.ip IS NOT NULL
     GROUP BY r.ip
     ORDER BY max(r.at) DESC
     LIMIT {MAX_IPS}
$fn$;
COMMENT ON FUNCTION app.api_client_recent_ips(uuid, uuid, integer) IS
    'The last addresses one machine client of the session''s org called from '
    '(Phase 12 T12 gaps). At most {MAX_IPS}, over at most {MAX_DAYS} days.';

REVOKE ALL ON FUNCTION app.api_client_usage(uuid, uuid, integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION app.api_client_recent_ips(uuid, uuid, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.api_client_usage(uuid, uuid, integer) TO {APP_ROLE};
GRANT EXECUTE ON FUNCTION app.api_client_recent_ips(uuid, uuid, integer) TO {APP_ROLE};

-- Hand both functions to the reader role, as 0013 does for the lookup role.
-- INHERIT FALSE (as 0011 and 0013): an inheriting member would pick up this
-- role's privileges and policies in the migrator's own sessions.
GRANT {USAGE_ROLE} TO CURRENT_USER WITH INHERIT FALSE, SET TRUE;
GRANT USAGE, CREATE ON SCHEMA app TO {USAGE_ROLE};
ALTER FUNCTION app.api_client_usage(uuid, uuid, integer) OWNER TO {USAGE_ROLE};
ALTER FUNCTION app.api_client_recent_ips(uuid, uuid, integer) OWNER TO {USAGE_ROLE};
REVOKE CREATE ON SCHEMA app FROM {USAGE_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(COLUMNS)
    op.execute(CREATE_USAGE_ROLE)
    op.execute(USAGE_FUNCTIONS)


def downgrade() -> None:
    # Dropping a function takes its owner's privileges; the migrator's
    # membership does not inherit them (INHERIT FALSE), so SET ROLE for the drop.
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{USAGE_ROLE}') THEN
                EXECUTE 'SET ROLE {USAGE_ROLE}';
                DROP FUNCTION IF EXISTS app.api_client_recent_ips(uuid, uuid, integer);
                DROP FUNCTION IF EXISTS app.api_client_usage(uuid, uuid, integer);
                RESET ROLE;
            ELSE
                DROP FUNCTION IF EXISTS app.api_client_recent_ips(uuid, uuid, integer);
                DROP FUNCTION IF EXISTS app.api_client_usage(uuid, uuid, integer);
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{USAGE_ROLE}') THEN
                REVOKE ALL ON audit.api_request FROM {USAGE_ROLE};
                REVOKE ALL ON SCHEMA audit FROM {USAGE_ROLE};
                REVOKE ALL ON SCHEMA app FROM {USAGE_ROLE};
                DROP ROLE {USAGE_ROLE};
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(
        """
        DROP INDEX IF EXISTS public.idx_partner_baas_org;
        ALTER TABLE public.partner_baas
            DROP COLUMN IF EXISTS revoked_reason,
            DROP COLUMN IF EXISTS revoked_by;
        ALTER TABLE public.api_clients DROP COLUMN IF EXISTS rotation_started_at;
        """
    )
