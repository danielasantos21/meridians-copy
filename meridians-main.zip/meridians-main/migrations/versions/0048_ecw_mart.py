"""ecw_mart — the container for the eCW data-mart copy in RDS: two roles, two
schemas, and the grants that keep every application role out of it.

Revision ID: 0048_ecw_mart
Revises: 0047_access_items
Create Date: 2026-10-18

ADR 0053 (eCW mart on RDS), owner decision of 2026-10-18 ("mart first, Cobalt
next"). RDS-only: Supabase never runs Alembic. This revision creates the
CONTAINER only. It copies no data; the nightly loader (scripts/sync_data_mart.py
--target rds) fills `mart` and applies the views into `analytics`.

WHAT IT ADDS
------------
* `meridian_mart_owner`  LOGIN, no powers. The loader logs in as it and owns
  both schemas, so every table, view and function the loader creates is its own.
* `meridian_mart_reader` LOGIN, no powers, read-only session. The api reads
  `analytics` as this role (src/mart_source.py). It has USAGE on `analytics`
  and SELECT / EXECUTE through default privileges, and NOTHING on `mart`: the
  analytics views are `security_invoker = false` and the analytics functions
  that read `mart` are SECURITY DEFINER, so owner-run objects reach `mart` for
  it. Nothing in `mart` is ever granted to anyone.
* schema `mart`      the patient-stripped copy of the mart tables the BI views
  read. No `org_id`, no RLS (ADR 0053, the ADR 0011 argument): it is a
  single-tenant staging copy dropped and rewritten by the loader and no
  application role can read it.
* schema `analytics` the views / snapshot tables / functions BI queries.

`meridian_app` and `phi_access` get nothing in either schema (explicit REVOKE,
even where it is a no-op today, so the no-grant property is written down and a
test holds it).

PASSWORDS
---------
Same contract as revision 0003: `MERIDIAN_MART_OWNER_DB_PASSWORD` and
`MERIDIAN_MART_READER_DB_PASSWORD` are read from the environment (Secrets
Manager, `meridian-<env>-secret-db-mart-owner` / `-reader`). Unset gives a
random password nobody holds and a warning on stderr; set means every re-run of
this step RE-PASSWORDS the role, so export both before ANY later
`alembic upgrade` that runs it. `create_or_update_role` and `_password` below
are a deliberate copy of 0003's (no revision imports another); a test asserts
the two copies are identical.

WHY THE MIGRATOR JOINS THE OWNER ROLE
-------------------------------------
On PostgreSQL 16+ a non-superuser (the RDS master user) can only
`CREATE SCHEMA ... AUTHORIZATION role` and `ALTER DEFAULT PRIVILEGES FOR ROLE
role` when it is a member of that role with SET. As in 0011 / 0013 the
membership is `INHERIT FALSE, SET TRUE`: it can become the owner (SET ROLE) but
does not pick up the owner's privileges in its own sessions. The membership is
kept because later revisions that touch these schemas need it.

DOWNGRADE
---------
Drops the default privileges and both schemas WITHOUT CASCADE, under SET ROLE
meridian_mart_owner. A populated schema makes the downgrade fail loudly:
production rollback is a snapshot restore (docs/runbooks/migrations.md), and
the mart is rebuildable from the source anyway. The two LOGIN roles are LEFT
in place: roles are cluster-wide, other databases on the same server (test
databases, RDS's own) may hold their grants, and their passwords live in
Secrets Manager. Re-upgrading re-passwords them.
"""

from __future__ import annotations

import os
import secrets
import sys

from alembic import op

revision = "0048_ecw_mart"
down_revision = "0047_access_items"
branch_labels = None
depends_on = None

OWNER_ROLE = "meridian_mart_owner"
READER_ROLE = "meridian_mart_reader"
APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"


def _password(env_var: str, role: str) -> str:
    value = os.environ.get(env_var)
    if value:
        return value
    print(
        f"warning: {env_var} is not set; creating {role} with a random password "
        "that nobody holds. Set it from Secrets Manager before the application "
        "tries to connect.",
        file=sys.stderr,
    )
    return secrets.token_urlsafe(32)


def create_or_update_role(conn, name: str, password: str, extra: str = "") -> None:
    """Create `name` (or reset its password) with PostgreSQL doing the quoting.

    `conn` is a SQLAlchemy connection (`op.get_bind()`), or anything with
    `exec_driver_sql`. Exposed by name so tests can drive it directly with
    hostile passwords.

    The `%%I` / `%%L` are doubled because psycopg2 is given parameters and
    therefore treats `%` in the query text as its own; the server sees `%I`
    and `%L`.
    """
    exists = conn.exec_driver_sql("SELECT 1 FROM pg_roles WHERE rolname = %s", (name,)).fetchone()
    if exists is None:
        template = (
            "CREATE ROLE %%I LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB "
            "NOCREATEROLE NOINHERIT " + extra + " PASSWORD %%L"
        )
    else:
        # ALTER carries no attributes. A CREATEROLE-but-not-superuser principal
        # -- which is what the RDS master user is -- may not issue
        # `ALTER ROLE ... NOSUPERUSER` or `... NOBYPASSRLS` even redundantly
        # ("Only roles with the SUPERUSER attribute may change the SUPERUSER
        # attribute"). So the attributes are asserted below instead of
        # re-asserted here: if a pre-existing role has them, that is a fact a
        # human has to deal with, not something this revision can quietly fix.
        template = "ALTER ROLE %%I WITH LOGIN PASSWORD %%L"
    statement = conn.exec_driver_sql(
        f"SELECT format('{template}', %s, %s)", (name, password)
    ).scalar()

    # Executed on the raw DBAPI cursor with NO parameters, so psycopg2 does no
    # `%`-formatting of it. `conn.exec_driver_sql(statement)` would hand the
    # driver an empty parameter mapping, and a password containing `%` (say
    # `100%sure`) would then be read as a format specifier. The statement is
    # already fully quoted by the server's `format(..., %L)`; nothing further
    # may touch it.
    cursor = getattr(conn, "connection", conn).cursor()
    try:
        cursor.execute(statement)
    finally:
        cursor.close()

    row = conn.exec_driver_sql(
        "SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = %s", (name,)
    ).fetchone()
    if row and (row[0] or row[1]):
        raise RuntimeError(
            f"role {name} already existed as SUPERUSER/BYPASSRLS. Revision 0004's "
            "row-level security would be decorative for it, and this revision "
            "cannot strip those attributes without a superuser. Fix the role by "
            "hand, then re-run."
        )


def _assert_powerless(conn, name: str) -> None:
    """The other attributes 0003's check does not look at.

    A pre-existing role with CREATEDB / CREATEROLE / REPLICATION would be able
    to read or reshape far more than its job, and (like SUPERUSER) cannot be
    stripped here by a non-superuser.
    """
    row = conn.exec_driver_sql(
        "SELECT rolcreatedb, rolcreaterole, rolreplication, rolcanlogin "
        "FROM pg_roles WHERE rolname = %s",
        (name,),
    ).fetchone()
    if row is None or row[0] or row[1] or row[2] or not row[3]:
        raise RuntimeError(
            f"role {name} must be LOGIN with NOCREATEDB, NOCREATEROLE and "
            "NOREPLICATION. It already existed with other attributes; fix the "
            "role by hand, then re-run."
        )


OFFLINE_ROLE_PLACEHOLDER = f"""
-- Offline (--sql) mode: roles are NOT created here, because a generated script
-- with a password in it is a leak. Create them with the real credentials first
-- (LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOINHERIT):
--   {OWNER_ROLE}, {READER_ROLE}
"""

#: Cluster-wide membership so the migrator may create objects owned by the
#: owner role (see the docstring: INHERIT FALSE, SET TRUE, like 0011 / 0013).
MEMBERSHIP = f"GRANT {OWNER_ROLE} TO CURRENT_USER WITH INHERIT FALSE, SET TRUE"

#: The schemas belong to the owner role, so everything that needs the owner's
#: privileges (REVOKE / GRANT / COMMENT on its schemas) runs under SET ROLE;
#: the migrator's membership does not inherit them. RESET ROLE ends the block.
SCHEMAS_AND_GRANTS = f"""
CREATE SCHEMA IF NOT EXISTS mart      AUTHORIZATION {OWNER_ROLE};
CREATE SCHEMA IF NOT EXISTS analytics AUTHORIZATION {OWNER_ROLE};
SET ROLE {OWNER_ROLE};

-- Explicit even where it is a no-op today (the 0044 / 0045 pattern).
REVOKE ALL ON SCHEMA mart      FROM PUBLIC;
REVOKE ALL ON SCHEMA analytics FROM PUBLIC;
REVOKE ALL ON SCHEMA mart, analytics FROM {APP_ROLE}, {PHI_ROLE};

-- The reader sees `analytics` only. NOTHING is granted on `mart` to anyone.
GRANT USAGE ON SCHEMA analytics TO {READER_ROLE};

-- The loader drops and recreates its objects every night; default privileges
-- are what keep the reader's access alive across that cycle.
ALTER DEFAULT PRIVILEGES FOR ROLE {OWNER_ROLE} IN SCHEMA analytics
    GRANT SELECT ON TABLES TO {READER_ROLE};
ALTER DEFAULT PRIVILEGES FOR ROLE {OWNER_ROLE} IN SCHEMA analytics
    GRANT EXECUTE ON FUNCTIONS TO {READER_ROLE};

COMMENT ON SCHEMA mart IS
    'ADR 0053: patient-stripped copy of the eCW data mart. Single tenant, no org_id, '
    'no RLS, readable by no application role. Owned and rewritten by the nightly loader.';
COMMENT ON SCHEMA analytics IS
    'ADR 0053: views, snapshot tables and functions over mart that BI reads, as '
    'meridian_mart_reader only. Owner-run (security definer / invoker=false).';
RESET ROLE;
"""  # noqa: S608 DDL from module constants; no runtime input

#: Backstops; BI still sets its own SET LOCAL limits per query.
READER_SETTINGS = f"""
ALTER ROLE {READER_ROLE} SET default_transaction_read_only = on;
ALTER ROLE {READER_ROLE} SET statement_timeout = '60s';
"""


def upgrade() -> None:
    if op.get_context().as_sql:
        op.execute(OFFLINE_ROLE_PLACEHOLDER)
    else:
        conn = op.get_bind()
        create_or_update_role(
            conn, OWNER_ROLE, _password("MERIDIAN_MART_OWNER_DB_PASSWORD", OWNER_ROLE)
        )
        create_or_update_role(
            conn, READER_ROLE, _password("MERIDIAN_MART_READER_DB_PASSWORD", READER_ROLE)
        )
        _assert_powerless(conn, OWNER_ROLE)
        _assert_powerless(conn, READER_ROLE)
    op.execute(MEMBERSHIP)
    op.execute(SCHEMAS_AND_GRANTS)
    op.execute(READER_SETTINGS)


def downgrade() -> None:
    # The membership does not inherit the owner's privileges, so SET ROLE for
    # the drops. No CASCADE: a populated schema must stop the downgrade.
    # The LOGIN roles stay (cluster-wide; see the docstring).
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{OWNER_ROLE}') THEN
                EXECUTE 'SET ROLE {OWNER_ROLE}';
                ALTER DEFAULT PRIVILEGES FOR ROLE {OWNER_ROLE} IN SCHEMA analytics
                    REVOKE EXECUTE ON FUNCTIONS FROM {READER_ROLE};
                ALTER DEFAULT PRIVILEGES FOR ROLE {OWNER_ROLE} IN SCHEMA analytics
                    REVOKE SELECT ON TABLES FROM {READER_ROLE};
                REVOKE USAGE ON SCHEMA analytics FROM {READER_ROLE};
                DROP SCHEMA IF EXISTS analytics;
                DROP SCHEMA IF EXISTS mart;
                RESET ROLE;
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
