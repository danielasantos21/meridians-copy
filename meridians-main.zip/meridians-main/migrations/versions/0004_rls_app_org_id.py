"""rls_app_org_id — FORCE row-level security on every tenant table.

Revision ID: 0004_rls_app_org_id
Revises: 0003_rds_adaptations
Create Date: 2026-09-15

Layer (b) of ADR 0011. Layer (a) is the explicit `org_id = %s` predicate in
every statement, enforced by `scripts/lint_org_scope.py`. This revision is the
backstop underneath it: if a predicate is ever forgotten, the database returns
no rows instead of another tenant's rows.

WHAT IT DOES
------------
For every table listed in `scripts/tenant_tables.txt` (read at runtime — the
file is generated from the schema by `scripts/gen_tenant_tables.py`, so adding
an org-scoped table without listing it fails CI). The list is
**schema-qualified** (`public.transactions`, `phi.transaction_identity`),
because `phi` is where the patient identifiers are and leaving it out of this
revision was the largest hole in the first draft: `phi.transaction_identity`
has an `org_id` and had no RLS at all.

* `ENABLE ROW LEVEL SECURITY` **and `FORCE ROW LEVEL SECURITY`**. `ENABLE`
  alone exempts the table's owner; `FORCE` does not. The application connects
  as `meridian_app`, which is neither the owner nor `BYPASSRLS`, but `FORCE`
  means even a mistake in that arrangement still cannot leak.
* Every inherited Supabase-era policy is dropped and replaced by one pair:

      USING      (org_id = app.current_org_id())
      WITH CHECK (org_id = app.current_org_id())

  The old policies called `public.user_org_id()`, which revision 0003 already
  repointed at the same setting, so this is a simplification rather than a
  change of meaning — except for the 23 tables whose policy had `USING` and no
  `WITH CHECK` (inventory §7), which could be *written* with another org's
  `org_id`. They get one here.

* `role_permissions` has no `org_id` of its own; its policy joins through
  `roles`, which is where the org lives. This is the hole ADR 0011 describes as
  a live cross-org permission escalation.

WHY `app.current_org_id()` AND NOT A `NULLIF` INLINE
---------------------------------------------------
`current_setting('app.org_id', true)` returns `''` after a `RESET`, and
`''::uuid` raises `22P02 invalid input syntax`. An error is not a safe default:
the test that matters ("`app.org_id` unset, `SELECT * FROM transactions`
returns zero rows") would instead blow up, and an application that catches the
error might carry on.

`NULLIF(..., '')::uuid` fixes the *empty* case and nothing else. `SET app.org_id
= 'not-a-uuid'` — which is what an unvalidated request parameter reaching the
pool looks like — still raises 22P02 from inside every policy. Pool-side UUID
validation is Phase 5a; the predicate has to be robust before then, so revision
0003 defines `app.current_org_id()`: `STABLE`, and NULL unless the setting
matches the UUID shape. `org_id = NULL` is NULL, NULL is not true, the row is
not visible. Fail closed, quietly, for *every* bad value.

WHAT ABOUT THE TABLES WITH NO `org_id`?
---------------------------------------
`organizations` and `superadmins` are not tenant tables — one *is* the tenant,
the other is cross-org by definition — so they are not in
`scripts/tenant_tables.txt` and the loop above does not touch them. They still
carried their Supabase-era policies, which call `auth.uid()`. After Phase 4
identity lives in Cognito, `auth.uid()` is a stub over `app.user_id`, and those
policies resolved through `org_members` against a user id nothing was setting:
`meridian_app` could not read *its own organization row* or the superadmin list.
They are replaced here with RDS-era policies (see `IDENTITY_TABLES` below).

Both keep `ENABLE ROW LEVEL SECURITY` **without** `FORCE`, deliberately and
unlike every tenant table. Creating an organization and granting a superadmin
are owner/bypass operations — there is no `app.org_id` that could authorise
creating the org that `app.org_id` would name. `FORCE` here would mean no
principal at all could insert an organization, including the migration role and
the load script. `meridian_app` is not the owner, so it is still subject to the
policies, which is the property that matters.

THE SUPERADMIN BYPASS IS NOT HERE
---------------------------------
There is deliberately no `app.assume_org(uuid)` SQL function and no
`is_superadmin` predicate in any policy. Per ADR 0011 the bypass is exactly one
named Python function that writes an `audit.phi_access`-style audit row and
then sets `app.org_id` for the scope of that operation. Putting it in SQL would
make it ambient — anything holding a connection could call it, and nothing
would record that it did.

HOW `app.org_id` IS SET
-----------------------
Session level, on connection checkout (`SET app.org_id = %s`), and
`RESET app.org_id` unconditionally on return to the pool. Not `SET LOCAL`: the
repository layer is autocommit by default and `SET LOCAL` only survives inside
a transaction, so it would silently do nothing. A test asserts the setting is
empty after checkout.

DOWNGRADE
---------
Supported, and it is the one revision where that is meaningful: it drops the
policies and disables RLS, which is how you would isolate a performance problem
on `transactions`. It leaves the tables and their data untouched.
"""

from __future__ import annotations

import pathlib

from alembic import op

revision = "0004_rls_app_org_id"
down_revision = "0003_rds_adaptations"
branch_labels = None
depends_on = None

TENANT_TABLES_FILE = pathlib.Path(__file__).resolve().parents[2] / "scripts" / "tenant_tables.txt"

POLICY = "meridian_org_isolation"

#: The org_id expression for the ordinary, directly-scoped case.
_ORG = "(org_id = app.current_org_id())"

#: Tables that inherit their org through a join rather than an org_id column.
#: Must match JOIN_SCOPED in scripts/gen_tenant_tables.py.
JOIN_SCOPED: dict[str, str] = {
    "public.role_permissions": (
        "(EXISTS (SELECT 1 FROM public.roles r "
        " WHERE r.id = role_permissions.role_id "
        "   AND r.org_id = app.current_org_id()))"
    ),
}

#: The two public tables that have no `org_id` and are therefore NOT in
#: tenant_tables.txt, but do carry inherited `auth.uid()` policies that have to
#: go. `(policy name, FOR clause, USING, WITH CHECK or None)`.
#:
#: There is deliberately no INSERT and no DELETE policy on either. With RLS
#: enabled and no policy for a command, that command is denied -- creating an
#: organization and granting a superadmin go through the one audited bypass
#: (ADR 0011), as the owner, not through `meridian_app`.
_ORG_SELF = "(id = app.current_org_id())"
_USER_SELF = "(user_id = app.current_user_id())"

IDENTITY_TABLES: dict[str, list[tuple[str, str, str, str | None]]] = {
    "public.organizations": [
        ("meridian_org_self_select", "SELECT", _ORG_SELF, None),
        ("meridian_org_self_update", "UPDATE", _ORG_SELF, _ORG_SELF),
    ],
    "public.superadmins": [
        ("meridian_superadmin_self_select", "SELECT", _USER_SELF, None),
    ],
}


def read_tenant_tables() -> list[str]:
    """The schema-qualified tenant tables, in file order."""
    if not TENANT_TABLES_FILE.exists():
        raise RuntimeError(
            f"{TENANT_TABLES_FILE} is missing. Generate it with "
            "scripts/gen_tenant_tables.py before running this revision."
        )
    names = []
    for line in TENANT_TABLES_FILE.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            if "." not in line:
                raise RuntimeError(
                    f"{TENANT_TABLES_FILE} entry {line!r} is not schema-qualified; "
                    "regenerate it with scripts/gen_tenant_tables.py"
                )
            names.append(line)
    if not names:
        raise RuntimeError(f"{TENANT_TABLES_FILE} lists no tables")
    return names


def _exists(conn, schema: str, table: str) -> bool:
    """Does this table exist *yet*?

    `tenant_tables.txt` is a LIVE file, not a snapshot: it lists every
    org-scoped table at HEAD, and a revision after this one may add another
    (0007 adds `public.invoice_counters`). This revision then reads a name for
    a table that does not exist when it runs, and `ALTER TABLE` fails with
    `relation ... does not exist` — a migration chain that breaks itself from
    empty, in a file nobody edited.

    A revision that creates a tenant table after 0004 carries its own
    `FORCE ROW LEVEL SECURITY` and its own policy, which is where that
    statement belongs anyway. So a name this revision cannot see yet is skipped
    rather than being an error, and `tests/test_migrations.py` still checks
    the end state of every listed table at head.
    """
    row = conn.exec_driver_sql(
        "SELECT to_regclass(%s) IS NOT NULL", (f"{schema}.{table}",)
    ).fetchone()
    return bool(row[0])


def _drop_existing_policies(conn, schema: str, table: str) -> None:
    rows = conn.exec_driver_sql(
        "SELECT policyname FROM pg_policies WHERE schemaname = %s AND tablename = %s",
        (schema, table),
    ).fetchall()
    for (name,) in rows:
        op.execute(f'DROP POLICY IF EXISTS "{name}" ON {schema}.{table}')


def upgrade() -> None:
    if op.get_context().as_sql:
        raise RuntimeError(
            "0004 cannot run in offline mode (`alembic upgrade --sql`). It reads "
            "pg_policies to find the inherited Supabase policies it has to drop, "
            "and their names are not knowable from the repository. Generate the "
            "script up to 0003 and apply 0004 with a live connection. See "
            "docs/runbooks/migrations.md."
        )

    conn = op.get_bind()

    for qualified in read_tenant_tables():
        schema, table = qualified.split(".", 1)
        if not _exists(conn, schema, table):
            continue  # a later revision creates it, with its own policy
        # Every inherited policy goes, whatever it was called.
        _drop_existing_policies(conn, schema, table)

        op.execute(f"ALTER TABLE {schema}.{table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {schema}.{table} FORCE ROW LEVEL SECURITY")

        predicate = JOIN_SCOPED.get(qualified, _ORG)
        op.execute(
            f"CREATE POLICY {POLICY} ON {schema}.{table} USING {predicate} WITH CHECK {predicate}"
        )

    for qualified, policies in IDENTITY_TABLES.items():
        schema, table = qualified.split(".", 1)
        _drop_existing_policies(conn, schema, table)
        # ENABLE without FORCE -- see the docstring.
        op.execute(f"ALTER TABLE {schema}.{table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {schema}.{table} NO FORCE ROW LEVEL SECURITY")
        for name, command, using, with_check in policies:
            check = f" WITH CHECK {with_check}" if with_check else ""
            op.execute(
                f"CREATE POLICY {name} ON {schema}.{table} FOR {command} USING {using}{check}"
            )


def downgrade() -> None:
    conn = op.get_bind()
    for qualified in read_tenant_tables():
        schema, table = qualified.split(".", 1)
        if not _exists(conn, schema, table):
            continue  # same reason as upgrade(): it belongs to a later revision
        op.execute(f"DROP POLICY IF EXISTS {POLICY} ON {schema}.{table}")
        op.execute(f"ALTER TABLE {schema}.{table} NO FORCE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {schema}.{table} DISABLE ROW LEVEL SECURITY")
    for qualified, policies in IDENTITY_TABLES.items():
        schema, table = qualified.split(".", 1)
        for name, _command, _using, _check in policies:
            op.execute(f"DROP POLICY IF EXISTS {name} ON {schema}.{table}")
        op.execute(f"ALTER TABLE {schema}.{table} DISABLE ROW LEVEL SECURITY")
