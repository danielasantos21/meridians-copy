"""job_idempotency — the ledger that stops a redelivered job posting twice, and
the QuickBooks request id on the tie-out row.

Revision ID: 0012_job_idempotency
Revises: 0011_process_runs_worker
Create Date: 2026-09-24

Phase 11 task E1 (`docs/reports/phase-11-plan.md` §3.7; Codex PS-11; contract
§12.9). ADR 0011 (tenant isolation), ADR 0032 (idempotency table and the QBO
posting algorithm). RDS-only: Supabase never runs Alembic.

WHY
---
The queue delivers at least once (plan §3.5), so any job can run twice. For
most of a run that is harmless — outputs go to deterministic keys. For a
QuickBooks journal it is not: a second `create_journal_entry` books the payroll
twice. The rule (prompt, PROCESS FRAMEWORK) is "persist an idempotency record
BEFORE the QBO call". `src/idempotency.py` is the only writer:

1. `begin` inserts `(org, scope, key)` as `pending` — or finds it;
2. the caller does the remote work only if `begin` says so;
3. `complete`/`settle` records the outcome and the remote ids.

A `pending` row found on a replay means "a previous attempt may or may not have
reached QuickBooks": the caller re-queries by DocNumber before sending again,
with the SAME `requestid` (plan §3.7, step 3).

The create step already has its own key (`process_runs.idempotency_key`, 022 /
0008) and is NOT duplicated here. This table covers `run.execute` and
`qbo.journal` only (the CHECK).

THE TABLE
---------
`public.job_idempotency`, a tenant table like any other: `FORCE ROW LEVEL
SECURITY` with the same `meridian_org_isolation` policy 0004 gives every other
one, listed in `scripts/tenant_tables.txt` (MIGRATION_ADDED). Differences from
the plan's sketch:

* **No DELETE for `meridian_app`.** The default privileges (0003) grant it; this
  revision revokes it. A row is the evidence that a post happened; nothing in
  the application erases evidence.
* **The run reference is tenant-consistent.** `(run_id, org_id)` references
  `process_runs (run_id, org_id)` (0008's unique key), so a row can never point
  at another organization's run; `ON DELETE SET NULL (run_id)` keeps the row
  (and its `org_id`) when a run is deleted.
* CHECKs on the shapes: a 64-hex fingerprint, a bounded key, a `remote_result`
  that is a JSON object (ids only — `src/idempotency.py` enforces which).

ALSO: `qb_export_tie_out.qbo_request_id`
----------------------------------------
Tracker row "persist the QuickBooks RequestId": the column beside `qbo_je_id`,
at most 50 characters (Intuit's limit). Nothing writes it yet; the `qbo_push`
job (task E2) does.

DOWNGRADE
---------
Drops the table and the column. Rows are lost — which, for a ledger whose whole
job is to remember what was posted, is exactly why nobody downgrades past this
revision while a QuickBooks push is in flight.
"""

from __future__ import annotations

from alembic import op

revision = "0012_job_idempotency"
down_revision = "0011_process_runs_worker"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
TABLE = "public.job_idempotency"
POLICY = "meridian_org_isolation"
_ORG = "(org_id = app.current_org_id())"

#: The scopes this ledger covers. `src/idempotency.SCOPES` must equal it.
SCOPES = ("run.execute", "qbo.journal")
_SCOPE_LIST = ", ".join(f"'{s}'" for s in SCOPES)

CREATE = f"""
CREATE TABLE {TABLE} (
    org_id              uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    scope               text        NOT NULL CHECK (scope IN ({_SCOPE_LIST})),
    idempotency_key     text        NOT NULL CHECK (char_length(idempotency_key) BETWEEN 1 AND 200),
    run_id              uuid,
    request_fingerprint text        NOT NULL CHECK (request_fingerprint ~ '^[0-9a-f]{{64}}$'),
    qbo_request_id      text        CHECK (char_length(qbo_request_id) BETWEEN 1 AND 50),
    state               text        NOT NULL CHECK (state IN ('pending', 'completed', 'failed')),
    remote_result       jsonb       CHECK (remote_result IS NULL
                                           OR jsonb_typeof(remote_result) = 'object'),
    attempts            integer     NOT NULL DEFAULT 1 CHECK (attempts >= 1),
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (org_id, scope, idempotency_key),
    CONSTRAINT job_idempotency_run_fkey FOREIGN KEY (run_id, org_id)
        REFERENCES public.process_runs (run_id, org_id) ON DELETE SET NULL (run_id)
);
COMMENT ON TABLE {TABLE} IS
    'Phase 11 E1 / ADR 0032: one row per idempotent remote operation, written BEFORE the '
    'call. Ids only, never PHI. meridian_app may not DELETE.';
COMMENT ON COLUMN {TABLE}.remote_result IS
    'The remote ids ({{qbo_txn_id, doc_number}}). Never a request or response body.';
CREATE INDEX ix_job_idem_run     ON {TABLE} (org_id, run_id);
CREATE INDEX ix_job_idem_pending ON {TABLE} (updated_at) WHERE state = 'pending';
ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY;
ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;
CREATE POLICY {POLICY} ON {TABLE} USING {_ORG} WITH CHECK {_ORG};
REVOKE ALL ON {TABLE} FROM {APP_ROLE};
GRANT SELECT, INSERT, UPDATE ON {TABLE} TO {APP_ROLE};

ALTER TABLE public.qb_export_tie_out
    ADD COLUMN qbo_request_id text
        CONSTRAINT qb_export_tie_out_qbo_request_id_check
        CHECK (char_length(qbo_request_id) BETWEEN 1 AND 50);
COMMENT ON COLUMN public.qb_export_tie_out.qbo_request_id IS
    'The Intuit requestid the journal was posted with (src/qbo_client.journal_request_id).';
"""


def upgrade() -> None:
    op.execute(CREATE)


def downgrade() -> None:
    op.execute("ALTER TABLE public.qb_export_tie_out DROP COLUMN IF EXISTS qbo_request_id")
    op.execute(f"DROP TABLE IF EXISTS {TABLE}")
