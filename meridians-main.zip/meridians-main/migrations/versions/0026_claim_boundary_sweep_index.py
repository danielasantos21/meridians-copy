"""claim_boundary_and_sweeper_index — a lease that expires NOW is claimable; the
sweeper's abandoned-wizard pass has an index its loop can use; 0011's false
column comment corrected.

Revision ID: 0026_claim_boundary_sweep_index
Revises: 0025_webhook_delivery_sweep
Create Date: 2026-09-25

Stage 1 critic round 1 (`docs/reports/critic-stage1-r1.md`), three lows. RDS
only: Supabase never runs Alembic.

1. L-12 · `<` BECOMES `<=` IN BOTH CLAIMS
----------------------------------------
`process_runs.begin_action` queues a job by setting `lease_expires_at = now()`
(the queued-job marker), and `app.claim_run` (0011) / `app.claim_post_completion`
(0018) took a run only when `lease_expires_at < now()`. A claim whose
transaction started in the same microsecond as the marker's saw `busy` and the
job waited out the 900 s visibility timeout. A lease that expires exactly now
has expired: `<=`. Nothing else in either body changes (same signature, owner,
grants, `search_path`, comment). Replaced the way 0020/0024 replace a control-
role function: `CREATE OR REPLACE` under `SET ROLE meridian_job_control`, with a
transient CREATE on schema `app`, revoked at once. The migrator gains no
inheriting membership.

2. L-8 · `idx_process_runs_state_expiry (state, expires_at)`
------------------------------------------------------------
`app.expire_stale_runs` (0020) expires abandoned wizards with
`WHERE pr.state = v_state AND pr.expires_at < now()` inside a
`FOREACH v_state` loop. The baseline's partial `idx_process_runs_expiry`
(`WHERE state IN ('draft','parsing','needs_input','ready')`) serves the literal
form (the dry run) but not that one: once PL/pgSQL switches the statement to a
generic plan, `state = $1` cannot prove the partial predicate, and the sweep
reads the whole table every tick. A plain `(state, expires_at)` index serves
the parameterised form (`tests/test_claim_boundary_sweep_index_pg.py` shows the
generic plan using it).

3. L-7 · the `lease_owner` column comment
-----------------------------------------
0011 wrote "Set only by app.claim_run." It is also set by
`app.claim_post_completion` (0018) and cleared by the worker's release/settle
(`workers/run_job.py`), by the sweeper, and by the api when it moves a run to
`failed`/`expired` (critic L-13). The comment now says so.

DOWNGRADE
---------
Supported: both functions back to `<`, the index dropped, 0011's comment back.
"""

from __future__ import annotations

from alembic import op

revision = "0026_claim_boundary_sweep_index"
down_revision = "0025_webhook_delivery_sweep"
branch_labels = None
depends_on = None

CONTROL_ROLE = "meridian_job_control"

#: 0011's and 0018's values, repeated because a migration never imports another.
MAX_LEASE_SECONDS = 43_200
POST_COMPLETION = (("qbo_push", "completed"),)

CLAIM_RUN_SIGNATURE = "app.claim_run(uuid, uuid, text, integer, text)"
CLAIM_POST_SIGNATURE = "app.claim_post_completion(uuid, uuid, text, integer, text, text)"
INDEX = "idx_process_runs_state_expiry"

_KINDS = ", ".join(f"'{kind}'" for kind, _state in POST_COMPLETION)
_PAIRS = ", ".join(f"('{kind}', '{state}')" for kind, state in POST_COMPLETION)


def claim_run(op_: str) -> str:
    """0011's `app.claim_run`, with `op_` as the lease-expiry comparison."""
    return f"""
CREATE OR REPLACE FUNCTION app.claim_run(
    p_run_id        uuid,
    p_org_id        uuid,
    p_owner         text,
    p_lease_seconds integer,
    p_job_id        text
)
RETURNS TABLE (claimed_attempts integer, claimed_until timestamptz)
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF p_owner IS NULL OR char_length(p_owner) NOT BETWEEN 1 AND 200 THEN
        RAISE EXCEPTION 'claim_run: owner must be 1-200 characters'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_lease_seconds IS NULL OR p_lease_seconds NOT BETWEEN 1 AND {MAX_LEASE_SECONDS} THEN
        RAISE EXCEPTION 'claim_run: lease must be 1-{MAX_LEASE_SECONDS} seconds'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_job_id IS NULL OR char_length(p_job_id) NOT BETWEEN 1 AND 64 THEN
        RAISE EXCEPTION 'claim_run: job id must be 1-64 characters'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;

    -- One statement: the row lock makes two claimers race to exactly one
    -- winner; the loser re-checks the WHERE against the winner's lease and
    -- gets no row.
    RETURN QUERY
    UPDATE public.process_runs pr
       SET lease_owner      = p_owner,
           lease_expires_at = now() + make_interval(secs => p_lease_seconds),
           attempts         = CASE WHEN pr.last_job_id = p_job_id
                                   THEN pr.attempts + 1 ELSE 1 END,
           last_job_id      = p_job_id,
           updated_at       = now()
     WHERE pr.run_id = p_run_id
       AND pr.org_id = p_org_id
       AND pr.state NOT IN ('completed', 'failed', 'expired', 'superseded')
       AND (pr.lease_expires_at IS NULL OR pr.lease_expires_at {op_} now())
    RETURNING pr.attempts, pr.lease_expires_at;
END
$fn$;
"""  # noqa: S608 DDL from module constants; no runtime input


def claim_post_completion(op_: str) -> str:
    """0018's `app.claim_post_completion`, with `op_` as the lease-expiry comparison."""
    return f"""
CREATE OR REPLACE FUNCTION app.claim_post_completion(
    p_run_id        uuid,
    p_org_id        uuid,
    p_owner         text,
    p_lease_seconds integer,
    p_job_id        text,
    p_job_kind      text
)
RETURNS TABLE (claimed_attempts integer, claimed_until timestamptz)
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF p_owner IS NULL OR char_length(p_owner) NOT BETWEEN 1 AND 200 THEN
        RAISE EXCEPTION 'claim_post_completion: owner must be 1-200 characters'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_lease_seconds IS NULL OR p_lease_seconds NOT BETWEEN 1 AND {MAX_LEASE_SECONDS} THEN
        RAISE EXCEPTION 'claim_post_completion: lease must be 1-{MAX_LEASE_SECONDS} seconds'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_job_id IS NULL OR char_length(p_job_id) NOT BETWEEN 1 AND 64 THEN
        RAISE EXCEPTION 'claim_post_completion: job id must be 1-64 characters'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_job_kind IS NULL OR NOT (p_job_kind = ANY (ARRAY[{_KINDS}])) THEN
        -- Only an allowlisted kind may lease a finished run. Anything else is
        -- a programming error, never a quiet "not yours".
        RAISE EXCEPTION 'claim_post_completion: this job kind may not start from a finished run'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;

    -- claim_run's single statement, with the state test inverted to the
    -- allowlisted terminal state for this kind. The row lock gives two
    -- claimers exactly one winner.
    RETURN QUERY
    UPDATE public.process_runs pr
       SET lease_owner      = p_owner,
           lease_expires_at = now() + make_interval(secs => p_lease_seconds),
           attempts         = CASE WHEN pr.last_job_id = p_job_id
                                   THEN pr.attempts + 1 ELSE 1 END,
           last_job_id      = p_job_id,
           updated_at       = now()
     WHERE pr.run_id = p_run_id
       AND pr.org_id = p_org_id
       AND (p_job_kind, pr.state) IN ({_PAIRS})
       AND (pr.lease_expires_at IS NULL OR pr.lease_expires_at {op_} now())
    RETURNING pr.attempts, pr.lease_expires_at;
END
$fn$;
"""  # noqa: S608 DDL from module constants; no runtime input


LEASE_OWNER_COMMENT = (
    "COMMENT ON COLUMN public.process_runs.lease_owner IS "
    "'The worker holding this run (Phase 11, ADR 0030). Set by app.claim_run and "
    "app.claim_post_completion; cleared by the worker''s release and settle, the sweeper, "
    "and the api when it moves the run to failed or expired.';"
)
PREVIOUS_LEASE_OWNER_COMMENT = (
    "COMMENT ON COLUMN public.process_runs.lease_owner IS "
    "'The worker holding this run (Phase 11, ADR 0030). Set only by app.claim_run.';"
)


def _as_owner(body: str) -> str:
    """`body` run as the functions' owner, with CREATE on `app` only meanwhile (0020's way)."""
    return f"""
GRANT CREATE ON SCHEMA app TO {CONTROL_ROLE};
SET ROLE {CONTROL_ROLE};
{body}
RESET ROLE;
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""


def upgrade() -> None:
    op.execute(_as_owner(claim_run("<=") + claim_post_completion("<=")))
    op.execute(f"CREATE INDEX {INDEX} ON public.process_runs (state, expires_at)")
    op.execute(LEASE_OWNER_COMMENT)


def downgrade() -> None:
    op.execute(PREVIOUS_LEASE_OWNER_COMMENT)
    op.execute(f"DROP INDEX IF EXISTS public.{INDEX}")
    op.execute(_as_owner(claim_run("<") + claim_post_completion("<")))
