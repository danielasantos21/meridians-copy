"""auth_state — the half-finished sign-in store, the invite-redemption audit, and
the org-admin read of members' profiles.

Revision ID: 0017_auth_state
Revises: 0016_api_client_admin_gaps
Create Date: 2026-09-24

Three pieces, all for the sign-in and membership path, all additive.

1. `public.auth_pending_challenge` (migration tracker T:83, phase-11-plan G3).
   A half-finished Cognito sign-in — the MFA challenge, the new-password
   challenge, the MFA-setup challenge — used to be parked in a module-level
   dict in `src/api/v2/auth_routes.py`. One process, one dict: a second api
   task stranded every MFA attempt that landed on the other one. This is the
   short-TTL row the tracker asked for instead of a cache (ADR 0010: no Redis).

   * The primary key is the SHA-256 of the handle the browser holds, never the
     handle itself: a reader of this table cannot redeem a row through the
     API, because the API wants the preimage.
   * `sealed` holds what the next step has to hand back to Cognito — its
     `Session`, the username, the challenge parameters, and during enrolment
     an access token — ENCRYPTED under a key derived from the handle
     (`src/api/v2/auth_routes._seal`). The handle is only ever in the
     browser, so a copy of this table (a snapshot, a restore, a read replica)
     holds ciphertext it has no key for, and an email address never sits here
     in the clear. Rows live for `CHALLENGE_TTL_SECONDS` (300 s).
   * Not a tenant table: nobody has an org before they have signed in, so
     there is no `org_id` and no RLS — the same shape as 0013's
     `public.api_quota_window`, which is also counted before an org is known.
     `meridian_app` gets the four DML verbs through 0003's default privileges;
     `phi_access` gets nothing.

   The FastAPI rate limiter (tracker T:98) needs no table of its own: it counts
   in 0013's `public.api_quota_window`, under an `rl:` bucket prefix.

2. `audit.invite_redeemed` (tracker T:86). One row per invite code spent,
   written in the same transaction as the membership it creates, so a member
   who joined by invite without an audit row cannot exist. Ids, a role and a
   timestamp — never the code. Append-only the 0013 way: INSERT for
   `meridian_app` and nothing else, plus `audit.refuse_change()` on UPDATE,
   DELETE and TRUNCATE for everybody, the owner included.

3. `meridian_profile_org_admin_select` on `public.user_profiles` (tracker
   T:114). Revision 0006 keys that table's SELECT policy on the READER — own
   row, or a superadmin — so on `meridian_app` the admin-only members screen
   showed every other member with a blank name. The tracker offered two
   fixes: this policy, or names from the identity provider. The identity
   provider has no names (neither the pre-provisioning script nor the
   migration Lambda sets `name`), so it is this policy, as narrow as the
   screen: a session scoped to an org (`app.org_id`) whose own user is an
   ADMIN of that org may read the profile rows of that org's members. SELECT
   only; nothing wider than the members screen already shows. Both
   `org_members` reads inside it are themselves under that table's org policy.

DOWNGRADE drops the policy and both tables.
"""

from __future__ import annotations

from alembic import op

revision = "0017_auth_state"
down_revision = "0016_api_client_admin_gaps"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
PENDING_TABLE = "public.auth_pending_challenge"
AUDIT_TABLE = "audit.invite_redeemed"

PENDING = f"""
CREATE TABLE {PENDING_TABLE} (
    handle_hash  text        PRIMARY KEY CHECK (length(handle_hash) = 64),
    sealed       bytea       NOT NULL CHECK (octet_length(sealed) <= 16384),
    attempts     integer     NOT NULL DEFAULT 0,
    created_at   timestamptz NOT NULL DEFAULT now(),
    expires_at   timestamptz NOT NULL
);
CREATE INDEX idx_auth_pending_challenge_expires ON {PENDING_TABLE} (expires_at);
COMMENT ON TABLE {PENDING_TABLE} IS
    'Half-finished Cognito sign-ins (tracker T:83). Keyed by sha256(handle); rows live '
    'for five minutes. Not a tenant table: no org exists before sign-in.';
REVOKE ALL ON {PENDING_TABLE} FROM {PHI_ROLE};
GRANT SELECT, INSERT, UPDATE, DELETE ON {PENDING_TABLE} TO {APP_ROLE};
"""

AUDIT = f"""
CREATE TABLE {AUDIT_TABLE} (
    id         bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at         timestamptz NOT NULL DEFAULT now(),
    org_id     uuid        NOT NULL,
    user_id    uuid        NOT NULL,
    invite_id  uuid        NOT NULL,
    role       text        NOT NULL CHECK (length(role) <= 32)
);
COMMENT ON TABLE {AUDIT_TABLE} IS
    'One row per invite code redeemed (tracker T:86), written in the transaction that '
    'creates the membership. Ids only -- never the code. Append-only.';
CREATE INDEX idx_invite_redeemed_org ON {AUDIT_TABLE} (org_id, at DESC);
REVOKE ALL ON {AUDIT_TABLE} FROM {APP_ROLE}, {PHI_ROLE};
GRANT INSERT ON {AUDIT_TABLE} TO {APP_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.invite_redeemed_id_seq TO {APP_ROLE};
CREATE TRIGGER invite_redeemed_append_only
    BEFORE UPDATE OR DELETE ON {AUDIT_TABLE}
    FOR EACH ROW EXECUTE FUNCTION audit.refuse_change();
CREATE TRIGGER invite_redeemed_no_truncate
    BEFORE TRUNCATE ON {AUDIT_TABLE}
    FOR EACH STATEMENT EXECUTE FUNCTION audit.refuse_change();
"""


PROFILE_POLICY = "meridian_profile_org_admin_select"

#: An org admin, in a session scoped to that org, reads that org's members'
#: profile rows. Both conditions name `app.current_org_id()`, so a session with
#: no org scope (`pg.with_user`) matches nothing here and 0006's own-row policy
#: is all it has.
CO_MEMBER_PROFILES = f"""
CREATE POLICY {PROFILE_POLICY} ON public.user_profiles
    FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.org_members m
             WHERE m.user_id = user_profiles.user_id
               AND m.org_id = app.current_org_id()
        )
        AND EXISTS (
            SELECT 1 FROM public.org_members me
             WHERE me.user_id = app.current_user_id()
               AND me.org_id = app.current_org_id()
               AND me.role = 'admin'
        )
    );
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(PENDING)
    op.execute(AUDIT)
    op.execute(CO_MEMBER_PROFILES)


def downgrade() -> None:
    op.execute(f"DROP POLICY IF EXISTS {PROFILE_POLICY} ON public.user_profiles")
    op.execute(f"DROP TABLE IF EXISTS {AUDIT_TABLE}")
    op.execute(f"DROP TABLE IF EXISTS {PENDING_TABLE}")
