"""user_profiles — the application's own store for what Supabase Auth kept in
`user_metadata`.

Revision ID: 0006_user_profiles
Revises: 0005_drop_txn_identifiers
Create Date: 2026-09-16

Phase 4 step 1 of `docs/aws-migration-plan.md`, ADR 0003 and ADR 0021.

WHY IT EXISTS
-------------
Four pieces of per-user state — display name, avatar URL, UI language and the
dashboard layout — live today in Supabase Auth's `raw_user_meta_data`. Cognito
has no equivalent that may be used for them: custom attributes are capped at
2,048 characters and 50 attributes and **cannot be deleted once created**, so a
dashboard layout in a custom attribute is a schema decision that can never be
taken back. The store moves into Postgres, where it belongs, and it moves
**before** the identity provider does, while `auth.users` is still readable.

The key is the *application's* user id — `custom:app_uid` for a migrated user,
the Cognito `sub` for a new one (ADR 0021). It is deliberately not a foreign key
to anything: `auth.users` is going away, and `org_members.user_id` is not unique
per user across orgs.

RLS: ENABLED, NOT FORCED — the same reasoning as `superadmins` in 0004
-----------------------------------------------------------------------
`user_profiles` is a **per-user** table, not a tenant table. It has no `org_id`,
so it is not in `scripts/tenant_tables.txt` and the 0004 loop does not touch it.
It is the third member of the family 0004 calls `IDENTITY_TABLES`
(`public.organizations`, `public.superadmins`), and it is treated identically:

* `ENABLE ROW LEVEL SECURITY` **without `FORCE`.** `FORCE` applies to the table
  owner, and the owner is the migration role — the one principal that has to be
  able to run the backfill below and, later, a data load. Forcing it would mean
  no principal at all could seed the table. `meridian_app` is not the owner, so
  it is still fully subject to the policies, which is the property that matters.
* The policies are keyed on `app.current_user_id()`, exactly as `superadmins` is,
  because the row is scoped by *who you are* and not by *which org you are in*.

Three policies, and what each is for:

| Command | Predicate | Why |
|---|---|---|
| SELECT | own row **OR** caller is a superadmin | A user reads their own preferences on every `GET /me`. A superadmin reads all of them because the superadmin screens list every user in the system. |
| INSERT | own row | The profile row is created lazily, on the first save, by the session that owns it. |
| UPDATE | own row (`USING` **and** `WITH CHECK`) | `WITH CHECK` is not optional: without it a session could move its own row to another `user_id`. That is the exact hole 0004 closed on 23 tenant tables. |

There is deliberately **no DELETE policy**. Deleting a profile is an
administrative act, and with RLS enabled and no policy for a command that
command is denied — the same fail-closed default `organizations` relies on.

The superadmin sub-select reads `public.superadmins`, which carries its own RLS
(`user_id = app.current_user_id()`, 0004). That is not a problem, it is the
point: the only `superadmins` row a session can see is its own, and its own row
is precisely the one that answers "am I a superadmin?".

THE BACKFILL RUNS ONLY WHERE `auth.users` EXISTS
------------------------------------------------
On RDS it does not: revision 0003 removed the Supabase `auth.users` shim, and
`tests/test_migrations.py::test_auth_users_shim_and_its_foreign_keys_are_gone`
holds it removed. On a replay of the Supabase dump — the one place the metadata
still is — it does. So the backfill is wrapped in a `DO $$` block that checks
`to_regclass('auth.users')` first.

A PL/pgSQL block is used rather than a Python `if`, and that is deliberate: the
body of a PL/pgSQL block is not parsed until the branch executes, so the
`INSERT ... FROM auth.users` is not a parse error on a database with no `auth`
schema, **and** the whole revision still works under `alembic upgrade --sql`
(unlike 0004 and 0005, which have to refuse offline mode). There is therefore no
`scripts/backfill_user_profiles.py` to run, remember, or forget.

`ON CONFLICT DO NOTHING` makes it re-runnable: a second replay never overwrites a
preference the user has changed since.

DOWNGRADE
---------
Supported: it drops the table. Say plainly what that costs — every preference
saved *after* the backfill is in this table and nowhere else, so a downgrade
after the application has been writing here loses those edits. Everything that
came from `auth.users` is still in `auth.users`, which this revision never
mutates.
"""

from __future__ import annotations

from alembic import op

revision = "0006_user_profiles"
down_revision = "0005_drop_txn_identifiers"
branch_labels = None
depends_on = None

TABLE = "public.user_profiles"

#: Same shape as 0004's `IDENTITY_TABLES` entries: (name, FOR, USING, WITH CHECK).
_SELF = "(user_id = app.current_user_id())"
_SUPERADMIN = (
    "(EXISTS (SELECT 1 FROM public.superadmins s WHERE s.user_id = app.current_user_id()))"
)

POLICIES: list[tuple[str, str, str | None, str | None]] = [
    ("meridian_profile_self_or_superadmin_select", "SELECT", f"({_SELF} OR {_SUPERADMIN})", None),
    ("meridian_profile_self_insert", "INSERT", None, _SELF),
    ("meridian_profile_self_update", "UPDATE", _SELF, _SELF),
]

CREATE_TABLE = f"""
CREATE TABLE IF NOT EXISTS {TABLE} (
    user_id                uuid        PRIMARY KEY,
    full_name              text,
    avatar_url             text,
    language               text        NOT NULL DEFAULT 'en',
    dashboard_preferences  jsonb       NOT NULL DEFAULT '{{}}'::jsonb,
    created_at             timestamptz NOT NULL DEFAULT now(),
    updated_at             timestamptz NOT NULL DEFAULT now()
)
"""

#: `raw_user_meta_data` is free-form, so every field is defended:
#: `full_name` falls back to `name` (both spellings are in the live data),
#: an empty string becomes NULL, and `dashboard_preferences` is only taken when
#: it really is a JSON object — a scalar or an array there would violate the
#: column's contract for the life of the row.
BACKFILL = f"""
DO $$
BEGIN
    IF to_regclass('auth.users') IS NOT NULL THEN
        INSERT INTO {TABLE} (user_id, full_name, avatar_url, language, dashboard_preferences)
        SELECT u.id,
               nullif(coalesce(u.raw_user_meta_data ->> 'full_name',
                               u.raw_user_meta_data ->> 'name'), ''),
               nullif(u.raw_user_meta_data ->> 'avatar_url', ''),
               coalesce(nullif(u.raw_user_meta_data ->> 'language', ''), 'en'),
               CASE
                   WHEN jsonb_typeof(u.raw_user_meta_data -> 'dashboard_preferences') = 'object'
                   THEN u.raw_user_meta_data -> 'dashboard_preferences'
                   ELSE '{{}}'::jsonb
               END
          FROM auth.users u
         WHERE u.id IS NOT NULL
        ON CONFLICT (user_id) DO NOTHING;
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(CREATE_TABLE)
    op.execute(BACKFILL)

    # ENABLE without FORCE -- see the docstring.
    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {TABLE} NO FORCE ROW LEVEL SECURITY")
    for name, command, using, with_check in POLICIES:
        clauses = ""
        if using:
            clauses += f" USING {using}"
        if with_check:
            clauses += f" WITH CHECK {with_check}"
        op.execute(f"CREATE POLICY {name} ON {TABLE} FOR {command}{clauses}")


def downgrade() -> None:
    for name, _command, _using, _check in POLICIES:
        op.execute(f"DROP POLICY IF EXISTS {name} ON {TABLE}")
    op.execute(f"DROP TABLE IF EXISTS {TABLE}")
