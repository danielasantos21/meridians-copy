"""bi_ask_log - what people asked Ask Meridian and what it built, for Meridian staff.

Revision ID: 0045_bi_ask_log
Revises: 0044_bi_ask_usage
Create Date: 2026-10-13

WHY
---
Meridian needs to see which questions Ask Meridian gets wrong or cannot build, so
the prompt and the catalog descriptions can be improved. The token table
(bi_ask_usage) deliberately holds no text, so this is a separate table.

WHAT IT ADDS
------------
`public.bi_ask_log`, one row per ask: who (user_id), when, the question text
AFTER REDACTION (emails, phone numbers, long digit runs, SSN-like numbers and
birth dates are replaced with "[removed]" before the insert; at most 1000
characters), the one-sentence note, the built query (the BiQuery JSON, null when
nothing was built), the model that answered, whether it worked, a short error
reason, and the estimated dollar cost. NO result rows are ever stored, and no
patient data from the clinic database.

WHO CAN DO WHAT
---------------
* The application role (meridian_app) may INSERT and SELECT, and only rows of its
  own organization (row-level security keyed on app.org_id). It cannot UPDATE or
  DELETE.
* Meridian superadmins are the only people who can read it, through the API
  (GET /api/v2/bi/ask/log, 404 for everyone else). That is enforced by the route,
  not the database.
* The organization link cascades: deleting an organization removes its log.

DOWNGRADE (read this first)
---------------------------
A downgrade drops the table and DESTROYS the whole ask log. Plain Postgres 17.
"""

from __future__ import annotations

from alembic import op

revision = "0045_bi_ask_log"
down_revision = "0044_bi_ask_usage"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
LOG = "public.bi_ask_log"

COMMENT = "redacted Ask Meridian questions and the queries built; read only by Meridian superadmins; no result rows"

CREATE_LOG = f"""
CREATE TABLE {LOG} (
    id         bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id     uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id    uuid        NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    question   text        NOT NULL CHECK (char_length(question) <= 1000),
    note       text        NOT NULL DEFAULT '',
    query      jsonb,
    model_id   text,
    ok         boolean     NOT NULL,
    error      text,
    cost_usd   numeric     NOT NULL DEFAULT 0 CHECK (cost_usd >= 0)
)
"""

_ORG_RULE = "org_id = current_setting('app.org_id', true)::uuid"

UPGRADE_SQL: list[str] = [
    CREATE_LOG,
    f"CREATE INDEX bi_ask_log_org_created ON {LOG} (org_id, created_at)",
    f"COMMENT ON TABLE {LOG} IS '{COMMENT}'",
    f"ALTER TABLE {LOG} ENABLE ROW LEVEL SECURITY",
    f"ALTER TABLE {LOG} FORCE ROW LEVEL SECURITY",
    f"CREATE POLICY meridian_asklog_insert ON {LOG} FOR INSERT WITH CHECK ({_ORG_RULE})",
    f"CREATE POLICY meridian_asklog_select ON {LOG} FOR SELECT USING ({_ORG_RULE})",
    f"REVOKE ALL ON {LOG} FROM {PHI_ROLE}",
    # On the AWS chain, 0003's default privileges give the app role full DML on new tables;
    # revoke them first so the app can only add and read rows (owner-approved 2026-10-16).
    f"REVOKE ALL ON {LOG} FROM {APP_ROLE}",
    f"GRANT INSERT, SELECT ON {LOG} TO {APP_ROLE}",
]

DOWNGRADE_SQL: list[str] = [
    f"DROP TABLE IF EXISTS {LOG}",
]


def upgrade() -> None:
    for statement in UPGRADE_SQL:
        op.execute(statement)


def downgrade() -> None:
    for statement in DOWNGRADE_SQL:
        op.execute(statement)
