"""api_request_export_writer — a role that may record the audit export's watermark.

Revision ID: 0028_api_request_export_writer
Revises: 0027_api_request_retention
Create Date: 2026-09-25

Critic Stage 1 round 2 L17: 0027 created `audit.api_request_export` (the
watermark `app.prune_api_request_audit` reads) and revoked it from both
application roles on purpose — but granted INSERT to NOBODY, so the Stage 3
export would have had no way to record a watermark and the prune would never
fire. This revision gives that grant a home without widening the app role.

WHAT IT ADDS
------------
* `meridian_audit_export` — NOLOGIN, NOBYPASSRLS, NOINHERIT, and nobody can
  use it yet (PostgreSQL records the migrator as its ADMIN, with neither
  INHERIT nor SET). The audit export's identity (Stage 3, tracker T:57 (c)):
  its login role is made a member THEN, in the same change that builds it.
* On it: `USAGE` on schema `audit`; `SELECT` on `audit.api_request` (the rows
  it ships to the Object-Locked bucket — `audit.api_request` has no RLS);
  `SELECT`, `INSERT` and `UPDATE (exported_through, recorded_at)` on
  `audit.api_request_export` (the singleton row). No DELETE, no TRUNCATE.

WHAT IT DOES NOT CHANGE
-----------------------
`meridian_app` and `phi_access` still cannot write the watermark (0027's
REVOKE stands): the application must not be able to declare rows exported and
so shorten retention. The prune and its trigger are 0027's, unchanged.

DOWNGRADE
---------
Supported: the grants revoked and the role dropped (it owns nothing, and
nobody uses it until Stage 3).
"""

from __future__ import annotations

from alembic import op

revision = "0028_api_request_export_writer"
down_revision = "0027_api_request_retention"
branch_labels = None
depends_on = None

EXPORT_ROLE = "meridian_audit_export"
TABLE = "audit.api_request"
EXPORT_TABLE = "audit.api_request_export"

#: `CREATE ROLE` is cluster-wide and has no IF NOT EXISTS (same as 0011, 0013).
CREATE_ROLE = f"""
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{EXPORT_ROLE}') THEN
        CREATE ROLE {EXPORT_ROLE} NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB
            NOCREATEROLE NOINHERIT;
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input

GRANTS = f"""
GRANT USAGE ON SCHEMA audit TO {EXPORT_ROLE};
GRANT SELECT ON {TABLE} TO {EXPORT_ROLE};
GRANT SELECT, INSERT ON {EXPORT_TABLE} TO {EXPORT_ROLE};
GRANT UPDATE (exported_through, recorded_at) ON {EXPORT_TABLE} TO {EXPORT_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(CREATE_ROLE)
    op.execute(GRANTS)


def downgrade() -> None:
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{EXPORT_ROLE}') THEN
                REVOKE ALL ON {EXPORT_TABLE} FROM {EXPORT_ROLE};
                REVOKE ALL ON {TABLE} FROM {EXPORT_ROLE};
                REVOKE USAGE ON SCHEMA audit FROM {EXPORT_ROLE};
                DROP ROLE {EXPORT_ROLE};
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
