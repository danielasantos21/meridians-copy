"""bi_ask_usage - how many AI tokens "Ask Meridian" uses, per organization.

Revision ID: 0044_bi_ask_usage
Revises: 0043_bi_drill_audit
Create Date: 2026-10-13

WHY
---
Ask Meridian calls an AI model on AWS Bedrock, which bills per token. Admins
need to see what the feature costs this month, per model, without opening the
AWS bill.

WHAT IT ADDS
------------
`public.bi_ask_usage`, one row per model call: who (user_id), which model,
how many tokens went in and out (and the cache read/write counts), whether the
call produced an accepted query, and when. NO question text, no query, no
result data and no PHI. Dollar cost is computed on read from a price table in
the code, so a price change never needs a migration.

WHO CAN DO WHAT
---------------
* The application role (meridian_app) may INSERT and SELECT, and only rows of
  its own organization (row-level security keyed on app.org_id). It cannot
  UPDATE or DELETE.
* Who may SEE the numbers inside the app (organization admins) is enforced by
  the route, not the database.
* The organization link cascades: deleting an organization removes its usage.

DOWNGRADE (read this first)
---------------------------
A downgrade drops the table and DESTROYS all usage history. Plain Postgres 17.
"""

from __future__ import annotations

from alembic import op

revision = "0044_bi_ask_usage"
down_revision = "0043_bi_drill_audit"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
USAGE = "public.bi_ask_usage"

COMMENT = "token counts per Ask Meridian model call; no question text, no PHI"

CREATE_USAGE = f"""
CREATE TABLE {USAGE} (
    id                bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id            uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id           uuid        NOT NULL,
    model_id          text        NOT NULL,
    input_tokens      int         NOT NULL DEFAULT 0 CHECK (input_tokens >= 0),
    output_tokens     int         NOT NULL DEFAULT 0 CHECK (output_tokens >= 0),
    cache_read_tokens int         NOT NULL DEFAULT 0 CHECK (cache_read_tokens >= 0),
    cache_write_tokens int        NOT NULL DEFAULT 0 CHECK (cache_write_tokens >= 0),
    ok                boolean     NOT NULL,
    created_at        timestamptz NOT NULL DEFAULT now()
)
"""

_ORG_RULE = "org_id = current_setting('app.org_id', true)::uuid"

UPGRADE_SQL: list[str] = [
    CREATE_USAGE,
    f"CREATE INDEX bi_ask_usage_org_created ON {USAGE} (org_id, created_at)",
    f"COMMENT ON TABLE {USAGE} IS '{COMMENT}'",
    f"ALTER TABLE {USAGE} ENABLE ROW LEVEL SECURITY",
    f"ALTER TABLE {USAGE} FORCE ROW LEVEL SECURITY",
    f"CREATE POLICY meridian_usage_insert ON {USAGE} FOR INSERT WITH CHECK ({_ORG_RULE})",
    f"CREATE POLICY meridian_usage_select ON {USAGE} FOR SELECT USING ({_ORG_RULE})",
    f"REVOKE ALL ON {USAGE} FROM {PHI_ROLE}",
    # On the AWS chain, 0003's default privileges give the app role full DML on new tables;
    # revoke them first so the app can only add and read rows (owner-approved 2026-10-16).
    f"REVOKE ALL ON {USAGE} FROM {APP_ROLE}",
    f"GRANT INSERT, SELECT ON {USAGE} TO {APP_ROLE}",
]

DOWNGRADE_SQL: list[str] = [
    f"DROP TABLE IF EXISTS {USAGE}",
]


def upgrade() -> None:
    for statement in UPGRADE_SQL:
        op.execute(statement)


def downgrade() -> None:
    for statement in DOWNGRADE_SQL:
        op.execute(statement)
