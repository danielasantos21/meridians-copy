"""superadmin_control — support mode, the org switcher, and the two-person superadmin rule.

Revision ID: 0035_superadmin_control
Revises: 0034_process_pins
Create Date: 2026-09-30

WHY
---
The owner: "the super admin should be more like to control everything". A
Meridians staff member has to be able to go into any organization and act in
it — without becoming a member of it, and without that power being silent.
ADR 0051 records the model; this revision is the schema it needs.

WHAT IT ADDS
------------
1. `public.support_sessions` — "support mode". One row per time a superadmin
   entered an organization: who (`user_id`, plus a name/e-mail snapshot so the
   org's own admins can read WHO without reading a profile they cannot see),
   which org, why (`reason`, 10-500 characters), when it started, when it
   stops counting (`expires_at`, two hours), when it ended and how, and
   whether it may read patient-level data (`phi_access`, with its own
   `phi_reason`). While an unexpired, unended row exists, `src.auth.org_context`
   answers that user's requests with an ADMIN context for that org
   (`src/support_access.py`).

   A tenant table (it has `org_id`): ENABLE + FORCE RLS and two policies —
     * `meridian_org_isolation` FOR SELECT on `org_id = app.current_org_id()`:
       the org's admins read their "Meridians support access" log;
     * `meridian_support_own` FOR ALL on the session's own user AND that user
       being in `superadmins`: only a superadmin writes, and only their own.
   No DELETE grant: the log is not erasable by the application. A trigger
   keeps who/which org/why/when-started immutable, and forbids turning PHI
   access back off after it was granted (the grant is a fact that happened).
   At most one open session per user (partial unique index).

2. `audit.support_session` — append-only: one row per session started, PHI
   granted, ended, expired, or PHI refused. INSERT only for `meridian_app`
   plus `audit.refuse_change()` on UPDATE/DELETE/TRUNCATE (the 0017 pattern).

3. `audit.superadmin_access.support_session_id` — nullable. Every request a
   superadmin makes in support mode writes one `audit.superadmin_access` row
   with the session's reason; this column ties it to its session.

4. `public.user_org_selection` — the org switcher. One row per person who
   picked an organization other than their earliest membership. NOT a tenant
   table (no `org_id`: the row belongs to a person). FORCE RLS on the
   session's own user, and the WITH CHECK also demands a membership row in the
   picked org, so a foreign org cannot be stored even by a buggy caller. The
   read path only ever reorders the user's own memberships on top of that.

5. `public.superadmin_changes` + `audit.superadmin_change` — the two-person
   rule. Adding or removing a superadmin is a pending request that a SECOND
   superadmin approves. Only `app.decide_superadmin_change` (SECURITY DEFINER,
   owned by the new NOLOGIN role `meridian_superadmin_keeper`) writes
   `public.superadmins`; `meridian_app` still has no INSERT or DELETE on it.
   `app.list_superadmins()` is the one way the console lists them (a policy on
   `superadmins` that queried `superadmins` would recurse).

RDS-only: Supabase never runs Alembic. On the Supabase backend (Render, until
cutover) support sessions and the org selection live in the api process's
memory (one worker; a restart ends support mode, the safe direction) and the
audit fact is the `support_session` log event. Superadmin changes are refused
there (the runbook script is the way).

DOWNGRADE drops everything this adds (an open support session simply ends).
"""

from __future__ import annotations

from alembic import op

revision = "0035_superadmin_control"
down_revision = "0034_process_pins"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
KEEPER_ROLE = "meridian_superadmin_keeper"

SESSIONS = "public.support_sessions"
SESSION_AUDIT = "audit.support_session"
SELECTION = "public.user_org_selection"
CHANGES = "public.superadmin_changes"
CHANGE_AUDIT = "audit.superadmin_change"

#: "The session is a superadmin." `superadmins` carries its own self-select
#: policy, so the only row this can match is the session's own (revision 0010).
_IS_SUPERADMIN = (
    "(EXISTS (SELECT 1 FROM public.superadmins s WHERE s.user_id = app.current_user_id()))"
)
_OWN_SUPERADMIN = f"(user_id = app.current_user_id() AND {_IS_SUPERADMIN})"
_ORG = "(org_id = app.current_org_id())"

SUPPORT = f"""
CREATE TABLE {SESSIONS} (
    id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id          uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id         uuid        NOT NULL,
    actor_name      text,
    actor_email     text,
    reason          text        NOT NULL CHECK (char_length(btrim(reason)) BETWEEN 10 AND 500),
    started_at      timestamptz NOT NULL DEFAULT now(),
    expires_at      timestamptz NOT NULL,
    ended_at        timestamptz,
    end_reason      text        CHECK (end_reason IN ('exited', 'expired', 'replaced')),
    phi_access      boolean     NOT NULL DEFAULT false,
    phi_reason      text        CHECK (phi_reason IS NULL
                                       OR char_length(btrim(phi_reason)) BETWEEN 10 AND 500),
    phi_granted_at  timestamptz,
    CHECK (expires_at > started_at),
    CHECK (NOT phi_access OR (phi_reason IS NOT NULL AND phi_granted_at IS NOT NULL)),
    CHECK ((ended_at IS NULL) = (end_reason IS NULL))
);
COMMENT ON TABLE {SESSIONS} IS
    'Support mode: a Meridians superadmin acting inside an organization without '
    'being a member of it. Read by the org''s admins as their support-access log. '
    'No DELETE for the application (ADR 0051).';
CREATE UNIQUE INDEX uq_support_sessions_open ON {SESSIONS} (user_id) WHERE ended_at IS NULL;
CREATE INDEX idx_support_sessions_org ON {SESSIONS} (org_id, started_at DESC);

CREATE FUNCTION app.support_session_guard() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF NEW.id <> OLD.id OR NEW.org_id <> OLD.org_id OR NEW.user_id <> OLD.user_id
       OR NEW.reason <> OLD.reason OR NEW.started_at <> OLD.started_at
       OR NEW.actor_name IS DISTINCT FROM OLD.actor_name
       OR NEW.actor_email IS DISTINCT FROM OLD.actor_email THEN
        RAISE EXCEPTION 'who, which organization, why and when a support session '
                        'started cannot be changed' USING ERRCODE = 'check_violation';
    END IF;
    IF OLD.phi_access AND NOT NEW.phi_access THEN
        RAISE EXCEPTION 'a PHI grant on a support session is a fact; it cannot be undone'
            USING ERRCODE = 'check_violation';
    END IF;
    IF OLD.ended_at IS NOT NULL AND (NEW.ended_at IS DISTINCT FROM OLD.ended_at
       OR NEW.phi_access <> OLD.phi_access OR NEW.expires_at <> OLD.expires_at) THEN
        RAISE EXCEPTION 'an ended support session cannot be changed'
            USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER support_session_guard BEFORE UPDATE ON {SESSIONS}
    FOR EACH ROW EXECUTE FUNCTION app.support_session_guard();

ALTER TABLE {SESSIONS} ENABLE ROW LEVEL SECURITY;
ALTER TABLE {SESSIONS} FORCE ROW LEVEL SECURITY;
CREATE POLICY meridian_org_isolation ON {SESSIONS} FOR SELECT USING {_ORG};
CREATE POLICY meridian_support_own ON {SESSIONS}
    USING {_OWN_SUPERADMIN} WITH CHECK {_OWN_SUPERADMIN};
REVOKE ALL ON {SESSIONS} FROM {PHI_ROLE};
GRANT SELECT, INSERT, UPDATE ON {SESSIONS} TO {APP_ROLE};

CREATE TABLE {SESSION_AUDIT} (
    id          bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at          timestamptz NOT NULL DEFAULT now(),
    session_id  uuid        NOT NULL,
    org_id      uuid        NOT NULL,
    user_id     uuid        NOT NULL,
    action      text        NOT NULL CHECK (action IN
                    ('started', 'phi_granted', 'ended', 'expired', 'phi_refused')),
    reason      text
);
COMMENT ON TABLE {SESSION_AUDIT} IS
    'One row per support session started, PHI granted, ended, expired or PHI refused '
    '(ADR 0051). The reason is the superadmin''s own words for why. Append-only.';
CREATE INDEX idx_support_session_audit_org ON {SESSION_AUDIT} (org_id, at DESC);
REVOKE ALL ON {SESSION_AUDIT} FROM {APP_ROLE}, {PHI_ROLE};
GRANT INSERT ON {SESSION_AUDIT} TO {APP_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.support_session_id_seq TO {APP_ROLE};
CREATE TRIGGER support_session_append_only
    BEFORE UPDATE OR DELETE ON {SESSION_AUDIT}
    FOR EACH ROW EXECUTE FUNCTION audit.refuse_change();
CREATE TRIGGER support_session_no_truncate
    BEFORE TRUNCATE ON {SESSION_AUDIT}
    FOR EACH STATEMENT EXECUTE FUNCTION audit.refuse_change();

ALTER TABLE audit.superadmin_access ADD COLUMN support_session_id uuid;
"""  # noqa: S608 DDL from module constants; no runtime input

SELECTION_DDL = f"""
CREATE TABLE {SELECTION} (
    user_id          uuid        PRIMARY KEY,
    selected_org_id  uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    selected_at      timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE {SELECTION} IS
    'The organization a person in several organizations chose to work in. Only ever '
    'one of their own memberships; no row = the earliest one. Ids only.';
ALTER TABLE {SELECTION} ENABLE ROW LEVEL SECURITY;
ALTER TABLE {SELECTION} FORCE ROW LEVEL SECURITY;
CREATE POLICY meridian_selection_own ON {SELECTION}
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id() AND EXISTS (
        SELECT 1 FROM public.org_members m
         WHERE m.org_id = selected_org_id AND m.user_id = app.current_user_id()));
REVOKE ALL ON {SELECTION} FROM {PHI_ROLE};
GRANT SELECT, INSERT, UPDATE, DELETE ON {SELECTION} TO {APP_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input

CREATE_KEEPER = f"""
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{KEEPER_ROLE}') THEN
        CREATE ROLE {KEEPER_ROLE} NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB
            NOCREATEROLE NOINHERIT;
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input

CHANGES_DDL = f"""
CREATE TABLE {CHANGES} (
    id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    action          text        NOT NULL CHECK (action IN ('add', 'remove')),
    target_user_id  uuid        NOT NULL,
    target_label    text,
    reason          text        NOT NULL CHECK (char_length(btrim(reason)) BETWEEN 10 AND 500),
    requested_by    uuid        NOT NULL,
    requested_at    timestamptz NOT NULL DEFAULT now(),
    expires_at      timestamptz NOT NULL DEFAULT now() + interval '7 days',
    status          text        NOT NULL DEFAULT 'pending' CHECK (status IN
                        ('pending', 'applied', 'rejected', 'cancelled', 'expired')),
    decided_by      uuid,
    decided_at      timestamptz
);
COMMENT ON TABLE {CHANGES} IS
    'Requests to add or remove a superadmin. Applied only by a SECOND superadmin '
    'through app.decide_superadmin_change (ADR 0051). Ids, a label and a reason.';
CREATE UNIQUE INDEX uq_superadmin_changes_pending
    ON {CHANGES} (target_user_id, action) WHERE status = 'pending';
ALTER TABLE {CHANGES} ENABLE ROW LEVEL SECURITY;
ALTER TABLE {CHANGES} FORCE ROW LEVEL SECURITY;
CREATE POLICY meridian_changes_superadmin_select ON {CHANGES}
    FOR SELECT TO {APP_ROLE} USING {_IS_SUPERADMIN};
CREATE POLICY meridian_changes_superadmin_request ON {CHANGES}
    FOR INSERT TO {APP_ROLE}
    WITH CHECK ({_IS_SUPERADMIN} AND requested_by = app.current_user_id()
                AND status = 'pending' AND decided_by IS NULL);
REVOKE ALL ON {CHANGES} FROM {PHI_ROLE};
GRANT SELECT, INSERT ON {CHANGES} TO {APP_ROLE};

CREATE TABLE {CHANGE_AUDIT} (
    id              bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at              timestamptz NOT NULL DEFAULT now(),
    db_user         text        NOT NULL DEFAULT session_user,
    actor_user_id   uuid,
    change_id       uuid,
    target_user_id  uuid        NOT NULL,
    action          text        NOT NULL CHECK (action IN
                        ('requested', 'applied', 'rejected', 'cancelled', 'expired',
                         'bootstrap_added', 'bootstrap_removed')),
    reason          text
);
COMMENT ON TABLE {CHANGE_AUDIT} IS
    'One row per superadmin change requested, decided or bootstrapped by the runbook '
    'script (ADR 0051). Ids and the stated reason. Append-only.';
REVOKE ALL ON {CHANGE_AUDIT} FROM {APP_ROLE}, {PHI_ROLE};
GRANT INSERT ON {CHANGE_AUDIT} TO {APP_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.superadmin_change_id_seq TO {APP_ROLE};
CREATE TRIGGER superadmin_change_append_only
    BEFORE UPDATE OR DELETE ON {CHANGE_AUDIT}
    FOR EACH ROW EXECUTE FUNCTION audit.refuse_change();
CREATE TRIGGER superadmin_change_no_truncate
    BEFORE TRUNCATE ON {CHANGE_AUDIT}
    FOR EACH STATEMENT EXECUTE FUNCTION audit.refuse_change();
"""  # noqa: S608 DDL from module constants; no runtime input

KEEPER_GRANTS = f"""
GRANT USAGE ON SCHEMA public, audit, app TO {KEEPER_ROLE};
GRANT EXECUTE ON FUNCTION app.current_user_id() TO {KEEPER_ROLE};
GRANT SELECT, INSERT, DELETE ON public.superadmins TO {KEEPER_ROLE};
CREATE POLICY meridian_keeper_superadmins ON public.superadmins
    TO {KEEPER_ROLE} USING (true) WITH CHECK (true);
GRANT SELECT, UPDATE ON {CHANGES} TO {KEEPER_ROLE};
CREATE POLICY meridian_keeper_changes ON {CHANGES}
    TO {KEEPER_ROLE} USING (true) WITH CHECK (true);
GRANT INSERT ON {CHANGE_AUDIT} TO {KEEPER_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.superadmin_change_id_seq TO {KEEPER_ROLE};
"""

FUNCTIONS = f"""
CREATE FUNCTION app.list_superadmins()
RETURNS TABLE (user_id uuid, created_at timestamptz)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
#variable_conflict use_column
DECLARE
    v_user uuid := app.current_user_id();
BEGIN
    IF v_user IS NULL
       OR NOT EXISTS (SELECT 1 FROM public.superadmins s WHERE s.user_id = v_user) THEN
        RAISE EXCEPTION 'only a superadmin may list superadmins'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    RETURN QUERY
        SELECT s.user_id, s.created_at FROM public.superadmins s
         ORDER BY s.created_at, s.user_id;
END
$fn$;
COMMENT ON FUNCTION app.list_superadmins() IS
    'Every superadmin, for a superadmin caller only (ADR 0051).';
REVOKE ALL ON FUNCTION app.list_superadmins() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.list_superadmins() TO {APP_ROLE};

CREATE FUNCTION app.decide_superadmin_change(
    p_change uuid, p_approve boolean, p_allow_self boolean)
RETURNS text
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
#variable_conflict use_column
DECLARE
    v_user   uuid := app.current_user_id();
    v_row    public.superadmin_changes%ROWTYPE;
    v_status text;
    v_count  integer;
BEGIN
    IF v_user IS NULL
       OR NOT EXISTS (SELECT 1 FROM public.superadmins s WHERE s.user_id = v_user) THEN
        RETURN 'not_superadmin';
    END IF;
    SELECT * INTO v_row FROM public.superadmin_changes c WHERE c.id = p_change FOR UPDATE;
    IF NOT FOUND OR v_row.status <> 'pending' THEN
        RETURN 'not_pending';
    END IF;
    IF v_row.expires_at <= now() THEN
        UPDATE public.superadmin_changes c
           SET status = 'expired', decided_at = now() WHERE c.id = p_change;
        INSERT INTO {CHANGE_AUDIT} (actor_user_id, change_id, target_user_id, action)
             VALUES (v_user, p_change, v_row.target_user_id, 'expired');
        RETURN 'expired';
    END IF;
    IF NOT p_approve THEN
        v_status := CASE WHEN v_row.requested_by = v_user THEN 'cancelled' ELSE 'rejected' END;
        UPDATE public.superadmin_changes c
           SET status = v_status, decided_by = v_user, decided_at = now()
         WHERE c.id = p_change;
        INSERT INTO {CHANGE_AUDIT} (actor_user_id, change_id, target_user_id, action)
             VALUES (v_user, p_change, v_row.target_user_id, v_status);
        RETURN v_status;
    END IF;
    IF v_row.requested_by = v_user AND NOT coalesce(p_allow_self, false) THEN
        RETURN 'second_approver_required';
    END IF;
    IF v_row.action = 'add' THEN
        INSERT INTO public.superadmins (user_id) VALUES (v_row.target_user_id)
            ON CONFLICT DO NOTHING;
    ELSE
        SELECT count(*) INTO v_count FROM public.superadmins;
        IF v_count <= 1 THEN
            RETURN 'last_superadmin';
        END IF;
        DELETE FROM public.superadmins s WHERE s.user_id = v_row.target_user_id;
    END IF;
    UPDATE public.superadmin_changes c
       SET status = 'applied', decided_by = v_user, decided_at = now()
     WHERE c.id = p_change;
    INSERT INTO {CHANGE_AUDIT} (actor_user_id, change_id, target_user_id, action, reason)
         VALUES (v_user, p_change, v_row.target_user_id, 'applied', v_row.reason);
    RETURN 'applied';
END
$fn$;
COMMENT ON FUNCTION app.decide_superadmin_change(uuid, boolean, boolean) IS
    'The one way meridian_app changes public.superadmins: a second superadmin approves '
    'a pending request (p_allow_self only in development). ADR 0051.';
REVOKE ALL ON FUNCTION app.decide_superadmin_change(uuid, boolean, boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.decide_superadmin_change(uuid, boolean, boolean) TO {APP_ROLE};

-- Hand both functions to the keeper, as 0015 hands app.create_organization to
-- its creator role (INHERIT FALSE: the migrator must not pick up its policies).
GRANT {KEEPER_ROLE} TO CURRENT_USER WITH INHERIT FALSE, SET TRUE;
GRANT CREATE ON SCHEMA app TO {KEEPER_ROLE};
ALTER FUNCTION app.list_superadmins() OWNER TO {KEEPER_ROLE};
ALTER FUNCTION app.decide_superadmin_change(uuid, boolean, boolean) OWNER TO {KEEPER_ROLE};
REVOKE CREATE ON SCHEMA app FROM {KEEPER_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(SUPPORT)
    op.execute(SELECTION_DDL)
    op.execute(CREATE_KEEPER)
    op.execute(CHANGES_DDL)
    op.execute(KEEPER_GRANTS)
    op.execute(FUNCTIONS)


def downgrade() -> None:
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{KEEPER_ROLE}') THEN
                EXECUTE 'SET ROLE {KEEPER_ROLE}';
                DROP FUNCTION IF EXISTS app.decide_superadmin_change(uuid, boolean, boolean);
                DROP FUNCTION IF EXISTS app.list_superadmins();
                RESET ROLE;
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute("DROP POLICY IF EXISTS meridian_keeper_superadmins ON public.superadmins")
    op.execute(f"DROP TABLE IF EXISTS {CHANGE_AUDIT}")
    op.execute(f"DROP TABLE IF EXISTS {CHANGES}")
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{KEEPER_ROLE}') THEN
                REVOKE ALL ON public.superadmins FROM {KEEPER_ROLE};
                REVOKE ALL ON FUNCTION app.current_user_id() FROM {KEEPER_ROLE};
                REVOKE USAGE ON SCHEMA public, audit, app FROM {KEEPER_ROLE};
                DROP ROLE {KEEPER_ROLE};
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(f"DROP TABLE IF EXISTS {SELECTION}")
    op.execute("ALTER TABLE audit.superadmin_access DROP COLUMN IF EXISTS support_session_id")
    op.execute(f"DROP TABLE IF EXISTS {SESSION_AUDIT}")
    op.execute(f"DROP TABLE IF EXISTS {SESSIONS}")
    op.execute("DROP FUNCTION IF EXISTS app.support_session_guard()")
