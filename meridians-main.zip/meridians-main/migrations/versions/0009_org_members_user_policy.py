"""org_members_user_policy — the identity reads every request makes before it
knows an organization.

Revision ID: 0009_org_members_user_policy
Revises: 0008_process_runs_unique
Create Date: 2026-09-16

Phase 5a of `docs/aws-migration-plan.md` (the "v2 API + `src/auth.py` sites"
item); ADR 0011 (tenant isolation), ADR 0022 (`with_user`, and the KNOWN GAP
this revision closes).

WHAT IT CLOSES
--------------
`pg.with_user(user_id)` sets `app.user_id` and leaves `app.org_id` empty, for
the two questions a request has to answer *before* it knows an org id: who is
this bearer, and which organization is he in? Revision 0004 answered the first
(`superadmins` carries `user_id = app.current_user_id()`) and broke the second:
`public.org_members` is in `scripts/tenant_tables.txt`, so 0004 gave it the
org-scoped policy and dropped the inherited user-scoped one with every other
inherited policy. `src/auth.get_user_org` therefore read **zero rows** under
`with_user`, and `tests/test_pg.py` asserted the gap rather than pretending
otherwise.

POLICIES ARE OR-ED, AND THAT IS WHY THIS IS SAFE
------------------------------------------------
PostgreSQL combines several *permissive* policies for one command with OR, so
adding a policy can only ever make more rows visible — never fewer, and never
to a command it does not name. Each one below is therefore read as "and also":

| Table | Command | Added predicate | What it lets a session see |
|---|---|---|---|
| `public.org_members` | SELECT | `user_id = app.current_user_id()` | its **own** membership rows, in any org, and nobody else's |
| `public.organizations` | SELECT | it is a member of that org | the orgs it belongs to — the names the org picker shows |
| `public.invite_codes` | SELECT | `code = app.invite_code` | the one invite whose code the session is holding |

None of them widens an *org* scope. A user reading his own two membership rows
learns which organizations he is in, which he already knew; he does not gain a
single row of any organization's data, because all 62 tenant tables stay
filtered on `app.current_org_id()` and that is still NULL under `with_user`.
Acting on an organization is still `with_org(that_org_id)`, entered
deliberately, with the same predicate as any other member (ADR 0022).

`organizations` is `ENABLE ROW LEVEL SECURITY` **without** `FORCE` (0004), and
its only SELECT policy was `id = app.current_org_id()` — which under `with_user`
is NULL, so the org picker could not name the orgs whose ids `org_members` had
just returned. The second policy is the other half of the first; without it
this revision would close half the gap.

The `organizations` sub-select reads `org_members`, which carries its own RLS,
and that is deliberate rather than a problem — the same reasoning 0006 records
for the `superadmins` sub-select on `user_profiles`. The only membership rows it
can see are the session's own, and the session's own rows are exactly the ones
that answer "which organizations am I in?".

THE INVITE POLICY, AND WHY IT IS NOT AN ENUMERATION HOLE
--------------------------------------------------------
Redeeming an invite is the one authenticated operation that genuinely has no
organization yet: the bearer holds a code, and which org it joins him to is the
answer, not the question. Under RLS alone the lookup reads zero rows and the
feature is dead on RDS.

So the session **states the code it is holding** — `SET app.invite_code` — and
the policy reveals exactly the row that matches it:

    USING (code = nullif(current_setting('app.invite_code', true), ''))

* With the setting unset it is `code = NULL`, which is NULL, which is not true:
  **no row**. Fail closed, exactly as `app.current_org_id()` does.
* With it set it is one equality against a 12-character secret the holder was
  given out of band. There is no wildcard, no prefix and no listing — a session
  cannot walk the table any more than it could guess the code.
* **SELECT only.** Marking the code used is an UPDATE, and an UPDATE still needs
  `org_id = app.current_org_id()` — i.e. an ordinary `with_org()` on the
  organization the invite names, entered after it has been read. Joining the org
  is an INSERT into `org_members`, likewise.

`src/auth.py` sets the value for the length of the lookup and `RESET`s it in a
`finally`, and `src/pg.py`'s `_release_scope` resets it again — with `ROLE`,
`app.org_id` and `app.user_id` — before the connection goes back to the pool.
Two nets, because the `finally` is the one that does not run when the process
is killed between the `SET` and the lookup.

DOWNGRADE
---------
Supported and cheap: it drops the three policies. What it costs is exactly what
this revision bought — `get_user_org` goes back to reading zero rows under
`with_user` and invite redemption goes back to being unavailable on RDS. No data
is touched.
"""

from __future__ import annotations

from alembic import op

revision = "0009_org_members_user_policy"
down_revision = "0008_process_runs_unique"
branch_labels = None
depends_on = None

#: The role the application connects as (revision 0003). The policies are
#: granted to it by name rather than to PUBLIC: they exist for the application's
#: org-less identity reads, and naming the grantee says so. The owner is
#: unaffected either way — it seeds these tables with `app.org_id` set.
APP_ROLE = "meridian_app"

_SELF = "(user_id = app.current_user_id())"

#: The session's own membership of the organization being read. `org_members`
#: carries RLS of its own, so this sees only the session's rows — see the
#: docstring.
_MEMBER_OF = (
    "(EXISTS (SELECT 1 FROM public.org_members m "
    " WHERE m.org_id = organizations.id "
    "   AND m.user_id = app.current_user_id()))"
)

#: The invite code the session says it is holding. `nullif(..., '')` is what
#: makes an unset setting read as NULL rather than as the empty string, so an
#: invite row with an empty code — there are none, the column is NOT NULL and
#: generated — could still not be reached by a session that set nothing.
_HOLDS_THE_CODE = "(code = nullif(current_setting('app.invite_code', true), ''))"

#: `(table, policy name, USING)`. SELECT, all three: nothing here may write.
POLICIES: list[tuple[str, str, str]] = [
    ("public.org_members", "meridian_member_self_select", _SELF),
    ("public.organizations", "meridian_org_member_select", _MEMBER_OF),
    ("public.invite_codes", "meridian_invite_by_code_select", _HOLDS_THE_CODE),
]


def upgrade() -> None:
    for table, name, using in POLICIES:
        op.execute(f"CREATE POLICY {name} ON {table} FOR SELECT TO {APP_ROLE} USING {using}")


def downgrade() -> None:
    for table, name, _using in POLICIES:
        op.execute(f"DROP POLICY IF EXISTS {name} ON {table}")
