"""queued_job_resend — a queued job whose message never left is sent again, on SQS too.

Revision ID: 0031_queued_job_resend
Revises: 0029_clinic_group_unposted
Create Date: 2026-09-25

ADR 0028 (one `run_job`, two transports), ADR 0048 (in-process redelivery, amended
by this revision). RDS-only: Supabase never runs Alembic, and nothing on Render
calls any of this.

WHY
---
The api starts a job in two steps that are not one transaction: the
compare-and-set (`process_runs.begin_action`) COMMITS the queued-job marker
(`last_job_id` = the job, `attempts` 0, an ownerless lapsed lease), and only
then is the message handed to the transport (`workers/dispatch.enqueue`). An
api task killed between the two left, on `JOB_TRANSPORT=sqs`, a run marked
queued whose message SQS never received. `Dispatcher.recover` skipped every
process routed to SQS ("SQS's to redeliver"), SQS had nothing to redeliver,
and `begin_action` refuses every new start while a job is queued: the run sat
on the processing screen, unstartable, until someone cancelled it.

The fix is a recovery sweep that is bounded and idempotent by job id, rather
than a second queue table (ADR 0028 rejected an outbox table for the same
reason: the run row already records the job). The marker IS the outbox row:
`Dispatcher.recover` now re-sends a queued, never-claimed job past the grace on
whichever transport its process is routed to, with the SAME job id, after
winning ONE conditional UPDATE on the run (`process_runs.claim_resend`) that
counts the send and re-arms the marker's clock. So:

* **bounded:** a job is sent at most `MAX_JOB_SENDS` times in all (the api's
  own send is the first), at most once per grace, by whichever api task wins
  the UPDATE;
* **idempotent:** a copy of a message that DID arrive is harmless — the lease
  lets one delivery claim the run, and the other is acknowledged as a
  duplicate once the job has settled (`workers/run_job._settled_by`).

WHAT CHANGES
------------
* `process_runs.job_sends smallint NOT NULL DEFAULT 0`, CHECK 0..`MAX_JOB_SENDS`:
  how many times the queued job named by `last_job_id` was handed to a
  transport. `begin_action` sets it to 1 with the marker; `claim_resend`
  increments it. A counter only — no ids, no values. `meridian_app` writes it
  through its table-level grants; the control role may SELECT it (the definer
  below reads it).
* `app.redeliverable_jobs` replaced in place (same signature, same answer
  columns): the queued branch answers only jobs with a send left
  (`job_sends < MAX_JOB_SENDS`), so a job whose every send was refused is not
  handed out on every pass, crowding the oldest-first `LIMIT` for good.

HOW THE FUNCTION IS REPLACED
----------------------------
0024's way: `CREATE OR REPLACE` under `SET ROLE meridian_job_control`, with a
transient `CREATE` on schema `app`, revoked at once. Owner and EXECUTE grants
are kept.

DOWNGRADE
---------
Supported: puts 0024's body back, drops the CHECK, the grant and the column. Without
them `recover` re-sends nothing on SQS (the code reads the column) — the code
must be rolled back with it, as for every revision.
"""

from __future__ import annotations

from alembic import op

revision = "0031_queued_job_resend"
down_revision = "0029_clinic_group_unposted"
branch_labels = None
depends_on = None

CONTROL_ROLE = "meridian_job_control"

#: 0022/0024's values, repeated because a migration never imports another one.
MAX_ATTEMPTS = 3
MAX_GRACE_SECONDS = 86_400
MAX_LIMIT = 1_000
POST_COMPLETION_STATES = ("completed",)

#: A queued job is handed to a transport at most this many times: the api's own
#: send and two re-sends (`workers/inprocess.MAX_JOB_SENDS`; a test holds them
#: equal). Three, like SQS's maxReceiveCount.
MAX_JOB_SENDS = 3

SIGNATURE = "app.redeliverable_jobs(integer, integer)"
CHECK = "process_runs_job_sends_bounded"

_FINISHED = ", ".join(f"'{state}'" for state in POST_COMPLETION_STATES)
_NEVER_STARTED_FROM = ", ".join(
    f"'{state}'"
    for state in ("completed", "failed", "expired", "superseded")
    if state not in POST_COMPLETION_STATES
)

COLUMN = f"""
ALTER TABLE public.process_runs
    ADD COLUMN job_sends smallint NOT NULL DEFAULT 0;
ALTER TABLE public.process_runs
    ADD CONSTRAINT {CHECK} CHECK (job_sends BETWEEN 0 AND {MAX_JOB_SENDS});
COMMENT ON COLUMN public.process_runs.job_sends IS
    'Queued-job resend (0031): how many times the job named by last_job_id was handed to a '
    'transport while unclaimed; at most {MAX_JOB_SENDS}. A counter only.';
GRANT SELECT (job_sends) ON public.process_runs TO {CONTROL_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input

_HEAD = f"""
CREATE OR REPLACE FUNCTION app.redeliverable_jobs(
    p_queued_grace_seconds integer,
    p_limit                integer
)
RETURNS TABLE (
    job_run_id    uuid,
    job_org_id    uuid,
    job_process   text,
    job_state     text,
    job_id        text,
    job_attempts  integer
)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF p_queued_grace_seconds IS NULL
       OR p_queued_grace_seconds NOT BETWEEN 0 AND {MAX_GRACE_SECONDS} THEN
        RAISE EXCEPTION 'redeliverable_jobs: grace must be 0-{MAX_GRACE_SECONDS} seconds'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_limit IS NULL OR p_limit NOT BETWEEN 1 AND {MAX_LIMIT} THEN
        RAISE EXCEPTION 'redeliverable_jobs: limit must be 1-{MAX_LIMIT}'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
"""  # noqa: S608 DDL from module constants; no runtime input

_END = """
     ORDER BY r.lease_expires_at, r.run_id
     LIMIT p_limit;
END
$fn$;
"""


def _branches(queued_extra: str, index_note: str) -> str:
    """0024's three branches; `queued_extra` is appended to the queued one's WHERE."""
    return f"""
    -- Cross-org by design; ids and states only. Each branch reads one partial
    -- index (0011's idx_process_runs_stale_lease, 0024's
    -- idx_process_runs_finished_lease, 0022's idx_process_runs_queued_job).{index_note}
    RETURN QUERY
    SELECT r.run_id, r.org_id, r.process, r.state, r.last_job_id, r.attempts
      FROM (
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.state IN ('parsing', 'running')
           AND pr.lease_expires_at < now()
           AND pr.last_job_id IS NOT NULL
           AND pr.attempts BETWEEN 1 AND {MAX_ATTEMPTS - 1}
        UNION ALL
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.state IN ({_FINISHED})
           AND pr.lease_expires_at < now()
           AND pr.last_job_id IS NOT NULL
           AND pr.attempts BETWEEN 1 AND {MAX_ATTEMPTS - 1}
        UNION ALL
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.attempts = 0
           AND pr.last_job_id IS NOT NULL
           AND pr.lease_owner IS NULL
           AND pr.state NOT IN ({_NEVER_STARTED_FROM})
           AND pr.lease_expires_at < now() - make_interval(secs => p_queued_grace_seconds){queued_extra}
      ) AS r"""  # noqa: S608 DDL from module constants; no runtime input


_COMMENT = f"""
COMMENT ON FUNCTION {SIGNATURE} IS
    'Phase 11 D4 / E2 / 0031: jobs no live worker holds - killed mid-job (a lapsed lease, fewer '
    'than {MAX_ATTEMPTS} claims; on a finished run, a post-completion job) or queued, never '
    'claimed and with a send left - for the api to deliver again (a queued job on either '
    'transport). Cross-org by design; returns ids and states only.';
"""

#: 0024's comment, word for word, for the downgrade.
_PREVIOUS_COMMENT = f"""
COMMENT ON FUNCTION {SIGNATURE} IS
    'Phase 11 D4 / E2: jobs no live worker holds - killed mid-job (a lapsed lease, fewer than '
    '{MAX_ATTEMPTS} claims; on a finished run, a post-completion job) or queued and never '
    'claimed - for the in-process transport to deliver again. Cross-org by design; returns '
    'ids and states only.';
"""

REDELIVERABLE = "".join(
    (
        _HEAD,
        _branches(
            f"\n           AND pr.job_sends < {MAX_JOB_SENDS}",
            "\n    -- 0031: a queued job is answered only while it has a send left.",
        ),
        _END,
        _COMMENT,
    )
)
PREVIOUS_REDELIVERABLE = "".join((_HEAD, _branches("", ""), _END, _PREVIOUS_COMMENT))


def _as_owner(body: str) -> str:
    """`body` run as the function's owner, with CREATE on `app` only meanwhile (0020's way)."""
    return f"""
GRANT CREATE ON SCHEMA app TO {CONTROL_ROLE};
SET ROLE {CONTROL_ROLE};
{body}
RESET ROLE;
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""


def upgrade() -> None:
    op.execute(COLUMN)
    op.execute(_as_owner(REDELIVERABLE))


def downgrade() -> None:
    op.execute(_as_owner(PREVIOUS_REDELIVERABLE))
    op.execute(f"REVOKE SELECT (job_sends) ON public.process_runs FROM {CONTROL_ROLE}")  # noqa: S608 module constant
    op.execute(f"ALTER TABLE public.process_runs DROP CONSTRAINT IF EXISTS {CHECK}")
    op.execute("ALTER TABLE public.process_runs DROP COLUMN IF EXISTS job_sends")
