"""drop_transaction_identifiers — the DDL half of the Phase 3 PHI split.

Revision ID: 0005_drop_txn_identifiers
Revises: 0004_rls_app_org_id
Create Date: 2026-09-16

Plan §2.3 ("public.transactions — everything EXCEPT the three identifiers") and
Phase 3 step 11. The DATA half is `scripts/split_phi.sql`, which runs at 0003;
this is what makes the split permanent.

WHAT IT DOES
------------
1. Asserts the split actually ran: every `public.transactions` row has a
   `patient_ref`, and `phi.transaction_identity` has exactly as many rows as
   `public.transactions`. On an empty database (CI) both counts are zero and
   the assertion is vacuously true, which is correct — there is nothing to
   split.
1b. On a database that HAS transactions, asserts `phi.hmac_key_fingerprint`
   exists and holds exactly one row. The TABLE is created by revision 0003
   (DDL belongs to the chain, ADR 0019); the ROW is written by
   `scripts/split_phi.sql` at 0003, before this revision exists. It is
   `sha256(key)` in hex: the evidence of WHICH key wrote every `patient_ref`,
   which is what makes a later accidental re-key loud instead of silent
   (critic M-1). On an empty database the table is allowed to be absent, for
   the same reason the counts are allowed to be zero: nothing was split.
2. Drops `patient_id`, `claim_no` and `encounter_id` from
   `public.transactions`.
3. Puts `NOT NULL` on `public.transactions.patient_ref`.

WHY THE DDL IS NOT IN THE SCRIPT
--------------------------------
Alembic owns DDL (ADR 0019). A load script that dropped columns would leave the
chain describing a schema the database does not have, and the next
`alembic upgrade` on a fresh environment would produce a different table from
the one in production. So the script NULLs the columns and this revision drops
them.

THE ORDER, AND WHY IT IS THIS ORDER
-----------------------------------
Alembic revisions are linear and 0004 is already before any 0005, so:

    restore at 0003  ->  scripts/split_phi.py  ->  alembic upgrade head
                                                   (0004 RLS, then 0005)

There is no version of this where the split runs after 0004: 0004 turns on
FORCE ROW LEVEL SECURITY, which applies to the table owner, so the migrator's
UPDATE would match zero rows and report success.

**A failure here leaves the database at 0003, not at 0004** (critic R2-L4).
`migrations/env.py` wraps the whole upgrade in ONE `context.begin_transaction()`
— it does not set `transaction_per_migration` — so the assertions below roll
0004 back with them. That is why every recovery message here says "restore to
0003 and run the split", with no `alembic downgrade` in between: the chain has
already undone itself. That is also why the
assertion below has to lift FORCE for the length of two `count(*)`s — by the
time 0005 runs, 0004 has already made the migrator blind to every row.

LIFTING `FORCE` FOR THE ASSERTION
---------------------------------
`ALTER TABLE ... NO FORCE ROW LEVEL SECURITY`, two counts, `FORCE` again — all
inside the migration's transaction. If anything raises, the transaction rolls
back and FORCE comes back with it; the table is never left unforced on disk.
The alternative (loop over `organizations` setting `app.org_id`) reads the org
list through the same RLS and would quietly check nothing if that list were
empty.

THE APPLICATION DOES NOT WRITE `patient_ref` YET (critic H-3)
-------------------------------------------------------------
**After this revision, `src/database.py`'s transaction inserts fail on RDS.**
`bulk_add_transactions` and its callers write `patient_id`, `claim_no` and
`encounter_id` and never write `patient_ref`; this revision drops the first
three and makes the fourth `NOT NULL`. That is not a latent risk, it is an
`UndefinedColumn` on the first upload.

It is not fixed here because the fix is not a migration. The repository layer
(**Phase 5a**) computes `patient_ref` with the same key — `src/phi.py`, reading
`MERIDIAN_PHI_HMAC_KEY` — and routes the three identifiers to
`phi.transaction_identity` through the `phi_access` role, which is the only
role with any grant on `phi`. Until that lands, RDS is a parity target and
Supabase is authoritative: nothing writes to the target, which is exactly the
state `docs/runbooks/data-load.md` describes and `cutover.md` ends.

Tracked in `docs/migration-tracker.md` (Phase 5a), not left to be discovered.

`source_transactions` IS DELIBERATELY NOT MOVED HERE
----------------------------------------------------
Plan P-3 has `public.source_transactions` moving into `phi` as-is
(`ALTER TABLE ... SET SCHEMA phi`, not a 167k-row copy). It is NOT in this
revision, and the move is blocked on three things that are outside the scope of
the data step:

  * `src/database.py` writes and reads `source_transactions` as `meridian_app`
    (`bulk_add_source_transactions`, `get_source_transactions`, called from
    `web_app.py` on every upload). `meridian_app` has NO grant of any kind on
    `phi` (revision 0003, plan §2.3), so the move breaks upload at runtime the
    moment it lands. Either those calls move behind `src/phi.py` / the
    `phi_access` role, or the move does not happen.
  * `scripts/tenant_tables.txt` lists `public.source_transactions`, and
    `tests/test_migrations.py` checks that file against BOTH the committed
    Supabase dump (where it is in `public` forever) and a database at head.
    Those two checks cannot both pass across a relocation until
    `scripts/gen_tenant_tables.py` learns about it.
  * `scripts/lint_org_scope.py` resolves the same list.

Recorded in docs/runbooks/data-load.md as an open item rather than done
quietly.

DOWNGRADE
---------
Not supported. The columns can be re-added but their values are in `phi`, and
putting them back would undo the split this revision exists to make permanent.
"""

from __future__ import annotations

from alembic import op

revision = "0005_drop_txn_identifiers"
down_revision = "0004_rls_app_org_id"
branch_labels = None
depends_on = None

IDENTIFIER_COLUMNS = ("patient_id", "claim_no", "encounter_id")

#: Both tables carry FORCE ROW LEVEL SECURITY after 0004 (they are in
#: scripts/tenant_tables.txt), so both have to be lifted for the counts.
#:
#: `phi.hmac_key_fingerprint` is NOT in this list and is not in
#: scripts/tenant_tables.txt: it holds one row, that row is a hash of a key, and
#: it belongs to no organization. There is nothing for a tenant policy to scope.
_FORCED = ("public.transactions", "phi.transaction_identity")

#: Created by revision 0003; its one row is written by scripts/split_phi.sql at
#: 0003. See the docstring.
_FINGERPRINT_TABLE = "phi.hmac_key_fingerprint"


def _assert_split_has_run(conn) -> None:
    for table in _FORCED:
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY")
    try:
        n_tx = conn.exec_driver_sql("SELECT count(*) FROM public.transactions").scalar()
        n_id = conn.exec_driver_sql("SELECT count(*) FROM phi.transaction_identity").scalar()
        n_null = conn.exec_driver_sql(
            "SELECT count(*) FROM public.transactions WHERE patient_ref IS NULL"
        ).scalar()
    finally:
        for table in _FORCED:
            op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")

    if n_null:
        raise RuntimeError(
            f"{n_null} of {n_tx} public.transactions rows have a NULL patient_ref. "
            "The PHI split has not run on this database. Restore to revision "
            "0003, run `python scripts/split_phi.py`, then upgrade again. "
            "See docs/runbooks/data-load.md."
        )
    if n_id != n_tx:
        raise RuntimeError(
            f"phi.transaction_identity has {n_id} rows and public.transactions has "
            f"{n_tx}. The split is incomplete, and dropping the identifier columns "
            "now would destroy the difference. See docs/runbooks/data-load.md."
        )

    if not n_tx:
        # Empty database (CI, or a fresh environment). Nothing was split, so
        # there is no key to have recorded.
        return

    exists = conn.exec_driver_sql(
        f"SELECT to_regclass('{_FINGERPRINT_TABLE}') IS NOT NULL"
    ).scalar()
    if not exists:
        raise RuntimeError(
            f"{_FINGERPRINT_TABLE} does not exist on a database with {n_tx} "
            "transactions. Revision 0003 creates it and scripts/split_phi.sql "
            "writes its one row, so its absence means the patient_ref values were "
            "written by something other than the split script and nothing records "
            "which key wrote them. Restore to 0003 and run "
            "`python scripts/split_phi.py`. See docs/runbooks/data-load.md."
        )
    n_fp = conn.exec_driver_sql(f"SELECT count(*) FROM {_FINGERPRINT_TABLE}").scalar()  # noqa: S608 DDL from module constants; no runtime input
    if n_fp != 1:
        raise RuntimeError(
            f"{_FINGERPRINT_TABLE} holds {n_fp} rows; it must hold exactly one. "
            "One key wrote every patient_ref in this database, and that is the row."
        )


def upgrade() -> None:
    if op.get_context().as_sql:
        raise RuntimeError(
            "0005 cannot run in offline mode (`alembic upgrade --sql`). It "
            "counts rows to prove the PHI split ran before it drops the "
            "columns the split copied, and a generated script cannot count "
            "anything. See docs/runbooks/data-load.md."
        )

    conn = op.get_bind()
    _assert_split_has_run(conn)

    for column in IDENTIFIER_COLUMNS:
        op.execute(f"ALTER TABLE public.transactions DROP COLUMN IF EXISTS {column}")

    # Now that every row is tokenised and nothing can write an untokenised one.
    op.execute("ALTER TABLE public.transactions ALTER COLUMN patient_ref SET NOT NULL")


def downgrade() -> None:
    raise RuntimeError(
        "0005 has no downgrade. The identifiers it dropped live in "
        "phi.transaction_identity; re-adding the columns would recreate the "
        "PHI exposure the split removed. To undo the split, restore the "
        "pre-migration snapshot."
    )
