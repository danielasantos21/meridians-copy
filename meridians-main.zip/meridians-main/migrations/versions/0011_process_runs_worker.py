"""process_runs_worker — run leases, and the three definer functions the worker
calls before it knows which organization it is working for.

Revision ID: 0011_process_runs_worker
Revises: 0010_superadmin_org_list
Create Date: 2026-09-24

Phase 11 task D2 (`docs/reports/phase-11-plan.md` §3.4, §3.5). ADR 0011 (tenant
isolation: the `org_id` predicate AND row-level security), ADR 0029 (job
message and pre-context authorization), ADR 0030 (leases, not advisory locks).
RDS-only: Supabase never runs Alembic, and nothing on Render calls any of this.

WHY A WORKER NEEDS A DOOR AT ALL
--------------------------------
A queue message says "run job X of run R in org O for actor A". The worker must
not believe it: `with_org(O)` on the message's word alone would let anybody who
can put a message on the queue act inside any organization. So the worker
re-reads the run row FIRST. But `process_runs` is `FORCE ROW LEVEL SECURITY`
(0004) and `meridian_app` sees no row of it until `app.org_id` is set — which is
exactly the thing it has not decided yet. A narrow `SECURITY DEFINER` function
is the only way to do "re-read before setting context" (plan §3.4).

WHAT IT ADDS
------------
Four columns on `process_runs` (plan §3.5; no new table):

* `lease_owner`      — which worker holds the run ("task-id/pid"), or NULL.
* `lease_expires_at` — when that claim lapses unless heartbeated.
* `attempts`         — claims of the CURRENT job (see `app.claim_run`).
* `last_job_id`      — the `job_id` of the message that last claimed it.

Three functions, all `SECURITY DEFINER`, `search_path` pinned to
`pg_catalog, pg_temp`, every name schema-qualified, EXECUTE revoked from PUBLIC
and granted to `meridian_app` (the worker runs the api image and connects as the
same role):

* `app.authorize_job(run, org, actor_type, actor_id, process, from_states,
  versions)` — one row: `(authorized, reason, current_state)`. `reason` is a
  code (`run_not_found`, `actor_mismatch`, `actor_not_member`,
  `client_inactive`, `actor_unknown`, `process_mismatch`, `state_not_allowed`,
  `inputs_mismatch`), never a value; it is what goes on the DLQ message. A run
  in another organization is `run_not_found`, the same answer as a run that
  does not exist, so the function cannot be used to probe other tenants.
* `app.claim_run(run, org, owner, lease_seconds, job_id)` — the lease. Zero rows
  back means somebody else holds a live lease (or the run is terminal) and the
  worker must not run.
* `app.expire_stale_runs(dry_run)` — the sweeper (task D5 calls it).

THE OWNER IS A NOLOGIN ROLE, NOT THE MIGRATOR
---------------------------------------------
The same pitfall revision 0013 documents: `FORCE` applies to the table owner,
so a definer function owned by the migration role would see nothing. The
functions are owned by `meridian_job_control`, created here `NOLOGIN
NOSUPERUSER NOBYPASSRLS`, which holds:

* a COLUMN-level SELECT on the `process_runs` columns the three functions read
  and a column-level UPDATE on the ones `claim_run` / `expire_stale_runs`
  write (the lease columns, `state`, `run_state`, `error`, `updated_at`);
* a column-level SELECT on `org_members (org_id, user_id)`;
* one policy per table that applies TO THAT ROLE ONLY (`USING (true)`), so the
  bypass is the width of three reviewed functions and no session.

The migrator becomes a member of the role only to hand ownership over, and with
`INHERIT FALSE`: an inheriting member would pick up those `USING (true)`
policies in its own sessions (RLS applies a policy to the members of its role),
which would quietly undo `FORCE` for the owner — the load-order guarantee in
`docs/runbooks/migrations.md` depends on the owner seeing nothing.

THE MACHINE-CLIENT ACTOR (Phase 12 R17)
---------------------------------------
`authorize_job` accepts `actor_type = 'client'`: the run's
`created_by_client_id` must be the client and `api_clients` must hold an
`active` row for it in the same org. Both of those arrive in revision
`0013_api_platform`, which comes AFTER this one, so this function reads them in
a branch that runs only once `public.api_clients` exists (PL/pgSQL plans a
statement the first time it runs, not at CREATE time), and 0013 grants
`meridian_job_control` the columns and the SELECT policy that branch needs.
Before 0013 a client actor is refused as `actor_unknown`.

INPUTS
------
The message's `input_object_versions` must equal, as a multiset of
`{bucket_role, key, version_id, sha256}`, the list the api recorded in
`process_runs.inputs -> 'object_versions'` (task C1 writes it). Today no run
records any, and a message with none matches a run with none.

DOWNGRADE
---------
Supported: drops the functions, the policies, the grants, the role and the four
columns (their values are lost, which is the point of a downgrade; nothing
outside the worker reads them).
"""

from __future__ import annotations

from alembic import op

revision = "0011_process_runs_worker"
down_revision = "0010_superadmin_org_list"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
CONTROL_ROLE = "meridian_job_control"

#: A run that has failed this many claims of one job with its lease lapsing each
#: time is abandoned by the sweeper. Equal to the queue's maxReceiveCount
#: (plan §3.5), so the DLQ and the run agree on when a job is dead.
MAX_ATTEMPTS = 3

#: Longest lease one claim may take: SQS's maximum visibility timeout.
MAX_LEASE_SECONDS = 43_200

#: `process_runs` columns the functions read, and the ones they write.
READ_COLUMNS = (
    "run_id",
    "org_id",
    "process",
    "state",
    "created_by",
    "inputs",
    "run_state",
    "expires_at",
    "lease_owner",
    "lease_expires_at",
    "attempts",
    "last_job_id",
)
WRITE_COLUMNS = (
    "state",
    "run_state",
    "error",
    "updated_at",
    "lease_owner",
    "lease_expires_at",
    "attempts",
    "last_job_id",
)

FUNCTION_SIGNATURES = (
    "app.authorize_job(uuid, uuid, text, uuid, text, text[], jsonb)",
    "app.claim_run(uuid, uuid, text, integer, text)",
    "app.expire_stale_runs(boolean)",
)

LEASE_COLUMNS = f"""
ALTER TABLE public.process_runs
    ADD COLUMN lease_owner      text,
    ADD COLUMN lease_expires_at timestamptz,
    ADD COLUMN attempts         integer NOT NULL DEFAULT 0,
    ADD COLUMN last_job_id      text,
    ADD CONSTRAINT process_runs_lease_owner_check
        CHECK (lease_owner IS NULL OR char_length(lease_owner) BETWEEN 1 AND 200),
    ADD CONSTRAINT process_runs_attempts_check CHECK (attempts >= 0),
    ADD CONSTRAINT process_runs_last_job_id_check
        CHECK (last_job_id IS NULL OR char_length(last_job_id) BETWEEN 1 AND 64);
COMMENT ON COLUMN public.process_runs.lease_owner IS
    'The worker holding this run (Phase 11, ADR 0030). Set only by app.claim_run.';
COMMENT ON COLUMN public.process_runs.attempts IS
    'Claims of the current job (last_job_id). The sweeper fails a running run '
    'whose lease lapsed after {MAX_ATTEMPTS}.';
-- The sweeper's second question: which working runs lost their worker.
CREATE INDEX idx_process_runs_stale_lease
    ON public.process_runs (lease_expires_at)
    WHERE state IN ('parsing', 'running');
"""

#: `CREATE ROLE` is cluster-wide and has no IF NOT EXISTS (same as 0013).
CREATE_ROLE = f"""
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CONTROL_ROLE}') THEN
        CREATE ROLE {CONTROL_ROLE} NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB
            NOCREATEROLE NOINHERIT;
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input

GRANTS = f"""
GRANT USAGE ON SCHEMA public TO {CONTROL_ROLE};
GRANT SELECT ({", ".join(READ_COLUMNS)}) ON public.process_runs TO {CONTROL_ROLE};
GRANT UPDATE ({", ".join(WRITE_COLUMNS)}) ON public.process_runs TO {CONTROL_ROLE};
GRANT SELECT (org_id, user_id) ON public.org_members TO {CONTROL_ROLE};
CREATE POLICY meridian_job_control_select ON public.process_runs
    FOR SELECT TO {CONTROL_ROLE} USING (true);
CREATE POLICY meridian_job_control_update ON public.process_runs
    FOR UPDATE TO {CONTROL_ROLE} USING (true) WITH CHECK (true);
CREATE POLICY meridian_job_control_select ON public.org_members
    FOR SELECT TO {CONTROL_ROLE} USING (true);
"""

AUTHORIZE_JOB = """
CREATE FUNCTION app.authorize_job(
    p_run_id      uuid,
    p_org_id      uuid,
    p_actor_type  text,
    p_actor_id    uuid,
    p_process     text,
    p_from_states text[],
    p_versions    jsonb
)
RETURNS TABLE (authorized boolean, reason text, current_state text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
DECLARE
    v_run      record;
    v_matches  boolean;
    v_recorded jsonb;
    v_wanted   jsonb;
BEGIN
    SELECT pr.process, pr.state, pr.created_by, pr.inputs
      INTO v_run
      FROM public.process_runs pr
     WHERE pr.run_id = p_run_id
       AND pr.org_id = p_org_id;
    IF NOT FOUND THEN
        -- Missing and "in another org" are one answer: no tenant probing.
        RETURN QUERY SELECT false, 'run_not_found'::text, NULL::text;
        RETURN;
    END IF;

    IF p_actor_type = 'user' THEN
        IF v_run.created_by IS DISTINCT FROM p_actor_id THEN
            RETURN QUERY SELECT false, 'actor_mismatch'::text, NULL::text;
            RETURN;
        END IF;
        -- CX-BE-01 for the worker: still a member NOW, not when the run began.
        IF NOT EXISTS (SELECT 1 FROM public.org_members m
                        WHERE m.org_id = p_org_id AND m.user_id = p_actor_id) THEN
            RETURN QUERY SELECT false, 'actor_not_member'::text, NULL::text;
            RETURN;
        END IF;
    ELSIF p_actor_type = 'client' AND to_regclass('public.api_clients') IS NOT NULL THEN
        -- Planned on first use, so these names need exist only from 0013 on.
        SELECT pr.created_by_client_id = p_actor_id
          INTO v_matches
          FROM public.process_runs pr
         WHERE pr.run_id = p_run_id
           AND pr.org_id = p_org_id;
        IF v_matches IS NOT TRUE THEN
            RETURN QUERY SELECT false, 'actor_mismatch'::text, NULL::text;
            RETURN;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM public.api_clients c
                        WHERE c.id = p_actor_id AND c.org_id = p_org_id
                          AND c.status = 'active') THEN
            RETURN QUERY SELECT false, 'client_inactive'::text, NULL::text;
            RETURN;
        END IF;
    ELSE
        RETURN QUERY SELECT false, 'actor_unknown'::text, NULL::text;
        RETURN;
    END IF;

    IF v_run.process IS DISTINCT FROM p_process THEN
        RETURN QUERY SELECT false, 'process_mismatch'::text, NULL::text;
        RETURN;
    END IF;

    IF p_from_states IS NULL OR NOT (v_run.state = ANY (p_from_states)) THEN
        RETURN QUERY SELECT false, 'state_not_allowed'::text, NULL::text;
        RETURN;
    END IF;

    v_recorded := COALESCE(v_run.inputs -> 'object_versions', '[]'::jsonb);
    IF p_versions IS NULL OR jsonb_typeof(p_versions) <> 'array'
       OR jsonb_typeof(v_recorded) <> 'array' THEN
        RETURN QUERY SELECT false, 'inputs_mismatch'::text, NULL::text;
        RETURN;
    END IF;
    -- Compared as multisets of the four identifying fields, in a fixed order.
    SELECT COALESCE(jsonb_agg(x ORDER BY x), '[]'::jsonb) INTO v_recorded
      FROM (SELECT jsonb_build_object('bucket_role', e ->> 'bucket_role', 'key', e ->> 'key',
                                      'version_id', e ->> 'version_id', 'sha256', e ->> 'sha256') AS x
              FROM jsonb_array_elements(v_recorded) AS e) AS s;
    SELECT COALESCE(jsonb_agg(x ORDER BY x), '[]'::jsonb) INTO v_wanted
      FROM (SELECT jsonb_build_object('bucket_role', e ->> 'bucket_role', 'key', e ->> 'key',
                                      'version_id', e ->> 'version_id', 'sha256', e ->> 'sha256') AS x
              FROM jsonb_array_elements(p_versions) AS e) AS s;
    IF v_recorded IS DISTINCT FROM v_wanted THEN
        RETURN QUERY SELECT false, 'inputs_mismatch'::text, NULL::text;
        RETURN;
    END IF;

    RETURN QUERY SELECT true, NULL::text, v_run.state::text;
END
$fn$;
COMMENT ON FUNCTION app.authorize_job(uuid, uuid, text, uuid, text, text[], jsonb) IS
    'Phase 11 D2 / ADR 0029: may this queue message run? Read BEFORE any tenant context. '
    'Returns a reason code, never a value.';
"""

CLAIM_RUN = f"""
CREATE FUNCTION app.claim_run(
    p_run_id        uuid,
    p_org_id        uuid,
    p_owner         text,
    p_lease_seconds integer,
    p_job_id        text
)
RETURNS TABLE (claimed_attempts integer, claimed_until timestamptz)
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF p_owner IS NULL OR char_length(p_owner) NOT BETWEEN 1 AND 200 THEN
        RAISE EXCEPTION 'claim_run: owner must be 1-200 characters'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_lease_seconds IS NULL OR p_lease_seconds NOT BETWEEN 1 AND {MAX_LEASE_SECONDS} THEN
        RAISE EXCEPTION 'claim_run: lease must be 1-{MAX_LEASE_SECONDS} seconds'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_job_id IS NULL OR char_length(p_job_id) NOT BETWEEN 1 AND 64 THEN
        RAISE EXCEPTION 'claim_run: job id must be 1-64 characters'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;

    -- One statement: the row lock makes two claimers race to exactly one
    -- winner; the loser re-checks the WHERE against the winner's lease and
    -- gets no row.
    RETURN QUERY
    UPDATE public.process_runs pr
       SET lease_owner      = p_owner,
           lease_expires_at = now() + make_interval(secs => p_lease_seconds),
           attempts         = CASE WHEN pr.last_job_id = p_job_id
                                   THEN pr.attempts + 1 ELSE 1 END,
           last_job_id      = p_job_id,
           updated_at       = now()
     WHERE pr.run_id = p_run_id
       AND pr.org_id = p_org_id
       AND pr.state NOT IN ('completed', 'failed', 'expired', 'superseded')
       AND (pr.lease_expires_at IS NULL OR pr.lease_expires_at < now())
    RETURNING pr.attempts, pr.lease_expires_at;
END
$fn$;
COMMENT ON FUNCTION app.claim_run(uuid, uuid, text, integer, text) IS
    'Phase 11 D2 / ADR 0030: take the lease on a run. No row back = not yours.';
"""  # noqa: S608 DDL from module constants; no runtime input

_FAILED_ERROR = (
    "jsonb_build_object('code', 'RUN_FAILED', 'message', "
    f"'The run stopped responding and was abandoned after {MAX_ATTEMPTS} attempts.')"
)

EXPIRE_STALE_RUNS = f"""
CREATE FUNCTION app.expire_stale_runs(p_dry_run boolean DEFAULT false)
RETURNS TABLE (swept_run_id uuid, swept_org_id uuid, from_state text, to_state text)
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
DECLARE
    v_state text;
BEGIN
    IF p_dry_run THEN
        RETURN QUERY
        SELECT pr.run_id, pr.org_id, pr.state, 'expired'::text
          FROM public.process_runs pr
         WHERE pr.state IN ('draft', 'needs_input') AND pr.expires_at < now()
        UNION ALL
        SELECT pr.run_id, pr.org_id, pr.state, 'failed'::text
          FROM public.process_runs pr
         WHERE pr.state IN ('parsing', 'running') AND pr.lease_expires_at < now()
           AND pr.attempts >= {MAX_ATTEMPTS};
        RETURN;
    END IF;

    -- Abandoned wizards: expired, and the one-run-only roster answers go with
    -- them (the clear_run_overrides contract, 975d5db).
    FOREACH v_state IN ARRAY ARRAY['draft', 'needs_input'] LOOP
        RETURN QUERY
        UPDATE public.process_runs pr
           SET state            = 'expired',
               run_state        = pr.run_state - 'run_overrides',
               lease_owner      = NULL,
               lease_expires_at = NULL,
               updated_at       = now()
         WHERE pr.state = v_state AND pr.expires_at < now()
        RETURNING pr.run_id, pr.org_id, v_state, 'expired'::text;
    END LOOP;

    -- Lost workers: the lease lapsed on the last attempt the queue will make.
    FOREACH v_state IN ARRAY ARRAY['parsing', 'running'] LOOP
        RETURN QUERY
        UPDATE public.process_runs pr
           SET state            = 'failed',
               run_state        = pr.run_state - 'run_overrides',
               error            = {_FAILED_ERROR},
               lease_owner      = NULL,
               lease_expires_at = NULL,
               updated_at       = now()
         WHERE pr.state = v_state
           AND pr.lease_expires_at < now()
           AND pr.attempts >= {MAX_ATTEMPTS}
        RETURNING pr.run_id, pr.org_id, v_state, 'failed'::text;
    END LOOP;
END
$fn$;
COMMENT ON FUNCTION app.expire_stale_runs(boolean) IS
    'Phase 11 D2/D5: the TTL sweeper. Cross-org by design; returns ids and states only.';
"""  # noqa: S608 DDL from module constants; no runtime input

#: Grants first, while the migrator still owns the functions: once ownership
#: has moved, a REVOKE by the (non-inheriting) migrator is a silent no-op and
#: PUBLIC would keep EXECUTE. Then hand the functions to the control role. The
#: migrator must be able to SET ROLE to the new owner (a member with SET, but
#: NOT inheriting — see the docstring), and the owner needs CREATE on `app`
#: while ownership moves.
OWNERSHIP = f"""
{"".join(f"REVOKE ALL ON FUNCTION {sig} FROM PUBLIC;{chr(10)}" for sig in FUNCTION_SIGNATURES)}
{"".join(f"GRANT EXECUTE ON FUNCTION {sig} TO {APP_ROLE};{chr(10)}" for sig in FUNCTION_SIGNATURES)}
GRANT {CONTROL_ROLE} TO CURRENT_USER WITH INHERIT FALSE, SET TRUE;
GRANT USAGE, CREATE ON SCHEMA app TO {CONTROL_ROLE};
{"".join(f"ALTER FUNCTION {sig} OWNER TO {CONTROL_ROLE};{chr(10)}" for sig in FUNCTION_SIGNATURES)}
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""


def upgrade() -> None:
    op.execute(LEASE_COLUMNS)
    op.execute(CREATE_ROLE)
    op.execute(GRANTS)
    op.execute(AUTHORIZE_JOB)
    op.execute(CLAIM_RUN)
    op.execute(EXPIRE_STALE_RUNS)
    op.execute(OWNERSHIP)


def downgrade() -> None:
    # Dropping a function takes its owner's privileges; the migrator's
    # membership does not inherit them, so SET ROLE for the drop itself.
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CONTROL_ROLE}') THEN
                EXECUTE 'SET ROLE {CONTROL_ROLE}';
                {"".join(f"DROP FUNCTION IF EXISTS {sig};" for sig in FUNCTION_SIGNATURES)}
                RESET ROLE;
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(
        """
        DROP POLICY IF EXISTS meridian_job_control_select ON public.org_members;
        DROP POLICY IF EXISTS meridian_job_control_update ON public.process_runs;
        DROP POLICY IF EXISTS meridian_job_control_select ON public.process_runs;
        DROP INDEX IF EXISTS public.idx_process_runs_stale_lease;
        ALTER TABLE public.process_runs
            DROP COLUMN IF EXISTS last_job_id,
            DROP COLUMN IF EXISTS attempts,
            DROP COLUMN IF EXISTS lease_expires_at,
            DROP COLUMN IF EXISTS lease_owner;
        """
    )
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CONTROL_ROLE}') THEN
                REVOKE ALL ON public.process_runs FROM {CONTROL_ROLE};
                REVOKE ALL ON public.org_members FROM {CONTROL_ROLE};
                REVOKE ALL ON SCHEMA app FROM {CONTROL_ROLE};
                REVOKE ALL ON SCHEMA public FROM {CONTROL_ROLE};
                DROP ROLE {CONTROL_ROLE};
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
