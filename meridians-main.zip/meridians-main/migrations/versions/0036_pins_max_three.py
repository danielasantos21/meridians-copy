"""pins_max_three — a sidebar pins at most 3 processes (was 6).

Revision ID: 0036_pins_max_three
Revises: 0035_superadmin_control

Owner's decision, 2026-10-01: the sidebar holds 3 pinned processes; the rest
live on "All processes". Any stored list longer than 3 keeps its first 3 keys
(the order is the sidebar order, so those are the ones the person put first),
then both CHECKs tighten. `src.process_pins.MAX_PINS` says the same.
"""

from __future__ import annotations

from alembic import op

revision = "0036_pins_max_three"
down_revision = "0035_superadmin_control"
branch_labels = None
depends_on = None

ORG_TABLE = "public.org_process_pins"
USER_TABLE = "public.user_process_pins"
# Postgres names an unnamed column CHECK `<table>_<column>_check`.
ORG_CHECK = "org_process_pins_process_keys_check"
USER_CHECK = "user_process_pins_process_keys_check"


def _limit(n: int) -> str:
    return f"""
UPDATE {ORG_TABLE} SET process_keys = process_keys[1:{n}] WHERE cardinality(process_keys) > {n};
UPDATE {USER_TABLE} SET process_keys = process_keys[1:{n}] WHERE cardinality(process_keys) > {n};
ALTER TABLE {ORG_TABLE} DROP CONSTRAINT {ORG_CHECK};
ALTER TABLE {ORG_TABLE} ADD CONSTRAINT {ORG_CHECK}
    CHECK (cardinality(process_keys) BETWEEN 1 AND {n});
ALTER TABLE {USER_TABLE} DROP CONSTRAINT {USER_CHECK};
ALTER TABLE {USER_TABLE} ADD CONSTRAINT {USER_CHECK}
    CHECK (cardinality(process_keys) <= {n});
"""


def upgrade() -> None:
    op.execute(_limit(3))


def downgrade() -> None:
    # Widening never needs a trim; the UPDATEs match no row at 6.
    op.execute(_limit(6))
