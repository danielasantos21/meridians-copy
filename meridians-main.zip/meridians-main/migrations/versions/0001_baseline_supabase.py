"""baseline_supabase — replay the 37 Supabase migration files verbatim.

Revision ID: 0001_baseline_supabase
Revises: None
Create Date: 2026-09-15

WHAT THIS DOES
--------------
It reads `supabase_migrations/migrations/*.sql` **at runtime**, in filename
order, and executes each file's text unchanged. The SQL is not copied into this
file: the folder is the history (see `supabase_migrations/README.md`), and a
copy would be a second source of truth that silently drifts from the first.

Filename order, not numeric order, because two files share the prefix `013`
(`013_not_null_org_id_unique_constraints.sql` sorts before
`013_wearbly_uniforms.sql`, `n` < `w`) and that is the order the live database
was actually built in.

THE `auth` PREAMBLE
-------------------
Supabase ships an `auth` schema. The 37 files lean on it in two ways: 14
`REFERENCES auth.users(id)` foreign keys (including `superadmins.user_id`,
which is also that table's primary key) and 22 calls to `auth.uid()` inside RLS
policies. On a bare PostgreSQL those statements fail, so the preamble creates
the smallest thing that makes them resolve:

    CREATE SCHEMA auth;
    CREATE TABLE auth.users (id uuid PRIMARY KEY);
    CREATE FUNCTION auth.uid() RETURNS uuid ...  -- returns NULL

This shim exists ONLY so the replay is faithful. Revision 0003 drops the FKs
and the `auth.users` table.

THE SKIP ALLOWLIST
------------------
Two kinds of skip, both recorded in `migrations/baseline/SKIPPED.md`:

* `SKIP_FILES` — whole files that only make sense on Supabase.
* `SKIP_STATEMENTS` — statement-level regexes (optionally scoped to one file)
  and extensions. **No file in today's 37 matches any of these**; they are the
  documented rule, kept so a future addition to the folder cannot smuggle an
  `anon` grant into RDS unnoticed. A file is executed byte-for-byte unless one
  of these patterns matches somewhere in its text; only then is it split into
  statements and filtered.

SKIPPED, IN FULL (every statement, as of 2026-09-15):

  003_storage_buckets.sql — all 5 statements. Supabase Storage only.
    1. INSERT INTO storage.buckets ... ('uploads', 'uploads', false)
    2. INSERT INTO storage.buckets ... ('outputs', 'outputs', false)
    3. INSERT INTO storage.buckets ... ('templates', 'templates', false)
    4. CREATE POLICY "Org members can access their uploads" ON storage.objects
    5. CREATE POLICY "Authenticated users can read templates" ON storage.objects

  011_bkv5_location_remap.sql -- 1 statement, the 25-row INSERT (see the
    pattern's reason below). Schema is untouched; the rows are a seed.

  Nothing else is skipped. There are no `CREATE EXTENSION`, `GRANT ... TO
  anon|authenticated|service_role` or `ALTER DEFAULT PRIVILEGES` statements in
  the 37 files (verified by grep, 2026-09-15).

DOWNGRADE
---------
Not supported. A downgrade of a baseline means "drop the entire schema", which
is `DROP SCHEMA public CASCADE` — an operation nobody should be able to trigger
by typing `alembic downgrade`. Rebuild from empty instead; staging is rebuilt
from empty every session (D-15) precisely so this chain stays proven.
"""

from __future__ import annotations

import pathlib
import re

from alembic import op

revision = "0001_baseline_supabase"
down_revision = None
branch_labels = None
depends_on = None

#: The folder this revision replays. Resolved relative to this file so it works
#: from any working directory.
BASELINE_DIR = pathlib.Path(__file__).resolve().parents[2] / "supabase_migrations" / "migrations"

#: Files skipped whole, with the reason. See the docstring and SKIPPED.md.
SKIP_FILES: dict[str, str] = {
    "003_storage_buckets.sql": (
        "Supabase Storage only: inserts into storage.buckets and two policies "
        "on storage.objects. RDS has no storage schema; S3 replaces it "
        "(plan step 7, src/storage.py S3StorageManager)."
    ),
}

#: Statement-level skips: (filename or None for "any file", regex, reason).
#: A regex is matched against each statement with `re.MULTILINE`, so `^`
#: anchors to a line start (a statement usually begins with a comment line).
#:
#: Every regex here is also used as the FILE-level trigger that decides whether
#: a file is executed verbatim or statement by statement, and there it is
#: matched against the whole file. So no `.*?` may cross a `;`: `[^;]*?` keeps
#: a match inside one statement, and without it a file containing an innocent
#: `GRANT ... TO meridian_app;` followed much later by the word `authenticated`
#: matched as though one statement held both.
SKIP_STATEMENTS: list[tuple[str | None, re.Pattern[str], str]] = [
    (
        None,
        re.compile(r"^\s*create\s+extension\b", re.IGNORECASE | re.MULTILINE),
        "Supabase pre-provisions extensions; on RDS they are installed by the "
        "parameter group and rds_superuser, not by a migration. (No file in "
        "today's 37 matches -- this is the standing rule.)",
    ),
    (
        None,
        re.compile(
            r"^\s*grant\b[^;]*?\bto\b[^;]*?\b(anon|authenticated|service_role)\b",
            re.IGNORECASE | re.DOTALL | re.MULTILINE,
        ),
        "Supabase's PostgREST roles do not exist on RDS; meridian_app and "
        "phi_access replace them (revision 0003). (No file matches today.)",
    ),
    (
        None,
        re.compile(
            r"^\s*alter\s+default\s+privileges\b[^;]*?\b(anon|authenticated|service_role)\b",
            re.IGNORECASE | re.DOTALL | re.MULTILINE,
        ),
        "Same: default privileges for PostgREST roles. (No file matches today.)",
    ),
    (
        None,
        re.compile(
            r"^\s*(insert\s+into|create\s+policy[^;]*?\bon)\s+storage\.",
            re.IGNORECASE | re.MULTILINE,
        ),
        "Supabase Storage buckets/objects. (003 is skipped whole; this catches "
        "any future file that touches storage.)",
    ),
    (
        "011_bkv5_location_remap.sql",
        re.compile(
            r"^\s*insert\s+into\s+public\.bkv5_location_remap\b",
            re.IGNORECASE | re.MULTILINE,
        ),
        "Tenant data, not schema. 011 inserts 25 rows with no org_id; the "
        "backfill that gives them one was moved to supabase_migrations/seeds/ "
        "in Phase 0 because it names a tenant. Replaying the INSERT without "
        "that backfill makes 012's `ALTER COLUMN org_id SET NOT NULL` fail on "
        "a fresh database. 012's own comment assumes the table is empty at "
        "that point -- true only once this INSERT is skipped. A fresh database "
        "gets these rows from the seed, like every other tenant row.",
    ),
    (
        "014_rls_with_check_user_org_id_fix.sql",
        re.compile(
            r"\b(alter\s+table|create\s+policy|drop\s+policy)\b[^;]*?\bpublic\.(clients|invoices)\b",
            re.IGNORECASE | re.DOTALL | re.MULTILINE,
        ),
        "Order, not intent. `public.clients` and `public.invoices` were created "
        "ad hoc outside this folder; 015 transcribes them with CREATE TABLE IF "
        "NOT EXISTS. Live, 014 ran when they already existed. On a replay from "
        "empty 014 runs BEFORE 015 creates them, so these statements error. "
        "Revision 0002 re-applies exactly what is skipped here, after 015 has "
        "created the tables -- which is what live looks like.",
    ),
]

#: The expected number of files. A mismatch means the closed history changed,
#: which `supabase_migrations/README.md` says is a bug.
EXPECTED_FILE_COUNT = 37

#: Files `main` added to the folder AFTER this history closed. Production still
#: runs on Supabase through the dual-maintenance window (plan §7), so main keeps
#: shipping `supabase_migrations/` files and they arrive here by merge. They are
#: never replayed by this revision -- that would change what the baseline means.
#: Each names what carries it on RDS. A file in the folder that is neither one
#: of the closed 37 nor listed here stops the migration: a new Supabase migration
#: on main needs its Alembic twin (and a line here) before it can merge.
POST_CLOSURE_FILES: dict[str, str] = {
    "037_qb_usa_employee_qb_name.sql": "0002_reconcile_live_drift (qb_usa_employee.qb_name)",
    "038_mx_payroll_column_map_seed.sql": (
        "nothing: data only (each org's default MX column -> account rows); the "
        "rows come across with the data at cutover"
    ),
    "039_qb_usa_employee_adp_codes.sql": "0002_reconcile_live_drift (qb_usa_employee.adp_*)",
    "040_role_permission_processes.sql": (
        "0047_access_items (CI parity twin of the widened role_permissions CHECK; "
        "never applied to any database)"
    ),
}

AUTH_PREAMBLE = """
CREATE SCHEMA IF NOT EXISTS auth;

-- Shim, not a real user store. Revision 0003 drops it together with the 14
-- foreign keys that point at it.
CREATE TABLE IF NOT EXISTS auth.users (id uuid PRIMARY KEY);

-- Supabase reads the JWT; here it resolves to NULL so the 22 policies that
-- call it parse and create. Revision 0003 gives it a body that reads
-- `app.user_id`, set by the application.
CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $shim$ SELECT NULL::uuid $shim$;
"""


def _split_statements(sql: str) -> list[str]:
    """Split a SQL script on `;`, respecting `$tag$ ... $tag$` dollar quoting
    and single-quoted literals. Only used for files that match a statement-level
    skip pattern; every other file is executed verbatim.
    """
    out: list[str] = []
    buf: list[str] = []
    i = 0
    n = len(sql)
    dollar_tag: str | None = None
    in_squote = False
    in_line_comment = False
    in_block_comment = False
    while i < n:
        ch = sql[i]
        two = sql[i : i + 2]
        if in_line_comment:
            if ch == "\n":
                in_line_comment = False
            buf.append(ch)
            i += 1
            continue
        if in_block_comment:
            buf.append(ch)
            if two == "*/":
                buf.append(sql[i + 1])
                i += 2
                in_block_comment = False
                continue
            i += 1
            continue
        if dollar_tag is not None:
            if sql.startswith(dollar_tag, i):
                buf.append(dollar_tag)
                i += len(dollar_tag)
                dollar_tag = None
                continue
            buf.append(ch)
            i += 1
            continue
        if in_squote:
            buf.append(ch)
            if ch == "'":
                in_squote = sql[i + 1 : i + 2] == "'"
                if in_squote:
                    buf.append("'")
                    i += 1
            i += 1
            continue
        if two == "--":
            in_line_comment = True
            buf.append(two)
            i += 2
            continue
        if two == "/*":
            in_block_comment = True
            buf.append(two)
            i += 2
            continue
        if ch == "'":
            in_squote = True
            buf.append(ch)
            i += 1
            continue
        if ch == "$":
            m = re.match(r"\$[A-Za-z_][A-Za-z_0-9]*\$|\$\$", sql[i:])
            if m:
                dollar_tag = m.group(0)
                buf.append(dollar_tag)
                i += len(dollar_tag)
                continue
        if ch == ";":
            out.append("".join(buf))
            buf = []
            i += 1
            continue
        buf.append(ch)
        i += 1
    tail = "".join(buf)
    if tail.strip():
        out.append(tail)
    return [s for s in out if s.strip()]


def _is_only_comment(stmt: str) -> bool:
    """True when a chunk the splitter produced is nothing but comments.

    A trailing comment block after the last `;` is a statement to `str.split`
    and an empty query to psycopg2.
    """
    body = re.sub(r"/\*.*?\*/", " ", stmt, flags=re.DOTALL)
    body = re.sub(r"--[^\n]*", " ", body)
    return not body.strip()


def _rules_for(filename: str) -> list[tuple[re.Pattern[str], str]]:
    return [(rx, why) for who, rx, why in SKIP_STATEMENTS if who in (None, filename)]


def upgrade() -> None:
    files = sorted(p for p in BASELINE_DIR.glob("*.sql") if p.name not in POST_CLOSURE_FILES)
    if len(files) != EXPECTED_FILE_COUNT:
        raise RuntimeError(
            f"{BASELINE_DIR} holds {len(files)} .sql files outside POST_CLOSURE_FILES, "
            f"expected {EXPECTED_FILE_COUNT}. That history is closed "
            "(supabase_migrations/README.md); a change here means the replay no "
            "longer reproduces the schema production was built from. A new file "
            "from main needs an Alembic revision and a POST_CLOSURE_FILES entry."
        )

    op.execute(AUTH_PREAMBLE)

    for path in files:
        if path.name in SKIP_FILES:
            continue
        sql = path.read_text()
        rules = _rules_for(path.name)
        if not any(rx.search(sql) for rx, _ in rules):
            op.execute(sql)  # verbatim, one script, untouched
            continue
        for stmt in _split_statements(sql):
            if _is_only_comment(stmt):
                continue
            if any(rx.search(stmt) for rx, _ in rules):
                continue
            op.execute(stmt)


def downgrade() -> None:
    raise NotImplementedError(
        "0001 is a baseline; it has no downgrade. Undoing it means dropping the "
        "whole schema. Rebuild the database from empty instead."
    )
