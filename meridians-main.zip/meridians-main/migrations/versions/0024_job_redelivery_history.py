"""job_redelivery_history — finished-run jobs are redelivered, settled jobs are remembered.

Revision ID: 0024_job_redelivery_history
Revises: 0023_qbo_token_envelope
Create Date: 2026-09-24

Phase 11 E2 open items (`docs/reports/phase-11-plan.md` §4 E2, deviations 8
and 9). ADR 0011 (tenant isolation), ADR 0028 (one `run_job`, two transports),
ADR 0030 (leases), ADR 0032 (the push ledger). RDS-only: Supabase never runs
Alembic, and nothing on Render calls any of this.

WHY
---
Two gaps E2 left, both about a job that acts on a FINISHED run (`qbo_push` on
a `completed` run, claimed through 0018's `app.claim_post_completion`):

1. **An in-process push killed with its api process was never redelivered.**
   0022's `app.redeliverable_jobs` answers runs in a working state
   (`parsing`/`running`) and queued jobs on UNFINISHED runs only, so a push
   whose process died — its lease lapsed on a `completed` run, or its queued
   marker (0022's second case) sat on a `completed` run — was nobody's to
   deliver again. On SQS the visibility timeout redelivers it; in-process
   nothing did. The function now also answers a `completed` run whose job was
   claimed 1-2 times and whose lease lapsed, and a queued, never-claimed job on
   a `completed` run past the grace. Only a post-completion job can hold either
   on a `completed` run: `claim_run` refuses terminal runs, and every settle
   clears the lease to NULL/NULL, so a lease or a queued marker on a finished
   run is always such a job's. `POST_COMPLETION_STATES` below is the state list
   0018's allowlist leases (`tests/test_job_redelivery_history_pg.py` holds the
   two, and the manifests, equal). At 3 claims the run is left alone, as for a
   working run (SQS's maxReceiveCount 3; the push's DLQ alarm).

2. **A late duplicate of a run's execute message raised a DLQ alarm.** The
   worker acknowledges a redelivery of a job that already settled the run (it
   reads `last_job_id` = this job and the lease NULL/NULL). After a push,
   though, `last_job_id` names the PUSH job, so a late copy of the execute
   message was dead-lettered `state_not_allowed` — booking nothing, but paging
   someone. New column `process_runs.settled_job_ids`: the ids of the last
   `MAX_SETTLED_JOB_IDS` jobs that settled the run, newest first, appended by
   the worker's settle in the same fenced UPDATE (`workers/run_job._settle`). A
   delivery whose job id is in it is a duplicate and is acknowledged.

WHAT CHANGES
------------
* `process_runs.settled_job_ids text[] NOT NULL DEFAULT '{}'`, bounded by a
  CHECK (at most `MAX_SETTLED_JOB_IDS` entries). Job ids only — no amounts, no
  names. `meridian_app` writes it through its existing table-level grants; the
  api's run store never names it (it is not in `WRITABLE_COLUMNS`). The control
  role gets no grant on it: no definer reads it.
* `app.redeliverable_jobs` replaced in place (same signature, same answer
  columns): 0022's queued branch no longer excludes `completed`, and a new
  branch answers lapsed leases on `completed` runs, reading a new partial index
  `idx_process_runs_finished_lease` (a finished run WITH a lease expiry: only
  runs whose post-completion job is in flight, released or lost — a settle
  leaves NULL).

HOW THE FUNCTION IS REPLACED
----------------------------
0020's way: the function belongs to `meridian_job_control` and the migrator's
membership in it is `INHERIT FALSE, SET TRUE` (0011), so `CREATE OR REPLACE`
runs under `SET ROLE` to the owner, with a transient `CREATE` on schema `app`
(which `CREATE OR REPLACE` requires), revoked again at once. The owner and
0022's EXECUTE grants (PUBLIC revoked, `meridian_app` granted) are kept. The
migrator gains no inheriting membership
(`tests/test_migrations.py::test_the_migrator_inherits_no_role_the_chain_granted_it`).

DOWNGRADE
---------
Supported: puts 0022's body back, drops the index, the CHECK and the column.
The column holds job ids only; without it a late duplicate is dead-lettered
again, exactly as before this revision.
"""

from __future__ import annotations

from alembic import op

revision = "0024_job_redelivery_history"
down_revision = "0023_qbo_token_envelope"
branch_labels = None
depends_on = None

CONTROL_ROLE = "meridian_job_control"

#: 0022's values, repeated because a migration never imports another one.
MAX_ATTEMPTS = 3
MAX_GRACE_SECONDS = 86_400
MAX_LIMIT = 1_000

#: The finished states a post-completion job starts from: the states of 0018's
#: `POST_COMPLETION` (kind, state) pairs.
POST_COMPLETION_STATES = ("completed",)

#: Settled job ids kept per run. A run settles a handful of jobs (a parse or
#: two, an execute, a few pushes); twenty is ample and bounded.
MAX_SETTLED_JOB_IDS = 20

SIGNATURE = "app.redeliverable_jobs(integer, integer)"
INDEX = "idx_process_runs_finished_lease"
CHECK = "process_runs_settled_job_ids_bounded"

_FINISHED = ", ".join(f"'{state}'" for state in POST_COMPLETION_STATES)
#: 0022's queued branch skipped every terminal state; now only the ones no job
#: may start from.
_NEVER_STARTED_FROM = ", ".join(
    f"'{state}'"
    for state in ("completed", "failed", "expired", "superseded")
    if state not in POST_COMPLETION_STATES
)

COLUMN = f"""
ALTER TABLE public.process_runs
    ADD COLUMN settled_job_ids text[] NOT NULL DEFAULT '{{}}'::text[];
ALTER TABLE public.process_runs
    ADD CONSTRAINT {CHECK} CHECK (cardinality(settled_job_ids) <= {MAX_SETTLED_JOB_IDS});
COMMENT ON COLUMN public.process_runs.settled_job_ids IS
    'Phase 11 E2 follow-up: ids of the last {MAX_SETTLED_JOB_IDS} jobs that settled this run, '
    'newest first. A redelivered message naming one is a duplicate. Job ids only.';
CREATE INDEX {INDEX}
    ON public.process_runs (lease_expires_at)
    WHERE state IN ({_FINISHED}) AND lease_expires_at IS NOT NULL;
"""  # noqa: S608 DDL from module constants; no runtime input

_HEAD = f"""
CREATE OR REPLACE FUNCTION app.redeliverable_jobs(
    p_queued_grace_seconds integer,
    p_limit                integer
)
RETURNS TABLE (
    job_run_id    uuid,
    job_org_id    uuid,
    job_process   text,
    job_state     text,
    job_id        text,
    job_attempts  integer
)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF p_queued_grace_seconds IS NULL
       OR p_queued_grace_seconds NOT BETWEEN 0 AND {MAX_GRACE_SECONDS} THEN
        RAISE EXCEPTION 'redeliverable_jobs: grace must be 0-{MAX_GRACE_SECONDS} seconds'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_limit IS NULL OR p_limit NOT BETWEEN 1 AND {MAX_LIMIT} THEN
        RAISE EXCEPTION 'redeliverable_jobs: limit must be 1-{MAX_LIMIT}'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
"""  # noqa: S608 DDL from module constants; no runtime input

_END = """
     ORDER BY r.lease_expires_at, r.run_id
     LIMIT p_limit;
END
$fn$;
"""

_COMMENT = f"""
COMMENT ON FUNCTION {SIGNATURE} IS
    'Phase 11 D4 / E2: jobs no live worker holds - killed mid-job (a lapsed lease, fewer than '
    '{MAX_ATTEMPTS} claims; on a finished run, a post-completion job) or queued and never '
    'claimed - for the in-process transport to deliver again. Cross-org by design; returns '
    'ids and states only.';
"""

#: 0022's comment, word for word, for the downgrade.
_PREVIOUS_COMMENT = f"""
COMMENT ON FUNCTION {SIGNATURE} IS
    'Phase 11 D4: jobs no live worker holds - killed mid-job (a lapsed lease, fewer than '
    '{MAX_ATTEMPTS} claims) or queued and never claimed - for the in-process transport to '
    'deliver again. Cross-org by design; returns ids and states only.';
"""

#: 0024's body: 0022's two branches (the queued one no longer skipping the
#: finished states a post-completion job starts from) and a third for a
#: post-completion job's lapsed lease. One partial index per branch.
_BRANCHES = f"""
    -- Cross-org by design; ids and states only. Each branch reads one partial
    -- index (0011's idx_process_runs_stale_lease, 0024's
    -- idx_process_runs_finished_lease, 0022's idx_process_runs_queued_job).
    RETURN QUERY
    SELECT r.run_id, r.org_id, r.process, r.state, r.last_job_id, r.attempts
      FROM (
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.state IN ('parsing', 'running')
           AND pr.lease_expires_at < now()
           AND pr.last_job_id IS NOT NULL
           AND pr.attempts BETWEEN 1 AND {MAX_ATTEMPTS - 1}
        UNION ALL
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.state IN ({_FINISHED})
           AND pr.lease_expires_at < now()
           AND pr.last_job_id IS NOT NULL
           AND pr.attempts BETWEEN 1 AND {MAX_ATTEMPTS - 1}
        UNION ALL
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.attempts = 0
           AND pr.last_job_id IS NOT NULL
           AND pr.lease_owner IS NULL
           AND pr.state NOT IN ({_NEVER_STARTED_FROM})
           AND pr.lease_expires_at < now() - make_interval(secs => p_queued_grace_seconds)
      ) AS r"""  # noqa: S608 DDL from module constants; no runtime input
REDELIVERABLE = "".join((_HEAD, _BRANCHES, _END, _COMMENT))

#: 0022's body, verbatim in effect, for the downgrade.
_PREVIOUS_BRANCHES = f"""
    -- Cross-org by design; ids and states only. Each branch reads one partial
    -- index (0011's idx_process_runs_stale_lease, this revision's
    -- idx_process_runs_queued_job).
    RETURN QUERY
    SELECT r.run_id, r.org_id, r.process, r.state, r.last_job_id, r.attempts
      FROM (
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.state IN ('parsing', 'running')
           AND pr.lease_expires_at < now()
           AND pr.last_job_id IS NOT NULL
           AND pr.attempts BETWEEN 1 AND {MAX_ATTEMPTS - 1}
        UNION ALL
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.attempts = 0
           AND pr.last_job_id IS NOT NULL
           AND pr.lease_owner IS NULL
           AND pr.state NOT IN ('completed', 'failed', 'expired', 'superseded')
           AND pr.lease_expires_at < now() - make_interval(secs => p_queued_grace_seconds)
      ) AS r"""  # noqa: S608 DDL from module constants; no runtime input
PREVIOUS_REDELIVERABLE = "".join((_HEAD, _PREVIOUS_BRANCHES, _END, _PREVIOUS_COMMENT))


def _as_owner(body: str) -> str:
    """`body` run as the function's owner, with CREATE on `app` only meanwhile (0020's way)."""
    return f"""
GRANT CREATE ON SCHEMA app TO {CONTROL_ROLE};
SET ROLE {CONTROL_ROLE};
{body}
RESET ROLE;
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""


def upgrade() -> None:
    op.execute(COLUMN)
    op.execute(_as_owner(REDELIVERABLE))


def downgrade() -> None:
    op.execute(_as_owner(PREVIOUS_REDELIVERABLE))
    op.execute(f"DROP INDEX IF EXISTS public.{INDEX}")
    op.execute(f"ALTER TABLE public.process_runs DROP CONSTRAINT IF EXISTS {CHECK}")
    op.execute("ALTER TABLE public.process_runs DROP COLUMN IF EXISTS settled_job_ids")
