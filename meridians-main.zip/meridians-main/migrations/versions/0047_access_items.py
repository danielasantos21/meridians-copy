"""access_items — Payroll DB, Operations, Reports & dashboards and Ask a question get their own rights.

Revision ID: 0047_access_items
Revises: 0046_bi_models_metrics
Create Date: 2026-10-18

WHY
---
Owner request: each of the four becomes an access item an admin can give or
hide per role on Settings > Roles. Until now Payroll DB borrowed
`payroll:results` and the other three borrowed `pnl_provider:access`.

WHAT CHANGES
------------
* The `role_permissions.process` CHECK allows four more values: `payroll_db`,
  `operations`, `bi`, `bi_ask` (15 in all).
* `org_modules` gets `payroll_db` for every org with `payroll` enabled and
  `operations`, `bi`, `bi_ask` for every org with `pnl_provider` enabled.
  Without these rows the request-time module mask would zero the four rights
  even for admins.
* `role_permissions` gets `payroll_db` for every role whose `payroll` row can
  view results, and `operations`, `bi`, `bi_ask` for every role whose
  `pnl_provider` row can access. Level-exact, so nobody gains or loses
  anything on day one. `can_view_results` is written false.
Both inserts are ON CONFLICT DO NOTHING (re-runnable).

FORCE ROW LEVEL SECURITY is lifted on the two tables for the length of the
backfill (the migrator sees zero rows otherwise, and the backfill would be a
silent no-op) and restored before the transaction ends.

DOWNGRADE
---------
Deletes the four scopes' rows from both tables, then narrows the CHECK back to
the 0046 list. A downgrade therefore forgets any admin edits made to the four
rows. Rows go before the narrower CHECK is added.
"""

from __future__ import annotations

from alembic import op

revision = "0047_access_items"
down_revision = "0046_bi_models_metrics"
branch_labels = None
depends_on = None

_TABLES = ("public.org_modules", "public.role_permissions")
_NEW_SCOPES = "('payroll_db', 'operations', 'bi', 'bi_ask')"


def _lift_force() -> None:
    for table in _TABLES:
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY")


def _restore_force() -> None:
    for table in _TABLES:
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")


def upgrade() -> None:
    op.execute(
        "ALTER TABLE public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_process_check"
    )
    op.execute(
        "ALTER TABLE public.role_permissions ADD CONSTRAINT role_permissions_process_check "
        "CHECK (process IN ('revenue', 'payroll', 'qb_usa_payroll', 'adp_payroll', 'config', "
        "'invoice', 'booking_payroll', 'pnl_provider', 'code_grader', 'mso_payroll', 'wearbly', "
        "'payroll_db', 'operations', 'bi', 'bi_ask'))"
    )

    _lift_force()
    op.execute(
        """
INSERT INTO public.org_modules (org_id, module, enabled, updated_at, updated_by)
SELECT m.org_id, v.module, true, now(), 'alembic:0047_access_items'
  FROM public.org_modules m
  JOIN (VALUES ('payroll', 'payroll_db'), ('pnl_provider', 'operations'),
               ('pnl_provider', 'bi'), ('pnl_provider', 'bi_ask')) AS v(parent, module)
    ON v.parent = m.module
 WHERE m.enabled IS TRUE
ON CONFLICT (org_id, module) DO NOTHING
"""
    )
    op.execute(
        """
INSERT INTO public.role_permissions (role_id, process, can_access, can_view_results)
SELECT p.role_id, v.process, true, false
  FROM public.role_permissions p
  JOIN (VALUES ('payroll', 'payroll_db', 'results'), ('pnl_provider', 'operations', 'access'),
               ('pnl_provider', 'bi', 'access'), ('pnl_provider', 'bi_ask', 'access')) AS v(parent, process, level)
    ON v.parent = p.process
 WHERE (v.level = 'results' AND p.can_view_results IS TRUE)
    OR (v.level = 'access'  AND p.can_access IS TRUE)
ON CONFLICT (role_id, process) DO NOTHING
"""
    )
    _restore_force()


def downgrade() -> None:
    _lift_force()
    op.execute(f"DELETE FROM public.role_permissions WHERE process IN {_NEW_SCOPES}")  # noqa: S608
    op.execute(f"DELETE FROM public.org_modules WHERE module IN {_NEW_SCOPES}")  # noqa: S608
    _restore_force()
    op.execute(
        "ALTER TABLE public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_process_check"
    )
    op.execute(
        "ALTER TABLE public.role_permissions ADD CONSTRAINT role_permissions_process_check "
        "CHECK (process IN ('revenue', 'payroll', 'qb_usa_payroll', 'adp_payroll', 'config', "
        "'invoice', 'booking_payroll', 'pnl_provider', 'code_grader', 'mso_payroll', 'wearbly'))"
    )
