"""clinic_group_unposted — the unposted JE's clinic-group config in Postgres.

Revision ID: 0029_clinic_group_unposted
Revises: 0028_api_request_export_writer
Create Date: 2026-09-25

Stage 2 local test F3: `UnpostedGenerator` read its configuration ONLY from
the `unposted_config` sheet of `config/mappings.xlsx` — which clinic JE files
make up each clinic group, its hospital JE file, the bank-deposit key and the
fallback location code. On RDS there is no such workbook, so every unposted
JE was silently skipped while the run still said "Booked".

`config_clinic_groups` (org-scoped, RLS, `UNIQUE (org_id, group_name)`)
already holds three of those five columns (`group_name`, `locations`,
`bank_account_key`). This revision adds the other two, so the table is the
whole `unposted_config` sheet, one row per group:

* `hospital_location`     — the hospital JE file of the group (`HospitalWSC`);
                            NULL for a group with no hospital.
* `primary_location_code` — the location an unposted line takes when the
                            revenue line it is allocated from has none
                            (`0001 - Bishop`). Required on Postgres: a group
                            without it blocks the run (`UNPOSTED_CONFIG_UNAVAILABLE`,
                            `reason: incomplete`).

Both nullable: existing rows stay valid, and the run — not a constraint —
says which group is incomplete. The table's RLS policy, its `org_id` FK and
`meridian_app`'s table-level grants cover the new columns unchanged.

DOWNGRADE
---------
Supported: both columns dropped (their values are lost; the workbook sheet is
where they came from).
"""

from __future__ import annotations

from alembic import op

revision = "0029_clinic_group_unposted"
down_revision = "0028_api_request_export_writer"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        ALTER TABLE public.config_clinic_groups
            ADD COLUMN IF NOT EXISTS hospital_location text,
            ADD COLUMN IF NOT EXISTS primary_location_code text;
        """
    )


def downgrade() -> None:
    op.execute(
        """
        ALTER TABLE public.config_clinic_groups
            DROP COLUMN IF EXISTS primary_location_code,
            DROP COLUMN IF EXISTS hospital_location;
        """
    )
