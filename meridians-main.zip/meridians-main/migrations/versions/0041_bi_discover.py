"""bi_discover — bookmarks, recently viewed and SQL snippets for BI.

Revision ID: 0041_bi_discover
Revises: 0040_bi_saved_content
Create Date: 2026-10-13

WHY
---
BI Stage 4B helps people find and reuse things: search, a private list of
bookmarks, "recently viewed" and "popular", pins at the top of a folder, and
named pieces of SQL ("snippets") that admins drop into queries.

WHAT IT ADDS
------------
1. `public.bi_bookmarks` — one row per person per bookmarked item. Private: the
   row-level security (RLS) rule only shows a person their own rows.
2. `public.bi_views` — one row per person per item they opened (the time of the
   latest open). Used for "recently viewed" (only your own rows are ever read)
   and "popular" (counts of different people; no names are returned). RLS is by
   organization only, because "popular" has to count across people; the
   application never returns another person's id, and a test locks that.
3. `public.bi_snippets` — admin-written, named SQL text. A snippet is archived,
   never deleted, so a saved question that mentions it can still be explained.
4. Two small partial indexes that make "what is pinned in this folder" fast on
   the existing `bi_cards` / `bi_collections` tables (their `pinned_position`
   columns already exist from 0040).

No query results, no PHI: ids, names, timestamps and admin-written SQL only.

RLS: ENABLE + FORCE on all three, policy `meridian_org_isolation`.
Plain Postgres 17 only (identity column, CHECKs, partial and expression indexes).

DOWNGRADE drops the two partial indexes FIRST (they live on tables this
revision does not drop; leaving them would make a re-upgrade fail with
"already exists"), then the three new tables.
"""

from __future__ import annotations

from alembic import op

revision = "0041_bi_discover"
down_revision = "0040_bi_saved_content"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
POLICY = "meridian_org_isolation"
BOOKMARKS = "public.bi_bookmarks"
VIEWS = "public.bi_views"
SNIPPETS = "public.bi_snippets"

_ORG_RULE = "(org_id = app.current_org_id())"
_OWN_RULE = "(org_id = app.current_org_id() AND user_id = app.current_user_id())"


def _rls(table: str, rule: str) -> list[str]:
    return [
        f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY",
        f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY",
        f"CREATE POLICY {POLICY} ON {table} USING {rule} WITH CHECK {rule}",
        f"REVOKE ALL ON {table} FROM {PHI_ROLE}",
        f"GRANT SELECT, INSERT, UPDATE, DELETE ON {table} TO {APP_ROLE}",
    ]


CREATE_BOOKMARKS = f"""
CREATE TABLE {BOOKMARKS} (
    org_id     uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id    uuid        NOT NULL,
    item_type  text        NOT NULL CHECK (item_type IN ('card', 'collection')),
    item_id    bigint      NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (org_id, user_id, item_type, item_id)
)
"""

CREATE_VIEWS = f"""
CREATE TABLE {VIEWS} (
    org_id         uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id        uuid        NOT NULL,
    item_type      text        NOT NULL CHECK (item_type IN ('card', 'collection')),
    item_id        bigint      NOT NULL,
    last_viewed_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (org_id, user_id, item_type, item_id)
)
"""

CREATE_SNIPPETS = f"""
CREATE TABLE {SNIPPETS} (
    id          bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id      uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    name        text        NOT NULL
        CHECK (char_length(name) BETWEEN 1 AND 60 AND name ~ '^[A-Za-z0-9 _-]+$'),
    description text        CHECK (char_length(description) <= 500),
    content     text        NOT NULL CHECK (octet_length(content) BETWEEN 1 AND 8192),
    archived_at timestamptz,
    archived_by uuid,
    created_by  uuid        NOT NULL,
    updated_by  uuid        NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id)
)
"""

UPGRADE_SQL: list[str] = [
    CREATE_BOOKMARKS,
    f"""COMMENT ON TABLE {BOOKMARKS} IS
        'Private BI bookmarks (ids only): no query text, no results, no PHI.'""",
    *_rls(BOOKMARKS, _OWN_RULE),
    CREATE_VIEWS,
    f"""CREATE INDEX bi_views_user_recent ON {VIEWS}
        (org_id, user_id, last_viewed_at DESC)""",
    f"""CREATE INDEX bi_views_item_recent ON {VIEWS}
        (org_id, item_type, item_id, last_viewed_at)""",
    f"""COMMENT ON TABLE {VIEWS} IS
        'Who opened which BI item and when (ids only): no query text, no results, no PHI.'""",
    *_rls(VIEWS, _ORG_RULE),
    CREATE_SNIPPETS,
    f"""CREATE UNIQUE INDEX bi_snippets_active_name ON {SNIPPETS}
        (org_id, lower(name)) WHERE archived_at IS NULL""",
    f"""COMMENT ON TABLE {SNIPPETS} IS
        'Admin-written SQL snippets: no query results, no PHI.'""",
    *_rls(SNIPPETS, _ORG_RULE),
    # "What is pinned in this folder": partial indexes on the 0040 tables.
    """CREATE INDEX bi_cards_pinned ON public.bi_cards
        (org_id, collection_id) WHERE pinned_position IS NOT NULL""",
    """CREATE INDEX bi_collections_pinned ON public.bi_collections
        (org_id, parent_id) WHERE pinned_position IS NOT NULL""",
]

DOWNGRADE_SQL: list[str] = [
    "DROP INDEX IF EXISTS public.bi_collections_pinned",
    "DROP INDEX IF EXISTS public.bi_cards_pinned",
    f"DROP TABLE IF EXISTS {SNIPPETS}",
    f"DROP TABLE IF EXISTS {VIEWS}",
    f"DROP TABLE IF EXISTS {BOOKMARKS}",
]


def upgrade() -> None:
    for statement in UPGRADE_SQL:
        op.execute(statement)


def downgrade() -> None:
    for statement in DOWNGRADE_SQL:
        op.execute(statement)
