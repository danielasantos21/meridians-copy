"""process_pins — which processes the sidebar shows, per org and per user.

Revision ID: 0034_process_pins
Revises: 0033_role_preview
Create Date: 2026-09-30

WHY
---
More processes are coming, and only the few a person uses belong in the
sidebar; the rest live in the Processes catalogue (`/processes`). An org admin
picks the org's default pins; a user may replace them with their own and later
reset to the org default. Nothing pinned anywhere means today's sidebar: every
process the org has and the user may open.

WHAT IT ADDS
------------
1. `public.org_process_pins` — one row per org that has a default list: the
   process keys, in sidebar order, in a `text[]` (1 to 6). No row = no default.
   `updated_by` is the admin who saved it last. Tenant table: `org_id`, FORCE
   RLS and the org-isolation policy like every other.

2. `public.user_process_pins` — one row per (org, user) who chose their own
   list (0 to 6 keys: an empty list is a real choice, "pin nothing"). No row =
   follow the org default. FORCE RLS on the org AND the session's own user
   (`user_id = app.current_user_id()`, the 0033 pattern), so one member's
   session can never read or change another's list.

The keys are not a foreign key: processes are code (the registry), not rows.
The API validates every key against the registry on write (422 otherwise) and
skips one that is no longer registered, enabled or permitted on read.

The change record is the `process_pins_change` log event (ids and keys), as for
the other settings screens (`qb_mapping_change`, `clinic_group_change`).

RDS-only: Supabase never runs Alembic. On the Supabase backend (Render until
cutover) the same two lists live in `organizations.settings` under the
`process_pins` key (`src/process_pins.py`).

DOWNGRADE drops both tables (every sidebar goes back to showing everything).
"""

from __future__ import annotations

from alembic import op

revision = "0034_process_pins"
down_revision = "0033_role_preview"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
ORG_TABLE = "public.org_process_pins"
USER_TABLE = "public.user_process_pins"
ORG_POLICY = "meridian_org_isolation"
#: `web/src/components/shell/sidebar.tsx`'s budget; `src.process_pins.MAX_PINS`.
MAX_PINS = 6
_ORG = "(org_id = app.current_org_id())"
_OWN = "(org_id = app.current_org_id() AND user_id = app.current_user_id())"

ORG_PINS = f"""
CREATE TABLE {ORG_TABLE} (
    org_id        uuid        PRIMARY KEY REFERENCES public.organizations(id) ON DELETE CASCADE,
    process_keys  text[]      NOT NULL,
    updated_by    uuid,
    updated_at    timestamptz NOT NULL DEFAULT now(),
    CHECK (cardinality(process_keys) BETWEEN 1 AND {MAX_PINS})
);
COMMENT ON TABLE {ORG_TABLE} IS
    'The org''s default sidebar pins: process keys in order. No row = no default '
    '(the sidebar shows every process the user may open). Keys only.';
ALTER TABLE {ORG_TABLE} ENABLE ROW LEVEL SECURITY;
ALTER TABLE {ORG_TABLE} FORCE ROW LEVEL SECURITY;
CREATE POLICY {ORG_POLICY} ON {ORG_TABLE} USING {_ORG} WITH CHECK {_ORG};
REVOKE ALL ON {ORG_TABLE} FROM {PHI_ROLE};
GRANT SELECT, INSERT, UPDATE, DELETE ON {ORG_TABLE} TO {APP_ROLE};
"""

USER_PINS = f"""
CREATE TABLE {USER_TABLE} (
    org_id        uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id       uuid        NOT NULL,
    process_keys  text[]      NOT NULL,
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (org_id, user_id),
    CHECK (cardinality(process_keys) <= {MAX_PINS})
);
COMMENT ON TABLE {USER_TABLE} IS
    'A user''s own sidebar pins, replacing the org default: process keys in order '
    '(empty = pin nothing). No row = follow the org default. Keys only.';
ALTER TABLE {USER_TABLE} ENABLE ROW LEVEL SECURITY;
ALTER TABLE {USER_TABLE} FORCE ROW LEVEL SECURITY;
CREATE POLICY {ORG_POLICY} ON {USER_TABLE} USING {_OWN} WITH CHECK {_OWN};
REVOKE ALL ON {USER_TABLE} FROM {PHI_ROLE};
GRANT SELECT, INSERT, UPDATE, DELETE ON {USER_TABLE} TO {APP_ROLE};
"""


def upgrade() -> None:
    op.execute(ORG_PINS)
    op.execute(USER_PINS)


def downgrade() -> None:
    op.execute(f"DROP TABLE IF EXISTS {USER_TABLE}")
    op.execute(f"DROP TABLE IF EXISTS {ORG_TABLE}")
