"""invoice_numbers — a per-org counter that cannot hand out the same number twice.

Revision ID: 0007_invoice_numbers
Revises: 0006_user_profiles
Create Date: 2026-09-16

Phase 5a of `docs/aws-migration-plan.md` ("replace the read-max-then-increment
invoice numbering with a sequence — it races"), ADR 0011 (tenant isolation),
ADR 0022 (the repository layer).

WHAT IS WRONG TODAY
-------------------
`get_next_invoice_number()` reads the largest `invoice_number` for the org,
parses the three digits off the end and adds one. Two requests that read before
either writes both read `INV-2026-041` and both return `INV-2026-042`, and
`public.invoices` has nothing that stops the second one landing: the column is
plain `text` with no default, and the only index on it —
`idx_invoices_number (org_id, invoice_number)` — is **not** unique. Two invoices
with the same number is not a display bug; it is two different PDFs a client can
be asked to pay against one reference.

WHAT REPLACES IT
----------------
A counter row per organization, moved by one statement:

    INSERT INTO public.invoice_counters (org_id, year, last_number)
    VALUES (...)
    ON CONFLICT (org_id) DO UPDATE
       SET last_number = CASE WHEN invoice_counters.year = EXCLUDED.year
                              THEN invoice_counters.last_number + 1
                              ELSE 1 END
    RETURNING last_number

One statement, so it is atomic without anybody having to remember a
transaction: the `ON CONFLICT` path takes a row lock, and a second session
blocks on it and then reads the value the first one wrote. No read-then-write
window exists to lose.

**Why `org_id` alone is the primary key, with `year` as an ordinary column.**
The number resets every January, so the counter has to know which year it is
counting. Making the key `(org_id, year)` would leave last year's row behind
forever and make "the current counter" a `max()` query — the shape this
revision exists to delete. One row per org, carrying the year it is counting,
resets in the same single statement: a different year overwrites `year` and
starts `last_number` at 1.

**And the unique index, because a counter is not a constraint.** The counter is
how numbers are *allocated*; `invoices_org_number_key` is what makes a duplicate
*impossible*, including one written by a path that never asked the counter (the
Supabase backend still reads-max-and-increments until cutover — plan §7, dual
maintenance). Belt and braces, and the braces are the index.

THE GUARD, AND WHY IT DOES NOT CLEAN UP AFTER ITSELF
----------------------------------------------------
A unique index over existing data fails with `could not create unique index`
and a message naming one arbitrary duplicated key. That is a true statement and
a useless one: it says nothing about how many there are or which organizations
they belong to, and it arrives halfway through a migration.

So the duplicates are counted first and the revision refuses with the whole
list. It deliberately does **not** renumber or delete anything: a duplicated
invoice number means two documents went out into the world, and which of them
keeps the number is a business decision about money that a migration must not
make at 3am. Resolve them by hand, then re-run.

THE BACKFILL IS NOT OPTIONAL
----------------------------
An organization that already has `INV-2026-041` and an empty counter would be
handed `INV-2026-001` by the statement above — and, now that the index exists,
its second invoice of the year would fail outright. So every organization's
counter is seeded from the largest number it has actually used **this calendar
year**, read out of `public.invoices` itself. `INV-2026-041` seeds
`last_number = 41`, and the next allocation is 42, which is what the old code
would have said too.

Three digits is the shortest tail a sequence position has, not the longest: an
org past its 999th invoice of the year writes `INV-2026-1000`, so the seed reads
`\\d{3,}` and would otherwise ignore exactly the organizations with the most
numbers to preserve.

What it still ignores is the timestamp fallback the old code emitted when
Supabase was unreachable (`INV-2026-143052`): `HHMMSS` is not a sequence
position, and letting one in would jump the counter to 143,052 and never come
back. Six digits is where the two shapes part company — no organization here
issues 100,000 invoices in a year — so the seed takes tails of five digits or
fewer, row by row.

THE REVISION HAS TO LIFT `FORCE` OFF `public.invoices` TO READ IT
-----------------------------------------------------------------
Revision 0004 puts `FORCE ROW LEVEL SECURITY` on every tenant table, and
`FORCE` applies to the table **owner** — which is the migration role. So a
migration running at 0006 with no `app.org_id` set reads `public.invoices` as
**zero rows**: the guard below would find no duplicates however many there
were, and the backfill would seed nothing. Neither would fail; both would
quietly do nothing, which is the failure mode this whole revision exists to
remove.

Setting `app.org_id` is not an option — the revision has no single organization,
it has all of them. So it lifts `FORCE` for the duration and puts it back, both
inside the revision's own transaction, so there is no moment at which a
concurrent session sees `public.invoices` with the backstop off. It is the same
manoeuvre the data-load step in `docs/runbooks/migrations.md` makes for the same
reason, in a smaller window.

RLS
---
`invoice_counters` carries an `org_id`, so it is a tenant table like any other:
`ENABLE` **and** `FORCE ROW LEVEL SECURITY`, with 0004's one policy pair
(`org_id = app.current_org_id()`, both `USING` and `WITH CHECK`). It is listed
in `scripts/tenant_tables.txt` through `MIGRATION_ADDED`, which is what makes
`scripts/lint_org_scope.py` demand an `org_id` predicate on every statement that
names it and `tests/test_migrations.py` check the policy exists.

Grants need no clause here: revision 0003 set `ALTER DEFAULT PRIVILEGES` for the
migration role in `public`, so a table it creates later is already readable and
writable by `meridian_app`.

DOWNGRADE
---------
Drops the index and the table. That is safe for the *data* — every invoice
number is in `public.invoices` and this table only remembers the last one — but
it restores the race, and an organization that downgrades and upgrades again is
re-seeded from the invoices themselves, which is the same answer.
"""

from __future__ import annotations

from alembic import op

revision = "0007_invoice_numbers"
down_revision = "0006_user_profiles"
branch_labels = None
depends_on = None

TABLE = "public.invoice_counters"
INDEX = "invoices_org_number_key"
POLICY = "meridian_org_isolation"
_ORG = "(org_id = app.current_org_id())"

CREATE_TABLE = f"""
CREATE TABLE IF NOT EXISTS {TABLE} (
    org_id       uuid        PRIMARY KEY,
    year         integer     NOT NULL,
    last_number  integer     NOT NULL DEFAULT 0,
    updated_at   timestamptz NOT NULL DEFAULT now()
)
"""

#: Refuse, with the whole list, rather than let `CREATE UNIQUE INDEX` fail
#: naming one arbitrary pair. `format('%s')` on a uuid and a plain invoice
#: number: neither is a patient identifier, and the message has to be
#: actionable by whoever is holding the failed migration.
GUARD = """
DO $$
DECLARE
    offenders text;
    total integer;
BEGIN
    SELECT count(*), string_agg(format('%s (org %s, %s copies)', d.invoice_number,
                                       d.org_id, d.n), '; ')
      INTO total, offenders
      FROM (SELECT org_id, invoice_number, count(*) AS n
              FROM public.invoices
             WHERE invoice_number IS NOT NULL
             GROUP BY org_id, invoice_number
            HAVING count(*) > 1) d;

    IF total > 0 THEN
        RAISE EXCEPTION
            'public.invoices already holds % duplicated (org_id, invoice_number) '
            'pair(s), so the unique index this revision adds cannot be created: %. '
            'This revision deliberately does not renumber or delete anything — two '
            'invoices sharing a number means two documents went out, and which one '
            'keeps the number is a decision about money. Resolve them by hand and '
            're-run.', total, offenders;
    END IF;
END
$$;
"""

CREATE_INDEX = f"""
CREATE UNIQUE INDEX IF NOT EXISTS {INDEX}
    ON public.invoices (org_id, invoice_number)
 WHERE invoice_number IS NOT NULL
"""

#: `substring(... from '-(\\d{3,})$')` — three digits at the end is the FLOOR,
#: not the ceiling. `\\d{3}` matched nothing once an organization passed its
#: 999th invoice of the year (`INV-2026-1000` has a four-digit tail), so such an
#: org would have been seeded from its 999th number — or, if every number it
#: held was already four digits, not seeded at all — and its next allocation
#: would have collided with an invoice that has already been sent.
#:
#: `length(...) <= 5` is what still keeps the `HHMMSS` timestamp fallback out
#: (`INV-2026-143052`): six digits is a clock reading, not a sequence position,
#: and seeding a counter from one would push it to 143,052 and never bring it
#: back. The filter is per ROW, not on the aggregate — an org holding both
#: `INV-2026-041` and a fallback number must still be seeded from 41, and a
#: `HAVING` would have dropped the whole organization instead.
#: `src/invoice_generator._MAX_SEQUENCE` draws the same line in Python.
BACKFILL = f"""
INSERT INTO {TABLE} (org_id, year, last_number)
SELECT i.org_id,
       date_part('year', now())::integer,
       max((substring(i.invoice_number from '-(\\d{{3,}})$'))::integer)
  FROM public.invoices i
 WHERE i.org_id IS NOT NULL
   AND i.invoice_number LIKE 'INV-' || date_part('year', now())::integer || '-%'
   AND substring(i.invoice_number from '-(\\d{{3,}})$') IS NOT NULL
   AND length(substring(i.invoice_number from '-(\\d{{3,}})$')) <= 5
 GROUP BY i.org_id
HAVING max((substring(i.invoice_number from '-(\\d{{3,}})$'))::integer) IS NOT NULL
ON CONFLICT (org_id) DO NOTHING
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    # See "THE REVISION HAS TO LIFT `FORCE`..." above: without this both the
    # guard and the backfill read zero rows and silently succeed. Restored
    # below, in the same transaction.
    op.execute("ALTER TABLE public.invoices NO FORCE ROW LEVEL SECURITY")
    op.execute(GUARD)
    op.execute(CREATE_TABLE)
    op.execute(CREATE_INDEX)
    op.execute(BACKFILL)
    op.execute("ALTER TABLE public.invoices FORCE ROW LEVEL SECURITY")

    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY")
    op.execute(f"CREATE POLICY {POLICY} ON {TABLE} USING {_ORG} WITH CHECK {_ORG}")


def downgrade() -> None:
    op.execute(f"DROP POLICY IF EXISTS {POLICY} ON {TABLE}")
    op.execute(f"DROP TABLE IF EXISTS {TABLE}")
    op.execute(f"DROP INDEX IF EXISTS public.{INDEX}")
