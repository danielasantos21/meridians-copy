"""superadmin_org_list — the one audited cross-organization read, and the table
that records every use of it.

Revision ID: 0010_superadmin_org_list
Revises: 0009_org_members_user_policy
Create Date: 2026-09-16

Phase 5b of `docs/aws-migration-plan.md` (the `/superadmin` screen); ADR 0011
("Superadmin and cross-org admin paths bypass through exactly one named
function, which writes an audit row"), ADR 0022 (`with_org` / `with_user`, and
now `with_superadmin`).

WHAT IT CLOSES
--------------
`docs/migration-tracker.md` carries four `web_app.py` superadmin reads that are
CROSS-ORGANIZATION and stayed on the Supabase service key: `superadmin_orgs`
(every organization, and the member count per organization inside that loop),
`_check_process_health` and `_get_last_batch`. None of them can be written as an
org-scoped statement, and ADR 0011 says the bypass is exactly one audited
function. `src/pg.with_superadmin` is that function; this revision is the two
pieces of schema it cannot work without.

**Why a policy is needed at all.** A superadmin is not necessarily a member of
anything. Revision 0004 gave `public.organizations` the policy
`id = app.current_org_id()`, and revision 0009 added
`meridian_org_member_select` — "the orgs you belong to", through `org_members`.
Under `pg.with_user` a superadmin with no membership row therefore matches
NEITHER: `app.org_id` is empty and there is no membership to join through, so
`SELECT * FROM organizations` returns zero rows and the superadmin console is
blank. That was verified against a database at head before this revision was
written; it is not an assumption.

    | policy                        | predicate                       | a member-less superadmin |
    |-------------------------------|---------------------------------|--------------------------|
    | 0004 `meridian_org_self_...`  | `id = app.current_org_id()`     | NULL under `with_user`   |
    | 0009 `meridian_org_member_..` | member of it through org_members| no membership rows       |
    | 0010 `meridian_org_superad..` | is in `superadmins`             | **this one**             |

POLICIES ARE OR-ED, SO THIS ONLY EVER ADDS ROWS
-----------------------------------------------
PostgreSQL combines permissive policies for one command with OR, so the new
policy cannot take a row away from anybody. It names SELECT and nothing else:
`organizations` is `ENABLE`d without `FORCE` (0004) and its INSERT and DELETE
deliberately have no policy at all, which is what keeps creating and destroying
an organization with the owner role. A superadmin reading the list of
organizations does not thereby gain one row of any organization's DATA — the 62
tenant tables are still filtered on `app.current_org_id()`, which is empty under
`with_user`. Reading an organization's data is still `with_org(that_org_id)`, an
ordinary scoped checkout, and `with_superadmin` enters one per organization
deliberately, writing the audit row below as it goes.

The `superadmins` sub-select reads a table that carries RLS of its own —
revision 0004's `meridian_superadmin_self_select` (`user_id =
app.current_user_id()`). That is deliberate and is the same reasoning 0006
records for `user_profiles` and 0009 for `organizations`: the only row the
session can see in `superadmins` is its own, and its own row is exactly the one
that answers "am I a superadmin?".

THE AUDIT TABLE
---------------
`audit.superadmin_access` is `audit.phi_access`'s sibling and is built the same
way: `meridian_app` is granted **INSERT and nothing else**, so the application
can append to it and can neither read, amend nor erase it. That is what makes it
an audit trail rather than a log the audited party controls. It holds ids, a
timestamp and a short reason — never a row of the data that was read, and never
a patient identifier of any kind.

One row per ORGANIZATION VISITED, not one per call: a console that lists eleven
organizations leaves eleven rows, because "which organizations did this
superadmin actually read?" is the question an access review asks, and a single
row per call cannot answer it.

DOWNGRADE
---------
Supported and cheap: it drops the policy and the table. What it costs is exactly
what this revision bought — `with_superadmin` raises instead of listing, and the
superadmin console goes blank again. No tenant data is touched either way.
"""

from __future__ import annotations

from alembic import op

revision = "0010_superadmin_org_list"
down_revision = "0009_org_members_user_policy"
branch_labels = None
depends_on = None

#: The role the application connects as (revision 0003). Named rather than
#: granted to PUBLIC, for the reason revision 0009 gives.
APP_ROLE = "meridian_app"

POLICY_TABLE = "public.organizations"
POLICY_NAME = "meridian_org_superadmin_select"

#: "The session is a superadmin." `superadmins` carries its own RLS, so the only
#: row this can match is the session's own — see the docstring.
_IS_SUPERADMIN = (
    "(EXISTS (SELECT 1 FROM public.superadmins s  WHERE s.user_id = app.current_user_id()))"
)

AUDIT_TABLE = "audit.superadmin_access"

#: Append-only for `meridian_app`, exactly like `audit.phi_access` (revision
#: 0003). No SELECT, no UPDATE, no DELETE — to anybody but the owner.
_CREATE_AUDIT = f"""
CREATE TABLE IF NOT EXISTS {AUDIT_TABLE} (
    id       bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at       timestamptz NOT NULL DEFAULT now(),
    db_user  text        NOT NULL DEFAULT current_user,
    user_id  uuid        NOT NULL,
    org_id   uuid        NOT NULL,
    reason   text        NOT NULL
);
COMMENT ON TABLE {AUDIT_TABLE} IS
    'One row per organization a superadmin read through src/pg.with_superadmin '
    '(ADR 0011). Ids, a timestamp and a reason -- never the data that was read.';
CREATE INDEX IF NOT EXISTS idx_superadmin_access_at
    ON {AUDIT_TABLE} USING btree (at DESC);
CREATE INDEX IF NOT EXISTS idx_superadmin_access_user
    ON {AUDIT_TABLE} USING btree (user_id, at DESC);
GRANT INSERT ON {AUDIT_TABLE} TO {APP_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.superadmin_access_id_seq TO {APP_ROLE};
"""


def upgrade() -> None:
    op.execute(_CREATE_AUDIT)
    op.execute(
        f"CREATE POLICY {POLICY_NAME} ON {POLICY_TABLE} "
        f"FOR SELECT TO {APP_ROLE} USING {_IS_SUPERADMIN}"
    )


def downgrade() -> None:
    op.execute(f"DROP POLICY IF EXISTS {POLICY_NAME} ON {POLICY_TABLE}")
    op.execute(f"DROP TABLE IF EXISTS {AUDIT_TABLE}")
