"""mart_reader_jit_off - turn off JIT compilation for the BI mart reader role.

Revision ID: 0050_mart_reader_jit_off
Revises: 0049_bi_exec_tables
Create Date: 2026-10-19

WHY
---
The Daily Report cards read `analytics` as `meridian_mart_reader` (src/mart_source.py). On the small
RDS box (db.t3.micro, 1 GB) PostgreSQL's JIT (just-in-time compiler) decides these big view queries
are "expensive" and spends seconds compiling them before running, which on its own can use up the
10 s BI statement timeout. The queries are short analytics reads, so JIT never pays off here.

WHAT IT DOES
------------
`ALTER ROLE meridian_mart_reader SET jit = off`, only when the role exists (0048 creates it, but a
cluster restored without it must not fail this revision). Per-role setting: it affects no other
role and no other database setting. Same style as 0048's READER_SETTINGS.

DOWNGRADE
---------
`ALTER ROLE ... RESET jit` (back to the server default). Also guarded.
"""

from __future__ import annotations

from alembic import op

revision = "0050_mart_reader_jit_off"
down_revision = "0049_bi_exec_tables"
branch_labels = None
depends_on = None

READER_ROLE = "meridian_mart_reader"


def _alter(action: str) -> str:
    return f"""
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{READER_ROLE}') THEN
        EXECUTE 'ALTER ROLE {READER_ROLE} {action}';
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(_alter("SET jit = off"))


def downgrade() -> None:
    op.execute(_alter("RESET jit"))
