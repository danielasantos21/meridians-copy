"""create_organization — the audited, owner-side way to create an organization.

Revision ID: 0015_create_organization
Revises: 0014_webhook_delivery_history
Create Date: 2026-09-24

Migration tracker T:115. `src/auth.create_organization` had no Postgres twin:
revision 0004 gives `public.organizations` no INSERT policy, deliberately, because
there is no `app.org_id` that could authorise creating the organization
`app.org_id` would name. ADR 0011 says creating one is an owner-side act that goes
through one audited path. This revision is that path, and nothing wider.

`app.create_organization(p_name, p_slug)` — ONE `SECURITY DEFINER` FUNCTION
---------------------------------------------------------------------------
It creates the organization, makes the CALLER (`app.current_user_id()`, never an
argument) its `admin`, and writes one `audit.organization_created` row — all in
the one statement, so there is no organization without an admin and no admin
without an audit row. It returns the new id.

* **Who it runs as.** `meridian_org_creator`, a `NOLOGIN` role created here, the
  same shape as 0013's `meridian_api_lookup`. It holds INSERT on three column
  lists and nothing else: `organizations (id, name, slug)`, `org_members (org_id,
  user_id, role)` and the audit table. Owning the function as the migration role
  would have handed the function body every privilege the RDS master user has.
* **How the membership insert passes RLS.** `org_members` is a tenant table
  (`FORCE ROW LEVEL SECURITY`, `org_id = app.current_org_id()`), and this role
  gets no policy of its own there: the function sets `app.org_id` to the new id
  with `set_config(..., true)` — transaction-local — for the one insert, and
  puts the caller's value back before it returns. So the ordinary tenant policy
  is what admits the row, and a caller inside a longer transaction does not come
  back scoped to an organization it did not ask for.
* **`organizations`** has RLS enabled without `FORCE` (0004) and a new policy
  `meridian_org_creator_insert`, `FOR INSERT TO meridian_org_creator` — the
  application role still has no INSERT policy there, so this function is the
  only door.
* **No RETURNING through RLS.** The id is generated in the function
  (`gen_random_uuid()`) rather than read back, so the role needs no SELECT and no
  SELECT policy anywhere.
* `search_path` is pinned (`pg_catalog, pg_temp`) and every name is
  schema-qualified. EXECUTE is revoked from PUBLIC and granted to `meridian_app`.
* A caller with no `app.user_id` (an anonymous or org-only session) is refused
  with `42501` before anything is written. A blank name or slug is `22023`; a
  slug that is taken is the table's own `23505`.

THE AUDIT TABLE
---------------
`audit.organization_created` — who created which organization, when, and through
which login role (`session_user`, i.e. `meridian_app`, not the definer). Ids and
a timestamp only; the name is not copied into it. Append-only: only
`meridian_org_creator` holds INSERT (the schema's default grant to `meridian_app`
and `phi_access` is revoked), and 0013's `audit.refuse_change()` trigger refuses
UPDATE, DELETE and TRUNCATE from everybody, the owner included.

DOWNGRADE
---------
Drops the function, the policy, the audit table and the role. Organizations the
function created stay: they are ordinary rows by then.
"""

from __future__ import annotations

from alembic import op

revision = "0015_create_organization"
down_revision = "0014_webhook_delivery_history"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
CREATOR_ROLE = "meridian_org_creator"
AUDIT_TABLE = "audit.organization_created"
INSERT_POLICY = "meridian_org_creator_insert"

CREATE_ROLE = f"""
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CREATOR_ROLE}') THEN
        CREATE ROLE {CREATOR_ROLE} NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB
            NOCREATEROLE NOINHERIT;
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input

AUDIT = f"""
CREATE TABLE {AUDIT_TABLE} (
    id       bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at       timestamptz NOT NULL DEFAULT now(),
    db_user  text        NOT NULL DEFAULT session_user,
    user_id  uuid        NOT NULL,
    org_id   uuid        NOT NULL
);
COMMENT ON TABLE {AUDIT_TABLE} IS
    'One row per organization created through app.create_organization (ADR 0011, '
    'migration tracker T:115). Ids and a timestamp -- never the organization name.';
REVOKE ALL ON {AUDIT_TABLE} FROM {APP_ROLE}, {PHI_ROLE};
CREATE TRIGGER organization_created_append_only
    BEFORE UPDATE OR DELETE ON {AUDIT_TABLE}
    FOR EACH ROW EXECUTE FUNCTION audit.refuse_change();
CREATE TRIGGER organization_created_no_truncate
    BEFORE TRUNCATE ON {AUDIT_TABLE}
    FOR EACH STATEMENT EXECUTE FUNCTION audit.refuse_change();
"""

GRANTS = f"""
GRANT USAGE ON SCHEMA public, audit TO {CREATOR_ROLE};
GRANT INSERT (id, name, slug) ON public.organizations TO {CREATOR_ROLE};
GRANT INSERT (org_id, user_id, role) ON public.org_members TO {CREATOR_ROLE};
GRANT INSERT (user_id, org_id) ON {AUDIT_TABLE} TO {CREATOR_ROLE};
CREATE POLICY {INSERT_POLICY} ON public.organizations
    FOR INSERT TO {CREATOR_ROLE} WITH CHECK (true);
"""

FUNCTION = f"""
CREATE FUNCTION app.create_organization(p_name text, p_slug text)
RETURNS uuid
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
DECLARE
    v_user     uuid := app.current_user_id();
    v_name     text := btrim(coalesce(p_name, ''));
    v_slug     text := lower(btrim(coalesce(p_slug, '')));
    v_org      uuid := gen_random_uuid();
    v_prev_org text := current_setting('app.org_id', true);
BEGIN
    IF v_user IS NULL THEN
        RAISE EXCEPTION 'app.create_organization needs app.user_id: an organization is '
                        'created by a signed-in person, who becomes its admin'
            USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF v_name = '' OR v_slug = '' THEN
        RAISE EXCEPTION 'organization name and slug are both required'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;

    INSERT INTO public.organizations (id, name, slug) VALUES (v_org, v_name, v_slug);

    -- The ordinary tenant policy on org_members admits this row once the
    -- transaction is scoped to the new organization; the caller's scope is put
    -- back straight after.
    PERFORM pg_catalog.set_config('app.org_id', v_org::text, true);
    INSERT INTO public.org_members (org_id, user_id, role) VALUES (v_org, v_user, 'admin');
    PERFORM pg_catalog.set_config('app.org_id', coalesce(v_prev_org, ''), true);

    INSERT INTO {AUDIT_TABLE} (user_id, org_id) VALUES (v_user, v_org);
    RETURN v_org;
END
$fn$;
COMMENT ON FUNCTION app.create_organization(text, text) IS
    'The one way meridian_app creates an organization (ADR 0011, tracker T:115): '
    'the caller becomes its admin and one audit.organization_created row is written.';
REVOKE ALL ON FUNCTION app.create_organization(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.create_organization(text, text) TO {APP_ROLE};

-- Hand the function to the creator role, exactly as 0013 hands its lookup
-- function to meridian_api_lookup: the migration role must be able to SET ROLE
-- to the new owner, and the owner needs CREATE on the schema only while
-- ownership moves.
-- INHERIT FALSE (as 0011 and 0013): an inheriting member would pick up this
-- role's privileges and policies in the migrator's own sessions.
GRANT {CREATOR_ROLE} TO CURRENT_USER WITH INHERIT FALSE, SET TRUE;
GRANT USAGE, CREATE ON SCHEMA app TO {CREATOR_ROLE};
ALTER FUNCTION app.create_organization(text, text) OWNER TO {CREATOR_ROLE};
REVOKE CREATE ON SCHEMA app FROM {CREATOR_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(CREATE_ROLE)
    op.execute(AUDIT)
    op.execute(GRANTS)
    op.execute(FUNCTION)


def downgrade() -> None:
    # Dropping a function takes its owner's privileges; the migrator's
    # membership does not inherit them (INHERIT FALSE), so SET ROLE for the drop.
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CREATOR_ROLE}') THEN
                EXECUTE 'SET ROLE {CREATOR_ROLE}';
                DROP FUNCTION IF EXISTS app.create_organization(text, text);
                RESET ROLE;
            ELSE
                DROP FUNCTION IF EXISTS app.create_organization(text, text);
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(f"DROP POLICY IF EXISTS {INSERT_POLICY} ON public.organizations")
    op.execute(f"DROP TABLE IF EXISTS {AUDIT_TABLE}")
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CREATOR_ROLE}') THEN
                REVOKE ALL ON public.organizations FROM {CREATOR_ROLE};
                REVOKE ALL ON public.org_members FROM {CREATOR_ROLE};
                REVOKE ALL ON SCHEMA app FROM {CREATOR_ROLE};
                REVOKE ALL ON SCHEMA public FROM {CREATOR_ROLE};
                REVOKE ALL ON SCHEMA audit FROM {CREATOR_ROLE};
                DROP ROLE {CREATOR_ROLE};
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
