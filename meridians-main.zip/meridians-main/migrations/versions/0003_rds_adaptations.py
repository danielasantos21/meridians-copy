"""rds_adaptations — strip what only made sense on Supabase; add phi/audit.

Revision ID: 0003_rds_adaptations
Revises: 0002_reconcile_live_drift
Create Date: 2026-09-15

**This revision has not been applied to any environment yet** (no RDS instance
has been loaded; see docs/migration-tracker.md), so it is still editable in
place rather than by a follow-on revision. That is why the `pgcrypto` extension
and `phi.hmac_key_fingerprint` were moved INTO it from `scripts/split_phi.sql`
rather than added as 0006. Once it has been applied anywhere, this stops being
true and the rule is the usual one: a new revision.

This is the first revision that deliberately makes the schema DIFFERENT from
live Supabase. Everything before it reproduces production; this one adapts it
to RDS. Source: plan §2.2, §2.3, ADR 0011, ADR 0012.

WHAT IT DOES
------------
1. **Drops the three real `auth.users` foreign keys** (`org_members.user_id`,
   `org_members.invited_by`, `config_mx_employees.updated_by`) and the
   `auth.users` shim table 0001 created. Identity lives in Cognito after
   Phase 4; there is no user table in this database to point at.

2. **Keeps the function `public.user_org_id()`, replaces its body.** It used
   to read the Supabase JWT (`auth.uid()`) and look the caller up in
   `org_members`. It now returns `current_setting('app.org_id', true)::uuid` —
   the value the connection pool sets on checkout. The NAME is kept on purpose:
   74 live policies call it, and renaming would mean rewriting every one.
   `is_superadmin` is NOT reimplemented in SQL: superadmin and cross-org access
   is an application concern (one named Python function that writes an audit
   row and then sets `app.org_id`), per ADR 0011.

3. **`auth.uid()` survives as a stub**, reading `app.user_id`. Twenty live
   policies on the identity tables (`organizations`, `org_members`,
   `superadmins`) call it directly; dropping the function would need CASCADE,
   which would silently drop those policies. The `auth` SCHEMA therefore
   remains, holding exactly one stub function and no tables. This is the one
   place where "drop the shim" is narrowed to "drop the shim TABLE", and it is
   deliberate.

4. **Drops the Supabase PostgREST roles** `anon`, `authenticated`,
   `service_role` and any grants to them, if they exist. On a fresh RDS they do
   not, so this is a no-op guarded by a `DO` block — it matters when this chain
   is replayed onto a restored Supabase dump.

5. **Creates the `phi` and `audit` schemas**, the `meridian_app` and
   `phi_access` roles, and the grant matrix of plan §2.3:

   | principal | gets |
   |---|---|
   | `meridian_app` | `USAGE` on `public`; `SELECT/INSERT/UPDATE/DELETE` on every `public` table; `USAGE` on every `public` sequence; `USAGE` on `audit` and **INSERT only** on `audit.phi_access`. **Nothing at all on `phi`.** |
   | `phi_access` | `USAGE` on `phi`; `SELECT/INSERT` on every `phi` table; `USAGE` on `phi` sequences; `USAGE` on `audit` + INSERT on `audit.phi_access` |

   `ALTER DEFAULT PRIVILEGES` is set for the migration role so a table created
   by a LATER revision inherits the same matrix instead of being invisible to
   the application until someone notices.

   **`meridian_app` is `NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE` and is
   not the owner of any table.** That is what makes revision 0004's row-level
   security real rather than decorative — unlike Supabase's service key, this
   role genuinely cannot step over a policy.

6. **Creates `phi.transaction_identity`, `audit.phi_access` and
   `phi.hmac_key_fingerprint`** (DDL only), and the `pgcrypto` extension the
   split script's `hmac()` needs.
   Adds `public.transactions.patient_ref`. It does NOT move any identifier:
   copying `patient_id` / `claim_no` / `encounter_id` across and then dropping
   them from `public.transactions` is a data operation with an HMAC key and a
   verification step, and belongs to the Phase 3 load script, not to a schema
   migration that CI runs against an empty database.

7. **Creates the `app` schema and `app.current_org_id()` / `app.current_user_id()`.**
   Both are `STABLE` and both return NULL unless the session setting they read
   is a syntactically valid UUID. `NULLIF(current_setting(...), '')::uuid`
   handles the *unset* case but not the *malformed* one: a pool that set
   `app.org_id` from an unvalidated request value would make every policy
   predicate raise `22P02` instead of returning no rows, and an application that
   caught that error could carry on. Validating the shape in one STABLE function
   makes the predicate fail closed for every malformed value, not just the empty
   one. Pool-side UUID validation is still coming (Phase 5a); this is the
   database-side half, and it does not depend on it.

PASSWORDS
---------
Read from `MERIDIAN_APP_DB_PASSWORD` and `MERIDIAN_PHI_DB_PASSWORD` at
migration time. Never literals in this file. If either is unset the role is
created with a random password nobody holds, and a warning is printed: the real
credential arrives from Secrets Manager (plan step 8, RDS-managed rotation),
and a role that cannot be logged into is a much better failure than a role with
a guessable password.

A password is **never** interpolated into this file's SQL. It is passed as a
bind parameter to a server-side `format('... %I ... %L', role, password)`, and
the string that comes back is executed. `ALTER ROLE ... PASSWORD` does not
accept a bind parameter, so the quoting has to happen somewhere; doing it with
`%L` inside PostgreSQL means the escaping rules are PostgreSQL's own. The
previous version built a `DO $$ ... $$` block around the literal, which a
password containing `$$` closes early — tested now, with `$$`, `'`, `%` and
backslash.

OFFLINE MODE (`--sql`)
----------------------
`alembic upgrade head --sql` emits a script instead of connecting. Role creation
is skipped there and replaced by a comment naming the two statements a human
must run with the real credentials: a generated script is a file, and a file
with a password in it is a leak. Everything else in this revision is plain DDL
and appears in the script as written.

DOWNGRADE
---------
Not supported. Dropping `phi` would drop patient identifiers.
"""

from __future__ import annotations

import os
import secrets
import sys

from alembic import op

revision = "0003_rds_adaptations"
down_revision = "0002_reconcile_live_drift"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"


def _password(env_var: str, role: str) -> str:
    value = os.environ.get(env_var)
    if value:
        return value
    print(
        f"warning: {env_var} is not set; creating {role} with a random password "
        "that nobody holds. Set it from Secrets Manager before the application "
        "tries to connect.",
        file=sys.stderr,
    )
    return secrets.token_urlsafe(32)


def create_or_update_role(conn, name: str, password: str, extra: str = "") -> None:
    """Create `name` (or reset its password) with PostgreSQL doing the quoting.

    `conn` is a SQLAlchemy connection (`op.get_bind()`), or anything with
    `exec_driver_sql`. Exposed by name so tests can drive it directly with
    hostile passwords.

    The `%%I` / `%%L` are doubled because psycopg2 is given parameters and
    therefore treats `%` in the query text as its own; the server sees `%I`
    and `%L`.
    """
    exists = conn.exec_driver_sql("SELECT 1 FROM pg_roles WHERE rolname = %s", (name,)).fetchone()
    if exists is None:
        template = (
            "CREATE ROLE %%I LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB "
            "NOCREATEROLE NOINHERIT " + extra + " PASSWORD %%L"
        )
    else:
        # ALTER carries no attributes. A CREATEROLE-but-not-superuser principal
        # -- which is what the RDS master user is -- may not issue
        # `ALTER ROLE ... NOSUPERUSER` or `... NOBYPASSRLS` even redundantly
        # ("Only roles with the SUPERUSER attribute may change the SUPERUSER
        # attribute"). So the attributes are asserted below instead of
        # re-asserted here: if a pre-existing role has them, that is a fact a
        # human has to deal with, not something this revision can quietly fix.
        template = "ALTER ROLE %%I WITH LOGIN PASSWORD %%L"
    statement = conn.exec_driver_sql(
        f"SELECT format('{template}', %s, %s)", (name, password)
    ).scalar()

    # Executed on the raw DBAPI cursor with NO parameters, so psycopg2 does no
    # `%`-formatting of it. `conn.exec_driver_sql(statement)` would hand the
    # driver an empty parameter mapping, and a password containing `%` (say
    # `100%sure`) would then be read as a format specifier. The statement is
    # already fully quoted by the server's `format(..., %L)`; nothing further
    # may touch it.
    cursor = getattr(conn, "connection", conn).cursor()
    try:
        cursor.execute(statement)
    finally:
        cursor.close()

    row = conn.exec_driver_sql(
        "SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = %s", (name,)
    ).fetchone()
    if row and (row[0] or row[1]):
        raise RuntimeError(
            f"role {name} already existed as SUPERUSER/BYPASSRLS. Revision 0004's "
            "row-level security would be decorative for it, and this revision "
            "cannot strip those attributes without a superuser. Fix the role by "
            "hand, then re-run."
        )


# --- 1-3. auth -------------------------------------------------------------
AUTH_ADAPTATIONS = """
ALTER TABLE public.org_members        DROP CONSTRAINT IF EXISTS org_members_user_id_fkey;
ALTER TABLE public.org_members        DROP CONSTRAINT IF EXISTS org_members_invited_by_fkey;
ALTER TABLE public.config_mx_employees DROP CONSTRAINT IF EXISTS config_mx_employees_updated_by_fkey;

DROP TABLE IF EXISTS auth.users;

-- Two session settings, and exactly two functions that read them. Both return
-- NULL unless the setting holds a syntactically valid UUID: '' (after a RESET)
-- and anything malformed both give NULL rather than raising 22P02, so a policy
-- predicate built on them fails closed instead of erroring. See ADR 0011.
CREATE SCHEMA IF NOT EXISTS app;
GRANT USAGE ON SCHEMA app TO PUBLIC;

CREATE OR REPLACE FUNCTION app.current_org_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $fn$
        SELECT CASE
            WHEN current_setting('app.org_id', true) ~*
                 '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
            THEN current_setting('app.org_id', true)::uuid
        END
    $fn$;

CREATE OR REPLACE FUNCTION app.current_user_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $fn$
        SELECT CASE
            WHEN current_setting('app.user_id', true) ~*
                 '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
            THEN current_setting('app.user_id', true)::uuid
        END
    $fn$;

-- The name is load-bearing: the policies inherited from Supabase call it.
CREATE OR REPLACE FUNCTION public.user_org_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $fn$ SELECT app.current_org_id() $fn$;

CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $fn$ SELECT app.current_user_id() $fn$;
"""

# --- 4. Supabase PostgREST roles -------------------------------------------
DROP_SUPABASE_ROLES = """
DO $$
DECLARE r text;
BEGIN
    FOREACH r IN ARRAY ARRAY['anon', 'authenticated', 'service_role'] LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
            EXECUTE format('REVOKE ALL ON ALL TABLES IN SCHEMA public FROM %I', r);
            EXECUTE format('REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM %I', r);
            EXECUTE format('REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM %I', r);
            EXECUTE format('REVOKE ALL ON SCHEMA public FROM %I', r);
            EXECUTE format('DROP OWNED BY %I', r);
            EXECUTE format('DROP ROLE %I', r);
        END IF;
    END LOOP;
END $$;
"""

# --- 5. schemas, roles, grant matrix ---------------------------------------
SCHEMAS = """
CREATE SCHEMA IF NOT EXISTS phi;
CREATE SCHEMA IF NOT EXISTS audit;
"""

GRANTS = f"""
REVOKE ALL ON SCHEMA phi   FROM PUBLIC;
REVOKE ALL ON SCHEMA audit FROM PUBLIC;

-- meridian_app: the whole of public, nothing of phi.
GRANT USAGE ON SCHEMA public TO {APP_ROLE};
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {APP_ROLE};
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO {APP_ROLE};
GRANT USAGE ON SCHEMA audit TO {APP_ROLE};

-- phi_access: read and append inside phi, nothing else.
GRANT USAGE ON SCHEMA phi TO {PHI_ROLE};
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA phi TO {PHI_ROLE};
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA phi TO {PHI_ROLE};
GRANT USAGE ON SCHEMA audit TO {PHI_ROLE};
GRANT USAGE ON SCHEMA public TO {PHI_ROLE};

-- Future objects, created by whichever role runs migrations, inherit the same
-- matrix. Without this a table added by revision 0007 is invisible to the app.
DO $$
DECLARE owner text := current_user;
BEGIN
    EXECUTE format(
        'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
        'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO {APP_ROLE}', owner);
    EXECUTE format(
        'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
        'GRANT USAGE, SELECT ON SEQUENCES TO {APP_ROLE}', owner);
    EXECUTE format(
        'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA phi '
        'GRANT SELECT, INSERT ON TABLES TO {PHI_ROLE}', owner);
    EXECUTE format(
        'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA phi '
        'GRANT USAGE, SELECT ON SEQUENCES TO {PHI_ROLE}', owner);
    -- `audit` was missing here. A future audit table would have been created
    -- with no grant to either role, so the first thing to try writing an audit
    -- row would get `permission denied` -- and an audit trail that silently
    -- cannot be written to is worse than not having one.
    EXECUTE format(
        'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA audit '
        'GRANT INSERT ON TABLES TO {APP_ROLE}, {PHI_ROLE}', owner);
    EXECUTE format(
        'ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA audit '
        'GRANT USAGE, SELECT ON SEQUENCES TO {APP_ROLE}, {PHI_ROLE}', owner);
END $$;
"""

# --- 6. phi and audit tables ------------------------------------------------
PHI_TABLES = f"""
CREATE TABLE IF NOT EXISTS phi.transaction_identity (
    transaction_id integer PRIMARY KEY REFERENCES public.transactions(id),
    org_id         uuid NOT NULL REFERENCES public.organizations(id),
    patient_id     text,
    claim_no       text,
    encounter_id   text
);
CREATE INDEX IF NOT EXISTS idx_transaction_identity_org
    ON phi.transaction_identity USING btree (org_id);

-- Who touched PHI, when, and how much of it. NEVER the values themselves --
-- a column holding a patient id here would defeat the whole quarantine.
CREATE TABLE IF NOT EXISTS audit.phi_access (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    occurred_at  timestamptz NOT NULL DEFAULT now(),
    db_user      text NOT NULL DEFAULT current_user,
    app_user_id  uuid,
    org_id       uuid,
    action       text NOT NULL,
    object_name  text NOT NULL,
    row_count    integer,
    request_id   text,
    client_ip    inet
);
CREATE INDEX IF NOT EXISTS idx_phi_access_occurred_at
    ON audit.phi_access USING btree (occurred_at DESC);

-- The tokenized stand-in for patient_id. Populated by the Phase 3 load script,
-- not here: it needs the HMAC key from Secrets Manager.
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS patient_ref text;
CREATE INDEX IF NOT EXISTS idx_transactions_patient_ref
    ON public.transactions USING btree (org_id, patient_ref);

-- Which key wrote every `patient_ref`: one row, `sha256(key)` in hex. The TABLE
-- is created here (critic R2-M3); the ROW is written by scripts/split_phi.sql
-- from the session setting, and revision 0005 asserts it. It used to be a
-- `CREATE TABLE` inside the load script, which meant an environment built by
-- `alembic upgrade head` alone did not have it -- DDL belongs to Alembic
-- (ADR 0019), including this.
CREATE TABLE IF NOT EXISTS phi.hmac_key_fingerprint (
    one_row     boolean     PRIMARY KEY DEFAULT true CHECK (one_row),
    fingerprint text        NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE phi.hmac_key_fingerprint IS
    'sha256 of the MERIDIAN_PHI_HMAC_KEY that wrote public.transactions.patient_ref. '
    'One row, written by scripts/split_phi.sql. A hash, not the key.';
GRANT SELECT ON phi.hmac_key_fingerprint TO {PHI_ROLE};
-- The default privileges above gave phi_access INSERT on every phi table; the
-- fingerprint is written by the migrator alone (a pre-seeded row could make the
-- split refuse, or a rotation accept the wrong key).
REVOKE INSERT ON phi.hmac_key_fingerprint FROM {PHI_ROLE};

-- Append-only for the application; phi_access may also append. Nobody gets
-- UPDATE or DELETE, which is what makes it an audit trail.
GRANT INSERT ON audit.phi_access TO {APP_ROLE};
GRANT INSERT ON audit.phi_access TO {PHI_ROLE};
GRANT SELECT, INSERT ON phi.transaction_identity TO {PHI_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.phi_access_id_seq TO {APP_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.phi_access_id_seq TO {PHI_ROLE};

-- phi_access has to be able to join back to the row it is re-identifying:
-- `phi.transaction_identity JOIN public.transactions USING (transaction_id)` is
-- the only way to get from a patient identifier to its transaction, and it is
-- what src/phi.py will do. SELECT only, and only on this one public table.
GRANT SELECT ON public.transactions TO {PHI_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input

# --- Alembic's own ledger ---------------------------------------------------
# `GRANT ... ON ALL TABLES IN SCHEMA public` above swept up `alembic_version`,
# which Alembic created before revision 0001 ran. The application has no
# business reading -- let alone rewriting -- the record of which migrations a
# database has had: an UPDATE there makes the chain lie about the schema.
# ALTER DEFAULT PRIVILEGES cannot exclude a single table, so the REVOKE is
# re-asserted here, last, after every GRANT in this revision.
REVOKE_LEDGER = f"""
REVOKE ALL ON public.alembic_version FROM {APP_ROLE}, {PHI_ROLE};
"""

# pgaudit is loaded by the RDS parameter group and is absent from a plain
# container, so this is best-effort by design.
PGAUDIT = f"""
DO $$
BEGIN
    EXECUTE 'ALTER ROLE {PHI_ROLE} SET pgaudit.log = ''read,write''';
EXCEPTION WHEN undefined_object OR insufficient_privilege THEN
    RAISE NOTICE 'pgaudit not available here; set pgaudit.log on % via the RDS parameter group', '{PHI_ROLE}';
END $$;
"""


OFFLINE_ROLE_PLACEHOLDER = """
-- ---------------------------------------------------------------------------
-- NOT EMITTED IN OFFLINE MODE: the two role passwords.
--
-- `alembic upgrade --sql` produces a file, and a file is the wrong place for a
-- credential. Before running the rest of this script, create the roles by hand
-- with the values from Secrets Manager (meridian-<env>/db-app and
-- meridian-<env>/db-phi-access):
--
--   CREATE ROLE meridian_app  LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB
--                             NOCREATEROLE NOINHERIT PASSWORD '<db-app>';
--   CREATE ROLE phi_access    LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB
--                             NOCREATEROLE NOINHERIT PASSWORD '<db-phi-access>';
--   GRANT phi_access TO meridian_app;
--
-- See docs/runbooks/migrations.md, "Offline mode".
-- ---------------------------------------------------------------------------
"""


#: `hmac()` and `sha256()` come from pgcrypto, and `scripts/split_phi.sql` needs
#: both. It is created HERE and not by the script (critic R2-M3): the script
#: does data, the chain does DDL (ADR 0019), and an environment built by
#: `alembic upgrade head` alone has to end up with the same database as one
#: built by a restore plus the split.
#:
#: `IF NOT EXISTS` with no `WITH SCHEMA`: a database restored from a Supabase
#: dump already has pgcrypto, in the `extensions` schema, and re-creating it
#: there would fail. pgcrypto is TRUSTED from PostgreSQL 13 on, so the database
#: owner installs it without being a superuser; it is on the RDS supported list.
PGCRYPTO = "CREATE EXTENSION IF NOT EXISTS pgcrypto"


def upgrade() -> None:
    op.execute(PGCRYPTO)
    op.execute(AUTH_ADAPTATIONS)
    op.execute(DROP_SUPABASE_ROLES)
    op.execute(SCHEMAS)

    if op.get_context().as_sql:
        op.execute(OFFLINE_ROLE_PLACEHOLDER)
    else:
        conn = op.get_bind()
        create_or_update_role(conn, APP_ROLE, _password("MERIDIAN_APP_DB_PASSWORD", APP_ROLE))
        create_or_update_role(conn, PHI_ROLE, _password("MERIDIAN_PHI_DB_PASSWORD", PHI_ROLE))

        # The application may SET ROLE phi_access (src/phi.py), so the app role
        # must be a member of it. Membership alone grants nothing until SET
        # ROLE, because both roles are NOINHERIT.
        op.execute(f"GRANT {PHI_ROLE} TO {APP_ROLE}")

    op.execute(GRANTS)
    op.execute(PHI_TABLES)
    op.execute(PGAUDIT)
    op.execute(REVOKE_LEDGER)


def downgrade() -> None:
    raise NotImplementedError(
        "0003 creates the PHI quarantine; there is no safe automated downgrade."
    )
