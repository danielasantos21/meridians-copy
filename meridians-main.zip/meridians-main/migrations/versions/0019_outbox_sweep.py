"""outbox_sweep — the one cross-org read the webhook outbox sweep needs.

Revision ID: 0019_outbox_sweep
Revises: 0018_push_claim_and_input_digest
Create Date: 2026-09-24

Phase 12 T19 (`docs/reports/phase-12-plan.md` §3.7, risk R9). ADR 0011 (tenant
isolation), ADR 0038 (webhooks). RDS-only: Supabase never runs Alembic, and
nothing on Render calls any of this.

WHY A FUNCTION
--------------
The worker writes an `api_events` row (the outbox) in the same transaction as
the run's state change and hands it to EventBridge after commit. If that
PutEvents call fails, or the worker dies between the commit and the call, the
row stays `published_at IS NULL`. Every 5 minutes a sweep re-publishes those
rows. The sweep works across every organization and has no tenant context, and
`api_events` is a FORCE-RLS tenant table: as `meridian_app` with no
`app.org_id` it reads zero rows, which is the point of RLS.

So, like the TTL sweeper (0011's `app.expire_stale_runs`), the sweep asks one
narrow `SECURITY DEFINER` function:

    app.unpublished_api_events(p_min_age_seconds integer, p_limit integer)
        RETURNS TABLE (outbox_event_id uuid, outbox_org_id uuid)

It answers ids only — which event, of which org — oldest first, for rows still
unpublished and at least `p_min_age_seconds` old (the grace period that leaves
a fresh row to the worker's own after-commit publish). It reads nothing else
and writes nothing. The sweep then publishes each event under
`with_org(<its org>)`, where the explicit `org_id = %s` predicate and RLS both
apply, exactly as the worker's own publish does.

OWNER
-----
`meridian_job_control` (0011's NOLOGIN, NOBYPASSRLS owner of the worker's
definers). This revision gives it:

* `SELECT (id, org_id, occurred_at, published_at)` on `public.api_events` —
  the four columns the function reads; not `type`, not `subject_id`;
* one policy on `public.api_events`, `FOR SELECT TO meridian_job_control
  USING (true)` — the same shape 0011 gives it on `process_runs`.

`search_path` is pinned, EXECUTE is revoked from PUBLIC and granted to
`meridian_app` only, grants are issued while the migrator still owns the
function (after the hand-over a REVOKE by the non-inheriting migrator is a
silent no-op). The migrator does NOT become an inheriting member of anything:
0011's `INHERIT FALSE, SET TRUE` membership is what lets it hand ownership over,
and this revision does not grant it again
(`tests/test_migrations.py::test_the_migrator_inherits_no_role_the_chain_granted_it`).

DOWNGRADE
---------
Supported: drops the function (as its owner, 0011's way), the policy and the
column grant. No row of any table changes.
"""

from __future__ import annotations

from alembic import op

revision = "0019_outbox_sweep"
down_revision = "0018_push_claim_and_input_digest"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
CONTROL_ROLE = "meridian_job_control"

#: The grace period and the batch are bounded: a day of grace at most, and at
#: most this many rows per call (the sweep loops if it wants more).
MAX_MIN_AGE_SECONDS = 86_400
MAX_LIMIT = 1_000

#: The columns the function reads. `type` and `subject_id` stay invisible to
#: the control role: the sweep re-reads them under the event's own org.
READ_COLUMNS = ("id", "org_id", "occurred_at", "published_at")

SIGNATURE = "app.unpublished_api_events(integer, integer)"
POLICY = "meridian_job_control_select"

GRANTS = f"""
GRANT SELECT ({", ".join(READ_COLUMNS)}) ON public.api_events TO {CONTROL_ROLE};
CREATE POLICY {POLICY} ON public.api_events
    FOR SELECT TO {CONTROL_ROLE} USING (true);
"""

UNPUBLISHED = f"""
CREATE FUNCTION app.unpublished_api_events(
    p_min_age_seconds integer,
    p_limit           integer
)
RETURNS TABLE (outbox_event_id uuid, outbox_org_id uuid)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF p_min_age_seconds IS NULL
       OR p_min_age_seconds NOT BETWEEN 0 AND {MAX_MIN_AGE_SECONDS} THEN
        RAISE EXCEPTION 'unpublished_api_events: min age must be 0-{MAX_MIN_AGE_SECONDS} seconds'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_limit IS NULL OR p_limit NOT BETWEEN 1 AND {MAX_LIMIT} THEN
        RAISE EXCEPTION 'unpublished_api_events: limit must be 1-{MAX_LIMIT}'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;

    -- Cross-org by design; ids only. The partial index
    -- idx_api_events_unpublished (0013) holds exactly these rows.
    RETURN QUERY
    SELECT e.id, e.org_id
      FROM public.api_events e
     WHERE e.published_at IS NULL
       AND e.occurred_at <= now() - make_interval(secs => p_min_age_seconds)
     ORDER BY e.occurred_at, e.id
     LIMIT p_limit;
END
$fn$;
COMMENT ON FUNCTION {SIGNATURE} IS
    'Phase 12 T19: the outbox sweep. Unpublished api_events older than the grace period, '
    'oldest first. Cross-org by design; returns ids only.';
"""  # noqa: S608 DDL from module constants; no runtime input

#: Grants while the migrator still owns the function, then ownership to the
#: control role through 0011's SET-only membership (0018's way).
OWNERSHIP = f"""
REVOKE ALL ON FUNCTION {SIGNATURE} FROM PUBLIC;
GRANT EXECUTE ON FUNCTION {SIGNATURE} TO {APP_ROLE};
GRANT USAGE, CREATE ON SCHEMA app TO {CONTROL_ROLE};
ALTER FUNCTION {SIGNATURE} OWNER TO {CONTROL_ROLE};
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""


def upgrade() -> None:
    op.execute(GRANTS)
    op.execute(UNPUBLISHED)
    op.execute(OWNERSHIP)


def downgrade() -> None:
    # The function belongs to the control role; the migrator's membership does
    # not inherit its privileges, so SET ROLE for the drop itself (0011's way).
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CONTROL_ROLE}') THEN
                EXECUTE 'SET ROLE {CONTROL_ROLE}';
                DROP FUNCTION IF EXISTS {SIGNATURE};
                RESET ROLE;
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(f"DROP POLICY IF EXISTS {POLICY} ON public.api_events")
    op.execute(
        f"REVOKE SELECT ({', '.join(READ_COLUMNS)}) ON public.api_events FROM {CONTROL_ROLE}"  # noqa: S608 DDL from module constants; no runtime input
    )
