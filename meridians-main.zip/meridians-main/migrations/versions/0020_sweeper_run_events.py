"""sweeper_run_events — the TTL sweeper announces what it moves, in the same call.

Revision ID: 0020_sweeper_run_events
Revises: 0019_outbox_sweep
Create Date: 2026-09-24

Phase 12 T19 follow-up (`docs/reports/phase-12-plan.md` §3.7, risk R9; the
tracker row "run state changes outside the worker's settle announce nothing").
ADR 0011 (tenant isolation), ADR 0038 (webhooks). RDS-only: Supabase never runs
Alembic, and nothing on Render calls any of this.

WHY
---
0011's `app.expire_stale_runs` moves runs across every organization inside a
`SECURITY DEFINER` function: `draft`/`needs_input` runs past `expires_at` →
`expired`, `parsing`/`running` runs whose last lease lapsed → `failed`. Those
are run state changes a partner subscribed to webhooks has to hear about, and
until now nothing wrote their outbox row. The worker's settle writes its row in
its own transaction (0019's docstring); the sweeper has no tenant session to do
that from, so the function itself now inserts one `public.api_events` row per
run it moves, in the same call — the move and its announcement commit together
or not at all:

* `failed`  → `run.failed`;
* `expired` → `run.expired` (the event type this revision's T19 follow-up adds
  to `src/webhooks/engine.EVENT_TYPES`: "the run was closed without running to
  an end" — its TTL lapsed, or it was cancelled).

A dry run inserts nothing. The function's signature and its answer are
unchanged, so `workers/sweep.py` is untouched. The rows are published by the
outbox sweep (`workers/outbox_sweep.py`, 0019) after its grace period; the TTL
sweeper does not publish them itself.

WHAT THE CONTROL ROLE GAINS
---------------------------
`meridian_job_control` (0011's NOLOGIN, NOBYPASSRLS owner of the definer):

* `INSERT (org_id, type, subject_id)` on `public.api_events` — three columns.
  `id` and `occurred_at` take their defaults; `published_at` stays NULL, so the
  role can never mark an event published;
* one policy, `FOR INSERT TO meridian_job_control`, whose `WITH CHECK` admits
  only `run.failed` for a run of THAT org that is `failed` now, and
  `run.expired` for a run of that org that is `expired` now. The function runs
  the UPDATE first and the INSERT as its own statement, so the check sees the
  moved row. The role cannot announce another org's run, a state the run is not
  in, or any other event type.

No SELECT beyond 0019's four columns, no UPDATE, no DELETE on `api_events`.

HOW THE FUNCTION IS REPLACED
----------------------------
The function belongs to the control role and the migrator's membership in it is
`INHERIT FALSE, SET TRUE` (0011). So the replacement runs under `SET ROLE` to
the owner, with a transient `CREATE` on schema `app` (which `CREATE OR REPLACE`
requires), revoked again at once. `CREATE OR REPLACE` keeps the owner and the
EXECUTE grants 0011 made (PUBLIC revoked, `meridian_app` granted). The migrator
gains no new membership
(`tests/test_migrations.py::test_the_migrator_inherits_no_role_the_chain_granted_it`).

DOWNGRADE
---------
Supported: puts 0011's body back (no inserts), drops the policy, revokes the
column grant. Event rows already written stay — they announce moves that
happened.
"""

from __future__ import annotations

from alembic import op

revision = "0020_sweeper_run_events"
down_revision = "0019_outbox_sweep"
branch_labels = None
depends_on = None

CONTROL_ROLE = "meridian_job_control"

#: 0011's value, repeated because a migration never imports another one.
MAX_ATTEMPTS = 3

#: The columns the function writes; the rest take their defaults.
INSERT_COLUMNS = ("org_id", "type", "subject_id")

SIGNATURE = "app.expire_stale_runs(boolean)"
POLICY = "meridian_job_control_insert"

GRANTS = f"""
GRANT INSERT ({", ".join(INSERT_COLUMNS)}) ON public.api_events TO {CONTROL_ROLE};
CREATE POLICY {POLICY} ON public.api_events
    FOR INSERT TO {CONTROL_ROLE}
    WITH CHECK (
        (type = 'run.failed' OR type = 'run.expired')
        AND published_at IS NULL
        AND EXISTS (
            SELECT 1 FROM public.process_runs pr
             WHERE pr.run_id = api_events.subject_id
               AND pr.org_id = api_events.org_id
               AND pr.state = CASE api_events.type WHEN 'run.failed' THEN 'failed'
                                                   ELSE 'expired' END
        )
    );
"""  # noqa: S608 DDL from module constants; no runtime input

_FAILED_ERROR = (
    "jsonb_build_object('code', 'RUN_FAILED', 'message', "
    f"'The run stopped responding and was abandoned after {MAX_ATTEMPTS} attempts.')"
)

_DRY_RUN = f"""
    IF p_dry_run THEN
        RETURN QUERY
        SELECT pr.run_id, pr.org_id, pr.state, 'expired'::text
          FROM public.process_runs pr
         WHERE pr.state IN ('draft', 'needs_input') AND pr.expires_at < now()
        UNION ALL
        SELECT pr.run_id, pr.org_id, pr.state, 'failed'::text
          FROM public.process_runs pr
         WHERE pr.state IN ('parsing', 'running') AND pr.lease_expires_at < now()
           AND pr.attempts >= {MAX_ATTEMPTS};
        RETURN;
    END IF;
"""  # noqa: S608 DDL from module constants; no runtime input

#: The body with the outbox rows. Each move is one UPDATE; each run it moved
#: gets its event from a separate INSERT, which sees the moved row (the policy
#: checks it). All of it is one call, so one transaction.
EXPIRE_STALE_RUNS = f"""
CREATE OR REPLACE FUNCTION app.expire_stale_runs(p_dry_run boolean DEFAULT false)
RETURNS TABLE (swept_run_id uuid, swept_org_id uuid, from_state text, to_state text)
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
DECLARE
    v_state text;
    v_run   record;
BEGIN
{_DRY_RUN}
    -- Abandoned wizards: expired, and the one-run-only roster answers go with
    -- them (the clear_run_overrides contract, 975d5db). Announced run.expired.
    FOREACH v_state IN ARRAY ARRAY['draft', 'needs_input'] LOOP
        FOR v_run IN
            UPDATE public.process_runs pr
               SET state            = 'expired',
                   run_state        = pr.run_state - 'run_overrides',
                   lease_owner      = NULL,
                   lease_expires_at = NULL,
                   updated_at       = now()
             WHERE pr.state = v_state AND pr.expires_at < now()
            RETURNING pr.run_id, pr.org_id
        LOOP
            INSERT INTO public.api_events (org_id, type, subject_id)
            VALUES (v_run.org_id, 'run.expired', v_run.run_id);
            swept_run_id := v_run.run_id;
            swept_org_id := v_run.org_id;
            from_state   := v_state;
            to_state     := 'expired';
            RETURN NEXT;
        END LOOP;
    END LOOP;

    -- Lost workers: the lease lapsed on the last attempt the queue will make.
    -- Announced run.failed.
    FOREACH v_state IN ARRAY ARRAY['parsing', 'running'] LOOP
        FOR v_run IN
            UPDATE public.process_runs pr
               SET state            = 'failed',
                   run_state        = pr.run_state - 'run_overrides',
                   error            = {_FAILED_ERROR},
                   lease_owner      = NULL,
                   lease_expires_at = NULL,
                   updated_at       = now()
             WHERE pr.state = v_state
               AND pr.lease_expires_at < now()
               AND pr.attempts >= {MAX_ATTEMPTS}
            RETURNING pr.run_id, pr.org_id
        LOOP
            INSERT INTO public.api_events (org_id, type, subject_id)
            VALUES (v_run.org_id, 'run.failed', v_run.run_id);
            swept_run_id := v_run.run_id;
            swept_org_id := v_run.org_id;
            from_state   := v_state;
            to_state     := 'failed';
            RETURN NEXT;
        END LOOP;
    END LOOP;
END
$fn$;
COMMENT ON FUNCTION {SIGNATURE} IS
    'Phase 11 D2/D5, Phase 12 T19: the TTL sweeper. Cross-org by design; returns ids and '
    'states only; writes one api_events row (run.expired / run.failed) per run it moves.';
"""  # noqa: S608 DDL from module constants; no runtime input

#: 0011's body, exactly: what a downgrade puts back.
PREVIOUS_EXPIRE_STALE_RUNS = f"""
CREATE OR REPLACE FUNCTION app.expire_stale_runs(p_dry_run boolean DEFAULT false)
RETURNS TABLE (swept_run_id uuid, swept_org_id uuid, from_state text, to_state text)
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
DECLARE
    v_state text;
BEGIN
{_DRY_RUN}
    -- Abandoned wizards: expired, and the one-run-only roster answers go with
    -- them (the clear_run_overrides contract, 975d5db).
    FOREACH v_state IN ARRAY ARRAY['draft', 'needs_input'] LOOP
        RETURN QUERY
        UPDATE public.process_runs pr
           SET state            = 'expired',
               run_state        = pr.run_state - 'run_overrides',
               lease_owner      = NULL,
               lease_expires_at = NULL,
               updated_at       = now()
         WHERE pr.state = v_state AND pr.expires_at < now()
        RETURNING pr.run_id, pr.org_id, v_state, 'expired'::text;
    END LOOP;

    -- Lost workers: the lease lapsed on the last attempt the queue will make.
    FOREACH v_state IN ARRAY ARRAY['parsing', 'running'] LOOP
        RETURN QUERY
        UPDATE public.process_runs pr
           SET state            = 'failed',
               run_state        = pr.run_state - 'run_overrides',
               error            = {_FAILED_ERROR},
               lease_owner      = NULL,
               lease_expires_at = NULL,
               updated_at       = now()
         WHERE pr.state = v_state
           AND pr.lease_expires_at < now()
           AND pr.attempts >= {MAX_ATTEMPTS}
        RETURNING pr.run_id, pr.org_id, v_state, 'failed'::text;
    END LOOP;
END
$fn$;
COMMENT ON FUNCTION {SIGNATURE} IS
    'Phase 11 D2/D5: the TTL sweeper. Cross-org by design; returns ids and states only.';
"""  # noqa: S608 DDL from module constants; no runtime input


def _as_owner(body: str) -> str:
    """`body` run as the function's owner, with CREATE on `app` only meanwhile."""
    return f"""
GRANT CREATE ON SCHEMA app TO {CONTROL_ROLE};
SET ROLE {CONTROL_ROLE};
{body}
RESET ROLE;
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""


def upgrade() -> None:
    op.execute(GRANTS)
    op.execute(_as_owner(EXPIRE_STALE_RUNS))


def downgrade() -> None:
    op.execute(_as_owner(PREVIOUS_EXPIRE_STALE_RUNS))
    op.execute(f"DROP POLICY IF EXISTS {POLICY} ON public.api_events")
    op.execute(
        f"REVOKE INSERT ({', '.join(INSERT_COLUMNS)}) ON public.api_events FROM {CONTROL_ROLE}"
    )
