"""api_platform — machine clients, partner BAAs, webhooks, the event outbox,
the API audit trail and the shared quota counters.

Revision ID: 0013_api_platform
Revises: 0012_job_idempotency
Create Date: 2026-09-24

Phase 12 task T04 (`docs/reports/phase-12-plan.md` §3.5). ADR 0011 (tenant
isolation: the `org_id` predicate AND row-level security), ADR 0021 (no
authorization in a token claim), ADR 0012 (PHI never leaves `phi`).

WHY 0013 AND NOT 0011
---------------------
`docs/reports/phase-11-plan.md` reserves `0011_process_runs_worker` and
`0012_job_idempotency`. Alembic is a linear chain, so this revision took the
next free number and revised 0010 until those two existed. They merged second,
so this revision was re-pointed onto them (the plan's T04 row: "Phase 11
revisions merged first *or* renumber at merge").

One thing here now serves Phase 11 (`JOB_CONTROL_GRANTS`): revision 0011's
`app.authorize_job` checks a machine-client actor against `api_clients` and
`process_runs.created_by_client_id`, both born in this revision, so this is
where its owner (`meridian_job_control`) is given the three columns and the
SELECT-only policy that check reads. Dropping the table and the column on
downgrade takes the grant and the policy with them.

WHAT IT CREATES
---------------
Five tenant tables, each `FORCE ROW LEVEL SECURITY` with the same
`meridian_org_isolation` policy revision 0004 gives every other one, and listed
in `scripts/tenant_tables.txt` (MIGRATION_ADDED):

* `public.partner_baas`     — no machine `phi:read` without a BAA row here.
* `public.api_clients`      — one row per machine client. The CHECKs are the
  database half of two rules `src/api_scopes.py` also enforces: a machine never
  holds a human-only scope, and `phi:read` needs a BAA and an mTLS subject.
* `public.webhook_subscriptions`, `public.webhook_deliveries` — T11's store.
* `public.api_events`       — the outbox (§3.7). Ids only, never PHI.

Three additive columns: `process_runs.created_by_client_id`,
`artifact_downloads.api_client_id` (extend, never parallel) and
`roles.can_read_phi` (default false: R20, nobody needs it today).

Two append-only audit tables, `audit.api_request` (one row per `/api/v3`
call, T06) and `audit.api_client_change` (grants, approvals, rotations,
revocations, T12), and one plain table, `public.api_quota_window` (T09's
shared counters — ADR 0010 reopened for more than one api task, still no
Redis).

APPEND-ONLY, IN THE DATABASE
----------------------------
`audit.superadmin_access` (0010) and `audit.phi_access` (0003) are append-only
for `meridian_app` because it holds INSERT and nothing else. The two tables
here get that AND a trigger that refuses UPDATE, DELETE and TRUNCATE from
anybody, the owner included. Removing that needs an explicit
`DROP TRIGGER`/`DISABLE TRIGGER` by the owner — a DDL act a reviewer can see —
rather than a stray `DELETE` from a maintenance session.

THE PRE-TENANT LOOKUP: `app.api_client_for_token`
-------------------------------------------------
A machine's request carries a Cognito `client_id` and nothing else. The api has
to find the `api_clients` row BEFORE it knows the org, and RLS (rightly) shows
`meridian_app` no row of a tenant table while `app.org_id` is empty. So there is
exactly one `SECURITY DEFINER` function that answers "which client is this, in
which org, allowed what", returning only the authorization columns.

It is owned by `meridian_api_lookup`, a `NOLOGIN` role created here that holds
SELECT on those columns only (a column-level grant), plus a SELECT-only policy
on `api_clients` and `partner_baas` that applies to that role and no other. The
alternative — owning the function as the migration role — does not work:
`FORCE` applies to the owner, so the function would see nothing, and giving
the owner a bypass policy would weaken `FORCE` for every session the owner ever
opens. A dedicated role keeps the bypass the width of one function.

The migrator becomes a member of the lookup role only to hand ownership over,
and `WITH INHERIT FALSE, SET TRUE` (the same shape 0011 gives
`meridian_job_control`): RLS applies a policy to the members of its role, so an
inheriting membership would hand the migrator those `USING (true)` policies and
it would read every organization's `api_clients` and `partner_baas` rows with
no `app.org_id` set.

`search_path` is pinned on the function (`pg_catalog, pg_temp`) and every name
in it is schema-qualified, so a caller cannot shadow `public.api_clients` with
a temp table. EXECUTE is revoked from PUBLIC and granted to `meridian_app`.

`baa_active` is returned beside the plan's columns: the CHECK proves a BAA row
was named, not that it is still in force. A revoked or expired BAA must take
`phi:read` away on the next request, and the function is the only place the
api can learn that before it knows the org.

ALSO: `employee_clinic_allocations` UNIQUE KEY GAINS `org_id`
------------------------------------------------------------
The Supabase-era key was `(employee_normalized, location_code)` with no
`org_id`, so two organizations could not both allocate an employee of the same
normalized name to the same location code — the second insert collided with a
row it cannot even see under RLS. The narrow key is dropped and
`(org_id, employee_normalized, location_code)` is added unless the replay
already left one (see `WIDEN_ALLOCATION_KEY`). This cannot fail on existing
data: the old
key already guaranteed no two rows share `(employee_normalized,
location_code)`, so none can share the wider one. No statement names the old
key as an `ON CONFLICT` target (only the frozen SQLite CLI keeps its own copy
of the table).

DOWNGRADE
---------
Supported: drops everything above in reverse, including the lookup role. Rows
in these tables are lost, which is the point of a downgrade; no pre-existing
table loses a row (the three added columns go, and nothing reads them yet).
Restoring the narrow allocation key FAILS if two organizations have come to
hold the same `(employee_normalized, location_code)` since the upgrade; that
is deliberate — which organization's row to drop is not a migration's call.
"""

from __future__ import annotations

from alembic import op

revision = "0013_api_platform"
down_revision = "0012_job_idempotency"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
LOOKUP_ROLE = "meridian_api_lookup"

POLICY = "meridian_org_isolation"
_ORG = "(org_id = app.current_org_id())"

#: The tenant tables this revision creates, in dependency order.
TENANT_TABLES = (
    "public.partner_baas",
    "public.api_clients",
    "public.webhook_subscriptions",
    "public.api_events",
    "public.webhook_deliveries",
)

#: A machine can never hold these (`src.api_scopes.HUMAN_ONLY_SCOPES`). A test
#: asserts the two lists are the same list.
HUMAN_ONLY_SCOPES = (
    "org:admin",
    "clients:manage",
    "audit:read",
    "settings:admin",
    "superadmin",
    "profile:self",
    "dashboard:self",
)
_HUMAN_ONLY_ARRAY = "ARRAY[" + ", ".join(f"'{s}'" for s in HUMAN_ONLY_SCOPES) + "]::text[]"

#: The columns `app.api_client_for_token` returns, and the only ones the lookup
#: role may read.
LOOKUP_COLUMNS = (
    "id",
    "org_id",
    "status",
    "granted_scopes",
    "allowed_processes",
    "ip_allowlist",
    "mtls_subject",
    "revoked_epoch",
    "cognito_client_id",
    "partner_baa_id",
)

CREATE_TABLES = f"""
CREATE TABLE public.partner_baas (
    id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id        uuid        NOT NULL REFERENCES public.organizations(id),
    partner_name  text        NOT NULL CHECK (length(partner_name) BETWEEN 1 AND 200),
    document_ref  text        NOT NULL,
    signed_on     date        NOT NULL,
    expires_on    date,
    approved_by   uuid        NOT NULL,
    approved_at   timestamptz NOT NULL DEFAULT now(),
    revoked_at    timestamptz
);
COMMENT ON COLUMN public.partner_baas.document_ref IS
    'Evidence-store key of the signed BAA -- never the document itself.';

CREATE TABLE public.api_clients (
    id                  uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id              uuid        NOT NULL REFERENCES public.organizations(id),
    name                text        NOT NULL CHECK (length(name) BETWEEN 3 AND 80),
    kind                text        NOT NULL CHECK (kind IN ('internal', 'partner', 'sandbox')),
    status              text        NOT NULL
                        CHECK (status IN ('pending_approval', 'active', 'disabled', 'revoked')),
    cognito_client_id   text        UNIQUE,
    secret_fingerprint  text,
    granted_scopes      text[]      NOT NULL DEFAULT '{{}}',
    allowed_processes   text[]      NOT NULL DEFAULT '{{}}',
    ip_allowlist        cidr[],
    mtls_subject        text,
    partner_baa_id      uuid        REFERENCES public.partner_baas(id),
    revoked_epoch       timestamptz NOT NULL DEFAULT 'epoch',
    requested_by        uuid        NOT NULL,
    approved_by         uuid,
    approved_at         timestamptz,
    disabled_at         timestamptz,
    disabled_reason     text,
    last_used_at        timestamptz,
    last_used_ip        inet,
    created_at          timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT api_clients_no_human_only_scopes
        CHECK (NOT granted_scopes && {_HUMAN_ONLY_ARRAY}),
    CONSTRAINT api_clients_phi_needs_baa_and_subject
        CHECK (NOT ('phi:read' = ANY (granted_scopes))
               OR (partner_baa_id IS NOT NULL AND mtls_subject IS NOT NULL)),
    CONSTRAINT api_clients_active_needs_approval
        CHECK (status <> 'active' OR (approved_by IS NOT NULL AND cognito_client_id IS NOT NULL))
);
COMMENT ON COLUMN public.api_clients.secret_fingerprint IS
    'A sha256 prefix of the live secret, for display during rotation. Never the secret: '
    'Cognito verifies it, so a hash here would verify nothing.';
COMMENT ON COLUMN public.api_clients.revoked_epoch IS
    'Tokens whose iat is before this are refused on the next request.';
CREATE INDEX idx_api_clients_org ON public.api_clients (org_id, created_at DESC, id DESC);

CREATE TABLE public.webhook_subscriptions (
    id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id          uuid        NOT NULL REFERENCES public.organizations(id),
    api_client_id   uuid        REFERENCES public.api_clients(id),
    url             text        NOT NULL CHECK (url LIKE 'https://%' AND length(url) <= 2048),
    event_types     text[]      NOT NULL CHECK (cardinality(event_types) > 0),
    secret_arn      text        NOT NULL,
    status          text        NOT NULL CHECK (status IN ('active', 'paused', 'disabled')),
    failure_streak  integer     NOT NULL DEFAULT 0,
    created_by      uuid,
    created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_webhook_subscriptions_org
    ON public.webhook_subscriptions (org_id, created_at DESC, id DESC);

CREATE TABLE public.api_events (
    id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id        uuid        NOT NULL,
    type          text        NOT NULL,
    subject_id    uuid        NOT NULL,
    occurred_at   timestamptz NOT NULL DEFAULT now(),
    published_at  timestamptz
);
COMMENT ON TABLE public.api_events IS
    'The webhook outbox: written in the same transaction as the change it announces. '
    'Ids only, never PHI.';
CREATE INDEX idx_api_events_unpublished
    ON public.api_events (published_at) WHERE published_at IS NULL;

CREATE TABLE public.webhook_deliveries (
    id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id            uuid        NOT NULL,
    subscription_id   uuid        NOT NULL REFERENCES public.webhook_subscriptions(id),
    event_id          uuid        NOT NULL REFERENCES public.api_events(id),
    attempt           integer     NOT NULL DEFAULT 0,
    status            text        NOT NULL
                      CHECK (status IN ('pending', 'delivered', 'failed', 'dropped', 'dead')),
    last_status_code  integer,
    last_error_code   text,
    next_attempt_at   timestamptz,
    delivered_at      timestamptz,
    CONSTRAINT webhook_deliveries_fanout_once UNIQUE (subscription_id, event_id)
);
CREATE INDEX idx_webhook_deliveries_org
    ON public.webhook_deliveries (org_id, subscription_id, status);

-- ADR 0010 reopened: shared counters for more than one api task, no Redis.
-- Not a tenant table: an IP bucket is counted before anybody knows an org.
CREATE TABLE public.api_quota_window (
    bucket        text        NOT NULL CHECK (length(bucket) <= 200),
    window_start  timestamptz NOT NULL,
    hits          integer     NOT NULL,
    PRIMARY KEY (bucket, window_start)
);
"""

ADD_COLUMNS = """
ALTER TABLE public.process_runs
    ADD COLUMN created_by_client_id uuid REFERENCES public.api_clients(id);
ALTER TABLE public.artifact_downloads
    ADD COLUMN api_client_id uuid REFERENCES public.api_clients(id);
ALTER TABLE public.roles
    ADD COLUMN can_read_phi boolean NOT NULL DEFAULT false;
"""

#: The machine's lifecycle is status + revoked_epoch, and an audit review has
#: to be able to find a client that no longer works. So nobody deletes one.
REVOKE_DELETES = f"""
REVOKE DELETE ON public.partner_baas FROM {APP_ROLE};
REVOKE DELETE ON public.api_clients  FROM {APP_ROLE};
REVOKE DELETE ON public.api_events   FROM {APP_ROLE};
"""

AUDIT = f"""
CREATE TABLE audit.api_request (
    id             bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at             timestamptz NOT NULL DEFAULT now(),
    request_id     text        NOT NULL CHECK (length(request_id) <= 64),
    org_id         uuid,
    user_id        uuid,
    api_client_id  uuid,
    method         text        NOT NULL CHECK (length(method) <= 16),
    route          text        NOT NULL CHECK (length(route) <= 300),
    record_id      uuid,
    scope_used     text,
    status         smallint    NOT NULL,
    ip             inet
);
COMMENT ON TABLE audit.api_request IS
    'One row per /api/v3 call (Phase 12 T06). The matched route TEMPLATE, never the raw '
    'URL or query string; ids, never PHI. Append-only.';
CREATE INDEX idx_api_request_at ON audit.api_request USING btree (at DESC);
CREATE INDEX idx_api_request_client ON audit.api_request USING btree (api_client_id, at DESC);

CREATE TABLE audit.api_client_change (
    id             bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at             timestamptz NOT NULL DEFAULT now(),
    api_client_id  uuid        NOT NULL,
    actor_user_id  uuid        NOT NULL,
    action         text        NOT NULL,
    scopes_before  text[],
    scopes_after   text[],
    reason         text
);
COMMENT ON TABLE audit.api_client_change IS
    'Grants, approvals, rotations and revocations of machine clients. Append-only.';

-- INSERT for the application and nothing else. The schema's default
-- privileges (0003) also hand INSERT to phi_access; nothing there writes these.
REVOKE ALL ON audit.api_request, audit.api_client_change FROM {PHI_ROLE};
GRANT INSERT ON audit.api_request, audit.api_client_change TO {APP_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.api_request_id_seq, audit.api_client_change_id_seq
    TO {APP_ROLE};

CREATE FUNCTION audit.refuse_change() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    RAISE EXCEPTION '% on %.% is refused: this audit table is append-only',
        TG_OP, TG_TABLE_SCHEMA, TG_TABLE_NAME
        USING ERRCODE = 'insufficient_privilege';
END
$fn$;
REVOKE ALL ON FUNCTION audit.refuse_change() FROM PUBLIC;

CREATE TRIGGER api_request_append_only
    BEFORE UPDATE OR DELETE ON audit.api_request
    FOR EACH ROW EXECUTE FUNCTION audit.refuse_change();
CREATE TRIGGER api_request_no_truncate
    BEFORE TRUNCATE ON audit.api_request
    FOR EACH STATEMENT EXECUTE FUNCTION audit.refuse_change();
CREATE TRIGGER api_client_change_append_only
    BEFORE UPDATE OR DELETE ON audit.api_client_change
    FOR EACH ROW EXECUTE FUNCTION audit.refuse_change();
CREATE TRIGGER api_client_change_no_truncate
    BEFORE TRUNCATE ON audit.api_client_change
    FOR EACH STATEMENT EXECUTE FUNCTION audit.refuse_change();
"""  # noqa: S608 DDL from module constants; no runtime input

#: `CREATE ROLE` is cluster-wide and has no IF NOT EXISTS; a database restored
#: next to another one on the same cluster may find it already there.
CREATE_LOOKUP_ROLE = f"""
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{LOOKUP_ROLE}') THEN
        CREATE ROLE {LOOKUP_ROLE} NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB
            NOCREATEROLE NOINHERIT;
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input

LOOKUP_FUNCTION = f"""
GRANT USAGE ON SCHEMA public TO {LOOKUP_ROLE};
GRANT SELECT ({", ".join(LOOKUP_COLUMNS)}) ON public.api_clients TO {LOOKUP_ROLE};
GRANT SELECT (id, revoked_at, expires_on) ON public.partner_baas TO {LOOKUP_ROLE};
CREATE POLICY meridian_api_client_lookup ON public.api_clients
    FOR SELECT TO {LOOKUP_ROLE} USING (true);
CREATE POLICY meridian_api_client_lookup ON public.partner_baas
    FOR SELECT TO {LOOKUP_ROLE} USING (true);

CREATE FUNCTION app.api_client_for_token(p_cognito_client_id text)
RETURNS TABLE (
    id                uuid,
    org_id            uuid,
    status            text,
    granted_scopes    text[],
    allowed_processes text[],
    ip_allowlist      cidr[],
    mtls_subject      text,
    revoked_epoch     timestamptz,
    baa_active        boolean
)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
    SELECT c.id, c.org_id, c.status, c.granted_scopes, c.allowed_processes,
           c.ip_allowlist, c.mtls_subject, c.revoked_epoch,
           EXISTS (SELECT 1 FROM public.partner_baas b
                    WHERE b.id = c.partner_baa_id
                      AND b.revoked_at IS NULL
                      AND (b.expires_on IS NULL OR b.expires_on >= current_date))
      FROM public.api_clients c
     WHERE c.cognito_client_id = p_cognito_client_id
       AND p_cognito_client_id IS NOT NULL
$fn$;
COMMENT ON FUNCTION app.api_client_for_token(text) IS
    'The one pre-tenant read of api_clients (Phase 12 T04/T05): authorization columns only, '
    'looked up by the Cognito client id of a verified machine token.';
REVOKE ALL ON FUNCTION app.api_client_for_token(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.api_client_for_token(text) TO {APP_ROLE};

-- Hand the function to the lookup role. The migration role needs to be able
-- to SET ROLE to the new owner, and the owner needs CREATE on the schema at
-- the moment ownership moves; the CREATE is taken back straight after.
-- INHERIT FALSE (as 0011 does for meridian_job_control): an inheriting member
-- would pick up the two `USING (true)` lookup policies above in its own
-- sessions and read every org's api_clients and partner_baas rows with no
-- app.org_id set -- FORCE undone for the owner.
GRANT {LOOKUP_ROLE} TO CURRENT_USER WITH INHERIT FALSE, SET TRUE;
GRANT USAGE, CREATE ON SCHEMA app TO {LOOKUP_ROLE};
ALTER FUNCTION app.api_client_for_token(text) OWNER TO {LOOKUP_ROLE};
REVOKE CREATE ON SCHEMA app FROM {LOOKUP_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input


#: Revision 0011's `app.authorize_job` (Phase 11) checks a client actor: the
#: run's `created_by_client_id`, and an `active` client in the same org.
JOB_CONTROL_ROLE = "meridian_job_control"
JOB_CONTROL_GRANTS = f"""
GRANT SELECT (created_by_client_id) ON public.process_runs TO {JOB_CONTROL_ROLE};
GRANT SELECT (id, org_id, status) ON public.api_clients TO {JOB_CONTROL_ROLE};
CREATE POLICY meridian_job_control_select ON public.api_clients
    FOR SELECT TO {JOB_CONTROL_ROLE} USING (true);
"""


ALLOCATIONS = "public.employee_clinic_allocations"
OLD_ALLOCATION_KEY = "employee_clinic_allocations_employee_normalized_location_co_key"
NEW_ALLOCATION_KEY = "employee_clinic_allocations_org_employee_location_key"


#: 0002 meant to drop the replayed org-scoped key and keep live's narrow one,
#: but names it `..._loca_key`, which is what PostgreSQL 17 generates and not
#: what every version does (18 generates `..._location`). So at 0010 the
#: org-scoped key may or may not already exist; it is added only if missing.
WIDEN_ALLOCATION_KEY = f"""
ALTER TABLE {ALLOCATIONS} DROP CONSTRAINT IF EXISTS {OLD_ALLOCATION_KEY};
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
         WHERE conrelid = '{ALLOCATIONS}'::regclass AND contype = 'u'
           AND pg_get_constraintdef(oid) = 'UNIQUE (org_id, employee_normalized, location_code)'
    ) THEN
        ALTER TABLE {ALLOCATIONS} ADD CONSTRAINT {NEW_ALLOCATION_KEY}
            UNIQUE (org_id, employee_normalized, location_code);
    END IF;
END
$$;
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(WIDEN_ALLOCATION_KEY)
    op.execute(CREATE_TABLES)
    for table in TENANT_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY {POLICY} ON {table} USING {_ORG} WITH CHECK {_ORG}")
    op.execute(ADD_COLUMNS)
    op.execute(REVOKE_DELETES)
    op.execute(AUDIT)
    op.execute(CREATE_LOOKUP_ROLE)
    op.execute(LOOKUP_FUNCTION)
    op.execute(JOB_CONTROL_GRANTS)


def downgrade() -> None:
    # Dropping a function takes its owner's privileges; the migrator's
    # membership does not inherit them, so SET ROLE for the drop itself.
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{LOOKUP_ROLE}') THEN
                EXECUTE 'SET ROLE {LOOKUP_ROLE}';
                DROP FUNCTION IF EXISTS app.api_client_for_token(text);
                RESET ROLE;
            ELSE
                DROP FUNCTION IF EXISTS app.api_client_for_token(text);
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute("DROP TABLE IF EXISTS audit.api_client_change")
    op.execute("DROP TABLE IF EXISTS audit.api_request")
    op.execute("DROP FUNCTION IF EXISTS audit.refuse_change()")
    op.execute(
        """
        ALTER TABLE public.roles              DROP COLUMN IF EXISTS can_read_phi;
        ALTER TABLE public.artifact_downloads DROP COLUMN IF EXISTS api_client_id;
        ALTER TABLE public.process_runs       DROP COLUMN IF EXISTS created_by_client_id;
        """
    )
    op.execute("DROP TABLE IF EXISTS public.api_quota_window")
    for table in reversed(TENANT_TABLES):
        op.execute(f"DROP TABLE IF EXISTS {table}")
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{LOOKUP_ROLE}') THEN
                REVOKE ALL ON SCHEMA app FROM {LOOKUP_ROLE};
                REVOKE ALL ON SCHEMA public FROM {LOOKUP_ROLE};
                DROP ROLE {LOOKUP_ROLE};
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(
        f"ALTER TABLE {ALLOCATIONS} DROP CONSTRAINT IF EXISTS {NEW_ALLOCATION_KEY}, "
        f"ADD CONSTRAINT {OLD_ALLOCATION_KEY} UNIQUE (employee_normalized, location_code)"
    )
