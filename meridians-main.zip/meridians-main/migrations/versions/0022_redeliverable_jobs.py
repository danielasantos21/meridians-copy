"""redeliverable_jobs — the cross-org read the in-process transport's redelivery needs.

Revision ID: 0022_redeliverable_jobs
Revises: 0021_qbo_connection_audit
Create Date: 2026-09-24

Phase 11 D4 (`docs/reports/phase-11-plan.md` §3.3, §3.5, task D4). ADR 0011
(tenant isolation), ADR 0028 (one `run_job`, two transports), ADR 0030 (leases).
RDS-only: Supabase never runs Alembic, and nothing on Render calls any of this.

WHY
---
On SQS a job whose worker was killed is delivered again when its visibility
timeout lapses: the run's lease has lapsed too, the next worker claims it and
resumes (`attempts` + 1), and after three lapsed claims the sweeper
(`app.expire_stale_runs`) fails the run. The in-process transport keeps its
queue in the api process's memory, so a KILLED process takes the message with
it: nothing ever delivers it again, and the run sits leased at attempt 1 —
which the sweeper, waiting for attempt 3, never touches.

`workers.inprocess.Dispatcher.recover()` closes that gap the way SQS would: it
asks this function which runs have a job no live worker holds, rebuilds each
job's message from the run row (same `job_id`, the creator as the actor, the
recorded inputs) and delivers it again. Two cases:

* **killed mid-job** — `state` is a working state (`parsing`, `running`), the
  lease has lapsed, and the job has been claimed 1 or 2 times (`attempts`). At
  3 the run is the sweeper's to fail, exactly as with SQS's maxReceiveCount 3.
* **queued, never claimed** — the api's compare-and-set marked a job queued
  (`last_job_id` set, `attempts` 0, no owner) and the process died before any
  worker claimed it; `p_queued_grace_seconds` after the mark (the lapsed lease
  expiry `begin_action` writes is the mark's time).

The function answers ids, the process, the state and the attempt count — no
`run_state`, no `params`, no `inputs` — oldest first, at most `p_limit`. The
caller re-reads each run under `with_org(<its org>)` before building anything,
and `app.authorize_job` then checks the rebuilt message like any other.

INDEX
-----
`idx_process_runs_stale_lease` (0011) already holds the first case's rows
(`WHERE state IN ('parsing','running')`, on `lease_expires_at`). The second
case gets its own partial index on the same column, `WHERE attempts = 0 AND
last_job_id IS NOT NULL`: at any moment it holds only the jobs queued and not
yet claimed.

OWNER
-----
`meridian_job_control` (0011's NOLOGIN, NOBYPASSRLS owner of the worker's
definers), whose column grants on `process_runs` (0011) already cover every
column read here and whose `USING (true)` SELECT policy is for that role only.
`search_path` pinned; EXECUTE revoked from PUBLIC and granted to `meridian_app`
only, while the migrator still owns the function; then ownership moves through
0011's SET-only membership (0018/0019's way). The migrator becomes an inheriting
member of nothing.

DOWNGRADE
---------
Supported: drops the function (as its owner, 0011's way) and the index. No row
of any table changes.
"""

from __future__ import annotations

from alembic import op

revision = "0022_redeliverable_jobs"
down_revision = "0021_qbo_connection_audit"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
CONTROL_ROLE = "meridian_job_control"

#: Equal to 0011's MAX_ATTEMPTS and the queue's maxReceiveCount (plan §3.5): a
#: job claimed this many times with its lease lapsing each time is the
#: sweeper's to fail, not this function's to deliver again.
MAX_ATTEMPTS = 3

#: Bounds on the arguments: a day of grace at most, this many rows per call.
MAX_GRACE_SECONDS = 86_400
MAX_LIMIT = 1_000

SIGNATURE = "app.redeliverable_jobs(integer, integer)"
INDEX = "idx_process_runs_queued_job"

REDELIVERABLE = f"""
CREATE FUNCTION app.redeliverable_jobs(
    p_queued_grace_seconds integer,
    p_limit                integer
)
RETURNS TABLE (
    job_run_id    uuid,
    job_org_id    uuid,
    job_process   text,
    job_state     text,
    job_id        text,
    job_attempts  integer
)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF p_queued_grace_seconds IS NULL
       OR p_queued_grace_seconds NOT BETWEEN 0 AND {MAX_GRACE_SECONDS} THEN
        RAISE EXCEPTION 'redeliverable_jobs: grace must be 0-{MAX_GRACE_SECONDS} seconds'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_limit IS NULL OR p_limit NOT BETWEEN 1 AND {MAX_LIMIT} THEN
        RAISE EXCEPTION 'redeliverable_jobs: limit must be 1-{MAX_LIMIT}'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;

    -- Cross-org by design; ids and states only. Each branch reads one partial
    -- index (0011's idx_process_runs_stale_lease, this revision's
    -- idx_process_runs_queued_job).
    RETURN QUERY
    SELECT r.run_id, r.org_id, r.process, r.state, r.last_job_id, r.attempts
      FROM (
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.state IN ('parsing', 'running')
           AND pr.lease_expires_at < now()
           AND pr.last_job_id IS NOT NULL
           AND pr.attempts BETWEEN 1 AND {MAX_ATTEMPTS - 1}
        UNION ALL
        SELECT pr.run_id, pr.org_id, pr.process, pr.state, pr.last_job_id, pr.attempts,
               pr.lease_expires_at
          FROM public.process_runs pr
         WHERE pr.attempts = 0
           AND pr.last_job_id IS NOT NULL
           AND pr.lease_owner IS NULL
           AND pr.state NOT IN ('completed', 'failed', 'expired', 'superseded')
           AND pr.lease_expires_at < now() - make_interval(secs => p_queued_grace_seconds)
      ) AS r
     ORDER BY r.lease_expires_at, r.run_id
     LIMIT p_limit;
END
$fn$;
COMMENT ON FUNCTION {SIGNATURE} IS
    'Phase 11 D4: jobs no live worker holds - killed mid-job (a lapsed lease, fewer than '
    '{MAX_ATTEMPTS} claims) or queued and never claimed - for the in-process transport to '
    'deliver again. Cross-org by design; returns ids and states only.';
CREATE INDEX {INDEX}
    ON public.process_runs (lease_expires_at)
    WHERE attempts = 0 AND last_job_id IS NOT NULL;
"""  # noqa: S608 DDL from module constants; no runtime input

#: Grants while the migrator still owns the function, then ownership to the
#: control role through 0011's SET-only membership (0018's way).
OWNERSHIP = f"""
REVOKE ALL ON FUNCTION {SIGNATURE} FROM PUBLIC;
GRANT EXECUTE ON FUNCTION {SIGNATURE} TO {APP_ROLE};
GRANT USAGE, CREATE ON SCHEMA app TO {CONTROL_ROLE};
ALTER FUNCTION {SIGNATURE} OWNER TO {CONTROL_ROLE};
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""


def upgrade() -> None:
    op.execute(REDELIVERABLE)
    op.execute(OWNERSHIP)


def downgrade() -> None:
    # The function belongs to the control role; the migrator's membership does
    # not inherit its privileges, so SET ROLE for the drop itself (0011's way).
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CONTROL_ROLE}') THEN
                EXECUTE 'SET ROLE {CONTROL_ROLE}';
                DROP FUNCTION IF EXISTS {SIGNATURE};
                RESET ROLE;
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(f"DROP INDEX IF EXISTS public.{INDEX}")
