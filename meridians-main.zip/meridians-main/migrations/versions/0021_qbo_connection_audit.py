"""qbo_connection_audit — who connected or disconnected QuickBooks, and when.

Revision ID: 0021_qbo_connection_audit
Revises: 0020_sweeper_run_events
Create Date: 2026-09-24

Decision D18 option 2 (provisional): "Connect QuickBooks" moved from the Flask
`/qbo/connect` + `/qbo/callback` views into the React settings screen, over
`/api/v2/qbo/connection` (`api/routers/qbo.py`, `src/api/v2/qbo_connection.py`).
Connecting a company re-points where the whole organization's journal entries
are posted, and disconnecting stops every push, so both are org-wide admin
actions and each leaves an append-only row here — the pattern of 0015's
`audit.org_created` and 0017's `audit.invite_redeemed`.

`audit.qbo_connection_change`: one row per connect (per realm) and one per
realm removed by a disconnect, written in the SAME transaction as the
`public.qbo_connection` write it describes (`src/qbo_client.save_connection`,
`delete_connections`), so a connection with no audit row cannot exist.

Ids, the realm id, the environment and the action — NEVER a token. The realm id
is Intuit's company number, which identifies a QuickBooks company and is not a
credential (it is in every API URL). `actor_user_id` is NULL only for the
local-development bypass, whose user id is not a UUID.

Append-only the 0013 way: INSERT for `meridian_app` and nothing else, plus
`audit.refuse_change()` on UPDATE, DELETE and TRUNCATE for everybody, the owner
included. Not a tenant table (no RLS), like every other `audit.*` table: the
application never reads it.

RDS-only: Supabase never runs Alembic. On the Supabase backend the same fact is
the `qbo_connection_change` log event (`src/log_setup.py`), which the service
emits on both backends.

DOWNGRADE drops the table.
"""

from __future__ import annotations

from alembic import op

revision = "0021_qbo_connection_audit"
down_revision = "0020_sweeper_run_events"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
AUDIT_TABLE = "audit.qbo_connection_change"

AUDIT = f"""
CREATE TABLE {AUDIT_TABLE} (
    id             bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at             timestamptz NOT NULL DEFAULT now(),
    org_id         uuid        NOT NULL,
    actor_user_id  uuid,
    action         text        NOT NULL CHECK (action IN ('connected', 'disconnected')),
    realm_id       text        NOT NULL CHECK (length(realm_id) <= 64),
    environment    text        CHECK (environment IN ('sandbox', 'production'))
);
COMMENT ON TABLE {AUDIT_TABLE} IS
    'One row per QuickBooks connect or disconnect (D18), written in the transaction '
    'that changes public.qbo_connection. Ids and the realm -- never a token. Append-only.';
CREATE INDEX idx_qbo_connection_change_org ON {AUDIT_TABLE} (org_id, at DESC);
REVOKE ALL ON {AUDIT_TABLE} FROM {APP_ROLE}, {PHI_ROLE};
GRANT INSERT ON {AUDIT_TABLE} TO {APP_ROLE};
GRANT USAGE, SELECT ON SEQUENCE audit.qbo_connection_change_id_seq TO {APP_ROLE};
CREATE TRIGGER qbo_connection_change_append_only
    BEFORE UPDATE OR DELETE ON {AUDIT_TABLE}
    FOR EACH ROW EXECUTE FUNCTION audit.refuse_change();
CREATE TRIGGER qbo_connection_change_no_truncate
    BEFORE TRUNCATE ON {AUDIT_TABLE}
    FOR EACH STATEMENT EXECUTE FUNCTION audit.refuse_change();
"""


def upgrade() -> None:
    op.execute(AUDIT)


def downgrade() -> None:
    op.execute(f"DROP TABLE IF EXISTS {AUDIT_TABLE}")
