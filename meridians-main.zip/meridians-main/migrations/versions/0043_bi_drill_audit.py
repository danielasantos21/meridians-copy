"""bi_drill_audit - an access log for every BI run that returns individual rows.

Revision ID: 0043_bi_drill_audit
Revises: 0042_bi_dashboards
Create Date: 2026-10-13

WHY
---
BI Stage 5B adds "See these rows" (the individual records behind a number).
Owner decision O1: EVERY run that sends back unsummed rows is logged before the
rows are returned - "See these rows", any builder run whose last step does not
group or sum, and every admin SQL run. If the log cannot be written, the rows
are not returned (the application fails closed).

WHAT IT ADDS
------------
`public.bi_drill_audit`, one row per such run: who (user_id), when (at), what
kind of run, where it came from (a saved question, a dashboard card or an
ad-hoc question), the item ids when there are any, a 16-character fingerprint
of the query, a short summary of its filters, whether it was a preview, how
many rows came back, and whether it was cut off. NO result data and no PHI.
These are advisory (client-reported): `from_masked`, `origin`, `card_id`, `dashboard_id`
and `dashcard_id` are sent by the browser. The server checks that a named item
exists and is readable, but cannot prove the drilled query came from it. Read
them as claims; `query_hash` and the filters are server-derived.
The ids have no foreign keys on purpose, so the log outlives deleted items.

WHO CAN DO WHAT (owner decision O3)
-----------------------------------
* The application role may only INSERT (own organization, own user id). It
  cannot SELECT, UPDATE or DELETE: the log is append-only for the app.
* Reading is for Meridian superadmins only - never an organization admin.
  The database has no superadmin check, so a dedicated NOLOGIN role
  `bi_audit_reader` (created here if missing) gets a SELECT policy and a SELECT
  grant. The future superadmin viewer connects as / SET ROLEs to it. FORCE RLS
  hides the table even from a non-superuser owner, which is why this exists.
  `meridian_app` stays INSERT-only. Nobody else is granted anything.
* RETENTION: keep rows for 6 years. No purge job exists yet (a later decision).
* The organization link is ON DELETE RESTRICT, NOT cascade: an organization
  that has audit rows cannot be deleted. That is on purpose - the log must not
  disappear with the organization.

DOWNGRADE (read this first)
---------------------------
A downgrade DESTROYS the log, so it REFUSES to run while the table holds any
rows: a superadmin must export or clear the 6-year audit log first. On an empty
table it drops the table and revokes the reader's SELECT; the `bi_audit_reader`
role itself is kept (other objects may use it).
Plain Postgres 17 only.
"""

from __future__ import annotations

from alembic import op

revision = "0043_bi_drill_audit"
down_revision = "0042_bi_dashboards"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
READER_ROLE = "bi_audit_reader"
POLICY = "meridian_audit_insert"
READ_POLICY = "meridian_audit_read"
AUDIT = "public.bi_drill_audit"

COMMENT = (
    "who/when/what filters/how many rows; no results, no PHI. "
    "from_masked, origin and item ids are advisory (client-reported). Retained 6 years; "
    "org FK is RESTRICT on purpose; readable only by Meridian superadmins via bi_audit_reader"
)

COLUMN_COMMENTS = {
    "origin": "advisory, client-reported: where the browser says the run came from",
    "card_id": "advisory, client-reported: item exists and was readable, not proven to match the query",
    "dashboard_id": "advisory, client-reported: item exists and was readable, not proven to match the query",
    "dashcard_id": "advisory, client-reported: item exists and was readable, not proven to match the query",
    "from_masked": "advisory, client-reported: the browser says the click came from a hidden cell",
}

CREATE_AUDIT = f"""
CREATE TABLE {AUDIT} (
    id           bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id       uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE RESTRICT,
    user_id      uuid        NOT NULL,
    at           timestamptz NOT NULL DEFAULT now(),
    kind         text        NOT NULL CHECK (kind IN ('rows_drill', 'builder', 'native')),
    origin       text        NOT NULL CHECK (origin IN ('question', 'dashboard', 'adhoc')),
    card_id      bigint,
    dashboard_id bigint,
    dashcard_id  bigint,
    query_hash   text        NOT NULL CHECK (char_length(query_hash) = 16),
    filters      jsonb       NOT NULL DEFAULT '[]'::jsonb
        CHECK (jsonb_typeof(filters) = 'array' AND octet_length(filters::text) <= 4096),
    preview      boolean     NOT NULL DEFAULT false,
    row_count    int         NOT NULL CHECK (row_count BETWEEN 0 AND 10000),
    truncated    boolean     NOT NULL,
    from_masked  boolean     NOT NULL,
    sensitive    boolean     NOT NULL,
    UNIQUE (org_id, id)
)
"""

# Insert only, and only for yourself in your own organization.
_INSERT_RULE = "(org_id = app.current_org_id() AND user_id = app.current_user_id())"

UPGRADE_SQL: list[str] = [
    CREATE_AUDIT,
    f"CREATE INDEX bi_drill_audit_org_at ON {AUDIT} (org_id, at DESC)",
    f"CREATE INDEX bi_drill_audit_org_user_at ON {AUDIT} (org_id, user_id, at DESC)",
    f"COMMENT ON TABLE {AUDIT} IS '{COMMENT}'",
    f"ALTER TABLE {AUDIT} ENABLE ROW LEVEL SECURITY",
    f"ALTER TABLE {AUDIT} FORCE ROW LEVEL SECURITY",
    f"CREATE POLICY {POLICY} ON {AUDIT} FOR INSERT WITH CHECK {_INSERT_RULE}",
    f"REVOKE ALL ON {AUDIT} FROM {PHI_ROLE}",
    # On RDS revision 0003 set DEFAULT PRIVILEGES, so a new table starts with full
    # DML for the app role. Take that away first: the app role is INSERT-only.
    f"REVOKE ALL ON {AUDIT} FROM {APP_ROLE}",
    f"GRANT INSERT ON {AUDIT} TO {APP_ROLE}",
    *[f"COMMENT ON COLUMN {AUDIT}.{c} IS '{t}'" for c, t in COLUMN_COMMENTS.items()],
    # The superadmin reader: a NOLOGIN role, created only if missing.
    f"""DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{READER_ROLE}') THEN
        CREATE ROLE {READER_ROLE} NOLOGIN NOSUPERUSER NOBYPASSRLS;
    END IF;
END $$""",  # noqa: S608 (identifiers and constants only; values are bound parameters)
    f"CREATE POLICY {READ_POLICY} ON {AUDIT} FOR SELECT TO {READER_ROLE} USING (true)",
    f"GRANT SELECT ON {AUDIT} TO {READER_ROLE}",
]

# FORCE RLS hides rows even from the owner, so the guard first lifts FORCE; if it
# then raises, the whole statement (including the lift) is rolled back.
DOWNGRADE_SQL: list[str] = [
    f"""DO $$ BEGIN
    IF to_regclass('{AUDIT}') IS NOT NULL THEN
        ALTER TABLE {AUDIT} NO FORCE ROW LEVEL SECURITY;
        IF EXISTS (SELECT 1 FROM {AUDIT}) THEN
            RAISE EXCEPTION 'Cannot downgrade: bi_drill_audit holds audit rows. '
                'The 6-year audit log must be exported or cleared by a superadmin first.';
        END IF;
        REVOKE SELECT ON {AUDIT} FROM {READER_ROLE};
    END IF;
END $$""",  # noqa: S608 (identifiers and constants only; values are bound parameters)
    f"DROP TABLE IF EXISTS {AUDIT}",
]


def upgrade() -> None:
    for statement in UPGRADE_SQL:
        op.execute(statement)


def downgrade() -> None:
    for statement in DOWNGRADE_SQL:
        op.execute(statement)
