"""push_claim_and_input_digest — the claim a job on a FINISHED run needs, the
input fingerprint `DUPLICATE_INPUT` looks up, and the Intuit requestid history.

Revision ID: 0018_push_claim_and_input_digest
Revises: 0017_auth_state
Create Date: 2026-09-24

Phase 11: the E2 prerequisite and task E3 (`docs/reports/phase-11-plan.md`
§3.4, §3.7, §4 E2/E3). ADR 0011 (tenant isolation), ADR 0030 (leases), ADR 0032
(the idempotency table and the QBO posting algorithm). RDS-only: Supabase never
runs Alembic, and nothing on Render calls any of this.

1. `app.claim_post_completion` — THE CLAIM FOR `qbo_push`
---------------------------------------------------------
`app.claim_run` (0011) refuses a terminal run, on purpose: a job that could
lease a `completed` run could re-run its export. But qb-usa's `qbo_push` starts
FROM `completed` (the manifest: "`push_to_quickbooks` refuses anything but a
completed run"), so as 0011 stands a `qbo_push` job can never be claimed
(the open E2 issue D3 recorded).

The smallest safe door is a second function rather than a wider `claim_run`:

* `claim_run` keeps its refusal unchanged — its callers, its tests and its
  meaning ("no terminal run is ever leased") stay exactly as they were;
* `claim_post_completion(run, org, owner, lease, job_id, job_kind)` leases ONLY
  a `completed` run and ONLY for a job kind on its allowlist. Today that list
  is one pair, `('qbo_push', 'completed')`. A kind that is not on it is an
  error (`invalid_parameter_value`), never a lease; a listed kind on a run in
  any other state gets zero rows, the same "not yours" answer as `claim_run`.

It is the same lease: same columns, same "one row per winner" single UPDATE,
same per-job attempt count (`last_job_id`). It does NOT move the run's state —
a push leaves the run `completed`. It is owned by `meridian_job_control`
(0011's NOLOGIN owner, whose column grants and `USING (true)` policies already
cover every column it touches), `SECURITY DEFINER` with `search_path` pinned,
EXECUTE revoked from PUBLIC and granted to `meridian_app`. The migrator does
not become an INHERITing member of anything: 0011's `INHERIT FALSE, SET TRUE`
membership is what lets it hand ownership over, and this revision does not
grant it again (`tests/test_migrations.py`'s chain-wide non-inherit test).

`workers/run_job.POST_COMPLETION_KINDS` must equal the SQL allowlist
(`tests/test_post_completion_claim_pg.py` compares them).

2. `app.input_digest(inputs)` — WHAT `DUPLICATE_INPUT` COMPARES
---------------------------------------------------------------
Contract §12.9: running the same input twice is a WARNING
(`DUPLICATE_INPUT`, with `previous_run_id`), never a block. "The same input" is
the multiset of sha256s the api recorded in `process_runs.inputs ->
'object_versions'` (task C1). `app.input_digest` turns that list into one value
— sha256 of the sorted hashes joined by commas — or NULL when there is no list,
an empty one, or an element without a well-formed sha256. It is IMMUTABLE and
reads nothing but its argument (an ordinary invoker function, not a definer),
so an expression index can hold it:

    idx_process_runs_input_digest (org_id, process, app.input_digest(inputs))
        WHERE inputs ? 'object_versions'

EXECUTE goes to every role that writes `process_runs`, not only to the one
that looks the digest up: Postgres evaluates an index expression with the
privileges of whoever inserts or updates the row, and checks EXECUTE when it
does. `meridian_job_control` writes the row inside `claim_run`,
`claim_post_completion` and `expire_stale_runs` (its definers); without the
grant, every one of those on a run whose `inputs` carries `object_versions` —
i.e. every run the api started since C1 — fails with "permission denied for
function input_digest" (the worker then left each job for redelivery forever).
The migrator owns the function; `meridian_app` needs it for the lookup and its
own writes.

and the lookup (`src/api/v2/execute_idempotency.previous_run_with_same_input`)
is one indexed probe per execute, `LIMIT 1`, with the `org_id = %s` predicate
and RLS both in force. No column to keep in step with `inputs`: the digest is
derived from the very list `app.authorize_job` checks, so the two cannot
disagree.

3. `job_idempotency.qbo_request_id_history` — BOTH REQUESTIDS
-------------------------------------------------------------
ADR 0032's decision on Intuit's replay window: a retry after a DEFINITE failure
(Intuit answered and created nothing) is sent with a NEW requestid, because
Intuit may replay its cached failure for the old one; an AMBIGUOUS failure
(timeout, 5xx, lost response) keeps the row `pending` and reuses the old one,
because that request may have booked the journal. `src/idempotency.begin`
rotates `qbo_request_id` when it re-arms a `failed` row and appends the
superseded id here, so the ledger records every requestid ever sent for the
journal. Bounded (at most 20 superseded ids): a journal that fails definitely
twenty times needs a person, not a twenty-first request.

DOWNGRADE
---------
Supported: drops the column (its history is lost), the index, both functions.
"""

from __future__ import annotations

from alembic import op

revision = "0018_push_claim_and_input_digest"
down_revision = "0017_auth_state"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
CONTROL_ROLE = "meridian_job_control"

#: Longest lease one claim may take (0011's `MAX_LEASE_SECONDS`).
MAX_LEASE_SECONDS = 43_200

#: The only (job kind, state) pairs `claim_post_completion` leases.
#: `workers/run_job.POST_COMPLETION_KINDS` holds the same kinds.
POST_COMPLETION = (("qbo_push", "completed"),)

#: Superseded Intuit requestids one journal may accumulate.
MAX_REQUEST_ID_HISTORY = 20

CLAIM_SIGNATURE = "app.claim_post_completion(uuid, uuid, text, integer, text, text)"
DIGEST_SIGNATURE = "app.input_digest(jsonb)"

_KINDS = ", ".join(f"'{kind}'" for kind, _state in POST_COMPLETION)
_PAIRS = ", ".join(f"('{kind}', '{state}')" for kind, state in POST_COMPLETION)

CLAIM_POST_COMPLETION = f"""
CREATE FUNCTION app.claim_post_completion(
    p_run_id        uuid,
    p_org_id        uuid,
    p_owner         text,
    p_lease_seconds integer,
    p_job_id        text,
    p_job_kind      text
)
RETURNS TABLE (claimed_attempts integer, claimed_until timestamptz)
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF p_owner IS NULL OR char_length(p_owner) NOT BETWEEN 1 AND 200 THEN
        RAISE EXCEPTION 'claim_post_completion: owner must be 1-200 characters'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_lease_seconds IS NULL OR p_lease_seconds NOT BETWEEN 1 AND {MAX_LEASE_SECONDS} THEN
        RAISE EXCEPTION 'claim_post_completion: lease must be 1-{MAX_LEASE_SECONDS} seconds'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_job_id IS NULL OR char_length(p_job_id) NOT BETWEEN 1 AND 64 THEN
        RAISE EXCEPTION 'claim_post_completion: job id must be 1-64 characters'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_job_kind IS NULL OR NOT (p_job_kind = ANY (ARRAY[{_KINDS}])) THEN
        -- Only an allowlisted kind may lease a finished run. Anything else is
        -- a programming error, never a quiet "not yours".
        RAISE EXCEPTION 'claim_post_completion: this job kind may not start from a finished run'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;

    -- claim_run's single statement, with the state test inverted to the
    -- allowlisted terminal state for this kind. The row lock gives two
    -- claimers exactly one winner.
    RETURN QUERY
    UPDATE public.process_runs pr
       SET lease_owner      = p_owner,
           lease_expires_at = now() + make_interval(secs => p_lease_seconds),
           attempts         = CASE WHEN pr.last_job_id = p_job_id
                                   THEN pr.attempts + 1 ELSE 1 END,
           last_job_id      = p_job_id,
           updated_at       = now()
     WHERE pr.run_id = p_run_id
       AND pr.org_id = p_org_id
       AND (p_job_kind, pr.state) IN ({_PAIRS})
       AND (pr.lease_expires_at IS NULL OR pr.lease_expires_at < now())
    RETURNING pr.attempts, pr.lease_expires_at;
END
$fn$;
COMMENT ON FUNCTION {CLAIM_SIGNATURE} IS
    'Phase 11 E2 prerequisite / ADR 0030: lease a COMPLETED run for an allowlisted '
    'post-completion job (qbo_push). No row back = not yours. The state is not changed.';
"""  # noqa: S608 DDL from module constants; no runtime input

INPUT_DIGEST = f"""
CREATE FUNCTION app.input_digest(p_inputs jsonb)
RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    SET search_path = pg_catalog, pg_temp
AS $fn$
    SELECT CASE
        WHEN jsonb_typeof(p_inputs -> 'object_versions') IS DISTINCT FROM 'array' THEN NULL
        WHEN jsonb_array_length(p_inputs -> 'object_versions') = 0 THEN NULL
        WHEN EXISTS (
            SELECT 1 FROM jsonb_array_elements(p_inputs -> 'object_versions') AS e
             WHERE jsonb_typeof(e) IS DISTINCT FROM 'object'
                OR (e ->> 'sha256') IS NULL
                OR (e ->> 'sha256') !~ '^[0-9a-f]{{64}}$'
        ) THEN NULL
        ELSE encode(sha256(convert_to((
            SELECT string_agg(e ->> 'sha256', ',' ORDER BY e ->> 'sha256')
              FROM jsonb_array_elements(p_inputs -> 'object_versions') AS e
        ), 'UTF8')), 'hex')
    END
$fn$;
COMMENT ON FUNCTION {DIGEST_SIGNATURE} IS
    'Phase 11 E3: sha256 of the sorted input sha256s in inputs.object_versions, or NULL. '
    'What DUPLICATE_INPUT compares (contract 12.9). Reads nothing but its argument.';
REVOKE ALL ON FUNCTION {DIGEST_SIGNATURE} FROM PUBLIC;
GRANT EXECUTE ON FUNCTION {DIGEST_SIGNATURE} TO {APP_ROLE};
GRANT EXECUTE ON FUNCTION {DIGEST_SIGNATURE} TO {CONTROL_ROLE};
CREATE INDEX idx_process_runs_input_digest
    ON public.process_runs (org_id, process, app.input_digest(inputs))
    WHERE inputs ? 'object_versions';
"""  # noqa: S608 DDL from module constants; no runtime input

REQUEST_ID_HISTORY = f"""
ALTER TABLE public.job_idempotency
    ADD COLUMN qbo_request_id_history text[] NOT NULL DEFAULT '{{}}'::text[],
    ADD CONSTRAINT job_idempotency_qbo_request_id_history_check
        CHECK (cardinality(qbo_request_id_history) <= {MAX_REQUEST_ID_HISTORY});
COMMENT ON COLUMN public.job_idempotency.qbo_request_id_history IS
    'ADR 0032: every Intuit requestid a DEFINITE failure superseded, oldest first. '
    'qbo_request_id is the one to send now.';
"""

#: Grants while the migrator still owns the function (after the hand-over a
#: REVOKE by the non-inheriting migrator is a silent no-op), then ownership to
#: the control role through 0011's SET-only membership.
CLAIM_OWNERSHIP = f"""
REVOKE ALL ON FUNCTION {CLAIM_SIGNATURE} FROM PUBLIC;
GRANT EXECUTE ON FUNCTION {CLAIM_SIGNATURE} TO {APP_ROLE};
GRANT USAGE, CREATE ON SCHEMA app TO {CONTROL_ROLE};
ALTER FUNCTION {CLAIM_SIGNATURE} OWNER TO {CONTROL_ROLE};
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""


def upgrade() -> None:
    op.execute(CLAIM_POST_COMPLETION)
    op.execute(CLAIM_OWNERSHIP)
    op.execute(INPUT_DIGEST)
    op.execute(REQUEST_ID_HISTORY)


def downgrade() -> None:
    op.execute(
        """
        ALTER TABLE public.job_idempotency
            DROP CONSTRAINT IF EXISTS job_idempotency_qbo_request_id_history_check,
            DROP COLUMN IF EXISTS qbo_request_id_history;
        DROP INDEX IF EXISTS public.idx_process_runs_input_digest;
        """
    )
    op.execute(f"DROP FUNCTION IF EXISTS {DIGEST_SIGNATURE}")
    # The function belongs to the control role; the migrator's membership does
    # not inherit its privileges, so SET ROLE for the drop itself (0011's way).
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CONTROL_ROLE}') THEN
                EXECUTE 'SET ROLE {CONTROL_ROLE}';
                DROP FUNCTION IF EXISTS {CLAIM_SIGNATURE};
                RESET ROLE;
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
