"""bi_saved_content — saved BI questions, collections (folders) and revisions.

Revision ID: 0040_bi_saved_content
Revises: 0039_run_inputs
Create Date: 2026-10-13

WHY
---
BI Stage 4A lets a person save a question, put it in a folder ("collection"),
trash and restore it, and go back to an earlier version ("revision"). That is
the first BI feature that writes application data, so it is tenant-safe from
day one: every row carries `org_id`, Postgres row-level security (RLS) hides
other organizations' rows, and a second rule hides a person's private
"My collection" from everybody else, admins included.

WHAT IT ADDS
------------
1. `public.bi_collections` — nested folders. `personal_owner_id` is set on every
   folder inside a user's private tree; the tree's top folder also has
   `is_personal_root`. `archived_*` columns are the trash; `archived_with` is the
   id of the folder whose trashing took this row along, so restoring that folder
   brings back exactly those rows.
2. `public.bi_cards` — one saved question (definition only: no results, no PHI).
   `revision_no` is the current revision and is used for optimistic concurrency.
   `dataset_query->>'type'` is the kind ('query' = builder, 'native' = SQL).
3. `public.bi_card_revisions` — a snapshot of the card each time it changes
   (the application keeps the newest 50 per card).

`pinned_position` columns are here so Stage 4B (pins) needs no second change.

RLS: ENABLE + FORCE on all three, policy `meridian_org_isolation`. Collections
also hide other users' personal trees; cards and revisions are hidden through an
EXISTS on their (already filtered) collection / card.

Plain Postgres 17 only: identity columns, jsonb, partial unique indexes, RLS.
RDS-only: Supabase never runs Alembic. On main the store stays off until
BI_STORE_DSN is set.

DOWNGRADE drops the three tables (revisions, cards, collections).
"""

from __future__ import annotations

from alembic import op

revision = "0040_bi_saved_content"
down_revision = "0039_run_inputs"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
POLICY = "meridian_org_isolation"
COLLECTIONS = "public.bi_collections"
CARDS = "public.bi_cards"
REVISIONS = "public.bi_card_revisions"

_COLLECTION_RULE = (
    "(org_id = app.current_org_id() AND "
    "(personal_owner_id IS NULL OR personal_owner_id = app.current_user_id()))"
)
_CARD_RULE = (
    "(org_id = app.current_org_id() AND (collection_id IS NULL OR EXISTS ("
    "SELECT 1 FROM public.bi_collections c "
    "WHERE c.org_id = bi_cards.org_id AND c.id = bi_cards.collection_id)))"
)
_REVISION_RULE = (
    "(org_id = app.current_org_id() AND EXISTS ("
    "SELECT 1 FROM public.bi_cards k "
    "WHERE k.org_id = bi_card_revisions.org_id AND k.id = bi_card_revisions.card_id))"
)


def _rls(table: str, rule: str) -> list[str]:
    return [
        f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY",
        f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY",
        f"CREATE POLICY {POLICY} ON {table} USING {rule} WITH CHECK {rule}",
        f"REVOKE ALL ON {table} FROM {PHI_ROLE}",
        f"GRANT SELECT, INSERT, UPDATE, DELETE ON {table} TO {APP_ROLE}",
    ]


CREATE_COLLECTIONS = f"""
CREATE TABLE {COLLECTIONS} (
    id                bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id            uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    parent_id         bigint,
    name              text        NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 100),
    description       text        CHECK (char_length(description) <= 2000),
    personal_owner_id uuid,
    is_personal_root  boolean     NOT NULL DEFAULT false,
    pinned_position   int,
    archived_at       timestamptz,
    archived_by       uuid,
    archived_with     bigint,
    created_by        uuid        NOT NULL,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id),
    FOREIGN KEY (org_id, parent_id) REFERENCES {COLLECTIONS} (org_id, id),
    CHECK (NOT is_personal_root OR (personal_owner_id IS NOT NULL AND parent_id IS NULL))
)
"""

CREATE_CARDS = f"""
CREATE TABLE {CARDS} (
    id                     bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id                 uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    collection_id          bigint,
    kind                   text        NOT NULL DEFAULT 'question' CHECK (kind IN ('question')),
    name                   text        NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 200),
    description            text        CHECK (char_length(description) <= 2000),
    display                text        NOT NULL CHECK (display ~ '^[a-z_]{{1,40}}$'),
    visualization_settings jsonb       NOT NULL DEFAULT '{{}}'::jsonb
        CHECK (jsonb_typeof(visualization_settings) = 'object'
               AND octet_length(visualization_settings::text) <= 32768),
    dataset_query          jsonb       NOT NULL
        CHECK (dataset_query->>'type' IN ('query', 'native')
               AND octet_length(dataset_query::text) <= 65536),
    parameters             jsonb       NOT NULL DEFAULT '[]'::jsonb,
    revision_no            int         NOT NULL DEFAULT 1,
    pinned_position        int,
    archived_at            timestamptz,
    archived_by            uuid,
    archived_with          bigint,
    created_by             uuid        NOT NULL,
    updated_by             uuid        NOT NULL,
    created_at             timestamptz NOT NULL DEFAULT now(),
    updated_at             timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, id),
    FOREIGN KEY (org_id, collection_id) REFERENCES {COLLECTIONS} (org_id, id)
)
"""

CREATE_REVISIONS = f"""
CREATE TABLE {REVISIONS} (
    id             bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id         uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    card_id        bigint      NOT NULL,
    revision_no    int         NOT NULL,
    snapshot       jsonb       NOT NULL,
    message        text        NOT NULL CHECK (message IN
        ('created', 'edited_query', 'edited_chart', 'renamed', 'moved',
         'reverted', 'trashed', 'restored')),
    is_creation    boolean     NOT NULL DEFAULT false,
    is_reversion   boolean     NOT NULL DEFAULT false,
    reverted_to    int,
    changed_by     uuid        NOT NULL,
    created_at     timestamptz NOT NULL DEFAULT now(),
    UNIQUE (card_id, revision_no),
    FOREIGN KEY (org_id, card_id) REFERENCES {CARDS} (org_id, id) ON DELETE CASCADE
)
"""

UPGRADE_SQL: list[str] = [
    CREATE_COLLECTIONS,
    # Sibling names are unique (case-insensitively) among ACTIVE folders; each
    # user's private tree is its own namespace.
    f"""CREATE UNIQUE INDEX bi_collections_sibling_name ON {COLLECTIONS}
        (org_id, COALESCE(parent_id, 0),
         COALESCE(personal_owner_id, '00000000-0000-0000-0000-000000000000'::uuid),
         lower(name)) WHERE archived_at IS NULL""",
    f"""CREATE UNIQUE INDEX bi_collections_one_personal_root ON {COLLECTIONS}
        (org_id, personal_owner_id) WHERE is_personal_root""",
    f"""CREATE INDEX bi_collections_parent ON {COLLECTIONS}
        (org_id, parent_id) WHERE archived_at IS NULL""",
    f"""COMMENT ON TABLE {COLLECTIONS} IS
        'BI folders. Definitions only: no query results, no PHI.'""",
    *_rls(COLLECTIONS, _COLLECTION_RULE),
    CREATE_CARDS,
    f"""CREATE INDEX bi_cards_collection ON {CARDS}
        (org_id, collection_id) WHERE archived_at IS NULL""",
    f"""CREATE INDEX bi_cards_trash ON {CARDS}
        (org_id, archived_at) WHERE archived_at IS NOT NULL""",
    f"""COMMENT ON TABLE {CARDS} IS
        'Saved BI questions. The query definition only: no query results, no PHI.'""",
    *_rls(CARDS, _CARD_RULE),
    CREATE_REVISIONS,
    f"""CREATE INDEX bi_card_revisions_card ON {REVISIONS}
        (org_id, card_id, revision_no DESC)""",
    f"""COMMENT ON TABLE {REVISIONS} IS
        'Snapshots of a saved question (newest 50 kept). Definitions only: no PHI.'""",
    *_rls(REVISIONS, _REVISION_RULE),
]

DOWNGRADE_SQL: list[str] = [
    f"DROP TABLE IF EXISTS {REVISIONS}",
    f"DROP TABLE IF EXISTS {CARDS}",
    f"DROP TABLE IF EXISTS {COLLECTIONS}",
]


def upgrade() -> None:
    for statement in UPGRADE_SQL:
        op.execute(statement)


def downgrade() -> None:
    for statement in DOWNGRADE_SQL:
        op.execute(statement)
