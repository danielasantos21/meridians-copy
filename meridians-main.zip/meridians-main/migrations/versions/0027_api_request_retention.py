"""api_request_retention — `audit.api_request` rows leave RDS after 400 days, once exported.

Revision ID: 0027_api_request_retention
Revises: 0026_claim_boundary_sweep_index
Create Date: 2026-09-25

Critic Stage 1 L-9: `audit.api_request` (0013) is one row per `/api/v3` call with
no retention, so it grows for ever. ADR 0040 decision 4 already said how it
ends: the HIPAA six-year rule is met by the audit EXPORT to the Object-Locked
`audit` bucket (seven years, compliance mode), "not by keeping rows in RDS for
ever". This revision is the RDS half of that sentence; the export itself is
Stage 3 work (tracker T:57 (c)).

WHAT IT ADDS
------------
* `audit.api_request_export` — one row, `exported_through`: every
  `audit.api_request` row at or before this instant is in the audit bucket.
  Written by the export (Stage 3) and nobody else; until then it has no row.
* `app.prune_api_request_audit(p_limit)` — SECURITY DEFINER, owned by
  0011's `meridian_job_control` (NOLOGIN, NOBYPASSRLS), EXECUTE for
  `meridian_app` only. Deletes, oldest first and at most `p_limit` per call,
  the rows older than **400 days** (`RETENTION_DAYS`, the CloudWatch log
  retention, `infra/meridian/stacks/data.py` `LOG_RETENTION`) **and** at or
  before `exported_through`. No export row → it deletes nothing and answers 0.
  Returns a count; never a row.
* `audit.api_request_refuse_change()` replaces 0013's `audit.refuse_change()`
  on this one table's UPDATE/DELETE trigger. It refuses everything it refused
  before — UPDATE always; DELETE by anybody, the table owner included — EXCEPT
  a DELETE by `meridian_job_control` (i.e. inside the definer above) of a row
  that is past retention and already exported. The rule lives in the trigger as
  well as in the function, so no other route to a DELETE (a future definer, a
  human with `SET ROLE`) can shorten retention. TRUNCATE stays refused.

WHO CALLS IT
------------
The worker's sweep tick (`workers/sweep.py`, every 15 minutes on ECS), after
`app.expire_stale_runs`. Bounded (`MAX_LIMIT`) and served by 0013's
`idx_api_request_at`.

RDS-only: Supabase never runs Alembic, and `audit.api_request` exists only here.

DOWNGRADE
---------
Supported: 0013's trigger function back on the table, the definer and the
export table dropped, the grants to the control role revoked. Rows already
deleted stay deleted — they are in the audit bucket by construction.
"""

from __future__ import annotations

from alembic import op

revision = "0027_api_request_retention"
down_revision = "0026_claim_boundary_sweep_index"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
CONTROL_ROLE = "meridian_job_control"

#: Rows younger than this never leave RDS, exported or not. The CloudWatch log
#: retention (`LOG_RETENTION = THIRTEEN_MONTHS`, 400 days); a test holds the two
#: and `workers/sweep.py` equal.
RETENTION_DAYS = 400
#: Rows deleted per call, at most.
MAX_LIMIT = 10_000

TABLE = "audit.api_request"
EXPORT_TABLE = "audit.api_request_export"
SIGNATURE = "app.prune_api_request_audit(integer)"
TRIGGER_FN = "audit.api_request_refuse_change()"

EXPORT = f"""
CREATE TABLE {EXPORT_TABLE} (
    singleton         boolean     PRIMARY KEY DEFAULT true CHECK (singleton),
    exported_through  timestamptz NOT NULL,
    recorded_at       timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE {EXPORT_TABLE} IS
    'One row: every audit.api_request row at or before exported_through is in the '
    'Object-Locked audit bucket (ADR 0040 d4). Written by the audit export only; '
    'no row means nothing has been exported and nothing may be pruned.';
-- 0003's default privileges hand INSERT on a new audit table to both
-- application roles; neither writes this one (the export does).
REVOKE ALL ON {EXPORT_TABLE} FROM PUBLIC, {APP_ROLE}, {PHI_ROLE};
GRANT USAGE ON SCHEMA audit TO {CONTROL_ROLE};
GRANT SELECT ON {EXPORT_TABLE} TO {CONTROL_ROLE};
GRANT SELECT (id, at) ON {TABLE} TO {CONTROL_ROLE};
GRANT DELETE ON {TABLE} TO {CONTROL_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input

TRIGGER = f"""
CREATE FUNCTION {TRIGGER_FN} RETURNS trigger
    LANGUAGE plpgsql
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF TG_OP = 'DELETE'
       AND current_user = '{CONTROL_ROLE}'
       AND OLD.at < now() - make_interval(days => {RETENTION_DAYS})
       AND OLD.at <= (SELECT e.exported_through FROM {EXPORT_TABLE} e WHERE e.singleton)
    THEN
        RETURN OLD;
    END IF;
    RAISE EXCEPTION '% on %.% is refused: this audit table is append-only',
        TG_OP, TG_TABLE_SCHEMA, TG_TABLE_NAME
        USING ERRCODE = 'insufficient_privilege';
END
$fn$;
REVOKE ALL ON FUNCTION {TRIGGER_FN} FROM PUBLIC;
DROP TRIGGER api_request_append_only ON {TABLE};
CREATE TRIGGER api_request_append_only
    BEFORE UPDATE OR DELETE ON {TABLE}
    FOR EACH ROW EXECUTE FUNCTION {TRIGGER_FN};
"""  # noqa: S608 DDL from module constants; no runtime input

PRUNE = f"""
CREATE FUNCTION {SIGNATURE.replace("(integer)", "(p_limit integer)")}
RETURNS integer
    LANGUAGE plpgsql VOLATILE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
DECLARE
    v_cutoff  timestamptz;
    v_deleted integer;
BEGIN
    IF p_limit IS NULL OR p_limit NOT BETWEEN 1 AND {MAX_LIMIT} THEN
        RAISE EXCEPTION 'prune_api_request_audit: limit must be 1-{MAX_LIMIT}'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    SELECT least(now() - make_interval(days => {RETENTION_DAYS}), e.exported_through)
      INTO v_cutoff
      FROM {EXPORT_TABLE} e
     WHERE e.singleton;
    IF v_cutoff IS NULL THEN
        RETURN 0;  -- nothing exported yet: nothing may leave RDS
    END IF;
    DELETE FROM {TABLE} a
     WHERE a.id IN (
        SELECT r.id FROM {TABLE} r
         WHERE r.at <= v_cutoff
           AND r.at < now() - make_interval(days => {RETENTION_DAYS})
         ORDER BY r.at
         LIMIT p_limit
     );
    GET DIAGNOSTICS v_deleted = ROW_COUNT;
    RETURN v_deleted;
END
$fn$;
COMMENT ON FUNCTION {SIGNATURE} IS
    'Critic Stage 1 L-9 / ADR 0040 d4: delete at most p_limit audit.api_request rows older '
    'than {RETENTION_DAYS} days AND already exported (audit.api_request_export). Returns a count.';
REVOKE ALL ON FUNCTION {SIGNATURE} FROM PUBLIC;
GRANT EXECUTE ON FUNCTION {SIGNATURE} TO {APP_ROLE};
GRANT USAGE, CREATE ON SCHEMA app TO {CONTROL_ROLE};
ALTER FUNCTION {SIGNATURE} OWNER TO {CONTROL_ROLE};
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""  # noqa: S608 DDL from module constants; no runtime input


def upgrade() -> None:
    op.execute(EXPORT)
    op.execute(TRIGGER)
    op.execute(PRUNE)


def downgrade() -> None:
    # The function belongs to the control role; the migrator's membership does
    # not inherit its privileges, so SET ROLE for the drop itself (0022's way).
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CONTROL_ROLE}') THEN
                EXECUTE 'SET ROLE {CONTROL_ROLE}';
                DROP FUNCTION IF EXISTS {SIGNATURE};
                RESET ROLE;
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(
        f"""
        DROP TRIGGER IF EXISTS api_request_append_only ON {TABLE};
        CREATE TRIGGER api_request_append_only
            BEFORE UPDATE OR DELETE ON {TABLE}
            FOR EACH ROW EXECUTE FUNCTION audit.refuse_change();
        DROP FUNCTION IF EXISTS {TRIGGER_FN};
        REVOKE SELECT (id, at) ON {TABLE} FROM {CONTROL_ROLE};
        REVOKE DELETE ON {TABLE} FROM {CONTROL_ROLE};
        DROP TABLE IF EXISTS {EXPORT_TABLE};
        REVOKE USAGE ON SCHEMA audit FROM {CONTROL_ROLE};
        """  # noqa: S608 DDL from module constants; no runtime input
    )
