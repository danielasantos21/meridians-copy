"""bi_exec_tables - the Executive Report's two typed tables, shared per organization and period.

Revision ID: 0049_bi_exec_tables
Revises: 0048_ecw_mart
Create Date: 2026-10-19

WHY
---
The Executive Report page has two tables people type into (Highlights and
Initiatives). Until now that text lived only in the browser (localStorage), so
it was lost on another computer and could not be shared. Project rule: everything
new that stores data lives in AWS RDS, per organization, with RLS.

WHAT IT ADDS
------------
1. `public.bi_exec_tables`: one JSONB document per (organization, fiscal year,
   period or quarter edition, which period, table kind). `version` is the
   compare-and-set counter: a save only succeeds when the caller names the
   current version. The app role may SELECT, INSERT and UPDATE; it can NOT
   delete (a table is cleared by saving).
2. `public.bi_exec_table_revisions`: one append-only row per save (who, when,
   version, via, the full rows). The app role may only SELECT and INSERT, so the
   history cannot be rewritten or pruned by the application.

Typed report text only: no PHI, no patient identifiers.

RLS: ENABLE + FORCE on both, policy `meridian_org_isolation`. Revisions are
hidden through an EXISTS on their (already filtered) table row.
Plain Postgres 17 only.

DOWNGRADE (read this first)
---------------------------
A downgrade DROPS both tables and so DESTROYS every saved Executive Report row
and its revision history. Back up first.
"""

from __future__ import annotations

from alembic import op

revision = "0049_bi_exec_tables"
down_revision = "0048_ecw_mart"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
PHI_ROLE = "phi_access"
POLICY = "meridian_org_isolation"
TABLES = "public.bi_exec_tables"
REVISIONS = "public.bi_exec_table_revisions"

COMMENT = "typed report text only; no PHI, no patient identifiers"

_TABLES_RULE = "(org_id = app.current_org_id())"
_REVISIONS_RULE = (
    "(org_id = app.current_org_id() AND EXISTS ("  # noqa: S608 (identifiers and constants only)
    "SELECT 1 FROM public.bi_exec_tables t "
    "WHERE t.org_id = bi_exec_table_revisions.org_id "
    "AND t.id = bi_exec_table_revisions.table_id))"
)

UPGRADE_SQL: list[str] = [
    f"""
CREATE TABLE {TABLES} (
    id          bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id      uuid        NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    fiscal_year int         NOT NULL CHECK (fiscal_year BETWEEN 2000 AND 2100),
    edition     text        NOT NULL CHECK (edition IN ('period', 'quarter')),
    which       int         NOT NULL CHECK (which BETWEEN 1 AND 12),
    kind        text        NOT NULL CHECK (kind IN ('highlights', 'initiatives')),
    rows        jsonb       NOT NULL DEFAULT '[]'::jsonb CHECK (
        jsonb_typeof(rows) = 'array'
        AND jsonb_array_length(rows) <= 37
        AND octet_length(rows::text) <= 262144),
    version     int         NOT NULL DEFAULT 1 CHECK (version >= 1),
    created_by  uuid        NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_by  uuid        NOT NULL,
    updated_at  timestamptz NOT NULL DEFAULT now(),
    CHECK (edition <> 'quarter' OR which <= 4),
    UNIQUE (org_id, fiscal_year, edition, which, kind),
    UNIQUE (org_id, id)
)
""",
    f"""
CREATE TABLE {REVISIONS} (
    id         bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    org_id     uuid        NOT NULL,
    table_id   bigint      NOT NULL,
    version    int         NOT NULL,
    rows       jsonb       NOT NULL CHECK (
        jsonb_typeof(rows) = 'array' AND octet_length(rows::text) <= 262144),
    via        text        NOT NULL CHECK (via IN ('save', 'import', 'merge')),
    changed_by uuid        NOT NULL,
    changed_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (org_id, table_id, version),
    FOREIGN KEY (org_id, table_id) REFERENCES {TABLES} (org_id, id) ON DELETE CASCADE
)
""",
    f"COMMENT ON TABLE {TABLES} IS '{COMMENT}'",
    f"COMMENT ON TABLE {REVISIONS} IS '{COMMENT}'",
    f"ALTER TABLE {TABLES} ENABLE ROW LEVEL SECURITY",
    f"ALTER TABLE {TABLES} FORCE ROW LEVEL SECURITY",
    f"CREATE POLICY {POLICY} ON {TABLES} USING {_TABLES_RULE} WITH CHECK {_TABLES_RULE}",
    f"ALTER TABLE {REVISIONS} ENABLE ROW LEVEL SECURITY",
    f"ALTER TABLE {REVISIONS} FORCE ROW LEVEL SECURITY",
    f"CREATE POLICY {POLICY} ON {REVISIONS} USING {_REVISIONS_RULE} WITH CHECK {_REVISIONS_RULE}",
    # Revision 0003 set DEFAULT PRIVILEGES, so a new table starts with full DML for the
    # app role. Take that away first, then grant exactly what is needed.
    f"REVOKE ALL ON {TABLES} FROM {PHI_ROLE}",
    f"REVOKE ALL ON {REVISIONS} FROM {PHI_ROLE}",
    f"REVOKE ALL ON {TABLES} FROM {APP_ROLE}",
    f"REVOKE ALL ON {REVISIONS} FROM {APP_ROLE}",
    f"GRANT SELECT, INSERT, UPDATE ON {TABLES} TO {APP_ROLE}",
    f"GRANT SELECT, INSERT ON {REVISIONS} TO {APP_ROLE}",
]

DOWNGRADE_SQL: list[str] = [
    f"DROP TABLE IF EXISTS {REVISIONS}",
    f"DROP TABLE IF EXISTS {TABLES}",
]


def upgrade() -> None:
    for statement in UPGRADE_SQL:
        op.execute(statement)


def downgrade() -> None:
    for statement in DOWNGRADE_SQL:
        op.execute(statement)
