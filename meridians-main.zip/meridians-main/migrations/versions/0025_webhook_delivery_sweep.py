"""webhook_delivery_sweep — stalled deliveries are found again, redrive is bounded, local secrets persist.

Revision ID: 0025_webhook_delivery_sweep
Revises: 0024_job_redelivery_history
Create Date: 2026-09-25

Stage 1 critic round 1 (`docs/reports/critic-stage1-r1.md`): H-2, M-7 and M-8.
ADR 0011 (tenant isolation), ADR 0038 (webhooks). RDS-only: Supabase never runs
Alembic, and nothing on Render calls any of this.

WHAT THIS REVISION ADDS
-----------------------
1. **The stalled-delivery sweep (M-8).** A failed attempt used to rely on
   nothing but the queue's delayed message to come back. If that message was
   lost — an in-process queue whose api restarted, a Lambda that died between
   the claim and the outcome — the row stayed `pending`/`failed` forever. Now
   every open delivery that is DUE (its `next_attempt_at`, or for one never
   attempted its `created_at`, older than a grace period) can be listed by

       app.due_webhook_deliveries(p_grace_seconds integer, p_limit integer)
           RETURNS TABLE (due_delivery_id uuid, due_org_id uuid)

   ids only, oldest due first, across every organization, and re-enqueued by
   the sweep (`src/webhooks/engine.sweep_due_deliveries`), which runs on the
   worker's 5-minute `outbox_sweep` tick on AWS and on the local drainer's
   cadence on a laptop. The engine then re-reads everything under the
   delivery's own org, exactly as for any other message; a claim is still a
   conditional UPDATE, so a delivery the queue ALSO still holds is attempted
   once. The partial expression index `idx_webhook_deliveries_due` holds
   exactly the open rows, keyed on the moment they fall due.

2. **Bounded redrive (M-7).** `redrive_count` (how many times a person or a
   client put this delivery back) and `last_redriven_at`. The api refuses a
   fourth redrive and a redrive of an event older than 7 days
   (`src/webhooks/subscriptions.redrive`); the per-subscription hourly cap is
   a quota counter (`api/v3/routers/webhooks.py`). The columns make the
   per-delivery bound a fact of the row, checked in the same UPDATE that
   re-opens it.

3. **Local signing secrets that survive a restart (H-2).** On a laptop there
   is no Secrets Manager. The api used to keep each subscription's signing
   secret in a process dictionary, so a restart lost it and every later
   delivery was dropped `SECRET_UNAVAILABLE`. `public.webhook_local_secrets`
   holds the secret SEALED (AES-256-GCM under a per-secret data key, wrapped by
   the development key — `src/webhooks/local.SealedSecretStore`); the plaintext
   never reaches the database. The application refuses to use this store
   outside development (`settings.dev_fallbacks_permitted`); in AWS the table
   exists and stays empty. It is a tenant table: `org_id`, FORCE RLS and the
   org-isolation policy like every other.

OWNER OF THE FUNCTION
---------------------
`meridian_job_control` (0011's NOLOGIN, NOBYPASSRLS owner of the worker's
definers), 0019's shape exactly: column SELECT on the five columns the
function reads (`id, org_id, status, next_attempt_at, created_at` — not the
URL-free but still private `last_error_code`, not `subscription_id`), and one
`FOR SELECT TO meridian_job_control USING (true)` policy on
`public.webhook_deliveries`. `search_path` pinned, EXECUTE revoked from PUBLIC
and granted to `meridian_app` only, grants issued while the migrator still
owns the function.

DOWNGRADE
---------
Supported: drops the function (as its owner), the policy, the column grant, the
index, the two columns and the local-secrets table. Losing the table on a
laptop loses the local secrets, which is what "downgrade" means there.
"""

from __future__ import annotations

from alembic import op

revision = "0025_webhook_delivery_sweep"
down_revision = "0024_job_redelivery_history"
branch_labels = None
depends_on = None

APP_ROLE = "meridian_app"
CONTROL_ROLE = "meridian_job_control"

#: At most a day of grace, at most this many rows per call.
MAX_GRACE_SECONDS = 86_400
MAX_LIMIT = 1_000

#: The columns the function reads, and the only ones the control role may.
READ_COLUMNS = ("id", "org_id", "status", "next_attempt_at", "created_at")

SIGNATURE = "app.due_webhook_deliveries(integer, integer)"
POLICY = "meridian_job_control_select"
ORG_POLICY = "meridian_org_isolation"
_ORG = "(org_id = app.current_org_id())"

LOCAL_SECRETS = "public.webhook_local_secrets"

#: When an open delivery falls due: its scheduled attempt, or — never attempted,
#: never scheduled — the moment it was created.
DUE_AT = "COALESCE(next_attempt_at, created_at)"

COLUMNS = f"""
ALTER TABLE public.webhook_deliveries
    ADD COLUMN redrive_count    integer     NOT NULL DEFAULT 0 CHECK (redrive_count >= 0),
    ADD COLUMN last_redriven_at timestamptz;
CREATE INDEX idx_webhook_deliveries_due
    ON public.webhook_deliveries (({DUE_AT}), id)
    WHERE status IN ('pending', 'failed');
"""

TABLE = f"""
CREATE TABLE {LOCAL_SECRETS} (
    ref         text        PRIMARY KEY CHECK (length(ref) BETWEEN 1 AND 300),
    org_id      uuid        NOT NULL REFERENCES public.organizations(id),
    sealed      bytea       NOT NULL,
    wrapped_key bytea       NOT NULL,
    key_id      text        NOT NULL CHECK (length(key_id) <= 100),
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE {LOCAL_SECRETS} IS
    'Local development only: webhook signing secrets sealed under the development key. '
    'Empty in AWS (Secrets Manager holds them there). Never plaintext.';
ALTER TABLE {LOCAL_SECRETS} ENABLE ROW LEVEL SECURITY;
ALTER TABLE {LOCAL_SECRETS} FORCE ROW LEVEL SECURITY;
CREATE POLICY {ORG_POLICY} ON {LOCAL_SECRETS} USING {_ORG} WITH CHECK {_ORG};
"""

GRANTS = f"""
GRANT SELECT ({", ".join(READ_COLUMNS)}) ON public.webhook_deliveries TO {CONTROL_ROLE};
CREATE POLICY {POLICY} ON public.webhook_deliveries
    FOR SELECT TO {CONTROL_ROLE} USING (true);
"""

DUE = f"""
CREATE FUNCTION app.due_webhook_deliveries(
    p_grace_seconds integer,
    p_limit         integer
)
RETURNS TABLE (due_delivery_id uuid, due_org_id uuid)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path = pg_catalog, pg_temp
AS $fn$
BEGIN
    IF p_grace_seconds IS NULL
       OR p_grace_seconds NOT BETWEEN 0 AND {MAX_GRACE_SECONDS} THEN
        RAISE EXCEPTION 'due_webhook_deliveries: grace must be 0-{MAX_GRACE_SECONDS} seconds'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;
    IF p_limit IS NULL OR p_limit NOT BETWEEN 1 AND {MAX_LIMIT} THEN
        RAISE EXCEPTION 'due_webhook_deliveries: limit must be 1-{MAX_LIMIT}'
            USING ERRCODE = 'invalid_parameter_value';
    END IF;

    -- Cross-org by design; ids only. idx_webhook_deliveries_due holds exactly
    -- these rows, keyed on the same expression.
    RETURN QUERY
    SELECT d.id, d.org_id
      FROM public.webhook_deliveries d
     WHERE d.status IN ('pending', 'failed')
       AND COALESCE(d.next_attempt_at, d.created_at)
           <= now() - make_interval(secs => p_grace_seconds)
     ORDER BY COALESCE(d.next_attempt_at, d.created_at), d.id
     LIMIT p_limit;
END
$fn$;
COMMENT ON FUNCTION {SIGNATURE} IS
    'Critic Stage 1 M-8: open webhook deliveries past their due time plus the grace period, '
    'oldest first, for the sweep to re-enqueue. Cross-org by design; returns ids only.';
"""  # noqa: S608 DDL from module constants; no runtime input

#: Grants while the migrator still owns the function, then ownership to the
#: control role through 0011's SET-only membership (0019's way).
OWNERSHIP = f"""
REVOKE ALL ON FUNCTION {SIGNATURE} FROM PUBLIC;
GRANT EXECUTE ON FUNCTION {SIGNATURE} TO {APP_ROLE};
GRANT USAGE, CREATE ON SCHEMA app TO {CONTROL_ROLE};
ALTER FUNCTION {SIGNATURE} OWNER TO {CONTROL_ROLE};
REVOKE CREATE ON SCHEMA app FROM {CONTROL_ROLE};
"""


def upgrade() -> None:
    op.execute(COLUMNS)
    op.execute(TABLE)
    op.execute(GRANTS)
    op.execute(DUE)
    op.execute(OWNERSHIP)


def downgrade() -> None:
    op.execute(
        f"""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{CONTROL_ROLE}') THEN
                EXECUTE 'SET ROLE {CONTROL_ROLE}';
                DROP FUNCTION IF EXISTS {SIGNATURE};
                RESET ROLE;
            END IF;
        END
        $$;
        """  # noqa: S608 DDL from module constants; no runtime input
    )
    op.execute(f"DROP POLICY IF EXISTS {POLICY} ON public.webhook_deliveries")
    op.execute(
        f"REVOKE SELECT ({', '.join(READ_COLUMNS)}) ON public.webhook_deliveries "  # noqa: S608 DDL from module constants; no runtime input
        f"FROM {CONTROL_ROLE}"
    )
    op.execute(f"DROP TABLE IF EXISTS {LOCAL_SECRETS}")
    op.execute("DROP INDEX IF EXISTS public.idx_webhook_deliveries_due")
    op.execute(
        "ALTER TABLE public.webhook_deliveries "
        "DROP COLUMN IF EXISTS last_redriven_at, DROP COLUMN IF EXISTS redrive_count"
    )
