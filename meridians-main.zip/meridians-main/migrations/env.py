"""Alembic environment for Meridian's PostgreSQL schema.

Reads:  MERIDIAN_DATABASE_URL (the only source of the connection string)
Writes: the target database's schema, plus the `alembic_version` table

Three things about this file that are not obvious:

1. **No `sqlalchemy.url` in `alembic.ini`.** The URL is read from the
   environment at runtime. A connection string in a tracked file is a leak
   waiting to happen, and staging/production/CI each need a different one.

2. **`alembic` runs as the migration/owner role, never as `meridian_app`.**
   Revision 0003 creates `meridian_app` as a non-owner role with no
   `BYPASSRLS`; if migrations ran as that role they could not create or alter
   anything. Point `MERIDIAN_DATABASE_URL` at the owner/migration credential.

3. **No SQLAlchemy models.** `target_metadata` is `None` on purpose: this
   project has no ORM (ADR 0005 — raw SQL behind a repository layer), so
   autogenerate is not available and every revision is hand-written SQL.
   `alembic revision --autogenerate` will produce an empty revision; use
   `alembic revision -m "..."` instead.
"""

from __future__ import annotations

import os

from alembic import context
from sqlalchemy import engine_from_config, pool

config = context.config

target_metadata = None


def _database_url() -> str:
    url = os.environ.get("MERIDIAN_DATABASE_URL")
    if not url:
        raise RuntimeError(
            "MERIDIAN_DATABASE_URL is not set. Alembic reads the connection "
            "string from the environment; there is no URL in alembic.ini."
        )
    # psycopg2 is the driver this project already depends on (D-21). Normalise
    # the bare `postgresql://` form so SQLAlchemy does not pick a driver we do
    # not ship.
    if url.startswith("postgresql://"):
        url = "postgresql+psycopg2://" + url[len("postgresql://") :]
    elif url.startswith("postgres://"):
        url = "postgresql+psycopg2://" + url[len("postgres://") :]
    return url


def run_migrations_offline() -> None:
    """Emit SQL to stdout instead of executing it (`alembic upgrade head --sql`)."""
    context.configure(
        url=_database_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    section = config.get_section(config.config_ini_section) or {}
    section["sqlalchemy.url"] = _database_url()
    connectable = engine_from_config(section, prefix="sqlalchemy.", poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
