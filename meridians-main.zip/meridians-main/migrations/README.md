# migrations/

The Alembic chain that builds Meridian's PostgreSQL schema on RDS (and on the local and
test databases). Decided in ADR 0019; how to run it and the rules for writing a revision are
in `docs/runbooks/migrations.md`.

```bash
MERIDIAN_DATABASE_URL=postgresql://meridian_migrator:...@host/db \
  alembic -c migrations/alembic.ini upgrade head
```

The URL is the OWNER role (`meridian_migrator`), never `meridian_app`. Locally,
`scripts/local_db_bootstrap.sh` runs this for you; the test suite's `tests/pg_fixture.py`
builds a throwaway server at head for every run.

## What lives here

| Path | What it is |
|---|---|
| `alembic.ini`, `env.py` | Alembic's configuration. The URL comes from `MERIDIAN_DATABASE_URL`, never from the file. |
| `baseline/` | The committed `pg_dump --schema-only` of live Supabase (2026-09-15) and the drift diffs `scripts/diff_baseline_schema.py` wrote against it. Read-only evidence for revisions 0001-0002. |
| `versions/` | One file per revision, applied in order. |

## The chain

| Revision | What it does |
|---|---|
| `0001_baseline_supabase` | Replays the 37 `supabase_migrations/` files verbatim. |
| `0002_reconcile_live_drift` | Makes the replay equal the live Supabase schema (floats, naive timestamps, missing cascades, text actor columns). No downgrade. |
| `0003_rds_adaptations` | Strips what only made sense on Supabase; creates the roles, `phi` and `audit` schemas. |
| `0004_rls_app_org_id` | FORCE row-level security on every tenant table, keyed on `app.org_id`. |
| `0005_drop_txn_identifiers` | The DDL half of the PHI split: identifiers leave `public.transactions`. |
| `0006_user_profiles` | The app's own store for what Supabase kept in `user_metadata`. |
| `0007_invoice_numbers` | A per-org invoice counter that cannot hand out a number twice. |
| `0008_process_runs_unique` | `UNIQUE (run_id, org_id)` on `process_runs`. |
| `0009_org_members_user_policy` | The identity reads made before an organization is known. |
| `0010_superadmin_org_list` | The one audited cross-organization read. |
| `0011_process_runs_worker` | Run leases and the worker's definer functions. |
| `0012_job_idempotency` | The ledger that stops a redelivered job posting twice. |
| `0013_api_platform` | Machine clients, partner BAAs, webhooks, the event outbox, the API audit trail, quotas. |
| `0014_webhook_delivery_history` | When a webhook delivery was created and last tried. |
| `0015_create_organization` | The audited, owner-side way to create an organization. |
| `0016_api_client_admin_gaps` | API usage metrics, BAA revocation, the rotation flag. |
| `0017_auth_state` | The half-finished sign-in store, invite-redemption audit, admin read of members' profiles. |
| `0018_push_claim_and_input_digest` | The claim for a job on a finished run, the input fingerprint, the Intuit requestid history. |
| `0019_outbox_sweep` | The cross-org read the webhook outbox sweep needs. |
| `0020_sweeper_run_events` | The TTL sweeper announces what it moves. |
| `0021_qbo_connection_audit` | Who connected or disconnected QuickBooks. |
| `0022_redeliverable_jobs` | The cross-org read the in-process transport's redelivery needs. |
| `0023_qbo_token_envelope` | QuickBooks OAuth tokens stored sealed. |

Revisions written but **held** until the port gate is green (tracker T:99) live on the branch
`hold/post-parity-schema`, not here — see `docs/migration-tracker.md`, "Drain status".

## What does not live here

- **Hand-edited schema.** Every change is a new revision; nothing is changed in the console
  or through the Supabase MCP tools.
- **Seed data with real names or PHI.** Local seeds are synthetic (`scripts/seed_local_dev.py`).
- **Secrets.** Role passwords come from `MERIDIAN_APP_DB_PASSWORD` /
  `MERIDIAN_PHI_DB_PASSWORD` at upgrade time.
- **The Supabase-era SQL.** That is `supabase_migrations/`, history since `0001` replays it.
