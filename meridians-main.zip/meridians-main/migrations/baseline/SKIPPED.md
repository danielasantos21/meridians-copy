# What revision 0001 does not replay

`migrations/versions/0001_baseline_supabase.py` executes the 37 files in
`supabase_migrations/migrations/` verbatim, in filename order. This file is the
complete list of what it leaves out, and why. It is the companion to the
allowlist in that revision's `SKIP_FILES` / `SKIP_STATEMENTS`; if the two ever
disagree, the code is right and this file is stale.

Every entry is a decision, not an accident. Nothing is skipped because it
"failed" — a statement that errors and is swallowed is how
`deploy/aws-trial/apply_migrations.py` produced a "successful" replay that was
never checked (it caught every exception, logged `WARN`, and carried on). The
Alembic replay is strict: any statement that errors stops the migration.

---

## Skipped whole files

### `003_storage_buckets.sql` — all 5 statements

Supabase Storage only. RDS has no `storage` schema; S3 replaces it
(plan step 7, `S3StorageManager` in `src/storage.py`).

1. `INSERT INTO storage.buckets (id, name, public) VALUES ('uploads', 'uploads', false);`
2. `INSERT INTO storage.buckets (id, name, public) VALUES ('outputs', 'outputs', false);`
3. `INSERT INTO storage.buckets (id, name, public) VALUES ('templates', 'templates', false);`
4. `CREATE POLICY "Org members can access their uploads" ON storage.objects FOR ALL USING (...)`
5. `CREATE POLICY "Authenticated users can read templates" ON storage.objects FOR SELECT USING (...)`

---

## Skipped statements

### `011_bkv5_location_remap.sql` — the 25-row `INSERT`

```sql
INSERT INTO public.bkv5_location_remap (location_code, entity, netsuite_label)
VALUES ...   -- 25 rows, no org_id
```

Tenant data, not schema. The backfill that gives those rows an `org_id` was
moved to `supabase_migrations/seeds/` in Phase 0 because it names a tenant.
Replaying the `INSERT` without the backfill makes `012`'s
`ALTER COLUMN org_id SET NOT NULL` fail on a fresh database — the migration
chain simply does not build. `012`'s own comment says "a fresh replay reaches
STEP 3 with an empty table", which is true **only** once this `INSERT` is
skipped. A fresh database gets these rows from the seed, like every other
tenant row.

### `014_rls_with_check_user_org_id_fix.sql` — its 8 statements on `public.clients` / `public.invoices`

```sql
ALTER TABLE public.clients  ADD COLUMN IF NOT EXISTS org_id UUID REFERENCES ...;
ALTER TABLE public.invoices ADD COLUMN IF NOT EXISTS org_id UUID REFERENCES ...;
ALTER TABLE public.clients  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "org_isolation" ON public.clients;
CREATE POLICY "org_isolation" ON public.clients  USING (org_id = public.user_org_id()) WITH CHECK (...);
DROP POLICY IF EXISTS "org_isolation" ON public.invoices;
CREATE POLICY "org_isolation" ON public.invoices USING (org_id = public.user_org_id()) WITH CHECK (...);
```

Order, not intent. `public.clients` and `public.invoices` were created ad hoc
outside the migration folder; `015_document_unmigrated_tables.sql` transcribes
them with `CREATE TABLE IF NOT EXISTS`. Live, `014` ran when the tables already
existed. On a replay from empty, `014` runs **before** `015` creates them, so
all eight statements error on a missing relation.

Nothing is lost:

* the `org_id` columns are declared by `015`'s `CREATE TABLE`;
* `ENABLE ROW LEVEL SECURITY` is re-applied by revision 0002 (and by `015`);
* the policies are re-created by `015` in its own
  `org_id IN (SELECT ... FROM org_members ...)` form, which is **what the live
  dump actually shows** — `015` sorts after `014`, so live kept `015`'s version.
  Re-applying `014`'s `user_org_id()` form would put the replay one revision
  *ahead* of production.

---

## Standing rules that match nothing today

These patterns are in `SKIP_STATEMENTS` so that a future file cannot smuggle a
Supabase-only statement into RDS unnoticed. **Verified 2026-09-15: no file in
the 37 matches any of them.**

| Pattern | Why it would be skipped |
|---|---|
| `CREATE EXTENSION ...` | Supabase pre-provisions extensions; on RDS they come from the parameter group and `rds_superuser`. |
| `GRANT ... TO anon\|authenticated\|service_role` | Those PostgREST roles do not exist on RDS. `meridian_app` and `phi_access` replace them (revision 0003). |
| `ALTER DEFAULT PRIVILEGES ... anon\|authenticated\|service_role` | Same. |
| `INSERT INTO storage.*` / `CREATE POLICY ... ON storage.*` | Supabase Storage. |

---

## The `auth` preamble (added, not skipped)

The 37 files declare 14 `REFERENCES auth.users(id)` foreign keys and call
`auth.uid()` 22 times inside policies. On a bare PostgreSQL those statements
fail, so 0001 creates the smallest shim that makes them resolve:

```sql
CREATE SCHEMA auth;
CREATE TABLE auth.users (id uuid PRIMARY KEY);
CREATE FUNCTION auth.uid() RETURNS uuid ...   -- returns NULL
```

Revision 0003 drops the `auth.users` **table** and the three foreign keys that
survive reconciliation. It keeps the `auth` **schema** holding one stub
`auth.uid()` that reads `current_setting('app.user_id', true)`, because 20 live
policies on `organizations`, `org_members` and `superadmins` call it directly
and dropping the function would need `CASCADE` — which would silently drop
those policies. That narrowing is deliberate and is recorded in ADR 0019.

---

## Not recreated at all

| Object | Decision |
|---|---|
| `public.trial_migrations` | The aws-trial replay ledger. Not Meridian's schema; dropped at cutover. |
| `public.qgenda_workspaces` | No migration file, no established owner, rows excluded from the migration (plan P-4), and its only three policies are granted `TO authenticated` — a Supabase role that does not exist on RDS. It stays in the retained Supabase archive, so nothing is lost if it turns out to be Meridian's. |
| `public.alembic_version` | The reverse: created by Alembic, absent from live. |

All three are asserted as the **only** permitted differences by
`tests/test_migrations.py::test_replayed_schema_equals_live_baseline`.
