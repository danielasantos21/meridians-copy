--
-- PostgreSQL database dump
--

\restrict 7vx07fHy4ARGHW7awas1ud6bd7KFQO1vcop08MWNzQWg3aeJWG4ipUpWPSlsl7l

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.3 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: user_org_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.user_org_id() RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    AS $$
  SELECT org_id
  FROM public.org_members
  WHERE user_id = auth.uid()
  ORDER BY joined_at ASC NULLS LAST
  LIMIT 1;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artifact_downloads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artifact_downloads (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    run_id uuid,
    batch_id integer,
    artifact_id text,
    artifact_name text,
    user_id uuid,
    user_email text,
    ip text,
    user_agent text,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: artifact_downloads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.artifact_downloads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: artifact_downloads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.artifact_downloads_id_seq OWNED BY public.artifact_downloads.id;


--
-- Name: bkv5_location_remap; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bkv5_location_remap (
    location_code text NOT NULL,
    entity text NOT NULL,
    netsuite_label text NOT NULL,
    org_id uuid NOT NULL
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    address text,
    email text,
    phone text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_account_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_account_codes (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    payer_type text NOT NULL,
    account_code text NOT NULL,
    account_name text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_account_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_account_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_account_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_account_codes_id_seq OWNED BY public.config_account_codes.id;


--
-- Name: config_clinic_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_clinic_groups (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    group_name text NOT NULL,
    locations text NOT NULL,
    bank_account_key text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_clinic_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_clinic_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_clinic_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_clinic_groups_id_seq OWNED BY public.config_clinic_groups.id;


--
-- Name: config_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_departments (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: config_departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_departments_id_seq OWNED BY public.config_departments.id;


--
-- Name: config_employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_employees (
    id integer NOT NULL,
    employee_id text NOT NULL,
    name text NOT NULL,
    primary_location text,
    department text,
    active integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by text,
    org_id uuid NOT NULL
);


--
-- Name: config_employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_employees_id_seq OWNED BY public.config_employees.id;


--
-- Name: config_fiscal_calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_fiscal_calendar (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    period_key text NOT NULL,
    je_date text NOT NULL,
    period_start text,
    period_end text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_fiscal_calendar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_fiscal_calendar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_fiscal_calendar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_fiscal_calendar_id_seq OWNED BY public.config_fiscal_calendar.id;


--
-- Name: config_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_history (
    id integer NOT NULL,
    table_name text NOT NULL,
    record_id integer NOT NULL,
    field_name text NOT NULL,
    old_value text,
    new_value text,
    changed_by text,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid NOT NULL
);


--
-- Name: config_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_history_id_seq OWNED BY public.config_history.id;


--
-- Name: config_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_locations (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    clinic_group text,
    netsuite_entity text,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by text,
    org_id uuid NOT NULL,
    facility_raw text,
    has_hospital boolean DEFAULT false
);


--
-- Name: config_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_locations_id_seq OWNED BY public.config_locations.id;


--
-- Name: config_mso_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_mso_mappings (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    mapping_type text NOT NULL,
    source_key text NOT NULL,
    target_value text NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_mso_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_mso_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_mso_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_mso_mappings_id_seq OWNED BY public.config_mso_mappings.id;


--
-- Name: config_mx_employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_mx_employees (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    employee_id text NOT NULL,
    name text NOT NULL,
    "position" text DEFAULT ''::text,
    department_netsuite text DEFAULT ''::text NOT NULL,
    department text DEFAULT ''::text,
    report text DEFAULT ''::text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by uuid
);


--
-- Name: config_mx_employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_mx_employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_mx_employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_mx_employees_id_seq OWNED BY public.config_mx_employees.id;


--
-- Name: config_payers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_payers (
    id integer NOT NULL,
    name text NOT NULL,
    payer_type text,
    account_code text,
    category text,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by text,
    org_id uuid NOT NULL,
    override_type text,
    notes text
);


--
-- Name: config_payers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_payers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_payers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_payers_id_seq OWNED BY public.config_payers.id;


--
-- Name: config_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_providers (
    id integer NOT NULL,
    name text NOT NULL,
    department_code text,
    department_name text,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by text,
    org_id uuid NOT NULL,
    location_code text
);


--
-- Name: config_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_providers_id_seq OWNED BY public.config_providers.id;


--
-- Name: config_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_settings (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    setting_key text NOT NULL,
    setting_value text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: config_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_settings_id_seq OWNED BY public.config_settings.id;


--
-- Name: employee_clinic_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_clinic_allocations (
    id integer NOT NULL,
    employee_name text NOT NULL,
    employee_normalized text NOT NULL,
    location_code text NOT NULL,
    percentage double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid NOT NULL,
    entity text,
    job_category text,
    subsidiary text,
    pay_type text,
    file_number text
);


--
-- Name: employee_clinic_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_clinic_allocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_clinic_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_clinic_allocations_id_seq OWNED BY public.employee_clinic_allocations.id;


--
-- Name: fiscal_calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_calendar (
    id integer NOT NULL,
    org_id uuid,
    fiscal_year text NOT NULL,
    period integer NOT NULL,
    period_key text NOT NULL,
    date date NOT NULL
);


--
-- Name: fiscal_calendar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_calendar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_calendar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_calendar_id_seq OWNED BY public.fiscal_calendar.id;


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id integer NOT NULL,
    fiscal_year integer NOT NULL,
    period integer NOT NULL,
    input_file text NOT NULL,
    file_hash text NOT NULL,
    record_count integer DEFAULT 0,
    total_amount double precision DEFAULT 0.0,
    status text DEFAULT 'pending'::text,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    overview_data text,
    output_folder text,
    batch_type text DEFAULT 'revenue'::text,
    org_id uuid NOT NULL,
    user_id uuid,
    is_test boolean DEFAULT false NOT NULL,
    superseded_by integer,
    CONSTRAINT import_batches_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'error'::text, 'superseded'::text])))
);


--
-- Name: import_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.import_batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: import_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.import_batches_id_seq OWNED BY public.import_batches.id;


--
-- Name: invite_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invite_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    code text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    role_id uuid,
    created_by uuid NOT NULL,
    used_by uuid,
    used_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    email text
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    invoice_number text NOT NULL,
    client_id uuid,
    client_name text NOT NULL,
    client_address text,
    invoice_date date NOT NULL,
    due_date date,
    line_items jsonb NOT NULL,
    total numeric(10,2),
    notes text,
    pdf_filename text,
    status text DEFAULT 'draft'::text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id integer NOT NULL,
    batch_id integer NOT NULL,
    je_type text NOT NULL,
    clinic_group text NOT NULL,
    line_number integer NOT NULL,
    je_date text NOT NULL,
    subsidiary text,
    location text,
    department text,
    account text NOT NULL,
    debit double precision DEFAULT 0.0,
    credit double precision DEFAULT 0.0,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid NOT NULL,
    is_test boolean DEFAULT false NOT NULL
);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_entries_id_seq OWNED BY public.journal_entries.id;


--
-- Name: mx_payroll_column_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mx_payroll_column_map (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    column_header text NOT NULL,
    account_code text NOT NULL,
    is_negated boolean DEFAULT false NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: mx_payroll_column_map_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mx_payroll_column_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mx_payroll_column_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mx_payroll_column_map_id_seq OWNED BY public.mx_payroll_column_map.id;


--
-- Name: org_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    invited_by uuid,
    joined_at timestamp with time zone DEFAULT now(),
    role_id uuid,
    CONSTRAINT org_members_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'user'::text])))
);


--
-- Name: org_modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_modules (
    org_id uuid NOT NULL,
    module text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: payroll_column_account_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_column_account_map (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    column_header text NOT NULL,
    account_code text NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: payroll_column_account_map_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_column_account_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_column_account_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_column_account_map_id_seq OWNED BY public.payroll_column_account_map.id;


--
-- Name: payroll_employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_employees (
    id integer NOT NULL,
    batch_id integer NOT NULL,
    employee_code text,
    employee_name text,
    department text,
    department_netsuite text,
    payroll_date text,
    period text,
    wages_71215 double precision DEFAULT 0,
    pto_71218 double precision DEFAULT 0,
    xmas_72033 double precision DEFAULT 0,
    food_72032 double precision DEFAULT 0,
    peo1_72065 double precision DEFAULT 0,
    taxes_72012 double precision DEFAULT 0,
    peo2_72065 double precision DEFAULT 0,
    indem double precision DEFAULT 0,
    total_mxn double precision DEFAULT 0,
    total_usd double precision DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid NOT NULL
);


--
-- Name: payroll_employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_employees_id_seq OWNED BY public.payroll_employees.id;


--
-- Name: pnl_account_drivers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pnl_account_drivers (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    system text DEFAULT 'quickbooks'::text NOT NULL,
    code text NOT NULL,
    name text,
    node_id text,
    driver_id text,
    formula text DEFAULT 'qb_amount'::text NOT NULL,
    vars jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_rate boolean DEFAULT false NOT NULL,
    source_rule text,
    created_at timestamp with time zone DEFAULT now(),
    created_by text,
    scope text DEFAULT 'location'::text NOT NULL,
    mso_pool_name text,
    if_use_service text,
    CONSTRAINT pnl_account_drivers_scope_chk CHECK ((scope = ANY (ARRAY['location'::text, 'region'::text, 'company'::text])))
);


--
-- Name: pnl_account_drivers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pnl_account_drivers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pnl_account_drivers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pnl_account_drivers_id_seq OWNED BY public.pnl_account_drivers.id;


--
-- Name: pnl_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pnl_configs (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    config_jsonb jsonb NOT NULL,
    content_hash text NOT NULL,
    superseded_by bigint,
    created_at timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: pnl_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pnl_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pnl_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pnl_configs_id_seq OWNED BY public.pnl_configs.id;


--
-- Name: pnl_cost_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pnl_cost_batches (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    fiscal_year integer NOT NULL,
    period integer NOT NULL,
    file_hash text NOT NULL,
    source_filename text,
    row_count integer,
    status text DEFAULT 'completed'::text NOT NULL,
    superseded_by bigint,
    created_at timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: pnl_cost_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pnl_cost_batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pnl_cost_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pnl_cost_batches_id_seq OWNED BY public.pnl_cost_batches.id;


--
-- Name: pnl_cost_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pnl_cost_lines (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    batch_id bigint NOT NULL,
    fiscal_year integer,
    period integer,
    location text,
    clinic text,
    dep_id text,
    department text,
    account text,
    book_account text,
    type text,
    amount_cents bigint NOT NULL,
    pl_group text,
    reclassification text,
    ga_breakdown text,
    ga_key text,
    provider_code text,
    created_at timestamp with time zone DEFAULT now(),
    created_by text,
    gross_amount_cents bigint
);


--
-- Name: pnl_cost_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pnl_cost_lines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pnl_cost_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pnl_cost_lines_id_seq OWNED BY public.pnl_cost_lines.id;


--
-- Name: pnl_driver_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pnl_driver_batches (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    fiscal_year integer NOT NULL,
    period integer NOT NULL,
    file_hash text NOT NULL,
    source_filename text,
    row_count integer,
    status text DEFAULT 'completed'::text NOT NULL,
    superseded_by bigint,
    created_at timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: pnl_driver_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pnl_driver_batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pnl_driver_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pnl_driver_batches_id_seq OWNED BY public.pnl_driver_batches.id;


--
-- Name: pnl_driver_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pnl_driver_values (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    batch_id bigint NOT NULL,
    driver_id text NOT NULL,
    period_id text NOT NULL,
    provider_code text NOT NULL,
    clinic text NOT NULL,
    value numeric NOT NULL,
    apply_flags jsonb,
    created_at timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: pnl_driver_values_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pnl_driver_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pnl_driver_values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pnl_driver_values_id_seq OWNED BY public.pnl_driver_values.id;


--
-- Name: process_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_runs (
    run_id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    process text NOT NULL,
    state text NOT NULL,
    step text,
    batch_id integer,
    fiscal_year integer,
    period integer,
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    inputs jsonb DEFAULT '{}'::jsonb NOT NULL,
    run_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    progress jsonb DEFAULT '{}'::jsonb NOT NULL,
    error jsonb,
    idempotency_key text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    superseded_by_run_id uuid,
    is_test boolean DEFAULT false NOT NULL,
    CONSTRAINT process_runs_process_check CHECK ((process = ANY (ARRAY['qb-revenue'::text, 'mx-payroll'::text, 'qb-usa-payroll'::text]))),
    CONSTRAINT process_runs_state_check CHECK ((state = ANY (ARRAY['draft'::text, 'parsing'::text, 'needs_input'::text, 'ready'::text, 'running'::text, 'blocked'::text, 'completed'::text, 'failed'::text, 'expired'::text, 'superseded'::text])))
);


--
-- Name: processed_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.processed_entries (
    id integer NOT NULL,
    run_id integer NOT NULL,
    entry_type text,
    location text,
    clinic_group text,
    department text,
    payer_type text,
    account_code text,
    debit double precision DEFAULT 0.0,
    credit double precision DEFAULT 0.0,
    memo text,
    je_date text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid NOT NULL
);


--
-- Name: processed_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.processed_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processed_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.processed_entries_id_seq OWNED BY public.processed_entries.id;


--
-- Name: processing_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.processing_runs (
    id integer NOT NULL,
    upload_id integer NOT NULL,
    config_version text,
    status text DEFAULT 'running'::text,
    entry_count integer DEFAULT 0,
    total_debits double precision DEFAULT 0.0,
    total_credits double precision DEFAULT 0.0,
    output_folder text,
    error_message text,
    started_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone,
    run_by text,
    supersedes_run_id integer,
    org_id uuid NOT NULL,
    is_test boolean DEFAULT false NOT NULL,
    CONSTRAINT processing_runs_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'complete'::text, 'error'::text, 'running'::text])))
);


--
-- Name: processing_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.processing_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processing_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.processing_runs_id_seq OWNED BY public.processing_runs.id;


--
-- Name: qb_account_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_account_map (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    domain text NOT NULL,
    ns_account text NOT NULL,
    qb_account text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_standard boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: qb_account_map_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_account_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_account_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_account_map_id_seq OWNED BY public.qb_account_map.id;


--
-- Name: qb_clinic_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_clinic_map (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    location_name text NOT NULL,
    service_line text DEFAULT ''::text NOT NULL,
    qb_clinic text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: qb_clinic_map_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_clinic_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_clinic_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_clinic_map_id_seq OWNED BY public.qb_clinic_map.id;


--
-- Name: qb_department_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_department_map (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    ns_department text NOT NULL,
    qb_class text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: qb_department_map_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_department_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_department_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_department_map_id_seq OWNED BY public.qb_department_map.id;


--
-- Name: qb_export_tie_out; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_export_tie_out (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    batch_id integer NOT NULL,
    process text NOT NULL,
    file_name text NOT NULL,
    kind text NOT NULL,
    journal_no text DEFAULT ''::text NOT NULL,
    line_count integer DEFAULT 0 NOT NULL,
    credits numeric(15,2) DEFAULT 0 NOT NULL,
    debits numeric(15,2) DEFAULT 0 NOT NULL,
    balanced boolean GENERATED ALWAYS AS ((round((credits - debits), 2) = (0)::numeric)) STORED,
    unmapped_count integer DEFAULT 0 NOT NULL,
    storage_path text,
    created_at timestamp with time zone DEFAULT now(),
    is_test boolean DEFAULT false NOT NULL,
    qbo_je_id text,
    qbo_sync_token text,
    qbo_posted_at timestamp with time zone,
    CONSTRAINT qb_export_tie_out_process_check CHECK ((process = ANY (ARRAY['qb-revenue'::text, 'mx-payroll'::text])))
);


--
-- Name: qb_export_tie_out_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_export_tie_out_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_export_tie_out_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_export_tie_out_id_seq OWNED BY public.qb_export_tie_out.id;


--
-- Name: qb_location_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_location_map (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    ns_location text NOT NULL,
    qb_location text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: qb_location_map_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_location_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_location_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_location_map_id_seq OWNED BY public.qb_location_map.id;


--
-- Name: qb_other_code_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_other_code_map (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    service_line text NOT NULL,
    other_code text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: qb_other_code_map_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_other_code_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_other_code_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_other_code_map_id_seq OWNED BY public.qb_other_code_map.id;


--
-- Name: qb_payer_label_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_payer_label_map (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    payer_type text NOT NULL,
    label text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: qb_payer_label_map_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_payer_label_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_payer_label_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_payer_label_map_id_seq OWNED BY public.qb_payer_label_map.id;


--
-- Name: qb_provider_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_provider_map (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    provider_name text NOT NULL,
    provider_code text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text,
    start_date date,
    end_date date
);


--
-- Name: qb_provider_map_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_provider_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_provider_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_provider_map_id_seq OWNED BY public.qb_provider_map.id;


--
-- Name: qb_usa_coding_exception; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_usa_coding_exception (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    adp_dept_code text NOT NULL,
    adp_cost_code text,
    qb_location text,
    qb_department text,
    note text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text,
    CONSTRAINT qb_usa_coding_exception_overrides_something CHECK (((qb_location IS NOT NULL) OR (qb_department IS NOT NULL)))
);


--
-- Name: qb_usa_coding_exception_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_usa_coding_exception_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_usa_coding_exception_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_usa_coding_exception_id_seq OWNED BY public.qb_usa_coding_exception.id;


--
-- Name: qb_usa_department_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_usa_department_rule (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    adp_cost_code text NOT NULL,
    qb_department text NOT NULL,
    note text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: qb_usa_department_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_usa_department_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_usa_department_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_usa_department_rule_id_seq OWNED BY public.qb_usa_department_rule.id;


--
-- Name: qb_usa_employee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_usa_employee (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    employee_key text NOT NULL,
    name text NOT NULL,
    entity text NOT NULL,
    variant text NOT NULL,
    qb_class text DEFAULT ''::text NOT NULL,
    qb_location text,
    qb_department text,
    note text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text,
    CONSTRAINT qb_usa_employee_entity_check CHECK ((entity = ANY (ARRAY['HW3'::text, 'DJ8'::text]))),
    CONSTRAINT qb_usa_employee_variant_check CHECK ((variant = ANY (ARRAY['smh_salaried'::text, 'smllc_salaried'::text, 'smllc_hourly'::text])))
);


--
-- Name: qb_usa_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_usa_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_usa_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_usa_employee_id_seq OWNED BY public.qb_usa_employee.id;


--
-- Name: qb_usa_location_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_usa_location_rule (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    adp_dept_code text NOT NULL,
    qb_location text NOT NULL,
    note text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text
);


--
-- Name: qb_usa_location_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_usa_location_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_usa_location_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_usa_location_rule_id_seq OWNED BY public.qb_usa_location_rule.id;


--
-- Name: qb_usa_payroll_gate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_usa_payroll_gate (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    batch_id integer NOT NULL,
    gate_name text NOT NULL,
    passed boolean NOT NULL,
    expected numeric(15,2) DEFAULT 0 NOT NULL,
    actual numeric(15,2) DEFAULT 0 NOT NULL,
    variance numeric(15,2) GENERATED ALWAYS AS (round((actual - expected), 2)) STORED,
    offender_count integer DEFAULT 0 NOT NULL,
    offenders jsonb,
    declared boolean DEFAULT false NOT NULL,
    declared_by text,
    declared_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT qb_usa_payroll_gate_declared_needs_who_when CHECK (((NOT declared) OR ((declared_by IS NOT NULL) AND (declared_at IS NOT NULL)))),
    CONSTRAINT qb_usa_payroll_gate_only_failed_declared CHECK (((NOT declared) OR (NOT passed)))
);


--
-- Name: qb_usa_payroll_gate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_usa_payroll_gate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_usa_payroll_gate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_usa_payroll_gate_id_seq OWNED BY public.qb_usa_payroll_gate.id;


--
-- Name: qb_usa_payroll_journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qb_usa_payroll_journal (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    batch_id integer NOT NULL,
    journal_no text NOT NULL,
    je_date date NOT NULL,
    variant text NOT NULL,
    kind text DEFAULT 'main'::text NOT NULL,
    line_count integer DEFAULT 0 NOT NULL,
    total numeric(15,2) DEFAULT 0 NOT NULL,
    storage_path text,
    created_at timestamp with time zone DEFAULT now(),
    is_test boolean DEFAULT false NOT NULL,
    CONSTRAINT qb_usa_payroll_journal_kind_check CHECK ((kind = ANY (ARRAY['main'::text, 'accrual'::text]))),
    CONSTRAINT qb_usa_payroll_journal_variant_check CHECK ((variant = ANY (ARRAY['smh_salaried'::text, 'smllc_salaried'::text, 'smllc_hourly'::text])))
);


--
-- Name: qb_usa_payroll_journal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qb_usa_payroll_journal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qb_usa_payroll_journal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qb_usa_payroll_journal_id_seq OWNED BY public.qb_usa_payroll_journal.id;


--
-- Name: qbo_connection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qbo_connection (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    realm_id text NOT NULL,
    environment text DEFAULT 'sandbox'::text NOT NULL,
    access_token text NOT NULL,
    refresh_token text NOT NULL,
    access_expires_at timestamp with time zone NOT NULL,
    refresh_expires_at timestamp with time zone,
    connected_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT qbo_connection_environment_check CHECK ((environment = ANY (ARRAY['sandbox'::text, 'production'::text])))
);


--
-- Name: qbo_connection_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qbo_connection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qbo_connection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qbo_connection_id_seq OWNED BY public.qbo_connection.id;


--
-- Name: qgenda_workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qgenda_workspaces (
    id text NOT NULL,
    data jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid NOT NULL,
    process text NOT NULL,
    can_access boolean DEFAULT false NOT NULL,
    can_view_results boolean DEFAULT false NOT NULL,
    CONSTRAINT role_permissions_process_check CHECK ((process = ANY (ARRAY['revenue'::text, 'payroll'::text, 'qb_usa_payroll'::text, 'adp_payroll'::text, 'config'::text, 'invoice'::text, 'booking_payroll'::text, 'pnl_provider'::text, 'code_grader'::text, 'mso_payroll'::text, 'wearbly'::text])))
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: source_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_transactions (
    id integer NOT NULL,
    upload_id integer NOT NULL,
    row_number integer NOT NULL,
    raw_data text,
    transaction_date text,
    amount double precision DEFAULT 0.0,
    provider text,
    location text,
    payer text,
    department text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid NOT NULL
);


--
-- Name: source_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.source_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: source_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.source_transactions_id_seq OWNED BY public.source_transactions.id;


--
-- Name: superadmins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.superadmins (
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    batch_id integer NOT NULL,
    row_number integer NOT NULL,
    transaction_date text,
    patient_id text,
    payer_original text,
    payer_type text,
    facility_original text,
    location_code text,
    provider_original text,
    department text,
    clinic_group text,
    account_code text,
    amount double precision,
    service_date text,
    payment_date text,
    claim_no text,
    encounter_id text,
    record_type text DEFAULT 'clinic'::text,
    mapping_status text DEFAULT 'pending'::text,
    mapping_errors text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    location_name text,
    billing_provider text,
    org_id uuid NOT NULL,
    is_test boolean DEFAULT false NOT NULL
);


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: trial_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trial_migrations (
    name text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ts_benefit_override; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ts_benefit_override (
    id integer NOT NULL,
    org_id uuid NOT NULL,
    kind text DEFAULT 'benefit'::text NOT NULL,
    period integer,
    year integer,
    run integer,
    entity text,
    name text,
    amount numeric(12,2),
    employee_id text,
    variant text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    updated_by text,
    qb_location text,
    qb_department text,
    qb_class text,
    CONSTRAINT ts_benefit_override_kind_check CHECK ((kind = ANY (ARRAY['benefit'::text, 'redistribution'::text, 'variant'::text, 'fixed_pool'::text]))),
    CONSTRAINT ts_benefit_override_shape CHECK ((((kind = 'benefit'::text) AND (period IS NOT NULL) AND (year IS NOT NULL) AND (run IS NOT NULL) AND (entity IS NOT NULL) AND (name IS NOT NULL) AND (amount IS NOT NULL) AND (employee_id IS NULL) AND (variant IS NULL) AND (qb_location IS NULL) AND (qb_department IS NULL) AND (qb_class IS NULL)) OR ((kind = 'redistribution'::text) AND (period IS NOT NULL) AND (year IS NOT NULL) AND (run IS NOT NULL) AND (entity IS NOT NULL) AND (name IS NOT NULL) AND (amount IS NULL) AND (employee_id IS NULL) AND (variant IS NULL) AND (qb_location IS NULL) AND (qb_department IS NULL) AND (qb_class IS NULL)) OR ((kind = 'variant'::text) AND (period IS NULL) AND (year IS NULL) AND (employee_id IS NOT NULL) AND (variant IS NOT NULL) AND (run IS NULL) AND (entity IS NULL) AND (name IS NULL) AND (amount IS NULL) AND (qb_location IS NULL) AND (qb_department IS NULL) AND (qb_class IS NULL)) OR ((kind = 'fixed_pool'::text) AND (entity IS NOT NULL) AND (qb_location IS NOT NULL) AND (qb_department IS NOT NULL) AND (variant IS NOT NULL) AND (period IS NULL) AND (year IS NULL) AND (run IS NULL) AND (name IS NULL) AND (amount IS NULL) AND (employee_id IS NULL)))),
    CONSTRAINT ts_benefit_override_variant_check CHECK (((variant IS NULL) OR (variant = ANY (ARRAY['smh_salaried'::text, 'smllc_salaried'::text, 'smllc_hourly'::text]))))
);


--
-- Name: ts_benefit_override_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ts_benefit_override_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ts_benefit_override_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ts_benefit_override_id_seq OWNED BY public.ts_benefit_override.id;


--
-- Name: uniform_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uniform_catalog (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    item_type text NOT NULL,
    size text NOT NULL,
    gender text,
    brand text NOT NULL,
    cut text DEFAULT 'Regular'::text NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    sku text,
    vendor text,
    embroidery_logo_cost numeric(10,2) DEFAULT 0,
    embroidery_name_cost numeric(10,2) DEFAULT 0,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: uniform_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uniform_catalog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uniform_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uniform_catalog_id_seq OWNED BY public.uniform_catalog.id;


--
-- Name: uniform_column_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uniform_column_mappings (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    source_header text NOT NULL,
    canonical_field text NOT NULL,
    confidence numeric(5,2),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: uniform_column_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uniform_column_mappings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uniform_column_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uniform_column_mappings_id_seq OWNED BY public.uniform_column_mappings.id;


--
-- Name: uniform_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uniform_order_items (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    org_id uuid NOT NULL,
    employee_name text,
    item_type text NOT NULL,
    brand text,
    original_size text,
    normalized_size text,
    gender text,
    cut text,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2),
    line_total numeric(12,2),
    sku text,
    vendor text,
    logo_embroidery boolean DEFAULT false,
    name_embroidery boolean DEFAULT false,
    embroidery_cost numeric(10,2) DEFAULT 0,
    lookup_status text
);


--
-- Name: uniform_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uniform_order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uniform_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uniform_order_items_id_seq OWNED BY public.uniform_order_items.id;


--
-- Name: uniform_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uniform_orders (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    created_by text,
    client_name text,
    status text DEFAULT 'processing'::text NOT NULL,
    subtotal numeric(12,2) DEFAULT 0,
    embroidery_total numeric(12,2) DEFAULT 0,
    grand_total numeric(12,2) DEFAULT 0,
    logo_embroidery_flag boolean DEFAULT false,
    name_embroidery_flag boolean DEFAULT false,
    options_json jsonb,
    pdf_storage_path text,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT uniform_orders_status_check CHECK ((status = ANY (ARRAY['processing'::text, 'complete'::text, 'failed'::text])))
);


--
-- Name: uniform_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uniform_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uniform_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uniform_orders_id_seq OWNED BY public.uniform_orders.id;


--
-- Name: uniform_size_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uniform_size_mappings (
    id bigint NOT NULL,
    org_id uuid NOT NULL,
    input_pattern text NOT NULL,
    normalized_size text NOT NULL,
    item_type text
);


--
-- Name: uniform_size_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uniform_size_mappings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uniform_size_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uniform_size_mappings_id_seq OWNED BY public.uniform_size_mappings.id;


--
-- Name: unmapped_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unmapped_items (
    id integer NOT NULL,
    batch_id integer NOT NULL,
    item_type text NOT NULL,
    original_value text NOT NULL,
    occurrence_count integer DEFAULT 1,
    total_amount double precision DEFAULT 0.0,
    resolved integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid NOT NULL
);


--
-- Name: unmapped_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.unmapped_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: unmapped_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.unmapped_items_id_seq OWNED BY public.unmapped_items.id;


--
-- Name: uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uploads (
    id integer NOT NULL,
    file_name text NOT NULL,
    processor_type text NOT NULL,
    file_hash text,
    file_size integer,
    record_count integer DEFAULT 0,
    total_amount double precision DEFAULT 0.0,
    period text,
    fiscal_year text,
    status text DEFAULT 'pending'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    org_id uuid,
    is_test boolean DEFAULT false NOT NULL,
    CONSTRAINT uploads_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'processed'::text, 'error'::text])))
);


--
-- Name: uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uploads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uploads_id_seq OWNED BY public.uploads.id;


--
-- Name: artifact_downloads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_downloads ALTER COLUMN id SET DEFAULT nextval('public.artifact_downloads_id_seq'::regclass);


--
-- Name: config_account_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_account_codes ALTER COLUMN id SET DEFAULT nextval('public.config_account_codes_id_seq'::regclass);


--
-- Name: config_clinic_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_clinic_groups ALTER COLUMN id SET DEFAULT nextval('public.config_clinic_groups_id_seq'::regclass);


--
-- Name: config_departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_departments ALTER COLUMN id SET DEFAULT nextval('public.config_departments_id_seq'::regclass);


--
-- Name: config_employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_employees ALTER COLUMN id SET DEFAULT nextval('public.config_employees_id_seq'::regclass);


--
-- Name: config_fiscal_calendar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_fiscal_calendar ALTER COLUMN id SET DEFAULT nextval('public.config_fiscal_calendar_id_seq'::regclass);


--
-- Name: config_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_history ALTER COLUMN id SET DEFAULT nextval('public.config_history_id_seq'::regclass);


--
-- Name: config_locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_locations ALTER COLUMN id SET DEFAULT nextval('public.config_locations_id_seq'::regclass);


--
-- Name: config_mso_mappings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_mso_mappings ALTER COLUMN id SET DEFAULT nextval('public.config_mso_mappings_id_seq'::regclass);


--
-- Name: config_mx_employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_mx_employees ALTER COLUMN id SET DEFAULT nextval('public.config_mx_employees_id_seq'::regclass);


--
-- Name: config_payers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_payers ALTER COLUMN id SET DEFAULT nextval('public.config_payers_id_seq'::regclass);


--
-- Name: config_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_providers ALTER COLUMN id SET DEFAULT nextval('public.config_providers_id_seq'::regclass);


--
-- Name: config_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_settings ALTER COLUMN id SET DEFAULT nextval('public.config_settings_id_seq'::regclass);


--
-- Name: employee_clinic_allocations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_clinic_allocations ALTER COLUMN id SET DEFAULT nextval('public.employee_clinic_allocations_id_seq'::regclass);


--
-- Name: fiscal_calendar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_calendar ALTER COLUMN id SET DEFAULT nextval('public.fiscal_calendar_id_seq'::regclass);


--
-- Name: import_batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches ALTER COLUMN id SET DEFAULT nextval('public.import_batches_id_seq'::regclass);


--
-- Name: journal_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries ALTER COLUMN id SET DEFAULT nextval('public.journal_entries_id_seq'::regclass);


--
-- Name: mx_payroll_column_map id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mx_payroll_column_map ALTER COLUMN id SET DEFAULT nextval('public.mx_payroll_column_map_id_seq'::regclass);


--
-- Name: payroll_column_account_map id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_column_account_map ALTER COLUMN id SET DEFAULT nextval('public.payroll_column_account_map_id_seq'::regclass);


--
-- Name: payroll_employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_employees ALTER COLUMN id SET DEFAULT nextval('public.payroll_employees_id_seq'::regclass);


--
-- Name: pnl_account_drivers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_account_drivers ALTER COLUMN id SET DEFAULT nextval('public.pnl_account_drivers_id_seq'::regclass);


--
-- Name: pnl_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_configs ALTER COLUMN id SET DEFAULT nextval('public.pnl_configs_id_seq'::regclass);


--
-- Name: pnl_cost_batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_cost_batches ALTER COLUMN id SET DEFAULT nextval('public.pnl_cost_batches_id_seq'::regclass);


--
-- Name: pnl_cost_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_cost_lines ALTER COLUMN id SET DEFAULT nextval('public.pnl_cost_lines_id_seq'::regclass);


--
-- Name: pnl_driver_batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_driver_batches ALTER COLUMN id SET DEFAULT nextval('public.pnl_driver_batches_id_seq'::regclass);


--
-- Name: pnl_driver_values id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_driver_values ALTER COLUMN id SET DEFAULT nextval('public.pnl_driver_values_id_seq'::regclass);


--
-- Name: processed_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_entries ALTER COLUMN id SET DEFAULT nextval('public.processed_entries_id_seq'::regclass);


--
-- Name: processing_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processing_runs ALTER COLUMN id SET DEFAULT nextval('public.processing_runs_id_seq'::regclass);


--
-- Name: qb_account_map id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_account_map ALTER COLUMN id SET DEFAULT nextval('public.qb_account_map_id_seq'::regclass);


--
-- Name: qb_clinic_map id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_clinic_map ALTER COLUMN id SET DEFAULT nextval('public.qb_clinic_map_id_seq'::regclass);


--
-- Name: qb_department_map id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_department_map ALTER COLUMN id SET DEFAULT nextval('public.qb_department_map_id_seq'::regclass);


--
-- Name: qb_export_tie_out id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_export_tie_out ALTER COLUMN id SET DEFAULT nextval('public.qb_export_tie_out_id_seq'::regclass);


--
-- Name: qb_location_map id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_location_map ALTER COLUMN id SET DEFAULT nextval('public.qb_location_map_id_seq'::regclass);


--
-- Name: qb_other_code_map id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_other_code_map ALTER COLUMN id SET DEFAULT nextval('public.qb_other_code_map_id_seq'::regclass);


--
-- Name: qb_payer_label_map id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_payer_label_map ALTER COLUMN id SET DEFAULT nextval('public.qb_payer_label_map_id_seq'::regclass);


--
-- Name: qb_provider_map id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_provider_map ALTER COLUMN id SET DEFAULT nextval('public.qb_provider_map_id_seq'::regclass);


--
-- Name: qb_usa_coding_exception id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_coding_exception ALTER COLUMN id SET DEFAULT nextval('public.qb_usa_coding_exception_id_seq'::regclass);


--
-- Name: qb_usa_department_rule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_department_rule ALTER COLUMN id SET DEFAULT nextval('public.qb_usa_department_rule_id_seq'::regclass);


--
-- Name: qb_usa_employee id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_employee ALTER COLUMN id SET DEFAULT nextval('public.qb_usa_employee_id_seq'::regclass);


--
-- Name: qb_usa_location_rule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_location_rule ALTER COLUMN id SET DEFAULT nextval('public.qb_usa_location_rule_id_seq'::regclass);


--
-- Name: qb_usa_payroll_gate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_payroll_gate ALTER COLUMN id SET DEFAULT nextval('public.qb_usa_payroll_gate_id_seq'::regclass);


--
-- Name: qb_usa_payroll_journal id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_payroll_journal ALTER COLUMN id SET DEFAULT nextval('public.qb_usa_payroll_journal_id_seq'::regclass);


--
-- Name: qbo_connection id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_connection ALTER COLUMN id SET DEFAULT nextval('public.qbo_connection_id_seq'::regclass);


--
-- Name: source_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_transactions ALTER COLUMN id SET DEFAULT nextval('public.source_transactions_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: ts_benefit_override id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ts_benefit_override ALTER COLUMN id SET DEFAULT nextval('public.ts_benefit_override_id_seq'::regclass);


--
-- Name: uniform_catalog id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_catalog ALTER COLUMN id SET DEFAULT nextval('public.uniform_catalog_id_seq'::regclass);


--
-- Name: uniform_column_mappings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_column_mappings ALTER COLUMN id SET DEFAULT nextval('public.uniform_column_mappings_id_seq'::regclass);


--
-- Name: uniform_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_order_items ALTER COLUMN id SET DEFAULT nextval('public.uniform_order_items_id_seq'::regclass);


--
-- Name: uniform_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_orders ALTER COLUMN id SET DEFAULT nextval('public.uniform_orders_id_seq'::regclass);


--
-- Name: uniform_size_mappings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_size_mappings ALTER COLUMN id SET DEFAULT nextval('public.uniform_size_mappings_id_seq'::regclass);


--
-- Name: unmapped_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unmapped_items ALTER COLUMN id SET DEFAULT nextval('public.unmapped_items_id_seq'::regclass);


--
-- Name: uploads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads ALTER COLUMN id SET DEFAULT nextval('public.uploads_id_seq'::regclass);


--
-- Name: artifact_downloads artifact_downloads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_downloads
    ADD CONSTRAINT artifact_downloads_pkey PRIMARY KEY (id);


--
-- Name: bkv5_location_remap bkv5_location_remap_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bkv5_location_remap
    ADD CONSTRAINT bkv5_location_remap_pkey PRIMARY KEY (org_id, location_code, entity);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: config_account_codes config_account_codes_org_id_payer_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_account_codes
    ADD CONSTRAINT config_account_codes_org_id_payer_type_key UNIQUE (org_id, payer_type);


--
-- Name: config_account_codes config_account_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_account_codes
    ADD CONSTRAINT config_account_codes_pkey PRIMARY KEY (id);


--
-- Name: config_clinic_groups config_clinic_groups_org_id_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_clinic_groups
    ADD CONSTRAINT config_clinic_groups_org_id_group_name_key UNIQUE (org_id, group_name);


--
-- Name: config_clinic_groups config_clinic_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_clinic_groups
    ADD CONSTRAINT config_clinic_groups_pkey PRIMARY KEY (id);


--
-- Name: config_departments config_departments_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_departments
    ADD CONSTRAINT config_departments_org_id_name_key UNIQUE (org_id, name);


--
-- Name: config_departments config_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_departments
    ADD CONSTRAINT config_departments_pkey PRIMARY KEY (id);


--
-- Name: config_employees config_employees_org_id_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_employees
    ADD CONSTRAINT config_employees_org_id_employee_id_key UNIQUE (org_id, employee_id);


--
-- Name: config_employees config_employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_employees
    ADD CONSTRAINT config_employees_pkey PRIMARY KEY (id);


--
-- Name: config_fiscal_calendar config_fiscal_calendar_org_id_period_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_fiscal_calendar
    ADD CONSTRAINT config_fiscal_calendar_org_id_period_key_key UNIQUE (org_id, period_key);


--
-- Name: config_fiscal_calendar config_fiscal_calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_fiscal_calendar
    ADD CONSTRAINT config_fiscal_calendar_pkey PRIMARY KEY (id);


--
-- Name: config_history config_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_history
    ADD CONSTRAINT config_history_pkey PRIMARY KEY (id);


--
-- Name: config_locations config_locations_org_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_locations
    ADD CONSTRAINT config_locations_org_id_code_key UNIQUE (org_id, code);


--
-- Name: config_locations config_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_locations
    ADD CONSTRAINT config_locations_pkey PRIMARY KEY (id);


--
-- Name: config_mso_mappings config_mso_mappings_org_id_mapping_type_source_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_mso_mappings
    ADD CONSTRAINT config_mso_mappings_org_id_mapping_type_source_key_key UNIQUE (org_id, mapping_type, source_key);


--
-- Name: config_mso_mappings config_mso_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_mso_mappings
    ADD CONSTRAINT config_mso_mappings_pkey PRIMARY KEY (id);


--
-- Name: config_mx_employees config_mx_employees_org_id_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_mx_employees
    ADD CONSTRAINT config_mx_employees_org_id_employee_id_key UNIQUE (org_id, employee_id);


--
-- Name: config_mx_employees config_mx_employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_mx_employees
    ADD CONSTRAINT config_mx_employees_pkey PRIMARY KEY (id);


--
-- Name: config_payers config_payers_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_payers
    ADD CONSTRAINT config_payers_org_id_name_key UNIQUE (org_id, name);


--
-- Name: config_payers config_payers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_payers
    ADD CONSTRAINT config_payers_pkey PRIMARY KEY (id);


--
-- Name: config_providers config_providers_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_providers
    ADD CONSTRAINT config_providers_org_id_name_key UNIQUE (org_id, name);


--
-- Name: config_providers config_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_providers
    ADD CONSTRAINT config_providers_pkey PRIMARY KEY (id);


--
-- Name: config_settings config_settings_org_id_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_settings
    ADD CONSTRAINT config_settings_org_id_setting_key_key UNIQUE (org_id, setting_key);


--
-- Name: config_settings config_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_settings
    ADD CONSTRAINT config_settings_pkey PRIMARY KEY (id);


--
-- Name: employee_clinic_allocations employee_clinic_allocations_employee_normalized_location_co_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_clinic_allocations
    ADD CONSTRAINT employee_clinic_allocations_employee_normalized_location_co_key UNIQUE (employee_normalized, location_code);


--
-- Name: employee_clinic_allocations employee_clinic_allocations_org_id_employee_normalized_location; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_clinic_allocations
    ADD CONSTRAINT employee_clinic_allocations_org_id_employee_normalized_location UNIQUE (org_id, employee_normalized, location_code);


--
-- Name: employee_clinic_allocations employee_clinic_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_clinic_allocations
    ADD CONSTRAINT employee_clinic_allocations_pkey PRIMARY KEY (id);


--
-- Name: fiscal_calendar fiscal_calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_calendar
    ADD CONSTRAINT fiscal_calendar_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: invite_codes invite_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_code_key UNIQUE (code);


--
-- Name: invite_codes invite_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: mx_payroll_column_map mx_payroll_column_map_org_id_column_header_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mx_payroll_column_map
    ADD CONSTRAINT mx_payroll_column_map_org_id_column_header_key UNIQUE (org_id, column_header);


--
-- Name: mx_payroll_column_map mx_payroll_column_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mx_payroll_column_map
    ADD CONSTRAINT mx_payroll_column_map_pkey PRIMARY KEY (id);


--
-- Name: org_members org_members_org_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_user_id_key UNIQUE (org_id, user_id);


--
-- Name: org_members org_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_pkey PRIMARY KEY (id);


--
-- Name: org_modules org_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_modules
    ADD CONSTRAINT org_modules_pkey PRIMARY KEY (org_id, module);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_slug_key UNIQUE (slug);


--
-- Name: payroll_column_account_map payroll_column_account_map_org_id_column_header_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_column_account_map
    ADD CONSTRAINT payroll_column_account_map_org_id_column_header_key UNIQUE (org_id, column_header);


--
-- Name: payroll_column_account_map payroll_column_account_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_column_account_map
    ADD CONSTRAINT payroll_column_account_map_pkey PRIMARY KEY (id);


--
-- Name: payroll_employees payroll_employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_employees
    ADD CONSTRAINT payroll_employees_pkey PRIMARY KEY (id);


--
-- Name: pnl_account_drivers pnl_account_drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_account_drivers
    ADD CONSTRAINT pnl_account_drivers_pkey PRIMARY KEY (id);


--
-- Name: pnl_configs pnl_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_configs
    ADD CONSTRAINT pnl_configs_pkey PRIMARY KEY (id);


--
-- Name: pnl_cost_batches pnl_cost_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_cost_batches
    ADD CONSTRAINT pnl_cost_batches_pkey PRIMARY KEY (id);


--
-- Name: pnl_cost_lines pnl_cost_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_cost_lines
    ADD CONSTRAINT pnl_cost_lines_pkey PRIMARY KEY (id);


--
-- Name: pnl_driver_batches pnl_driver_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_driver_batches
    ADD CONSTRAINT pnl_driver_batches_pkey PRIMARY KEY (id);


--
-- Name: pnl_driver_values pnl_driver_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_driver_values
    ADD CONSTRAINT pnl_driver_values_pkey PRIMARY KEY (id);


--
-- Name: process_runs process_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_runs
    ADD CONSTRAINT process_runs_pkey PRIMARY KEY (run_id);


--
-- Name: processed_entries processed_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_entries
    ADD CONSTRAINT processed_entries_pkey PRIMARY KEY (id);


--
-- Name: processing_runs processing_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processing_runs
    ADD CONSTRAINT processing_runs_pkey PRIMARY KEY (id);


--
-- Name: qb_account_map qb_account_map_org_id_domain_ns_account_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_account_map
    ADD CONSTRAINT qb_account_map_org_id_domain_ns_account_key UNIQUE (org_id, domain, ns_account);


--
-- Name: qb_account_map qb_account_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_account_map
    ADD CONSTRAINT qb_account_map_pkey PRIMARY KEY (id);


--
-- Name: qb_clinic_map qb_clinic_map_org_id_location_name_service_line_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_clinic_map
    ADD CONSTRAINT qb_clinic_map_org_id_location_name_service_line_key UNIQUE (org_id, location_name, service_line);


--
-- Name: qb_clinic_map qb_clinic_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_clinic_map
    ADD CONSTRAINT qb_clinic_map_pkey PRIMARY KEY (id);


--
-- Name: qb_department_map qb_department_map_org_id_ns_department_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_department_map
    ADD CONSTRAINT qb_department_map_org_id_ns_department_key UNIQUE (org_id, ns_department);


--
-- Name: qb_department_map qb_department_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_department_map
    ADD CONSTRAINT qb_department_map_pkey PRIMARY KEY (id);


--
-- Name: qb_export_tie_out qb_export_tie_out_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_export_tie_out
    ADD CONSTRAINT qb_export_tie_out_pkey PRIMARY KEY (id);


--
-- Name: qb_location_map qb_location_map_org_id_ns_location_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_location_map
    ADD CONSTRAINT qb_location_map_org_id_ns_location_key UNIQUE (org_id, ns_location);


--
-- Name: qb_location_map qb_location_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_location_map
    ADD CONSTRAINT qb_location_map_pkey PRIMARY KEY (id);


--
-- Name: qb_other_code_map qb_other_code_map_org_id_service_line_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_other_code_map
    ADD CONSTRAINT qb_other_code_map_org_id_service_line_key UNIQUE (org_id, service_line);


--
-- Name: qb_other_code_map qb_other_code_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_other_code_map
    ADD CONSTRAINT qb_other_code_map_pkey PRIMARY KEY (id);


--
-- Name: qb_payer_label_map qb_payer_label_map_org_id_payer_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_payer_label_map
    ADD CONSTRAINT qb_payer_label_map_org_id_payer_type_key UNIQUE (org_id, payer_type);


--
-- Name: qb_payer_label_map qb_payer_label_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_payer_label_map
    ADD CONSTRAINT qb_payer_label_map_pkey PRIMARY KEY (id);


--
-- Name: qb_provider_map qb_provider_map_org_id_provider_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_provider_map
    ADD CONSTRAINT qb_provider_map_org_id_provider_name_key UNIQUE (org_id, provider_name);


--
-- Name: qb_provider_map qb_provider_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_provider_map
    ADD CONSTRAINT qb_provider_map_pkey PRIMARY KEY (id);


--
-- Name: qb_usa_coding_exception qb_usa_coding_exception_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_coding_exception
    ADD CONSTRAINT qb_usa_coding_exception_pkey PRIMARY KEY (id);


--
-- Name: qb_usa_department_rule qb_usa_department_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_department_rule
    ADD CONSTRAINT qb_usa_department_rule_pkey PRIMARY KEY (id);


--
-- Name: qb_usa_employee qb_usa_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_employee
    ADD CONSTRAINT qb_usa_employee_pkey PRIMARY KEY (id);


--
-- Name: qb_usa_location_rule qb_usa_location_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_location_rule
    ADD CONSTRAINT qb_usa_location_rule_pkey PRIMARY KEY (id);


--
-- Name: qb_usa_payroll_gate qb_usa_payroll_gate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_payroll_gate
    ADD CONSTRAINT qb_usa_payroll_gate_pkey PRIMARY KEY (id);


--
-- Name: qb_usa_payroll_journal qb_usa_payroll_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_payroll_journal
    ADD CONSTRAINT qb_usa_payroll_journal_pkey PRIMARY KEY (id);


--
-- Name: qbo_connection qbo_connection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_connection
    ADD CONSTRAINT qbo_connection_pkey PRIMARY KEY (id);


--
-- Name: qgenda_workspaces qgenda_workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qgenda_workspaces
    ADD CONSTRAINT qgenda_workspaces_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_id_process_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_process_key UNIQUE (role_id, process);


--
-- Name: roles roles_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_org_id_name_key UNIQUE (org_id, name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: source_transactions source_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_transactions
    ADD CONSTRAINT source_transactions_pkey PRIMARY KEY (id);


--
-- Name: superadmins superadmins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.superadmins
    ADD CONSTRAINT superadmins_pkey PRIMARY KEY (user_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: trial_migrations trial_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trial_migrations
    ADD CONSTRAINT trial_migrations_pkey PRIMARY KEY (name);


--
-- Name: ts_benefit_override ts_benefit_override_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ts_benefit_override
    ADD CONSTRAINT ts_benefit_override_pkey PRIMARY KEY (id);


--
-- Name: uniform_catalog uniform_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_catalog
    ADD CONSTRAINT uniform_catalog_pkey PRIMARY KEY (id);


--
-- Name: uniform_column_mappings uniform_column_mappings_org_id_source_header_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_column_mappings
    ADD CONSTRAINT uniform_column_mappings_org_id_source_header_key UNIQUE (org_id, source_header);


--
-- Name: uniform_column_mappings uniform_column_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_column_mappings
    ADD CONSTRAINT uniform_column_mappings_pkey PRIMARY KEY (id);


--
-- Name: uniform_order_items uniform_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_order_items
    ADD CONSTRAINT uniform_order_items_pkey PRIMARY KEY (id);


--
-- Name: uniform_orders uniform_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_orders
    ADD CONSTRAINT uniform_orders_pkey PRIMARY KEY (id);


--
-- Name: uniform_size_mappings uniform_size_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_size_mappings
    ADD CONSTRAINT uniform_size_mappings_pkey PRIMARY KEY (id);


--
-- Name: unmapped_items unmapped_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unmapped_items
    ADD CONSTRAINT unmapped_items_pkey PRIMARY KEY (id);


--
-- Name: uploads uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_pkey PRIMARY KEY (id);


--
-- Name: idx_artifact_downloads_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_artifact_downloads_batch ON public.artifact_downloads USING btree (batch_id);


--
-- Name: idx_artifact_downloads_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_artifact_downloads_org ON public.artifact_downloads USING btree (org_id);


--
-- Name: idx_artifact_downloads_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_artifact_downloads_run ON public.artifact_downloads USING btree (run_id);


--
-- Name: idx_clients_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clients_org ON public.clients USING btree (org_id);


--
-- Name: idx_clients_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clients_org_id ON public.clients USING btree (org_id);


--
-- Name: idx_config_account_codes_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_account_codes_org ON public.config_account_codes USING btree (org_id);


--
-- Name: idx_config_clinic_groups_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_clinic_groups_org ON public.config_clinic_groups USING btree (org_id);


--
-- Name: idx_config_departments_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_departments_org ON public.config_departments USING btree (org_id);


--
-- Name: idx_config_employees_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_employees_id ON public.config_employees USING btree (org_id, employee_id);


--
-- Name: idx_config_employees_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_employees_org ON public.config_employees USING btree (org_id);


--
-- Name: idx_config_fiscal_calendar_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_fiscal_calendar_org ON public.config_fiscal_calendar USING btree (org_id);


--
-- Name: idx_config_history_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_history_org ON public.config_history USING btree (org_id);


--
-- Name: idx_config_history_table; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_history_table ON public.config_history USING btree (org_id, table_name, record_id);


--
-- Name: idx_config_locations_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_locations_code ON public.config_locations USING btree (org_id, code);


--
-- Name: idx_config_locations_facility_raw; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_config_locations_facility_raw ON public.config_locations USING btree (org_id, facility_raw);


--
-- Name: idx_config_locations_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_locations_org ON public.config_locations USING btree (org_id);


--
-- Name: idx_config_mso_mappings_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_mso_mappings_org ON public.config_mso_mappings USING btree (org_id);


--
-- Name: idx_config_mso_mappings_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_mso_mappings_type ON public.config_mso_mappings USING btree (org_id, mapping_type);


--
-- Name: idx_config_mx_employees_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_mx_employees_id ON public.config_mx_employees USING btree (org_id, employee_id);


--
-- Name: idx_config_mx_employees_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_mx_employees_org ON public.config_mx_employees USING btree (org_id);


--
-- Name: idx_config_payers_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_payers_name ON public.config_payers USING btree (org_id, name);


--
-- Name: idx_config_payers_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_payers_org ON public.config_payers USING btree (org_id);


--
-- Name: idx_config_providers_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_providers_name ON public.config_providers USING btree (org_id, name);


--
-- Name: idx_config_providers_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_providers_org ON public.config_providers USING btree (org_id);


--
-- Name: idx_config_settings_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_settings_org ON public.config_settings USING btree (org_id);


--
-- Name: idx_employee_allocations_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_allocations_entity ON public.employee_clinic_allocations USING btree (org_id, entity);


--
-- Name: idx_employee_allocations_file_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_allocations_file_number ON public.employee_clinic_allocations USING btree (org_id, file_number);


--
-- Name: idx_employee_allocations_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_allocations_name ON public.employee_clinic_allocations USING btree (org_id, employee_normalized);


--
-- Name: idx_employee_allocations_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_allocations_org ON public.employee_clinic_allocations USING btree (org_id);


--
-- Name: idx_employee_allocations_pay_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_allocations_pay_type ON public.employee_clinic_allocations USING btree (org_id, pay_type);


--
-- Name: idx_employee_clinic_allocations_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_clinic_allocations_org ON public.employee_clinic_allocations USING btree (org_id);


--
-- Name: idx_fiscal_calendar_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fiscal_calendar_date ON public.fiscal_calendar USING btree (date);


--
-- Name: idx_fiscal_calendar_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fiscal_calendar_org ON public.fiscal_calendar USING btree (org_id);


--
-- Name: idx_fiscal_calendar_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fiscal_calendar_period ON public.fiscal_calendar USING btree (org_id, fiscal_year, period);


--
-- Name: idx_import_batches_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_import_batches_current ON public.import_batches USING btree (org_id, batch_type, fiscal_year, period) WHERE ((superseded_by IS NULL) AND (NOT is_test));


--
-- Name: idx_import_batches_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_import_batches_org ON public.import_batches USING btree (org_id);


--
-- Name: idx_import_batches_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_import_batches_period ON public.import_batches USING btree (org_id, fiscal_year, period);


--
-- Name: idx_import_batches_qb_usa_payroll; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_import_batches_qb_usa_payroll ON public.import_batches USING btree (org_id, fiscal_year, period, created_at DESC) WHERE (batch_type = 'qb_usa_payroll'::text);


--
-- Name: idx_import_batches_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_import_batches_status ON public.import_batches USING btree (org_id, status);


--
-- Name: idx_invite_codes_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invite_codes_code ON public.invite_codes USING btree (code);


--
-- Name: idx_invite_codes_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invite_codes_org ON public.invite_codes USING btree (org_id);


--
-- Name: idx_invoices_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_client_id ON public.invoices USING btree (client_id);


--
-- Name: idx_invoices_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_created_at ON public.invoices USING btree (created_at DESC);


--
-- Name: idx_invoices_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_number ON public.invoices USING btree (org_id, invoice_number);


--
-- Name: idx_invoices_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_org ON public.invoices USING btree (org_id);


--
-- Name: idx_invoices_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_org_id ON public.invoices USING btree (org_id);


--
-- Name: idx_journal_entries_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_entries_batch ON public.journal_entries USING btree (batch_id);


--
-- Name: idx_journal_entries_clinic_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_entries_clinic_group ON public.journal_entries USING btree (batch_id, clinic_group);


--
-- Name: idx_journal_entries_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_entries_org ON public.journal_entries USING btree (org_id);


--
-- Name: idx_journal_entries_org_real; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_entries_org_real ON public.journal_entries USING btree (org_id, je_type) WHERE (NOT is_test);


--
-- Name: idx_mx_payroll_col_map_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mx_payroll_col_map_org ON public.mx_payroll_column_map USING btree (org_id);


--
-- Name: idx_org_members_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_members_org ON public.org_members USING btree (org_id);


--
-- Name: idx_org_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_members_user ON public.org_members USING btree (user_id);


--
-- Name: idx_org_modules_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_org_modules_org ON public.org_modules USING btree (org_id);


--
-- Name: idx_organizations_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organizations_slug ON public.organizations USING btree (slug);


--
-- Name: idx_payroll_col_map_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_col_map_org ON public.payroll_column_account_map USING btree (org_id);


--
-- Name: idx_payroll_employees_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_employees_batch ON public.payroll_employees USING btree (batch_id);


--
-- Name: idx_payroll_employees_dept; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_employees_dept ON public.payroll_employees USING btree (batch_id, department_netsuite);


--
-- Name: idx_payroll_employees_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_employees_org ON public.payroll_employees USING btree (org_id);


--
-- Name: idx_process_runs_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_runs_batch ON public.process_runs USING btree (batch_id);


--
-- Name: idx_process_runs_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_runs_expiry ON public.process_runs USING btree (expires_at) WHERE (state = ANY (ARRAY['draft'::text, 'parsing'::text, 'needs_input'::text, 'ready'::text]));


--
-- Name: idx_process_runs_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_runs_org ON public.process_runs USING btree (org_id);


--
-- Name: idx_process_runs_org_process; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_runs_org_process ON public.process_runs USING btree (org_id, process, created_at DESC);


--
-- Name: idx_process_runs_org_real; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_runs_org_real ON public.process_runs USING btree (org_id, process) WHERE (NOT is_test);


--
-- Name: idx_process_runs_period_booking; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_runs_period_booking ON public.process_runs USING btree (org_id, process, fiscal_year, period) WHERE (state = 'completed'::text);


--
-- Name: idx_process_runs_superseded_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_runs_superseded_by ON public.process_runs USING btree (superseded_by_run_id) WHERE (superseded_by_run_id IS NOT NULL);


--
-- Name: idx_processed_entries_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_processed_entries_org ON public.processed_entries USING btree (org_id);


--
-- Name: idx_processed_entries_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_processed_entries_run ON public.processed_entries USING btree (run_id);


--
-- Name: idx_processing_runs_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_processing_runs_org ON public.processing_runs USING btree (org_id);


--
-- Name: idx_processing_runs_org_real; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_processing_runs_org_real ON public.processing_runs USING btree (org_id) WHERE (NOT is_test);


--
-- Name: idx_processing_runs_upload; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_processing_runs_upload ON public.processing_runs USING btree (upload_id);


--
-- Name: idx_qb_account_map_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_account_map_org ON public.qb_account_map USING btree (org_id);


--
-- Name: idx_qb_clinic_map_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_clinic_map_org ON public.qb_clinic_map USING btree (org_id);


--
-- Name: idx_qb_department_map_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_department_map_org ON public.qb_department_map USING btree (org_id);


--
-- Name: idx_qb_export_tie_out_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_export_tie_out_batch ON public.qb_export_tie_out USING btree (batch_id, process);


--
-- Name: idx_qb_export_tie_out_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_export_tie_out_org ON public.qb_export_tie_out USING btree (org_id);


--
-- Name: idx_qb_location_map_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_location_map_org ON public.qb_location_map USING btree (org_id);


--
-- Name: idx_qb_other_code_map_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_other_code_map_org ON public.qb_other_code_map USING btree (org_id);


--
-- Name: idx_qb_payer_label_map_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_payer_label_map_org ON public.qb_payer_label_map USING btree (org_id);


--
-- Name: idx_qb_provider_map_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_provider_map_org ON public.qb_provider_map USING btree (org_id);


--
-- Name: idx_qb_usa_coding_exception_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_usa_coding_exception_org ON public.qb_usa_coding_exception USING btree (org_id);


--
-- Name: idx_qb_usa_department_rule_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_usa_department_rule_org ON public.qb_usa_department_rule USING btree (org_id);


--
-- Name: idx_qb_usa_employee_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_usa_employee_name ON public.qb_usa_employee USING btree (org_id, name);


--
-- Name: idx_qb_usa_employee_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_usa_employee_org ON public.qb_usa_employee USING btree (org_id);


--
-- Name: idx_qb_usa_location_rule_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_usa_location_rule_org ON public.qb_usa_location_rule USING btree (org_id);


--
-- Name: idx_qb_usa_payroll_gate_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_usa_payroll_gate_batch ON public.qb_usa_payroll_gate USING btree (batch_id);


--
-- Name: idx_qb_usa_payroll_gate_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_usa_payroll_gate_org ON public.qb_usa_payroll_gate USING btree (org_id);


--
-- Name: idx_qb_usa_payroll_journal_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_usa_payroll_journal_batch ON public.qb_usa_payroll_journal USING btree (batch_id);


--
-- Name: idx_qb_usa_payroll_journal_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qb_usa_payroll_journal_org ON public.qb_usa_payroll_journal USING btree (org_id);


--
-- Name: idx_qbo_connection_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qbo_connection_org ON public.qbo_connection USING btree (org_id);


--
-- Name: idx_role_permissions_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permissions_role ON public.role_permissions USING btree (role_id);


--
-- Name: idx_roles_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_roles_org ON public.roles USING btree (org_id);


--
-- Name: idx_source_transactions_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_source_transactions_org ON public.source_transactions USING btree (org_id);


--
-- Name: idx_source_transactions_upload; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_source_transactions_upload ON public.source_transactions USING btree (upload_id);


--
-- Name: idx_transactions_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_batch ON public.transactions USING btree (batch_id);


--
-- Name: idx_transactions_clinic_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_clinic_group ON public.transactions USING btree (batch_id, clinic_group);


--
-- Name: idx_transactions_mapping_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_mapping_status ON public.transactions USING btree (batch_id, mapping_status);


--
-- Name: idx_transactions_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_org ON public.transactions USING btree (org_id);


--
-- Name: idx_ts_benefit_override_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ts_benefit_override_org ON public.ts_benefit_override USING btree (org_id);


--
-- Name: idx_ts_benefit_override_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ts_benefit_override_period ON public.ts_benefit_override USING btree (org_id, year, period);


--
-- Name: idx_uniform_catalog_org_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uniform_catalog_org_lookup ON public.uniform_catalog USING btree (org_id, item_type, size, gender, brand, cut);


--
-- Name: idx_uniform_column_mappings_org_header; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uniform_column_mappings_org_header ON public.uniform_column_mappings USING btree (org_id, source_header);


--
-- Name: idx_uniform_order_items_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uniform_order_items_order_id ON public.uniform_order_items USING btree (order_id);


--
-- Name: idx_uniform_orders_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uniform_orders_org_created ON public.uniform_orders USING btree (org_id, created_at DESC);


--
-- Name: idx_uniform_size_mappings_org_pattern; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uniform_size_mappings_org_pattern ON public.uniform_size_mappings USING btree (org_id, input_pattern);


--
-- Name: idx_unmapped_items_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_unmapped_items_batch ON public.unmapped_items USING btree (batch_id);


--
-- Name: idx_unmapped_items_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_unmapped_items_org ON public.unmapped_items USING btree (org_id);


--
-- Name: idx_uploads_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uploads_org ON public.uploads USING btree (org_id);


--
-- Name: idx_uploads_org_real; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uploads_org_real ON public.uploads USING btree (org_id) WHERE (NOT is_test);


--
-- Name: idx_uploads_processor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uploads_processor ON public.uploads USING btree (org_id, processor_type);


--
-- Name: idx_uploads_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uploads_status ON public.uploads USING btree (org_id, status);


--
-- Name: import_batches_active_file_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX import_batches_active_file_key ON public.import_batches USING btree (org_id, fiscal_year, period, file_hash) WHERE (status IS DISTINCT FROM 'superseded'::text);


--
-- Name: pnl_account_drivers_org_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pnl_account_drivers_org_code_key ON public.pnl_account_drivers USING btree (org_id, system, code);


--
-- Name: pnl_configs_active_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pnl_configs_active_name_key ON public.pnl_configs USING btree (org_id, name) WHERE (superseded_by IS NULL);


--
-- Name: pnl_configs_org_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pnl_configs_org_idx ON public.pnl_configs USING btree (org_id);


--
-- Name: pnl_cost_batches_active_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pnl_cost_batches_active_key ON public.pnl_cost_batches USING btree (org_id, fiscal_year, period) WHERE (superseded_by IS NULL);


--
-- Name: pnl_cost_lines_org_batch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pnl_cost_lines_org_batch_idx ON public.pnl_cost_lines USING btree (org_id, batch_id);


--
-- Name: pnl_cost_lines_org_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pnl_cost_lines_org_period_idx ON public.pnl_cost_lines USING btree (org_id, fiscal_year, period);


--
-- Name: pnl_driver_batches_active_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pnl_driver_batches_active_key ON public.pnl_driver_batches USING btree (org_id, fiscal_year, period) WHERE (superseded_by IS NULL);


--
-- Name: pnl_driver_values_grain_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pnl_driver_values_grain_key ON public.pnl_driver_values USING btree (org_id, batch_id, driver_id, period_id, provider_code, clinic);


--
-- Name: pnl_driver_values_org_batch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pnl_driver_values_org_batch_idx ON public.pnl_driver_values USING btree (org_id, batch_id);


--
-- Name: uq_process_runs_idempotency; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_process_runs_idempotency ON public.process_runs USING btree (org_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: uq_qb_export_tie_out; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_qb_export_tie_out ON public.qb_export_tie_out USING btree (batch_id, file_name, journal_no);


--
-- Name: uq_qb_usa_coding_exception; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_qb_usa_coding_exception ON public.qb_usa_coding_exception USING btree (org_id, adp_dept_code, adp_cost_code) NULLS NOT DISTINCT;


--
-- Name: uq_qb_usa_department_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_qb_usa_department_rule ON public.qb_usa_department_rule USING btree (org_id, adp_cost_code);


--
-- Name: uq_qb_usa_employee; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_qb_usa_employee ON public.qb_usa_employee USING btree (org_id, employee_key);


--
-- Name: uq_qb_usa_location_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_qb_usa_location_rule ON public.qb_usa_location_rule USING btree (org_id, adp_dept_code);


--
-- Name: uq_qb_usa_payroll_gate; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_qb_usa_payroll_gate ON public.qb_usa_payroll_gate USING btree (batch_id, gate_name);


--
-- Name: uq_qb_usa_payroll_journal; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_qb_usa_payroll_journal ON public.qb_usa_payroll_journal USING btree (batch_id, journal_no);


--
-- Name: uq_qbo_connection; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_qbo_connection ON public.qbo_connection USING btree (org_id, realm_id);


--
-- Name: uq_ts_benefit_override_benefit; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_ts_benefit_override_benefit ON public.ts_benefit_override USING btree (org_id, year, period, run, entity, name) WHERE (kind = 'benefit'::text);


--
-- Name: uq_ts_benefit_override_fixed_pool; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_ts_benefit_override_fixed_pool ON public.ts_benefit_override USING btree (org_id, entity) WHERE (kind = 'fixed_pool'::text);


--
-- Name: uq_ts_benefit_override_redistribution; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_ts_benefit_override_redistribution ON public.ts_benefit_override USING btree (org_id, year, period, run, entity, name) WHERE (kind = 'redistribution'::text);


--
-- Name: uq_ts_benefit_override_redistribution_order; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_ts_benefit_override_redistribution_order ON public.ts_benefit_override USING btree (org_id, year, period, run, entity, sort_order) WHERE (kind = 'redistribution'::text);


--
-- Name: uq_ts_benefit_override_variant; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_ts_benefit_override_variant ON public.ts_benefit_override USING btree (org_id, employee_id) WHERE (kind = 'variant'::text);


--
-- Name: uq_uniform_size_mappings_global; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_uniform_size_mappings_global ON public.uniform_size_mappings USING btree (org_id, input_pattern) WHERE (item_type IS NULL);


--
-- Name: uq_uniform_size_mappings_typed; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_uniform_size_mappings_typed ON public.uniform_size_mappings USING btree (org_id, input_pattern, item_type) WHERE (item_type IS NOT NULL);


--
-- Name: artifact_downloads artifact_downloads_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_downloads
    ADD CONSTRAINT artifact_downloads_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE SET NULL;


--
-- Name: artifact_downloads artifact_downloads_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_downloads
    ADD CONSTRAINT artifact_downloads_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: artifact_downloads artifact_downloads_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_downloads
    ADD CONSTRAINT artifact_downloads_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.process_runs(run_id) ON DELETE SET NULL;


--
-- Name: bkv5_location_remap bkv5_location_remap_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bkv5_location_remap
    ADD CONSTRAINT bkv5_location_remap_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: config_account_codes config_account_codes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_account_codes
    ADD CONSTRAINT config_account_codes_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: config_clinic_groups config_clinic_groups_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_clinic_groups
    ADD CONSTRAINT config_clinic_groups_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: config_departments config_departments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_departments
    ADD CONSTRAINT config_departments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: config_employees config_employees_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_employees
    ADD CONSTRAINT config_employees_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: config_fiscal_calendar config_fiscal_calendar_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_fiscal_calendar
    ADD CONSTRAINT config_fiscal_calendar_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: config_history config_history_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_history
    ADD CONSTRAINT config_history_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: config_locations config_locations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_locations
    ADD CONSTRAINT config_locations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: config_mso_mappings config_mso_mappings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_mso_mappings
    ADD CONSTRAINT config_mso_mappings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: config_mx_employees config_mx_employees_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_mx_employees
    ADD CONSTRAINT config_mx_employees_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: config_mx_employees config_mx_employees_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_mx_employees
    ADD CONSTRAINT config_mx_employees_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES auth.users(id);


--
-- Name: config_payers config_payers_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_payers
    ADD CONSTRAINT config_payers_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: config_providers config_providers_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_providers
    ADD CONSTRAINT config_providers_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: config_settings config_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_settings
    ADD CONSTRAINT config_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: employee_clinic_allocations employee_clinic_allocations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_clinic_allocations
    ADD CONSTRAINT employee_clinic_allocations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: fiscal_calendar fiscal_calendar_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_calendar
    ADD CONSTRAINT fiscal_calendar_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: import_batches import_batches_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: import_batches import_batches_superseded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_superseded_by_fkey FOREIGN KEY (superseded_by) REFERENCES public.import_batches(id);


--
-- Name: invite_codes invite_codes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: invite_codes invite_codes_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: journal_entries journal_entries_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id);


--
-- Name: journal_entries journal_entries_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mx_payroll_column_map mx_payroll_column_map_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mx_payroll_column_map
    ADD CONSTRAINT mx_payroll_column_map_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES auth.users(id);


--
-- Name: org_members org_members_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: org_members org_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: org_modules org_modules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_modules
    ADD CONSTRAINT org_modules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: payroll_column_account_map payroll_column_account_map_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_column_account_map
    ADD CONSTRAINT payroll_column_account_map_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: payroll_employees payroll_employees_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_employees
    ADD CONSTRAINT payroll_employees_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id);


--
-- Name: payroll_employees payroll_employees_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_employees
    ADD CONSTRAINT payroll_employees_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: pnl_account_drivers pnl_account_drivers_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_account_drivers
    ADD CONSTRAINT pnl_account_drivers_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: pnl_configs pnl_configs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_configs
    ADD CONSTRAINT pnl_configs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: pnl_configs pnl_configs_superseded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_configs
    ADD CONSTRAINT pnl_configs_superseded_by_fkey FOREIGN KEY (superseded_by) REFERENCES public.pnl_configs(id);


--
-- Name: pnl_cost_batches pnl_cost_batches_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_cost_batches
    ADD CONSTRAINT pnl_cost_batches_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: pnl_cost_batches pnl_cost_batches_superseded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_cost_batches
    ADD CONSTRAINT pnl_cost_batches_superseded_by_fkey FOREIGN KEY (superseded_by) REFERENCES public.pnl_cost_batches(id);


--
-- Name: pnl_cost_lines pnl_cost_lines_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_cost_lines
    ADD CONSTRAINT pnl_cost_lines_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.pnl_cost_batches(id) ON DELETE CASCADE;


--
-- Name: pnl_cost_lines pnl_cost_lines_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_cost_lines
    ADD CONSTRAINT pnl_cost_lines_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: pnl_driver_batches pnl_driver_batches_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_driver_batches
    ADD CONSTRAINT pnl_driver_batches_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: pnl_driver_batches pnl_driver_batches_superseded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_driver_batches
    ADD CONSTRAINT pnl_driver_batches_superseded_by_fkey FOREIGN KEY (superseded_by) REFERENCES public.pnl_driver_batches(id);


--
-- Name: pnl_driver_values pnl_driver_values_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_driver_values
    ADD CONSTRAINT pnl_driver_values_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.pnl_driver_batches(id) ON DELETE CASCADE;


--
-- Name: pnl_driver_values pnl_driver_values_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pnl_driver_values
    ADD CONSTRAINT pnl_driver_values_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: process_runs process_runs_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_runs
    ADD CONSTRAINT process_runs_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE SET NULL;


--
-- Name: process_runs process_runs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_runs
    ADD CONSTRAINT process_runs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: process_runs process_runs_superseded_by_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_runs
    ADD CONSTRAINT process_runs_superseded_by_run_id_fkey FOREIGN KEY (superseded_by_run_id) REFERENCES public.process_runs(run_id) ON DELETE SET NULL;


--
-- Name: processed_entries processed_entries_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_entries
    ADD CONSTRAINT processed_entries_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: processed_entries processed_entries_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_entries
    ADD CONSTRAINT processed_entries_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.processing_runs(id);


--
-- Name: processing_runs processing_runs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processing_runs
    ADD CONSTRAINT processing_runs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: processing_runs processing_runs_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processing_runs
    ADD CONSTRAINT processing_runs_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.uploads(id);


--
-- Name: qb_account_map qb_account_map_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_account_map
    ADD CONSTRAINT qb_account_map_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_clinic_map qb_clinic_map_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_clinic_map
    ADD CONSTRAINT qb_clinic_map_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_department_map qb_department_map_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_department_map
    ADD CONSTRAINT qb_department_map_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_export_tie_out qb_export_tie_out_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_export_tie_out
    ADD CONSTRAINT qb_export_tie_out_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: qb_export_tie_out qb_export_tie_out_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_export_tie_out
    ADD CONSTRAINT qb_export_tie_out_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_location_map qb_location_map_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_location_map
    ADD CONSTRAINT qb_location_map_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_other_code_map qb_other_code_map_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_other_code_map
    ADD CONSTRAINT qb_other_code_map_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_payer_label_map qb_payer_label_map_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_payer_label_map
    ADD CONSTRAINT qb_payer_label_map_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_provider_map qb_provider_map_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_provider_map
    ADD CONSTRAINT qb_provider_map_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_usa_coding_exception qb_usa_coding_exception_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_coding_exception
    ADD CONSTRAINT qb_usa_coding_exception_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_usa_department_rule qb_usa_department_rule_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_department_rule
    ADD CONSTRAINT qb_usa_department_rule_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_usa_employee qb_usa_employee_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_employee
    ADD CONSTRAINT qb_usa_employee_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_usa_location_rule qb_usa_location_rule_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_location_rule
    ADD CONSTRAINT qb_usa_location_rule_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_usa_payroll_gate qb_usa_payroll_gate_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_payroll_gate
    ADD CONSTRAINT qb_usa_payroll_gate_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: qb_usa_payroll_gate qb_usa_payroll_gate_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_payroll_gate
    ADD CONSTRAINT qb_usa_payroll_gate_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qb_usa_payroll_journal qb_usa_payroll_journal_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_payroll_journal
    ADD CONSTRAINT qb_usa_payroll_journal_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: qb_usa_payroll_journal qb_usa_payroll_journal_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qb_usa_payroll_journal
    ADD CONSTRAINT qb_usa_payroll_journal_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: qbo_connection qbo_connection_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_connection
    ADD CONSTRAINT qbo_connection_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: roles roles_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: source_transactions source_transactions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_transactions
    ADD CONSTRAINT source_transactions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: source_transactions source_transactions_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_transactions
    ADD CONSTRAINT source_transactions_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.uploads(id);


--
-- Name: transactions transactions_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id);


--
-- Name: transactions transactions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ts_benefit_override ts_benefit_override_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ts_benefit_override
    ADD CONSTRAINT ts_benefit_override_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: uniform_catalog uniform_catalog_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_catalog
    ADD CONSTRAINT uniform_catalog_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: uniform_column_mappings uniform_column_mappings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_column_mappings
    ADD CONSTRAINT uniform_column_mappings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: uniform_order_items uniform_order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_order_items
    ADD CONSTRAINT uniform_order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.uniform_orders(id) ON DELETE CASCADE;


--
-- Name: uniform_order_items uniform_order_items_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_order_items
    ADD CONSTRAINT uniform_order_items_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: uniform_orders uniform_orders_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_orders
    ADD CONSTRAINT uniform_orders_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: uniform_size_mappings uniform_size_mappings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uniform_size_mappings
    ADD CONSTRAINT uniform_size_mappings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: unmapped_items unmapped_items_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unmapped_items
    ADD CONSTRAINT unmapped_items_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id);


--
-- Name: unmapped_items unmapped_items_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unmapped_items
    ADD CONSTRAINT unmapped_items_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: uploads uploads_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: invite_codes Admins can manage invite codes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage invite codes" ON public.invite_codes USING ((org_id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE ((org_members.user_id = auth.uid()) AND (org_members.role = 'admin'::text))))) WITH CHECK ((org_id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE ((org_members.user_id = auth.uid()) AND (org_members.role = 'admin'::text)))));


--
-- Name: org_members Admins can manage org members; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage org members" ON public.org_members USING ((org_id IN ( SELECT org_members_1.org_id
   FROM public.org_members org_members_1
  WHERE ((org_members_1.user_id = auth.uid()) AND (org_members_1.role = 'admin'::text)))));


--
-- Name: role_permissions Admins can manage role permissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage role permissions" ON public.role_permissions USING ((role_id IN ( SELECT roles.id
   FROM public.roles
  WHERE (roles.org_id IN ( SELECT org_members.org_id
           FROM public.org_members
          WHERE ((org_members.user_id = auth.uid()) AND (org_members.role = 'admin'::text)))))));


--
-- Name: roles Admins can manage roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage roles" ON public.roles USING ((org_id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE ((org_members.user_id = auth.uid()) AND (org_members.role = 'admin'::text)))));


--
-- Name: organizations Admins can update their organization; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update their organization" ON public.organizations FOR UPDATE USING ((id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE ((org_members.user_id = auth.uid()) AND (org_members.role = 'admin'::text)))));


--
-- Name: organizations Authenticated users can create organizations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can create organizations" ON public.organizations FOR INSERT WITH CHECK ((auth.uid() IS NOT NULL));


--
-- Name: org_members Members can view org members; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Members can view org members" ON public.org_members FOR SELECT USING ((org_id IN ( SELECT org_members_1.org_id
   FROM public.org_members org_members_1
  WHERE (org_members_1.user_id = auth.uid()))));


--
-- Name: org_modules Members can view org modules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Members can view org modules" ON public.org_modules FOR SELECT USING ((org_id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE (org_members.user_id = auth.uid()))));


--
-- Name: role_permissions Members can view role permissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Members can view role permissions" ON public.role_permissions FOR SELECT USING ((role_id IN ( SELECT roles.id
   FROM public.roles
  WHERE (roles.org_id IN ( SELECT org_members.org_id
           FROM public.org_members
          WHERE (org_members.user_id = auth.uid()))))));


--
-- Name: roles Members can view roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Members can view roles" ON public.roles FOR SELECT USING ((org_id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE (org_members.user_id = auth.uid()))));


--
-- Name: organizations Members can view their organization; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Members can view their organization" ON public.organizations FOR SELECT USING ((id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE (org_members.user_id = auth.uid()))));


--
-- Name: org_members Users can join organizations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can join organizations" ON public.org_members FOR INSERT WITH CHECK ((user_id = auth.uid()));


--
-- Name: artifact_downloads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.artifact_downloads ENABLE ROW LEVEL SECURITY;

--
-- Name: artifact_downloads artifact_downloads_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY artifact_downloads_org_isolation ON public.artifact_downloads USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qgenda_workspaces authenticated can insert workspaces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated can insert workspaces" ON public.qgenda_workspaces FOR INSERT TO authenticated WITH CHECK (true);


--
-- Name: qgenda_workspaces authenticated can read workspaces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated can read workspaces" ON public.qgenda_workspaces FOR SELECT TO authenticated USING (true);


--
-- Name: qgenda_workspaces authenticated can update workspaces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated can update workspaces" ON public.qgenda_workspaces FOR UPDATE TO authenticated USING (true) WITH CHECK (true);


--
-- Name: bkv5_location_remap; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bkv5_location_remap ENABLE ROW LEVEL SECURITY;

--
-- Name: bkv5_location_remap bkv5_location_remap_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY bkv5_location_remap_org_isolation ON public.bkv5_location_remap USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

--
-- Name: config_account_codes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_account_codes ENABLE ROW LEVEL SECURITY;

--
-- Name: config_clinic_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_clinic_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: config_departments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_departments ENABLE ROW LEVEL SECURITY;

--
-- Name: config_employees; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_employees ENABLE ROW LEVEL SECURITY;

--
-- Name: config_fiscal_calendar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_fiscal_calendar ENABLE ROW LEVEL SECURITY;

--
-- Name: config_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_history ENABLE ROW LEVEL SECURITY;

--
-- Name: config_locations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_locations ENABLE ROW LEVEL SECURITY;

--
-- Name: config_mso_mappings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_mso_mappings ENABLE ROW LEVEL SECURITY;

--
-- Name: config_mx_employees; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_mx_employees ENABLE ROW LEVEL SECURITY;

--
-- Name: config_payers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_payers ENABLE ROW LEVEL SECURITY;

--
-- Name: config_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: config_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: employee_clinic_allocations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.employee_clinic_allocations ENABLE ROW LEVEL SECURITY;

--
-- Name: fiscal_calendar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fiscal_calendar ENABLE ROW LEVEL SECURITY;

--
-- Name: import_batches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.import_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: invite_codes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invite_codes ENABLE ROW LEVEL SECURITY;

--
-- Name: invoices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.journal_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: mx_payroll_column_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mx_payroll_column_map ENABLE ROW LEVEL SECURITY;

--
-- Name: clients org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.clients USING ((org_id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE (org_members.user_id = auth.uid())))) WITH CHECK ((org_id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE (org_members.user_id = auth.uid()))));


--
-- Name: config_account_codes org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_account_codes USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_clinic_groups org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_clinic_groups USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_departments org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_departments USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_employees org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_employees USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_fiscal_calendar org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_fiscal_calendar USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_history org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_history USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_locations org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_locations USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_mso_mappings org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_mso_mappings USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_payers org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_payers USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_providers org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_providers USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_settings org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.config_settings USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: employee_clinic_allocations org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.employee_clinic_allocations USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: fiscal_calendar org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.fiscal_calendar USING ((org_id = public.user_org_id()));


--
-- Name: import_batches org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.import_batches USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: invoices org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.invoices USING ((org_id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE (org_members.user_id = auth.uid())))) WITH CHECK ((org_id IN ( SELECT org_members.org_id
   FROM public.org_members
  WHERE (org_members.user_id = auth.uid()))));


--
-- Name: journal_entries org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.journal_entries USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: mx_payroll_column_map org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.mx_payroll_column_map USING ((org_id = public.user_org_id()));


--
-- Name: org_modules org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.org_modules USING ((org_id = public.user_org_id()));


--
-- Name: payroll_column_account_map org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.payroll_column_account_map USING ((org_id = public.user_org_id()));


--
-- Name: payroll_employees org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.payroll_employees USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: pnl_account_drivers org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.pnl_account_drivers USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: pnl_configs org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.pnl_configs USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: pnl_cost_batches org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.pnl_cost_batches USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: pnl_cost_lines org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.pnl_cost_lines USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: pnl_driver_batches org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.pnl_driver_batches USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: pnl_driver_values org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.pnl_driver_values USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: processed_entries org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.processed_entries USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: processing_runs org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.processing_runs USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: source_transactions org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.source_transactions USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: transactions org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.transactions USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: unmapped_items org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.unmapped_items USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: uploads org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation ON public.uploads USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: config_mx_employees org_isolation_mx_employees; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_isolation_mx_employees ON public.config_mx_employees USING ((org_id = ( SELECT org_members.org_id
   FROM public.org_members
  WHERE (org_members.user_id = auth.uid())
 LIMIT 1)));


--
-- Name: org_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_members ENABLE ROW LEVEL SECURITY;

--
-- Name: org_modules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_modules ENABLE ROW LEVEL SECURITY;

--
-- Name: organizations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;

--
-- Name: payroll_column_account_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payroll_column_account_map ENABLE ROW LEVEL SECURITY;

--
-- Name: payroll_employees; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payroll_employees ENABLE ROW LEVEL SECURITY;

--
-- Name: pnl_account_drivers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pnl_account_drivers ENABLE ROW LEVEL SECURITY;

--
-- Name: pnl_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pnl_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: pnl_cost_batches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pnl_cost_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: pnl_cost_lines; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pnl_cost_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: pnl_driver_batches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pnl_driver_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: pnl_driver_values; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pnl_driver_values ENABLE ROW LEVEL SECURITY;

--
-- Name: process_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.process_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: process_runs process_runs_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY process_runs_org_isolation ON public.process_runs USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: processed_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.processed_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: processing_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.processing_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_account_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_account_map ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_account_map qb_account_map_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_account_map_org_isolation ON public.qb_account_map USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_clinic_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_clinic_map ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_clinic_map qb_clinic_map_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_clinic_map_org_isolation ON public.qb_clinic_map USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_department_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_department_map ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_department_map qb_department_map_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_department_map_org_isolation ON public.qb_department_map USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_export_tie_out; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_export_tie_out ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_export_tie_out qb_export_tie_out_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_export_tie_out_org_isolation ON public.qb_export_tie_out USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_location_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_location_map ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_location_map qb_location_map_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_location_map_org_isolation ON public.qb_location_map USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_other_code_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_other_code_map ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_other_code_map qb_other_code_map_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_other_code_map_org_isolation ON public.qb_other_code_map USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_payer_label_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_payer_label_map ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_payer_label_map qb_payer_label_map_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_payer_label_map_org_isolation ON public.qb_payer_label_map USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_provider_map; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_provider_map ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_provider_map qb_provider_map_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_provider_map_org_isolation ON public.qb_provider_map USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_usa_coding_exception; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_usa_coding_exception ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_usa_coding_exception qb_usa_coding_exception_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_usa_coding_exception_org_isolation ON public.qb_usa_coding_exception USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_usa_department_rule; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_usa_department_rule ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_usa_department_rule qb_usa_department_rule_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_usa_department_rule_org_isolation ON public.qb_usa_department_rule USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_usa_employee; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_usa_employee ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_usa_employee qb_usa_employee_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_usa_employee_org_isolation ON public.qb_usa_employee USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_usa_location_rule; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_usa_location_rule ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_usa_location_rule qb_usa_location_rule_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_usa_location_rule_org_isolation ON public.qb_usa_location_rule USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_usa_payroll_gate; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_usa_payroll_gate ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_usa_payroll_gate qb_usa_payroll_gate_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_usa_payroll_gate_org_isolation ON public.qb_usa_payroll_gate USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qb_usa_payroll_journal; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qb_usa_payroll_journal ENABLE ROW LEVEL SECURITY;

--
-- Name: qb_usa_payroll_journal qb_usa_payroll_journal_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qb_usa_payroll_journal_org_isolation ON public.qb_usa_payroll_journal USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qbo_connection; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qbo_connection ENABLE ROW LEVEL SECURITY;

--
-- Name: qbo_connection qbo_connection_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qbo_connection_org_isolation ON public.qbo_connection USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: qgenda_workspaces; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.qgenda_workspaces ENABLE ROW LEVEL SECURITY;

--
-- Name: role_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;

--
-- Name: source_transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.source_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: superadmins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.superadmins ENABLE ROW LEVEL SECURITY;

--
-- Name: superadmins superadmins_self_only; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY superadmins_self_only ON public.superadmins USING ((user_id = auth.uid()));


--
-- Name: transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: ts_benefit_override; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ts_benefit_override ENABLE ROW LEVEL SECURITY;

--
-- Name: ts_benefit_override ts_benefit_override_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ts_benefit_override_org_isolation ON public.ts_benefit_override USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: uniform_catalog; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.uniform_catalog ENABLE ROW LEVEL SECURITY;

--
-- Name: uniform_catalog uniform_catalog_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY uniform_catalog_org_isolation ON public.uniform_catalog USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: uniform_column_mappings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.uniform_column_mappings ENABLE ROW LEVEL SECURITY;

--
-- Name: uniform_column_mappings uniform_column_mappings_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY uniform_column_mappings_org_isolation ON public.uniform_column_mappings USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: uniform_order_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.uniform_order_items ENABLE ROW LEVEL SECURITY;

--
-- Name: uniform_order_items uniform_order_items_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY uniform_order_items_org_isolation ON public.uniform_order_items USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: uniform_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.uniform_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: uniform_orders uniform_orders_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY uniform_orders_org_isolation ON public.uniform_orders USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: uniform_size_mappings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.uniform_size_mappings ENABLE ROW LEVEL SECURITY;

--
-- Name: uniform_size_mappings uniform_size_mappings_org_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY uniform_size_mappings_org_isolation ON public.uniform_size_mappings USING ((org_id = public.user_org_id())) WITH CHECK ((org_id = public.user_org_id()));


--
-- Name: unmapped_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.unmapped_items ENABLE ROW LEVEL SECURITY;

--
-- Name: uploads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.uploads ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict 7vx07fHy4ARGHW7awas1ud6bd7KFQO1vcop08MWNzQWg3aeJWG4ipUpWPSlsl7l

