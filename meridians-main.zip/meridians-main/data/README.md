# data/

Reference data the application reads at runtime. **Almost nothing belongs here**, and what
does is small, non-client, and stable.

## What is tracked here

| Path | What it is |
|---|---|
| `Calendar/Calendar.xlsx` | The fiscal calendar — every date mapped to its fiscal period. The fiscal year runs late-December to late-December and periods are 4-5 weeks, so this cannot be computed from a calendar month. It moves into Postgres in Phase 3 (`docs/architecture/repo-layout.md` §3, row 16). |

## What does not live here — and where it goes instead

- **Input files.** `data/input/` is gitignored. Billing exports, payroll workbooks and
  carrier bills are client data and PHI; they are uploaded through the app, not committed.
  After the migration they land in the S3 `phi` bucket.
- **Databases.** `data/revenue.db` and every `*.db` are gitignored. The SQLite database is
  retained **only** for the legacy CLI (`process_revenue.py`) and is frozen — it is never
  extended, and no new feature may use it.
- **Generated output.** Journal-entry CSVs, enriched workbooks and reports go to `output/`
  (gitignored) today and to the S3 `artifacts` bucket after cutover — never into the repo.
- **Anything with a patient account number, an employee name, a date of birth or a member
  id in it.** Those live on the PHI volume; set `MERIDIAN_DATA_DIR` to point the whole tree
  there.
