# `infra/conformance-packs/` — vendored AWS Config conformance packs

One file lives here, and it is **not ours**: it is AWS's published HIPAA control
set, copied into this repository unchanged.

| | |
|---|---|
| **File** | `Operational-Best-Practices-for-HIPAA-Security.yaml` |
| **Source** | `https://raw.githubusercontent.com/awslabs/aws-config-rules/master/aws-config-conformance-packs/Operational-Best-Practices-for-HIPAA-Security.yaml` |
| **Upstream repo** | [`awslabs/aws-config-rules`](https://github.com/awslabs/aws-config-rules) (AWS Labs) |
| **Upstream commit** | `d51caecc74f6b23085476b23f2479c565c415b27` — *"Removing S3_BUCKET_LEVEL_PUBLIC_ACCESS_PROHIBITED which is redundant to limit rules to 130"* (#433), 2025-01-07 |
| **Downloaded** | 2026-09-15 |
| **SHA-256** | `6daaddbbd3da53b31f313cc00587fd2e4de2b59c4fad2e8feb68c0c03d52125b` |
| **Size** | 50,485 bytes · 130 AWS Config rules |
| **Modified?** | **No.** Byte for byte as published. |

## Why it is checked in rather than downloaded or uploaded

`meridian-shared-foundation` publishes this file with `aws_s3_assets.Asset` and
hands AWS Config the resulting S3 URL. The alternative — the operator uploading
the YAML to a bucket once, by hand, before the first deploy — was how this
started, and it has one failure mode worth naming: the stack deploys perfectly
whether or not anyone did the upload. The conformance pack resource is created,
CloudFormation is satisfied, and the 130 HIPAA rules are simply not there. A
control you believe is in place and is not is worse than one you know is missing.

Three things follow from vendoring it:

- **There is no step to forget.** `cdk deploy` publishes the asset.
- **The deployed control set is this file.** `cdk diff` shows a change here as a
  changed asset hash, so upgrading the pack is a reviewable pull request like any
  other — not a console upload nobody sees.
- **It does not depend on a size margin.** CloudFormation's inline `TemplateBody`
  limit is 51,200 bytes and this file is 50,485 — inside it, with about 700 bytes
  to spare. Two more rules upstream and inline would stop working. An S3 asset
  has no such cliff.

## Updating it

AWS revises the pack occasionally (usually adding or retiring rules). To take a
new version:

```bash
cd infra/conformance-packs
curl -sSL -o Operational-Best-Practices-for-HIPAA-Security.yaml \
  https://raw.githubusercontent.com/awslabs/aws-config-rules/master/aws-config-conformance-packs/Operational-Best-Practices-for-HIPAA-Security.yaml
shasum -a 256 Operational-Best-Practices-for-HIPAA-Security.yaml
```

Then update the table above (commit, date, SHA-256, size, rule count), run
`npx cdk diff -c env=staging meridian-shared-foundation` to see the asset change,
and **read the diff of the YAML itself** — a rule added here becomes a control
that can start reporting NON_COMPLIANT across the account on the next evaluation,
which is a thing to know about before it happens rather than after.

Do not edit the file to silence a rule. If a rule does not apply, record the
exception in `docs/compliance/` with the reason; an edited "AWS-published" pack is
one nobody can verify against upstream.
