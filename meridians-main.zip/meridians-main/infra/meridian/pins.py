"""Build inputs pinned by digest in the repository (Codex CX-INF-03).

`infra/pins/rds-global-bundle.sha256` is the one file `Dockerfile.api` and the webhook
sender's Lambda bundling both check the downloaded RDS CA bundle against. Written by
`scripts/pin_rds_ca_bundle.py`; `UNPINNED` until a human has run it, and both builds
refuse to run in that state.
"""

from __future__ import annotations

import re
from pathlib import Path

PIN_DIR = Path(__file__).resolve().parents[1] / "pins"
RDS_CA_PIN_FILE = PIN_DIR / "rds-global-bundle.sha256"
RDS_CA_BUNDLE_URL = "https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem"

_DIGEST = re.compile(r"^[0-9a-f]{64}$")


def rds_ca_bundle_sha256() -> str | None:
    """The pinned digest, or None while the pin file says `UNPINNED` (or is empty)."""
    for line in RDS_CA_PIN_FILE.read_text(encoding="utf-8").splitlines():
        value = line.strip()
        if value and not value.startswith("#"):
            return value if _DIGEST.match(value) else None
    return None


def rds_ca_bundle_commands(destination: str) -> list[str]:
    """Shell steps that fetch the bundle to `destination` and verify it, or refuse.

    Unpinned, the steps are a message and `exit 1`: the build fails where it would
    otherwise have trusted whatever the download returned. The failure is at bundling
    (deploy) time, not at synth, so `cdk synth` and the tests still run.
    """
    digest = rds_ca_bundle_sha256()
    if digest is None:
        return [
            "echo 'The RDS CA bundle is not pinned (infra/pins/rds-global-bundle.sha256): "
            "run scripts/pin_rds_ca_bundle.py' >&2",
            "exit 1",
        ]
    return [
        f"curl -fsSL -o {destination} {RDS_CA_BUNDLE_URL}",
        f"echo '{digest}  {destination}' | sha256sum -c -",
    ]
