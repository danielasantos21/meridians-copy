"""Which CloudWatch log groups each environment's CMKs may encrypt — one list, by name.

**CX-INF-04.** The `logs` and `phi` key policies used to let CloudWatch Logs use the key
for `log-group:*`, i.e. for any log group in the account. A principal able to call
`logs:AssociateKmsKey` on an unrelated group could then bind it to the production PHI
key: not a read of PHI, but a PHI key doing work nothing in this estate asked it to, and
a Decrypt trail that no longer means "Meridian production". The condition now names the
groups this estate actually creates, per environment, and nothing else.

The patterns live here, rather than in `stacks/data.py`, because three stacks need the
same names: `data` writes them into the key policies, `edge` and `observability` create
groups under them, and `infra/tests/test_data.py` walks every synthesized log group and
asserts it matches a pattern of the key it is encrypted with. A name that drifts from
this list is a group that cannot create (CloudWatch Logs refuses a key it may not use),
and that test is what finds it before a deploy does.
"""

from __future__ import annotations

from .naming import resource_name

#: WAF logs go to a CloudWatch log group whose name AWS **requires** to start with
#: `aws-waf-logs-`. That prefix wins over `meridian-<env>-logs-waf`: a
#: `PutLoggingConfiguration` against any other name is rejected outright. So the
#: convention is bent here, deliberately, and only here.
WAF_LOG_GROUP_PREFIX = "aws-waf-logs-meridian"


def rds_instance_identifier(env_name: str) -> str:
    """`meridian-<env>-rds-main`, the one database instance per environment."""
    return resource_name(env_name, "rds", "main")


def canary_name(env_name: str) -> str:
    """The health canary's name: `stag-health` / `prod-health`.

    CloudWatch Synthetics caps a canary name at 21 characters and prefixes its Lambda
    with `cwsyn-`, so `meridian-<env>-canary-health` (28) cannot be the name — the
    first four letters of the environment are what fit. It is here because the canary's
    implicit log group, `/aws/lambda/cwsyn-<name>-<uuid>`, is one of the names the
    `logs` key admits (tracker rows on the canary and helper log groups).
    """
    return f"{env_name[:4]}-health"


def logs_key_log_group_patterns(env_name: str) -> tuple[str, ...]:
    """Log-group NAME patterns the environment's `logs` CMK may encrypt.

    * `/meridian/<env>/*` — the ECS api, web and exec groups (`compute.py`).
    * `meridian-<env>-*` — the VPC flow log and stop-schedule groups.
    * `/aws/lambda/meridian-<env>-*` — every Lambda this environment names, plus the
      CDK helper Lambdas, whose CloudFormation-generated names start with the stack
      name (`meridian-<env>-vpc-CustomVpcRestrictDefaultSG…`).
    * `aws-waf-logs-meridian-<env>` — the WAF log group (AWS fixes the prefix).
    * `/aws/lambda/cwsyn-<canary>-*` — the canary's implicit group, which only the
      log-group governor (`observability.py`) ever associates with the key.
    """
    return (
        f"/meridian/{env_name}/*",
        f"meridian-{env_name}-*",
        f"/aws/lambda/meridian-{env_name}-*",
        f"{WAF_LOG_GROUP_PREFIX}-{env_name}",
        f"/aws/lambda/cwsyn-{canary_name(env_name)}-*",
    )


def phi_key_log_group_patterns(env_name: str) -> tuple[str, ...]:
    """Log-group NAME patterns the environment's `phi` CMK may encrypt.

    Only the two RDS exports (`postgresql`, `upgrade`), which hold pgaudit statement
    text and are therefore PHI (M-4, `data.py` `_log_groups`).
    """
    return (f"/aws/rds/instance/{rds_instance_identifier(env_name)}/*",)
