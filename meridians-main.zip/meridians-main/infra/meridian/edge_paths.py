"""The `api` target group's ALB path patterns, **generated from `web/next.config.mjs`**.

Plan §3 Phase 2 step 5 and `docs/architecture/inventory-web-surface.md` §1: on AWS
the ALB does the job Next.js's `rewrites()` does today. Every path the Next app
proxies to Flask has to reach the `api` target group, and **one omission is a hard
404 on a live screen** — there is no Jinja app on that hostname to fall back to.

So the list is never retyped. This module reads `web/next.config.mjs`, extracts the
rewrite sources, and turns them into ALB path patterns. `PINNED_API_PATH_PATTERNS`
below is what the file says *today*; a test asserts the two still agree, so changing
`next.config.mjs` without changing the edge fails CI rather than production.

**Plain language.** A Next.js *rewrite* says "when the browser asks for this path,
quietly fetch it from Flask instead". An ALB *listener rule* says "when a request
matches this path pattern, send it to these containers". Same idea, one layer lower.

**The translation, exactly**

| `next.config.mjs` | ALB pattern(s) | Why |
|---|---|---|
| `"/profile"` in the `jinja` list | `/profile` **and** `/profile/*` | the config expands every family into the bare path *and* `"<path>/:path*"` (`next.config.mjs:53-58`) |
| `source: "/api/:path*"` | `/api/*` | `:path*` is Next's "and everything under it"; `*` is the ALB's |

`/login` and `/dashboard` are **deliberately excluded.** They are appended to the
`jinja` list only when `MERIDIAN_JINJA_AUTH=1` (`next.config.mjs:44`), which is off
by default; the React login posts to `/api/v2/auth/login` instead. Sending `/login`
to Flask at the ALB would make the React sign-in screen unreachable. If that escape
hatch is ever switched on, the two rules are added at the edge deliberately — see
`jinja_auth_families()`.

**`/api/*` belongs to Flask, entirely** (L-7). At the edge, `/api/*` forwards to the
`api` target group, so any Next.js Route Handler at `web/src/app/api/**/route.ts` would be
**unreachable** — the ALB decides before Next.js is asked, and the request never gets to
the `web` task. That is not a bug to fix later; it is the routing contract this module
encodes, and it is the reason `/api` is a Flask prefix rather than a shared one.

There is no such file in `web/` today, and `infra/tests/test_edge.py` asserts that there
never is. The note lives here, in the module that generates the ALB rules, rather than in
`web/next.config.mjs`: `web/` is application code and this is the infrastructure fact it
would otherwise have to know about. If a future screen genuinely needs a Next.js API
route, it gets a prefix of its own — `/bff/*`, say — added to the Next rewrites and to the
edge deliberately, not by dropping a file under `web/src/app/api/`.

Nothing here touches AWS. It is a pure function over a text file, which is why it is
unit-tested on its own rather than only through a synthesized template.
"""

from __future__ import annotations

import re
from pathlib import Path

#: `infra/meridian/edge_paths.py` → the repository root.
REPO_ROOT = Path(__file__).resolve().parents[2]

#: The one file this module reads. It is *application* config, not infrastructure
#: config, and it is read rather than duplicated on purpose.
NEXT_CONFIG_PATH = REPO_ROOT / "web" / "next.config.mjs"

#: An ALB listener rule condition holds at most **five** path patterns, so the
#: generated list is chunked across several rules of the same priority band.
#: (Quota: "condition values per rule", 5, not adjustable.)
MAX_PATTERNS_PER_CONDITION = 5

#: The ALB's own limit on one pattern, in characters.
MAX_PATTERN_LENGTH = 128

_JINJA_BLOCK = re.compile(r"const\s+jinja\s*=\s*\[(?P<body>.*?)\]\s*;", re.DOTALL)
#: `...(JINJA_AUTH ? ["/login", "/dashboard"] : [])` — a conditional spread.
_SPREAD = re.compile(r"\.\.\.\(.*?\)\s*,?", re.DOTALL)
_LINE_COMMENT = re.compile(r"//[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)
_STRING = re.compile(r"""['"]([^'"]+)['"]""")
#: `{ source: "/api/:path*", destination: ... }` — the rewrites written out in full
#: rather than generated from the `jinja` list.
_LITERAL_SOURCE = re.compile(r"""source\s*:\s*['"](?P<path>[^'"]+)['"]""")

#: What `web/next.config.mjs` produces today (3 rewrite rules → 3 ALB patterns:
#: **no** Jinja families left, just `/auth/*`, `/api/*`, `/static/*`). Pinned so
#: that a change to the Next config is a **visible** change here, reviewed on
#: purpose.
#: Regenerate with: `venv/bin/python -c "from meridian.edge_paths import
#: api_path_patterns; print(api_path_patterns())"` run from `infra/`.
#:
#: **2026-09-16, Phase 4 step 5:** was 21 patterns / 9 families. `/signup`,
#: `/forgot-password` and `/reset-password` left the `jinja` list — the first
#: dropped (invite-only, P-6), the other two rebuilt as React routes — so the
#: edge must no longer forward them to Flask. This is the "visible change,
#: reviewed on purpose" the pin exists to force.
#:
#: **2026-09-16, Phase 5b:** 15 patterns / 6 families → 3 / 0. The `jinja` list
#: is now EMPTY. `/invoice`, `/profile`, `/superadmin` and
#: `/config/mx-employees` are React screens, over `/api/v2` — which the edge
#: still forwards, through `/api/*`, so nothing about those screens stops
#: working. `/logout` and `/wearbly` are DROPPED: signing out is
#: `POST /api/v2/auth/logout`, and Wearbly is frozen (P-5) with its screen not
#: rebuilt. Sending any of the six to Flask now would shadow the React route
#: and make the new screens unreachable — the same failure the `/login`
#: exclusion above exists to prevent, one phase later.
PINNED_API_PATH_PATTERNS: tuple[str, ...] = (
    "/auth/*",
    "/api/*",
    "/static/*",
)


def read_next_config(path: Path | None = None) -> str:
    """The text of `web/next.config.mjs`, comments stripped."""
    text = (path or NEXT_CONFIG_PATH).read_text(encoding="utf-8")
    return _LINE_COMMENT.sub("", _BLOCK_COMMENT.sub("", text))


def jinja_families(text: str) -> list[str]:
    """The unconditional entries of the `jinja` list, in file order.

    The conditional spread (`MERIDIAN_JINJA_AUTH`) is removed first, so `/login`
    and `/dashboard` never appear here. See the module docstring.
    """
    match = _JINJA_BLOCK.search(text)
    if match is None:
        raise ValueError(
            f"no `const jinja = [...]` list found in {NEXT_CONFIG_PATH}. "
            "The edge path patterns are generated from it — if the list was "
            "renamed or restructured, update infra/meridian/edge_paths.py "
            "deliberately rather than hand-typing the ALB rules."
        )
    body = _SPREAD.sub("", match.group("body"))
    return _STRING.findall(body)


def jinja_auth_families(text: str) -> list[str]:
    """The entries behind `MERIDIAN_JINJA_AUTH=1` — excluded from the edge.

    Returned so that the exclusion is testable and so the rollback hatch has a
    named place to be switched on from, not because anything routes them today.
    """
    match = _JINJA_BLOCK.search(text)
    if match is None:
        return []
    spread = _SPREAD.search(match.group("body"))
    return _STRING.findall(spread.group(0)) if spread else []


def literal_rewrite_sources(text: str) -> list[str]:
    """Rewrite sources written out as literals: `/auth/:path*`, `/api/:path*`, ...

    The `jinja` families are generated with a template literal
    (`` `${FLASK}${source}` ``) and so have no literal `source:` of their own;
    they come from `jinja_families()`.
    """
    seen: dict[str, None] = {}
    for source in _LITERAL_SOURCE.findall(text):
        seen.setdefault(source, None)
    return list(seen)


def next_source_to_alb_patterns(source: str) -> list[str]:
    """One Next.js rewrite source → the ALB path pattern(s) that cover it."""
    if source.endswith("/:path*"):
        return [source[: -len("/:path*")] + "/*"]
    if source.endswith("*"):  # any other catch-all spelling
        return [source]
    # A bare family: the config expands it into the path *and* its sub-paths.
    return [source, f"{source}/*"]


def api_path_patterns(text: str | None = None) -> list[str]:
    """Every ALB path pattern the `api` target group must answer for, in order.

    Order is file order — `jinja` families first, then the literal sources — so a
    diff of this list reads like a diff of `next.config.mjs`.
    """
    config = read_next_config() if text is None else text
    patterns: list[str] = []
    seen: set[str] = set()
    for source in [*jinja_families(config), *literal_rewrite_sources(config)]:
        for pattern in next_source_to_alb_patterns(source):
            if pattern not in seen:
                seen.add(pattern)
                patterns.append(pattern)
                if len(pattern) > MAX_PATTERN_LENGTH:
                    raise ValueError(
                        f"ALB path pattern {pattern!r} is longer than "
                        f"{MAX_PATTERN_LENGTH} characters"
                    )
    return patterns


def chunked(patterns: list[str], size: int = MAX_PATTERNS_PER_CONDITION) -> list[list[str]]:
    """Split the patterns across listener rules, five to a condition.

    Every chunk becomes its own `ApplicationListenerRule`; they are equivalent
    (same condition on the origin-verify header, same forward action), so the
    split is a quota artefact and nothing else.
    """
    if size < 1:
        raise ValueError("chunk size must be at least 1")
    return [patterns[i : i + size] for i in range(0, len(patterns), size)]
