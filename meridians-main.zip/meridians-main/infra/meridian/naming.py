"""Resource and stack naming for the Meridian AWS estate.

The convention is fixed by `docs/aws-migration-prompt.md` ("Conventions") and
ADR 0001: every AWS resource is named

    meridian-<env>-<component>-<purpose>

`<env>` is `staging`, `production`, or the pseudo-environment `shared` for the
account-level foundation stack (CloudTrail, GuardDuty, Config, budgets) which is
deployed once and belongs to neither environment.

**Secrets are the one exception**, and it is deliberate: a Secrets Manager secret
is named `meridian-<env>/<purpose>` (a slash, not a fourth hyphenated segment),
because the console reads the path segment as a folder and the plan's Phase 3
secrets already use that form. Everything else goes through `resource_name()`.

Nothing here reads an account id. Account and region come from the CLI
environment at deploy time (see `infra/app.py`).
"""

from __future__ import annotations

import re

#: The two real environments. `shared` is deliberately not in this list: it is
#: the account-level scope, not something you can deploy an application into.
ENVIRONMENTS = ("staging", "production")

#: Pseudo-environment used by the account-level foundation stack.
SHARED = "shared"

_SEGMENT = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


def _check(label: str, value: str) -> str:
    if not _SEGMENT.match(value):
        raise ValueError(
            f"{label} must be lowercase alphanumeric with single hyphens, got {value!r}"
        )
    return value


def resource_name(env: str, component: str, purpose: str) -> str:
    """Return `meridian-<env>-<component>-<purpose>`.

    >>> resource_name("staging", "s3", "artifacts")
    'meridian-staging-s3-artifacts'
    >>> resource_name("shared", "cloudtrail", "audit")
    'meridian-shared-cloudtrail-audit'
    """
    _check("env", env)
    _check("component", component)
    _check("purpose", purpose)
    return f"meridian-{env}-{component}-{purpose}"


def stack_name(env: str, component: str) -> str:
    """Return the CloudFormation stack name for one environment component.

    Stacks are `meridian-<env>-<component>`; the foundation stack is
    `meridian-shared-foundation`.
    """
    _check("env", env)
    _check("component", component)
    return f"meridian-{env}-{component}"


def is_valid_resource_name(name: str) -> bool:
    """True when `name` follows `meridian-<env>-<component>-<purpose>`."""
    parts = name.split("-")
    return len(parts) >= 4 and parts[0] == "meridian" and _SEGMENT.match(name) is not None
