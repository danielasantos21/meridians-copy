"""`meridian-<env>-data` — the environment's keys, database, buckets, secrets and backups.

**This stack is never destroyed**, in either environment. Phase 1 put the five
customer-managed keys (CMKs) and the origin-verify secret here for that reason; Phase 3
(`docs/aws-migration-plan.md` §3, steps 6-9) fills in everything the keys were made for:

* **RDS PostgreSQL 17.x**, `db.t4g.small` in production and `db.t4g.micro` in staging,
  gp3 20 GB, **single-AZ — D-14 / ADR 0007**. Multi-AZ is the availability we chose not
  to buy (~$28/month taxed); the recovery story is 7-day point-in-time recovery plus a
  35-day locked AWS Backup vault with a cross-region copy, RPO ≈ 1 hour and RTO ≈ 8
  business hours. The app connects with `sslmode=verify-full` and the RDS CA bundle baked
  into the image — **not** `sslmode=require`, which does not authenticate the server.
* **An EventBridge schedule that stops the staging instance nightly** (D-15). RDS restarts
  itself after seven days stopped, so the schedule is infrastructure, not a chore.
* **Three S3 buckets** — `artifacts`, `phi`, `audit` — each encrypted with a CMK from the
  set below, versioned, public-access-blocked, `BucketOwnerEnforced`, TLS-only and
  encryption-enforcing, with **GuardDuty Malware Protection on the `phi` bucket only**
  (it is billed per GB, which is why it is here and not account-wide) and **Object Lock in
  compliance mode** on `audit`.
* **Secrets Manager**: the origin-verify secret (Phase 1), the two application database
  credentials, and the PHI HMAC key.
* **AWS Backup**: a vault with its own CMK, **Vault Lock in compliance mode**, daily RDS
  and S3 backups, 35-day retention and a cross-region copy. Until that exists, the same
  credential that can delete the database can delete every recovery point.

**Why the keys are here** (Phase 1's reasoning, unchanged): staging's `edge`, `compute`,
`api` and `observability` stacks are destroyed between phases (ADR 0008 / D-15). Keys in
the data stack survive a teardown; keys in a torn-down stack would be *scheduled for
deletion*, and a scheduled key deletion is how encrypted backups quietly become unreadable.

**Why this stack depends on `vpc` and nothing else** (ADR 0020). An RDS instance needs
subnets and a security group. Before Phase 3 all of that lived in `meridian-<env>-network`,
which staging destroys every session — so depending on it would have made the database
transient, which D-15 forbids ("the `data` stack stays with RDS stopped"). The network was
therefore split: `meridian-<env>-vpc` holds the free, durable half and is never destroyed;
`meridian-<env>-edge` holds every hourly charge and is destroyed every session. This stack
imports from `vpc`. Nothing imports from this stack except `edge` and, from Phase 5a,
`compute` — both of which are consumers, so destroying either can never reach the data.

**A sixth CMK: `meridian-<env>-kms-tokens`** (ADR 0044). It wraps the data keys the
application seals QuickBooks OAuth tokens under before they reach `public.qbo_connection`
(`src/qbo_token_crypto.py`, revision 0023). It is here for the reason every key is here — a
sealed token outlives any compute teardown. **It exists in both environments regardless of
`worker_enabled`** (T:186): the api stores QuickBooks tokens on RDS whenever it runs here,
and `scripts/encrypt_qbo_tokens.py` must re-seal the legacy rows before cutover, which needs
the key and the api's grant without the always-on worker (≈ $15/month, a separate cost
approval). Deploy this stack BEFORE the first `compute` deploy that carries it (compute
imports the key's ARN). ≈ $1/month per environment plus requests (a few thousand a month,
well under $0.01).
"""

from __future__ import annotations

from typing import Any

from aws_cdk import ArnFormat, Aws, CfnOutput, Duration, Fn, RemovalPolicy, Tags
from aws_cdk import aws_backup as backup
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_ecr as ecr
from aws_cdk import aws_events as events
from aws_cdk import aws_guardduty as guardduty
from aws_cdk import aws_iam as iam
from aws_cdk import aws_kms as kms
from aws_cdk import aws_logs as logs
from aws_cdk import aws_rds as rds
from aws_cdk import aws_s3 as s3
from aws_cdk import aws_scheduler as scheduler
from aws_cdk import aws_secretsmanager as secretsmanager
from aws_cdk import aws_sns as sns
from aws_cdk import aws_sqs as sqs
from constructs import Construct

from ..config import ORIGIN_VERIFY_HEADER, EnvConfig
from ..log_groups import (
    logs_key_log_group_patterns,
    phi_key_log_group_patterns,
    rds_instance_identifier,
)
from ..naming import resource_name
from .base import EnvStack
from .vpc import SUBNET_DATA, VpcStack

#: The Object Lock default retention on the `audit` and `archive` buckets: **2555 days**.
#:
#: That is `7 * 365` and **not** seven calendar years — leap days are not counted, so the
#: lock expires one or two days short of the seventh anniversary (2557 days would cover
#: every seven-year span). It is deliberate and it matches `AUDIT_RETENTION_DAYS` in
#: `stacks/foundation.py`, which is the same figure for the same reason: the requirement
#: behind it is 45 CFR 164.316(b)(2)(i)'s **six** years, and the seventh is already slack.
#: One or two days off the end of a year of slack changes nothing, and a round 2555 is the
#: number every compliance table in this repo and in `docs/compliance/` already quotes.
#:
#: **Compliance mode cannot be shortened, by anyone, including the root account.** So if
#: this ever needs to become 2557, it applies only to objects written after the change;
#: everything already locked keeps 2555. Keep `infra/tests/test_data.py` in step with it.
OBJECT_LOCK_RETENTION_DAYS = 365 * 7  # 2555

#: purpose -> (description, DataClassification)
#: Five keys per environment, matching plan §2.4's isolation table.
#:
#: **There is deliberately no sixth key for the `audit` bucket.** That bucket holds
#: exported `audit.phi_access` rows — who read what, when, how many rows — which ADR 0012
#: is explicit never contain PHI *values*. That is the same class of content as the log
#: groups, so it uses the same `logs` CMK. A sixth key would be $1/month for a boundary
#: that the Object Lock and the bucket policy already draw, between two kinds of record
#: that are read by the same people for the same reason. ADR 0020 §6.
CMK_PURPOSES: dict[str, tuple[str, str]] = {
    "rds": (
        "RDS storage, snapshots, Performance Insights and the RDS-managed master secret",
        "phi",
    ),
    "artifacts": ("The artifacts S3 bucket: exports, journal-entry CSVs, PDFs", "internal"),
    "phi": (
        "The phi S3 bucket, the phi schema's exports and the two RDS log groups",
        "phi",
    ),
    "logs": (
        "CloudWatch log groups (except the PHI-bearing RDS pair), VPC flow logs, "
        "ALB access logs and the audit bucket",
        "internal",
    ),
    "backups": ("The AWS Backup vault and its cross-region copies", "phi"),
}

#: ADR 0044: `meridian-<env>-kms-tokens`, in both environments (T:186).
TOKEN_KEY_PURPOSE = "tokens"  # noqa: S105 a key name segment, not a secret
TOKEN_KEY_DESCRIPTION = (
    "Wraps the data keys QuickBooks OAuth tokens are sealed under in qbo_connection (ADR 0044)"  # noqa: S105 a description, not a secret
)

#: `src/qbo_token_crypto.KMS_KEY_ENV`: the api's variable naming the key (a test reads that
#: file rather than retyping it). The worker copies it (`stacks/worker.py`).
QBO_TOKEN_KMS_KEY_ENV = "QBO_TOKEN_KMS_KEY_ARN"  # noqa: S105 a variable name, not a secret

#: `src/qbo_token_crypto.PURPOSE`: the KMS encryption context every seal and open carries.
#: Every grant on the key is conditioned on it, so a role can use it for nothing else.
QBO_TOKEN_KMS_PURPOSE = "qbo-token"  # noqa: S105 an encryption-context value, not a secret

#: Exactly the two calls `src/qbo_token_crypto.KmsKeyWrapper` makes. Not `kms:Encrypt`:
#: the data key comes from `GenerateDataKey`, and nothing is encrypted by KMS directly.
QBO_TOKEN_KMS_ACTIONS = ("kms:GenerateDataKey", "kms:Decrypt")

#: The PostgreSQL **major** version the whole estate runs, and deliberately only the
#: major. Supabase is on 17.6 today (plan §1) and the Alembic baseline was dumped with a
#: ≥ 17.6 client, so anything older than 17 cannot load it — which is exactly why the
#: assistant app's existing RDS instance (PostgreSQL 16.13) was never a candidate.
#:
#: **L-1.** `auto_minor_version_upgrade=True` below and a pinned *minor* (`VER_17_6`)
#: contradict each other: RDS applies a minor upgrade in the maintenance window, the
#: template still says 17.6, and the next `cdk deploy` either drifts silently or tries to
#: push the instance back down. `PostgresEngineVersion.of("17", "17")` renders
#: `EngineVersion: "17"`, which RDS reads as "any 17.x" — so the security fixes land on
#: AWS's schedule and the template never disagrees with the instance. The major is still
#: pinned, and `allow_major_version_upgrade=False` keeps 18 a migration rather than a
#: Sunday morning.
POSTGRES_VERSION = rds.PostgresEngineVersion.of("17", "17")

#: gp3 20 GB. The live database is ~250 MB of rows plus indexes; 20 GB is the RDS
#: minimum for gp3 and leaves room for the `phi` split and a few years of growth.
#: `max_allocated_storage` lets RDS grow it by itself rather than at 3am.
STORAGE_GB = 20
MAX_STORAGE_GB = 100

#: Automated backups, in days. Point-in-time recovery restores to any **5-minute** mark
#: inside this window, so the real RPO is ~5 minutes against ADR 0007's 1-hour target.
#: Seven days is the RDS default and the plan's figure; the 35-day story is AWS Backup.
BACKUP_RETENTION_DAYS = 7

#: AWS Backup retention, and the Vault Lock bounds around it. The lock refuses any
#: recovery point whose retention falls outside [min, max], which is what stops a
#: mis-typed plan from quietly shortening the DR window.
VAULT_RETENTION_DAYS = 35
VAULT_MIN_RETENTION_DAYS = 35
VAULT_MAX_RETENTION_DAYS = 400

#: **Vault Lock's cooling-off period.** For three days after the lock is applied it can
#: still be removed; after that it is immutable for the life of the vault, including by
#: the account root user and by AWS Support. Three days is AWS's minimum and the right
#: value: long enough to catch a wrong retention figure on the next working day, short
#: enough that the guarantee is real within the week.
VAULT_CHANGEABLE_FOR_DAYS = 3

#: The default region the cross-region copy goes to. `us-west-2` is the conventional
#: second region for a `us-east-1` estate: far enough for the correlated-failure
#: argument, cheap, and in-scope for the AWS BAA. Overridable with `-c drRegion=...`.
DEFAULT_DR_REGION = "us-west-2"

#: 400 days, the same figure every other audit log group in the estate uses.
LOG_RETENTION = logs.RetentionDays.THIRTEEN_MONTHS

#: The RDS log types exported to CloudWatch. `postgresql` is the server log — which,
#: with the parameter group below, carries pgaudit's `ddl,role,write` trail, every
#: connection and every disconnection. `upgrade` is written once per version upgrade and
#: is the only record of what a major-version upgrade did.
LOG_EXPORTS = ("postgresql", "upgrade")

#: The master user. **`meridian_migrator`, not `postgres`** — it is the role Alembic
#: runs as (migrations/versions/0003_rds_adaptations.py), it owns the schema, and it is
#: `NOBYPASSRLS`, which is what makes the Phase 3 step 11 load window real: at revision
#: 0004 `FORCE ROW LEVEL SECURITY` applies to the owner too, so `COPY ... FROM` is
#: refused and the data load has to happen between 0003 and 0004.
MASTER_USERNAME = "meridian_migrator"

#: Characters excluded from every generated password here.
#:
#: **This is a correctness requirement, not tidiness.** `MERIDIAN_DATABASE_URL` is a URL,
#: and a password containing `/`, `@`, `:`, `?`, `#`, `%`, `&`, `=` or a quote either
#: terminates a URL component early or has to be percent-encoded by every consumer that
#: ever builds one. Meridian has several (psycopg2, Alembic, `psql` in a runbook, the
#: task definition's `secretsmanager` dynamic reference), and one that forgets is an
#: authentication failure that looks like a wrong password. Excluding the characters
#: costs about four bits of entropy out of ~380.
URL_UNSAFE_CHARACTERS = " \"'\\/@:?#%&=[]{}<>|`^~,;"

#: `statement_timeout`, in milliseconds. **300 000 = 5 minutes, and the value is a
#: judgement call worth stating.**
#:
#: The obvious value is 60 seconds, which is right for a web request and wrong for this
#: application. Meridian's real work is batch: a period's revenue run enriches ~76 000
#: transactions, a payroll booking joins several ADP exports, and the parity suite in
#: Phase 3 step 11 counts every row of 57 tables. Those are single statements that
#: legitimately run for minutes, and a 60-second timeout would fail them at random
#: depending on load — the worst kind of failure, because it looks like a data bug.
#:
#: Five minutes is long enough for every statement the application actually issues and
#: short enough that a runaway query cannot hold a connection for the rest of the day.
#: **It is a backstop, not a budget:** anything approaching it is a bug, and
#: `pg_stat_statements` (preloaded below) is how it gets found.
STATEMENT_TIMEOUT_MS = 300_000

#: `idle_in_transaction_session_timeout`, in milliseconds. One minute, and deliberately
#: twenty times stricter than the statement timeout: an idle *transaction* is not work,
#: it is a connection holding locks and pinning the vacuum horizon because something
#: forgot to commit. Killing it after a minute turns a slow, spreading outage into one
#: failed request.
IDLE_IN_TRANSACTION_TIMEOUT_MS = 60_000

#: When the staging instance is stopped, in the timezone the business actually works in.
#: 02:00 America/Chicago is after any evening session and before any morning one.
STAGING_STOP_CRON = "cron(0 2 * * ? *)"
STAGING_STOP_TIMEZONE = "America/Chicago"

#: How long the stop-schedule dead-letter queue keeps a failed invocation.
#:
#: EventBridge Scheduler sends an invocation it could not deliver to the DLQ, and on most
#: nights there is exactly one: the instance is already stopped and `StopDBInstance`
#: answers `InvalidDBInstanceState`. That is expected, not a fault, and at the queue it is
#: indistinguishable from a real one.
#:
#: **There is no longer an alarm on the queue's depth, and that is a withdrawal** (critic,
#: data tier, medium b). The arithmetic it rested on — one day of retention makes the
#: steady state one message, so "more than one" is a second failure — cannot actually
#: detect a real failure: a night on which the ONLY message is a genuine error
#: (`AccessDenied`, a renamed instance, a throttle) has depth 1, exactly like every
#: expected night, and never fires. An alarm that cannot go off for the case it exists to
#: catch is worse than no alarm, because it is read as coverage.
#:
#: What replaces it is a READ of the error code, not a threshold on the depth. Phase 6
#: (ADR 0024 §5) built it: an **unfiltered** EventBridge Pipe puts every dead letter on
#: `meridian-<env>-events-alerts`, and two rules split it — unexpected pages the alerts
#: topic and is logged, expected is logged only, both to
#: `meridian-<env>-logs-stop-schedule`, which `scripts/staging_session.sh up` reads. The
#: Pipe is unfiltered deliberately: a **Pipes source filter discards** what it does not
#: match, which would have consumed the expected message — the one piece of evidence that
#: the schedule ran at all — before anybody could read it. ADR 0020 §7c has the reasoning
#: and a dated note about the shape that was proposed there and not shipped.
STOP_DLQ_RETENTION = Duration.days(1)

#: The message attribute EventBridge Scheduler puts on a dead-lettered invocation, and the
#: one value that is expected rather than wrong. The two EventBridge rules in
#: `observability.py` match on both, and `staging_session.sh up` reads the expected one out
#: of the log group.
STOP_DLQ_ERROR_ATTRIBUTE = "ERROR_CODE"
STOP_DLQ_EXPECTED_ERROR = "InvalidDBInstanceState"

#: How long raw uploads are kept: 7 years (2,557 days), decided by Andres 2026-09-28 so
#: any past JE can be re-proved from its source file (ADR 0020 §5b).
RAW_UPLOAD_RETENTION_DAYS = 2557

#: The object tag that marks a raw upload for the raw-upload lifecycle rule.
#:
#: **A prefix filter cannot express this.** `src/storage.py` writes
#: `{org_id}/{batch_id}/{subfolder}/{filename}`, so raw uploads live at
#: `<org>/<batch>/uploads/<file>` — `uploads/` is in the *middle* of the key, and S3
#: lifecycle prefixes match from the start with no wildcards. A tag filter is the only
#: filter that can select them, so the rule is written against a tag and
#: `S3StorageManager` must set it on every put under `uploads/`. That is a Phase 5a code
#: change (plan §3 Phase 3 step 10); until it lands **the rule matches nothing**, which
#: is recorded here and in ADR 0020 §7 rather than left to be discovered as a bill.
RAW_UPLOAD_TAG = ("meridian:content", "raw-upload")

#: The object GuardDuty Malware Protection writes to prove it can write to the bucket.
#:
#: The key is AWS\'s, not ours, and it is fixed
#: (`docs.aws.amazon.com/guardduty/latest/ug/malware-protection-s3-iam-policy-prerequisite.html`
#: — the `AllowPutValidationObject` statement names it literally). It appears twice here:
#: the scan role is allowed `s3:PutObject` on exactly this key, and the phi bucket\'s two
#: SSE-KMS denies exclude it, because GuardDuty sends the put with no encryption headers
#: and the deny would otherwise fail the plan at enable time. See `_deny_wrong_encryption`.
MALWARE_VALIDATION_OBJECT_KEY = "malware-protection-resource-validation-object"

#: The two images `compute` runs. Their ECR repositories live here, not in `compute`.
REPOSITORY_PURPOSES = ("api", "web")

#: Images kept per repository. Ten is roughly two weeks of deploys; anything
#: older is reachable from the git history and a rebuild.
IMAGES_KEPT = 10


def mart_secret_arn(env: str, which: str) -> str:
    """The ARN of the `owner` or `reader` mart login, read from the data stack's named export.

    The data stack ALWAYS exports these (`DatabaseMart<Owner|Reader>SecretArn`, in `_outputs`),
    flag or no flag, so compute imports by name instead of passing the secret object: a
    cross-stack object reference makes CDK add its own auto-export to the data stack only when
    `-c ecwMart=true`, and a later data deploy without it would try to delete an export compute
    uses, which CloudFormation refuses.
    """
    return Fn.import_value(f"meridian-{env}-data-DatabaseMart{which.capitalize()}SecretArn")


class DataStack(EnvStack):
    """Per-environment CMKs and secrets (Phase 1), then RDS, S3 and AWS Backup (Phase 3)."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_config: EnvConfig,
        vpc_stack: VpcStack,
        **kwargs: Any,
    ) -> None:
        super().__init__(scope, construct_id, env_config=env_config, **kwargs)

        self.vpc = vpc_stack.vpc
        self.data_sg = vpc_stack.data_sg

        self.keys: dict[str, kms.Key] = {}
        for purpose, (description, classification) in CMK_PURPOSES.items():
            self.keys[purpose] = self._cmk(purpose, description, classification)
        #: ADR 0044: the QuickBooks token key, in both environments (see the module).
        #: Not in `self.keys`: nothing that loops over the bucket/log/backup keys may use it.
        self.token_key: kms.Key = self._cmk(TOKEN_KEY_PURPOSE, TOKEN_KEY_DESCRIPTION, "internal")
        self._allow_cloudwatch_logs_to_use_the_logs_key()
        self._allow_cloudwatch_alarms_to_publish_to_the_alerts_topic()
        self._service_key_grants()

        self.origin_verify = self._origin_verify_secret()

        # Secrets before the database: the two application credentials are independent of
        # RDS (the roles they carry are created by Alembic, not by CloudFormation), and
        # the master credential is RDS's own — see `_database`.
        self.db_app_secret = self._db_credential_secret("app", "meridian_app")
        self.db_phi_secret = self._db_credential_secret("phi", "phi_access")
        # Alembic 0048 creates these two roles (the nightly eCW mart copy, ADR 0053): the
        # owner is the loader's login, the reader is the api's.
        self.db_mart_owner_secret = self._db_credential_secret("mart-owner", "meridian_mart_owner")
        self.db_mart_reader_secret = self._db_credential_secret(
            "mart-reader", "meridian_mart_reader"
        )
        self.phi_hmac_key = self._phi_hmac_secret()
        self.flask_secret_key = self._flask_secret_key()

        self.database = self._database()
        self._staging_stop_schedule()
        # After the topic exists: it is created inside `_staging_stop_schedule`, above the
        # staging-only guard.
        self._alerts_topic_policy()

        self.buckets = self._buckets()
        self.repositories = self._repositories()
        self._malware_protection()

        self.backup_vault, self.backup_plan = self._backups()

        self._outputs()

    # ---------------------------------------------------------------------- keys

    def _cmk(self, purpose: str, description: str, classification: str) -> kms.Key:
        """One environment-scoped CMK with annual rotation.

        The key policy names **this environment's** roles and nothing else. The
        roles do not exist yet (compute lands in Phase 5a), so the grant is by
        ARN pattern — `role/meridian-<env>-*` — which is the same boundary the
        IAM policies use (`aws:ResourceTag/Environment`) expressed on the key
        side. The effect is what §2.4 requires: **nothing in staging can decrypt
        a production ARN**, and a future account split changes nothing here
        because no account id is written down.
        """
        name = resource_name(self.env_name, "kms", purpose)
        key = kms.Key(
            self,
            f"Key{purpose.capitalize()}",
            alias=f"alias/{name}",
            description=f"{description} ({self.env_name}).",
            enable_key_rotation=True,  # automatic annual rotation — Phase 1 step 6
            # The data stack is never destroyed, not even for a staging teardown
            # (ADR 0008): RETAIN makes that structural rather than a promise.
            removal_policy=RemovalPolicy.RETAIN,
        )
        key.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowThisEnvironmentsRoles",
                principals=[iam.AccountRootPrincipal()],
                actions=[
                    "kms:Encrypt",
                    "kms:Decrypt",
                    "kms:ReEncrypt*",
                    "kms:GenerateDataKey*",
                    "kms:DescribeKey",
                ],
                resources=["*"],
                conditions={
                    "ArnLike": {
                        "aws:PrincipalArn": (
                            f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:role/"
                            f"meridian-{self.env_name}-*"
                        )
                    }
                },
            )
        )
        # **`kms:CreateGrant`, separately and narrowly.** RDS, AWS Backup and Secrets
        # Manager do not call KMS with the caller's credentials — they ask KMS for a
        # *grant* and then use it on the caller's behalf, which is how an encrypted
        # snapshot copy or a managed master password works at all. Without this, a
        # backup job fails with an access-denied that names the key and not the grant.
        #
        # It is its own statement rather than another action on the one above because of
        # the `GrantIsForAWSResource` condition: a grant may only be created **for an AWS
        # service acting on the principal's behalf**, never for an arbitrary principal.
        # Folding it in would have applied that condition to `Encrypt` and `Decrypt` too,
        # which would silently break every ordinary use of the key.
        key.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowAwsServiceGrantsForThisEnvironmentsRoles",
                principals=[iam.AccountRootPrincipal()],
                actions=["kms:CreateGrant", "kms:ListGrants", "kms:RevokeGrant"],
                resources=["*"],
                conditions={
                    "ArnLike": {
                        "aws:PrincipalArn": (
                            f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:role/"
                            f"meridian-{self.env_name}-*"
                        )
                    },
                    "Bool": {"kms:GrantIsForAWSResource": "true"},
                },
            )
        )
        Tags.of(key).add("DataClassification", classification)
        return key

    def _allow_cloudwatch_logs_to_use_the_logs_key(self) -> None:
        """Let CloudWatch Logs encrypt log groups with the `logs` **and `phi`** CMKs.

        CloudWatch Logs refuses to encrypt a group with a key whose policy does not name
        `logs.<region>.amazonaws.com` — and the failure is a group that will not create,
        with an error that does not say why.

        **The statement moved here from the edge stack in Phase 3**, and the move is the
        point. It was added by `NetworkStack._flow_logs`, which was fine while the flow
        log was the only CMK-encrypted group in the environment. The RDS log groups below
        are the second, and they exist while `edge` is destroyed — so the grant has to
        live with the key, in the stack that never goes away.

        **The `phi` key is named here too, and that is M-4.** `pgaudit.log` includes
        `write`, and Meridian interpolates literals client-side, so the statement text in
        `/aws/rds/instance/<id>/postgresql` contains PHI values. A log group holding PHI
        is encrypted with the PHI key, not the `internal` one — see `_log_groups`.

        **The `EncryptionContext` condition names this environment's log groups, not
        `log-group:*`** (Codex CX-INF-04). With the wildcard, anyone able to call
        `logs:AssociateKmsKey` on an unrelated group in this shared account could bind it
        to the production PHI key. The patterns are `meridian/log_groups.py`'s, per key:
        the `phi` key admits only the two RDS exports, and the `logs` key admits the
        names this environment creates. `infra/tests/test_data.py` walks every log group
        in every synthesized stack and fails on one whose name its key does not admit —
        CloudWatch Logs would refuse to create it.
        """
        patterns = {
            "logs": logs_key_log_group_patterns(self.env_name),
            "phi": phi_key_log_group_patterns(self.env_name),
        }
        for purpose in ("logs", "phi"):
            self.keys[purpose].add_to_resource_policy(
                iam.PolicyStatement(
                    sid="AllowCloudWatchLogsToUseThisKey",
                    principals=[iam.ServicePrincipal(f"logs.{Aws.REGION}.amazonaws.com")],
                    actions=[
                        "kms:Encrypt",
                        "kms:Decrypt",
                        "kms:ReEncrypt*",
                        "kms:GenerateDataKey*",
                        "kms:DescribeKey",
                    ],
                    resources=["*"],
                    conditions={
                        "ArnLike": {
                            "kms:EncryptionContext:aws:logs:arn": [
                                f"arn:{Aws.PARTITION}:logs:{Aws.REGION}:"
                                f"{Aws.ACCOUNT_ID}:log-group:{pattern}"
                                for pattern in patterns[purpose]
                            ]
                        }
                    },
                )
            )

    def _allow_cloudwatch_alarms_to_publish_to_the_alerts_topic(self) -> None:
        """Let CloudWatch publish an alarm notification to an SNS topic on the `logs` CMK.

        **Critic finding (data tier, medium a).** `AlertsTopic` is encrypted with the
        `logs` CMK, and CloudWatch publishes an alarm notification as the
        `cloudwatch.amazonaws.com` service principal — not as a role of ours, so the
        `ArnLike aws:PrincipalArn meridian-<env>-*` statement in `_cmk` never reaches it.
        Without `kms:GenerateDataKey*` and `kms:Decrypt` the publish fails with
        `KMS.AccessDeniedException` **inside SNS**, which surfaces as a
        `NumberOfNotificationsFailed` datapoint and nothing else: the alarm goes into
        ALARM, nobody is told, and the console shows a healthy alarm with an action.

        **Neither statement carries a condition, and that is the corrected form** (critic
        P6R2-01; both used to carry `aws:SourceAccount`). AWS's own key-management guide
        for encrypted topics says so in as many words:

        > Adding the `aws:SourceAccount`, `aws:SourceArn`, and `aws:SourceOrgID` to a AWS
        > KMS policy is not supported for EventBridge-to-encrypted topics.
        > — https://docs.aws.amazon.com/sns/latest/dg/sns-key-management.html
        >   ("Enable compatibility between event sources from AWS services and encrypted
        >   topics")

        A condition that the evaluating service never populates does not narrow the grant,
        it **denies** it: every rule-sourced publish fails inside SNS with
        `KMS.AccessDeniedException` while the rule shows as matched and invoked. For
        CloudWatch the same page offers no service-specific sanction either — CloudWatch
        is not in its list of event sources with documented confused-deputy details, and
        the documented key policy for an alarm publishing to an encrypted topic is the
        bare `Allow_CloudWatch_for_CMK` statement with **no** `Condition` at all
        (https://repost.aws/knowledge-center/cloudwatch-configure-alarm-sns). So the
        condition comes off there too rather than being left in on the strength of a
        guess, because the failure mode is silence at 3am.

        **The confused-deputy guard moves to where it is actually evaluated**: the TOPIC
        policy in `_alerts_topic_policy` keeps `aws:SourceAccount` on `sns:Publish` for
        both service principals, and SNS does evaluate that. A foreign account's alarm or
        rule is refused there; this key policy only says "CloudWatch and EventBridge may
        use this key", which is the shape AWS documents.

        It is installed even though the stop-schedule alarm was withdrawn (§7c): the
        topic's whole purpose is to carry alarms, Phase 6 is what attaches them, and a
        missing grant is the kind of thing that is found the first time an alarm matters.
        """
        self.keys["logs"].add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowCloudWatchAlarmsToPublishToAnEncryptedTopic",
                principals=[iam.ServicePrincipal("cloudwatch.amazonaws.com")],
                actions=["kms:Decrypt", "kms:GenerateDataKey*"],
                resources=["*"],
                # No Condition: see the docstring. The guard is on the topic policy.
            )
        )
        # **EventBridge needs the identical grant, and for the identical reason** (critic
        # P6-06). Half of Phase 6's notifications do not come from an alarm at all: the
        # backup, copy-job, rotation, finding and stop-schedule notifications are
        # EventBridge *rules* whose target is this topic, and a rule publishes as
        # `events.amazonaws.com`, not as CloudWatch and not as a role of ours. Without
        # this the rule's publish fails inside SNS exactly as an alarm's would — the rule
        # shows as matched and invoked, and nobody is told.
        #
        # And it must be **unconditioned**, which is the round-2 correction: AWS states
        # that `aws:SourceAccount`/`aws:SourceArn`/`aws:SourceOrgID` on a KMS policy are
        # not supported for EventBridge-to-encrypted-topics, so the condition this used to
        # carry turned the grant into a deny for every rule-sourced publish.
        # https://docs.aws.amazon.com/sns/latest/dg/sns-key-management.html
        self.keys["logs"].add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowEventBridgeRulesToPublishToAnEncryptedTopic",
                principals=[iam.ServicePrincipal("events.amazonaws.com")],
                actions=["kms:Decrypt", "kms:GenerateDataKey*"],
                resources=["*"],
            )
        )
        # `pipes.amazonaws.com` is deliberately absent. The stop-schedule Pipe reads the
        # KMS-encrypted DLQ under its own IAM role (which `observability.py` grants
        # `kms:Decrypt` on this key) and delivers to an **event bus**, not to this topic —
        # so Pipes never publishes to an encrypted SNS topic and needs nothing here.
        # ADR 0024 §5.

    def _alerts_topic_policy(self) -> None:
        """The alerts topic's resource policy, written here and nowhere else.

        **Any explicit `AWS::SNS::TopicPolicy` REPLACES the topic's default policy.** The
        default one is what lets everything in the owning account publish, so the moment
        one statement is added by a construct — `events_targets.SnsTopic` adds one — the
        default is gone and every principal not named in the new document is refused. That
        is a silent failure with a 3am symptom: the alarm goes to ALARM, the publish is
        denied inside SNS, and the console shows a healthy alarm with an action.

        So the policy is written out in full, here, in the stack that owns the topic:

        1. the owner statement, which is what the default policy was;
        2. `cloudwatch.amazonaws.com` — alarm actions;
        3. `events.amazonaws.com` — the rule targets in `observability.py`.

        Each service statement carries `aws:SourceAccount`, AWS's documented
        confused-deputy guard for a service principal: the account is shared (ADR 0001)
        and a topic ARN is derivable from the naming convention, so an unconditioned Allow
        for `events.amazonaws.com` lets a rule in **any** account publish into this
        mailbox. `observability.py` therefore uses a plain ARN rule target rather than
        `events_targets.SnsTopic`, which would append an unconditioned statement here and
        make the condition decorative.

        **This is the only policy of the two that may carry it.** The matching statements
        on the `logs` CMK are deliberately unconditioned, because AWS does not support
        `aws:SourceAccount` on a KMS policy for EventBridge-to-encrypted-topics and
        documents no conditioned form for CloudWatch either — see
        `_allow_cloudwatch_alarms_to_publish_to_the_alerts_topic` (critic P6R2-01). SNS
        evaluates `sns:Publish` here, so the guard is real here and only here.
        """
        service_actions = ["sns:Publish"]
        this_account_only = {"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}}

        self.alerts.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowThisAccountToOwnTheTopic",
                principals=[iam.AccountRootPrincipal()],
                actions=[
                    "sns:Publish",
                    "sns:Subscribe",
                    "sns:GetTopicAttributes",
                    "sns:SetTopicAttributes",
                    "sns:ListSubscriptionsByTopic",
                    "sns:AddPermission",
                    "sns:RemovePermission",
                    "sns:DeleteTopic",
                ],
                resources=[self.alerts.topic_arn],
            )
        )
        self.alerts.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowCloudWatchAlarmsFromThisAccount",
                principals=[iam.ServicePrincipal("cloudwatch.amazonaws.com")],
                actions=service_actions,
                resources=[self.alerts.topic_arn],
                conditions=this_account_only,
            )
        )
        self.alerts.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowEventBridgeRulesFromThisAccount",
                principals=[iam.ServicePrincipal("events.amazonaws.com")],
                actions=service_actions,
                resources=[self.alerts.topic_arn],
                conditions=this_account_only,
            )
        )

    def _service_key_grants(self) -> None:
        """The two service principals that touch a key without a role of ours in the path.

        * **Secrets Manager, on the `rds` key.** RDS encrypts the managed master-user
          secret with whatever key it is given, and it does so through Secrets Manager
          using the RDS service-linked role — not a `meridian-<env>-*` role, so the
          statement in `_cmk` does not reach it. `kms:ViaService` is what keeps the grant
          honest: it authorises a principal *in this account* calling *through Secrets
          Manager*, and nothing else.
        * **AWS Backup, on the `backups` key.** A copy job in the DR region is performed
          by the service, not by our backup role; the destination key has the mirror of
          this statement (`backup_dr.py`).
        """
        self.keys["rds"].add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowSecretsManagerToEncryptTheManagedMasterSecret",
                principals=[iam.AccountRootPrincipal()],
                actions=[
                    "kms:Encrypt",
                    "kms:Decrypt",
                    "kms:ReEncrypt*",
                    "kms:GenerateDataKey*",
                    "kms:DescribeKey",
                    "kms:CreateGrant",
                ],
                resources=["*"],
                conditions={
                    "StringEquals": {"kms:ViaService": f"secretsmanager.{Aws.REGION}.amazonaws.com"}
                },
            )
        )
        self.keys["backups"].add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowAwsBackupToUseThisKey",
                principals=[iam.ServicePrincipal("backup.amazonaws.com")],
                actions=[
                    "kms:Encrypt",
                    "kms:Decrypt",
                    "kms:ReEncrypt*",
                    "kms:GenerateDataKey*",
                    "kms:DescribeKey",
                    "kms:CreateGrant",
                ],
                resources=["*"],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )

    # ------------------------------------------------------------------- secrets

    def _origin_verify_secret(self) -> secretsmanager.Secret:
        """The shared secret CloudFront sends and the ALB demands.

        **It lives here, in the data stack, and not in the edge stack** — that is the
        whole point of the move. Staging's edge stack is destroyed at the end of every
        session (ADR 0008). A secret destroyed with it is not gone: Secrets Manager keeps
        a deleted secret, *and its name*, for a recovery window, so the next session's
        deploy failed with "a secret with this name is scheduled for deletion" unless the
        teardown force-deleted it first. That force-delete was a step in a script, which
        is to say a step that can be skipped, and it threw away the version history the
        rotation procedure depends on.

        In the data stack the secret simply survives, like the CMKs beside it, and the
        teardown has one fewer thing to remember. `RemovalPolicy.RETAIN` in both
        environments, not just production: the data stack is never destroyed, and this
        makes that structural rather than a promise.

        The value is generated by CloudFormation, so it exists in Secrets Manager and
        in two resource properties of the edge stack — and nowhere else. Nobody types it,
        and it is never in this repository.
        """
        secret = secretsmanager.Secret(
            self,
            "OriginVerifySecret",
            secret_name=resource_name(self.env_name, "secret", "origin-verify"),
            description=(
                "Shared secret proving a request came through CloudFront. Sent as the "
                f"{ORIGIN_VERIFY_HEADER} origin custom header; every ALB listener rule "
                "requires it."
            ),
            generate_secret_string=secretsmanager.SecretStringGenerator(
                password_length=64,
                # Header values: keep it to characters that survive HTTP framing and
                # a copy-paste into a curl command without quoting games.
                exclude_punctuation=True,
                exclude_characters=' "\'\\/@:',
                require_each_included_type=False,
            ),
            # A CMK of ours rather than `aws/secretsmanager` (critic, data tier, low).
            # It is not PHI, so the `phi` key would be the wrong boundary; it is not
            # public either, and the `logs` key is the environment's key for internal
            # material. What this buys is a key policy we control and a CloudTrail
            # `Decrypt` event naming a key we own, for every read of it.
            encryption_key=self.keys["logs"],
            removal_policy=RemovalPolicy.RETAIN,
        )
        # Not PHI and not public: it is the string that distinguishes our CloudFront
        # distribution from anyone else's.
        Tags.of(secret).add("DataClassification", "internal")
        return secret

    def _db_credential_secret(self, purpose: str, role: str) -> secretsmanager.Secret:
        """One application database credential — `meridian_app` or `phi_access`.

        **These two are not RDS credentials in the CloudFormation sense.** The roles are
        created by Alembic revision `0003_rds_adaptations`, which reads the passwords from
        `MERIDIAN_APP_DB_PASSWORD` and `MERIDIAN_PHI_DB_PASSWORD`; CloudFormation has no
        idea they exist. So what this creates is the *value*, generated once, in the right
        shape, under the right name — and the migration is what installs it in PostgreSQL.

        **Rotation is a Phase 5a runbook item, not a resource here, and that is a
        decision rather than an omission.** A Secrets Manager rotation Lambda has to reach
        both Secrets Manager and the database. The database is in an isolated subnet, so
        the Lambda has to be in the VPC; in the VPC it reaches Secrets Manager only
        through the NAT gateway, which lives in the transient `edge` stack (ADR 0020) or
        through an interface endpoint, which ADR 0009 declined to buy. A rotation that
        silently stops working whenever staging is torn down is worse than a rotation
        performed deliberately, so: `docs/runbooks/rotate-secrets.md`, quarterly, with the
        `ALTER ROLE ... PASSWORD` that a Lambda would have issued written out. Phase 5a
        can automate it from an ECS task, which is already in the VPC with egress.

        The JSON shape matches what a rotation Lambda would write, so automating it later
        changes the schedule and not the consumers.
        """
        secret = secretsmanager.Secret(
            self,
            "Db" + "".join(part.capitalize() for part in purpose.split("-")) + "Secret",
            secret_name=resource_name(self.env_name, "secret", f"db-{purpose}"),
            description=(
                f"PostgreSQL password for the {role} role ({self.env_name}). The role is "
                f"created by Alembic {'0048' if role.startswith('meridian_mart') else '0003'}; "
                "rotate with docs/runbooks/rotate-secrets.md."
            ),
            encryption_key=self.keys["rds"],
            generate_secret_string=secretsmanager.SecretStringGenerator(
                secret_string_template=f'{{"username": "{role}", "engine": "postgres"}}',
                generate_string_key="password",
                password_length=48,
                exclude_characters=URL_UNSAFE_CHARACTERS,
                require_each_included_type=True,
            ),
            removal_policy=RemovalPolicy.RETAIN,
        )
        # `phi_access` is the role that can read patient identifiers; its password is
        # the credential that guards them.
        # The two mart roles reach the eCW copy, which holds patient-level rows: PHI too.
        Tags.of(secret).add(
            "DataClassification",
            "phi" if purpose in ("phi", "mart-owner", "mart-reader") else "internal",
        )
        return secret

    def _phi_hmac_secret(self) -> secretsmanager.Secret:
        """The key behind `patient_ref` — and the one secret that must never be rotated.

        ADR 0012: `patient_ref = HMAC-SHA256(key, patient_id)`, stored on every row of
        `public.transactions` and used for duplicate detection. **The key is the link**
        between a tokenized row and `phi.transaction_identity`. Rotating it does not
        invalidate a session or a token; it silently makes every existing `patient_ref`
        stop matching the value a new computation produces, and duplicate detection —
        which is the only thing that reads it — starts returning nothing while continuing
        to look like it works.

        So there is **no rotation schedule on this secret**, and that is deliberate.
        Rotating it requires a re-keying plan: recompute `patient_ref` for all 76 132 rows
        from `phi.transaction_identity` inside one transaction, under the load window of
        `docs/runbooks/migrations.md`, with the old key retained until the new values are
        verified. `docs/runbooks/rotate-secrets.md` §4 carries that procedure and the
        standing instruction not to start it without it. ADR 0012 already names this a
        **backup-critical** secret: losing it is losing the join.

        64 characters from a 62-symbol alphabet is ≈ 380 bits of entropy, comfortably past
        HMAC-SHA256's 256-bit key. It is generated by CloudFormation and never typed.
        """
        secret = secretsmanager.Secret(
            self,
            "PhiHmacKey",
            secret_name=resource_name(self.env_name, "secret", "phi-hmac-key"),
            description=(
                "HMAC-SHA256 key for patient_ref (ADR 0012). NOT rotatable without the "
                "re-keying plan in docs/runbooks/rotate-secrets.md - rotating it breaks "
                "the link between public.transactions and phi.transaction_identity."
            ),
            encryption_key=self.keys["phi"],
            generate_secret_string=secretsmanager.SecretStringGenerator(
                password_length=64,
                exclude_punctuation=True,
                require_each_included_type=False,
            ),
            removal_policy=RemovalPolicy.RETAIN,
            # Replicated to the DR region (Codex G-H2): a region loss that keeps the
            # cross-region backup copy but loses this key loses the join between
            # `public.transactions` and `phi.transaction_identity` for good. The
            # replica is encrypted with the DR region's AWS-managed Secrets Manager
            # key — the phi CMK is regional and there is no CMK in `us-west-2` by
            # design (ADR 0007: no standing DR estate). ~$0.40/month.
            replica_regions=[secretsmanager.ReplicaRegion(region=self.dr_region)],
        )
        Tags.of(secret).add("DataClassification", "phi")
        return secret

    def _flask_secret_key(self) -> secretsmanager.Secret:
        """`FLASK_SECRET_KEY`, which `web_app.py` refuses to start without outside
        development (first staging compute deploy, 2026-10-05). It signs the Flask
        session cookie, so it lives here, persistent, not in `compute`: a new key on
        every staging `up` would sign everyone out. Rotating it signs everyone out
        once and is otherwise harmless."""
        return secretsmanager.Secret(
            self,
            "FlaskSecretKey",
            secret_name=resource_name(self.env_name, "secret", "flask-key"),
            description="FLASK_SECRET_KEY for the api task: signs the Flask session cookie.",
            encryption_key=self.keys["logs"],
            generate_secret_string=secretsmanager.SecretStringGenerator(
                password_length=64,
                exclude_punctuation=True,
                require_each_included_type=False,
            ),
            removal_policy=RemovalPolicy.RETAIN,
        )

    # ------------------------------------------------------------------ database

    def _parameter_group(self) -> rds.ParameterGroup:
        """The instance parameter group. Every value here is a control, not a preference.

        | Parameter | Value | Why |
        |---|---|---|
        | `rds.force_ssl` | `1` | The server refuses a non-TLS connection outright. Belt to the application's `sslmode=verify-full` braces: a client that forgets cannot connect at all. |
        | `shared_preload_libraries` | `pg_stat_statements,pgaudit` | `pgaudit` is the HIPAA audit trail (ADR 0012); `pg_stat_statements` is how a slow statement gets found. Both are **static** — they need a reboot, which is why they are set before the first data lands rather than after. |
        | `pgaudit.log` | `ddl,role,write` | Every schema change, every grant, every write, instance-wide. Reads are audited only on the one role that can perform them: `ALTER ROLE phi_access SET pgaudit.log='read,write'`, in Alembic 0003 — instance-wide read auditing on a batch workload is a log of everything and therefore a record of nothing. |
        | `log_connections` / `log_disconnections` | `1` | Who connected, from where, when. The other half of the audit story, and the only way to notice a credential being used from somewhere new. |
        | `statement_timeout` | 300 000 ms | See `STATEMENT_TIMEOUT_MS`. |
        | `idle_in_transaction_session_timeout` | 60 000 ms | See `IDLE_IN_TRANSACTION_TIMEOUT_MS`. |
        | `timezone` | `UTC` | The database stores instants, the fiscal calendar supplies the periods (`config/mappings.xlsx`), and a server-local timezone is how a period-boundary transaction lands in the wrong period. |

        `pgaudit.role` is not set: it is needed only for *object*-level auditing
        (`pgaudit.log='read'` against specific tables), which `phi_access` does with its
        own role-level setting.
        """
        return rds.ParameterGroup(
            self,
            "ParameterGroup",
            engine=rds.DatabaseInstanceEngine.postgres(version=POSTGRES_VERSION),
            description=f"Meridian {self.env_name}: TLS enforced, pgaudit on, timeouts set.",
            parameters={
                "rds.force_ssl": "1",
                "shared_preload_libraries": "pg_stat_statements,pgaudit",
                "pgaudit.log": "ddl,role,write",
                "log_connections": "1",
                "log_disconnections": "1",
                "statement_timeout": str(STATEMENT_TIMEOUT_MS),
                "idle_in_transaction_session_timeout": str(IDLE_IN_TRANSACTION_TIMEOUT_MS),
                "timezone": "UTC",
            },
        )

    def _log_groups(self, instance_identifier: str) -> list[logs.LogGroup]:
        """The RDS log groups, created **before** RDS so they carry our key and retention.

        RDS creates `/aws/rds/instance/<id>/<type>` by itself on first export, with AWS's
        defaults: never expire, no customer-managed key. CDK's `cloudwatch_logs_retention`
        prop does not fix that — it bolts on a custom-resource Lambda that calls
        `PutRetentionPolicy` afterwards, which sets retention and cannot set a key, and
        adds another Lambda with another implicit, unencrypted log group of its own (M-2).

        Declaring the groups here instead means RDS finds them already existing and writes
        into them: CMK-encrypted, 400 days, no extra Lambda. The database log carries the
        pgaudit trail and every connection, so "encrypted and retained as long as the rest
        of the audit record" is a control, not tidiness.

        **These two groups are `DataClassification=phi` and are encrypted with the `phi`
        key, not the `logs` key. M-4, and it is a correction rather than a nicety.**
        `pgaudit.log` is `ddl,role,write` instance-wide (`_parameter_group`), and pgaudit
        logs the **statement text**. Meridian's writers interpolate literals client-side
        rather than sending bound parameters, so an `INSERT` into a PHI table arrives in
        the postgresql log group with the patient account number in it. The group is
        therefore a PHI store: it takes the PHI key, it takes the PHI tag — which is also
        what puts it in the `phi` backup selection — and **reading it is a PHI access**,
        audited as one from Phase 6 (ADR 0012 §PHI-bearing logs, ADR 0020 §4).

        The alternative considered and rejected was dropping `write` from `pgaudit.log`.
        That trades the whole write trail — the thing the HIPAA control asks for — for a
        classification, and classifying the log correctly costs nothing.
        """
        groups = [
            logs.LogGroup(
                self,
                f"RdsLog{log_type.capitalize()}",
                log_group_name=f"/aws/rds/instance/{instance_identifier}/{log_type}",
                retention=LOG_RETENTION,
                # PHI, not `logs`: pgaudit `write` puts statement text here. See above.
                encryption_key=self.keys["phi"],
                # The data stack is never destroyed; RETAIN in both environments.
                removal_policy=RemovalPolicy.RETAIN,
            )
            for log_type in LOG_EXPORTS
        ]
        for group in groups:
            # The stack default is `internal`; this has to be set explicitly, after
            # construction, or the tag Aspect wins. It is also what puts the group in
            # the `phi` backup selection rather than the `internal` one.
            Tags.of(group).add("DataClassification", "phi")
        return groups

    def _database(self) -> rds.DatabaseInstance:
        """One single-AZ PostgreSQL 17 instance in the isolated `private-data` subnets.

        **Single-AZ is D-14 / ADR 0007**, not an oversight: Multi-AZ is ~$28/month for
        failover in minutes rather than hours, against a stated RTO of 8 business hours.
        The recovery story is the 7-day PITR window plus the locked backup vault below.

        **`publicly_accessible=False` and an isolated subnet group** are two separate
        controls saying the same thing. The subnets have no route to anything — not even
        the NAT — so even a mis-set flag would not produce a reachable database.

        **The master credential is RDS-managed** (`manage_master_user_password=True`), and
        that is a deviation from the Phase 3 brief worth stating plainly. The brief asked
        for a secret named `meridian-<env>-secret-db-master` with a 30-day rotation. A
        rotation schedule on a secret we own means a Secrets Manager rotation Lambda,
        which has to sit in the VPC to reach the database and therefore needs the NAT
        gateway — which lives in the transient `edge` stack and is absent for most of a
        staging month (ADR 0020). RDS-managed rotation has no Lambda, no VPC egress and no
        dependency on `edge`: RDS rotates the password internally, on its own schedule,
        encrypted with the `rds` CMK, and works while the rest of the environment is torn
        down. The cost is the name — RDS chooses it (`rds!db-...`) — so the ARN is a stack
        output instead. A managed rotation that always works beats a named one that works
        only during a session.

        **Performance Insights is on, and the earlier note saying it could not be was
        wrong (H-3).** The "not supported on burstable classes" rule is a *MySQL and
        MariaDB* rule; for PostgreSQL, `db.t4g.micro` and `db.t4g.small` are both in
        `aws rds describe-orderable-db-instance-options --engine postgres
        --engine-version 17 --query 'OrderableDBInstanceOptions[?
        SupportsPerformanceInsights==`true`].DBInstanceClass'`. The free tier is 7 days
        of retention and the default number of metrics, so this costs **$0/month** and is
        the only way to see which statement is holding the single `t4g` vCPU during a
        revenue run. `pg_stat_statements` still answers the cumulative question; PI
        answers "what is happening right now", which is the one asked during an incident.

        The dashboard is a PHI-adjacent surface — it shows SQL text — so it is encrypted
        with the `rds` CMK rather than the AWS-managed key, for the same §2.4 reason the
        master secret is.
        """
        instance_identifier = rds_instance_identifier(self.env_name)
        log_groups = self._log_groups(instance_identifier)

        subnet_group = rds.SubnetGroup(
            self,
            "SubnetGroup",
            vpc=self.vpc,
            subnet_group_name=resource_name(self.env_name, "rds", "subnets"),
            description="Isolated private-data subnets. No route to the internet, by design.",
            vpc_subnets=ec2.SubnetSelection(subnet_group_name=SUBNET_DATA),
            removal_policy=RemovalPolicy.RETAIN,
        )

        instance = rds.DatabaseInstance(
            self,
            "Database",
            instance_identifier=instance_identifier,
            engine=rds.DatabaseInstanceEngine.postgres(version=POSTGRES_VERSION),
            instance_type=ec2.InstanceType(self.env_config.db_instance_type),
            vpc=self.vpc,
            subnet_group=subnet_group,
            security_groups=[self.data_sg],
            # D-14 / ADR 0007. The single most expensive line we chose not to buy.
            multi_az=False,
            publicly_accessible=False,
            allocated_storage=STORAGE_GB,
            max_allocated_storage=MAX_STORAGE_GB,
            storage_type=rds.StorageType.GP3,
            storage_encrypted=True,
            storage_encryption_key=self.keys["rds"],
            # RDS owns and rotates the master password. See the docstring.
            credentials=rds.Credentials.from_username(MASTER_USERNAME),
            manage_master_user_password=True,
            parameter_group=self._parameter_group(),
            # 7 days of automated backups with point-in-time recovery to any 5-minute
            # mark (plan §6). The 35-day story is AWS Backup, below.
            backup_retention=Duration.days(BACKUP_RETENTION_DAYS),
            # A snapshot that does not carry Environment and DataClassification is a
            # snapshot the backup selection below cannot see and the budgets cannot
            # attribute. Copying the tags is what makes both true of restores as well.
            copy_tags_to_snapshot=True,
            delete_automated_backups=False,
            # Production refuses to be deleted at all; staging is torn down and rebuilt
            # deliberately (the plan's roll-back for Phase 3 is `cdk destroy` of it).
            deletion_protection=not self.env_config.destroyed_between_phases,
            removal_policy=RemovalPolicy.RETAIN,
            # H-3: supported on t4g for PostgreSQL; 7 days is the free tier.
            enable_performance_insights=self.env_config.performance_insights,
            performance_insight_encryption_key=(
                self.keys["rds"] if self.env_config.performance_insights else None
            ),
            performance_insight_retention=(
                rds.PerformanceInsightRetention.DEFAULT
                if self.env_config.performance_insights
                else None
            ),
            cloudwatch_logs_exports=list(LOG_EXPORTS),
            # Minor versions carry the security fixes and `POSTGRES_VERSION` pins only
            # the major (L-1), so the template never disagrees with the instance.
            auto_minor_version_upgrade=True,
            allow_major_version_upgrade=False,
            # Sunday 04:00-04:30 UTC, backups 03:00-04:00 UTC: outside any US business
            # day, and the backup finishes before maintenance starts.
            preferred_backup_window="03:00-04:00",
            preferred_maintenance_window="Sun:04:30-Sun:05:30",
        )
        # **The one escape hatch in this stack, and it is worth the line.** The L2 has no
        # prop for the managed master secret's encryption key, so without this RDS
        # encrypts it with the AWS-managed `aws/secretsmanager` key — a key whose policy
        # is AWS's and which draws no boundary between staging and production. The `rds`
        # CMK's policy names only `meridian-<env>-*`, which is the §2.4 isolation the
        # whole key set exists for, and it would be odd for the database's own credential
        # to be the one thing outside it.
        cfn_instance = instance.node.default_child
        if not isinstance(cfn_instance, rds.CfnDBInstance):
            raise AssertionError('isinstance(cfn_instance, rds.CfnDBInstance)')
        cfn_instance.master_user_secret = rds.CfnDBInstance.MasterUserSecretProperty(
            kms_key_id=self.keys["rds"].key_arn
        )

        # The groups must exist before RDS exports into them, or RDS makes its own with
        # never-expire retention and no key, and ours then collide on the next deploy.
        for group in log_groups:
            instance.node.add_dependency(group)

        Tags.of(instance).add("DataClassification", "phi")
        return instance

    def _staging_stop_schedule(self) -> None:
        """Stop the staging instance nightly at 02:00 America/Chicago. **D-15.**

        **This is infrastructure, not a chore, for a specific reason:** RDS restarts a
        stopped instance by itself after seven days. A one-off `stop-db-instance` at the
        end of a session therefore lasts a week and then quietly starts billing ~$12/month
        of `t4g.micro` hours for a database nobody is using. A nightly schedule re-stops
        it the same night, for ever, with nothing to remember.

        **Stopping is scheduled; starting is not.** `scripts/staging_session.sh up` starts
        the instance as part of bringing a session up, which is the only moment anyone
        wants it running. An automated start would be a schedule that costs money on
        every day nobody works.

        Production has no schedule. Stopping the production database is a decision, not a
        cron line.

        EventBridge Scheduler's **universal target** (`aws-sdk:rds:stopDBInstance`) calls
        the API directly — no Lambda, no code, nothing to patch, and the IAM role below
        can do exactly one thing to exactly one instance.

        **The input key is `DbInstanceIdentifier` (lower-case b), not the RDS API
        reference's `DBInstanceIdentifier`.** Scheduler validates the input against the
        SDK's member names when the schedule is created, and the first staging deploy
        (2026-10-03) was refused with "Request payload is missing the following field(s):
        DbInstanceIdentifier" while the input said `DBInstanceIdentifier`. An earlier
        review (M-1) had argued the opposite from the docs; the service is the authority.
        A wrong key fails at create time, so this can no longer be silently wrong; the
        dead-letter queue below still catches failures at invocation time.

        **Reading the queue is a step in `scripts/staging_session.sh up`, not an alarm.**
        See `STOP_DLQ_RETENTION` and ADR 0020 §7c for why the depth alarm was withdrawn.
        """
        self.stop_schedule: scheduler.CfnSchedule | None = None
        self.stop_dlq: sqs.Queue | None = None

        # A per-environment topic rather than an import of `meridian-shared-foundation`'s
        # security-alerts topic. Importing it would make this stack — the one that is
        # never destroyed — depend on a shared stack that is deployed on a different
        # cadence, for one alarm. **Phase 6 owns the alerting story** and should decide
        # whether the environment topics fan into the shared one or replace it.
        #
        # **Phase 6 (2026-09-16) moved it above the staging-only guard below.** It used to
        # be created only when `destroyed_between_phases` is true — that is, in staging
        # and nowhere else — because the only thing that was going to publish to it was
        # the stop-schedule DLQ alarm, and the stop schedule is a staging cost control.
        # `meridian-<env>-observability` attaches **27 alarms in staging and 26 in
        # production** to this topic (28 and 27 with `-c enableCanary=true`; staging has
        # the extra stop-DLQ age alarm, production the three account-scoped finding rules),
        # so a production-only outage had no topic to page. It stays
        # here, in the stack that is never destroyed (ADR 0020), so that the subscription
        # Andres confirms by email survives every staging teardown: an SNS subscription
        # is confirmed once, by a human, and re-creating the topic would silently
        # un-confirm it. Its CloudWatch key grant is on the `logs` CMK — see ADR 0020 §7c
        # for why that grant, not the topic, is the part that would have been missed.
        self.alerts: sns.Topic = sns.Topic(
            self,
            "AlertsTopic",
            topic_name=resource_name(self.env_name, "sns", "alerts"),
            display_name=f"Meridian {self.env_name} operational alerts",
            master_key=self.keys["logs"],
        )

        if not self.env_config.destroyed_between_phases:
            return

        # KMS-encrypted with the `logs` key: the message body is a failed API call and an
        # error code, never a row. `enforce_ssl` is the same TLS-only rule the buckets get.
        self.stop_dlq = sqs.Queue(
            self,
            "StopDatabaseDlq",
            queue_name=resource_name(self.env_name, "sqs", "rds-stop-dlq"),
            encryption=sqs.QueueEncryption.KMS,
            encryption_master_key=self.keys["logs"],
            enforce_ssl=True,
            retention_period=STOP_DLQ_RETENTION,
            removal_policy=RemovalPolicy.RETAIN,
        )

        role = iam.Role(
            self,
            "StopDatabaseRole",
            role_name=resource_name(self.env_name, "iam", "rds-stop"),
            # `aws:SourceAccount` on the TRUST policy, not only on the permissions
            # (critic, data tier, low): without it any EventBridge schedule in any
            # account that learns this role's ARN can ask Scheduler to assume it. The
            # condition is AWS's documented confused-deputy guard for service principals.
            assumed_by=iam.ServicePrincipal(
                "scheduler.amazonaws.com",
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            ),
            description="EventBridge Scheduler: stop the staging database nightly (D-15).",
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="StopThisInstanceOnly",
                actions=["rds:StopDBInstance"],
                resources=[self.database.instance_arn],
            )
        )
        # Scheduler writes the undeliverable invocation itself, under this role.
        self.stop_dlq.grant_send_messages(role)

        # **`AWS::Scheduler::Schedule` takes no tags** (critic, data tier, low). It is
        # one of the few resource types with no `Tags` property at all, so
        # `RequiredTagsAspect` cannot reach it and `Tags.of(...)` on it is silently a
        # no-op. The schedule is therefore invisible to every tag-driven control in the
        # account — cost allocation, the backup selections, any tag-scoped policy. It
        # holds no data and costs nothing, so nothing is lost here; it is written down so
        # that a future tag-based inventory is not read as complete.
        self.stop_schedule = scheduler.CfnSchedule(
            self,
            "StopDatabaseSchedule",
            name=resource_name(self.env_name, "schedule", "rds-stop"),
            description=(
                "D-15: stop the staging database every night. RDS restarts a stopped "
                "instance after 7 days, so this runs nightly rather than once."
            ),
            flexible_time_window=scheduler.CfnSchedule.FlexibleTimeWindowProperty(mode="OFF"),
            schedule_expression=STAGING_STOP_CRON,
            schedule_expression_timezone=STAGING_STOP_TIMEZONE,
            state="ENABLED",
            target=scheduler.CfnSchedule.TargetProperty(
                arn="arn:aws:scheduler:::aws-sdk:rds:stopDBInstance",
                role_arn=role.role_arn,
                # `DbInstanceIdentifier`, the spelling Scheduler accepts. See docstring.
                input=f'{{"DbInstanceIdentifier": "{self.database.instance_identifier}"}}',
                # An instance that is already stopped returns InvalidDBInstanceState, a
                # client error that no retry can fix. Nought attempts sends it straight
                # to the DLQ, which is where the arithmetic above takes over.
                retry_policy=scheduler.CfnSchedule.RetryPolicyProperty(maximum_retry_attempts=0),
                dead_letter_config=scheduler.CfnSchedule.DeadLetterConfigProperty(
                    arn=self.stop_dlq.queue_arn
                ),
            ),
        )

        # The DLQ depth alarm that used to be here is gone on purpose — see
        # STOP_DLQ_RETENTION above and ADR 0020 §7c. The queue is kept: it is the
        # evidence, and `scripts/staging_session.sh up` is what reads it.

    # -------------------------------------------------------------------- bucket

    def _buckets(self) -> dict[str, s3.Bucket]:
        """The four buckets, and the two policy statements every one of them carries.

        | Bucket | Key | Holds |
        |---|---|---|
        | `artifacts` | `artifacts` CMK | Journal-entry CSVs, invoice PDFs, exports with no identifiers (`src/storage.py` → `bucket_for`). |
        | `phi` | `phi` CMK | Raw uploads exactly as received, enriched workbooks, the validation report — everything carrying `Patient Acct No`. |
        | `audit` | `logs` CMK | Exported audit records, under **Object Lock**, seven years. |
        | `archive` | `phi` CMK | The Phase 10 Supabase archive, under **Object Lock**, seven years. PHI, so not `audit`. |

        **`enforce_ssl=True`** writes the `aws:SecureTransport=false` deny. **The KMS deny
        is the second statement and is the one that matters here:** S3 will happily accept
        a `PutObject` with SSE-S3 or with the *wrong* CMK, and the object is then encrypted
        — just not under the key whose policy draws the environment boundary. The deny
        turns that into a 403, which is why `src/storage.py` sends `ServerSideEncryption`
        and `SSEKMSKeyId` on every put and why `MERIDIAN_S3_KMS_KEY_ARN` is in
        `S3_REQUIRED_ENV`: a deployment missing one fails at startup rather than on the
        first upload of the period.

        **`BucketOwnerEnforced`** disables ACLs entirely, so object ownership cannot drift.
        **Versioning** is on everywhere: it is what makes an accidental overwrite
        recoverable, and AWS Backup's S3 support requires it.

        **Removal policy is RETAIN on all four, in both environments.** Staging's idle
        cost for all of this is a few cents — the plan's ~$1/month S3 line is production —
        so `DESTROY` would save nothing, and `auto_delete_objects` would add another
        Lambda custom resource with another implicit unencrypted log group (M-2). The
        `audit` bucket could not be destroyed anyway: Object Lock in compliance mode
        refuses to delete a locked object until its retention expires, which for a
        seven-year default means the bucket outlives every decision made about it.
        """
        buckets: dict[str, s3.Bucket] = {}

        for purpose, key_name, classification in (
            ("artifacts", "artifacts", "internal"),
            ("phi", "phi", "phi"),
        ):
            bucket = s3.Bucket(
                self,
                f"Bucket{purpose.capitalize()}",
                bucket_name=resource_name(self.env_name, "s3", purpose),
                encryption=s3.BucketEncryption.KMS,
                encryption_key=self.keys[key_name],
                # One data key per request costs money and API calls; a bucket key
                # reuses it for the whole bucket and cuts KMS charges by ~99%.
                bucket_key_enabled=True,
                enforce_ssl=True,
                versioned=True,
                block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
                object_ownership=s3.ObjectOwnership.BUCKET_OWNER_ENFORCED,
                lifecycle_rules=self._lifecycle_rules(purpose),
                removal_policy=RemovalPolicy.RETAIN,
            )
            self._deny_wrong_encryption(
                bucket,
                self.keys[key_name],
                # Only the phi bucket is scanned, so only it needs the carve-out (H-2).
                exempt_key=MALWARE_VALIDATION_OBJECT_KEY if purpose == "phi" else None,
            )
            Tags.of(bucket).add("DataClassification", classification)
            buckets[purpose] = bucket

        buckets["audit"] = self._audit_bucket()
        buckets["archive"] = self._archive_bucket()
        return buckets

    def _lifecycle_rules(self, purpose: str) -> list[s3.LifecycleRule]:
        """Raw uploads expire at 7 years (`RAW_UPLOAD_RETENTION_DAYS`); superseded versions at 90.

        **The raw-upload rule is on the `phi` bucket only**, because that is where raw uploads
        go: `src/storage.py` maps the `uploads` subfolder to `phi`, and it maps *every
        unknown* subfolder there too, fail-closed. A raw billing export is the densest PHI
        in the estate; it is kept 7 years so any past JE can be re-run from its source and
        compared (ADR 0020 §5b), and not longer.

        **It is a tag filter, not a prefix filter, and that is forced.** See
        `RAW_UPLOAD_TAG`: `uploads/` sits in the middle of the key, and S3 lifecycle
        prefixes match from the start. Until `S3StorageManager` tags its puts (Phase 5a)
        the rule selects nothing — stated here rather than discovered later.

        **90 days of noncurrent versions** is the undo window. Versioning without an
        expiry is a bucket that only grows, and every superseded version of a PHI object
        is another copy of PHI sitting there; 90 days is three fiscal periods, long enough
        that a mistake found at the next close is still recoverable.
        """
        rules = [
            s3.LifecycleRule(
                id="expire-noncurrent-versions-after-90-days",
                enabled=True,
                noncurrent_version_expiration=Duration.days(90),
                abort_incomplete_multipart_upload_after=Duration.days(7),
            ),
        ]
        if purpose == "phi":
            rules.append(
                s3.LifecycleRule(
                    id="expire-raw-uploads-after-7-years",
                    enabled=True,
                    expiration=Duration.days(RAW_UPLOAD_RETENTION_DAYS),
                    tag_filters={RAW_UPLOAD_TAG[0]: RAW_UPLOAD_TAG[1]},
                )
            )
        return rules

    def _audit_bucket(self) -> s3.Bucket:
        """Exported audit records, under **Object Lock in compliance mode, seven years**.

        Compliance mode means exactly what it says: for the retention period **nobody**
        can delete or overwrite an object — not an administrator, not the account root
        user, not AWS Support. That is the property that makes an audit record evidence
        rather than a file, and it is the same reasoning as the Vault Lock below: the
        credential that can delete the database must not be able to delete the record of
        what it did.

        Seven years is HIPAA's six-year documentation retention (45 CFR 164.316(b)(2))
        plus a year of slack, and plan §7 item 13 names the Object-Locked bucket as what
        satisfies it — 400-day log groups do not.

        **Object Lock can only be enabled when the bucket is created.** There is no
        migration; adding it later means a new bucket and a copy. It is also why this
        bucket has no expiration lifecycle at all: a lifecycle expiry on a locked object
        is a rule that cannot fire, and writing one would suggest the objects go away.

        It uses the `logs` CMK rather than a sixth key of its own — see `CMK_PURPOSES`.
        """
        bucket = s3.Bucket(
            self,
            "BucketAudit",
            bucket_name=resource_name(self.env_name, "s3", "audit"),
            encryption=s3.BucketEncryption.KMS,
            encryption_key=self.keys["logs"],
            bucket_key_enabled=True,
            enforce_ssl=True,
            versioned=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            object_ownership=s3.ObjectOwnership.BUCKET_OWNER_ENFORCED,
            object_lock_enabled=True,
            object_lock_default_retention=s3.ObjectLockRetention.compliance(
                Duration.days(OBJECT_LOCK_RETENTION_DAYS)
            ),
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="abort-incomplete-uploads",
                    enabled=True,
                    abort_incomplete_multipart_upload_after=Duration.days(7),
                )
            ],
            removal_policy=RemovalPolicy.RETAIN,
        )
        self._deny_wrong_encryption(bucket, self.keys["logs"])
        # Who read what, when, how many rows — never a PHI value (ADR 0012).
        Tags.of(bucket).add("DataClassification", "internal")
        return bucket

    def _archive_bucket(self) -> s3.Bucket:
        """The Phase 10 Supabase archive, Object-Locked — and on the **`phi`** key.

        The final `pg_dump` taken at decommissioning
        (`docs/runbooks/decommission-supabase-render.md` step 2) is the whole
        pre-migration database: 17,606 patient identifiers and the `auth` schema.
        It needed somewhere nothing can delete it from for seven years, and the
        first draft of that runbook sent it to the `audit` bucket. **That is
        wrong, and it is a classification error rather than a style one.**

        `audit` is `DataClassification=internal` and is encrypted with the `logs`
        CMK — the key ADR 0020 §4 deliberately keeps *away* from PHI so that
        "who may read the record of what happened" and "who may read the data"
        are two different grants. Putting a PHI dump in it would collapse that
        distinction irreversibly: compliance-mode Object Lock means the mistake
        cannot be undone by deleting the object, for seven years, by anyone.

        So PHI under Object Lock gets its own bucket, with:

        * the **`phi`** CMK, so the existing PHI key grants decide who can read it;
        * `DataClassification=phi`, so every sweep that looks for PHI finds it;
        * **Object Lock, compliance mode, seven years** by default — same figure and
          same reasoning as `audit` (45 CFR 164.316(b)(2) plus slack);
        * **versioning**, TLS-only (`enforce_ssl`) and KMS-only (`_deny_wrong_encryption`);
        * **no expiry lifecycle at all** — a lifecycle expiry on a locked object is a
          rule that cannot fire, and writing one would suggest the archive goes away;
        * `RemovalPolicy.RETAIN`, which Object Lock makes true whatever CDK says.

        It is created in **both** environments and it is empty in both until Phase
        10 — Object Lock can only be enabled at bucket creation, so the bucket has
        to exist before the dump does, and an empty versioned bucket costs nothing.
        Storing one dump is a few tens of MB compressed: under $0.01/month at
        $0.023/GB (`docs/reports/phase-1-cost-estimate.md` §2b).

        ADR 0020 §5 carries the dated note that split this away from `audit`.
        """
        bucket = s3.Bucket(
            self,
            "BucketArchive",
            bucket_name=resource_name(self.env_name, "s3", "archive"),
            encryption=s3.BucketEncryption.KMS,
            encryption_key=self.keys["phi"],
            bucket_key_enabled=True,
            enforce_ssl=True,
            versioned=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            object_ownership=s3.ObjectOwnership.BUCKET_OWNER_ENFORCED,
            object_lock_enabled=True,
            object_lock_default_retention=s3.ObjectLockRetention.compliance(
                Duration.days(OBJECT_LOCK_RETENTION_DAYS)
            ),
            # Aborting a stalled multipart upload is the one lifecycle action that
            # is safe here: it removes parts that were never an object, so Object
            # Lock never had anything to hold.
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="abort-incomplete-uploads",
                    enabled=True,
                    abort_incomplete_multipart_upload_after=Duration.days(7),
                )
            ],
            removal_policy=RemovalPolicy.RETAIN,
        )
        self._deny_wrong_encryption(bucket, self.keys["phi"])
        Tags.of(bucket).add("DataClassification", "phi")
        return bucket

    def _deny_wrong_encryption(
        self, bucket: s3.Bucket, key: kms.IKey, *, exempt_key: str | None = None
    ) -> None:
        """Refuse any `PutObject` that is not SSE-KMS under **this bucket's** key.

        Two statements, because there are two ways to get it wrong and they need
        different conditions:

        * the header is missing or is not `aws:kms` — `StringNotEquals` with
          `Null: true` on the key check would not catch this, because the key header is
          absent in the SSE-S3 case too;
        * the header says `aws:kms` but names another key — including another
          environment's key, which is the one this actually defends against. Staging
          writing a production-keyed object would put a production-decryptable object in
          a staging bucket, which is the §2.4 isolation boundary running backwards.

        `enforce_ssl=True` adds the third statement, the non-TLS deny.

        **`exempt_key` carves exactly one object key out of both denies, and only the
        `phi` bucket uses it (H-2).** GuardDuty Malware Protection proves it can write to
        the bucket by putting
        `malware-protection-resource-validation-object`, and it puts it with no
        encryption headers at all — the bucket's default SSE-KMS applies, but
        `s3:x-amz-server-side-encryption` is absent from the request, so the first deny
        fires and enabling the plan fails.

        The carve-out is written as **`NotResource`, not as an allow**, because an
        explicit `Allow` cannot override a `Deny` in IAM: a deny anywhere in the
        evaluation wins outright. `NotResource` instead narrows what the deny covers. It
        is safe here precisely because this is a *bucket* policy: S3 only evaluates it for
        requests against this bucket, so "every resource except this one key" means
        "every object in this bucket except this one key" and cannot leak wider. The
        object itself is still encrypted — by the bucket default — it simply is not
        required to say so on the wire.
        """
        exempt = [bucket.arn_for_objects(exempt_key)] if exempt_key else None
        all_objects = [bucket.arn_for_objects("*")]
        bucket.add_to_resource_policy(
            iam.PolicyStatement(
                sid="DenyUnencryptedObjectUploads",
                effect=iam.Effect.DENY,
                principals=[iam.AnyPrincipal()],
                actions=["s3:PutObject"],
                resources=None if exempt else all_objects,
                not_resources=exempt,
                conditions={"StringNotEquals": {"s3:x-amz-server-side-encryption": "aws:kms"}},
            )
        )
        bucket.add_to_resource_policy(
            iam.PolicyStatement(
                sid="DenyWrongKmsKey",
                effect=iam.Effect.DENY,
                principals=[iam.AnyPrincipal()],
                actions=["s3:PutObject"],
                resources=None if exempt else all_objects,
                not_resources=exempt,
                conditions={
                    "StringNotEquals": {
                        "s3:x-amz-server-side-encryption-aws-kms-key-id": key.key_arn
                    }
                },
            )
        )

    def _repositories(self) -> dict[str, ecr.Repository]:
        """One ECR repository per image, here because this stack is never destroyed.

        In `compute` (destroyed every staging session) a `RETAIN`ed repository made
        the next `up` collide on its name, and the first deploy had nowhere to push an
        image before its services needed one. `compute` looks them up by name.

        **`imageTagMutability: IMMUTABLE`.** A mutable tag means the image a task
        pulls on a restart is not necessarily the image that was tested. Immutable
        tags make "which code is running" answerable from the task definition alone.

        **`scanOnPush`.** Basic ECR scanning on arrival; Trivy in `deploy.yml` as well.

        `RETAIN`: a repository is free, and destroying one deletes every image in it.
        """
        return {
            purpose: ecr.Repository(
                self,
                f"Repository{purpose.capitalize()}",
                repository_name=resource_name(self.env_name, "ecr", purpose),
                image_tag_mutability=ecr.TagMutability.IMMUTABLE,
                image_scan_on_push=True,
                encryption=ecr.RepositoryEncryption.AES_256,
                lifecycle_rules=[
                    ecr.LifecycleRule(
                        rule_priority=1,
                        description=f"Keep the most recent {IMAGES_KEPT} images.",
                        max_image_count=IMAGES_KEPT,
                    )
                ],
                removal_policy=RemovalPolicy.RETAIN,
            )
            for purpose in REPOSITORY_PURPOSES
        }

    def _malware_protection(self) -> None:
        """GuardDuty Malware Protection, on the `phi` bucket and nowhere else.

        Every file Meridian ingests is an untrusted upload from a billing system, and the
        `phi` bucket is where they land. The plan scans them there (ADR 0012: "nothing is
        processed until the object is tagged clean") because the alternative is scanning
        inside the application, which means the file is already in the process.

        **`TAG` is the whole point.** GuardDuty writes `GuardDutyMalwareScanStatus` onto
        each object after scanning, so `meridian_app` can read the tag before it opens the
        file — that consumer is Phase 5a, and until it exists the tag is written and not
        yet read. Implementing the scan first is the right order: a scan with no reader
        still quarantines nothing, but a reader with no scan reads malware.

        **Only the `phi` bucket**, because it is billed per GB scanned. The `artifacts`
        bucket holds what this application itself wrote, and the `audit` bucket is
        append-only records; neither takes an upload from outside.

        **The role is AWS's documented prerequisite policy, followed exactly** — see the
        block comment below for what that changed and why a narrower hand-written version
        does not work.
        """
        phi_bucket = self.buckets["phi"]
        role = iam.Role(
            self,
            "MalwareProtectionRole",
            role_name=resource_name(self.env_name, "iam", "malware-scan"),
            assumed_by=iam.ServicePrincipal(
                "malware-protection-plan.guardduty.amazonaws.com",
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            ),
            description="GuardDuty Malware Protection for the phi bucket. Read, decrypt, tag.",
        )
        # ------------------------------------------------------------------------
        # **H-2: this is AWS's documented prerequisite policy, statement for statement.**
        # `docs.aws.amazon.com/guardduty/latest/ug/malware-protection-s3-iam-policy-prerequisite.html`
        # The earlier hand-rolled version was narrower than the document in two ways that
        # both fail at enable time rather than at deploy time:
        #
        #   * the EventBridge statement named the **default event bus** ARN. GuardDuty
        #     does not act on the bus; it creates and manages a *rule*, and the document
        #     scopes those actions to `rule/DO-NOT-DELETE-AmazonGuardDutyMalwareProtectionS3*`.
        #     A bus ARN authorises none of them.
        #   * there was no `s3:PutObject` on the validation object, which is the first
        #     thing the service does when a plan is created.
        #
        # The shape of the document is also deliberate and is kept: `PutRule` is the only
        # events action carrying the `events:ManagedBy` condition, because the read-ish
        # pair (`DescribeRule`, `ListTargetsByRule`) is a separate statement without it.
        # `s3:GetBucketLocation` and `kms:DescribeKey` are NOT in the document and were
        # dropped; the document is the contract the service is tested against.
        malware_rule_arn = self.format_arn(
            service="events",
            resource="rule",
            resource_name="DO-NOT-DELETE-AmazonGuardDutyMalwareProtectionS3*",
        )
        for statement in (
            iam.PolicyStatement(
                sid="AllowManagedRuleToSendS3EventsToGuardDuty",
                actions=[
                    "events:PutRule",
                    "events:DeleteRule",
                    "events:PutTargets",
                    "events:RemoveTargets",
                ],
                resources=[malware_rule_arn],
                conditions={
                    "StringLike": {
                        "events:ManagedBy": "malware-protection-plan.guardduty.amazonaws.com"
                    }
                },
            ),
            iam.PolicyStatement(
                sid="AllowGuardDutyToMonitorEventBridgeManagedRule",
                actions=["events:DescribeRule", "events:ListTargetsByRule"],
                resources=[malware_rule_arn],
            ),
            iam.PolicyStatement(
                sid="AllowPostScanTag",
                actions=[
                    "s3:PutObjectTagging",
                    "s3:GetObjectTagging",
                    "s3:PutObjectVersionTagging",
                    "s3:GetObjectVersionTagging",
                ],
                resources=[phi_bucket.arn_for_objects("*")],
            ),
            iam.PolicyStatement(
                sid="AllowEnableS3EventBridgeEvents",
                actions=["s3:PutBucketNotification", "s3:GetBucketNotification"],
                resources=[phi_bucket.bucket_arn],
            ),
            iam.PolicyStatement(
                sid="AllowPutValidationObject",
                actions=["s3:PutObject"],
                resources=[phi_bucket.arn_for_objects(MALWARE_VALIDATION_OBJECT_KEY)],
            ),
            iam.PolicyStatement(
                sid="AllowCheckBucketOwnership",
                actions=["s3:ListBucket"],
                resources=[phi_bucket.bucket_arn],
            ),
            iam.PolicyStatement(
                sid="AllowMalwareScan",
                actions=["s3:GetObject", "s3:GetObjectVersion"],
                resources=[phi_bucket.arn_for_objects("*")],
            ),
            iam.PolicyStatement(
                sid="AllowDecryptForMalwareScan",
                actions=["kms:GenerateDataKey", "kms:Decrypt"],
                resources=[self.keys["phi"].key_arn],
                conditions={"StringLike": {"kms:ViaService": f"s3.{Aws.REGION}.amazonaws.com"}},
            ),
        ):
            role.add_to_policy(statement)

        self.malware_protection_plan = guardduty.CfnMalwareProtectionPlan(
            self,
            "PhiMalwareProtection",
            role=role.role_arn,
            protected_resource=guardduty.CfnMalwareProtectionPlan.CFNProtectedResourceProperty(
                s3_bucket=guardduty.CfnMalwareProtectionPlan.S3BucketProperty(
                    bucket_name=phi_bucket.bucket_name
                )
            ),
            actions=guardduty.CfnMalwareProtectionPlan.CFNActionsProperty(
                tagging=guardduty.CfnMalwareProtectionPlan.CFNTaggingProperty(status="ENABLED")
            ),
        )
        # The plan names only the role's ARN, so without these CloudFormation creates it
        # before the role's policy and the bucket policy's validation-object carve-out
        # exist, and GuardDuty refuses: "role does not have the required permissions to
        # validate S3 bucket ownership" (first staging deploy, 2026-10-03).
        self.malware_protection_plan.node.add_dependency(role)
        self.malware_protection_plan.node.add_dependency(phi_bucket.policy)

        # The plan is about PHI even though it stores none: it is what says the phi
        # bucket's uploads are scanned. The stack-level default is `internal`, so this
        # has to be set explicitly, after construction, or the tag Aspect wins.
        Tags.of(self.malware_protection_plan).add("DataClassification", "phi")

    # ------------------------------------------------------------------- backups

    @property
    def dr_region(self) -> str:
        """The region the cross-region copy lands in. `-c drRegion=...`, default us-west-2."""
        return str(self.node.try_get_context("drRegion") or DEFAULT_DR_REGION)

    @property
    def dr_vault_arn(self) -> str:
        """The DR vault's ARN, **constructed rather than imported**.

        A CloudFormation stack cannot reference a resource in another region: there is no
        cross-region export, and CDK's own cross-region support works by copying values
        through custom resources, which would put a Lambda in the path of the backup
        configuration. So the ARN is composed from pseudo-parameters — no account id is
        written down (ADR 0001), and nothing here reads the other region.

        The vault it names is created by `meridian-<env>-dr`, a small stack in `app.py`
        that is **always** in the app: `-c drRegion` (default `us-west-2`) pins it, and
        the account stays unresolved like every other stack, so `cdk synth` still needs no
        credentials (M-5). Consequence, and it is an ordering rule rather than a
        subtlety: **deploy `meridian-<env>-dr` before
        `meridian-<env>-data`**, or the first copy job fails with "vault does not exist".
        `docs/runbooks/restore-drill.md` §1 says so; so does the stack's own description.
        """
        return (
            f"arn:{Aws.PARTITION}:backup:{self.dr_region}:{Aws.ACCOUNT_ID}:backup-vault:"
            + resource_name(self.env_name, "backup", "dr")
        )

    def _backups(self) -> tuple[backup.BackupVault, backup.BackupPlan | None]:
        """A locked vault, a daily plan, and a copy in another region.

        **Vault Lock in compliance mode is the point of this whole section.** Without it,
        the credential that can drop the database can also delete every recovery point,
        and the backup is a copy rather than a control. Locked, the vault refuses deletion
        of any recovery point before its retention expires — and refuses a plan that tries
        to write one with a retention outside [35, 400] days. After the three-day
        cooling-off window the lock cannot be removed by anyone, including AWS Support.

        **Read that consequence twice before deploying staging.** A compliance-locked
        vault cannot be deleted while it holds a recovery point, so a staging vault will
        hold its last backups for up to 35 days after anyone stops caring, and the vault
        itself cannot go until they expire. That is the intended behaviour of the control
        and it is also a real constraint on abandoning an environment; it is why
        `docs/runbooks/staging-teardown.md` now says the data stack is not merely "not
        destroyed by the script" but "not destroyable on demand".

        **Selection is by tag, in two selections rather than one**, and the shape is
        forced by AWS Backup: the `Conditions` of a single selection are ANDed. The rule
        wanted is `Project=meridian AND Environment=<env> AND DataClassification ∈ {phi,
        internal}` — an OR inside an AND, which one selection cannot express. Two
        selections, one per classification, is the same set. Tagging is also why this is
        robust: a resource added later with the right tags is backed up without anyone
        editing the plan, and a resource without them is *not*, which is the other half of
        why `RequiredTagsAspect` fails the build.

        **The S3 opt-in is not in this template and cannot be.** AWS Backup will not back
        up S3 until the account's region settings opt in
        (`aws backup update-region-settings --resource-type-opt-in-preference S3=true`),
        and no CloudFormation resource sets it. `infra/README.md` → "Pre-deploy checks"
        carries it. Without it the RDS backups still run and the S3 ones silently do not.

        **The scheduled plan exists in PRODUCTION only (M-2), and staging deliberately has
        no plan and no selections.** A daily 05:00 UTC job against a staging instance that
        the 02:00 schedule stopped three hours earlier does not skip — AWS Backup fails
        it, every night, for ever. A backup job that is *expected* to fail is worse than
        no job: it fills the AWS Backup console and any future job-failure alarm with
        noise, and the one night it fails for a real reason reads identically.

        Staging keeps the vault, the compliance lock and the role. What it does not keep
        is a cron line. The recovery story there is:

        * **PITR, 7 days**, which is unaffected by the instance being stopped — RDS keeps
          the automated backups and the transaction logs either way; and
        * **one on-demand job before the instance is stopped**, run by
          `scripts/staging_session.sh down` and documented in
          `docs/runbooks/staging-teardown.md` §2. It lands in the same locked vault, so
          the restore drill (`docs/runbooks/restore-drill.md`) has a real recovery point
          to exercise and exercises it against the same lock production has.
        """
        vault = backup.BackupVault(
            self,
            "BackupVault",
            backup_vault_name=resource_name(self.env_name, "backup", "vault"),
            encryption_key=self.keys["backups"],
            removal_policy=RemovalPolicy.RETAIN,
            lock_configuration=backup.LockConfiguration(
                min_retention=Duration.days(VAULT_MIN_RETENTION_DAYS),
                max_retention=Duration.days(VAULT_MAX_RETENTION_DAYS),
                changeable_for=Duration.days(VAULT_CHANGEABLE_FOR_DAYS),
            ),
        )
        Tags.of(vault).add("DataClassification", "phi")

        role = iam.Role(
            self,
            "BackupRole",
            role_name=resource_name(self.env_name, "iam", "backup"),
            # Same confused-deputy condition as the stop role: AWS Backup may assume
            # this role only when acting for THIS account (critic, data tier, low).
            assumed_by=iam.ServicePrincipal(
                "backup.amazonaws.com",
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            ),
            description="AWS Backup: back up and restore this environment's RDS and S3.",
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name(name)
                for name in (
                    "service-role/AWSBackupServiceRolePolicyForBackup",
                    "service-role/AWSBackupServiceRolePolicyForRestores",
                    # The S3 pair sits at the root path, not under service-role/.
                    "AWSBackupServiceRolePolicyForS3Backup",
                    "AWSBackupServiceRolePolicyForS3Restore",
                )
            ],
        )

        # M-2: staging gets the vault, the lock and the role, and stops there. The
        # on-demand job is `scripts/staging_session.sh down`.
        if self.env_config.destroyed_between_phases:
            return vault, None

        plan = backup.BackupPlan(
            self,
            "BackupPlan",
            backup_plan_name=resource_name(self.env_name, "backup", "plan"),
            backup_vault=vault,
            backup_plan_rules=[
                backup.BackupPlanRule(
                    rule_name="daily-35-day-with-cross-region-copy",
                    backup_vault=vault,
                    # 05:00 UTC — after the RDS backup window (03:00-04:00) and before
                    # the maintenance window, so the two never contend.
                    schedule_expression=events.Schedule.cron(hour="5", minute="0"),
                    start_window=Duration.hours(1),
                    completion_window=Duration.hours(6),
                    delete_after=Duration.days(VAULT_RETENTION_DAYS),
                    copy_actions=[
                        backup.BackupPlanCopyActionProps(
                            destination_backup_vault=backup.BackupVault.from_backup_vault_arn(
                                self, "DrVault", self.dr_vault_arn
                            ),
                            delete_after=Duration.days(VAULT_RETENTION_DAYS),
                        )
                    ],
                )
            ],
        )

        # **H-1: `Resources` AND `Conditions`, not `Conditions` alone.**
        #
        # A selection carrying only `Conditions` selects nothing. AWS Backup reads
        # `Resources` as the candidate set and `Conditions` as a filter over it, so an
        # empty `Resources` filters an empty set: the plan deploys clean, the console
        # shows two selections, and no job ever runs. It is the worst shape a backup
        # control can have, because it looks exactly like a working one.
        #
        # The candidate set is written by **type**, not by ARN, which is what keeps the
        # tag-driven behaviour: any RDS instance or any bucket in the account is a
        # candidate, and the three tag conditions decide which are actually taken. No
        # account id appears (ADR 0001) — the wildcards cover it — and the partition comes
        # from `Fn::Sub`-style pseudo-parameters via `format_arn`.
        #
        # **M-3 falls out of the same two lines.** The `edge` stack's `t4g.nano` ops
        # instance carries `Project`, `Environment` and `DataClassification=internal`, so
        # under a tags-only selection AWS Backup would have taken a nightly EBS snapshot
        # of a disposable jump box — billable storage for a machine whose entire content
        # is `cdk deploy` output. Scoping `Resources` to `rds:*:*:db:*` and `s3:::*`
        # excludes every EC2 and EBS ARN by construction rather than by an exclusion list
        # someone has to maintain.
        selection_resources = [
            self.format_arn(
                service="rds",
                region="*",
                account="*",
                resource="db",
                resource_name="*",
                arn_format=ArnFormat.COLON_RESOURCE_NAME,
            ),
            self.format_arn(
                service="s3",
                region="",
                account="",
                resource="*",
                arn_format=ArnFormat.NO_RESOURCE_NAME,
            ),
        ]

        for classification in ("phi", "internal"):
            backup.CfnBackupSelection(
                self,
                f"BackupSelection{classification.capitalize()}",
                backup_plan_id=plan.backup_plan_id,
                backup_selection=backup.CfnBackupSelection.BackupSelectionResourceTypeProperty(
                    selection_name=f"meridian-{self.env_name}-{classification}",
                    iam_role_arn=role.role_arn,
                    # The candidate set. See the comment above — without it, nothing.
                    resources=selection_resources,
                    # `Conditions` are ANDed. One selection per classification is how the
                    # OR is expressed — see the docstring.
                    conditions={
                        "StringEquals": [
                            {
                                "ConditionKey": "aws:ResourceTag/Project",
                                "ConditionValue": "meridian",
                            },
                            {
                                "ConditionKey": "aws:ResourceTag/Environment",
                                "ConditionValue": self.env_name,
                            },
                            {
                                "ConditionKey": "aws:ResourceTag/DataClassification",
                                "ConditionValue": classification,
                            },
                        ]
                    },
                ),
            )

        return vault, plan

    # ------------------------------------------------------------------- outputs

    def _outputs(self) -> None:
        """Everything the `compute` stack needs, under export names it can import.

        **The task definition's environment**, mapped to `src/settings.py`'s
        `S3_REQUIRED_ENV` — these four plus `AWS_REGION`, which the ECS agent sets:

        | Variable | Value |
        |---|---|
        | `MERIDIAN_S3_ARTIFACTS_BUCKET` | `ArtifactsBucketName` |
        | `MERIDIAN_S3_PHI_BUCKET` | `PhiBucketName` |
        | `MERIDIAN_S3_KMS_KEY_ARN` | `ArtifactsKeyArn` |
        | `MERIDIAN_S3_PHI_KMS_KEY_ARN` | `PhiKeyArn` |

        **`MERIDIAN_DATABASE_URL` is not an output and must never be one**: a
        CloudFormation output is readable by anyone who can call `DescribeStacks`, and
        this one would contain a password. It is assembled in the task definition from a
        `secretsmanager` dynamic reference, which CloudFormation resolves at deploy time
        into the task's secret configuration and never prints:

            postgresql://meridian_app:{{resolve:secretsmanager:<db-app secret arn>
              :SecretString:password}}@<DatabaseEndpoint>:5432/meridian?sslmode=verify-full

        `sslmode=verify-full`, never `require` — `require` encrypts without
        authenticating the server, which is not a defence against anything that can
        answer on the address. The RDS CA bundle is baked into the image (plan §3 Phase 3
        step 6); `sslrootcert` points at it.

        The same pattern supplies `MERIDIAN_APP_DB_PASSWORD` and
        `MERIDIAN_PHI_DB_PASSWORD` to Alembic 0003, and `MERIDIAN_PHI_HMAC_KEY` to
        `src/phi.py`. Task-role `GetSecretValue` grants are Phase 5a, scoped to exactly
        these ARNs.
        """

        def out(name: str, value: str, description: str) -> None:
            CfnOutput(
                self,
                name,
                value=value,
                description=description,
                export_name=f"meridian-{self.env_name}-data-{name}",
            )

        out(
            "DatabaseEndpoint",
            self.database.db_instance_endpoint_address,
            "RDS endpoint. Reachable only from the app and ops security groups.",
        )
        out(
            "DatabasePort",
            self.database.db_instance_endpoint_port,
            "PostgreSQL port.",
        )
        out(
            "DatabaseMasterSecretArn",
            self.database.secret.secret_arn if self.database.secret else "rds-managed",
            "The RDS-managed master credential for meridian_migrator. RDS rotates it; "
            "RDS also names it, which is why this is an output and not a convention.",
        )
        out(
            "ArtifactsBucketName",
            self.buckets["artifacts"].bucket_name,
            "MERIDIAN_S3_ARTIFACTS_BUCKET in the task definition.",
        )
        out(
            "PhiBucketName",
            self.buckets["phi"].bucket_name,
            "MERIDIAN_S3_PHI_BUCKET. Malware-scanned; read the scan tag before processing.",
        )
        out(
            "AuditBucketName",
            self.buckets["audit"].bucket_name,
            "Object Lock, compliance mode, 7 years. Nothing written here can be deleted.",
        )
        out(
            "ArchiveBucketName",
            self.buckets["archive"].bucket_name,
            "Phase 10 Supabase archive. PHI on the phi CMK, Object Lock, 7 years.",
        )
        for purpose in CMK_PURPOSES:
            out(
                f"{purpose.capitalize()}KeyArn",
                self.keys[purpose].key_arn,
                f"The {purpose} CMK. Never destroyed — see ADR 0008.",
            )
        out(
            "DbAppSecretArn",
            self.db_app_secret.secret_arn,
            "meridian_app password. MERIDIAN_APP_DB_PASSWORD / MERIDIAN_DATABASE_URL.",
        )
        out(
            "DbPhiSecretArn",
            self.db_phi_secret.secret_arn,
            "phi_access password. MERIDIAN_PHI_DB_PASSWORD.",
        )
        out(
            "DatabaseMartOwnerSecretArn",
            self.db_mart_owner_secret.secret_arn,
            "meridian_mart_owner password (Alembic 0048): the nightly mart-sync loader's login.",
        )
        out(
            "DatabaseMartReaderSecretArn",
            self.db_mart_reader_secret.secret_arn,
            "meridian_mart_reader password (Alembic 0048): the api's MART_DB_PASSWORD.",
        )
        out(
            "PhiHmacKeyArn",
            self.phi_hmac_key.secret_arn,
            "patient_ref HMAC key (ADR 0012). Backup-critical; rotating it breaks the join.",
        )
        out(
            "BackupVaultName",
            self.backup_vault.backup_vault_name,
            "Vault Lock, compliance mode, 35-400 days. Recovery points cannot be deleted.",
        )
        out(
            "DrBackupVaultArn",
            self.dr_vault_arn,
            f"The cross-region copy's destination in {self.dr_region}. Created by "
            "meridian-<env>-dr, which must be deployed first.",
        )
        CfnOutput(
            self,
            "OriginVerifySecretArn",
            value=self.origin_verify.secret_arn,
            description=(
                "Origin-verify shared secret. Consumed by meridian-<env>-edge; "
                "rotate with docs/runbooks/rotate-origin-verify-secret.md."
            ),
        )
