"""One CDK stack per concern (ADR 0006).

`FoundationStack`, `DnsStack` and `IdentityStack` are account-level and deployed
once. The others are deployed once per environment, with the environment supplied
as CDK context.

**Phase 3 split `NetworkStack` into `VpcStack` and `EdgeStack`** (ADR 0020). The
dividing line is lifetime, not function: `vpc` is free and persists, `edge` carries
every hourly charge and is destroyed at the end of every staging session. `DataStack`
depends on `vpc` only, which is what lets the database persist while the edge does not.

`BackupDrStack` is the one stack that is not in `us-east-1`; `infra/app.py` adds it only
when a concrete region is available.
"""

from .api import ApiStack
from .auth import AuthStack
from .backup_dr import BackupDrStack
from .base import EnvStack
from .compute import ComputeStack
from .data import DataStack
from .dns import DnsStack
from .edge import EdgeStack
from .foundation import FoundationStack
from .identity import IdentityStack
from .observability import ObservabilityStack
from .vpc import VpcStack

__all__ = [
    "ApiStack",
    "AuthStack",
    "BackupDrStack",
    "ComputeStack",
    "DataStack",
    "DnsStack",
    "EdgeStack",
    "EnvStack",
    "FoundationStack",
    "IdentityStack",
    "ObservabilityStack",
    "VpcStack",
]
