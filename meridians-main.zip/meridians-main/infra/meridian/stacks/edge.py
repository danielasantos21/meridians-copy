"""`meridian-<env>-edge` — the transient half of the network: NAT, ALB, CloudFront, WAF, ops.

Phase 2 of `docs/aws-migration-plan.md` (§3 steps 1-6), ADR 0009 (gateway endpoints
only), ADR 0015 (CloudFront + WAF), ADR 0018 (this stack's own decisions), **ADR 0020
(why `network` became `vpc` + `edge` in Phase 3)**.

**Everything in this file is billed by the hour, and that is the rule that decides what
lives here.** The NAT gateway ($37.50/month), the ALB ($24.73), the WAF ($11.60), the
CloudFront distribution, the flow-log ingestion and the `t4g.nano` ops instance ($3.10)
are the whole of a staging session's cost. Staging destroys this stack at the end of every
session and redeploys it at the start of the next, ~15 minutes (ADR 0008 / D-15).

The free, durable half — the VPC, its six subnets, the two gateway endpoints and the four
security groups — is `meridian-<env>-vpc`, and is never destroyed. `meridian-<env>-data`
(keys, secrets, RDS, buckets, the backup vault) depends on `vpc` and is never destroyed
either. **Nothing depends on this stack**, which is what makes `cdk destroy` of it safe:
CloudFormation blocks deleting a stack whose exports are in use, and this one exports
nothing anybody imports.

**Why the edge is not its own region-pinned stack.** CloudFront, a `CLOUDFRONT`-scoped WAF
web ACL and an ACM certificate for CloudFront must be in `us-east-1`. That is normally what
forces a separate stack — and there is no boundary to cross here, because the plan puts the
whole estate in `us-east-1` (§1). The split this file is the product of is about
**lifetime**, not region: what gets destroyed every session, and what must not.

**Two independent controls keep the origin private** (ADR 0015 — both, not either):

1. the ALB security group admits **CloudFront's managed prefix list** (declared in `vpc`)
   and nothing else; and
2. every listener rule requires the `X-Origin-Verify` header, and the listener's
   *default* action is a fixed `403`. A request that reaches the load balancer by
   any other route matches no rule and is refused.

**CloudFront is the only holder of that header** (P5AR5-01). The `web` task held it for
one round, so that `web/src/lib/proxy.ts` could dial `origin-<env>` directly — but
`_listener_rules` sends `/api/*`, `/auth/*` and `/static/*` to the `api` target group
before the `/*` rule that reaches the `web` task at all, so that hop never happened. The
task's `secrets:` entry and the `/32` NAT ingress rule that made the hop reachable are
both gone with it.

Either one failing alone is not an exposure. **Rotating the header is one
`put-secret-value` and two deploys**: the first widens the ALB to accept the new value
*and* the old one while CloudFront keeps sending the old one, the second moves
CloudFront. Both ends reference explicit secret **version ids** — never a staging label,
because a label renders identical template text at every rotation and CloudFormation
then silently declines to re-resolve it (finding H-F). The secret itself lives in the
`data` stack, so a staging teardown cannot delete it. See `_origin_verify_versions` and
`docs/runbooks/rotate-origin-verify-secret.md`.

**What this stack must never do** (ADR 0001): peer with, route through, or reference
the other owner's VPC or the default VPC where the trial instance lives. There is no
`from_lookup` anywhere in this file for exactly that reason.
"""

from __future__ import annotations

from typing import Any

from aws_cdk import (
    Annotations,
    Aws,
    CfnMapping,
    CfnOutput,
    Duration,
    Fn,
    RemovalPolicy,
    SecretValue,
    region_info,
)
from aws_cdk import aws_certificatemanager as acm
from aws_cdk import aws_cloudfront as cloudfront
from aws_cdk import aws_cloudfront_origins as origins
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_elasticloadbalancingv2 as elbv2
from aws_cdk import aws_iam as iam
from aws_cdk import aws_kms as kms
from aws_cdk import aws_logs as logs
from aws_cdk import aws_route53 as route53
from aws_cdk import aws_route53_targets as route53_targets
from aws_cdk import aws_s3 as s3
from aws_cdk import aws_wafv2 as wafv2
from constructs import Construct

from ..config import (
    DEFAULT_DOMAIN,
    ORIGIN_VERIFY_HEADER,
    SECRET_STAGE_CURRENT,
    SECRET_STAGE_PREVIOUS,
    EnvConfig,
    api_platform_enabled,
    site_hosts,
)
from ..edge_paths import api_path_patterns, chunked
from ..host_router import host_router_code
from ..log_groups import WAF_LOG_GROUP_PREFIX
from ..naming import resource_name
from .base import EnvStack, assert_edge_region
from .vpc import (
    API_PORT,
    PLACEHOLDER_PREFIX_LIST_ID,
    SUBNET_APP,
    SUBNET_PUBLIC,
    WEB_PORT,
    VpcStack,
)

#: D-25: the API's health endpoint. The `web` target group uses `/`.
API_HEALTH_PATH = "/api/v1/health"

#: 400 days: 365 for the year an auditor may ask about, plus a month of slack. The
#: same figure the foundation stack uses for its audit log groups. CloudWatch spells
#: 400 days `THIRTEEN_MONTHS` — it is the same number.
FLOW_LOG_RETENTION = logs.RetentionDays.THIRTEEN_MONTHS  # 400 days

#: WAF rate limits, per IP, per 5-minute window (plan §3 Phase 2 step 4).
RATE_LIMIT_GLOBAL = 2000
RATE_LIMIT_AUTH = 100
RATE_WINDOW_SECONDS = 300

#: Phase 12 T21 (`-c enableApiPlatform=true`): the `/api/v3` rate rule, per IP, per the
#: same 5-minute window. **1,500 = the application's own per-caller quota** (300 calls a
#: minute, `api/v3/quotas.CALLER_LIMIT` / `CALLER_WINDOW`) times five, so a caller that
#: stays inside its quota is never blocked at the edge; the edge exists to shed a flood
#: *before* it reaches the api and costs a database write per request in the quota
#: table. Stricter than the 2,000 global rule because v3 is the surface outside
#: machines call, and looser than the 100 sign-in rule because a machine polling runs
#: is not credential stuffing.
RATE_LIMIT_API_V3 = 1500
API_V3_PATH_PREFIX = "/api/v3/"

#: Rules inside `AWSManagedRulesCommonRuleSet` that are overridden to **Count**
#: rather than left at the group's own Block action, as `{rule name: why}`.
#:
#: **The bug this fixes.** Meridian's whole job is Excel in, journal entries out.
#: Every upload is a `multipart/form-data` POST to `/api/v2/...`, and a billing
#: export is routinely several megabytes. `SizeRestrictions_BODY` blocks any request
#: whose body exceeds **8 KB** — WAF only inspects the first 8 KB of a body, and the
#: rule's response to "there is more body than I can see" is to block it. Left at
#: Block, *every real upload in the product returns 403 at the edge*, before the ALB,
#: before Flask, with nothing in the application logs. That is not a tuning nicety;
#: it is the application not working.
#:
#: `CrossSiteScripting_BODY` and `GenericRFI_BODY` are the same class of problem one
#: step further in: they pattern-match the first 8 KB of the body, and the first 8 KB
#: of a multipart upload is MIME boundaries and the ZIP header of an `.xlsx` — binary
#: that trips injection signatures for reasons that have nothing to do with an attack.
#:
#: **Count, not Exclude.** A counted rule still evaluates, still publishes its
#: CloudWatch metric and still captures sampled requests, so Phase 5a's first staging
#: session with real workbooks has evidence to tighten against: if the two body rules
#: count zero on real uploads, they go back to Block with a scope-down that exempts
#: only the upload paths. Excluding them would delete the evidence.
#:
#: **What is NOT overridden:** the URI, query-string, header and cookie rules of the
#: same group, which is where the injection protection people actually mean when they
#: say "Common Rule Set", and both rate rules. The group is still a WAF.
COMMON_RULE_SET_COUNT_OVERRIDES: dict[str, str] = {
    "SizeRestrictions_BODY": (
        "Blocks any body over 8 KB. Every Excel upload in Meridian is bigger than that, "
        "so at Block this rule 403s the core workflow at the edge."
    ),
    "CrossSiteScripting_BODY": (
        "Pattern-matches the first 8 KB of the body, which for a multipart .xlsx upload "
        "is MIME boundaries and ZIP header bytes. False-positives on binary."
    ),
    "GenericRFI_BODY": (
        "Same field, same binary first 8 KB. Remote-file-inclusion signatures against a "
        "ZIP container are noise."
    ),
}

#: The upload surface those overrides exist for, taken from the inventory and from
#: `web/next.config.mjs` (`/api/:path*` -> `/api/*`): every Meridian file upload is a
#: multipart POST under `/api/v2/` **on the app host** (ADR 0050 — `www` and `api`
#: take no uploads, so the exception below is scoped to `app` as well as the path).
#: Recorded as a constant so that Phase 5a's tightening — turning the two body rules
#: back to Block outside this prefix — has a named place to start from, and so a
#: reader can see *which* requests the counted rules were loosened for.
UPLOAD_PATH_PREFIX = "/api/v2/"

#: M-K: the largest body accepted **outside** `UPLOAD_PATH_PREFIX`.
#:
#: The three Count overrides above are a property of the whole web ACL, not of the
#: upload paths — WAF's `RuleActionOverrides` list takes rule names, not conditions,
#: and a managed rule group may be referenced only **once** per web ACL, so there is no
#: way to keep the group blocking on `/*` and counting on `/api/v2/*`. Every POST in
#: the product therefore gets an uninspected body, including the ones that are plain
#: JSON and have no business being large.
#:
#: `meridian-body-size-non-upload` puts a floor back under that. It runs **before** the
#: managed groups and blocks any request whose body is larger than WAF's inspection
#: limit unless it is an `/api/v2/` request on the app host. How it works matters: WAF only
#: ever *sees* the first 16 KB of a body (the CloudFront default), so a size
#: comparison with `oversize_handling=CONTINUE` is evaluated on the truncated bytes and
#: can never exceed 16 KB — the first version of this rule was dead code. With
#: `oversize_handling=MATCH` an oversized body satisfies the statement outright,
#: which is AWS's documented recipe for "block bodies larger than the limit". 16 KB is
#: generous for JSON — Meridian's largest non-upload POST is a settings form.
#:
#: What it does **not** do: it does not restore body inspection, and it does not
#: protect the upload paths, which is where the uploads are. It narrows the accepted
#: risk in ADR 0018 §8 from "any body of any size, anywhere" to "any body of any size,
#: on the upload prefix". Phase 5a closes the rest with real workbooks.
#: CloudFront-scope web ACLs inspect at most 16 KB of a body by default.
NON_UPLOAD_BODY_LIMIT_BYTES = 16 * 1024

#: WAF logs go to `aws-waf-logs-meridian-<env>` — AWS fixes the prefix. The constant
#: lives in `meridian/log_groups.py` because the `logs` key policy names it too.

#: Headers redacted from every WAF log record. `authorization` carries the bearer
#: token and `cookie` carries the session, so an unredacted WAF log is a log of live
#: credentials — a worse exposure than whatever the log was opened to investigate.
#:
#: `X-Origin-Verify` is **not** in this list and does not need to be: the WAF runs at
#: CloudFront, on the request as the viewer sent it, and the header is added by the
#: distribution afterwards, on the way to the origin. The WAF never sees it (P5AR5-05).
WAF_REDACTED_HEADERS = ("authorization", "cookie")

#: The auth surface the stricter rate rule guards. `/api/v2/auth/*` is the React
#: sign-in path; `/login` is the Jinja form still reachable behind the rollback
#: hatch (`MERIDIAN_JINJA_AUTH=1`).
AUTH_PATH_PREFIX = "/api/v2/auth/"
AUTH_LOGIN_PATH = "/login"


def _flag(scope: Construct, name: str, *, default: bool) -> bool:
    """A boolean CDK context value. `-c name=false` arrives as the *string* "false"."""
    raw = scope.node.try_get_context(name)
    if raw is None:
        return default
    if isinstance(raw, bool):
        return raw
    return str(raw).strip().lower() in ("1", "true", "yes", "on")


class EdgeStack(EnvStack):
    """NAT gateway and routes, VPC flow logs, ALB, CloudFront, WAF, and the ops instance."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_config: EnvConfig,
        vpc_stack: VpcStack,
        logs_key: kms.IKey,
        ops_volume_key: kms.IKey,
        origin_verify_secret_arn: str,
        **kwargs: Any,
    ) -> None:
        """
        `vpc_stack` is the persistent `meridian-<env>-vpc` stack, passed as a **construct
        rather than imported by id** so that CDK works out the cross-stack exports and the
        deploy order itself. The direction is one-way: this stack consumes the VPC, the
        subnets and three of the four security groups, and exports nothing back. That is
        what makes `cdk destroy` of this stack safe — see ADR 0020 §3.

        `logs_key` and `ops_volume_key` are the environment's own CMKs, which live in
        the **data** stack because that stack survives a staging teardown (ADR 0008 —
        keys in a destroyed stack are *scheduled for deletion*, and a scheduled key
        deletion is how encrypted history quietly becomes unreadable). They are passed
        as `Key` objects for the same reason as the VPC: CDK writes the exports.

        The statement CloudWatch Logs needs on the `logs` key — the one that lets a log
        group be encrypted with it at all — is added by the **data** stack, next to the
        key itself (`DataStack._allow_cloudwatch_logs_to_use_the_logs_key`). It used to
        be added from here, which worked only as long as this stack was the only thing
        that made an encrypted log group. The data stack's RDS log groups are the second,
        and they have to exist while this stack is destroyed.
        """
        super().__init__(scope, construct_id, env_config=env_config, **kwargs)

        # us-east-1 or nothing. The CLOUDFRONT-scoped web ACL and the edge certificate
        # below cannot be created anywhere else, and a wrong region fails half way
        # through a changeset rather than at synth. No-op when the region is a token,
        # which is every offline synth. See `meridian/stacks/base.py`.
        assert_edge_region(self)

        # Staging is torn down and rebuilt every session (D-15), so its log groups and
        # buckets must actually go away or the next deploy collides with its own
        # leftovers. Production's are kept.
        self.removal_policy = (
            RemovalPolicy.DESTROY if env_config.destroyed_between_phases else RemovalPolicy.RETAIN
        )
        self.transient = env_config.destroyed_between_phases

        self.domain = str(self.node.try_get_context("domain") or DEFAULT_DOMAIN)
        #: The environment's web addresses — www / app / api (ADR 0050).
        self.hosts = site_hosts(self.env_name, self.domain)
        self.prefix_list_id = vpc_stack.prefix_list_id
        if self.prefix_list_id == PLACEHOLDER_PREFIX_LIST_ID:
            Annotations.of(self).add_warning(
                "cloudfrontPrefixListId is not set, so the ALB security group carries a "
                "placeholder prefix list id and neither this stack nor meridian-<env>-vpc "
                "will deploy. Look it up with `aws ec2 describe-managed-prefix-lists "
                "--filters Name=prefix-list-name,"
                "Values=com.amazonaws.global.cloudfront.origin-facing` "
                "and pass it with -c cloudfrontPrefixListId=pl-...  (infra/README.md)."
            )

        self.logs_key = logs_key
        self.vpc = vpc_stack.vpc
        self.alb_sg = vpc_stack.alb_sg
        self.app_sg = vpc_stack.app_sg
        self.ops_sg = vpc_stack.ops_sg

        self._nat_gateway()
        self._flow_logs(logs_key)

        self.origin_verify_secret_arn = origin_verify_secret_arn
        self._origin_verify_versions()
        self.zone = self._hosted_zone()
        self.certificate = self._certificate()
        self.alb, self.https_listener = self._load_balancer()
        self._listener_rules()
        self.web_acl = self._web_acl()
        self._web_acl_logging(self.web_acl, logs_key)
        self.distribution = self._distribution()
        self._dns_records()
        self._ops_instance(ops_volume_key)
        self._outputs()

    # ------------------------------------------------------------------- egress

    def _nat_gateway(self) -> None:
        """One NAT gateway, and one default route per `private-app` subnet.

        **Why it is built by hand here rather than by the `Vpc` construct.** CDK's `Vpc`
        creates the NAT gateway and the private subnets' default routes together, as one
        indivisible unit, and refuses `nat_gateways=0` alongside a `PRIVATE_WITH_EGRESS`
        tier. The NAT is $37.50/month — the single largest line in a staging session — so
        it has to be in the stack staging destroys, while the subnets it routes have to be
        in the stack that persists. The only way to have both is to declare the tier
        `PRIVATE_ISOLATED` in `vpc` (a subnet with an empty route table) and add the
        gateway and the routes here, as L1 resources. ADR 0020 §2 records the alternative
        — persisting the whole network, and paying the $37.50 while nothing runs.

        **One NAT, not one per AZ** (ADR 0018 §1, unchanged): a second costs another
        $32.85/month in hours to remove a failure mode — one AZ's *outbound* internet
        path — that ADR 0007 has already priced out. If the NAT's AZ fails, outbound
        calls to Intuit and the identity providers stop until it is replaced; nothing is
        lost, and the recovery is a `cdk deploy`.

        `private-data` is deliberately not in the loop. It gets no route in either stack.
        """
        public_subnets = self.vpc.select_subnets(subnet_group_name=SUBNET_PUBLIC).subnets
        app_subnets = self.vpc.select_subnets(subnet_group_name=SUBNET_APP).subnets

        eip = ec2.CfnEIP(
            self,
            "NatEip",
            domain="vpc",
            tags=[{"key": "Name", "value": resource_name(self.env_name, "eip", "nat")}],
        )
        self.nat_gateway = ec2.CfnNatGateway(
            self,
            "NatGateway",
            subnet_id=public_subnets[0].subnet_id,
            allocation_id=eip.attr_allocation_id,
            tags=[
                {"key": "Name", "value": resource_name(self.env_name, "nat", "main")},
            ],
        )

        #: Kept so the ops instance can depend on them: an instance that boots before its
        #: default route exists cannot reach Systems Manager, and an instance that never
        #: registers with SSM is an instance with no way in at all.
        self.nat_routes: list[ec2.CfnRoute] = []
        for index, subnet in enumerate(app_subnets):
            self.nat_routes.append(
                ec2.CfnRoute(
                    self,
                    f"NatRoute{index}",
                    route_table_id=subnet.route_table.route_table_id,
                    destination_cidr_block="0.0.0.0/0",
                    nat_gateway_id=self.nat_gateway.ref,
                )
            )

    def _flow_logs(self, logs_key: kms.IKey) -> None:
        """Every packet header, to a KMS-encrypted log group kept 400 days.

        **The flow log is in this stack, not in `vpc`,** although the VPC it watches is
        persistent. Two reasons, and the second is the one that decided it. CloudWatch
        Logs ingestion is metered, so the group is not free; and a log group encrypted
        with the `logs` CMK needs that key, the key lives in `data`, and `data` depends
        on `vpc` — a `vpc` that also consumed the key would close the cycle. ADR 0020 §4.

        What it costs: while `edge` is destroyed there are no flow logs. Nothing is
        running to generate traffic — the database is stopped and there are no tasks —
        so the gap is a gap in a record of silence. Production's `edge` is never
        destroyed, so production's flow logs are continuous.

        The `logs` key's own policy statement for `logs.<region>.amazonaws.com` is added
        by the **data** stack, beside the key. See `__init__`.
        """
        self.flow_log_group = logs.LogGroup(
            self,
            "FlowLogGroup",
            log_group_name=resource_name(self.env_name, "logs", "vpc-flow"),
            retention=FLOW_LOG_RETENTION,
            encryption_key=logs_key,
            # `@aws-cdk/aws-logs:defaultRemovalPolicy: retain` in cdk.json is the
            # right default for audit logs; it is wrong for a named log group in a
            # stack that is destroyed and recreated every session, because the
            # retained group then blocks its own recreation. Staging destroys.
            removal_policy=self.removal_policy,
        )

        ec2.FlowLog(
            self,
            "VpcFlowLog",
            flow_log_name=resource_name(self.env_name, "flowlog", "vpc"),
            resource_type=ec2.FlowLogResourceType.from_vpc(self.vpc),
            destination=ec2.FlowLogDestination.to_cloud_watch_logs(self.flow_log_group),
            traffic_type=ec2.FlowLogTrafficType.ALL,
            # 10 minutes rather than 1: a tenth of the log volume for a question
            # ("what talked to what") that is never asked to the minute.
            max_aggregation_interval=ec2.FlowLogMaxAggregationInterval.TEN_MINUTES,
        )

    # --------------------------------------------------------------------- edge

    def _origin_verify_versions(self) -> None:
        """Work out which *versions* of the origin-verify secret each end uses.

        **The problem this solves.** Before this, both the ALB listener rules and the
        CloudFront origin header rendered the same version-less dynamic reference,
        `{{resolve:secretsmanager:<arn>:SecretString:::}}`, which always means
        `AWSCURRENT`. That made the documented rotation a fiction: the
        `put-secret-value` changed nothing until a deploy, and then the next deploy
        moved **both** ends at once. CloudFront takes 5-10 minutes to propagate, and
        for those minutes the edges still sending the old value hit an ALB that no
        longer accepts it — a full outage, produced by the procedure that exists to
        avoid one.

        **Why labels on the ALB were not the fix either (H-F).** The obvious repair —
        ALB accepts the `AWSCURRENT` and `AWSPREVIOUS` *labels*, CloudFront is pinned
        to a version id — survives rotation #1 and breaks on rotation #2. A
        `{{resolve:...}}` dynamic reference is resolved during the deploy that writes
        it, and CloudFormation only re-writes a property whose **template text**
        changed. `AWSCURRENT`/`AWSPREVIOUS` are the same eleven characters at every
        rotation, so from rotation #2 on the listener rules are a no-diff resource:
        CloudFormation leaves them holding the strings resolved at the *first* deploy,
        while the CloudFront header — whose pinned version id genuinely changes — moves
        to the new value. The ALB then refuses every request CloudFront sends. That is
        not a window, it is an outage that lasts until somebody notices.

        **The fix: explicit version ids on BOTH ends, and one extra deploy.** Every id
        is a different uuid, so every rotation changes the template text of the
        listener rules and CloudFormation re-resolves them. The ALB's accepted set is
        widened in one deploy and the edge is moved in the next:

            0. read the current version id                         -> V_old
            1. put-secret-value                                    -> V_new
            2. deploy  active=V_new  previous=V_old  cloudfront=V_old
               ALB now accepts BOTH; CloudFront still sends V_old. Nothing moves.
            3. deploy  active=V_new  previous=V_old  cloudfront=V_new
               CloudFront moves. Every edge, mid-propagation, is sending something
               the ALB already accepts.

        `previous` can be dropped at the *next* rotation, when V_old stops being
        anything anyone sends.

        Plain language, because two of these words look alike:

        * A **version** is one stored value of the secret. Every `put-secret-value`
          creates a new one with its own id, and old versions stick around. A version
          id always means the same string, for ever.
        * A **staging label** (`AWSCURRENT`, `AWSPREVIOUS`) is a pointer at a version.
          `put-secret-value` moves `AWSCURRENT` to the new version and `AWSPREVIOUS`
          to the one it displaced.

        The three context values:

        * `originVerifyActiveVersion` — the primary value the **ALB** accepts.
          Default `AWSCURRENT`, which is correct on the **very first deploy only**,
          when no version id exists yet to name. After that it takes a version id.
        * `originVerifyPreviousVersion` — **default unset**: a brand-new secret has no
          second value to accept. From rotation #1 on it takes the *previous* version
          id. `AWSPREVIOUS` is accepted for the first rotation done from a stack that
          has never been pinned, and warns.
        * `originVerifyCloudFrontVersionId` — **default unset**, in which case
          CloudFront resolves `AWSCURRENT`, which is correct for the very first deploy
          and wrong for every deploy after it.

        **Being set is what marks "after the first deploy".** So whenever
        `originVerifyCloudFrontVersionId` is set and either ALB value is still a label,
        synth warns: that is precisely the rotation-#2 no-diff trap above.

        Full procedure: `docs/runbooks/rotate-origin-verify-secret.md`.
        """
        self.origin_verify_active_version = str(
            self.node.try_get_context("originVerifyActiveVersion") or SECRET_STAGE_CURRENT
        )
        previous = self.node.try_get_context("originVerifyPreviousVersion")
        self.origin_verify_previous_version = str(previous) if previous else None
        pinned = self.node.try_get_context("originVerifyCloudFrontVersionId")
        self.origin_verify_cloudfront_version = str(pinned) if pinned else None

        if self.origin_verify_cloudfront_version is None:
            Annotations.of(self).add_warning(
                "originVerifyCloudFrontVersionId is not set, so CloudFront resolves the "
                "origin-verify secret through the AWSCURRENT label. That is correct for "
                "the FIRST deploy only. Read the version id it resolved to with "
                "`aws secretsmanager describe-secret --secret-id "
                "meridian-<env>-secret-origin-verify --query VersionIdsToStages` and "
                "pass it with -c originVerifyCloudFrontVersionId=... from now on "
                "(docs/runbooks/rotate-origin-verify-secret.md step 0)."
            )
        else:
            # The pin is set, so this is not the first deploy. A LABEL on the ALB side
            # from here on is the rotation-#2 trap: the listener rules' template text
            # would not change at the next rotation, CloudFormation would not
            # re-resolve them, and the ALB would keep accepting only the value it was
            # given on the deploy that first wrote the label.
            labelled = [
                name
                for name, value in (
                    ("originVerifyActiveVersion", self.origin_verify_active_version),
                    ("originVerifyPreviousVersion", self.origin_verify_previous_version),
                )
                if value in (SECRET_STAGE_CURRENT, SECRET_STAGE_PREVIOUS)
            ]
            if labelled:
                Annotations.of(self).add_warning(
                    f"{', '.join(labelled)} still uses a Secrets Manager staging LABEL "
                    "while originVerifyCloudFrontVersionId is pinned to a version id. A "
                    "label renders the same template text at every rotation, so "
                    "CloudFormation will NOT re-resolve the listener rules on the next "
                    "rotation while CloudFront does move - the ALB would then refuse "
                    "every request the edge sends. Pass explicit version ids on both "
                    "ALB values from now on "
                    "(docs/runbooks/rotate-origin-verify-secret.md step 2)."
                )

        if (
            self.origin_verify_previous_version is not None
            and self.origin_verify_previous_version == self.origin_verify_active_version
        ):
            raise ValueError(
                "originVerifyPreviousVersion is the same as originVerifyActiveVersion "
                f"({self.origin_verify_active_version!r}). The ALB would then accept one "
                "value twice and the rotation window would not exist."
            )

    def _origin_verify_reference(self, version: str) -> str:
        """One version of the secret, as a CloudFormation dynamic reference.

        `version` is either a staging label (`AWSCURRENT`, `AWSPREVIOUS`) or an
        explicit version id — a uuid. They go in *different* positions of the
        `{{resolve:secretsmanager:...}}` syntax, so the two are told apart here
        rather than by whoever passes the context value.

        `unsafe_unwrap()` is the honest name for what this is: the value is resolved
        by CloudFormation into the ALB rule and the CloudFront origin header, which
        means it is readable by anyone who can read either template. That is
        inherent to an origin-verify header — both ends must hold the same string —
        and it is why the header is only ever the *second* of two controls (ADR
        0015), never the only one. It is also why `cdk.json` keeps
        `@aws-cdk/core:checkSecretUsage` on: nothing else in this app may do this
        without saying so out loud.
        """
        if version in (SECRET_STAGE_CURRENT, SECRET_STAGE_PREVIOUS):
            value = SecretValue.secrets_manager(
                self.origin_verify_secret_arn, version_stage=version
            )
        else:
            value = SecretValue.secrets_manager(self.origin_verify_secret_arn, version_id=version)
        return value.unsafe_unwrap()

    @property
    def alb_accepted_origin_verify_values(self) -> list[str]:
        """Every value a listener rule accepts: the active one, and the previous one.

        Two entries during and after a rotation, one before the first. They are
        distinct dynamic references, so CloudFormation resolves each independently at
        deploy time and the ALB ends up holding two literal strings.

        Both are version ids after the first deploy, and that is the point: a version
        id is a different uuid at every rotation, so the listener rules' template text
        changes and CloudFormation re-resolves them. A staging label here would not
        change, and would not be re-resolved. See `_origin_verify_versions`.
        """
        values = [self._origin_verify_reference(self.origin_verify_active_version)]
        if self.origin_verify_previous_version is not None:
            values.append(self._origin_verify_reference(self.origin_verify_previous_version))
        return values

    @property
    def cloudfront_origin_verify_value(self) -> str:
        """The single value CloudFront sends — pinned to a version id when one is given.

        Falling back to `AWSCURRENT` is deliberate and is only right once. See
        `_origin_verify_versions`.
        """
        return self._origin_verify_reference(
            self.origin_verify_cloudfront_version or SECRET_STAGE_CURRENT
        )

    def _hosted_zone(self) -> route53.IHostedZone | None:
        """The `meridiansgrp.com` zone from `meridian-shared-dns`, by id from context.

        **Not `HostedZone.from_lookup`**: a lookup calls Route 53 at synth time, so
        it needs credentials, and CI has none (`infra/app.py`). **Not a cross-stack
        reference to `DnsStack` either**: that would add a CloudFormation export to
        an account-level stack which a per-environment stack then pins, so the zone
        could not be changed while any environment existed — and it would couple a
        stack that is destroyed every session to one that is never destroyed.

        So: `-c hostedZoneId=Z...`, the same pattern the identity stack uses for the
        Identity Center identifiers (ADR 0001 — an identifier is not committed). Get
        it from the DNS stack's output:

            aws cloudformation describe-stacks --stack-name meridian-shared-dns \\
              --query "Stacks[0].Outputs[?OutputKey=='HostedZoneId'].OutputValue" --output text

        Without it the stack still synthesizes and still deploys; the certificate
        then waits on DNS validation records added by hand, and no alias records are
        created.
        """
        zone_id = self.node.try_get_context("hostedZoneId")
        if not zone_id:
            return None
        return route53.PublicHostedZone.from_public_hosted_zone_attributes(
            self, "HostedZone", hosted_zone_id=str(zone_id), zone_name=self.domain
        )

    @property
    def viewer_aliases(self) -> list[str]:
        """The hostnames CloudFront answers for in this environment (ADR 0050).

        Production: the apex, `www`, `app` and `api`. Staging: `staging-app` and
        `staging-api` — no `www` of its own; its marketing pages are served on
        `staging-app`. `config.site_hosts` is the table.
        """
        return self.hosts.viewer_aliases

    @property
    def public_hostname(self) -> str:
        """The app's name for this environment — the one every link the backend builds uses.

        `app.<domain>` in production, `staging-app.<domain>` in staging (ADR 0050).
        It is what the api task is given as `PUBLIC_APP_URL` (e-mail links, the
        Cognito and QuickBooks callbacks) and what `compute.py` gives the `web`
        task as `MERIDIAN_API_ORIGIN` — documented there as unused on ECS, because
        the listener rules claim every path that variable is about before the
        `web` container is reached (P5AR5-01).
        """
        return self.hosts.app

    @property
    def public_origin(self) -> str:
        """`public_hostname` with the scheme. Nothing here speaks plain HTTP."""
        return f"https://{self.public_hostname}"

    @property
    def www_origin(self) -> str | None:
        """The public website's origin, or `None` where marketing is served on `app`."""
        return f"https://{self.hosts.www}" if self.hosts.www else None

    @property
    def origin_host(self) -> str:
        """The hostname CloudFront connects to at the origin.

        CloudFront validates the origin's TLS certificate against **the name it dials**.
        The ALB's certificate covers this environment's own names (see
        `certificate_names`), not `*.elb.amazonaws.com`, so dialling the load
        balancer's AWS-generated DNS name over HTTPS would fail the handshake. A dedicated `origin-<env>` name, in the
        certificate and aliased at the ALB, is what makes "HTTPS to the origin"
        actually true rather than aspirational.

        This record is created whenever the zone id is supplied, **not** behind
        `createDnsAliases`: it is a brand-new name that nothing resolves today, so it
        moves no live traffic. Phase 9 flips the apex and `www` — those, and only
        those, are behind the flag (`_dns_records`).

        **Every viewer name is on the ALB's certificate too, not only this one.** The
        origin request policy forwards the viewer's `Host` header, and when it does,
        CloudFront checks the origin's certificate against *that* name — so a request
        for `api.<domain>` needs `api.<domain>` on the ALB's certificate. The one
        shared certificate (`certificate_names`) is what makes that true.
        """
        return f"origin-{self.env_name}.{self.domain}"

    @property
    def certificate_names(self) -> list[str]:
        """Every name this environment's certificate covers — **its own names only**.

        **M-1: staging must not request a certificate for the production names.**
        The first version asked for `meridiansgrp.com`, `www`, `staging` and
        `origin-<env>` in *both* environments, which is three problems in one
        property:

        1. **Staging would hold a valid certificate for the production apex.** A
           certificate is an assertion of identity. Staging has no business being able
           to make it, and the estate is meant to be split into two accounts later
           (ADR 0001) — at which point it would be a certificate for a name in another
           account.
        2. **Production would ask ACM to validate `staging.`**, a name it never
           answers for, so the certificate would sit `PENDING_VALIDATION` on a record
           that no production deploy has any reason to create.
        3. **A staging `cdk destroy` would delete the validation records for the
           production names.** The ACM-created Route 53 validation records belong to
           the stack that requested the certificate; staging is destroyed every
           session (ADR 0008), so the destroy would remove records production's
           renewal depends on.

        Each environment now asks only for what it serves:

        | Environment | Names |
        |---|---|
        | staging | `staging-app.`, `staging-api.`, `origin-staging.meridiansgrp.com` |
        | production | `meridiansgrp.com`, `www.`, `app.`, `api.`, `origin-production.meridiansgrp.com` |

        The two sets are disjoint, so the validation CNAMEs cannot collide — ACM
        derives each record's owner name from the name being validated, so distinct
        names give distinct records. (ADR 0017 spells this out.)
        """
        return [*self.viewer_aliases, self.origin_host]

    def _certificate(self) -> acm.Certificate:
        """One ACM certificate, in this stack's region (`us-east-1`), DNS-validated.

        CloudFront requires `us-east-1`; the plan puts everything there anyway (§1),
        so the ALB and CloudFront share one certificate instead of needing two.

        `certificate_names` is the subject list and explains why it is per-environment.
        """
        validation = (
            acm.CertificateValidation.from_dns(self.zone)
            if self.zone is not None
            else acm.CertificateValidation.from_dns()
        )
        primary, *alternates = self.certificate_names
        return acm.Certificate(
            self,
            "EdgeCertificate",
            certificate_name=resource_name(self.env_name, "acm", "edge"),
            domain_name=primary,
            subject_alternative_names=alternates,
            validation=validation,
        )

    def _access_log_bucket(self) -> s3.Bucket:
        """ALB access logs. **SSE-S3, not SSE-KMS — and that is not an oversight.**

        Elastic Load Balancing writes access logs with SSE-S3 (`AES256`) or no
        encryption at all; a bucket with a KMS default encryption rule makes every
        `PutObject` from the log delivery service fail, and the symptom is silence —
        no logs, no error anywhere you would look. So: SSE-S3, TLS-only, public
        access blocked, 400-day lifecycle, and the CMK spent elsewhere.
        """
        return s3.Bucket(
            self,
            "AlbAccessLogs",
            bucket_name=resource_name(self.env_name, "s3", "alb-logs"),
            encryption=s3.BucketEncryption.S3_MANAGED,
            enforce_ssl=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            object_ownership=s3.ObjectOwnership.BUCKET_OWNER_ENFORCED,
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="expire-after-400-days",
                    enabled=True,
                    expiration=Duration.days(400),
                    abort_incomplete_multipart_upload_after=Duration.days(7),
                )
            ],
            removal_policy=self.removal_policy,
            auto_delete_objects=self.transient,
        )

    def _cdn_log_bucket(self) -> s3.Bucket:
        """CloudFront standard logs. **SSE-S3, and ACLs enabled — both forced.**

        CloudFront's standard (legacy) log delivery writes with an ACL, so the bucket
        cannot use `BucketOwnerEnforced`; and it does not support SSE-KMS. Hence
        `BUCKET_OWNER_PREFERRED` plus SSE-S3. The alternative — v2 logging to
        CloudWatch or Firehose, which does support KMS — costs more and buys nothing
        here: these logs are request lines, classified `internal`, with no PHI in
        them (query strings are not logged by the app, and the path patterns are the
        ones in `edge_paths.py`).
        """
        return s3.Bucket(
            self,
            "CloudFrontLogs",
            bucket_name=resource_name(self.env_name, "s3", "cdn-logs"),
            encryption=s3.BucketEncryption.S3_MANAGED,
            enforce_ssl=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            object_ownership=s3.ObjectOwnership.BUCKET_OWNER_PREFERRED,
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="expire-after-400-days",
                    enabled=True,
                    expiration=Duration.days(400),
                )
            ],
            removal_policy=self.removal_policy,
            auto_delete_objects=self.transient,
        )

    def _load_balancer(self) -> tuple[elbv2.ApplicationLoadBalancer, elbv2.ApplicationListener]:
        """The ALB, its **one** listener (443) and the two (empty) target groups."""
        self.access_log_bucket = self._access_log_bucket()

        alb = elbv2.ApplicationLoadBalancer(
            self,
            "Alb",
            load_balancer_name=resource_name(self.env_name, "alb", "edge"),
            vpc=self.vpc,
            internet_facing=True,
            security_group=self.alb_sg,
            vpc_subnets=ec2.SubnetSelection(subnet_group_name=SUBNET_PUBLIC),
            # Refuse requests with malformed headers instead of normalising them.
            # Header smuggling between two proxies (CloudFront and the ALB) is
            # exactly the shape of bug this closes.
            drop_invalid_header_fields=True,
            # 120s: longer than the 60s default because a workbook export can take
            # a while to produce the first byte, shorter than any client timeout.
            idle_timeout=Duration.seconds(120),
        )
        self._enable_access_logs(alb, self.access_log_bucket, prefix="alb")

        self.web_target_group = elbv2.ApplicationTargetGroup(
            self,
            "WebTargetGroup",
            target_group_name=resource_name(self.env_name, "tg", "web"),
            vpc=self.vpc,
            port=WEB_PORT,
            protocol=elbv2.ApplicationProtocol.HTTP,
            # IP, because Fargate tasks are ENIs, not instances. Phase 5a registers
            # the service; until then the group is empty and the ALB returns 503.
            target_type=elbv2.TargetType.IP,
            deregistration_delay=Duration.seconds(30),
            health_check=elbv2.HealthCheck(
                path="/",
                healthy_http_codes="200-399",
                interval=Duration.seconds(30),
                timeout=Duration.seconds(5),
                healthy_threshold_count=2,
                unhealthy_threshold_count=3,
            ),
        )
        self.api_target_group = elbv2.ApplicationTargetGroup(
            self,
            "ApiTargetGroup",
            target_group_name=resource_name(self.env_name, "tg", "api"),
            vpc=self.vpc,
            port=API_PORT,
            protocol=elbv2.ApplicationProtocol.HTTP,
            target_type=elbv2.TargetType.IP,
            deregistration_delay=Duration.seconds(30),
            health_check=elbv2.HealthCheck(
                path=API_HEALTH_PATH,  # D-25
                healthy_http_codes="200",
                interval=Duration.seconds(30),
                timeout=Duration.seconds(5),
                healthy_threshold_count=2,
                unhealthy_threshold_count=3,
            ),
        )

        # **There is no port-80 listener** (L-3). CloudFront dials the origin with
        # `OriginProtocolPolicy.HTTPS_ONLY`, so nothing this load balancer serves ever
        # arrives on :80 — and the redirect it used to answer with was reachable by
        # every CloudFront distribution in the world, because the prefix list is AWS's
        # list of all of them, not ours. Removing it removes a listener that could only
        # ever be used by somebody else. The http→https redirect a *user* experiences
        # is CloudFront's `REDIRECT_TO_HTTPS`, at the edge, and is unaffected.
        #
        # `open=False`: CDK's default would add an 0.0.0.0/0 ingress rule to the ALB
        # security group, which is precisely the thing this design does not do. The
        # prefix-list rule in _security_groups is the only way in.
        https = alb.add_listener(
            "HttpsListener",
            port=443,
            protocol=elbv2.ApplicationProtocol.HTTPS,
            open=False,
            certificates=[elbv2.ListenerCertificate.from_certificate_manager(self.certificate)],
            ssl_policy=elbv2.SslPolicy.RECOMMENDED_TLS,
            # **The default action is a refusal.** Every route to a target group is
            # a rule that requires the origin-verify header, so anything arriving
            # without it — a direct hit on the load balancer's DNS name, a scanner,
            # a stale CloudFront distribution — matches no rule and lands here.
            # Fail closed, not "fall through to the web app".
            default_action=elbv2.ListenerAction.fixed_response(
                403,
                content_type="text/plain",
                message_body="Direct origin access is not allowed.",
            ),
        )
        return alb, https

    def _enable_access_logs(
        self, alb: elbv2.ApplicationLoadBalancer, bucket: s3.Bucket, *, prefix: str
    ) -> None:
        """Turn on ALB access logs by hand, because CDK's helper needs a fixed region.

        `alb.log_access_logs()` raises `RegionRequiredEnableBvAccess` when the stack
        has no concrete region — and this app is deliberately region-agnostic so that
        `cdk synth` needs no credentials (`infra/app.py`, ADR 0001). The helper only
        needs the region to look up **which AWS account writes the logs**, which
        differs per region and which CDK already publishes in its own region table.
        So the table is turned into a CloudFormation mapping and resolved at deploy
        time from the pseudo-parameter. No account id is written down here; the
        numbers come out of `aws-cdk-lib` and only ever appear in the generated
        template.

        Two statements, because AWS changed the mechanism halfway: regions launched
        before August 2022 (including `us-east-1`) have log delivery write from a
        per-region AWS account, and newer ones use the
        `logdelivery.elasticloadbalancing.amazonaws.com` service principal. Granting
        both means the same code works in either.
        """
        elbv2_accounts = region_info.RegionInfo.region_map(region_info.FactName.ELBV2_ACCOUNT)
        mapping = CfnMapping(
            self,
            "Elbv2LogDeliveryAccountByRegion",
            mapping={region: {"account": account} for region, account in elbv2_accounts.items()},
            lazy=False,
        )
        log_objects = f"{bucket.bucket_arn}/{prefix}/AWSLogs/{Aws.ACCOUNT_ID}/*"

        bucket.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowElbLogDeliveryAccount",
                principals=[iam.AccountPrincipal(mapping.find_in_map(Aws.REGION, "account"))],
                actions=["s3:PutObject"],
                resources=[log_objects],
            )
        )
        bucket.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowElbLogDeliveryServicePrincipal",
                principals=[iam.ServicePrincipal("logdelivery.elasticloadbalancing.amazonaws.com")],
                actions=["s3:PutObject"],
                resources=[log_objects],
                conditions={
                    "StringEquals": {
                        "s3:x-amz-acl": "bucket-owner-full-control",
                        "aws:SourceAccount": Aws.ACCOUNT_ID,
                    }
                },
            )
        )

        alb.set_attribute("access_logs.s3.enabled", "true")
        alb.set_attribute("access_logs.s3.bucket", bucket.bucket_name)
        alb.set_attribute("access_logs.s3.prefix", prefix)
        # The bucket policy has to exist before the load balancer tries its first
        # write, or the ALB fails to create with "Access Denied for bucket".
        alb.node.add_dependency(bucket.policy or bucket)

    def _listener_rules(self) -> None:
        """Route `api` and `web`, both gated on the origin-verify header.

        The `api` path patterns are **generated from `web/next.config.mjs`** by
        `meridian/edge_paths.py` and never retyped (plan §3 Phase 2 step 5). An ALB
        condition holds at most five values, so 21 patterns become five rules; the
        chunking is a quota artefact, and the rules are otherwise identical.

        **These rules come BEFORE the `/*` web rule, and that is what makes the
        Next.js proxy route handlers dead code on ECS** (P5AR5-01). Every prefix
        `web/src/lib/proxy.ts` answers for is in the list above, so the request
        reaches the `api` target group and the `web` task is never asked. The
        handlers are the DEV and RENDER path;
        `test_the_alb_claims_every_proxy_handler_prefix` in
        `infra/tests/test_edge.py` keeps the two in step, so adding a handler the
        edge does not claim fails CI.

        **The header condition holds one value before the first rotation and two
        after** — the new version id and the one it replaced — which is the whole
        rotation window. See `_origin_verify_versions`.
        """
        header = elbv2.ListenerCondition.http_header(
            ORIGIN_VERIFY_HEADER, self.alb_accepted_origin_verify_values
        )
        self.api_patterns = api_path_patterns()
        chunks = chunked(self.api_patterns)
        #: Kept so the distribution can depend on them — see `_distribution`.
        self.listener_rules: list[elbv2.ApplicationListenerRule] = []

        for index, patterns in enumerate(chunks, start=1):
            rule = elbv2.ApplicationListenerRule(
                self,
                f"ApiRule{index}",
                listener=self.https_listener,
                priority=index * 10,
                conditions=[header, elbv2.ListenerCondition.path_patterns(patterns)],
                action=elbv2.ListenerAction.forward([self.api_target_group]),
            )
            self.listener_rules.append(rule)

        # The catch-all. It is a *rule* rather than the listener's default action so
        # that it too carries the header condition — a default action cannot have
        # conditions, and a default that forwarded to `web` would serve the Next.js
        # app to anyone who found the load balancer's hostname.
        self.listener_rules.append(
            elbv2.ApplicationListenerRule(
                self,
                "WebRule",
                listener=self.https_listener,
                priority=(len(chunks) + 1) * 10,
                conditions=[header, elbv2.ListenerCondition.path_patterns(["/*"])],
                action=elbv2.ListenerAction.forward([self.web_target_group]),
            )
        )

    def _web_acl(self) -> wafv2.CfnWebACL:
        """The WAF web ACL, `CLOUDFRONT` scope (ADR 0015).

        Six rules: one custom body-size rule, three AWS-managed rule groups and two
        rate rules. **Shield Standard is automatic and free with CloudFront; Shield
        Advanced is $3,000/month and is never enabled without asking** (ADR 0015).

        The body-size rule runs first and is the M-K narrowing: see
        `NON_UPLOAD_BODY_LIMIT_BYTES` for why the Count overrides below cannot
        themselves be scoped to the upload paths.

        Managed rules can false-positive. They are tuned on staging first, and every
        rule below publishes CloudWatch metrics and sampled requests so that the
        tuning is evidence rather than guesswork.
        """

        def visibility(metric: str) -> wafv2.CfnWebACL.VisibilityConfigProperty:
            return wafv2.CfnWebACL.VisibilityConfigProperty(
                cloud_watch_metrics_enabled=True,
                # Off (Codex, 2026-09-17): a sampled request is the full request —
                # URI, query string and headers — kept by WAF for three hours with
                # none of the log redaction below applied to it. Metrics say how
                # often a rule fired; the redacted WAF log says on what.
                sampled_requests_enabled=False,
                metric_name=f"meridian-{self.env_name}-{metric}",
            )

        def managed(
            name: str,
            priority: int,
            *,
            count_rules: dict[str, str] | None = None,
        ) -> wafv2.CfnWebACL.RuleProperty:
            """One AWS managed rule group, optionally with per-rule Count overrides.

            `count_rules` is `{rule name: why}`. It is a **per-rule** override
            (`RuleActionOverrides`), not the group-level `OverrideAction` below —
            the distinction matters: the group-level one turns the *entire* group
            into logging, which is how a WAF quietly stops being a WAF, and it is
            never used here.
            """
            return wafv2.CfnWebACL.RuleProperty(
                name=name,
                priority=priority,
                statement=wafv2.CfnWebACL.StatementProperty(
                    managed_rule_group_statement=wafv2.CfnWebACL.ManagedRuleGroupStatementProperty(
                        vendor_name="AWS",
                        name=name,
                        rule_action_overrides=[
                            wafv2.CfnWebACL.RuleActionOverrideProperty(
                                name=rule_name,
                                action_to_use=wafv2.CfnWebACL.RuleActionProperty(
                                    count=wafv2.CfnWebACL.CountActionProperty()
                                ),
                            )
                            for rule_name in sorted(count_rules)
                        ]
                        if count_rules
                        else None,
                    )
                ),
                # `none` = use the rule group's own actions. `count` would turn the
                # whole group into logging only, which is how a WAF quietly stops
                # being a WAF.
                override_action=wafv2.CfnWebACL.OverrideActionProperty(none={}),
                visibility_config=visibility(name),
            )

        def host_is(host: str) -> wafv2.CfnWebACL.StatementProperty:
            """The request arrived on `host` — the viewer's own `Host` header.

            WAF runs before the host-router function, on the request as the viewer
            sent it, so this is the name the browser or partner actually used.
            """
            return wafv2.CfnWebACL.StatementProperty(
                byte_match_statement=wafv2.CfnWebACL.ByteMatchStatementProperty(
                    field_to_match=wafv2.CfnWebACL.FieldToMatchProperty(
                        single_header={"Name": "host"}
                    ),
                    positional_constraint="EXACTLY",
                    search_string=host,
                    text_transformations=[
                        wafv2.CfnWebACL.TextTransformationProperty(priority=0, type="LOWERCASE")
                    ],
                )
            )

        def uri_starts_with(value: str) -> wafv2.CfnWebACL.StatementProperty:
            return wafv2.CfnWebACL.StatementProperty(
                byte_match_statement=wafv2.CfnWebACL.ByteMatchStatementProperty(
                    field_to_match=wafv2.CfnWebACL.FieldToMatchProperty(uri_path={}),
                    positional_constraint="STARTS_WITH",
                    search_string=value,
                    text_transformations=[
                        wafv2.CfnWebACL.TextTransformationProperty(priority=0, type="LOWERCASE")
                    ],
                )
            )

        rules = [
            wafv2.CfnWebACL.RuleProperty(
                name="meridian-body-size-non-upload",
                # Priority 0: ahead of every managed group, so an oversized body on a
                # non-upload path is refused before anything tries to inspect it.
                priority=0,
                statement=wafv2.CfnWebACL.StatementProperty(
                    and_statement=wafv2.CfnWebACL.AndStatementProperty(
                        statements=[
                            wafv2.CfnWebACL.StatementProperty(
                                size_constraint_statement=(
                                    wafv2.CfnWebACL.SizeConstraintStatementProperty(
                                        field_to_match=wafv2.CfnWebACL.FieldToMatchProperty(
                                            # `oversize_handling=MATCH`: a body larger
                                            # than the inspection limit matches this
                                            # statement without being read. `CONTINUE`
                                            # would compare only the inspected bytes
                                            # (never more than the limit) and the rule
                                            # could never fire.
                                            body=wafv2.CfnWebACL.BodyProperty(
                                                oversize_handling="MATCH"
                                            )
                                        ),
                                        comparison_operator="GT",
                                        size=NON_UPLOAD_BODY_LIMIT_BYTES,
                                        text_transformations=[
                                            wafv2.CfnWebACL.TextTransformationProperty(
                                                priority=0, type="NONE"
                                            )
                                        ],
                                    )
                                )
                            ),
                            # The upload exception is the APP's alone (ADR 0050):
                            # `www` and `api` never take a multi-megabyte body, so
                            # an oversized one there is refused like anywhere else.
                            wafv2.CfnWebACL.StatementProperty(
                                not_statement=wafv2.CfnWebACL.NotStatementProperty(
                                    statement=wafv2.CfnWebACL.StatementProperty(
                                        and_statement=wafv2.CfnWebACL.AndStatementProperty(
                                            statements=[
                                                host_is(self.hosts.app),
                                                uri_starts_with(UPLOAD_PATH_PREFIX),
                                            ]
                                        )
                                    )
                                )
                            ),
                        ]
                    )
                ),
                action=wafv2.CfnWebACL.RuleActionProperty(
                    block=wafv2.CfnWebACL.BlockActionProperty()
                ),
                visibility_config=visibility("body-size-non-upload"),
            ),
            # Broad injection / traversal / bad-bot signatures, with three
            # body-inspection rules dropped to Count so that Excel uploads work at
            # all. COMMON_RULE_SET_COUNT_OVERRIDES says exactly which and why;
            # UPLOAD_PATH_PREFIX says which requests it was done for. Phase 5a's
            # first staging session drives real workbooks through it and tightens
            # from the counted metrics.
            managed(
                "AWSManagedRulesCommonRuleSet",
                1,
                count_rules=COMMON_RULE_SET_COUNT_OVERRIDES,
            ),
            # Request shapes that are never legitimate (bad headers, host confusion).
            managed("AWSManagedRulesKnownBadInputsRuleSet", 2),
            # Addresses AWS observes running bots and scanners.
            managed("AWSManagedRulesAmazonIpReputationList", 3),
            wafv2.CfnWebACL.RuleProperty(
                name="RateLimitPerIp",
                priority=4,
                # 2,000 requests per IP per 5 minutes. A person clicking through
                # Meridian makes a few dozen; a scraper makes thousands.
                statement=wafv2.CfnWebACL.StatementProperty(
                    rate_based_statement=wafv2.CfnWebACL.RateBasedStatementProperty(
                        limit=RATE_LIMIT_GLOBAL,
                        aggregate_key_type="IP",
                        evaluation_window_sec=RATE_WINDOW_SECONDS,
                    )
                ),
                action=wafv2.CfnWebACL.RuleActionProperty(
                    block=wafv2.CfnWebACL.BlockActionProperty()
                ),
                visibility_config=visibility("rate-limit-per-ip"),
            ),
            wafv2.CfnWebACL.RuleProperty(
                name="RateLimitAuthPerIp",
                priority=5,
                # The sign-in surface, 20× stricter: 100 per IP per 5 minutes. This
                # is the credential-stuffing brake, and it sits at the edge so it
                # works regardless of how many api tasks are running — the
                # application's own per-task limiter cannot make that promise.
                statement=wafv2.CfnWebACL.StatementProperty(
                    rate_based_statement=wafv2.CfnWebACL.RateBasedStatementProperty(
                        limit=RATE_LIMIT_AUTH,
                        aggregate_key_type="IP",
                        evaluation_window_sec=RATE_WINDOW_SECONDS,
                        scope_down_statement=wafv2.CfnWebACL.StatementProperty(
                            or_statement=wafv2.CfnWebACL.OrStatementProperty(
                                statements=[
                                    uri_starts_with(AUTH_PATH_PREFIX),
                                    uri_starts_with(AUTH_LOGIN_PATH),
                                ]
                            )
                        ),
                    )
                ),
                action=wafv2.CfnWebACL.RuleActionProperty(
                    block=wafv2.CfnWebACL.BlockActionProperty()
                ),
                visibility_config=visibility("rate-limit-auth"),
            ),
        ]
        if api_platform_enabled(self):
            rules.append(
                wafv2.CfnWebACL.RuleProperty(
                    name="RateLimitApiV3PerIp",
                    priority=6,
                    # Phase 12 T21. See RATE_LIMIT_API_V3 for the number. One more
                    # WAF rule is $1/month per running environment (cost estimate,
                    # "Phase 12 — pending approval").
                    statement=wafv2.CfnWebACL.StatementProperty(
                        rate_based_statement=wafv2.CfnWebACL.RateBasedStatementProperty(
                            limit=RATE_LIMIT_API_V3,
                            aggregate_key_type="IP",
                            evaluation_window_sec=RATE_WINDOW_SECONDS,
                            # The `api` host (ADR 0050) — every request on it is
                            # a v3 call — plus `/api/v3/` on any host, which is
                            # where the React admin screens call the same routes.
                            scope_down_statement=wafv2.CfnWebACL.StatementProperty(
                                or_statement=wafv2.CfnWebACL.OrStatementProperty(
                                    statements=[
                                        host_is(self.hosts.api),
                                        uri_starts_with(API_V3_PATH_PREFIX),
                                    ]
                                )
                            ),
                        )
                    ),
                    action=wafv2.CfnWebACL.RuleActionProperty(
                        block=wafv2.CfnWebACL.BlockActionProperty()
                    ),
                    visibility_config=visibility("rate-limit-api-v3"),
                )
            )

        return wafv2.CfnWebACL(
            self,
            "WebAcl",
            name=resource_name(self.env_name, "waf", "edge"),
            # WAF descriptions reject parentheses; the ADR reference stays, the
            # brackets do not.
            description=f"Meridian {self.env_name} edge protection - ADR 0015",
            scope="CLOUDFRONT",
            default_action=wafv2.CfnWebACL.DefaultActionProperty(
                allow=wafv2.CfnWebACL.AllowActionProperty()
            ),
            rules=rules,
            visibility_config=visibility("waf-edge"),
        )

    def _web_acl_logging(self, web_acl: wafv2.CfnWebACL, logs_key: kms.IKey) -> None:
        """WAF logs to CloudWatch, 400 days, CMK-encrypted, credentials redacted.

        **Without this the WAF is a black box.** CloudWatch metrics say *how many*
        requests a rule matched; only the logs say *which* request, with which URI
        and which rule. Every question worth asking after a block — "was that a real
        upload?", "is `SizeRestrictions_BODY` counting on the paths we expect?" —
        needs the log record, and the counted overrides above are only evidence-based
        if the evidence exists.

        Three details that are not style:

        * **The log group name must start with `aws-waf-logs-`.** AWS enforces it in
          `PutLoggingConfiguration`; any other name is rejected. That is why this one
          group does not follow `meridian-<env>-<component>-<purpose>`.
        * **`LogDestinationConfigs` wants the group ARN without the trailing `:*`.**
          CDK's `log_group_arn` includes it, WAF refuses it, and the error is opaque.
          `Fn.select(0, Fn.split(":*", arn))` trims it at deploy time.
        * **`authorization` and `cookie` are redacted.** A WAF log is written for
          every counted and blocked request; unredacted it would be a durable,
          400-day store of live session cookies and bearer tokens — a worse exposure
          than whatever it was opened to investigate. WAF replaces the value with
          `REDACTED`; the header's *presence* is still visible, which is all an
          investigation needs.

        The log group is encrypted with the environment's `logs` CMK. The key policy
        statement CloudWatch Logs needs is on the key itself, added by the `data` stack,
        and admits this group by name (`meridian/log_groups.py`, CX-INF-04) — so it is
        not repeated here.
        """
        self.waf_log_group = logs.LogGroup(
            self,
            "WafLogGroup",
            log_group_name=f"{WAF_LOG_GROUP_PREFIX}-{self.env_name}",
            retention=FLOW_LOG_RETENTION,  # 400 days, same figure as everything else
            encryption_key=logs_key,
            # Same reasoning as the flow-log group: a retained, named group in a stack
            # that is destroyed every staging session blocks its own recreation.
            removal_policy=self.removal_policy,
        )

        wafv2.CfnLoggingConfiguration(
            self,
            "WebAclLogging",
            resource_arn=web_acl.attr_arn,
            log_destination_configs=[
                Fn.select(0, Fn.split(":*", self.waf_log_group.log_group_arn))
            ],
            redacted_fields=[
                wafv2.CfnLoggingConfiguration.FieldToMatchProperty(single_header={"Name": header})
                for header in WAF_REDACTED_HEADERS
            ],
        )

    def _distribution(self) -> cloudfront.Distribution:
        """CloudFront in front of the ALB: HTTPS to the origin, TLS 1.2 to the viewer."""
        self.cdn_log_bucket = self._cdn_log_bucket()

        origin = origins.HttpOrigin(
            self.origin_host,
            # HTTPS end to end. The origin is the ALB, dialled by a name the ALB's
            # certificate actually covers — see `origin_host`.
            protocol_policy=cloudfront.OriginProtocolPolicy.HTTPS_ONLY,
            origin_ssl_protocols=[cloudfront.OriginSslPolicy.TLS_V1_2],
            # The second of the two origin controls (ADR 0015). The value is pinned to
            # one secret VERSION id, and so are both values the ALB accepts. A rotation
            # therefore takes two deploys — widen the ALB, then move the edge — and at
            # no instant is an edge sending something the ALB refuses. Labels on the
            # ALB side look like they would save a deploy and do not: identical
            # template text means CloudFormation never re-resolves them (H-F).
            # See `_origin_verify_versions` and
            # docs/runbooks/rotate-origin-verify-secret.md.
            custom_headers={ORIGIN_VERIFY_HEADER: self.cloudfront_origin_verify_value},
            read_timeout=Duration.seconds(60),
            keepalive_timeout=Duration.seconds(60),
            connection_attempts=3,
            connection_timeout=Duration.seconds(10),
        )

        # The www / app / api split (ADR 0050), on EVERY behaviour: the apex
        # redirect, the api host's `/v3` rewrite and 404, and the www<->app
        # redirects are decided by the name a request arrived on, before any of
        # it reaches the origin. `meridian/host_router.py` has the table.
        self.host_router = cloudfront.Function(
            self,
            "HostRouter",
            function_name=resource_name(self.env_name, "cff", "host-router"),
            comment="www / app / api host split - ADR 0050",
            code=cloudfront.FunctionCode.from_inline(host_router_code(self.hosts)),
            runtime=cloudfront.FunctionRuntime.JS_2_0,
        )
        host_router = [
            cloudfront.FunctionAssociation(
                function=self.host_router,
                event_type=cloudfront.FunctionEventType.VIEWER_REQUEST,
            )
        ]

        # Dynamic, cookie-bearing, per-user. Caching any of it would serve one
        # tenant's data to another — so: no cache, forward everything.
        dynamic = cloudfront.BehaviorOptions(
            origin=origin,
            viewer_protocol_policy=cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
            allowed_methods=cloudfront.AllowedMethods.ALLOW_ALL,
            cached_methods=cloudfront.CachedMethods.CACHE_GET_HEAD,
            cache_policy=cloudfront.CachePolicy.CACHING_DISABLED,
            # `ALL_VIEWER_AND_CLOUDFRONT_2022` rather than `ALL_VIEWER`: the same
            # viewer headers PLUS the `CloudFront-*` family, and the one that
            # matters is `CloudFront-Viewer-Address`. The edge writes it about
            # the viewer's own socket, and `api.deps.client_address` prefers it
            # over walking `X-Forwarded-For` — which is how the credential rate
            # limits bucket on the caller instead of on an edge node shared by
            # everybody behind it (P5AR3-02).
            #
            # It is only trustworthy because there is exactly ONE CloudFront
            # pass in front of the api: browser → CloudFront → ALB → api. The
            # `_listener_rules` above send `/api/*` to the `api` target group
            # directly, so nothing rewrites the header between the viewer and
            # the api. A design that routed those calls through the `web` task
            # and back out through this distribution would have the second pass
            # OVERWRITE the header with the NAT gateway's address, and every SPA
            # request would share one bucket — worse than the edge node it
            # replaced (ADR 0023, round-5 note).
            origin_request_policy=cloudfront.OriginRequestPolicy.ALL_VIEWER_AND_CLOUDFRONT_2022,
            compress=True,
            function_associations=host_router,
        )

        distribution = cloudfront.Distribution(
            self,
            "Distribution",
            comment=resource_name(self.env_name, "cloudfront", "edge"),
            # The default behaviour is Next.js, and it is **also** uncached for now:
            # the app sets session cookies on ordinary page responses, so a shared
            # cache in front of them is a cross-tenant bug waiting to happen. When
            # Phase 5b separates the cookie-setting routes, this becomes a real
            # cache policy — deliberately, with a test.
            default_behavior=dynamic,
            additional_behaviors={
                "/api/*": dynamic,
                "/auth/*": dynamic,
                # Next.js content-hashes these filenames, so they are immutable and
                # safe to cache at the edge for a long time. This is the only
                # behaviour that caches anything.
                "/_next/static/*": cloudfront.BehaviorOptions(
                    origin=origin,
                    viewer_protocol_policy=cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
                    allowed_methods=cloudfront.AllowedMethods.ALLOW_GET_HEAD_OPTIONS,
                    cache_policy=cloudfront.CachePolicy.CACHING_OPTIMIZED,
                    compress=True,
                    # The cache key has no Host in it, so without the function an
                    # `api.` request for a hashed asset would be served from cache.
                    function_associations=host_router,
                ),
            },
            domain_names=self.viewer_aliases,
            certificate=self.certificate,
            minimum_protocol_version=cloudfront.SecurityPolicyProtocol.TLS_V1_2_2021,
            ssl_support_method=cloudfront.SSLMethod.SNI,
            http_version=cloudfront.HttpVersion.HTTP2_AND_3,
            # North America + Europe. Nobody in this business is served from Asia or
            # South America, and the higher price classes charge for the difference.
            price_class=cloudfront.PriceClass.PRICE_CLASS_100,
            enable_logging=True,
            log_bucket=self.cdn_log_bucket,
            log_file_prefix="cloudfront/",
            log_includes_cookies=False,  # cookies here are session tokens
            web_acl_id=self.web_acl.attr_arn,
            enabled=True,
        )
        # **Update order, and it is load-bearing.** On a rotation deploy the listener
        # rules learn the new value and the distribution starts sending it. If
        # CloudFormation happened to update the distribution first, there would be a
        # gap — however brief — in which edges send a value the ALB does not yet
        # accept. `DependsOn` fixes the order on updates as well as on create, so the
        # ALB is always widened before the edge moves.
        for rule in self.listener_rules:
            distribution.node.add_dependency(rule)
        return distribution

    def _dns_records(self) -> None:
        """`origin-<env>`, `app` and `api` always; the apex and `www` behind `createDnsAliases`.

        **Phase 9 flips the apex and `www`, not Phase 2** (`docs/runbooks/cutover.md`).
        Render answers for those two today (`stacks/dns.py`, `renderRecords`), and
        creating them as CloudFront aliases now would move live traffic off Render
        the moment the nameservers are switched, months early — and could not
        coexist with the Render records anyway. So they sit behind
        `-c createDnsAliases=true`, default **false**, and Phase 9 is what sets it,
        after `meridian-shared-dns` has dropped the Render records.

        `origin-<env>`, `app`/`api` (production) and `staging-app`/`staging-api`
        (staging) are different (ADR 0050): brand-new names that nothing resolves
        today, so pointing them at CloudFront moves no live traffic, and the app and
        the partner API can be exercised on their real names before cutover.
        Construct ids are per name, not per position, so adding a name never
        replaces another's record.
        """
        self.create_dns_aliases = _flag(self, "createDnsAliases", default=False)

        if self.zone is None:
            if self.create_dns_aliases:
                Annotations.of(self).add_warning(
                    "createDnsAliases=true but no -c hostedZoneId was given, so no alias "
                    "records were created. Pass the zone id from meridian-shared-dns."
                )
            return

        route53.ARecord(
            self,
            "OriginRecord",
            zone=self.zone,
            record_name=self.origin_host,
            comment="CloudFront's origin. Not a viewer-facing name; moves no live traffic.",
            target=route53.RecordTarget.from_alias(route53_targets.LoadBalancerTarget(self.alb)),
        )

        aliases = list(self.hosts.new_aliases)
        if self.create_dns_aliases:
            aliases = [*self.hosts.cutover_aliases, *aliases]

        for alias in aliases:
            label = alias.removesuffix(self.domain).rstrip(".") or "apex"
            construct = "".join(part.capitalize() for part in label.split("-"))
            comment = (
                "Phase 9 cutover alias (ADR 0015, ADR 0050)."
                if alias in self.hosts.cutover_aliases
                else "New name, no live traffic before it (ADR 0050)."
            )
            target = route53.RecordTarget.from_alias(
                route53_targets.CloudFrontTarget(self.distribution)
            )
            route53.ARecord(
                self,
                f"ViewerAliasA{construct}",
                zone=self.zone,
                record_name=alias,
                target=target,
                comment=comment,
            )
            route53.AaaaRecord(
                self,
                f"ViewerAliasAaaa{construct}",
                zone=self.zone,
                record_name=alias,
                target=target,
                comment=comment,
            )

    # ---------------------------------------------------------------------- ops

    def _ops_instance(self, ops_volume_key: kms.IKey) -> None:
        """The only path from a laptop to a private database — and it has no open ports.

        SSM Session Manager works by the instance dialling *out* to the SSM service,
        so `ops` has zero ingress rules. `psql` then runs over a port-forwarding
        session (`docs/runbooks/db-access.md`). No key pair, no SSH, no bastion with
        22 open, and every session is recorded in CloudTrail against a named
        identity rather than a shared key.

        **The alternative is ECS Exec** — `aws ecs execute-command` into a one-off
        task — which costs $0 instead of $3.10/month and needs no instance to patch.
        It is not the default because it needs a task definition and a cluster, and
        the cluster arrives in Phase 5a; when it does, an environment can switch by
        setting `-c createOpsInstance=false`. Production defaults to **off** for
        that reason: nothing needs it until there is a production database to reach,
        and an idle instance is an idle thing to patch.
        """
        self.create_ops_instance = _flag(
            self, "createOpsInstance", default=self.env_name == "staging"
        )
        if not self.create_ops_instance:
            return

        role = iam.Role(
            self,
            "OpsInstanceRole",
            role_name=resource_name(self.env_name, "iam", "ops-instance"),
            assumed_by=iam.ServicePrincipal("ec2.amazonaws.com"),
            description="SSM Session Manager access for the ops instance. Nothing else.",
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name("AmazonSSMManagedInstanceCore")
            ],
        )

        # `require_imdsv2` makes CDK emit a launch template whose *name* is the
        # construct id + "LaunchTemplate" ("OpsInstanceLaunchTemplate"). Launch template
        # names are unique per account and region, so a second environment with the same
        # id fails to create. Staging already owns that name and keeps its id (changing
        # it would replace the running instance); every other environment gets its own.
        ops_id = "OpsInstance" if self.env_name == "staging" else f"OpsInstance{self.env_name.title()}"
        self.ops_instance = ec2.Instance(
            self,
            ops_id,
            instance_name=resource_name(self.env_name, "ec2", "ops"),
            instance_type=ec2.InstanceType("t4g.nano"),
            machine_image=ec2.MachineImage.latest_amazon_linux2023(
                cpu_type=ec2.AmazonLinuxCpuType.ARM_64
            ),
            vpc=self.vpc,
            vpc_subnets=ec2.SubnetSelection(subnet_group_name=SUBNET_APP),
            security_group=self.ops_sg,
            role=role,
            # IMDSv2 only: the session-token handshake is what stops a
            # server-side-request-forgery bug from reading the instance's
            # credentials with a single unauthenticated GET.
            require_imdsv2=True,
            # No `key_name`. There is no SSH path, so a key pair would only be a
            # credential to lose.
            block_devices=[
                ec2.BlockDevice(
                    device_name="/dev/xvda",
                    volume=ec2.BlockDeviceVolume.ebs(
                        8,
                        volume_type=ec2.EbsDeviceVolumeType.GP3,
                        encrypted=True,
                        # The environment's `artifacts` CMK. No PHI is ever written
                        # here — `psql` output goes to the operator's terminal, not
                        # to this disk — so the volume is `internal`, like the key.
                        kms_key=ops_volume_key,
                        delete_on_termination=True,
                    ),
                )
            ],
        )
        # The instance reaches Systems Manager over the NAT, so it must not boot before
        # the default route exists. CloudFormation would otherwise be free to create
        # them in either order, and an instance that misses its SSM registration window
        # is an instance with no way in at all — the one failure this design cannot
        # recover from, because there is no SSH.
        for route in self.nat_routes:
            self.ops_instance.node.add_dependency(route)

    # ------------------------------------------------------------------ outputs

    def _outputs(self) -> None:
        CfnOutput(
            self,
            "NatGatewayId",
            value=self.nat_gateway.ref,
            description=(
                "The environment's only NAT gateway, and the largest hourly charge in "
                "this stack. `aws ec2 describe-nat-gateways` after a teardown must be empty."
            ),
        )
        CfnOutput(
            self,
            "AlbDnsName",
            value=self.alb.load_balancer_dns_name,
            description="Origin load balancer. A direct request to it returns 403.",
        )
        CfnOutput(
            self,
            "DistributionDomainName",
            value=self.distribution.distribution_domain_name,
            description="CloudFront hostname. Serves 503 until Phase 5a attaches services.",
        )
        CfnOutput(
            self,
            "OriginVerifySecretArn",
            value=self.origin_verify_secret_arn,
            description=(
                "Imported from meridian-<env>-data, which owns it so a staging teardown "
                "cannot delete it. Rotate with "
                "docs/runbooks/rotate-origin-verify-secret.md."
            ),
        )
        # L-F: on a first deploy there is no version id to print. `AWS::SecretsManager::
        # Secret` exposes no version-id attribute — `Ref` is the ARN, and the only
        # `Fn::GetAtt` it has is `Id` — so this output cannot *be* the id. It points at
        # the one command that can read it instead of printing a label that looks like
        # an answer.
        CfnOutput(
            self,
            "OriginVerifyCloudFrontVersion",
            value=self.origin_verify_cloudfront_version
            or (
                "UNPINNED - CloudFront resolved the AWSCURRENT label. Read the id it "
                "resolved to: aws secretsmanager describe-secret --secret-id "
                f"{self.origin_verify_secret_arn} --query VersionIdsToStages"
            ),
            description=(
                "The secret VERSION id CloudFront sends. Pass it back as "
                "-c originVerifyCloudFrontVersionId=... on every deploy; the runbook "
                "explains why a staging label here is an outage waiting for a rotation."
            ),
        )
        CfnOutput(
            self,
            "OriginVerifyAlbAcceptedVersions",
            value=", ".join(
                v
                for v in (
                    self.origin_verify_active_version,
                    self.origin_verify_previous_version,
                )
                if v
            ),
            description=(
                "The secret versions the ALB listener rules accept. Two during and "
                "after a rotation, one before the first."
            ),
        )
        CfnOutput(
            self,
            "ApiPathPatternCount",
            value=str(len(self.api_patterns)),
            description="ALB patterns generated from web/next.config.mjs (edge_paths.py).",
        )
