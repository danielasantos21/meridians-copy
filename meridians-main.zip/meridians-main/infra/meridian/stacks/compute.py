"""`meridian-<env>-compute` — ECR, the ECS cluster, the task definitions, the services.

Phase 5a (`docs/aws-migration-plan.md` §2.5, §3; ADR 0002, ADR 0020). The
constraints below are load-bearing, not tuning, and the plan asks for them to be
written into the CDK as comments:

* **`desiredCount: 1`, `maximumPercent: 100`, `minimumHealthyPercent: 0` on the
  `api` service until Phase 11 — in BOTH environments.** Two api tasks mis-book
  journal entries *silently*, because five wizards keep their state in process
  memory (`web_app.py:7013, 8648, 9807, 10348, 10892`, `src/run_store.py:5-9`)
  and `src/api/v2/auth_routes.py` parks the half-finished MFA sign-in in a
  module-level dict. The price of that setting is **3-6 minutes of hard downtime
  per api deploy** — deploy outside business hours and never during a close.
  Phase 11 serializes the wizards out of memory and lifts it. A
  `HealthyHostCount > 1` alarm on the api target group is the tripwire that the
  setting has been undone. The `web` service has no such constraint and runs
  `WEB_DESIRED_COUNT` — 1 in staging, 2 in production.
* **One uvicorn worker** (`Dockerfile.api`'s CMD) — same reason, correctness
  not performance. It used to say `--workers 1 --worker-class gthread
  --threads 8`; there is no gunicorn in this image and there has not been since
  ADR 0023. The concurrency that matters now is anyio's worker thread pool,
  which is where every Flask view under the WSGI mount runs: **40** threads
  against `PG_POOL_MAX` (8). What keeps the two in sight of each other is the
  permit in `src/pg.py`, sized to `PG_POOL_MAX` and waited on for
  `PG_POOL_TIMEOUT`, so the surplus waits rather than fails. It is NOT
  `--limit-concurrency`, which was dropped in P5AR2-08: uvicorn counts that per
  connection and holds the count across keep-alive, so it refused idle tabs and
  missed real bursts.
* **`FLASK_ENV=production` in the task definition.** `src/auth.py:224` keys the
  `Secure` cookie flag off it; a missing value silently ships session cookies
  that are not HTTPS-only.
* **`ProxyFix(x_for=2)`** in both Flask and FastAPI: CloudFront and the ALB are
  two proxies. `x_for=1` re-creates the bug commit `71decf2` fixed, where rate
  limits keyed on the edge IP. That is an application change and is **not** made
  here; it lands with the FastAPI port. Recorded in `docs/migration-tracker.md`.
* **No plaintext credentials in `environment:`.** Two secrets reach a task — the
  database password and the Cognito web client's secret, both `api` (a third, the
  Resend key, only on `-c emailBackend=resend`) — through `secrets:`, which **ECS
  resolves with the execution role**; see `_execution_role` for why that is not
  the task role.
  The `web` task holds none: the origin-verify value it carried for one round
  was for a proxy hop the ALB's listener rules make unreachable (P5AR5-01).
* ARM64 (Graviton) images throughout: `api` 1 vCPU / 2 GB, `web` 0.25 / 0.5,
  `worker` 0.5 / 1 from Phase 11.
* Roles `meridian-<env>-iam-ecs-api-task`, `-ecs-web-task`, `-ecs-execution`:
  no wildcard actions anywhere, and the three statements that are
  `Resource: "*"` are three AWS defines that way. All three are listed with
  their reasons in `infra/tests/test_compute.py`, which fails on a fourth.

WHERE THE SERVICES LIVE, AND WHY THIS STACK DEPENDS ON `edge`
--------------------------------------------------------------
The ALB, its listener and its two (empty) target groups are the `edge` stack's;
this stack registers the services into them. That makes `compute` depend on
`edge`, which is new: ADR 0020's split relied on *nothing* importing from `edge`
so that destroying it could never reach the VPC or the database.

That property is unchanged — `edge` still imports from `vpc`, and `vpc` and
`data` still import from nobody — but the **teardown order now has two steps**:

    cdk destroy meridian-staging-api meridian-staging-observability \\
                meridian-staging-compute          # first
    cdk destroy meridian-staging-edge             # then

CloudFormation refuses to delete a stack whose exports are in use, so getting
this wrong is a refusal rather than an outage. `docs/runbooks/` and
`infra/README.md` carry the order.

THE PHASE 11 WORKER IS HERE, BEHIND A FLAG
------------------------------------------
With `-c worker_enabled=true` (off by default) this stack also holds the SQS job
queue and its DLQ, the sweep schedule and the `svc-worker` service
(`stacks/worker.py`, tasks H1/H2). It used to be pencilled in for
`meridian-<env>-api`; `stacks/worker.py` says why it is not there — the deploy
workflow ships this stack alone, and the queue must exist before the worker
starts. Off, this template is byte-identical to the one before the flag.
`meridian-<env>-api` keeps the `/api/v3` platform (Phase 12). The listener
**rules** stay in `edge` (they are generated from `web/next.config.mjs` by
`meridian/edge_paths.py` and must not be retyped).

Staging's compute stack is destroyed between phases (ADR 0008 / D-15).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aws_cdk import Aws, CfnOutput, Duration, RemovalPolicy, Stack, Tags, Token
from aws_cdk import aws_ecr as ecr
from aws_cdk import aws_ecs as ecs
from aws_cdk import aws_elasticloadbalancingv2 as elbv2
from aws_cdk import aws_iam as iam
from aws_cdk import aws_kms as kms
from aws_cdk import aws_logs as logs
from aws_cdk import aws_secretsmanager as secretsmanager
from constructs import Construct

from ..api_platform import (
    event_bus_name,
    queue_url,
    webhook_dlq_name,
    webhook_queue_name,
)
from ..config import (
    ASK_MONTHLY_CAP_USD,
    EnvConfig,
    api_platform_enabled,
    bedrock_region,
    ecw_db_enabled,
    ecw_mart_enabled,
    ecw_org_id,
    qbo_environment,
    qbo_oauth_enabled,
    worker_enabled,
)
from ..naming import resource_name
from .auth import AuthStack
from .base import EDGE_REGION, EnvStack
from .data import (
    LOG_RETENTION,
    QBO_TOKEN_KMS_ACTIONS,
    QBO_TOKEN_KMS_KEY_ENV,
    QBO_TOKEN_KMS_PURPOSE,
    REPOSITORY_PURPOSES,
    DataStack,
    mart_secret_arn,
)
from .edge import API_HEALTH_PATH, EdgeStack
from .vpc import API_PORT, SUBNET_APP, VPC_CIDR, WEB_PORT, VpcStack

if TYPE_CHECKING:
    from .mart import MartSync
    from .worker import JobWorker

#: The two images. The names are the ECR repository purposes and the container
#: names, so a log stream, a task definition and a repository all read the same.
API = "api"
WEB = "web"

#: `api`: 1 vCPU / 2 GB. A revenue run holds a period's transactions plus an
#: openpyxl workbook in memory, and openpyxl is not frugal; 2 GB is where the
#: trial stack stopped being the constraint.
API_CPU = 1024
API_MEMORY_MIB = 2048

#: **40 GiB of ephemeral storage, not the 20 GiB default.** WeasyPrint's font
#: cache, an uploaded billing export, the enriched workbook it produces and the
#: ZIP bundle of a results page can all be on disk at once. Fargate's minimum is
#: 21 GiB and the first 20 are free; the extra 20 cost about $0.05/month.
API_EPHEMERAL_GIB = 40

#: `web`: the smallest Fargate size there is. Next.js in standalone mode serves
#: pre-built pages and proxies everything else.
WEB_CPU = 256
WEB_MEMORY_MIB = 512

#: **120 seconds between SIGTERM and SIGKILL.** The default is 30, and a revenue
#: run that is writing journal entries when a deploy replaces the task needs
#: longer than that to finish the statement it is in. 120 is the Fargate maximum
#: and the plan's figure.
STOP_TIMEOUT = Duration.seconds(120)

#: What ECS waits before the first container health check counts. A cold api
#: container imports pandas, openpyxl and WeasyPrint before it serves anything.
HEALTH_CHECK_GRACE = Duration.seconds(60)

#: `web` only. The api service is pinned to one task until Phase 11 — see the
#: module docstring.
WEB_DESIRED_COUNT = {"staging": 1, "production": 2}

#: The api service's count, in every environment. Not a per-environment knob on
#: purpose: a "let us try two in staging" that works is the argument for two in
#: production, and the reason it must not happen is a correctness one that
#: staging would not reveal.
API_DESIRED_COUNT = 1

#: The tag the services deploy when nothing says otherwise. The default exists
#: so `cdk synth` works with no context, and it is a name no build ever pushes
#: rather than `latest`, which under `IMMUTABLE` tag mutability could be pushed
#: exactly once and would then be a lie for ever.
DEFAULT_IMAGE_TAG = "bootstrap"

#: The context keys that carry a real tag, **one per image**.
#:
#: `.github/workflows/deploy.yml` passes both as the commit sha
#: (`-c apiImageTag=${{ github.sha }} -c webImageTag=${{ github.sha }}`), so a
#: normal deploy ships the two images built from one commit. They are
#: nevertheless separate keys, because the two images are separately buildable
#: and a rollback is frequently one of them: pinning `web` to the last good sha
#: while `api` moves forward is the difference between a two-minute fix and
#: reverting a merge.
#:
#: `imageTag` is the older single key and is still honoured as the fallback for
#: both, so an existing `-c imageTag=<sha>` keeps working. Precedence is
#: per-image key → `imageTag` → `DEFAULT_IMAGE_TAG`.
API_IMAGE_TAG_CONTEXT = "apiImageTag"
WEB_IMAGE_TAG_CONTEXT = "webImageTag"
SHARED_IMAGE_TAG_CONTEXT = "imageTag"

#: `-c emailBackend=resend` — the SES → Resend rollback, as a deploy rather than a code
#: change (tracker T:143, `docs/runbooks/email-cutover.md` §2). Default `ses`: the task
#: definition is the post-cutover shape. Anything else is refused at synth, because a
#: typo here would otherwise deploy a task that sends nothing.
EMAIL_BACKEND_CONTEXT = "emailBackend"
EMAIL_BACKENDS_ON_ECS = ("ses", "resend")

#: The Resend key the rollback maps into `RESEND_API_KEY`, as
#: `meridian-<env>/resend-api-key`. **Created by hand, before the rollback deploy**,
#: on the environment's `logs` CMK (runbook §2): CDK only references it by name. A
#: secret CDK created in the same deploy would be empty when the task started, and an
#: empty key is Resend's "not configured, skipping email" — silence, not an error. A
#: missing secret, on the other hand, stops the task at start and the deployment
#: circuit breaker rolls it back, which is the loud failure wanted here.
RESEND_SECRET_NAME = "resend-api-key"  # noqa: S105 a name, not a secret

#: The QuickBooks app's OAuth client (D18, critic Stage 1 M-10), as
#: `meridian-<env>/qbo-oauth`: JSON `{"client_id": ..., "client_secret": ...}`. **Created
#: by hand, before the first `-c worker_enabled=true` deploy**, on the environment's
#: `logs` CMK (`docs/runbooks/rotate-secrets.md`), for the Resend key's reason: CDK only
#: references it by name, and a missing secret stops the task at start (loud) where an
#: empty one would be the "Connect QuickBooks" card answering 503 (silent). Mapped into
#: the api by `-c qboOAuth=true` (or `worker_enabled`, whose `qbo_push` refresh needs it
#: too; `config.qbo_oauth_enabled`), **off by default** so a deploy before the secret
#: exists still starts. **Operator: create the secret, then pass `-c qboOAuth=true` on
#: every production `compute` deploy from then on** (Render's production connects
#: QuickBooks today; without the flag the AWS api's "Connect QuickBooks" answers 503). The
#: token key (`QBO_TOKEN_KMS_KEY_ARN`, ADR 0044) is behind neither flag (T:186): stored
#: tokens are sealed and re-sealed (`scripts/encrypt_qbo_tokens.py`) regardless.
QBO_OAUTH_SECRET_NAME = "qbo-oauth"  # noqa: S105 a name, not a secret
#: The eCW data mart login for the P&L run, as `meridian-<env>/ecw-db`: JSON
#: `{"host": ..., "dbname": ..., "user": ..., "password": ...}`, created by hand on the
#: `logs` CMK like `qbo-oauth`, mapped into the api only with `-c ecwDb=true`.
ECW_DB_SECRET_NAME = "ecw-db"  # noqa: S105 a name, not a secret
#: `src/qbo_client.DEFAULT_CALLBACK_PATH` - a test holds the two equal (infra does not
#: import `src`). Registered at Intuit for each environment's public hostname.
QBO_CALLBACK_PATH = "/api/v2/qbo/connection/callback"

#: The Cognito admin calls the api makes for a person signing in (`src/cognito.py`):
#: the confidential client's password sign-in and its MFA challenge, turning TOTP on
#: after enrolment, and `ListUsers` for the members screen's addresses (the email lives
#: in the pool, not in `user_profiles`). Each takes the `userpool` resource, so the one
#: pool ARN scopes them all. `ForgotPassword`, `ConfirmForgotPassword`, `RevokeToken`,
#: `AssociateSoftwareToken` and `VerifySoftwareToken` are absent on purpose: they are
#: unauthenticated Cognito operations, authorized by the client secret or the user's
#: own token, not by IAM. Unconditional — sign-in does not depend on
#: `-c enableApiPlatform`, unlike the seven app-client actions in `api.py`.
#: Ask Meridian's model chain, `FAST + SMART` in `src/bi_ask.py` (a test keeps the two in step).
#: Each is a *global* cross-Region inference profile id; the foundation model behind it is the id
#: without the `global.` prefix. The code calls `client.messages.create` (InvokeModel), never the
#: streaming API, so `InvokeModelWithResponseStream` is deliberately not granted.
ASK_PROFILE_IDS = (
    "global.anthropic.claude-haiku-4-5-20251001-v1:0",
    "global.anthropic.claude-sonnet-5-5",
    "global.anthropic.claude-sonnet-4-6",
)

COGNITO_SIGN_IN_ACTIONS = (
    # An invite creates the invitee's account (self sign-up is off).
    "cognito-idp:AdminCreateUser",
    # A remembered browser skips the MFA code for 30 days: read the device's age,
    # forget it once older (Cognito never expires a remembered device itself).
    "cognito-idp:AdminForgetDevice",
    "cognito-idp:AdminGetDevice",
    "cognito-idp:AdminGetUser",
    "cognito-idp:AdminInitiateAuth",
    "cognito-idp:AdminRespondToAuthChallenge",
    "cognito-idp:AdminSetUserMFAPreference",
    "cognito-idp:ListUsers",
)


def _allow_secret_read(role: iam.Role, sid: str, secret_arn: str, key: kms.IKey) -> None:
    """`GetSecretValue` on one secret ARN, written by hand rather than granted.

    **`secret.grant_read(role)` would invert the stack dependency.** For a secret
    that knows its customer-managed key, `grantRead` also calls
    `encryptionKey.grantDecrypt(ViaServicePrincipal('secretsmanager...', role))`,
    and a `ViaServicePrincipal` reports no `principalAccount`. CDK's
    `Grant.addToPrincipalOrResource` reads that as "the grantee might be in
    another account", so it writes the statement into the **key policy** rather
    than into the role — which makes the `data` stack reference a role ARN in the
    `compute` stack. With `compute` already depending on `edge` (the target
    groups) and `edge` on `data` (the logs key), that closes a cycle and synth
    refuses outright:

        DependencyCycle: 'Data' depends on 'Edge'
        (Data -> Compute/ExecutionRole/Resource.Arn, ...)

    Writing the statements on the role side produces exactly the permissions
    `grantRead` intended and leaves every dependency arrow pointing one way. The
    IAM half is sufficient on its own because each CMK's policy already delegates
    to IAM for `role/meridian-<env>-*` (`data.py`, `AllowThisEnvironmentsRoles`)
    — the boundary §2.4 asks for, which these role names satisfy.

    The same trap catches `ecs.Secret.from_secrets_manager`, which grants on the
    caller's behalf; `ComputeStack.__init__` imports the credential by ARN so
    that the construct it grants on has no key to reach for.
    """
    role.add_to_policy(
        iam.PolicyStatement(
            sid=f"Read{sid}",
            actions=["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"],
            resources=[secret_arn],
        )
    )
    role.add_to_policy(
        iam.PolicyStatement(
            sid=f"Decrypt{sid}ThroughSecretsManager",
            actions=["kms:Decrypt"],
            resources=[key.key_arn],
            conditions={
                "StringEquals": {"kms:ViaService": f"secretsmanager.{Aws.REGION}.amazonaws.com"}
            },
        )
    )


def ses_region(dns_region: str) -> str:
    """The region the SES ARNs are composed in — checked, not assumed.

    `EDGE_REGION` was written into both ARNs as a constant while the `dns`
    stack that actually creates the identity and the configuration set took its
    region from somewhere else entirely. Two independent spellings of one fact:
    move the shared stack and the grant keeps naming
    `arn:…:ses:us-east-1:…:identity/meridiansgrp.com`, which no longer exists —
    and the failure is not a synth error, it is every invite denied by IAM
    after a deploy that reported success.

    So `infra/app.py` hands over `dns.region` and this compares it. Like
    `assert_edge_region`, it can only compare a **concrete** region: an offline
    `cdk synth` (CI, the tests) leaves it a token, and a token is not a region.
    Unresolved, the constant is returned and synth is byte-identical to before.
    """
    if Token.is_unresolved(dns_region):
        return EDGE_REGION
    if dns_region != EDGE_REGION:
        raise ValueError(
            f"The SES identity and configuration set live in {dns_region!r} (the shared "
            f"dns stack), but the api task role's grant is composed for {EDGE_REGION!r}. "
            "An ARN for the wrong region denies every send. Deploy the dns stack into "
            f"{EDGE_REGION} (ADR 0018), or change EDGE_REGION and both together."
        )
    return dns_region


def _allow_ses_send(
    role: iam.Role,
    stack: Stack,
    identity_name: str,
    configuration_set_name: str,
    from_address: str,
    region: str = EDGE_REGION,
) -> None:
    """`SendEmail`/`SendRawEmail` on one identity, one configuration set, one From.

    Three narrowings, each of which is the whole point of writing this by hand
    instead of `iam.PolicyStatement(actions=["ses:*"], resources=["*"])` — which
    is what the AWS documentation's example amounts to:

    * **Two resources, not `*`.** The identity ARN and the configuration set
      ARN. SES authorizes a v2 `SendEmail` against both, so naming both is what
      makes "send only as Meridian, only through the configuration set that
      publishes bounces" an IAM fact rather than a convention in the code. A
      send that omits `ConfigurationSetName`, or names another one, is denied.
    * **`ses:FromAddress` on the one mailbox.** Without it, the task may send as
      any address on the verified domain — `billing@`, `andres@`, anything. With
      it, the blast radius of a compromised task is mail from `no-reply@`, which
      is the address people already know not to reply to.
    * **Account-level identity, environment-level grant.** The identity is
      shared (one domain, one SES account), so the ARN is composed from the
      identity NAME rather than imported as a construct: staging and production
      each get their own statement naming the same identity, and neither stack
      takes a dependency on the other environment.

    `ses:SendRawEmail` is granted alongside `ses:SendEmail` because SESv2 maps a
    MIME send onto it; nothing here sends raw MIME today, and an attachment (a
    JE workbook, say) would — the day that is wanted, this line is why it is a
    code change and not an IAM change.
    """
    identity_arn = stack.format_arn(
        service="ses",
        region=region,
        resource="identity",
        resource_name=identity_name,
    )
    configuration_set_arn = stack.format_arn(
        service="ses",
        region=region,
        resource="configuration-set",
        resource_name=configuration_set_name,
    )
    role.add_to_policy(
        iam.PolicyStatement(
            sid="SendMeridianEmail",
            actions=["ses:SendEmail", "ses:SendRawEmail"],
            resources=[identity_arn, configuration_set_arn],
            conditions={"StringEquals": {"ses:FromAddress": from_address}},
        )
    )


def _flag(scope: Construct, name: str, *, default: bool) -> bool:
    """A boolean CDK context value. `-c name=false` arrives as the *string* "false"."""
    raw = scope.node.try_get_context(name)
    if raw is None:
        return default
    if isinstance(raw, bool):
        return raw
    return str(raw).strip().lower() in ("1", "true", "yes", "on")


def email_backend(scope: Construct) -> str:
    """`-c emailBackend`, checked: `ses` (default) or `resend`, nothing else."""
    raw = str(scope.node.try_get_context(EMAIL_BACKEND_CONTEXT) or "ses").strip().lower()
    if raw not in EMAIL_BACKENDS_ON_ECS:
        raise ValueError(
            f"-c {EMAIL_BACKEND_CONTEXT}={raw!r}: the api task can send through "
            f"{' or '.join(EMAIL_BACKENDS_ON_ECS)} only. `disabled` is a development "
            "setting, never a deployed one."
        )
    return raw


class ComputeStack(EnvStack):
    """ECR repositories, the ECS Fargate cluster, task definitions and services."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_config: EnvConfig,
        vpc_stack: VpcStack,
        data_stack: DataStack,
        edge_stack: EdgeStack,
        auth_stack: AuthStack,
        ses_identity_name: str,
        ses_configuration_set_name: str,
        ses_from_address: str,
        ses_region: str = EDGE_REGION,
        **kwargs: Any,
    ) -> None:
        super().__init__(scope, construct_id, env_config=env_config, **kwargs)

        self.vpc = vpc_stack.vpc
        self.app_sg = vpc_stack.app_sg
        self.data = data_stack
        self.edge = edge_stack
        # SES, from the shared `dns` stack (Phase 1, ADR 0014 / ADR 0025). Names
        # and one address — no ARN, no credential. The identity and the
        # configuration set are account-level and shared by both environments;
        # what is per-environment is the grant below and the `env` message tag.
        self.ses_identity_name = ses_identity_name
        self.ses_configuration_set_name = ses_configuration_set_name
        self.ses_from_address = ses_from_address
        #: Where the identity and the configuration set actually are. Checked
        #: against `EDGE_REGION` by `ses_region()` in `infra/app.py`.
        self.ses_region = ses_region
        self.image_tags = {
            API: self._image_tag(API_IMAGE_TAG_CONTEXT),
            WEB: self._image_tag(WEB_IMAGE_TAG_CONTEXT),
        }

        # The database credential, **imported by ARN** rather than used as the
        # `data` stack's own construct. `ecs.Secret.from_secrets_manager(secret, …)`
        # calls `secret.grantRead(executionRole)` on our behalf, and on a
        # construct that knows its customer-managed key that grant lands in the
        # KEY policy — in the `data` stack, naming a `compute` role, which closes
        # a dependency cycle. An imported secret has no `encryptionKey`, so the
        # same call writes only the IAM statement and `_allow_secret_read`
        # supplies the `kms:Decrypt` half explicitly. See that function.
        self.db_app_secret = secretsmanager.Secret.from_secret_complete_arn(
            self, "DbAppSecretRef", data_stack.db_app_secret.secret_arn
        )
        # Cognito (T:102). The `auth` stack is persistent and never imports from here,
        # so this import adds no cycle and no teardown constraint: staging destroys
        # `compute` every session and `auth` never. The client secret is imported by
        # ARN for the same reason the database credential is (see above): the grant
        # stays on the execution role and never reaches the `logs` key's policy.
        self.auth = auth_stack
        self.cognito_client_secret = secretsmanager.Secret.from_secret_complete_arn(
            self, "CognitoWebClientSecretRef", auth_stack.web_client_secret.secret_arn
        )
        # FLASK_SECRET_KEY, imported by ARN for the same reason as the credential above.
        self.flask_secret_key = secretsmanager.Secret.from_secret_complete_arn(
            self, "FlaskSecretKeyRef", data_stack.flask_secret_key.secret_arn
        )
        #: `ses` or `resend`. See EMAIL_BACKEND_CONTEXT.
        self.email_backend = email_backend(self)
        #: The rollback's Resend key, referenced by NAME (it is created by hand), or None.
        self.resend_api_key: secretsmanager.ISecret | None = (
            secretsmanager.Secret.from_secret_name_v2(
                self, "ResendApiKeyRef", f"meridian-{self.env_name}/{RESEND_SECRET_NAME}"
            )
            if self.email_backend == "resend"
            else None
        )
        #: The QuickBooks OAuth client, referenced by NAME, only with `qboOAuth` (or
        #: `worker_enabled`); None otherwise, which leaves the template as it was.
        self.qbo_oauth_secret: secretsmanager.ISecret | None = (
            secretsmanager.Secret.from_secret_name_v2(
                self, "QboOauthSecretRef", f"meridian-{self.env_name}/{QBO_OAUTH_SECRET_NAME}"
            )
            if qbo_oauth_enabled(self)
            else None
        )
        #: The eCW data mart login, by NAME, only with `ecwDb`; None leaves the template as it was.
        self.ecw_db_secret: secretsmanager.ISecret | None = (
            secretsmanager.Secret.from_secret_name_v2(
                self, "EcwDbSecretRef", f"meridian-{self.env_name}/{ECW_DB_SECRET_NAME}"
            )
            if ecw_db_enabled(self)
            else None
        )
        #: The api's read-only login to the RDS copy of the eCW mart (`-c ecwMart=true`, ADR
        #: 0053), imported by the data stack's always-present, named export (`mart_secret_arn`),
        #: NOT by passing the secret object, so the data stack is the same with the flag on
        #: or off and no CDK auto-export is ever created. None leaves the template as it was.
        #: A missing/invalid `-c ecwOrgId` fails here, at synth, naming the flag.
        self.ecw_org_id: str | None = ecw_org_id(self) if ecw_mart_enabled(self) else None
        self.db_mart_reader_secret: secretsmanager.ISecret | None = (
            secretsmanager.Secret.from_secret_complete_arn(
                self, "DbMartReaderSecretRef", mart_secret_arn(self.env_name, "reader")
            )
            if ecw_mart_enabled(self)
            else None
        )
        # **No reference to the origin-verify secret here** (P5AR5-01). The `web`
        # container held it for one round, so its proxy hop could dial the ALB
        # directly; the ALB claims `/api/*`, `/auth/*` and `/static/*` before the
        # `/*` rule that reaches that container, so the hop never happened. The
        # consumers are CloudFront and the ALB listener rules, both in `edge`, and
        # a rotation is `docs/runbooks/rotate-origin-verify-secret.md`'s two
        # deploys of one stack again.

        self.repositories = self._repositories()
        self.log_groups = self._log_groups()
        self.cluster = self._cluster()

        self.execution_role = self._execution_role()
        self.api_task_role = self._api_task_role()
        self.web_task_role = self._web_task_role()

        self.api_task_definition = self._api_task_definition()
        self.web_task_definition = self._web_task_definition()

        self.api_service = self._service(
            API,
            self.api_task_definition,
            API_DESIRED_COUNT,
            self.edge.api_target_group,
        )
        self.web_service = self._service(
            WEB,
            self.web_task_definition,
            WEB_DESIRED_COUNT[self.env_name],
            self.edge.web_target_group,
        )

        #: Phase 11 H1 (`-c worker_enabled=true`): the job queue, its DLQ, the sweep
        #: schedule and the worker service (`stacks/worker.py`). `None` with the flag
        #: off, which leaves this template exactly as it was.
        self.worker: JobWorker | None = self._worker() if worker_enabled(self) else None

        #: `-c ecwMart=true` (ADR 0053): the nightly eCW mart copy's task, roles, log group and
        #: schedule (`stacks/mart.py`). `None` with the flag off: the template is as it was.
        self.mart_sync: MartSync | None = self._mart_sync() if ecw_mart_enabled(self) else None

        self._outputs()

    def _worker(self) -> JobWorker:
        """The `JobWorker` construct. Imported here: `worker.py` imports this module."""
        from .worker import JobWorker

        return JobWorker(self, "Worker", compute=self)

    def _mart_sync(self) -> MartSync:
        """The `MartSync` construct. Imported here: `mart.py` imports this module."""
        from .mart import MartSync

        return MartSync(self, "MartSync", compute=self)

    # ------------------------------------------------------------- image tags
    def _image_tag(self, key: str) -> str:
        """The tag for one image: its own context key, then `imageTag`, then the default.

        Written as a lookup rather than an argument because a task definition
        that silently falls back to `bootstrap` is indistinguishable, in the
        console, from one that was deployed with a real tag — so the fallback
        chain has to be in one place where it can be tested.
        """
        for candidate in (key, SHARED_IMAGE_TAG_CONTEXT):
            value = self.node.try_get_context(candidate)
            if value:
                return str(value)
        return DEFAULT_IMAGE_TAG

    # ------------------------------------------------------------------ ECR
    def _repositories(self) -> dict[str, ecr.IRepository]:
        """The two repositories, looked up by name from the persistent `data` stack.

        They used to be created here, `RETAIN`ed, in a stack that is destroyed every
        staging session: the second `up` then collided with the retained names, and
        the very first deploy had no repository to push an image into before its
        services needed one. Created in `data` (never destroyed), they exist before
        the first build and survive every teardown. By name, not by cross-stack
        export, so `data` never holds an export `compute` would pin.
        """
        return {
            purpose: ecr.Repository.from_repository_name(
                self,
                f"Repository{purpose.capitalize()}",
                resource_name(self.env_name, "ecr", purpose),
            )
            for purpose in REPOSITORY_PURPOSES
        }

    # ----------------------------------------------------------------- logs
    def _log_groups(self) -> dict[str, logs.LogGroup]:
        """Application log groups, created here rather than by ECS.

        Left to itself, `awslogs` creates a log group with **no retention and no
        customer-managed key** the first time a task starts, and nothing ever
        says so. Creating them here is what puts them on the environment's
        `logs` CMK — the `internal`-classified one — and on the estate's 400-day
        retention.

        **400 days, and therefore no PHI in a log line.** Retention is what makes
        `scripts/lint_no_phi_logging.py` a build-breaking lint rather than a
        style preference: anything logged is a 400-day problem in a log group a
        great many principals can read.
        """
        groups: dict[str, logs.LogGroup] = {}
        for purpose in (API, WEB, "exec"):
            groups[purpose] = logs.LogGroup(
                self,
                f"LogGroup{purpose.capitalize()}",
                log_group_name=f"/meridian/{self.env_name}/ecs/{purpose}",
                retention=LOG_RETENTION,
                encryption_key=self.data.keys["logs"],
                # Destroyed with the stack in staging so a teardown does not
                # leave a log group that the next deploy cannot recreate.
                removal_policy=(
                    RemovalPolicy.DESTROY
                    if self.env_config.destroyed_between_phases
                    else RemovalPolicy.RETAIN
                ),
            )
        return groups

    # -------------------------------------------------------------- cluster
    def _cluster(self) -> ecs.Cluster:
        """The Fargate cluster, with Container Insights and audited ECS Exec.

        **Container Insights** is what turns "the task restarted" into a number
        anyone can alarm on: task and service CPU, memory and restart counts, at
        about $0.30/month for two services. Without it the only evidence a task
        was killed for memory is a stopped-task reason that ages out in an hour.

        **ECS Exec is on, and every session is recorded.**
        `docs/runbooks/db-access.md` names `aws ecs execute-command` as the
        alternative to the SSM ops instance — the task is already in the `app`
        security group the database admits, so it needs no tunnel. An
        interactive shell in a task that can reach PHI is an access event under
        45 CFR 164.312(b), so the cluster sends every session's input and output
        to its own log group, encrypted with the `logs` CMK. A session that
        cannot be logged does not start.
        """
        return ecs.Cluster(
            self,
            "Cluster",
            cluster_name=resource_name(self.env_name, "ecs", "main"),
            vpc=self.vpc,
            execute_command_configuration=ecs.ExecuteCommandConfiguration(
                kms_key=self.data.keys["logs"],
                log_configuration=ecs.ExecuteCommandLogConfiguration(
                    cloud_watch_log_group=self.log_groups["exec"],
                    cloud_watch_encryption_enabled=True,
                ),
                logging=ecs.ExecuteCommandLogging.OVERRIDE,
            ),
            container_insights_v2=ecs.ContainerInsights.ENABLED,
        )

    # ---------------------------------------------------------------- roles
    def _execution_role(self) -> iam.Role:
        """What the ECS **agent** uses to start a task: pull, log, and fetch secrets.

        This is not the task role and the difference matters. The agent resolves
        everything in a container's `secrets:` block **before** the container
        starts, using this role — so the database password is read by the agent
        and handed to the process, and the process itself never holds
        permission to read it again. Putting `GetSecretValue` on the *task* role
        instead would let any code in the container fetch the credential at will,
        which is strictly more access for no gain.

        **The one `Resource: "*"`:** `ecr:GetAuthorizationToken` takes no
        resource — it mints a registry-wide token and AWS defines it as
        account-level. Every other ECR action here is scoped to the two
        repositories this stack creates.
        """
        role = iam.Role(
            self,
            "ExecutionRole",
            role_name=resource_name(self.env_name, "iam", "ecs-execution"),
            assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            description=(
                f"Meridian {self.env_name}: the ECS agent. Pulls images, writes logs, "
                "resolves the task definitions' secrets."
            ),
        )
        # **The pull and the log writes are not written here on purpose.**
        # `ContainerImage.from_ecr_repository` and `LogDriver.aws_logs` each
        # grant this role what they need when the container is added — scoped to
        # the two repositories and the three log groups respectively, which is
        # exactly what a hand-written statement would say. Writing them here as
        # well produced a policy with every statement in it twice: harmless to
        # IAM, and a document an auditor has to read carefully to discover that
        # the duplicate is a duplicate. `infra/tests/test_compute.py` asserts
        # the resulting statements instead of trusting either source.
        #
        # What is left is the one thing nothing grants automatically:
        _allow_secret_read(
            role, "DbAppSecret", self.db_app_secret.secret_arn, self.data.keys["rds"]
        )
        # The Cognito web client's secret (T:102), on the `logs` CMK — the key the
        # `auth` stack created it under.
        _allow_secret_read(
            role,
            "CognitoWebClientSecret",
            self.cognito_client_secret.secret_arn,
            self.data.keys["logs"],
        )
        # FLASK_SECRET_KEY (web_app.py will not start without it), on the `logs` CMK.
        _allow_secret_read(
            role, "FlaskSecretKey", self.flask_secret_key.secret_arn, self.data.keys["logs"]
        )
        # The Resend key, only on `-c emailBackend=resend`. Referenced by name, so
        # the ARN has no random suffix and IAM needs the `-??????` form of it.
        if self.resend_api_key is not None:
            _allow_secret_read(
                role,
                "ResendApiKey",
                f"{self.resend_api_key.secret_arn}-??????",
                self.data.keys["logs"],
            )
        # The QuickBooks OAuth client (M-10), only with `qboOAuth` / `worker_enabled`; by name, so the
        # `-??????` form, on the `logs` CMK like the Resend key.
        if self.qbo_oauth_secret is not None:
            _allow_secret_read(
                role,
                "QboOauthSecret",
                f"{self.qbo_oauth_secret.secret_arn}-??????",
                self.data.keys["logs"],
            )
        if self.ecw_db_secret is not None:
            _allow_secret_read(
                role,
                "EcwDbSecret",
                f"{self.ecw_db_secret.secret_arn}-??????",
                self.data.keys["logs"],
            )
        if self.db_mart_reader_secret is not None:
            _allow_secret_read(
                role,
                "DbMartReaderSecret",
                self.db_mart_reader_secret.secret_arn,
                self.data.keys["rds"],
            )
        # **No other secret ARN on this role** (P5AR5-01). The origin-verify value
        # was granted here for one round, because the `web` task definition named
        # it; nothing in this stack reads that secret now. `db-phi` stays a
        # human's credential and `phi-hmac-key` belongs to the api TASK role
        # because nothing injects it.
        return role

    def _api_task_role(self) -> iam.Role:
        """What the **application** runs as: S3, the PHI key, and ECS Exec.

        Deliberately *not* granted:

        * `meridian-<env>-secret-db-phi`. That is `phi_access`'s password — the
          credential that reads patient identifiers. `src/phi.py` never connects
          as `phi_access`; it connects as `meridian_app` and issues `SET ROLE`,
          which is why revision 0003 makes `meridian_app` a `NOINHERIT` member.
          The password exists for a human with a runbook, not for the task.
        * `meridian-<env>-secret-origin-verify`. Both ends of that header are
          infrastructure: CloudFront sends it and the ALB listener rules check
          it. Neither application reads it, and since P5AR5-01 neither task is
          given it.

        **The one `Resource: "*"`:** the four `ssmmessages:*` actions ECS Exec
        needs. They are session-channel operations with no resource to name, and
        AWS's own documented policy for `enableExecuteCommand` uses `"*"`.
        Every session they permit is written to the cluster's exec log group
        and appears in CloudTrail against a named identity.
        """
        role = iam.Role(
            self,
            "ApiTaskRole",
            role_name=resource_name(self.env_name, "iam", "ecs-api-task"),
            assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            description=f"Meridian {self.env_name}: the api task's own permissions.",
        )
        # Artifacts and PHI: `src/storage.py`'s `bucket_for` decides which, and
        # sends `ServerSideEncryption` + `SSEKMSKeyId` on every put because the
        # bucket policy denies anything else. The grants include `kms:Decrypt`
        # and `kms:GenerateDataKey` on each bucket's CMK.
        #
        # **`grant_read` + `grant_put`, and NOT `grant_read_write`, on `phi`.**
        # CDK's `grantReadWrite` includes `s3:DeleteObject*`, and nothing in
        # `src/storage.py` deletes a PHI object: raw uploads and
        # identifier-bearing exports are aged out by the bucket's own lifecycle
        # rules, which is a property of the bucket and not a call the
        # application makes. Versioning would make a delete recoverable, but a
        # delete the task can issue is still a delete an attacker with the task
        # role can issue, in the one bucket whose contents are the patients.
        self.data.buckets["artifacts"].grant_read_write(role)
        self.data.buckets["phi"].grant_read(role)
        self.data.buckets["phi"].grant_put(role)
        # The `audit` bucket is Object-Locked and written by the audit export,
        # not by a request. No grant.

        # `MERIDIAN_PHI_HMAC_KEY`, fetched at runtime rather than injected.
        # `patient_ref`'s key is the link between a tokenized row and
        # `phi.transaction_identity`, and an injected secret sits in
        # `/proc/<pid>/environ` for the life of the task where any code in the
        # container — and anything that can read that file — can take it.
        # `src/phi.hmac_key()` fetches it with this permission, by the ARN in
        # `MERIDIAN_PHI_HMAC_KEY_SECRET_ARN` (`_api_environment`), and caches it
        # for the process (T:95).
        _allow_secret_read(
            role, "PhiHmacKey", self.data.phi_hmac_key.secret_arn, self.data.keys["phi"]
        )

        # Transactional email (Phase 7, ADR 0025). `src/email_service.py` sends
        # invites and run notices through SESv2 with `EMAIL_BACKEND=ses`; this
        # is the only permission that needs, and it is scoped to one identity,
        # one configuration set and one `From`.
        _allow_ses_send(
            role,
            self,
            self.ses_identity_name,
            self.ses_configuration_set_name,
            self.ses_from_address,
            self.ses_region,
        )

        # Sign-in (orchestrator item from the auth port): without these, password
        # sign-in, the MFA challenge and the members' addresses answer AccessDenied on
        # ECS. On this pool only — see COGNITO_SIGN_IN_ACTIONS.
        role.add_to_policy(
            iam.PolicyStatement(
                sid="SignInAgainstThisPoolOnly",
                actions=list(COGNITO_SIGN_IN_ACTIONS),
                resources=[self.auth.user_pool.user_pool_arn],
            )
        )

        # ADR 0044 / T:186: seal and open QuickBooks tokens (connect, refresh, and the
        # one-off `scripts/encrypt_qbo_tokens.py` re-seal run as this task). On the token
        # key only, and only with `purpose=qbo-token` in the encryption context. Direct KMS
        # use, not `kms:ViaService`: the application does the envelope encryption itself.
        role.add_to_policy(
            iam.PolicyStatement(
                sid="SealQboTokensFromTheApi",
                actions=list(QBO_TOKEN_KMS_ACTIONS),
                resources=[self.data.token_key.key_arn],
                conditions={
                    "StringEquals": {"kms:EncryptionContext:purpose": QBO_TOKEN_KMS_PURPOSE}
                },
            )
        )

        # T:254 / owner decision 2026-10-18: Ask Meridian calls Bedrock. A global inference
        # profile needs TWO statements (AWS "global cross-Region inference" policy shape):
        # the profile ARN in the home region, and the underlying foundation model, whose ARN
        # has no region because the request may be served from any commercial region. The
        # second is only usable *through* one of our profiles (bedrock:InferenceProfileArn),
        # so the role cannot call a foundation model directly or any other model.
        region = bedrock_region(self)
        profile_arns = [
            f"arn:aws:bedrock:{region}:{Aws.ACCOUNT_ID}:inference-profile/{pid}"
            for pid in ASK_PROFILE_IDS
        ]
        invoke = ["bedrock:InvokeModel"]
        role.add_to_policy(
            iam.PolicyStatement(
                sid="AskMeridianInvokeInferenceProfiles",
                actions=invoke,
                resources=profile_arns,
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="AskMeridianInvokeFoundationModelsViaProfiles",
                actions=invoke,
                # Both forms, as AWS's global-profile example and `get-inference-profile` list:
                # the region-less ARN and the home-region one (checker, 2026-10-18).
                resources=[
                    f"arn:aws:bedrock:{r}::foundation-model/{pid.removeprefix('global.')}"
                    for pid in ASK_PROFILE_IDS
                    for r in ("", region)
                ],
                conditions={"ArnEquals": {"bedrock:InferenceProfileArn": profile_arns}},
            )
        )

        # ECS Exec's four `ssmmessages:*` session-channel actions, and the
        # `logs:DescribeLogGroups` its log configuration needs, are added by CDK
        # from `enable_execute_command=True` on the service. They are the
        # stack's only `Resource: "*"` statements besides
        # `ecr:GetAuthorizationToken`, none of them has an ARN to name, and
        # `infra/tests/test_compute.py` lists all three with their reasons and
        # fails on a fourth.
        Tags.of(role).add("DataClassification", "phi")
        return role

    def _web_task_role(self) -> iam.Role:
        """The Next.js task's role: nothing but its own logs.

        It serves pre-built pages and proxies `/api/*` to the api service. It
        reads no bucket and talks to no AWS API — so the role exists to *be*
        empty, which is what makes an added statement visible in a diff. No ECS
        Exec either: there is nothing in that container to investigate that its
        logs do not show.

        **It holds no secret permission and the container holds no secret
        VALUE either** (P5AR5-01). `MERIDIAN_ORIGIN_VERIFY` was a `secrets:`
        entry here for one round, for a proxy hop the ALB's own listener rules
        make unreachable; it is gone, and the task definition's whole
        configuration is now plain environment variables.
        """
        return iam.Role(
            self,
            "WebTaskRole",
            role_name=resource_name(self.env_name, "iam", "ecs-web-task"),
            assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            description=(
                f"Meridian {self.env_name}: the web task. Deliberately holds no "
                "permissions beyond writing its own log stream."
            ),
        )

    # ------------------------------------------------------- task definitions
    def _api_task_definition(self) -> ecs.FargateTaskDefinition:
        task_definition = ecs.FargateTaskDefinition(
            self,
            "ApiTaskDefinition",
            family=resource_name(self.env_name, "ecs", "api"),
            cpu=API_CPU,
            memory_limit_mib=API_MEMORY_MIB,
            ephemeral_storage_gib=API_EPHEMERAL_GIB,
            execution_role=self.execution_role,
            task_role=self.api_task_role,
            runtime_platform=ecs.RuntimePlatform(
                cpu_architecture=ecs.CpuArchitecture.ARM64,
                operating_system_family=ecs.OperatingSystemFamily.LINUX,
            ),
        )
        task_definition.add_container(
            API,
            container_name=API,
            image=ecs.ContainerImage.from_ecr_repository(
                self.repositories[API], self.image_tags[API]
            ),
            # SIGTERM, then two minutes, then SIGKILL. See STOP_TIMEOUT.
            stop_timeout=STOP_TIMEOUT,
            port_mappings=[ecs.PortMapping(container_port=API_PORT)],
            logging=ecs.LogDriver.aws_logs(stream_prefix=API, log_group=self.log_groups[API]),
            environment=self._api_environment(),
            secrets=self._api_secrets(),
            health_check=ecs.HealthCheck(
                # The same route the ALB target group checks (D-25), so a task
                # that is unhealthy to one is unhealthy to both.
                command=[
                    "CMD-SHELL",
                    f"curl -fsS http://127.0.0.1:{API_PORT}{API_HEALTH_PATH} || exit 1",
                ],
                interval=Duration.seconds(30),
                timeout=Duration.seconds(5),
                retries=3,
                start_period=HEALTH_CHECK_GRACE,
            ),
        )
        return task_definition

    def _api_secrets(self) -> dict[str, ecs.Secret]:
        """What the ECS agent resolves with the execution role before the process starts.

        The database password, the Cognito client secret (T:102) and — only on
        `-c emailBackend=resend` — the Resend key. Each is one ARN on the execution
        role (`_execution_role`), never a task-role permission.
        """
        secrets = {
            "PGPASSWORD": ecs.Secret.from_secrets_manager(self.db_app_secret, "password"),
            "COGNITO_CLIENT_SECRET": ecs.Secret.from_secrets_manager(self.cognito_client_secret),
            "FLASK_SECRET_KEY": ecs.Secret.from_secrets_manager(self.flask_secret_key),
        }
        if self.resend_api_key is not None:
            secrets["RESEND_API_KEY"] = ecs.Secret.from_secrets_manager(self.resend_api_key)
        secrets.update(self.qbo_secrets())
        if self.ecw_db_secret is not None:
            for name, field in (
                ("ECW_DB_HOST", "host"),
                ("ECW_DB_NAME", "dbname"),
                ("ECW_DB_USER", "user"),
                ("ECW_DB_PASSWORD", "password"),
            ):
                secrets[name] = ecs.Secret.from_secrets_manager(self.ecw_db_secret, field)
        if self.db_mart_reader_secret is not None:
            secrets["MART_DB_PASSWORD"] = ecs.Secret.from_secrets_manager(
                self.db_mart_reader_secret, "password"
            )
        return secrets

    def qbo_secrets(self) -> dict[str, ecs.Secret]:
        """`QBO_CLIENT_ID` / `QBO_CLIENT_SECRET` (`src/qbo_client.py`), for the api AND the
        worker (the `qbo_push` job refreshes tokens). Empty unless `qboOAuth` or
        `worker_enabled` is on."""
        if self.qbo_oauth_secret is None:
            return {}
        return {
            "QBO_CLIENT_ID": ecs.Secret.from_secrets_manager(self.qbo_oauth_secret, "client_id"),
            "QBO_CLIENT_SECRET": ecs.Secret.from_secrets_manager(
                self.qbo_oauth_secret, "client_secret"
            ),
        }

    def _qbo_environment(self) -> dict[str, str]:
        """Which Intuit environment, and the exact redirect URI registered there (D18).

        Production talks to QuickBooks production; staging to the sandbox unless
        `-c qboEnvironment=production` (`config.qbo_environment`). The redirect
        URI is this environment's app hostname (ADR 0050) plus the callback path - never the
        `SITE_URL` default, which is production's and would not match staging's
        registration. Not credentials.
        """
        environment = {
            "QBO_ENVIRONMENT": qbo_environment(self, self.env_name),
            "QBO_REDIRECT_URI": f"https://{self.edge.public_hostname}{QBO_CALLBACK_PATH}",
        }
        if self.env_name != "production" and environment["QBO_ENVIRONMENT"] == "production":
            # real companies outside production: read them, never post journal entries
            environment["MERIDIAN_QBO_POSTING"] = "off"
        return environment

    def _api_environment(self) -> dict[str, str]:
        """Plain configuration. **Nothing here is a credential.**

        The database connection arrives as libpq's own variables — host, port,
        database and user in plain sight, `PGPASSWORD` from Secrets Manager.
        `src/settings.postgres_url()` composes the URL from them in the process,
        so the password is never concatenated into anything a template or a log
        can see. `PGSSLMODE=verify-full` plus `PG_SSLROOTCERT` is what
        `postgres_dsn()` insists on outside development, and the CA bundle is
        baked into the image by `Dockerfile.api`.

        `APP_ENV` is what makes `src/settings.py` fail loud: with it set, an
        unset backend switch raises at startup instead of quietly writing to
        SQLite on an ephemeral disk.
        """
        environment = {
            "APP_ENV": self.env_name,
            # src/auth.py:224 keys the Secure cookie flag off this name, not off
            # APP_ENV, and has done since before either existed.
            "FLASK_ENV": "production",
            "PORT": str(API_PORT),
            "DATABASE_BACKEND": "postgres",
            "STORAGE_BACKEND": "s3",
            "AUTH_BACKEND": "cognito",
            # T:102. `AUTH_BACKEND=cognito` makes `src/settings.require_cognito_config`
            # refuse to start without all four of COGNITO_USER_POOL_ID, _CLIENT_ID,
            # _REGION and (in `secrets:`) _CLIENT_SECRET. Ids and a region, off the
            # `auth` stack's own constructs — never retyped. `COGNITO_REGION` is this
            # stack's region: `auth` and `compute` are the same environment and
            # always deploy into the same one. `COGNITO_DOMAIN` is optional to the
            # app (only the federated redirects read it) and is the hosted domain
            # `auth` created, scheme included.
            "COGNITO_USER_POOL_ID": self.auth.user_pool.user_pool_id,
            "COGNITO_CLIENT_ID": self.auth.web_client.user_pool_client_id,
            "COGNITO_REGION": Aws.REGION,
            "COGNITO_DOMAIN": self.auth.domain.base_url(),
            # Phase 7. The ECS task definition is the post-cutover shape, so it
            # names `ses` here exactly as it names `postgres` and `s3` above.
            # `-c emailBackend=resend` is the rollback (T:143, email-cutover.md §2):
            # this variable, plus `RESEND_API_KEY` in `secrets:` and the From below.
            "EMAIL_BACKEND": self.email_backend,
            # ADR 0021's dual-acceptance window, as a task-definition variable
            # rather than a thing someone remembers to set. `true` until Phase
            # 10: a Supabase-issued token is still accepted alongside a Cognito
            # one, which is what makes Flip 1 reversible.
            # `-c acceptSupabaseTokens=false` is Phase 10 step 1
            # (`docs/runbooks/decommission-supabase-render.md`), deployed like
            # any other compute change, and the rollback is the same flag back.
            # Read by `src/settings.accept_supabase_tokens()`.
            "AUTH_ACCEPT_SUPABASE_TOKENS": (
                "true" if _flag(self, "acceptSupabaseTokens", default=True) else "false"
            ),
            "PGHOST": self.data.database.db_instance_endpoint_address,
            "PGPORT": self.data.database.db_instance_endpoint_port,
            "PGDATABASE": "meridian",
            "PGUSER": "meridian_app",
            "PGSSLMODE": "verify-full",
            "PG_SSLROOTCERT": "/etc/ssl/rds/global-bundle.pem",
            # Which peers uvicorn believes about `X-Forwarded-For`. The VPC's
            # own CIDR and nothing wider: the ALB reaches this container from a
            # private-app address, and `*` here would let anything that could
            # open a socket to the task claim any client address it liked —
            # which is the input `api/deps.rate_limit_key` uses to bucket the
            # credential rate limits. `Dockerfile.api`'s CMD passes this to
            # `--forwarded-allow-ips` and `api/main.py` gives the same list to
            # `ProxyHeadersMiddleware`. (Render has no such CIDR and uses `*`;
            # `render.yaml` says why that is sound there and not here.)
            #
            # **What the api actually sees in that header** (P5AR3-02,
            # P5AR4-02). A browser request the `web` task proxies now goes
            # browser → CloudFront → ALB → api: ONE CloudFront pass, and no web
            # hop at all, because the ALB's listener rules claim `/api/*`,
            # `/auth/*` and `/static/*` before the `/*` rule that reaches the
            # `web` container (P5AR5-01). So `X-Forwarded-For` reads
            # `<viewer>, <cf edge>, <alb>` and, more to the point,
            # `CloudFront-Viewer-Address` is the edge's statement about the
            # VIEWER's own socket — written by the one pass and preferred by
            # `api.deps.client_address`. That is the exact bucket the credential
            # rate limits want.
            #
            # It is exact only because there is one pass. A design that sent the
            # SPA's calls back out through the distribution would have the second
            # pass overwrite that header with the NAT gateway's address, and the
            # whole estate would share one bucket.
            #
            # A CIDR here is also what tells `client_address` it is on ECS and
            # may believe that header at all: `FORWARDED_ALLOW_IPS` being a real
            # range is the stand-in for "this deployment is behind an
            # origin-verifying edge" (there is no expected value to compare
            # against in the task).
            "FORWARDED_ALLOW_IPS": VPC_CIDR[self.env_name],
            "MERIDIAN_S3_ARTIFACTS_BUCKET": self.data.buckets["artifacts"].bucket_name,
            "MERIDIAN_S3_PHI_BUCKET": self.data.buckets["phi"].bucket_name,
            "MERIDIAN_S3_KMS_KEY_ARN": self.data.keys["artifacts"].key_arn,
            "MERIDIAN_S3_PHI_KMS_KEY_ARN": self.data.keys["phi"].key_arn,
            # T:95. Where `src/phi.hmac_key()` fetches the `patient_ref` key from —
            # a pointer, not the value. The api TASK role reads that one ARN
            # (`_api_task_role`); the value is deliberately not a `secrets:` entry.
            "MERIDIAN_PHI_HMAC_KEY_SECRET_ARN": self.data.phi_hmac_key.secret_arn,
            # Not a credential: the mailbox the IAM condition above allows, and
            # the configuration set that publishes bounces and complaints.
            "MERIDIAN_SES_FROM_EMAIL": self.ses_from_address,
            "MERIDIAN_SES_CONFIGURATION_SET": self.ses_configuration_set_name,
            # ADR 0050: the app's origin — every link an e-mail carries and the
            # Cognito `/auth/callback` are built from it (`src/settings.
            # public_app_url`). Unset it would fall back to Render's
            # `https://www.meridiansgrp.com`, which after cutover only redirects.
            "PUBLIC_APP_URL": self.edge.public_origin,
            # ADR 0044 / T:186: the KMS key QuickBooks tokens are sealed under
            # (`src/qbo_token_crypto.py`). A key ARN, not a credential; the worker copies it.
            QBO_TOKEN_KMS_KEY_ENV: self.data.token_key.key_arn,
            # T:254: Ask Meridian on (src/bi_ask.make_client refuses without a region) and the
            # app-side monthly spend cap. Api only: the worker never calls Bedrock.
            "BEDROCK_REGION": bedrock_region(self),
            "BI_ASK_MONTHLY_CAP_USD": ASK_MONTHLY_CAP_USD,
        }
        if self.email_backend == "resend":
            # The rollback sends from the same mailbox SES does; Resend has the
            # domain verified (it was the provider until the flip).
            environment["RESEND_FROM_EMAIL"] = self.ses_from_address
        if api_platform_enabled(self):
            environment.update(self._api_platform_environment())
        if worker_enabled(self):
            environment.update(self._job_queue_environment())
        if self.qbo_oauth_secret is not None:  # `qboOAuth` or `worker_enabled`
            environment.update(self._qbo_environment())
        if self.ecw_org_id is not None:  # `ecwMart` (ADR 0053)
            environment.update(
                {
                    "MART_DB_HOST": self.data.database.db_instance_endpoint_address,
                    "MART_DB_PORT": self.data.database.db_instance_endpoint_port,
                    "MART_DB_NAME": "meridian",
                    "MART_DB_USER": "meridian_mart_reader",
                    "ECW_ORG_ID": self.ecw_org_id,
                }
            )
        return environment

    def _job_queue_environment(self) -> dict[str, str]:
        """Where the job queues are (Phase 11 H1, `-c worker_enabled=true`), for D4's
        `enqueue()`: `src/settings.job_queue_urls` reads both. Composed from the names in
        `stacks/worker.py` — the queues are built after this task definition, from the
        same names, in the same stack. The api may only SEND, to the job queue.
        """
        from .worker import (
            JOBS_DLQ_URL_ENV,
            JOBS_QUEUE_URL_ENV,
            jobs_dlq_name,
            jobs_queue_name,
        )

        return {
            JOBS_QUEUE_URL_ENV: queue_url(jobs_queue_name(self.env_name)),
            JOBS_DLQ_URL_ENV: queue_url(jobs_dlq_name(self.env_name)),
        }

    def _api_platform_environment(self) -> dict[str, str]:
        """Where the webhook machinery is (Phase 12 T21, `-c enableApiPlatform=true`).

        Read by `src/webhooks/ports.adapters_from_env`: with `WEBHOOK_QUEUE_URL` set
        the api uses SQS, Secrets Manager and EventBridge instead of the in-process
        fakes. The queue URLs are **composed from the names** in
        `meridian/api_platform.py` rather than imported from the `api` stack, which
        already imports from this one. Names and URLs, never a credential.

        `WEBHOOK_SECRETS_KMS_KEY_ID` is the artifacts CMK (ADR 0038 decision 6): the
        key each subscription's signing secret is created under.
        `WEBHOOK_BLOCKED_CIDRS` is this VPC's range, which the SSRF guard refuses on
        top of the private ranges it always refuses.

        **`MERIDIAN_API_V3` is set here and nowhere else** (critic Stage 1 H-2): `/api/v3`
        is mounted exactly when the platform it needs is deployed, so "v3 on, platform
        off" cannot be configured. And if the webhook variables ever go missing while
        v3 is on, the api refuses to start (`src/webhooks/ports.check_configuration`)
        rather than answering 201/202 into an in-process queue nobody drains.
        """
        return {
            "MERIDIAN_API_V3": "1",
            "WEBHOOK_QUEUE_URL": queue_url(webhook_queue_name(self.env_name)),
            "WEBHOOK_DLQ_URL": queue_url(webhook_dlq_name(self.env_name)),
            "WEBHOOK_EVENT_BUS": event_bus_name(self.env_name),
            "WEBHOOK_SECRETS_KMS_KEY_ID": self.data.keys["artifacts"].key_arn,
            "WEBHOOK_BLOCKED_CIDRS": VPC_CIDR[self.env_name],
        }

    def _web_task_definition(self) -> ecs.FargateTaskDefinition:
        task_definition = ecs.FargateTaskDefinition(
            self,
            "WebTaskDefinition",
            family=resource_name(self.env_name, "ecs", "web"),
            cpu=WEB_CPU,
            memory_limit_mib=WEB_MEMORY_MIB,
            execution_role=self.execution_role,
            task_role=self.web_task_role,
            runtime_platform=ecs.RuntimePlatform(
                cpu_architecture=ecs.CpuArchitecture.ARM64,
                operating_system_family=ecs.OperatingSystemFamily.LINUX,
            ),
        )
        task_definition.add_container(
            WEB,
            container_name=WEB,
            image=ecs.ContainerImage.from_ecr_repository(
                self.repositories[WEB], self.image_tags[WEB]
            ),
            stop_timeout=STOP_TIMEOUT,
            port_mappings=[ecs.PortMapping(container_port=WEB_PORT)],
            logging=ecs.LogDriver.aws_logs(stream_prefix=WEB, log_group=self.log_groups[WEB]),
            environment={
                "NODE_ENV": "production",
                # The `env` field of every JSON log line the Next.js server writes
                # (`web/src/instrumentation.ts`, ADR 0024 §4). Unset, it reads
                # `development`, and `observability`'s web 5xx filter — which
                # publishes on `Environment=$.env` and is read with this
                # environment's name — never counts a line.
                "APP_ENV": self.env_name,
                "PORT": str(WEB_PORT),
                "HOSTNAME": "0.0.0.0",  # noqa: S104 Next.js listens on all interfaces inside the task
                # Where `web/src/lib/proxy.ts` would send /api/*, /auth/*
                # and /static/* — read **per request** by the route handlers, not
                # baked into the build (see `web/next.config.mjs`). With the
                # scheme: a hostname without `https://` is read as a relative URL
                # and the proxy fails silently, which is the trap render.yaml
                # documents.
                #
                # **On ECS nothing reads it, and that is the point** (P5AR5-01).
                # The ALB's listener rules send `/api/*`, `/auth/*` and
                # `/static/*` — `edge_paths.PINNED_API_PATH_PATTERNS`, generated
                # from `next.config.mjs` — to the `api` target group BEFORE the
                # `/*` rule that reaches this container, so the request never
                # arrives at Next.js and the route handlers never run. They are
                # the DEV and RENDER path (`web/src/lib/proxy.ts`, ADR 0023
                # round-5 note); `infra/tests/test_edge.py` asserts every handler
                # prefix is claimed by an ALB rule, so the claim is enforced
                # rather than asserted.
                #
                # It is set anyway, to this environment's **public hostname**,
                # for two reasons: it is the honest answer to "where is the api
                # from here" if a handler ever does run (a misconfigured rule, a
                # local `next start` against a deployed api), and a value that is
                # unset falls back to `http://localhost:5050`, a port nothing in
                # this container listens on. It used to be `origin-<env>`, the
                # ALB dialled directly, which required this container to hold the
                # origin-verify secret; that consumer is gone.
                #
                # The SPA path on ECS is browser → CloudFront → ALB → api: ONE
                # CloudFront pass, which is what makes `CloudFront-Viewer-Address`
                # the viewer's own address at the api (`api/deps.py`) and what
                # means the WAF has inspected every `/api/*` request — it reaches
                # the api from CloudFront like everything else.
                "MERIDIAN_API_ORIGIN": self.edge.public_origin,
                # ADR 0050: the app's and the public website's origins, read per
                # request by `web/src/lib/site-hosts.ts`. With both set and
                # different, `web/src/middleware.ts` splits www from app the same
                # way the edge's host router does, and the marketing pages link to
                # the app by its absolute address. Staging has no `www` of its
                # own, so it gets only the app origin and stays unsplit.
                "PUBLIC_APP_URL": self.edge.public_origin,
                **({"PUBLIC_WWW_URL": self.edge.www_origin} if self.edge.www_origin else {}),
            },
        )
        return task_definition

    # ------------------------------------------------------------- services
    def _service(
        self,
        purpose: str,
        task_definition: ecs.FargateTaskDefinition,
        desired_count: int,
        target_group: elbv2.ApplicationTargetGroup,
    ) -> ecs.FargateService:
        """One Fargate service, registered into the `edge` stack's target group.

        **The circuit breaker with rollback** is the difference between a bad
        deploy being a five-minute blip and a bad deploy being an outage until
        somebody notices: ECS watches the replacement tasks, and if they keep
        failing their health checks it stops and puts the previous task
        definition back by itself.

        **`minimumHealthyPercent: 0` / `maximumPercent: 100` on `api`** is what
        makes `desiredCount: 1` mean one task *during a deploy as well*. The
        default (100/200) would briefly run two, which is precisely the state
        that mis-books a journal entry. The cost is that the old task is stopped
        before the new one starts — real downtime, on purpose. `web` keeps the
        rolling default.

        The tasks sit in the `private-app` subnets with the `app` security
        group, whose only ingress is the ALB on these two ports and whose only
        route out is the NAT gateway.
        """
        single_task = purpose == API
        service = ecs.FargateService(
            self,
            f"Service{purpose.capitalize()}",
            service_name=resource_name(self.env_name, "ecs", f"svc-{purpose}"),
            cluster=self.cluster,
            task_definition=task_definition,
            desired_count=desired_count,
            assign_public_ip=False,
            vpc_subnets={"subnet_group_name": SUBNET_APP},
            security_groups=[self.app_sg],
            min_healthy_percent=0 if single_task else 100,
            max_healthy_percent=100 if single_task else 200,
            circuit_breaker=ecs.DeploymentCircuitBreaker(enable=True, rollback=True),
            health_check_grace_period=HEALTH_CHECK_GRACE,
            # ECS Exec on the api task only: it is the one with a database to
            # investigate (docs/runbooks/db-access.md). Every session is logged
            # to the cluster's exec log group.
            enable_execute_command=single_task,
            # A task that will not start is a deploy that should stop, not one
            # that retries for an hour.
            enable_ecs_managed_tags=True,
            propagate_tags=ecs.PropagatedTagSource.SERVICE,
        )
        service.attach_to_application_target_group(target_group)
        return service

    # -------------------------------------------------------------- outputs
    def _outputs(self) -> None:
        """Only what a runbook or the deploy workflow has to type.

        No ARNs, no account id: `docs/runbooks/db-access.md` and `deploy.yml`
        need the cluster and the repositories by name, and everything else is
        `describe-services` away.
        """
        CfnOutput(
            self,
            "ClusterName",
            value=self.cluster.cluster_name,
            description="ECS cluster — `aws ecs execute-command --cluster ...`.",
        )
        for purpose, repository in self.repositories.items():
            CfnOutput(
                self,
                f"Repository{purpose.capitalize()}Name",
                value=repository.repository_name,
                description=f"ECR repository for the {purpose} image.",
            )
        CfnOutput(
            self,
            "ApiServiceName",
            value=self.api_service.service_name,
            description="api ECS service — `update-service --force-new-deployment`.",
        )
        CfnOutput(
            self,
            "WebServiceName",
            value=self.web_service.service_name,
            description="web ECS service.",
        )
