"""Shared base class for the per-environment stacks, and the region guard."""

from __future__ import annotations

from typing import Any

from aws_cdk import Stack, Tags, Token
from constructs import Construct

from ..config import EnvConfig

#: The whole estate is in `us-east-1` (plan §1), and for three groups of resources
#: that is not a preference — CloudFormation refuses them anywhere else:
#:
#: * **The `CLOUDFRONT`-scoped WAF web ACL.** `AWS::WAFv2::WebACL` with
#:   `Scope: CLOUDFRONT` may only be created in `us-east-1`; a `REGIONAL` ACL cannot
#:   be attached to a distribution.
#: * **The edge certificate.** An ACM certificate used by a CloudFront distribution
#:   must be issued in `us-east-1`, whatever region the origin is in.
#: * **`AWS::CE::*`** — the anomaly monitors and their subscription in the foundation
#:   stack. Cost Explorer is a global service with a `us-east-1`-only endpoint.
#:
#: Deploying into another region does not fail at synth, it fails **part way through a
#: changeset**, which on the foundation stack rolls back CloudTrail and the alarms
#: along with it. Hence the guard.
EDGE_REGION = "us-east-1"


def assert_edge_region(stack: Stack) -> None:
    """Fail synth if this stack is being deployed outside `us-east-1`.

    `Stack.of(self).region` is a **token** whenever the environment is unresolved —
    which is every offline `cdk synth`, every CI run and every test, because
    `infra/app.py` takes account and region from `CDK_DEFAULT_*` and CI sets neither.
    A token is not a region and must not be compared to one, so the guard only fires
    when the region is concrete: set by real credentials at deploy time, which is
    exactly when getting it wrong costs something.
    """
    region = Stack.of(stack).region
    if Token.is_unresolved(region):
        return
    if region != EDGE_REGION:
        raise ValueError(
            f"{stack.node.id} resolves to region {region!r}, but Meridian deploys into "
            f"{EDGE_REGION} only: the CLOUDFRONT-scoped WAF web ACL, the edge ACM "
            "certificate and the AWS::CE::* anomaly resources cannot be created "
            "anywhere else. Set CDK_DEFAULT_REGION=us-east-1 (or AWS_REGION) and "
            "re-run. See meridian/stacks/base.py and ADR 0018."
        )


class EnvStack(Stack):
    """A stack that belongs to exactly one environment.

    Every per-environment stack takes the environment's config and tags itself
    with a `DataClassification`. The default is `internal`; the data stack
    overrides individual constructs to `phi`.
    """

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_config: EnvConfig,
        data_classification: str = "internal",
        **kwargs: Any,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)
        self.env_config = env_config
        Tags.of(self).add("DataClassification", data_classification)

    @property
    def env_name(self) -> str:
        return self.env_config.name
