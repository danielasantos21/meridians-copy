"""`meridian-<env>-api` — the `/api/v3` platform's AWS side (Phase 12 T21).

**Everything here is behind `-c enableApiPlatform=true`, off by default** (the flag is
defined in `meridian/config.py`). Off, this stack is empty, exactly as it was before
Phase 12, and a deploy of this branch changes nothing that is running. On, it holds
(`docs/reports/phase-12-plan.md` §3.6, §3.7; ADR 0037, ADR 0038):

* **The webhook path.** An EventBridge bus (`meridian-<env>-events-api`) → one rule
  matching `source = meridian.runs` → SQS `meridian-<env>-sqs-webhooks` (KMS, DLQ after
  8 receives) → the webhook sender Lambda `meridian-<env>-lambda-webhook-sender`: in
  the VPC, its own security group (443 out, 5432 to RDS — `stacks/vpc.py`) and its own
  role, reserved concurrency 2.
* **The api task's platform permissions**, attached to the `compute` stack's api task
  role from here: the seven Cognito app-client calls `src/cognito_client_admin.py`
  makes, on the one user pool ARN; create/rotate/delete of `meridian-<env>-webhook-*`
  secrets; `SendMessage` on the webhook queue; `PutEvents` on the bus.
* **Alarms**: the DLQ holds a dead delivery; machine-token refusals spike.
* **The daily idle-client sweep** (`scripts/disable_idle_api_clients.py`, ADR 0037
  decision 6) as an EventBridge Scheduler → ECS `RunTask` of the api task definition.
* **Not the 5-minute outbox sweep** any more (decision D17, 2026-09-24). It was a
  Scheduler → `RunTask` of the api task definition here (≈ $6/month per environment);
  it is now an `outbox_sweep` tick on the job queue that the always-on worker handles
  (`stacks/worker.py`, ≈ $0), so it exists when BOTH this flag and `worker_enabled` are
  on. With this flag alone synth warns (`meridian:outbox-sweep-needs-worker`), and
  `python -m workers.outbox_sweep` is the manual pass.

WHAT IS DELIBERATELY NOT HERE
-----------------------------
* **No machine app client.** Clients are created at runtime by the api, one per
  approved `api_clients` row (ADR 0037 decision 1); the placeholder CDK client is
  removed from `auth` by the same flag.
* **No `cognito-idp:DescribeUserPoolClient`.** It returns the client secret. The admin
  adapter never calls it, and the api cannot (ADR 0037).
* **Nothing PHI.** The sender's role reads no bucket, no PHI key and no PHI secret. It
  is a separate principal precisely so that "calls arbitrary internet URLs" and "reads
  patient data" are never the same identity (plan R7).
* **The new-client-IP and scope-change alarms** the plan lists: nothing emits those
  log events yet (tracker, T21 row). The auth-failure alarm matches a line the api
  already writes (`api/v3/deps.py`: "v3 machine token refused").
* **An API Gateway / mTLS ingress.** Only when a PHI-scoped partner exists (ADR 0042,
  T25).

Staging's api stack is destroyed between phases (ADR 0008 / D-15): the queues and the
log group follow `env_config.destroyed_between_phases`.

THE LAMBDA ASSET
----------------
`lambda/webhook_sender/handler.py` is a thin SQS adapter over `src/webhooks/engine.py`,
so the asset is **`src/` + the handler + psycopg2 + the RDS CA bundle**
(`docs/architecture/repo-layout.md`, `lambda/` row). It is built in the SAM Python 3.12
image for `linux/arm64` at synth time, which needs Docker — and so only when the flag
is on. The psycopg2 pin is read from `requirements.lock.txt`, never retyped. Tests skip
the bundling step with the CDK's own `aws:cdk:bundling-stacks` context.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from aws_cdk import (
    Annotations,
    Aws,
    BundlingOptions,
    CfnOutput,
    DockerImage,
    Duration,
    IgnoreMode,
    RemovalPolicy,
)
from aws_cdk import aws_cloudwatch as cloudwatch
from aws_cdk import aws_cloudwatch_actions as cw_actions
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_events as events
from aws_cdk import aws_iam as iam
from aws_cdk import aws_lambda as lambda_
from aws_cdk import aws_lambda_event_sources as event_sources
from aws_cdk import aws_logs as logs
from aws_cdk import aws_scheduler as scheduler
from aws_cdk import aws_sqs as sqs
from constructs import Construct

from ..api_platform import (
    RUN_EVENT_SOURCE,
    event_bus_name,
    webhook_dlq_name,
    webhook_queue_name,
    webhook_secret_arn_pattern,
    webhook_sender_name,
)
from ..config import (
    API_PLATFORM_CONTEXT_FLAG,
    WORKER_CONTEXT_FLAG,
    EnvConfig,
    api_platform_enabled,
    worker_enabled,
)
from ..naming import resource_name
from ..pins import rds_ca_bundle_commands
from .auth import AuthStack
from .base import EnvStack
from .compute import API, ComputeStack
from .data import LOG_RETENTION, DataStack
from .vpc import SUBNET_APP, VPC_CIDR, VpcStack

_REPO_ROOT = Path(__file__).resolve().parents[3]

# ------------------------------------------------------------------ Cognito

#: Every `cognito-idp` action `src/cognito_client_admin.BotoCognitoClientAdmin` calls,
#: and nothing else. **Verified 2026-09-24** against the AWS Service Authorization
#: Reference in its machine-readable form
#: (`https://servicereference.us-east-1.amazonaws.com/v1/cognito-idp/cognito-idp.json`,
#: v1.4): each exists under exactly this name, and each takes the `userpool` resource
#: type — `arn:${Partition}:cognito-idp:${Region}:${Account}:userpool/${UserPoolId}` —
#: so one pool ARN scopes all seven. `AddUserPoolClientSecret` and
#: `ListUserPoolClientSecrets` were also checked against their API reference pages
#: (request/response fields match the adapter). `DescribeUserPoolClient` exists too and
#: is deliberately absent: it returns the secret (ADR 0037).
COGNITO_CLIENT_ADMIN_ACTIONS = (
    "cognito-idp:AddUserPoolClientSecret",
    "cognito-idp:CreateUserPoolClient",
    "cognito-idp:DeleteUserPoolClient",
    "cognito-idp:DeleteUserPoolClientSecret",
    "cognito-idp:ListUserPoolClientSecrets",
    "cognito-idp:ListUserPoolClients",
    "cognito-idp:UpdateUserPoolClient",
)

# ----------------------------------------------------------------- webhooks

#: ADR 0038 decision 7: attempt 1 immediate, then seven backoffs → the eighth receive
#: is the last. The engine marks the delivery `dead` itself at attempt 8 and copies it
#: to the DLQ; this redrive policy is the backstop for a handler that crashes.
WEBHOOK_MAX_RECEIVES = 8

#: 10 s per send (`src/webhooks/sender.py`) × a batch of five, plus the database
#: round-trips, inside a minute.
WEBHOOK_SENDER_TIMEOUT = Duration.seconds(60)
WEBHOOK_BATCH_SIZE = 5

#: AWS's guidance for an SQS-triggered Lambda: visibility ≥ 6 × the function timeout,
#: so a batch that is still running is never handed to a second invocation.
WEBHOOK_VISIBILITY_TIMEOUT = Duration.seconds(6 * 60)

#: ≈ 1.3 days of retries fit inside four days with room to spare; the DLQ keeps its
#: dead deliveries for the SQS maximum so a triage after a long weekend still finds
#: them (`docs/runbooks/alerts.md`, webhook DLQ triage).
WEBHOOK_RETENTION = Duration.days(4)
WEBHOOK_DLQ_RETENTION = Duration.days(14)

#: Plan §3.7: two concurrent senders cap the fan-out, so a burst of events cannot
#: exhaust the database's connection slots or hammer a partner.
WEBHOOK_RESERVED_CONCURRENCY = 2

WEBHOOK_SENDER_MEMORY_MIB = 256

#: Where the Lambda finds the RDS CA bundle. `/var/task` is the unpacked asset. Same
#: file `Dockerfile.api` bakes into the image, checked against the same repository pin
#: (`meridian/pins.py`, CX-INF-03).
LAMBDA_RDS_CA_PATH = "/var/task/rds-global-bundle.pem"

#: The handler reads the database password from this secret at cold start
#: (`lambda/webhook_sender/handler.py`). The ARN is not a secret; the value is, which is
#: why a Lambda environment variable never holds it.
DB_SECRET_ARN_ENV = "WEBHOOK_DB_SECRET_ARN"  # noqa: S105 a name, not a secret

# ------------------------------------------------------------------- alarms

#: The line `api/v3/deps.py` logs on every refused machine token, reason code only.
MACHINE_AUTH_FAILURE_PATTERN = "v3 machine token refused"
APP_NAMESPACE = "Meridian/App"
#: Every other `Meridian/App` metric carries `Environment=<env>` as a dimension, taken
#: from `$.env` in a JSON log record (`stacks/observability.py`). This filter matches a
#: plain-text line, which has no field to take a dimension from, so the environment is
#: in the metric **name** instead (`MachineTokenRefused-staging`). Without it, staging's
#: and production's refusals would land on one metric and each alarm would page on the
#: sum of both.
MACHINE_AUTH_FAILURE_METRIC = "MachineTokenRefused"


def machine_auth_failure_metric(env: str) -> str:
    """`MachineTokenRefused-<env>`: one metric per environment in the shared namespace."""
    return f"{MACHINE_AUTH_FAILURE_METRIC}-{env}"


#: Twenty refusals in five minutes: a misconfigured client produces a steady trickle
#: (one per call), a guessing attack a wall. The api's own progressive lockout
#: (`api/v3/quotas.py`) refuses from the tenth failure per IP; this is the human page.
MACHINE_AUTH_FAILURE_THRESHOLD = 20

# ---------------------------------------------------------- idle-client sweep

#: `-c apiIdleSweepActor=<superadmin user id>`. The job records who it acts as on every
#: audit row (`scripts/disable_idle_api_clients.py --actor`). A user id is not an AWS
#: identifier, but it names a person, so it is passed at deploy time like the other
#: identifiers and never committed. Absent, the schedule is not created and synth warns.
IDLE_SWEEP_ACTOR_CONTEXT = "apiIdleSweepActor"
#: 06:15 US Central, every day: before anyone is at work, after the nightly jobs.
IDLE_SWEEP_SCHEDULE = "cron(15 6 * * ? *)"
IDLE_SWEEP_TIMEZONE = "America/Chicago"


def _psycopg2_pin() -> str:
    """`psycopg2-binary==X.Y.Z` from the lock file — the api image's exact version."""
    lock = _REPO_ROOT / "requirements.lock.txt"
    for line in lock.read_text(encoding="utf-8").splitlines():
        if line.strip().lower().startswith("psycopg2-binary=="):
            return line.strip().split()[0]
    raise ValueError("requirements.lock.txt pins no psycopg2-binary; the sender needs it")


class ApiStack(EnvStack):
    """The `/api/v3` platform: webhook plumbing, api permissions, alarms, the idle sweep."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_config: EnvConfig,
        vpc_stack: VpcStack,
        data_stack: DataStack,
        compute_stack: ComputeStack,
        auth_stack: AuthStack,
        **kwargs: Any,
    ) -> None:
        super().__init__(scope, construct_id, env_config=env_config, **kwargs)
        self.enabled = api_platform_enabled(self)
        if not self.enabled:
            # Deliberately empty: nothing is created until the cost line is approved.
            return

        self.vpc_stack = vpc_stack
        self.data = data_stack
        self.compute = compute_stack
        self.auth = auth_stack
        self.transient = env_config.destroyed_between_phases
        self._alarm_action = cw_actions.SnsAction(data_stack.alerts)

        self.bus = events.EventBus(self, "EventBus", event_bus_name=event_bus_name(self.env_name))
        self.dlq, self.queue = self._queues()
        self.rule = self._run_event_rule()
        self.sender = self._webhook_sender()
        self._api_task_permissions()
        self._alarms()
        self.idle_sweep = self._idle_client_sweep()
        self._outbox_sweep_needs_the_worker()
        self._outputs()

    # ------------------------------------------------------------- queues
    def _queues(self) -> tuple[sqs.Queue, sqs.Queue]:
        """The webhook queue and its DLQ, on the environment's `logs` CMK.

        **The `logs` key, not a new one.** A message is ids and a reason code — never a
        URL, a body or a row (`src/webhooks/ports.Message`) — which is what that key
        already protects (the stop-schedule DLQ is on it for the same reason). It also
        already lets `events.amazonaws.com` encrypt, which EventBridge needs to deliver
        to an encrypted queue (`data.py`), and its policy delegates to IAM for
        `role/meridian-<env>-*`, which the sender's role name satisfies. A dedicated
        CMK would be $1/month per environment for no separation that matters.
        """
        removal = RemovalPolicy.DESTROY if self.transient else RemovalPolicy.RETAIN
        key = self.data.keys["logs"]
        dlq = sqs.Queue(
            self,
            "WebhookDlq",
            queue_name=webhook_dlq_name(self.env_name),
            encryption=sqs.QueueEncryption.KMS,
            encryption_master_key=key,
            enforce_ssl=True,
            retention_period=WEBHOOK_DLQ_RETENTION,
            removal_policy=removal,
        )
        queue = sqs.Queue(
            self,
            "WebhookQueue",
            queue_name=webhook_queue_name(self.env_name),
            encryption=sqs.QueueEncryption.KMS,
            encryption_master_key=key,
            enforce_ssl=True,
            visibility_timeout=WEBHOOK_VISIBILITY_TIMEOUT,
            retention_period=WEBHOOK_RETENTION,
            dead_letter_queue=sqs.DeadLetterQueue(
                queue=dlq, max_receive_count=WEBHOOK_MAX_RECEIVES
            ),
            removal_policy=removal,
        )
        return dlq, queue

    def _run_event_rule(self) -> events.CfnRule:
        """`source = meridian.runs` on the bus → the webhook queue.

        **An L1 rule and a hand-written queue policy**, not `targets.SqsQueue`. That
        construct also grants `events.amazonaws.com` on the queue's CMK — a statement
        written into the `data` stack's key policy from here, duplicating the one the
        `logs` key already has. The queue policy below is the one permission this rule
        needs, pinned to this rule's ARN.
        """
        rule = events.CfnRule(
            self,
            "RunEventsToWebhooks",
            name=resource_name(self.env_name, "rule", "run-events-webhooks"),
            description="Run state changes (outbox, ADR 0038) to the webhook fan-out queue.",
            event_bus_name=self.bus.event_bus_name,
            event_pattern={"source": [RUN_EVENT_SOURCE]},
            state="ENABLED",
            targets=[events.CfnRule.TargetProperty(id="webhooks", arn=self.queue.queue_arn)],
        )
        self.queue.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowTheRunEventsRule",
                principals=[iam.ServicePrincipal("events.amazonaws.com")],
                actions=["sqs:SendMessage"],
                resources=[self.queue.queue_arn],
                conditions={"ArnEquals": {"aws:SourceArn": rule.attr_arn}},
            )
        )
        return rule

    # ------------------------------------------------------------- sender
    def _webhook_sender(self) -> lambda_.Function:
        name = webhook_sender_name(self.env_name)
        sg = self.vpc_stack.webhook_sender_sg
        if sg is None:  # pragma: no cover - the same flag builds both
            raise ValueError(
                f"the vpc stack has no webhook sender security group; pass "
                f"-c {API_PLATFORM_CONTEXT_FLAG}=true to both (it is one app-wide flag)"
            )
        log_group = logs.LogGroup(
            self,
            "WebhookSenderLogGroup",
            log_group_name=f"/aws/lambda/{name}",
            retention=LOG_RETENTION,
            encryption_key=self.data.keys["logs"],
            removal_policy=RemovalPolicy.DESTROY if self.transient else RemovalPolicy.RETAIN,
        )
        role = self._sender_role(log_group)
        database = self.data.database
        function = lambda_.Function(
            self,
            "WebhookSender",
            function_name=name,
            description=(
                "Webhook sender (ADR 0038): fan-out, tenant re-check, SSRF guard, signed "
                "HTTPS POST. Its own SG and role; no PHI access."
            ),
            runtime=lambda_.Runtime.PYTHON_3_12,
            architecture=lambda_.Architecture.ARM_64,
            handler="handler.handler",
            code=self._sender_code(),
            role=role,
            timeout=WEBHOOK_SENDER_TIMEOUT,
            memory_size=WEBHOOK_SENDER_MEMORY_MIB,
            reserved_concurrent_executions=WEBHOOK_RESERVED_CONCURRENCY,
            vpc=self.vpc_stack.vpc,
            vpc_subnets=ec2.SubnetSelection(subnet_group_name=SUBNET_APP),
            security_groups=[sg],
            log_group=log_group,
            # Names, ARNs and URLs only. The database password is read from
            # `WEBHOOK_DB_SECRET_ARN` at cold start; a Lambda environment variable is
            # readable by anyone with `lambda:GetFunctionConfiguration`.
            environment={
                "APP_ENV": self.env_name,
                "FLASK_ENV": "production",
                "DATABASE_BACKEND": "postgres",
                "PGHOST": database.db_instance_endpoint_address,
                "PGPORT": database.db_instance_endpoint_port,
                "PGDATABASE": "meridian",
                "PGUSER": "meridian_app",
                "PGSSLMODE": "verify-full",
                "PG_SSLROOTCERT": LAMBDA_RDS_CA_PATH,
                DB_SECRET_ARN_ENV: self.data.db_app_secret.secret_arn,
                "WEBHOOK_QUEUE_URL": self.queue.queue_url,
                "WEBHOOK_DLQ_URL": self.dlq.queue_url,
                "WEBHOOK_EVENT_BUS": self.bus.event_bus_name,
                "WEBHOOK_SECRETS_KMS_KEY_ID": self.data.keys["artifacts"].key_arn,
                "WEBHOOK_BLOCKED_CIDRS": VPC_CIDR[self.env_name],
            },
        )
        # `ReportBatchItemFailures`: the handler returns the ids to retry, so one bad
        # delivery does not re-run the whole batch (`lambda/webhook_sender/handler.py`).
        function.add_event_source(
            event_sources.SqsEventSource(
                self.queue,
                batch_size=WEBHOOK_BATCH_SIZE,
                report_batch_item_failures=True,
            )
        )
        return function

    def _sender_code(self) -> lambda_.Code:
        """`src/` + the handler + psycopg2 + the RDS CA bundle, built for arm64."""
        pin = _psycopg2_pin()
        command = " && ".join(
            [
                f"pip install --no-cache-dir --only-binary=:all: -t /asset-output '{pin}'",
                "cp -r /asset-input/src /asset-output/src",
                "cp /asset-input/lambda/webhook_sender/handler.py /asset-output/handler.py",
                # Downloaded, then refused unless it hashes to the repository pin.
                *rds_ca_bundle_commands("/asset-output/rds-global-bundle.pem"),
                "find /asset-output -name __pycache__ -type d -prune -exec rm -rf {} +",
            ]
        )
        return lambda_.Code.from_asset(
            str(_REPO_ROOT),
            # Only these paths are hashed: the repository root also holds client data
            # (gitignored, but on disk), `node_modules` and `.env`. **`.gitignore`
            # semantics** (`IgnoreMode.GIT`) because the default glob mode cannot
            # re-include a path under an excluded `*` — with it, the fingerprint saw
            # nothing at all and the asset would never have changed. The bundler
            # copies exactly the same three things out, and nothing else, so the
            # deployed zip holds `src/`, `handler.py`, psycopg2 and the CA bundle.
            ignore_mode=IgnoreMode.GIT,
            exclude=[
                "*",
                "!src",
                "!src/**",
                "!lambda",
                "!lambda/webhook_sender",
                "!lambda/webhook_sender/handler.py",
                "!requirements.lock.txt",
                "**/__pycache__",
                "**/*.pyc",
            ],
            bundling=BundlingOptions(
                image=DockerImage.from_registry(lambda_.Runtime.PYTHON_3_12.bundling_image.image),
                platform="linux/arm64",
                command=["bash", "-c", command],
            ),
        )

    def _sender_role(self, log_group: logs.ILogGroup) -> iam.Role:
        """The sender's own role — named so the `logs` and `artifacts` CMK policies'
        `role/meridian-<env>-*` delegation covers it.

        What it may do: consume the queue (added by the event source), send to the
        queue and the DLQ (fan-out and dead-lettering), read `meridian-<env>-webhook-*`
        signing secrets, read the `meridian_app` database credential, write its own
        log group, and attach to the VPC. **Nothing else** — no bucket, no PHI key, no
        `phi_access` credential, no PutEvents.
        """
        role = iam.Role(
            self,
            "WebhookSenderRole",
            role_name=resource_name(self.env_name, "iam", "lambda-webhook-sender"),
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            description="Webhook sender Lambda: its queue, webhook-* secrets, its logs. No PHI.",
        )
        # ENI create/describe/delete for a VPC Lambda. AWS's own managed policy; its
        # EC2 actions have no resource-level form, which is why it says `*`.
        role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name(
                "service-role/AWSLambdaVPCAccessExecutionRole"
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="WriteOwnLogs",
                actions=["logs:CreateLogStream", "logs:PutLogEvents"],
                resources=[log_group.log_group_arn, f"{log_group.log_group_arn}:*"],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="EnqueueDeliveriesAndDeadLetters",
                actions=["sqs:SendMessage", "sqs:ChangeMessageVisibility"],
                resources=[self.queue.queue_arn, self.dlq.queue_arn],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="EncryptQueueMessages",
                actions=["kms:GenerateDataKey", "kms:Decrypt"],
                resources=[self.data.keys["logs"].key_arn],
                conditions={"StringEquals": {"kms:ViaService": f"sqs.{Aws.REGION}.amazonaws.com"}},
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadWebhookSigningSecrets",
                actions=["secretsmanager:GetSecretValue"],
                resources=[webhook_secret_arn_pattern(self.env_name)],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadTheAppDatabaseCredential",
                actions=["secretsmanager:GetSecretValue"],
                resources=[self.data.db_app_secret.secret_arn],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="DecryptSecretsThroughSecretsManager",
                actions=["kms:Decrypt"],
                resources=[
                    self.data.keys["artifacts"].key_arn,
                    self.data.keys["rds"].key_arn,
                ],
                conditions={
                    "StringEquals": {"kms:ViaService": f"secretsmanager.{Aws.REGION}.amazonaws.com"}
                },
            )
        )
        return role

    # ---------------------------------------------------- api task permissions
    def _api_task_permissions(self) -> iam.Policy:
        """Attached to the `compute` stack's api task role, written here.

        Here and not in `compute` because the pool ARN and the queue are this stack's
        and `auth`'s; `compute` importing them would reverse the arrows (`api` already
        imports `compute`). An `AWS::IAM::Policy` naming a role in another stack is
        exactly as effective as a statement on the role itself.
        """
        env = self.env_name
        policy = iam.Policy(
            self,
            "ApiTaskPlatformPolicy",
            policy_name=resource_name(env, "iam", "api-platform"),
            roles=[self.compute.api_task_role],
            statements=[
                iam.PolicyStatement(
                    sid="ManageMachineAppClientsOnThisPoolOnly",
                    actions=list(COGNITO_CLIENT_ADMIN_ACTIONS),
                    resources=[self.auth.user_pool.user_pool_arn],
                ),
                iam.PolicyStatement(
                    sid="ManageWebhookSigningSecrets",
                    actions=[
                        "secretsmanager:CreateSecret",
                        "secretsmanager:GetSecretValue",
                        "secretsmanager:PutSecretValue",
                        "secretsmanager:DeleteSecret",
                    ],
                    resources=[webhook_secret_arn_pattern(env)],
                ),
                iam.PolicyStatement(
                    sid="EncryptWebhookSecretsThroughSecretsManager",
                    actions=["kms:GenerateDataKey", "kms:Decrypt"],
                    resources=[self.data.keys["artifacts"].key_arn],
                    conditions={
                        "StringEquals": {
                            "kms:ViaService": f"secretsmanager.{Aws.REGION}.amazonaws.com"
                        }
                    },
                ),
                iam.PolicyStatement(
                    sid="EnqueueWebhookWork",
                    actions=["sqs:SendMessage"],
                    resources=[self.queue.queue_arn, self.dlq.queue_arn],
                ),
                iam.PolicyStatement(
                    sid="EncryptQueueMessages",
                    actions=["kms:GenerateDataKey", "kms:Decrypt"],
                    resources=[self.data.keys["logs"].key_arn],
                    conditions={
                        "StringEquals": {"kms:ViaService": f"sqs.{Aws.REGION}.amazonaws.com"}
                    },
                ),
                iam.PolicyStatement(
                    sid="PublishRunEvents",
                    actions=["events:PutEvents"],
                    resources=[self.bus.event_bus_arn],
                ),
            ],
        )
        return policy

    # -------------------------------------------------------------- alarms
    def _alarm(
        self,
        construct_id: str,
        *,
        purpose: str,
        metric: cloudwatch.IMetric,
        threshold: float,
        description: str,
    ) -> cloudwatch.Alarm:
        """One alarm to the alerts topic, on both transitions (ADR 0024)."""
        alarm = cloudwatch.Alarm(
            self,
            construct_id,
            alarm_name=resource_name(self.env_name, "alarm", purpose),
            alarm_description=description,
            metric=metric,
            threshold=threshold,
            comparison_operator=cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
            evaluation_periods=1,
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
        )
        alarm.add_alarm_action(self._alarm_action)
        return alarm

    def _alarms(self) -> None:
        self._alarm(
            "WebhookDlqDepth",
            purpose="webhook-dlq",
            metric=self.dlq.metric_approximate_number_of_messages_visible(
                period=Duration.minutes(5), statistic="Maximum"
            ),
            threshold=1,
            description=(
                "A webhook delivery died after 8 attempts (~1.3 days). Triage: "
                "docs/runbooks/alerts.md, 'Webhook DLQ'."
            ),
        )
        metric_filter = logs.MetricFilter(
            self,
            "MachineTokenRefusedFilter",
            log_group=self.compute.log_groups[API],
            filter_pattern=logs.FilterPattern.literal(f'"{MACHINE_AUTH_FAILURE_PATTERN}"'),
            metric_namespace=APP_NAMESPACE,
            metric_name=machine_auth_failure_metric(self.env_name),
            metric_value="1",
            default_value=0,
        )
        self._alarm(
            "MachineTokenRefusals",
            purpose="machine-auth-failures",
            metric=metric_filter.metric(statistic="Sum", period=Duration.minutes(5)),
            threshold=MACHINE_AUTH_FAILURE_THRESHOLD,
            description=(
                "Machine tokens refused at /api/v3 at an unusual rate: a client with a "
                "rotated/revoked secret, or someone guessing. See "
                "docs/runbooks/revoke-api-client.md."
            ),
        )

    # --------------------------------------------- scheduled one-off api tasks
    def _api_task_family_arn(self) -> str:
        """The api task definition's FAMILY ARN — no revision, composed, not imported.

        **Not `api_task_definition.task_definition_arn`.** That is the revision ARN, and
        across stacks it is a CloudFormation export: every image deploy registers a new
        revision, so `compute`'s export value would change while this stack imports it —
        and CloudFormation refuses to update an export in use. `deploy.yml` deploys
        `compute` alone, so every api deploy would have failed once this stack held a
        schedule. The family ARN never changes; ECS `RunTask` (which Scheduler calls) runs
        the latest ACTIVE revision of a family given without a revision, which is the one
        the api service runs. IAM gets the family and `family:*` — that one family's
        revisions, nothing else.
        """
        return self.format_arn(
            service="ecs",
            resource="task-definition",
            resource_name=resource_name(self.env_name, "ecs", API),
        )

    # ---------------------------------------------------------- idle sweep
    def _idle_client_sweep(self) -> scheduler.CfnSchedule | None:
        """Daily `disable_idle_api_clients.py` as a one-off api task (ADR 0037 §6).

        EventBridge Scheduler → ECS `RunTask` of the **api task definition** with a
        command override: same image, same database credential, same network, so the
        job cannot drift from the code the api runs. About a minute of Fargate a day.
        """
        actor = self.node.try_get_context(IDLE_SWEEP_ACTOR_CONTEXT)
        if not actor:
            Annotations.of(self).add_warning_v2(
                "meridian:idle-sweep-no-actor",
                f"The daily idle API-client sweep is NOT scheduled: pass "
                f"-c {IDLE_SWEEP_ACTOR_CONTEXT}=<superadmin user id> (never commit it). "
                "Until then run scripts/disable_idle_api_clients.py by hand.",
            )
            return None

        task_family = self._api_task_family_arn()
        cluster = self.compute.cluster
        role = iam.Role(
            self,
            "IdleSweepSchedulerRole",
            role_name=resource_name(self.env_name, "iam", "idle-client-sweep"),
            assumed_by=iam.ServicePrincipal(
                "scheduler.amazonaws.com",
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            ),
            description="EventBridge Scheduler: run the idle API-client sweep, nothing else.",
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="RunTheApiTaskOnThisCluster",
                actions=["ecs:RunTask"],
                resources=[task_family, f"{task_family}:*"],
                conditions={"ArnEquals": {"ecs:cluster": cluster.cluster_arn}},
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="PassTheTaskRoles",
                actions=["iam:PassRole"],
                resources=[
                    self.compute.execution_role.role_arn,
                    self.compute.api_task_role.role_arn,
                ],
                conditions={"StringEquals": {"iam:PassedToService": "ecs-tasks.amazonaws.com"}},
            )
        )
        overrides = {
            "containerOverrides": [
                {
                    "name": API,
                    "command": [
                        "python3",
                        "scripts/disable_idle_api_clients.py",
                        "--actor",
                        str(actor),
                    ],
                }
            ]
        }
        subnets = self.vpc_stack.vpc.select_subnets(subnet_group_name=SUBNET_APP).subnet_ids
        return scheduler.CfnSchedule(
            self,
            "IdleClientSweep",
            name=resource_name(self.env_name, "schedule", "idle-api-clients"),
            description="Disable machine API clients unused for 90 days (ADR 0037).",
            schedule_expression=IDLE_SWEEP_SCHEDULE,
            schedule_expression_timezone=IDLE_SWEEP_TIMEZONE,
            flexible_time_window=scheduler.CfnSchedule.FlexibleTimeWindowProperty(mode="OFF"),
            state="ENABLED",
            target=scheduler.CfnSchedule.TargetProperty(
                arn=cluster.cluster_arn,
                role_arn=role.role_arn,
                input=json.dumps(overrides, separators=(",", ":")),
                ecs_parameters=scheduler.CfnSchedule.EcsParametersProperty(
                    task_definition_arn=task_family,
                    launch_type="FARGATE",
                    task_count=1,
                    network_configuration=scheduler.CfnSchedule.NetworkConfigurationProperty(
                        awsvpc_configuration=scheduler.CfnSchedule.AwsVpcConfigurationProperty(
                            subnets=subnets,
                            security_groups=[self.vpc_stack.app_sg.security_group_id],
                            assign_public_ip="DISABLED",
                        )
                    ),
                ),
                retry_policy=scheduler.CfnSchedule.RetryPolicyProperty(maximum_retry_attempts=2),
            ),
        )

    # -------------------------------------------------------- outbox sweep
    def _outbox_sweep_needs_the_worker(self) -> None:
        """Warn when nothing will re-publish what a failed after-commit publish left.

        Decision D17: the 5-minute outbox sweep is a tick on the job queue that the
        always-on worker handles (`stacks/worker.py`), so it exists only with
        `-c worker_enabled=true` as well. Nothing is created here either way; an annotation
        lands in the cloud assembly's metadata, never in a template.
        """
        if worker_enabled(self):
            return
        Annotations.of(self).add_warning_v2(
            "meridian:outbox-sweep-needs-worker",
            f"-c {API_PLATFORM_CONTEXT_FLAG}=true without -c {WORKER_CONTEXT_FLAG}=true: the "
            "5-minute webhook outbox sweep is NOT scheduled (it is a job-queue tick the worker "
            "handles, decision D17). Run `python -m workers.outbox_sweep` by hand until the "
            "worker is on.",
        )

    # ------------------------------------------------------------- outputs
    def _outputs(self) -> None:
        CfnOutput(
            self,
            "WebhookQueueUrl",
            value=self.queue.queue_url,
            description="The webhook fan-out queue (WEBHOOK_QUEUE_URL).",
        )
        CfnOutput(
            self,
            "WebhookDlqUrl",
            value=self.dlq.queue_url,
            description="Dead webhook deliveries (docs/runbooks/alerts.md, Webhook DLQ).",
        )
        CfnOutput(
            self,
            "EventBusName",
            value=self.bus.event_bus_name,
            description="The bus run events are published to (WEBHOOK_EVENT_BUS).",
        )
