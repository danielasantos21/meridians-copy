"""`meridian-<env>-auth` — Cognito user pool and clients.

Phase 4 steps 3 (`docs/aws-migration-plan.md` §3), ADR 0003 and ADR 0021.

* One user pool **per environment**, `custom:app_uid` as the link back to the
  application's own user id, email through SES in `DEVELOPER` mode (the identity
  verified in Phase 1), MFA `ON` with TOTP only, threat protection `AUDIT`,
  `DeletionProtection=ACTIVE`. A confidential app client.
* Google as a social IdP and Microsoft Entra ID as an OIDC IdP. Both stay (P-8);
  the Entra registration needs an external tenant admin, so it is the long pole.
* A **User Migration Lambda** so that no existing user is forced to reset a
  password. Federated users are pre-linked before the flip.
* Token lifetimes: ID token 60 minutes, in an HttpOnly cookie for the browser and
  as a Bearer token for mobile and machine clients. Machine clients use
  client-credentials with a token life of at most 15 minutes.
* Tokens are verified **locally** with PyJWT against a cached JWKS — never by
  calling Cognito on the request path (`src/cognito.py`).

Never put user metadata in Cognito custom attributes: 2,048 characters, 50
attributes, and they cannot be deleted. `user_profiles` in Postgres is the store
(Phase 4 step 1, Alembic revision 0006).

This stack has no data at rest of its own, but the pool holds email addresses, so
its DataClassification is `internal` and never `public`.

WHAT THE `PLUS` FEATURE PLAN COSTS, AND WHY IT IS NOT OPTIONAL
--------------------------------------------------------------
`aws-cdk-lib` 2.269.0 has two ways to say "threat protection":
`advanced_security_mode` (deprecated) and the pair `feature_plan` +
`standard_threat_protection_mode`. The pair is used here.

Threat protection at any level above `NO_ENFORCEMENT` requires the **Plus**
feature plan; `Essentials` and `Lite` cannot express it, so `PLUS` is the
cheapest plan that supports `AUDIT_ONLY` and is what the control matrix's 312(d)
row promises. Cognito Plus lists at **$0.02 per monthly active user**; with the
two-person workforce (D-04) that is **under $1/month per environment**, which is
inside the ~$250 account ceiling by three orders of magnitude.

`AUDIT_ONLY` and not `FULL_FUNCTION`: enforcement blocks sign-ins on a risk score
nobody here has calibrated, and a two-person workforce signing in from a new
network is indistinguishable from the thing it would block. Audit records the
same signals in CloudWatch, where Phase 8 can look at them before anyone turns
enforcement on.

THE TWO FEDERATED IdPs ARE OPT-IN AT SYNTH — IN **TWO** STEPS
--------------------------------------------------------------
The Secrets Manager secrets are **always** created, empty, so that the operator
has somewhere to put the values the moment the registrations come back. Nothing
else about an IdP is unconditional, because there is no way to ask Secrets
Manager whether a secret has a real value in it without an AWS call, and
`cdk synth` must stay credential-free.

There are **four** context flags, two per provider, and the split is the whole
point:

    -c googleIdp=true     creates the Google provider ON THE POOL. The web
    -c entraIdp=true      client still lists `COGNITO` only, so nobody can sign
                          in with it yet.
    -c googleSignIn=true  adds that provider to the web client's
    -c entraSignIn=true   `SupportedIdentityProviders`. Requires the matching
                          `*Idp` flag; synth fails otherwise, because a client
                          naming a provider that does not exist fails the deploy.

One flag doing both jobs made the order ADR 0003 requires **impossible to
execute**: `AdminLinkProviderForUser` needs the provider to exist on the pool
(without it Cognito answers `InvalidParameterException`), and a user's first
federated sign-in before their link exists auto-creates a duplicate empty
account with no `custom:app_uid`. The only superadmin is Microsoft-only, so the
cleanup for that is delete-and-relink on the one account that can do it.

So the procedure is three moves, and the flags now allow all three:
deploy with `*Idp` on → pre-provision and link (`scripts/preprovision_cognito_users.py`)
→ verify → deploy again with `*SignIn` on (runbook §0, §2, §3).

No secret VALUE appears in this file or in the synthesized template. The IdP
constructs take `SecretValue.secrets_manager(...)`, which renders as a
`{{resolve:secretsmanager:...}}` dynamic reference that CloudFormation resolves
at deploy time.

THE USER MIGRATION LAMBDA, AND THE TWO THINGS IT NEEDS FROM THIS STACK
----------------------------------------------------------------------
`lambda/user_migration/handler.py` (Phase 4 step 6) checks a password against
Supabase Auth on first sign-in and creates the Cognito user silently, so nobody
is forced to reset. 5-second timeout because Cognito abandons the trigger at
about that; outside the VPC because a VPC Lambda pays ENI attachment on a cold
start, and this one is cold almost every time.

**1. The legacy Supabase credentials.** They live in a placeholder secret,
`meridian-<env>/legacy-supabase-auth`, created empty here and filled in by hand.
The Lambda is given the secret's **ARN** in an environment variable and reads it
at cold start with the runtime's own boto3, caching the result in a module
global. The alternative — the Secrets Manager Lambda extension — is a layer, a
local HTTP port and a second cache to reason about, for a function invoked a
handful of times a day. **Cost of the chosen option: one `GetSecretValue` per
container, ~100-250 ms in-region, on the cold start only.** That is inside the
5-second budget alongside the Lambda's own 3-second **overall deadline** for the
Supabase call (connect capped at 1 s, the read bounded by what is left), and it
is the reason that deadline is 3 seconds and not 4. An environment variable holding the ARN is not a
secret; a Lambda environment variable holding the *key* would be, since it is
visible to anyone with `lambda:GetFunctionConfiguration`.

The IAM grant is written by hand rather than with `secret.grant_read()`, which
also hands out `secretsmanager:DescribeSecret`. One action, one ARN, and a test
asserts the role has nothing else beyond its log permissions.

**2. The snapshot.** `legacy_users.json` — every legacy address, its Supabase
UUID and its providers — is bundled INTO the asset. It is not committed (it is a
file of email addresses; `scripts/snapshot_legacy_users.py` generates it and
`.gitignore` keeps it out), which means **a `cdk deploy` of this stack from a
machine without a fresh snapshot silently ships a Lambda that fails every
sign-in closed.** Two defences: the runbook
(`docs/runbooks/cognito-user-migration.md`) says to regenerate it the same day,
and `-c requireLegacySnapshot=true` makes synth **fail** when the file is
missing. The guard defaults to off so that CI — which has no Supabase
credentials and deploys nothing — still synthesizes.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from aws_cdk import Aws, CfnOutput, Duration, RemovalPolicy, SecretValue, Tags
from aws_cdk import aws_cognito as cognito
from aws_cdk import aws_events as events
from aws_cdk import aws_events_targets as events_targets
from aws_cdk import aws_iam as iam
from aws_cdk import aws_kms as kms
from aws_cdk import aws_lambda as lambda_
from aws_cdk import aws_logs as logs
from aws_cdk import aws_secretsmanager as secretsmanager
from constructs import Construct

from ..config import EnvConfig, api_platform_enabled, site_hosts
from ..naming import resource_name
from .base import EDGE_REGION, EnvStack
from .dns import NO_REPLY_LOCAL_PART

# The Lambda source lives at the repo root; anchor on this file so synth and the
# tests work from any working directory (CI runs pytest from the repo root).
_REPO_ROOT = Path(__file__).resolve().parents[3]

#: Same figure as every other log group in the estate (400 days).
LOG_RETENTION = logs.RetentionDays.THIRTEEN_MONTHS

#: Cognito abandons a `UserMigration_*` trigger at ~5 seconds. A longer timeout
#: would not buy a slower Lambda anything except a bill.
MIGRATION_TIMEOUT = Duration.seconds(5)

#: ADR 0021. The ID token is what the browser cookie and the mobile Bearer header
#: carry; 60 minutes bounds how long a revoked session stays usable.
ID_TOKEN_VALIDITY = Duration.minutes(60)

#: 30 days, and it is a deliberate revision of ADR 0003's 12 hours. MFA is `ON`,
#: token revocation is enabled, and the workforce is two people: a 12-hour
#: refresh means a TOTP challenge every morning, which is the kind of friction
#: that gets MFA turned off. Revocation, not expiry, is the control that ends a
#: session here.
REFRESH_TOKEN_VALIDITY = Duration.days(30)

#: Machine tokens are short because nothing renews them interactively and nobody
#: notices when one leaks (ADR 0003: "≤ 15 minutes").
MACHINE_TOKEN_VALIDITY = Duration.minutes(15)

#: The application's own user id, carried as a custom attribute so that no
#: application row is ever rewritten. 36 characters is a UUID; **immutable**
#: because a mutable link between a token and 30 tables of rows is a rewrite
#: waiting to happen.
APP_UID_ATTRIBUTE = "app_uid"
APP_UID_MAX_LENGTH = 36

#: 12, not Cognito's default 8. Everyone who signs in here can reach PHI.
MIN_PASSWORD_LENGTH = 12

#: The machine client's resource server. `phi:read` is deliberately NOT here —
#: a PHI scope arrives with the partner API in Phase 12 (ADR 0002), and adding it
#: before anything checks it would be a scope that grants nothing and looks like
#: it grants everything.
RESOURCE_SERVER_IDENTIFIER = "meridian-api"
MACHINE_SCOPES = (
    ("runs:read", "Read process runs and their artifacts' metadata"),
    ("runs:write", "Create and execute process runs"),
)

#: The Phase 12 machine-grantable catalogue (`src/api_scopes.MACHINE_GRANTABLE_SCOPES`,
#: plan §3.4), used in place of `MACHINE_SCOPES` when `-c enableApiPlatform=true`.
#: `runs:write` becomes `processes:run` — safe because no token has ever carried it.
#:
#: **`phi:read` is still absent**, deliberately: it joins the resource server only when
#: the first partner BAA is recorded (plan §3.4, T25), so that no scope exists which
#: nothing checks. `infra/tests/test_api_platform.py` asserts this list equals the `src/`
#: catalogue minus `phi:read`, so the two cannot drift.
API_PLATFORM_MACHINE_SCOPES = (
    ("allocations:read", "Read employee clinic allocations"),
    ("artifacts:download", "Download a run's output files"),
    ("employees:read", "Read the employee directory"),
    ("journal-entries:read", "Read generated journal entries"),
    ("mappings:read", "Read payer, location and provider mappings"),
    ("mappings:write", "Change payer, location and provider mappings"),
    ("processes:execute", "Execute a finished run, such as booking it"),
    ("processes:run", "Start a process run"),
    ("revenue:read", "Read revenue summaries"),
    ("runs:read", "Read process runs and their artifacts' metadata"),
    ("webhooks:manage", "Manage webhook subscriptions and deliveries"),
)

#: The mailbox Cognito sends from — a subdomain-less address on the verified
#: identity; the MAIL FROM subdomain and the DKIM records are the DNS stack's.
#: Imported from `stacks/dns.py`, which owns the identity, so that this address,
#: the one `src/email_service.py` sends as, and the one the api task role's
#: `ses:FromAddress` condition allows are provably the same string (Phase 7).

#: Context keys that CREATE each federated IdP on the pool. See the module
#: docstring: creating a provider is not the same act as letting anybody sign in
#: with it, and the linking step happens between the two.
GOOGLE_IDP_CONTEXT = "googleIdp"
ENTRA_IDP_CONTEXT = "entraIdp"

#: Context keys that add an existing provider to the web client, i.e. actually
#: offer it as a sign-in button. Each requires its `*_IDP_CONTEXT` partner.
GOOGLE_SIGN_IN_CONTEXT = "googleSignIn"
ENTRA_SIGN_IN_CONTEXT = "entraSignIn"

#: The path the hosted UI redirects back to after a federated sign-in.
CALLBACK_PATH = "/auth/callback"

#: The origin each environment redirects back to when `-c authCallbackUrls` is
#: not given: that environment's **app** host (ADR 0050 — `config.site_hosts`:
#: `staging-app.meridiansgrp.com`, `app.meridiansgrp.com`). The app host, not
#: `www`, because `/auth/callback` sets the session cookie host-only, and the app
#: is where that cookie is read. A single default for both would make staging's
#: callback a production URL — see `_callback_urls`.
DEFAULT_CALLBACK_HOSTS = {env: site_hosts(env).app for env in ("staging", "production")}

#: The invitation email, in the app's own look (`web/src/app/tokens.css`: slate text,
#: `--accent` #2563eb button, 6px radii, IBM Plex, the `brand/logo.png` mark; left
#: aligned like the sign-in screen). Tables and inline styles because mail clients
#: drop stylesheets. Cognito fills `{username}` and `{####}` and refuses a template
#: without both. With email as the sign-in name `{username}` renders the internal
#: id, not the address, so it is present but hidden. `__HOST__` is the app host per
#: environment. Limit: 20,000 chars.
INVITE_EMAIL_HTML = """<!DOCTYPE html><html><head><meta charset="utf-8">\
<meta name="viewport" content="width=device-width, initial-scale=1.0"></head>\
<body style="margin:0;padding:0;background:#f4f6f9;font-family:'IBM Plex Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;color:#161d29;">\
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f9;padding:40px 16px;"><tr><td align="center">\
<table role="presentation" width="480" cellpadding="0" cellspacing="0" style="max-width:480px;width:100%;background:#ffffff;border:1px solid #dfe4ec;border-radius:6px;">\
<tr><td style="padding:36px 36px 8px 36px;">\
<img src="https://__HOST__/brand/logo.png" width="112" height="24" alt="meridians" style="display:block;border:0;"></td></tr>\
<tr><td style="padding:20px 36px 0 36px;">\
<h1 style="margin:0 0 12px 0;font-size:28px;line-height:1.2;font-weight:700;color:#161d29;">You're invited to Meridian</h1>\
<p style="margin:0 0 24px 0;font-size:16px;line-height:1.55;color:#525d6e;">\
Sign in with this email address and the temporary password below.</p></td></tr>\
<tr><td style="padding:0 36px;">\
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fafbfc;border:1px solid #dfe4ec;border-radius:6px;">\
<tr><td style="padding:16px 18px;">\
<p style="margin:0 0 6px 0;font-size:13px;font-weight:600;color:#3d4757;">Temporary password</p>\
<p style="margin:0;font-size:20px;font-weight:600;letter-spacing:1px;color:#161d29;font-family:'IBM Plex Mono',ui-monospace,'SF Mono',Menlo,Consolas,monospace;">{####}</p>\
</td></tr></table></td></tr>\
<tr><td style="padding:24px 36px 0 36px;">\
<a href="https://__HOST__/login" style="display:block;background:#2563eb;color:#ffffff;font-size:16px;font-weight:600;line-height:48px;text-align:center;border-radius:6px;text-decoration:none;">Sign in to Meridian</a></td></tr>\
<tr><td style="padding:24px 36px 32px 36px;">\
<p style="margin:0;font-size:14px;line-height:1.55;color:#616c7f;">\
Next you'll add your name, choose your own password and set up two-factor sign-in with Microsoft Authenticator. \
The temporary password works for 7 days. If you didn't expect this, you can ignore this email.</p></td></tr>\
</table>\
<p style="margin:20px 0 0 0;font-size:12px;color:#616c7f;">Meridians Logic Automation &middot; Stella Mattina Health, Inc.</p>\
</td></tr></table><span style="display:none">{username}</span></body></html>"""

#: T:163 / decision D15 (Andres, 2026-10-09): the pool's identities are exported
#: every night and kept SEVEN YEARS. The function is `scripts/cognito_export.py`'s own
#: `handler` -- the asset is the `scripts/` directory filtered down to that one file,
#: so the CLI and the Lambda are the same code and nothing is duplicated.
COGNITO_EXPORT_SOURCE_DIR = _REPO_ROOT / "scripts"
COGNITO_EXPORT_MODULE = "cognito_export"
#: Must equal `cognito_export.S3_PREFIX`; `infra/tests/test_auth.py` asserts it.
COGNITO_EXPORT_PREFIX = "cognito_export/"
#: 06:00 UTC = 01:00/00:00 US Central, quiet, and clear of the 05:00 UTC backup plan's start.
COGNITO_EXPORT_SCHEDULE = events.Schedule.cron(minute="0", hour="6")
COGNITO_EXPORT_TIMEOUT = Duration.minutes(2)
COGNITO_EXPORT_MEMORY_MB = 256

#: `-c requireLegacySnapshot=true` turns the missing-snapshot synth guard on.
#: Off by default so CI, which deploys nothing, still synthesizes.
REQUIRE_SNAPSHOT_CONTEXT = "requireLegacySnapshot"

#: The Lambda asset directory, and the file inside it that must be freshly
#: generated on the day of a deploy (`scripts/snapshot_legacy_users.py`).
LAMBDA_SOURCE_DIR = _REPO_ROOT / "lambda" / "user_migration"
LEGACY_SNAPSHOT_FILE = LAMBDA_SOURCE_DIR / "legacy_users.json"

#: Secrets are named `meridian-<env>/<purpose>`, with a slash, and not through
#: `resource_name()` — see the note in `infra/meridian/naming.py`. Secrets
#: Manager treats the path segment as a folder in the console, and the Phase 3
#: secrets in the plan already use that form; two conventions inside one stack
#: is how a runbook ends up naming a secret that does not exist.
LEGACY_AUTH_SECRET_NAME = "legacy-supabase-auth"  # noqa: S105 a name, not a secret

#: `meridian-<env>/cognito-web-client` — the web client's secret, copied into Secrets
#: Manager by CloudFormation so the api task can be handed it through `secrets:`
#: (tracker T:102). Not filled in by a human, unlike every other secret here.
WEB_CLIENT_SECRET_NAME = "cognito-web-client"  # noqa: S105 a name, not a secret

#: `-c legacyMigration=false` — Phase 10 step 1's off switch for the User
#: Migration trigger, its Lambda and the Supabase credential secret. Default
#: true until the cut-off.
LEGACY_MIGRATION_CONTEXT = "legacyMigration"

#: The two keys the Lambda reads out of that secret, and the environment
#: variable that tells it where to look. The ARN is not secret; the anon key is,
#: which is why only the ARN is an environment variable.
LEGACY_AUTH_SECRET_TEMPLATE = '{"SUPABASE_URL":"","SUPABASE_ANON_KEY":""}'  # noqa: S105 a name, not a secret
LEGACY_SECRET_ARN_ENV = "LEGACY_SUPABASE_SECRET_ARN"  # noqa: S105 a name, not a secret


def _flag(scope: Construct, name: str, *, default: bool) -> bool:
    """A boolean CDK context value. `-c name=false` arrives as the *string* "false"."""
    raw = scope.node.try_get_context(name)
    if raw is None:
        return default
    if isinstance(raw, bool):
        return raw
    return str(raw).strip().lower() in ("1", "true", "yes", "on")


class AuthStack(EnvStack):
    """Cognito user pool, app clients, federated IdPs, User Migration Lambda."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_config: EnvConfig,
        ses_identity_name: str,
        ses_configuration_set_name: str,
        logs_key: kms.IKey,
        export_key: kms.IKey,
        **kwargs: Any,
    ) -> None:
        super().__init__(scope, construct_id, env_config=env_config, **kwargs)

        self.ses_identity_name = ses_identity_name
        self.ses_configuration_set_name = ses_configuration_set_name

        self.google_secret = self._idp_secret(
            "Google",
            "google",
            "Google OAuth client id and secret for the Cognito social IdP. "
            "Created empty; fill it in from the Google Cloud console, then "
            "synthesize with -c googleIdp=true.",
            '{"client_id":"","client_secret":""}',
        )
        self.entra_secret = self._idp_secret(
            "Entra",
            "entra",
            "Microsoft Entra ID tenant id, application (client) id and client "
            "secret for the Cognito OIDC IdP. Created empty; the registration "
            "needs an external tenant admin (P-8), then -c entraIdp=true.",
            '{"tenant_id":"","client_id":"","client_secret":""}',
        )

        #: Phase 10 step 1 turns the whole legacy-migration apparatus off in code:
        #: `-c legacyMigration=false` removes the `UserMigration` trigger from the
        #: pool, the Lambda and its log group, and the Supabase credential secret.
        #: Default **true** — it is a live dependency of production sign-in until
        #: the Phase 10 cut-off (ADR 0021, D-06).
        #:
        #: **This is CloudFormation's job, not the CLI's.** Doing it by hand means
        #: `update-user-pool`, which replaces the whole `LambdaConfig`: a literal
        #: `--lambda-config '{}'` also removes any pre-token-generation or
        #: custom-message trigger, silently. Removing the trigger by deploying the
        #: stack changes only the key CDK wrote, and the rollback is the flag back
        #: and a redeploy. `docs/runbooks/decommission-supabase-render.md` step 1
        #: uses the CLI for **verification only**.
        #:
        #: The secret is `RemovalPolicy.RETAIN`, so `legacyMigration=false` orphans
        #: it rather than deleting it; the runbook's `delete-secret
        #: --recovery-window-in-days 30` is what actually removes it, after the
        #: deploy, deliberately and with a way back.
        self.legacy_migration = _flag(self, LEGACY_MIGRATION_CONTEXT, default=True)

        self.legacy_auth_secret = self._legacy_auth_secret() if self.legacy_migration else None
        self.migration_lambda = (
            self._migration_lambda(logs_key, self.legacy_auth_secret)
            if self.legacy_auth_secret is not None
            else None
        )
        # `lambda_triggers` also writes the `lambda:InvokeFunction` permission for
        # `cognito-idp.amazonaws.com`, scoped to this pool's ARN. A test asserts
        # it, because a trigger the service may not invoke fails every sign-in.
        self.user_pool = self._user_pool(self.migration_lambda)

        self.domain = self._hosted_domain(self.user_pool)
        #: Phase 12 T21 (`-c enableApiPlatform=true`, default off): the resource server
        #: carries the full machine catalogue, and the placeholder machine client is
        #: gone. Machine clients are created at runtime by the api, one per approved
        #: `api_clients` row (ADR 0037), so nothing here needs a client of its own.
        self.api_platform = api_platform_enabled(self)
        self.resource_server = self._resource_server(self.user_pool)

        self.identity_providers = self._identity_providers(self.user_pool)

        self.web_client = self._web_client(self.user_pool)
        self.web_client_secret = self._web_client_secret(logs_key)
        #: T:163 -- the nightly identity export into the Object-Locked `archive` bucket.
        self.cognito_export = self._cognito_export(logs_key, export_key)
        # ADR 0037 decision 7: the placeholder `meridian-<env>-auth-machine` client is
        # deleted when the platform is switched on. Nothing uses it — no token has been
        # minted with it — and runtime clients replace it. Kept while the flag is off
        # only so that deploying this branch changes nothing until the approval.
        self.machine_client: cognito.UserPoolClient | None = (
            None
            if self.api_platform
            else self._machine_client(self.user_pool, self.resource_server)
        )

        # **CDK does not write this dependency for you.** The web client names
        # `Google` and `Microsoft` in `SupportedIdentityProviders`; without an
        # explicit `DependsOn`, CloudFormation is free to create the client
        # before the provider it names, and the deploy fails on the one run that
        # matters — the first.
        for provider in self.identity_providers:
            self.web_client.node.add_dependency(provider)

        self._outputs()

    # --------------------------------------------------------------- secrets
    def _idp_secret(
        self, label: str, purpose: str, description: str, template: str
    ) -> secretsmanager.Secret:
        """An empty placeholder secret for one federated IdP's registration.

        `secret_string_value` with an all-empty JSON template rather than
        `generate_secret_string`: there is nothing to generate — these values come
        from someone else's console — and an empty template documents the field
        names the operator has to fill in. RETAIN, because a staging teardown must
        not throw away a registration that took a tenant admin a week to approve.
        """
        secret = secretsmanager.Secret(
            self,
            f"{label}IdpSecret",
            # `meridian-<env>/<purpose>-idp`: the slash form every secret in
            # this stack uses. These two have never been deployed, so there is
            # no rename to orchestrate.
            secret_name=f"meridian-{self.env_name}/{purpose}-idp",
            description=description,
            secret_string_value=SecretValue.unsafe_plain_text(template),
            removal_policy=RemovalPolicy.RETAIN,
        )
        Tags.of(secret).add("DataClassification", "internal")
        return secret

    def _web_client_secret(self, key: kms.IKey) -> secretsmanager.Secret:
        """The web client's secret, in Secrets Manager, for the api task (T:102).

        `COGNITO_CLIENT_SECRET` is required at startup (`src/settings.py`): the client
        is confidential, so every `InitiateAuth` carries a `SECRET_HASH` computed from
        it. The api task receives it the way it receives the database password — a
        `secrets:` entry the ECS agent resolves with the execution role — so the value
        is never in the task definition's `environment:` and never a CfnOutput.

        **The value is `Fn::GetAtt <client>.ClientSecret`**, CloudFormation's own
        attribute on `AWS::Cognito::UserPoolClient`, NOT CDK's
        `user_pool_client_secret`: that one is an `AwsCustomResource` — a Lambda with
        an unnamed role and an implicit, never-expiring log group that calls
        `DescribeUserPoolClient` and holds the secret in its response. The template
        shows the `GetAtt`, never the value. A client replacement rotates the secret
        and CloudFormation updates this copy in the same deploy; the api task picks
        the new value up on its next start.

        On the environment's `logs` CMK — the `internal` key, the same one the
        origin-verify secret uses — so a read is a `Decrypt` on a key this estate
        owns. `DESTROY` rather than `RETAIN`: it is a derived copy, and deleting the
        stack deletes the client it copies anyway.
        """
        client = self.web_client.node.default_child
        if not isinstance(client, cognito.CfnUserPoolClient):
            raise AssertionError('isinstance(client, cognito.CfnUserPoolClient)')
        secret = secretsmanager.Secret(
            self,
            "WebClientSecret",
            secret_name=f"meridian-{self.env_name}/{WEB_CLIENT_SECRET_NAME}",
            description=(
                "The Cognito web client's secret (COGNITO_CLIENT_SECRET), copied here by "
                "CloudFormation for the api task's secrets block. Never edit by hand."
            ),
            secret_string_value=SecretValue.resource_attribute(client.attr_client_secret),
            encryption_key=key,
            removal_policy=RemovalPolicy.DESTROY,
        )
        Tags.of(secret).add("DataClassification", "internal")
        return secret

    def _legacy_auth_secret(self) -> secretsmanager.Secret:
        """`meridian-<env>/legacy-supabase-auth` — empty, filled in by hand.

        RETAIN like the IdP secrets: a staging teardown must not throw away a
        credential somebody pasted in, and this one is needed again the next
        time the stack is stood up.
        """
        secret = secretsmanager.Secret(
            self,
            "LegacySupabaseAuthSecret",
            secret_name=f"meridian-{self.env_name}/{LEGACY_AUTH_SECRET_NAME}",
            description=(
                "Legacy Supabase Auth URL and ANON key, read at cold start by the Cognito "
                "User Migration Lambda. Created empty; fill it in before Flip 1. The ANON "
                "key, never the service key — this is an ordinary sign-in call from a "
                "function reachable from the internet. Deleted at the Phase 10 cut-off."
            ),
            secret_string_value=SecretValue.unsafe_plain_text(LEGACY_AUTH_SECRET_TEMPLATE),
            removal_policy=RemovalPolicy.RETAIN,
        )
        Tags.of(secret).add("DataClassification", "internal")
        return secret

    # ---------------------------------------------------------------- lambda
    def _require_snapshot(self) -> None:
        """Fail synth when the bundled snapshot is missing and the flag says it matters.

        `legacy_users.json` is gitignored, so an asset built without it is a
        Lambda that fails every sign-in closed — correct behaviour, terrible
        morning. `-c requireLegacySnapshot=true` is what a deploy passes; the
        default is off so that CI and the unit tests, which deploy nothing,
        still synthesize.
        """
        if not self._wants(REQUIRE_SNAPSHOT_CONTEXT):
            return
        if not LEGACY_SNAPSHOT_FILE.exists():
            raise FileNotFoundError(
                f"{LEGACY_SNAPSHOT_FILE} is missing and -c {REQUIRE_SNAPSHOT_CONTEXT}=true was "
                "passed. Generate it on THIS machine, TODAY: "
                "python3 scripts/snapshot_legacy_users.py "
                "(docs/runbooks/cognito-user-migration.md)."
            )

    def _migration_lambda(
        self, logs_key: kms.IKey, legacy_secret: secretsmanager.ISecret
    ) -> lambda_.Function:
        """The `UserMigration_*` trigger. Placeholder body; real shape.

        The log group is declared here rather than left to Lambda's implicit one,
        for the two reasons every other group in the estate is declared: an
        explicit 400-day retention, and encryption with the environment's
        `internal` CMK so that a `Decrypt` on these lines is a CloudTrail event
        naming a key we own. The real Lambda logs an email **domain** and a
        status, which is internal data, not public.
        """
        self._require_snapshot()
        log_group = logs.LogGroup(
            self,
            "UserMigrationLogGroup",
            log_group_name=f"/aws/lambda/{resource_name(self.env_name, 'lambda', 'user-migration')}",
            retention=LOG_RETENTION,
            encryption_key=logs_key,
            removal_policy=RemovalPolicy.RETAIN,
        )
        function = lambda_.Function(
            self,
            "UserMigrationFunction",
            role=self._migration_role(log_group),
            function_name=resource_name(self.env_name, "lambda", "user-migration"),
            description=(
                "Cognito User Migration trigger (Phase 4 step 6): checks the password "
                "against Supabase Auth on first sign-in and creates the user with "
                "custom:app_uid set, so nobody is forced to reset. Fails closed with "
                "'sign-in temporarily unavailable' on anything else."
            ),
            runtime=lambda_.Runtime.PYTHON_3_12,
            handler="handler.handler",
            # The whole directory, INCLUDING the gitignored `legacy_users.json`
            # when it is present. See the module docstring's second point.
            #
            # `exclude` is not tidiness. `__pycache__` makes the asset hash
            # depend on whether anyone has imported the handler locally, so an
            # unchanged function redeploys (and a changed one might not);
            # `legacy_users.example.json` would ship a second, stale file of the
            # same shape next to the real snapshot, in a function whose whole
            # job is deciding who is real.
            code=lambda_.Code.from_asset(
                str(LAMBDA_SOURCE_DIR),
                exclude=["__pycache__", "*.pyc", "legacy_users.example.json", "test_*"],
            ),
            timeout=MIGRATION_TIMEOUT,
            # CPU scales with memory. At the 128 MB default a cold start spent 3-5 s
            # importing boto3 and building its client, so the first sign-ins timed
            # out inside Cognito's 5 s (staging, 2026-10-08). 1024 MB is ~8x the CPU.
            memory_size=1024,
            # The ARN, not the credentials. A Lambda environment variable is
            # readable by anyone with `lambda:GetFunctionConfiguration`.
            environment={LEGACY_SECRET_ARN_ENV: legacy_secret.secret_arn},
            # **No `vpc=`.** Outside the VPC on purpose: the function reaches
            # Supabase over the public internet, and an ENI attachment on a cold
            # start does not fit in the 5 seconds Cognito allows.
            log_group=log_group,
        )
        # Written by hand rather than `legacy_secret.grant_read(function)`, which
        # also grants `secretsmanager:DescribeSecret`. One action, one ARN.
        function.add_to_role_policy(
            iam.PolicyStatement(
                actions=["secretsmanager:GetSecretValue"],
                resources=[legacy_secret.secret_arn],
            )
        )
        return function

    def _migration_role(self, log_group: logs.ILogGroup) -> iam.Role:
        """The migration Lambda's execution role — written out, not managed.

        CDK's default is `AWSLambdaBasicExecutionRole`, an AWS-managed policy
        whose `logs:CreateLogGroup` / `CreateLogStream` / `PutLogEvents` are all
        on `Resource: "*"`. That is a wildcard on every log group in the account,
        including `audit` and the PHI-adjacent application groups, granted to a
        function whose only job is to check one password — and it is exactly the
        least-privilege finding an auditor reads off a template first (164.308
        (a)(4), 164.312(a)(1)).

        So: an inline policy naming this function's own group. No
        `logs:CreateLogGroup` either — the group is declared above, and a
        function that cannot create one cannot create a group outside the
        retention and CMK policy the estate sets. `arn:...:log-group:NAME:*` is
        the log-stream form the API needs; the group ARN alone does not
        authorize `PutLogEvents`.
        """
        role = iam.Role(
            self,
            "UserMigrationRole",
            role_name=resource_name(self.env_name, "iam", "user-migration"),
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            description=(
                "Execution role for the Cognito User Migration trigger. Logs to its "
                "own declared log group and nothing else."
            ),
            inline_policies={
                "WriteOwnLogs": iam.PolicyDocument(
                    statements=[
                        iam.PolicyStatement(
                            actions=["logs:CreateLogStream", "logs:PutLogEvents"],
                            resources=[
                                log_group.log_group_arn,
                                f"{log_group.log_group_arn}:*",
                            ],
                        )
                    ]
                )
            },
        )
        return role

    # ------------------------------------------------------- identity export
    def _cognito_export(self, logs_key: kms.IKey, export_key: kms.IKey) -> lambda_.Function:
        """The nightly Cognito identity export (T:163, decision D15).

        A user pool is regional and AWS does not back it up, so every night at 06:00
        UTC `scripts/cognito_export.py`'s `handler` lists the pool and writes
        `cognito_export/<stamp>.json` -- username, `sub`, email + verified,
        `custom:app_uid`, status, enabled, linked IdPs; never a password, which
        Cognito never returns -- into **`meridian-<env>-s3-archive`**.

        **Seven years comes from that bucket, not from anything new here.** It is
        Object Lock, compliance mode, `OBJECT_LOCK_RETENTION_DAYS` (2555) by default
        (`data.py` `_archive_bucket`), on the `phi` CMK, and it has no expiry rule.
        That is the retention Andres confirmed for every address (D15).

        The bucket is addressed by its **name** (`resource_name`, the convention
        `data.py` uses) rather than by importing it, so this adds no export to the
        `data` stack; the `phi` key's ARN is already exported. Its bucket policy
        refuses a put that is not SSE-KMS under that key's ARN, which is why the key
        ARN (not an alias) is what the function is given.

        Least privilege, written inline so nothing else lands on the role:
        `cognito-idp:ListUsers` on this pool; `s3:PutObject` on `cognito_export/*` in
        that one bucket; `kms:GenerateDataKey`/`kms:Encrypt` on that one key; and its
        own log group. Errors alarm from `observability.py`, addressed by name.
        """
        name = resource_name(self.env_name, "lambda", "cognito-export")
        bucket_name = resource_name(self.env_name, "s3", "archive")
        log_group = logs.LogGroup(
            self,
            "CognitoExportLogGroup",
            log_group_name=f"/aws/lambda/{name}",
            retention=LOG_RETENTION,
            encryption_key=logs_key,
            removal_policy=RemovalPolicy.RETAIN,
        )
        role = iam.Role(
            self,
            "CognitoExportRole",
            role_name=resource_name(self.env_name, "iam", "cognito-export"),
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            description=(
                "Nightly Cognito identity export (T:163): lists this pool, writes one "
                "SSE-KMS object under cognito_export/ in the archive bucket."
            ),
            inline_policies={
                "CognitoExport": iam.PolicyDocument(
                    statements=[
                        iam.PolicyStatement(
                            sid="WriteOwnLogs",
                            actions=["logs:CreateLogStream", "logs:PutLogEvents"],
                            resources=[
                                log_group.log_group_arn,
                                f"{log_group.log_group_arn}:*",
                            ],
                        ),
                        iam.PolicyStatement(
                            sid="ListThisPoolsUsers",
                            actions=["cognito-idp:ListUsers"],
                            resources=[self.user_pool.user_pool_arn],
                        ),
                        iam.PolicyStatement(
                            sid="PutExportsOnly",
                            actions=["s3:PutObject"],
                            resources=[
                                f"arn:{Aws.PARTITION}:s3:::{bucket_name}/{COGNITO_EXPORT_PREFIX}*"
                            ],
                        ),
                        iam.PolicyStatement(
                            sid="EncryptWithThePhiKey",
                            actions=["kms:GenerateDataKey", "kms:Encrypt"],
                            resources=[export_key.key_arn],
                        ),
                    ]
                )
            },
        )
        function = lambda_.Function(
            self,
            "CognitoExportFunction",
            function_name=name,
            description=(
                "Nightly Cognito identity export to the Object-Locked archive bucket "
                "(T:163, D15). No passwords exist to export."
            ),
            runtime=lambda_.Runtime.PYTHON_3_12,
            architecture=lambda_.Architecture.ARM_64,
            handler=f"{COGNITO_EXPORT_MODULE}.handler",
            # `scripts/` filtered to the one module: the CLI and the Lambda share it.
            code=lambda_.Code.from_asset(
                str(COGNITO_EXPORT_SOURCE_DIR),
                exclude=["*", f"!{COGNITO_EXPORT_MODULE}.py"],
            ),
            role=role,
            timeout=COGNITO_EXPORT_TIMEOUT,
            memory_size=COGNITO_EXPORT_MEMORY_MB,
            log_group=log_group,
            environment={
                "USER_POOL_ID": self.user_pool.user_pool_id,
                "EXPORT_BUCKET": bucket_name,
                "EXPORT_KMS_KEY_ID": export_key.key_arn,
            },
        )
        events.Rule(
            self,
            "CognitoExportSchedule",
            rule_name=resource_name(self.env_name, "rule", "cognito-export"),
            description="Nightly Cognito identity export (T:163).",
            schedule=COGNITO_EXPORT_SCHEDULE,
            targets=[events_targets.LambdaFunction(function, retry_attempts=2)],
        )
        return function

    # ------------------------------------------------------------- user pool
    def _user_pool(self, migration_lambda: lambda_.IFunction | None) -> cognito.UserPool:
        return cognito.UserPool(
            self,
            "UserPool",
            user_pool_name=resource_name(self.env_name, "auth", "users"),
            # P-6: membership is by invite code plus `AdminCreateUser`. Anyone
            # who can reach the hosted domain must not be able to make an account.
            self_sign_up_enabled=False,
            sign_in_aliases=cognito.SignInAliases(email=True, username=False),
            sign_in_case_sensitive=False,
            auto_verify=cognito.AutoVerifiedAttrs(email=True),
            # No `standard_attributes`: on every UPDATE the CloudFormation handler sends
            # each standard attribute in `Schema` to AddCustomAttributes, which rejects
            # `email` whatever its shape (CloudTrail, 2026-10-05: "Invalid AttributeDataType"
            # untyped, "Required custom attributes are not supported" typed). Email is the
            # username (`sign_in_aliases`), so every user has one; a pool created before
            # this keeps `email` required, since schema settings never change after create.
            custom_attributes={
                APP_UID_ATTRIBUTE: cognito.StringAttribute(
                    max_len=APP_UID_MAX_LENGTH, mutable=False
                ),
            },
            # The one email an invited person gets (an admin's invite calls
            # AdminCreateUser): the temporary password and where to use it.
            user_invitation=cognito.UserInvitationConfig(
                email_subject="You're invited to Meridian",
                email_body=INVITE_EMAIL_HTML.replace(
                    "__HOST__", DEFAULT_CALLBACK_HOSTS[self.env_name]
                ),
            ),
            mfa=cognito.Mfa.REQUIRED,
            # TOTP only. SMS is a second factor an attacker can have transferred
            # to their own handset, and it costs money per message.
            mfa_second_factor=cognito.MfaSecondFactor(otp=True, sms=False),
            # "Remember this browser": after a correct code the backend confirms the
            # browser as a device (`src/cognito.py`), and a remembered device skips
            # the code. Always remembered, no prompt; the 30-day limit is the device
            # cookie's life (`src/auth.py` DEVICE_COOKIE_MAX_AGE), not a pool setting.
            device_tracking=cognito.DeviceTracking(
                challenge_required_on_new_device=True,
                device_only_remembered_on_user_prompt=False,
            ),
            password_policy=cognito.PasswordPolicy(
                min_length=MIN_PASSWORD_LENGTH,
                require_lowercase=True,
                require_uppercase=True,
                require_digits=True,
                require_symbols=True,
            ),
            account_recovery=cognito.AccountRecovery.EMAIL_ONLY,
            feature_plan=cognito.FeaturePlan.PLUS,
            standard_threat_protection_mode=(cognito.StandardThreatProtectionMode.AUDIT_ONLY),
            email=cognito.UserPoolEmail.with_ses(
                from_email=f"{NO_REPLY_LOCAL_PART}@{self.ses_identity_name}",
                from_name="Meridian",
                # DEVELOPER sending mode: `ses_verified_domain` is what makes CDK
                # emit `EmailSendingAccount: DEVELOPER` with a `SourceArn` on the
                # Phase 1 identity, instead of Cognito's own 50-a-day mailbox.
                ses_verified_domain=self.ses_identity_name,
                # Explicit, not inferred. `UserPoolEmail.with_ses` refuses to
                # synthesize when it cannot determine the stack's region, and the
                # region is a TOKEN on every credential-free synth — which is CI,
                # the tests, and any offline `cdk synth`. `us-east-1` is not a
                # guess: `assert_edge_region` already holds the whole estate
                # there, and the SES identity is an account-level resource in it.
                ses_region=EDGE_REGION,
                configuration_set_name=self.ses_configuration_set_name,
            ),
            # `None` after `-c legacyMigration=false`: CDK then emits no
            # `LambdaConfig` at all, which is the whole point — CloudFormation
            # removes the one trigger it owns and leaves any other alone.
            lambda_triggers=(
                cognito.UserPoolTriggers(user_migration=migration_lambda)
                if migration_lambda is not None
                else None
            ),
            # ACTIVE in both environments. Deleting a pool deletes every user and
            # every MFA enrolment in it, and there is no restore.
            deletion_protection=True,
            removal_policy=RemovalPolicy.RETAIN,
        )

    # ----------------------------------------------------------------- domain
    def _hosted_domain(self, user_pool: cognito.UserPool) -> cognito.UserPoolDomain:
        """`meridian-<env>.auth.<region>.amazoncognito.com`.

        The Cognito-hosted domain rather than a custom one: it is only ever seen
        during a federated redirect, and a custom domain needs its own ACM
        certificate and an A record that would have to be kept in step with the
        Phase 9 CloudFront cutover for no user-visible gain.

        **What Google and Microsoft are told.** Their OAuth clients redirect to
        *Cognito*, not to Meridian: the one redirect URI each registers is
        `https://meridian-<env>.auth.us-east-1.amazoncognito.com/oauth2/idpresponse`,
        so the www / app / api split (ADR 0050) does not touch either registration.
        What moved is the pool client's own callback — `/auth/callback` on the app
        host (`DEFAULT_CALLBACK_HOSTS`).
        """
        return cognito.UserPoolDomain(
            self,
            "HostedDomain",
            user_pool=user_pool,
            cognito_domain=cognito.CognitoDomainOptions(domain_prefix=f"meridian-{self.env_name}"),
        )

    # -------------------------------------------------------------- clients
    def _web_client(self, user_pool: cognito.UserPool) -> cognito.UserPoolClient:
        """The confidential client the Flask/FastAPI backend authenticates with.

        `generate_secret=True` is what makes it confidential, and confidential is
        what `ADMIN_USER_PASSWORD_AUTH` requires. The secret never reaches a
        browser: the SPA talks to our own origin, our own backend holds the
        secret and computes the `SECRET_HASH` (`src/cognito.py`).
        """
        return cognito.UserPoolClient(
            self,
            "WebClient",
            user_pool=user_pool,
            user_pool_client_name=resource_name(self.env_name, "auth", "web"),
            generate_secret=True,
            auth_flows=cognito.AuthFlow(
                # The admin flow is what lets the User Migration Lambda run.
                admin_user_password=True,
                user_password=False,
                user_srp=False,
                custom=False,
            ),
            prevent_user_existence_errors=True,
            enable_token_revocation=True,
            id_token_validity=ID_TOKEN_VALIDITY,
            access_token_validity=ID_TOKEN_VALIDITY,
            refresh_token_validity=REFRESH_TOKEN_VALIDITY,
            supported_identity_providers=self._supported_providers(),
            o_auth=cognito.OAuthSettings(
                flows=cognito.OAuthFlows(authorization_code_grant=True, implicit_code_grant=False),
                scopes=[
                    cognito.OAuthScope.OPENID,
                    cognito.OAuthScope.EMAIL,
                    cognito.OAuthScope.PROFILE,
                ],
                # Callback URLs are supplied at deploy time, not committed: they
                # differ per environment and one of them is a localhost port.
                callback_urls=self._callback_urls(),
                logout_urls=self._callback_urls(),
            ),
        )

    def _machine_client(
        self, user_pool: cognito.UserPool, resource_server: cognito.UserPoolResourceServer
    ) -> cognito.UserPoolClient:
        """Client credentials for machine callers. 15-minute tokens, no refresh.

        A client-credentials token has no human behind it, so it carries no
        `custom:app_uid` and `src/cognito.validate_token` refuses it outright.
        Machine authorization is a scope check against this resource server, and
        it arrives with the partner API (Phase 12).
        """
        return cognito.UserPoolClient(
            self,
            "MachineClient",
            user_pool=user_pool,
            user_pool_client_name=resource_name(self.env_name, "auth", "machine"),
            generate_secret=True,
            auth_flows=cognito.AuthFlow(),
            prevent_user_existence_errors=True,
            enable_token_revocation=True,
            access_token_validity=MACHINE_TOKEN_VALIDITY,
            o_auth=cognito.OAuthSettings(
                flows=cognito.OAuthFlows(client_credentials=True),
                scopes=[
                    cognito.OAuthScope.resource_server(resource_server, scope)
                    for scope in self._machine_scopes
                ],
            ),
        )

    def _resource_server(self, user_pool: cognito.UserPool) -> cognito.UserPoolResourceServer:
        catalogue = API_PLATFORM_MACHINE_SCOPES if self.api_platform else MACHINE_SCOPES
        self._machine_scopes = [
            cognito.ResourceServerScope(scope_name=name, scope_description=description)
            for name, description in catalogue
        ]
        return cognito.UserPoolResourceServer(
            self,
            "ResourceServer",
            user_pool=user_pool,
            identifier=RESOURCE_SERVER_IDENTIFIER,
            user_pool_resource_server_name=resource_name(self.env_name, "auth", "api"),
            scopes=self._machine_scopes,
        )

    def _callback_urls(self) -> list[str]:
        """OAuth redirect targets, from context, defaulted **per environment**.

        `-c authCallbackUrls=https://a,https://b` overrides. The default is this
        environment's own origin (`edge.py`'s hostname table): staging redirects
        to staging, production to production.

        One default for both used to send staging's federated sign-in to the
        production origin. That is not merely wrong-and-obvious: an allowed
        callback URL is a redirect target for a real authorization code, so
        pointing a *non-production* pool's callback at the *production* host
        crosses the two environments at the one moment a credential is in flight.
        A default that is wrong per environment is worse than one that is missing.
        """
        raw = str(self.node.try_get_context("authCallbackUrls") or "")
        urls = [url.strip() for url in raw.split(",") if url.strip()]
        if urls:
            return urls
        host = DEFAULT_CALLBACK_HOSTS.get(self.env_name)
        if host is None:
            raise ValueError(
                f"No default OAuth callback host for environment {self.env_name!r}. "
                "Add one to DEFAULT_CALLBACK_HOSTS or pass -c authCallbackUrls=..."
            )
        return [f"https://{host}{CALLBACK_PATH}"]

    # ------------------------------------------------------ federated IdPs
    def _wants(self, context_key: str) -> bool:
        return str(self.node.try_get_context(context_key) or "").lower() in ("1", "true", "yes")

    def _sign_in_with(self, sign_in_key: str, idp_key: str) -> bool:
        """True when this provider is offered as a sign-in button on the client.

        Enabling sign-in without creating the provider is refused at synth, not
        at deploy: CloudFormation's message for a client naming a provider that
        does not exist arrives after the stack has started changing, and this
        one is a typo in a `-c` flag.
        """
        if not self._wants(sign_in_key):
            return False
        if not self._wants(idp_key):
            raise ValueError(
                f"-c {sign_in_key}=true needs -c {idp_key}=true: the web client cannot "
                "list an identity provider that this stack has not created. Deploy with "
                f"-c {idp_key}=true first, link the existing identities "
                "(scripts/preprovision_cognito_users.py), then deploy again with "
                f"-c {sign_in_key}=true."
            )
        return True

    def _supported_providers(self) -> list[cognito.UserPoolClientIdentityProvider]:
        """What the web client offers — NOT what exists on the pool.

        A provider is created first and offered second, with the pre-provision
        and linking step in between (module docstring, runbook §2).
        """
        providers = [cognito.UserPoolClientIdentityProvider.COGNITO]
        if self._sign_in_with(GOOGLE_SIGN_IN_CONTEXT, GOOGLE_IDP_CONTEXT):
            providers.append(cognito.UserPoolClientIdentityProvider.GOOGLE)
        if self._sign_in_with(ENTRA_SIGN_IN_CONTEXT, ENTRA_IDP_CONTEXT):
            providers.append(cognito.UserPoolClientIdentityProvider.custom("Microsoft"))
        return providers

    def _identity_providers(self, user_pool: cognito.UserPool) -> list[Construct]:
        """Google and Entra, each only once its secret has been filled in.

        Both map the provider's email onto the pool's `email` attribute and
        nothing else. Names and avatars are `user_profiles`' business, and a
        mapping that overwrote them on every federated sign-in would silently
        undo whatever the user had set.
        """
        providers: list[Construct] = []
        if self._wants(GOOGLE_IDP_CONTEXT):
            providers.append(
                cognito.UserPoolIdentityProviderGoogle(
                    self,
                    "GoogleIdp",
                    user_pool=user_pool,
                    client_id=SecretValue.secrets_manager(
                        self.google_secret.secret_arn, json_field="client_id"
                    ).unsafe_unwrap(),
                    client_secret_value=SecretValue.secrets_manager(
                        self.google_secret.secret_arn, json_field="client_secret"
                    ),
                    scopes=["openid", "email", "profile"],
                    attribute_mapping=cognito.AttributeMapping(
                        email=cognito.ProviderAttribute.GOOGLE_EMAIL
                    ),
                )
            )

        if self._wants(ENTRA_IDP_CONTEXT):
            tenant = SecretValue.secrets_manager(
                self.entra_secret.secret_arn, json_field="tenant_id"
            ).unsafe_unwrap()
            providers.append(
                cognito.UserPoolIdentityProviderOidc(
                    self,
                    "EntraIdp",
                    user_pool=user_pool,
                    name="Microsoft",
                    client_id=SecretValue.secrets_manager(
                        self.entra_secret.secret_arn, json_field="client_id"
                    ).unsafe_unwrap(),
                    client_secret=SecretValue.secrets_manager(
                        self.entra_secret.secret_arn, json_field="client_secret"
                    ).unsafe_unwrap(),
                    issuer_url=f"https://login.microsoftonline.com/{tenant}/v2.0",
                    scopes=["openid", "email", "profile"],
                    attribute_mapping=cognito.AttributeMapping(
                        email=cognito.ProviderAttribute.other("email")
                    ),
                )
            )
        return providers

    # ---------------------------------------------------------------- outputs
    def _outputs(self) -> None:
        """The three values `src/settings.py` asks for by name.

        **The client secret is not among them.** It is in
        `meridian-<env>/cognito-web-client` (`_web_client_secret`), which the api
        task's `secrets:` block reads; a CfnOutput is world-readable to anyone with
        `cloudformation:DescribeStacks`. On ECS all four `COGNITO_*` values, plus
        `COGNITO_DOMAIN`, are wired by `compute.py` — these outputs are for a
        human configuring anything else.
        """
        CfnOutput(
            self,
            "UserPoolId",
            value=self.user_pool.user_pool_id,
            description="COGNITO_USER_POOL_ID for the application environment.",
        )
        CfnOutput(
            self,
            "WebClientId",
            value=self.web_client.user_pool_client_id,
            description="COGNITO_CLIENT_ID for the application environment.",
        )
        if self.machine_client is not None:
            CfnOutput(
                self,
                "MachineClientId",
                value=self.machine_client.user_pool_client_id,
                description="Client-credentials client id (Phase 12 partner API).",
            )
        CfnOutput(
            self,
            "HostedDomainPrefix",
            value=self.domain.domain_name,
            description="Cognito hosted domain prefix; the federated redirect target.",
        )
