"""The nightly eCW mart copy's AWS side (ADR 0053, `docs/runbooks/ecw-mart.md`).

**Built by `ComputeStack` only with `-c ecwMart=true -c ecwOrgId=<uuid>`, off by default.**
Off, nothing in this module is instantiated and the compute, api and worker templates are
byte-identical to the ones before it existed (`infra/tests/test_mart.py`). On, it adds:

* **`meridian-<env>-ecs-mart-sync`**: a Fargate task definition of the **api image** (same
  repository, same tag as the api) running `python3 scripts/sync_data_mart.py --target rds`,
  ARM64 0.5 vCPU / 1 GB. It copies the eCW data mart's BI tables into the RDS `mart` schema
  as `meridian_mart_owner` and nothing else.
* **Its own execution role and task role.** The shared execution role resolves the api's
  secrets; this task needs two different ones (the owner login, and the hand-made
  `meridian-<env>/ecw-db` source login), and giving the api's role those would let the api
  read the owner's and the source's passwords. The task role has **no policy statements**: the
  loader talks to two PostgreSQL servers and writes stdout, nothing in AWS.
* **A log group** `/meridian/<env>/ecs/mart-sync` on the `logs` CMK, retention like the worker's.
* **A schedule** `meridian-<env>-schedule-mart-sync`: EventBridge Scheduler, 05:00 Central
  every night, `RunTask` of the family (the api's idle-sweep shape), through a role that may
  run that one family on this cluster and pass only the two mart roles.

The api's `MART_DB_*` / `ECW_ORG_ID` settings are `compute.py`'s (they live in the api's
task definition); this module owns the loader only.

WHY `compute` AND NOT `api`
---------------------------
The deploy workflow deploys `meridian-<env>-compute` alone, with the commit's image tag: the
loader has to run the same code the api runs, so it lives next to the image tag, like the
worker (`stacks/worker.py`).

GATE BEFORE THE FIRST LOAD (checker warning 8)
----------------------------------------------
The source server admits only allowlisted addresses (this environment's NAT address,
`meridian-<env>-eip-nat`). **One P&L run from AWS (`-c ecwDb=true`) must have succeeded
before the first load**: that is the proof the NAT address is on the allowlist and the
`ecw-db` login works from here. The runbook's step 1 carries the same gate. Until then the
nightly schedule would only fail, so a deploy with this flag on is safe but pointless.

TLS to the source
-----------------
`MART_SOURCE_SSLMODE` defaults to `verify-full` (the CA bundle in the image). If the source
server's certificate does not verify, redeploy with `-c ecwMartSourceSslMode=require`; the
loader accepts those two values and nothing weaker. The `ecw-db` secret has no port, so
`MART_SOURCE_PORT` is a plain setting (5432).

Cost (per month, approximate)
-----------------------------
Fargate ARM 0.5 vCPU / 1 GB, ~15 min a night: ~$0.3. NAT data processing, ~0.8 GB a night
x $0.045/GB: ~$1. Two secrets: $0.80. RDS storage, +~1 GB gp3: ~$0.1 plus backup churn.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from aws_cdk import Aws, RemovalPolicy
from aws_cdk import aws_ecs as ecs
from aws_cdk import aws_iam as iam
from aws_cdk import aws_logs as logs
from aws_cdk import aws_scheduler as scheduler
from aws_cdk import aws_secretsmanager as secretsmanager
from constructs import Construct

from ..config import (
    ECW_MART_SOURCE_DB,
    ECW_MART_SOURCE_PORT,
    MART_SYNC_SCHEDULE,
    MART_SYNC_TIMEZONE,
    ecw_mart_source_sslmode,
    ecw_org_id,
)
from ..naming import resource_name
from .data import LOG_RETENTION, mart_secret_arn
from .vpc import SUBNET_APP

if TYPE_CHECKING:
    from .compute import ComputeStack

#: The container name, the log stream prefix and the last segment of every name.
MART_SYNC = "mart-sync"

#: ARM64, 0.5 vCPU / 1 GB, like the worker.
MART_SYNC_CPU = 512
MART_SYNC_MEMORY_MIB = 1024

#: The loader's command; the first load overrides it (`aws ecs run-task --overrides`).
MART_SYNC_COMMAND = ("python3", "scripts/sync_data_mart.py", "--target", "rds")

#: The RDS roles Alembic 0048 creates, and the database they live in.
MART_OWNER_ROLE = "meridian_mart_owner"
MART_READER_ROLE = "meridian_mart_reader"
MART_DATABASE = "meridian"

#: The hand-made source login's fields, by name (`ecw-db` has no port).
ECW_SOURCE_FIELDS = (
    ("MART_SOURCE_HOST", "host"),
    ("MART_SOURCE_NAME", "dbname"),
    ("MART_SOURCE_USER", "user"),
    ("MART_SOURCE_PASSWORD", "password"),
)


def mart_sync_family(env: str) -> str:
    """`meridian-<env>-ecs-mart-sync`."""
    return resource_name(env, "ecs", MART_SYNC)


class MartSync(Construct):
    """The loader's task definition, roles, log group and nightly schedule. See the module."""

    def __init__(self, scope: Construct, construct_id: str, *, compute: ComputeStack) -> None:
        super().__init__(scope, construct_id)
        self.compute = compute
        self.env_name = compute.env_name
        self.data = compute.data
        self.org_id = ecw_org_id(compute)
        self.owner_secret = secretsmanager.Secret.from_secret_complete_arn(
            self, "MartOwnerSecretRef", mart_secret_arn(self.env_name, "owner")
        )
        # By NAME, like compute's `ecw_db_secret`: it is created by hand.
        self.source_secret = secretsmanager.Secret.from_secret_name_v2(
            self, "EcwSourceSecretRef", f"meridian-{self.env_name}/ecw-db"
        )
        self.log_group = self._log_group()
        self.execution_role = self._execution_role()
        self.task_role = self._task_role()
        self.task_definition = self._task_definition()
        self.schedule = self._schedule()

    # ---------------------------------------------------------------- logs
    def _log_group(self) -> logs.LogGroup:
        """`/meridian/<env>/ecs/mart-sync`, on the `logs` CMK, retention like the worker's."""
        return logs.LogGroup(
            self,
            "LogGroup",
            log_group_name=f"/meridian/{self.env_name}/ecs/{MART_SYNC}",
            retention=LOG_RETENTION,
            encryption_key=self.data.keys["logs"],
            removal_policy=(
                RemovalPolicy.DESTROY
                if self.compute.env_config.destroyed_between_phases
                else RemovalPolicy.RETAIN
            ),
        )

    # --------------------------------------------------------------- roles
    def _execution_role(self) -> iam.Role:
        """ECR pull + logs (granted by the container below) + the two secrets it names."""
        from .compute import _allow_secret_read

        role = iam.Role(
            self,
            "ExecutionRole",
            role_name=resource_name(self.env_name, "iam", "ecs-mart-sync-execution"),
            assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            description=(
                f"Meridian {self.env_name}: the ECS agent for the mart-sync task. Pulls the "
                "image, writes logs, resolves the owner and source logins."
            ),
        )
        _allow_secret_read(
            role, "MartOwnerSecret", self.owner_secret.secret_arn, self.data.keys["rds"]
        )
        _allow_secret_read(
            role,
            "EcwSourceSecret",
            f"{self.source_secret.secret_arn}-??????",
            self.data.keys["logs"],
        )
        return role

    def _task_role(self) -> iam.Role:
        """No policy statements: the loader reaches two PostgreSQL servers and stdout."""
        return iam.Role(
            self,
            "TaskRole",
            role_name=resource_name(self.env_name, "iam", "ecs-mart-sync-task"),
            assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            description=f"Meridian {self.env_name}: the mart-sync loader. Holds no AWS permission.",
        )

    # ------------------------------------------------------ task definition
    def _task_definition(self) -> ecs.FargateTaskDefinition:
        from .compute import API

        compute = self.compute
        endpoint = compute.data.database.db_instance_endpoint_address
        task_definition = ecs.FargateTaskDefinition(
            self,
            "TaskDefinition",
            family=mart_sync_family(self.env_name),
            cpu=MART_SYNC_CPU,
            memory_limit_mib=MART_SYNC_MEMORY_MIB,
            execution_role=self.execution_role,
            task_role=self.task_role,
            runtime_platform=ecs.RuntimePlatform(
                cpu_architecture=ecs.CpuArchitecture.ARM64,
                operating_system_family=ecs.OperatingSystemFamily.LINUX,
            ),
        )
        environment = {
            "MART_TARGET_HOST": endpoint,
            "MART_TARGET_PORT": compute.data.database.db_instance_endpoint_port,
            "MART_TARGET_NAME": MART_DATABASE,
            "MART_TARGET_USER": MART_OWNER_ROLE,
            # The one host the loader may write to (`scripts/mart_target.py` refuses any other).
            "MART_TARGET_ALLOWED_HOSTS": endpoint,
            "PG_SSLROOTCERT": "/etc/ssl/rds/global-bundle.pem",
            "ECW_ORG_ID": self.org_id,
            "MART_SOURCE_PORT": ECW_MART_SOURCE_PORT,
            "MART_SOURCE_SSLMODE": ecw_mart_source_sslmode(compute),
            "MART_SOURCE_EXPECTED_DB": ECW_MART_SOURCE_DB[self.env_name],
        }
        secrets = {
            "MART_TARGET_PASSWORD": ecs.Secret.from_secrets_manager(self.owner_secret, "password")
        }
        for name, field in ECW_SOURCE_FIELDS:
            secrets[name] = ecs.Secret.from_secrets_manager(self.source_secret, field)
        task_definition.add_container(
            MART_SYNC,
            container_name=MART_SYNC,
            # The SAME repository and tag as the api container: one build, one sha.
            image=ecs.ContainerImage.from_ecr_repository(
                compute.repositories[API], compute.image_tags[API]
            ),
            command=list(MART_SYNC_COMMAND),
            logging=ecs.LogDriver.aws_logs(stream_prefix=MART_SYNC, log_group=self.log_group),
            environment=environment,
            secrets=secrets,
        )
        return task_definition

    # ------------------------------------------------------------ schedule
    def _schedule(self) -> scheduler.CfnSchedule:
        """05:00 Central every night: `RunTask` of the family (no revision), the sweep's shape.

        The family ARN never changes; `RunTask` without a revision runs the latest ACTIVE
        one, which is the one the last compute deploy registered. IAM gets the family and
        `family:*` and the cluster condition, and may pass only the two mart roles.
        """
        compute = self.compute
        cluster = compute.cluster
        family_arn = compute.format_arn(
            service="ecs",
            resource="task-definition",
            resource_name=mart_sync_family(self.env_name),
        )
        role = iam.Role(
            self,
            "SchedulerRole",
            role_name=resource_name(self.env_name, "iam", "mart-sync-scheduler"),
            assumed_by=iam.ServicePrincipal(
                "scheduler.amazonaws.com",
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            ),
            description="EventBridge Scheduler: run the nightly mart-sync task, nothing else.",
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="RunTheMartSyncTaskOnThisCluster",
                actions=["ecs:RunTask"],
                resources=[family_arn, f"{family_arn}:*"],
                conditions={"ArnEquals": {"ecs:cluster": cluster.cluster_arn}},
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="PassTheMartSyncRoles",
                actions=["iam:PassRole"],
                resources=[self.execution_role.role_arn, self.task_role.role_arn],
                conditions={"StringEquals": {"iam:PassedToService": "ecs-tasks.amazonaws.com"}},
            )
        )
        subnets = compute.vpc.select_subnets(subnet_group_name=SUBNET_APP).subnet_ids
        return scheduler.CfnSchedule(
            self,
            "NightlySync",
            name=resource_name(self.env_name, "schedule", MART_SYNC),
            description="Copy the eCW data mart's BI tables into RDS (ADR 0053).",
            schedule_expression=MART_SYNC_SCHEDULE,
            schedule_expression_timezone=MART_SYNC_TIMEZONE,
            flexible_time_window=scheduler.CfnSchedule.FlexibleTimeWindowProperty(mode="OFF"),
            state="ENABLED",
            target=scheduler.CfnSchedule.TargetProperty(
                arn=cluster.cluster_arn,
                role_arn=role.role_arn,
                input=json.dumps({}, separators=(",", ":")),
                ecs_parameters=scheduler.CfnSchedule.EcsParametersProperty(
                    task_definition_arn=family_arn,
                    launch_type="FARGATE",
                    task_count=1,
                    network_configuration=scheduler.CfnSchedule.NetworkConfigurationProperty(
                        awsvpc_configuration=scheduler.CfnSchedule.AwsVpcConfigurationProperty(
                            subnets=subnets,
                            security_groups=[compute.app_sg.security_group_id],
                            assign_public_ip="DISABLED",
                        )
                    ),
                ),
                retry_policy=scheduler.CfnSchedule.RetryPolicyProperty(maximum_retry_attempts=1),
            ),
        )
