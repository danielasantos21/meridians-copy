"""`meridian-shared-foundation` — the account-level security floor.

Deployed **once** for the whole AWS account, not once per environment: CloudTrail,
GuardDuty, Security Hub, AWS Config, Inspector, IAM Access Analyzer, the
break-glass role, budgets, and the GitHub Actions OIDC trust. This is plan
Phase 1 steps 5, 7 and 8 (`docs/aws-migration-plan.md`).

Two things that are **not** here on purpose:

* **KMS CMKs per environment** (Phase 1 step 6) live in each environment's `data`
  stack, so that tearing staging down (ADR 0008 / D-15) does not schedule its keys
  for deletion along with the network. The only key here is the foundation key
  that encrypts this stack's own audit logs.
* **GuardDuty Malware Protection for S3** is configured per bucket and billed per
  GB, so it is attached to the `phi` upload bucket in the data stack, not enabled
  account-wide here.

**The account is shared (ADR 0001).** GuardDuty, Security Hub, the Config recorder,
Inspector and the GitHub OIDC provider are all *singletons per account*: if the
other owner in this account has already enabled one, creating it again fails the
whole stack. Each therefore sits behind a context switch (`enableGuardDuty`,
`enableSecurityHub`, `enableConfigRecorder`, `enableInspector`,
`createGithubOidcProvider`) documented in `cdk.json`. Flip one to `false` and
record why in `docs/compliance/`; do not adopt the other owner's resource.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from aws_cdk import (
    Annotations,
    Aws,
    CfnParameter,
    Duration,
    RemovalPolicy,
    Stack,
    Tags,
)
from aws_cdk import (
    aws_accessanalyzer as accessanalyzer,
)
from aws_cdk import (
    aws_budgets as budgets,
)
from aws_cdk import (
    aws_ce as ce,
)
from aws_cdk import (
    aws_cloudtrail as cloudtrail,
)
from aws_cdk import (
    aws_cloudwatch as cloudwatch,
)
from aws_cdk import (
    aws_cloudwatch_actions as cw_actions,
)
from aws_cdk import (
    aws_config as config,
)
from aws_cdk import (
    aws_guardduty as guardduty,
)
from aws_cdk import (
    aws_iam as iam,
)
from aws_cdk import (
    aws_kms as kms,
)
from aws_cdk import (
    aws_logs as logs,
)
from aws_cdk import (
    aws_s3 as s3,
)
from aws_cdk import (
    aws_s3_assets as s3_assets,
)
from aws_cdk import (
    aws_securityhub as securityhub,
)
from aws_cdk import (
    aws_sns as sns,
)
from aws_cdk import (
    custom_resources as cr,
)
from constructs import Construct

from ..config import (
    ACCOUNT_BUDGET_USD,
    ANOMALY_THRESHOLD_USD,
    DEFAULT_COST_CENTER,
    DEFAULT_OWNER,
    ENV_CONFIG,
    GITHUB_REPO,
)
from ..naming import SHARED, resource_name
from ..tags import common_tags
from .base import assert_edge_region

#: **2555 days** = `7 * 365`, leap days not counted — so it is one or two days short of
#: seven calendar years, not seven calendar years (that would be 2557). Deliberate:
#: 45 CFR 164.316(b)(2)(i) requires **6**-year retention of documentation, and the extra
#: year absorbs the gap between "created" and "last in effect", so the slack is a year and
#: the rounding is inside it. `OBJECT_LOCK_RETENTION_DAYS` in `stacks/data.py` is the same
#: figure for the same reason; change them together, and the tests with them.
AUDIT_RETENTION_DAYS = 2555

#: Plan §2.4 / Phase 2 step 1 use the same figure for VPC flow logs.
LOG_GROUP_RETENTION = logs.RetentionDays.THIRTEEN_MONTHS  # 400 days

#: GitHub's OIDC issuer. The thumbprint is no longer verified by IAM for this
#: issuer, but the property is still accepted and kept for older tooling.
GITHUB_OIDC_URL = "https://token.actions.githubusercontent.com"
GITHUB_OIDC_THUMBPRINT = "6938fd4d98bab03faadb97b34396831e3780aea1"
GITHUB_OIDC_CLAIM = "token.actions.githubusercontent.com"

#: The branches whose workflow runs may assume `meridian-shared-iam-github-deploy`.
#: `aws-migration` is where the migration lands; `main` is where it lands after
#: that. Anything else — a fork, a tag, a `pull_request` run, a workflow on a
#: feature branch — fails `sts:AssumeRoleWithWebIdentity` outright.
GITHUB_DEPLOY_BRANCHES = ("aws-migration", "main")

#: The GitHub **Environments** whose jobs may assume `meridian-shared-iam-github-deploy`.
#:
#: An OIDC token minted by a job that declares `environment: staging` carries the
#: subject `repo:<repo>:environment:staging` instead of `repo:<repo>:ref:refs/heads/<branch>`.
#: Trusting the environment form binds the role to the one workflow shape that
#: opts in, not to every workflow that happens to run on a trusted branch
#: (CX-INF-02): a new or compromised workflow on `main` gets a `ref:` subject and
#: is refused. The branch restriction moves to the Environment's
#: deployment-branch policy (`aws-migration`, `main`), set in repository
#: settings; `docs/runbooks/deploy-staging.md` records it. Production is not
#: listed because `deploy.yml` cannot target it — production is deployed by hand.
GITHUB_DEPLOY_ENVIRONMENTS = ("staging",)

#: The CDK bootstrap **qualifier**. `cdk bootstrap` with no `--qualifier` uses
#: `hnb659fds` (not an acronym; CDK's own documentation calls it a random
#: string), and every bootstrap role is named
#: `cdk-<qualifier>-<purpose>-role-<account>-<region>`. `infra/README.md`
#: documents the bootstrap this estate ran, and it used the default.
CDK_BOOTSTRAP_QUALIFIER = "hnb659fds"

#: The one CloudFormation stack `.github/workflows/deploy.yml` deploys, and the
#: only stack `meridian-shared-iam-github-deploy` may drive CloudFormation on
#: **directly**.
#:
#: **It is not the whole boundary, and round 2's claim that it was is withdrawn**
#: (P5AR3-03). `cdk deploy` does almost nothing as the caller: it assumes
#: `cdk-<qualifier>-deploy-role`, and THAT role — created by `cdk bootstrap`, not
#: by this file — is account-wide and passes `cdk-<qualifier>-cfn-exec-role`,
#: which this estate bootstrapped with `AdministratorAccess`. So a workflow that
#: could run an arbitrary `cdk deploy` could reach any stack in the account,
#: whatever this constant says. What actually holds the line today is two things
#: that are real: `--exclusively` in the workflow (CDK deploys this stack and
#: nothing it depends on) and the trust policy below (only this repository, only
#: two branches, so only a commit that passed review can dispatch it at all).
#: `docs/migration-tracker.md` carries the row for the fix — a staging-only
#: bootstrap qualifier with scoped `--cloudformation-execution-policies`, and
#: this role pointed at those bootstrap roles instead.
GITHUB_DEPLOY_STACK = "meridian-staging-compute"

#: The environment whose ECR repositories, ECS services and task roles that stack
#: owns. Staging only, deliberately: production is deployed by hand, one stack at
#: a time, with the runbook open.
GITHUB_DEPLOY_ENV = "staging"

#: The OIDC subjects `meridian-shared-iam-github-diff` trusts — Phase 8.
#:
#: **Round 1 narrowed this (P8-03).** It first included `…:pull_request`, on the
#: reasoning that a pull request is when a `cdk diff` is worth having. That was
#: wrong in one specific way: `cdk diff` renders the pull request's own Python on
#: the runner, so trusting `pull_request` hands **pre-review code** an
#: account-wide read-only identity — the `cdk-<qualifier>-lookup-role` is
#: `ReadOnlyAccess`, which is CloudWatch Logs reads (including the PHI access
#: audit log once it is live), `cognito-idp:ListUsers`, `rds:Describe*`,
#: `secretsmanager:ListSecrets`/`DescribeSecret` and every non-CMK S3 object.
#: Read-only is not harmless when the thing being read is a PHI estate.
#:
#: So the subject list is now **exactly the deploy role's**: the two branches,
#: nothing else. `infra-diff` runs on `push` to those branches, which is
#: *after* review, and the diff it prints is the diff of what is about to be
#: deployed — which is the question the job was added to answer anyway.
#: `docs/compliance/threat-model.md` §13.7.5 enumerates the reach and the
#: residual.
#:
#: A consequence worth stating: a fork cannot reach this role at all now, not
#: because a workflow condition excludes it but because a fork cannot push to
#: this repository's branches. There is no `pull_request` claim left to confuse
#: with a fork's.
GITHUB_DIFF_SUBJECTS = tuple(
    f"repo:{GITHUB_REPO}:ref:refs/heads/{branch}" for branch in GITHUB_DEPLOY_BRANCHES
)

#: The CloudFormation stack ARNs the diff role may read: `meridian-*` only.
#:
#: A `cdk diff` of a stack outside that prefix fails closed with an
#: `AccessDenied`, which is the intended behaviour — this role exists to compare
#: Meridian's templates with Meridian's stacks and has no business reading the
#: other owner's (ADR 0001).
GITHUB_DIFF_STACK_PREFIX = "meridian-*"

#: Inspector v2 resource types this account scans. See `_inspector`.
INSPECTOR_RESOURCE_TYPES = ("ECR", "LAMBDA")

#: Security Hub standards. There is **no HIPAA standard in Security Hub** — the
#: HIPAA control set is an AWS Config conformance pack (below). NIST SP 800-53
#: Rev 5 is the Security Hub standard HIPAA assessments map onto, so it stands in
#: for "HIPAA" here and the control matrix says so.
#:
#: **CIS v3.0.0 was added in Phase 8, and the plan did not ask for it** (P8-07:
#: the earlier comment here claimed the plan's Phase 8 list "names it
#: explicitly"; it does not — the plan names Security Hub with "the AWS
#: Foundational and HIPAA standards" and no benchmark). It is added because CIS
#: is the benchmark a pen-test report and a SOC 2 auditor ask for **by name**,
#: and because its ~60 controls are the cheapest way to be told about a
#: root-account or region-level lapse — the class of finding FSBP and NIST
#: 800-53 report unevenly. All three standards read the same Config recorder, so
#: the marginal cost is Security Hub's own per-check charge, already inside the
#: Phase 1 estimate's $5–20 range for this line.
#:
#: The ARN shape differs by version and is easy to get wrong: CIS **v1.2.0** is
#: the region-less `ruleset/cis-aws-foundations-benchmark/v/1.2.0`; v1.4.0 and
#: v3.0.0 use the regional `standards/...` form every other standard uses, which
#: is the form the f-string below builds.
SECURITY_HUB_STANDARDS = {
    "Fsbp": "standards/aws-foundational-security-best-practices/v/1.0.0",
    "Nist80053R5": "standards/nist-800-53/v/5.0.0",
    "CisV3": "standards/cis-aws-foundations-benchmark/v/3.0.0",
}

#: The AWS-published conformance pack. The YAML itself is **vendored** into
#: `infra/conformance-packs/` and published as a CDK asset, so there is no manual
#: upload step and no chance of the deployed control set differing from the one in
#: this repository. See `infra/conformance-packs/README.md` for the source URL and
#: the upstream commit.
HIPAA_CONFORMANCE_PACK = "Operational-Best-Practices-for-HIPAA-Security"
HIPAA_CONFORMANCE_PACK_FILE = (
    Path(__file__).resolve().parents[2] / "conformance-packs" / f"{HIPAA_CONFORMANCE_PACK}.yaml"
)

#: GuardDuty feature switches, stated explicitly so the bill matches
#: `docs/reports/phase-1-cost-estimate.md` rather than whatever AWS's default is
#: on the day the stack is deployed. The detector's base analysis (CloudTrail,
#: VPC flow logs, DNS logs) is not a feature and is always on; everything here is
#: an *extra* billed on its own meter.
#:
#: `S3_DATA_EVENTS` is the one we buy: it is how GuardDuty sees reads and writes
#: against the future `meridian-<env>-s3-phi` bucket. The rest are off because
#: nothing in the estate produces them yet (no EKS, no Lambda in the data path)
#: or because they are billed per GB scanned on resources we do not run
#: (`EBS_MALWARE_PROTECTION` — EC2 volume scanning; Malware Protection for *S3*
#: is a separate, per-bucket setting attached in the data stack).
GUARDDUTY_FEATURES: tuple[tuple[str, str], ...] = (
    ("S3_DATA_EVENTS", "ENABLED"),
    ("EKS_AUDIT_LOGS", "DISABLED"),
    ("EBS_MALWARE_PROTECTION", "DISABLED"),
    ("RDS_LOGIN_EVENTS", "DISABLED"),
    ("LAMBDA_NETWORK_LOGS", "DISABLED"),
    ("RUNTIME_MONITORING", "DISABLED"),
)


#: The console-drift metric filter, kept as a module constant so the test can
#: assert on it verbatim and so the runbook can quote it. See `_trail_alarms`.
#: The cost-allocation tag key the per-environment budgets filter on. It has to be
#: the *same string* the tag Aspect writes, so it is taken from there rather than
#: typed twice; a test asserts the identity.
TAG_KEY_ENVIRONMENT = "Environment"

CONSOLE_DRIFT_PATTERN = (
    '{ ($.eventName = "Create*" || $.eventName = "Delete*") '
    "&& ($.userIdentity.invokedBy NOT EXISTS) "
    '&& ($.eventType != "AwsServiceEvent") '
    '&& ( $.userIdentity.type = "IAMUser" '
    '|| $.userIdentity.sessionContext.sessionIssuer.userName = "AWSReservedSSO_*" ) }'
)


class FoundationStack(Stack):
    """Account-level audit, detection, guardrails and CI trust."""

    def __init__(self, scope: Construct, construct_id: str, **kwargs: Any) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # `AWS::CE::AnomalyMonitor` / `AnomalySubscription` are Cost Explorer, which is
        # global with a us-east-1-only endpoint: in any other region the changeset
        # fails half way and takes the trail and the alarms back with it. No-op when
        # the region is a token. See `meridian/stacks/base.py`.
        assert_edge_region(self)

        # Nothing in this stack holds PHI: it holds *audit records about* PHI
        # access. `phi` is reserved for the data stack's buckets and database.
        Tags.of(self).add("DataClassification", "internal")

        alert_email = CfnParameter(
            self,
            "AlertEmail",
            type="String",
            min_length=3,
            description=(
                "Mailbox that receives security and budget alerts. Passed at deploy "
                "time (--parameters AlertEmail=...), never committed."
            ),
        )

        self.security_alerts = self._security_alerts_topic(alert_email)
        self.foundation_key = self._foundation_key()
        self.audit_bucket = self._audit_bucket(self.foundation_key)
        self.trail_log_group = self._trail_log_group(self.foundation_key)
        self.trail = self._cloudtrail(self.audit_bucket, self.trail_log_group, self.foundation_key)
        self._trail_alarms(self.trail_log_group, self.security_alerts)
        self._guardduty()
        self._security_hub()
        self._aws_config(self.foundation_key)
        self._access_analyzer()
        self._inspector(self.foundation_key)
        self.breakglass_role = self._breakglass_role()
        self._budgets(self.security_alerts)
        self._cost_anomaly_detection(self.security_alerts)
        self._github_oidc_provider()
        self.github_deploy_role = self._github_deploy_role()
        self.github_diff_role = self._github_diff_role()

    # ------------------------------------------------------------------ alerts

    def _security_alerts_topic(self, alert_email: CfnParameter) -> sns.Topic:
        topic = sns.Topic(
            self,
            "SecurityAlerts",
            topic_name=resource_name(SHARED, "sns", "security-alerts"),
            display_name="Meridian security and budget alerts",
            master_key=None,  # see comment below
        )
        # Deliberately *not* KMS-encrypted: AWS Budgets cannot publish to an
        # SNS topic encrypted with a customer-managed key, and these messages
        # carry no PHI — an alarm name and a dollar amount.
        topic.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowBudgetsPublish",
                principals=[iam.ServicePrincipal("budgets.amazonaws.com")],
                actions=["sns:Publish"],
                resources=[topic.topic_arn],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )
        # Cost Anomaly Detection publishes as its own service principal, not as
        # Budgets. Without this statement the subscription is created and then
        # silently never delivers — AWS validates the topic policy when the
        # subscription is created, so this is also why it is not KMS-encrypted.
        topic.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowCostAnomalyDetectionPublish",
                principals=[iam.ServicePrincipal("costalerts.amazonaws.com")],
                actions=["sns:Publish"],
                resources=[topic.topic_arn],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )
        sns.Subscription(
            self,
            "SecurityAlertsEmail",
            topic=topic,
            protocol=sns.SubscriptionProtocol.EMAIL,
            endpoint=alert_email.value_as_string,
        )
        return topic

    # --------------------------------------------------------------------- kms

    def _foundation_key(self) -> kms.Key:
        key = kms.Key(
            self,
            "FoundationKey",
            alias=f"alias/{resource_name(SHARED, 'kms', 'audit')}",
            description="Encrypts the account audit trail, its log group and Config data.",
            enable_key_rotation=True,
            # An audit key that can be deleted is not an audit control.
            removal_policy=RemovalPolicy.RETAIN,
        )
        key.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowCloudTrailEncrypt",
                principals=[iam.ServicePrincipal("cloudtrail.amazonaws.com")],
                actions=["kms:GenerateDataKey*", "kms:DescribeKey", "kms:Decrypt"],
                resources=["*"],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )
        key.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowCloudWatchLogs",
                principals=[iam.ServicePrincipal(f"logs.{Aws.REGION}.amazonaws.com")],
                actions=[
                    "kms:Encrypt*",
                    "kms:Decrypt*",
                    "kms:ReEncrypt*",
                    "kms:GenerateDataKey*",
                    "kms:Describe*",
                ],
                resources=["*"],
                conditions={
                    "ArnLike": {
                        "kms:EncryptionContext:aws:logs:arn": (
                            f"arn:{Aws.PARTITION}:logs:{Aws.REGION}:{Aws.ACCOUNT_ID}:log-group:*"
                        )
                    }
                },
            )
        )
        key.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowAwsConfig",
                principals=[iam.ServicePrincipal("config.amazonaws.com")],
                actions=["kms:GenerateDataKey*", "kms:DescribeKey", "kms:Decrypt"],
                resources=["*"],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )
        return key

    # ---------------------------------------------------------------- the trail

    def _audit_bucket(self, key: kms.Key) -> s3.Bucket:
        """The write-once audit bucket.

        **Object Lock in compliance mode** means that for `AUDIT_RETENTION_DAYS`
        nobody — not the account root, not AWS Support — can delete or overwrite
        an object version. That is the point: it is the only configuration in
        which "the credential that can delete the database can also delete the
        evidence" stops being true.
        """
        bucket = s3.Bucket(
            self,
            "AuditBucket",
            bucket_name=resource_name(SHARED, "s3", "audit"),
            versioned=True,
            object_lock_enabled=True,
            object_lock_default_retention=s3.ObjectLockRetention.compliance(
                Duration.days(AUDIT_RETENTION_DAYS)
            ),
            encryption=s3.BucketEncryption.KMS,
            encryption_key=key,
            bucket_key_enabled=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            # BUCKET_OWNER_ENFORCED switches ACLs off entirely: every object is
            # owned by this account and access is decided by bucket policy and IAM
            # alone. It matters here beyond tidiness — an ACL is the one grant that
            # does not appear in a policy review, so leaving ACLs enabled means an
            # auditor reading the bucket policy has not, in fact, read who can get
            # at the audit log. CloudTrail and Config both support it (they write
            # with `bucket-owner-full-control` semantics automatically); older
            # guides that tell you to grant `s3:PutObjectAcl` predate it.
            object_ownership=s3.ObjectOwnership.BUCKET_OWNER_ENFORCED,
            enforce_ssl=True,  # adds the aws:SecureTransport=false deny statement
            removal_policy=RemovalPolicy.RETAIN,
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="glacier-after-90-days",
                    enabled=True,
                    transitions=[
                        s3.Transition(
                            storage_class=s3.StorageClass.GLACIER,
                            transition_after=Duration.days(90),
                        )
                    ],
                    noncurrent_version_transitions=[
                        s3.NoncurrentVersionTransition(
                            storage_class=s3.StorageClass.GLACIER,
                            transition_after=Duration.days(90),
                        )
                    ],
                )
            ],
        )
        bucket.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AWSCloudTrailAclCheck",
                principals=[iam.ServicePrincipal("cloudtrail.amazonaws.com")],
                actions=["s3:GetBucketAcl"],
                resources=[bucket.bucket_arn],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )
        bucket.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AWSCloudTrailWrite",
                principals=[iam.ServicePrincipal("cloudtrail.amazonaws.com")],
                actions=["s3:PutObject"],
                resources=[bucket.arn_for_objects(f"AWSLogs/{Aws.ACCOUNT_ID}/*")],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )
        return bucket

    def _trail_log_group(self, key: kms.Key) -> logs.LogGroup:
        return logs.LogGroup(
            self,
            "TrailLogGroup",
            log_group_name=f"/aws/cloudtrail/{resource_name(SHARED, 'cloudtrail', 'audit')}",
            retention=LOG_GROUP_RETENTION,
            encryption_key=key,
            removal_policy=RemovalPolicy.RETAIN,
        )

    def _cloudtrail(
        self,
        bucket: s3.Bucket,
        log_group: logs.LogGroup,
        key: kms.Key,
    ) -> cloudtrail.CfnTrail:
        """A **second** management-event trail, alongside the existing one.

        The account already has a pre-existing Terraform-managed trail (plan §1)
        belonging to the other application in this account (ADR 0001). It is
        off-limits: we do not modify, adopt, or import it, and it stays exactly
        as it is. Ours is an additional trail — see
        `docs/adr/0016-cloudtrail-second-trail.md`.

        **What the duplication costs:** the first copy of management events in an
        account is free; every additional trail's copy is charged at about
        **$2.00 per 100,000 management events**. At Meridian's volume (a handful
        of deploys and a single-digit number of human sessions per week) that is
        well under $1/month. S3 data events are billed separately at about
        $0.10 per 100,000 events and are scoped by ARN prefix below, so the
        other owner's buckets are never logged by us.

        Advanced event selectors (not basic ones) are used because only they
        support a `StartsWith` match on `resources.ARN` — which is how the future
        `meridian-<env>-s3-*` buckets are covered *before they exist*, without
        naming any of them and without catching anyone else's.
        """
        cw_role = iam.Role(
            self,
            "TrailToLogsRole",
            role_name=resource_name(SHARED, "iam", "cloudtrail-logs"),
            assumed_by=iam.ServicePrincipal("cloudtrail.amazonaws.com"),
        )
        cw_role.add_to_policy(
            iam.PolicyStatement(
                actions=["logs:CreateLogStream", "logs:PutLogEvents"],
                # Built from the NAME, not `log_group_arn`: CloudFormation's
                # `Arn` for a log group already ends in `:*`, so appending
                # `:log-stream:*` gave `...:name:*:log-stream:*`, which matches no
                # stream, and the first deploy (2026-10-02) failed AccessDenied.
                resources=[
                    f"arn:{Aws.PARTITION}:logs:{Aws.REGION}:{Aws.ACCOUNT_ID}"
                    f":log-group:{log_group.log_group_name}:log-stream:*"
                ],
            )
        )

        trail = cloudtrail.CfnTrail(
            self,
            "AuditTrail",
            trail_name=resource_name(SHARED, "cloudtrail", "audit"),
            is_logging=True,
            is_multi_region_trail=True,
            include_global_service_events=True,
            enable_log_file_validation=True,
            s3_bucket_name=bucket.bucket_name,
            kms_key_id=key.key_arn,
            cloud_watch_logs_log_group_arn=log_group.log_group_arn,
            cloud_watch_logs_role_arn=cw_role.role_arn,
            advanced_event_selectors=[
                cloudtrail.CfnTrail.AdvancedEventSelectorProperty(
                    name="Management events",
                    field_selectors=[
                        cloudtrail.CfnTrail.AdvancedFieldSelectorProperty(
                            field="eventCategory", equal_to=["Management"]
                        )
                    ],
                ),
                cloudtrail.CfnTrail.AdvancedEventSelectorProperty(
                    name="Meridian S3 object access",
                    field_selectors=[
                        cloudtrail.CfnTrail.AdvancedFieldSelectorProperty(
                            field="eventCategory", equal_to=["Data"]
                        ),
                        cloudtrail.CfnTrail.AdvancedFieldSelectorProperty(
                            field="resources.type", equal_to=["AWS::S3::Object"]
                        ),
                        cloudtrail.CfnTrail.AdvancedFieldSelectorProperty(
                            field="resources.ARN",
                            starts_with=[f"arn:{Aws.PARTITION}:s3:::meridian-"],
                        ),
                    ],
                ),
            ],
        )
        if bucket.policy is not None:
            trail.node.add_dependency(bucket.policy)
        # CloudTrail validates, at CreateTrail time, that the role it is handed can
        # actually write to the log group. The role is created before the trail by
        # reference, but its *inline policy* is a separate CloudFormation resource
        # with no implicit ordering — so without this the first deploy can fail with
        # "InsufficientDependencyServiceAccessPermission" and succeed on a retry,
        # which is the worst kind of flake: intermittent and environment-dependent.
        trail.node.add_dependency(cw_role)
        return trail

    # -------------------------------------------------------------- the alarms

    def _trail_alarms(self, log_group: logs.LogGroup, topic: sns.Topic) -> None:
        """Metric filters over the trail's CloudWatch Logs copy, plus alarms.

        These are the reason the trail is wired to CloudWatch Logs at all. A
        metric filter is the documented mechanism for this (prompt, "AWS
        hygiene"); a hand-rolled Lambda is explicitly ruled out.
        """
        namespace = "Meridian/Security"

        # The drift tripwire: a `Create*`/`Delete*` call made by a *person*.
        #
        # The obvious shape — "anything that is not a `cdk-*` role" — is wrong, and
        # wrong in the direction that matters. CloudWatch Logs filter patterns have
        # no wildcard on a `!=` comparison: `$.x != "cdk-*"` is a literal string
        # comparison against the four characters `cdk-*`, so it is true for every
        # session in the account, including our own deploys. An exclusion that
        # excludes nothing yields an alarm that fires on every deploy, and an alarm
        # that fires on every deploy is one that gets muted.
        #
        # So this matches the human path **positively** instead. There are exactly
        # two ways a person reaches this account: an IAM user
        # (`userIdentity.type = "IAMUser"` — `andres-cli` today), or an Identity
        # Center session, whose role name always begins `AWSReservedSSO_`. `=` with
        # a `*` in the value *is* a wildcard match, so the second term works where
        # the negated one did not.
        #
        # `invokedBy NOT EXISTS` stays: it drops calls AWS services make on a
        # principal's behalf, which are not somebody in a console.
        self._alarm(
            log_group,
            topic,
            namespace,
            key="ConsoleCreateDelete",
            metric_name="ConsoleCreateOrDeleteCalls",
            alarm_suffix="console-create-delete",
            description=(
                "A Create* or Delete* API call was made by a human principal, not by a "
                "CDK deploy. Someone is clicking in the console — find out who and "
                "bring the change back into infra/."
            ),
            pattern=CONSOLE_DRIFT_PATTERN,
        )

        # Root account usage. Root should sign in for account recovery and
        # nothing else; CIS 1.7 and every HIPAA assessment ask for this alarm.
        self._alarm(
            log_group,
            topic,
            namespace,
            key="RootUsage",
            metric_name="RootAccountUsage",
            alarm_suffix="root-usage",
            description="The AWS account root user was used. Confirm it was you, now.",
            pattern=(
                "{ $.userIdentity.type = \"Root\" "
                "&& $.userIdentity.invokedBy NOT EXISTS "
                "&& $.eventType != \"AwsServiceEvent\" }"
            ),
        )

        # Break-glass. 45 CFR 164.312(a)(2)(ii) requires an emergency access
        # procedure; this alarm plus docs/runbooks/break-glass.md is it.
        self._alarm(
            log_group,
            topic,
            namespace,
            key="BreakGlass",
            metric_name="BreakGlassAssumeRole",
            alarm_suffix="breakglass-assumed",
            description=(
                "The break-glass administrator role was assumed. Follow "
                "docs/runbooks/break-glass.md: record why, and rotate afterwards."
            ),
            pattern=(
                "{ ($.eventName = \"AssumeRole\") "
                "&& ($.requestParameters.roleArn = \"*meridian-shared-iam-breakglass*\") }"
            ),
        )

        # IAM policy changes. The account is shared (ADR 0001), so a widened
        # policy is the single change most likely to cross the boundary between
        # Meridian's PHI and the other application.
        self._alarm(
            log_group,
            topic,
            namespace,
            key="IamPolicyChange",
            metric_name="IamPolicyChanges",
            alarm_suffix="iam-policy-change",
            description="An IAM policy, role trust or attachment changed. Review the diff.",
            pattern=(
                "{ ($.eventName = \"DeleteGroupPolicy\") || ($.eventName = \"DeleteRolePolicy\") "
                "|| ($.eventName = \"DeleteUserPolicy\") || ($.eventName = \"PutGroupPolicy\") "
                "|| ($.eventName = \"PutRolePolicy\") || ($.eventName = \"PutUserPolicy\") "
                "|| ($.eventName = \"CreatePolicy\") || ($.eventName = \"DeletePolicy\") "
                "|| ($.eventName = \"CreatePolicyVersion\") "
                "|| ($.eventName = \"DeletePolicyVersion\") "
                "|| ($.eventName = \"AttachRolePolicy\") || ($.eventName = \"DetachRolePolicy\") "
                "|| ($.eventName = \"AttachUserPolicy\") || ($.eventName = \"DetachUserPolicy\") "
                "|| ($.eventName = \"AttachGroupPolicy\") "
                "|| ($.eventName = \"DetachGroupPolicy\") "
                "|| ($.eventName = \"UpdateAssumeRolePolicy\") }"
            ),
        )

    def _alarm(
        self,
        log_group: logs.LogGroup,
        topic: sns.Topic,
        namespace: str,
        *,
        key: str,
        metric_name: str,
        alarm_suffix: str,
        description: str,
        pattern: str,
    ) -> None:
        logs.MetricFilter(
            self,
            f"{key}Filter",
            log_group=log_group,
            filter_pattern=logs.FilterPattern.literal(pattern),
            metric_namespace=namespace,
            metric_name=metric_name,
            metric_value="1",
            default_value=0,
        )
        alarm = cloudwatch.Alarm(
            self,
            f"{key}Alarm",
            alarm_name=resource_name(SHARED, "alarm", alarm_suffix),
            alarm_description=description,
            metric=cloudwatch.Metric(
                namespace=namespace,
                metric_name=metric_name,
                statistic="Sum",
                period=Duration.minutes(5),
            ),
            threshold=1,
            evaluation_periods=1,
            comparison_operator=cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
        )
        alarm.add_alarm_action(cw_actions.SnsAction(topic))

    # ------------------------------------------------------ detection services

    def _context_flag(self, name: str, default: bool = True) -> bool:
        value = self.node.try_get_context(name)
        if value is None:
            return default
        if isinstance(value, bool):
            return value
        return str(value).lower() in ("1", "true", "yes")

    def _guardduty(self) -> None:
        if not self._context_flag("enableGuardDuty"):
            return
        # Malware Protection for S3 is per bucket and billed per GB: it is
        # attached to the `phi` upload bucket in the data stack, not here.
        guardduty.CfnDetector(
            self,
            "GuardDuty",
            enable=True,
            finding_publishing_frequency="FIFTEEN_MINUTES",
            # Stated rather than defaulted: the cost estimate is only meaningful if
            # the feature set is pinned. See GUARDDUTY_FEATURES.
            features=[
                guardduty.CfnDetector.CFNFeatureConfigurationProperty(name=name, status=status)
                for name, status in GUARDDUTY_FEATURES
            ],
        )

    def _security_hub(self) -> None:
        if not self._context_flag("enableSecurityHub"):
            return
        hub = securityhub.CfnHub(
            self,
            "SecurityHub",
            control_finding_generator="SECURITY_CONTROL",
            enable_default_standards=False,  # we choose them explicitly, below
            auto_enable_controls=True,
        )
        for key, path in SECURITY_HUB_STANDARDS.items():
            standard = securityhub.CfnStandard(
                self,
                f"SecurityHubStandard{key}",
                standards_arn=f"arn:{Aws.PARTITION}:securityhub:{Aws.REGION}::{path}",
            )
            standard.add_resource_dependency(hub)

    def _aws_config(self, key: kms.Key) -> None:
        if not self._context_flag("enableConfigRecorder"):
            return

        config_bucket = s3.Bucket(
            self,
            "ConfigBucket",
            bucket_name=resource_name(SHARED, "s3", "config"),
            versioned=True,
            encryption=s3.BucketEncryption.KMS,
            encryption_key=key,
            bucket_key_enabled=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            object_ownership=s3.ObjectOwnership.BUCKET_OWNER_ENFORCED,
            enforce_ssl=True,
            removal_policy=RemovalPolicy.RETAIN,
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="expire-after-7-years",
                    enabled=True,
                    expiration=Duration.days(AUDIT_RETENTION_DAYS),
                    noncurrent_version_expiration=Duration.days(AUDIT_RETENTION_DAYS),
                )
            ],
        )

        config_role = iam.Role(
            self,
            "ConfigRole",
            role_name=resource_name(SHARED, "iam", "config-recorder"),
            assumed_by=iam.ServicePrincipal("config.amazonaws.com"),
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name("service-role/AWS_ConfigRole")
            ],
        )
        config_bucket.grant_put(config_role)
        config_bucket.grant_read(config_role)
        config_bucket.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AWSConfigBucketAclCheck",
                principals=[iam.ServicePrincipal("config.amazonaws.com")],
                actions=["s3:GetBucketAcl", "s3:ListBucket"],
                resources=[config_bucket.bucket_arn],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )

        # `all_supported=True` records **every** resource type in the account,
        # including the other owner's (ADR 0001), and Config bills per configuration
        # item recorded — so this is the single biggest lever on the LOW-confidence
        # $5–25 Config line in the cost estimate.
        #
        # It stays on anyway. The conformance pack below is 130 AWS-authored rules
        # covering resource types across the whole account; a rule whose resource
        # type is not recorded does not fail — it reports NOT_APPLICABLE, which
        # reads exactly like a pass. Scoping the recorder to "the types Meridian
        # uses" would therefore turn an unknown number of HIPAA controls into
        # silent no-ops, and the list would need revisiting every time a phase adds
        # a service. A wrong bill is visible; a control that is quietly not
        # evaluated is not. `docs/reports/phase-1-cost-estimate.md` §1 records the
        # trade and the number to watch.
        recorder = config.CfnConfigurationRecorder(
            self,
            "ConfigRecorder",
            name=resource_name(SHARED, "config", "recorder"),
            role_arn=config_role.role_arn,
            recording_group=config.CfnConfigurationRecorder.RecordingGroupProperty(
                all_supported=True,
                include_global_resource_types=True,
            ),
        )
        # Created STOPPED, then started below once the channel exists. AWS Config
        # needs the recorder before it accepts a delivery channel, and the
        # CloudFormation handler, left to itself, tries to start the recorder at
        # create time and waits for a channel that cannot exist yet — the first
        # deploy (2026-10-02) sat in NoAvailableDeliveryChannelException for nine
        # minutes and rolled back. `StartedOnCreate` is not yet in aws-cdk-lib's
        # L1, hence the override.
        recorder.add_property_override("StartedOnCreate", False)
        channel = config.CfnDeliveryChannel(
            self,
            "ConfigDeliveryChannel",
            name=resource_name(SHARED, "config", "delivery"),
            s3_bucket_name=config_bucket.bucket_name,
            s3_kms_key_arn=key.key_arn,
            config_snapshot_delivery_properties=(
                config.CfnDeliveryChannel.ConfigSnapshotDeliveryPropertiesProperty(
                    delivery_frequency="TwentyFour_Hours"
                )
            ),
        )
        channel.add_resource_dependency(recorder)

        # Start it. `StartConfigurationRecorder` is idempotent, so it also runs on
        # update. **It must stop it again on delete**: this resource depends on
        # the channel, so CloudFormation deletes it first, and AWS Config refuses
        # to delete the last delivery channel while a recorder is running
        # (LastDeliveryChannelDeleteFailedException). Without the stop, the third
        # deploy's rollback (2026-10-02) retried that delete for over an hour.
        start_call = cr.AwsSdkCall(
            service="ConfigService",
            action="startConfigurationRecorder",
            parameters={"ConfigurationRecorderName": recorder.ref},
            physical_resource_id=cr.PhysicalResourceId.of(
                resource_name(SHARED, "config", "recorder-start")
            ),
        )
        start = cr.AwsCustomResource(
            self,
            "ConfigRecorderStart",
            resource_type="Custom::ConfigRecorderStart",
            on_create=start_call,
            on_update=start_call,
            on_delete=cr.AwsSdkCall(
                service="ConfigService",
                action="stopConfigurationRecorder",
                parameters={"ConfigurationRecorderName": recorder.ref},
            ),
            policy=cr.AwsCustomResourcePolicy.from_statements(
                [
                    iam.PolicyStatement(
                        actions=[
                            "config:StartConfigurationRecorder",
                            "config:StopConfigurationRecorder",
                        ],
                        resources=["*"],
                    )
                ]
            ),
            install_latest_aws_sdk=False,
            log_group=self._sdk_call_log_group(key),
        )
        start.node.add_dependency(channel)

        # The HIPAA conformance pack. The AWS-published YAML is vendored into
        # `infra/conformance-packs/` and published as a **CDK asset**: `cdk deploy`
        # uploads it to the bootstrap staging bucket and hands CloudFormation the
        # resulting S3 URL. Three things follow from that, and they are the reason
        # this is not a hand-upload.
        #
        # 1. There is no step anyone can forget. A manual upload is a precondition
        #    that lives only in a README, and the failure mode is a stack that
        #    deploys and a control set that silently is not there.
        # 2. The deployed control set is the one in this repository, byte for byte.
        #    `cdk diff` sees a change to the YAML because the asset hash changes.
        # 3. It does not depend on the template staying under CloudFormation's
        #    51,200-byte `TemplateBody` limit. Today's copy is ~50 KB — inside the
        #    limit, but with about 700 bytes to spare, which is not a margin.
        #
        # `-c hipaaConformancePackS3Uri=s3://.../file.yaml` still overrides it, for
        # the case where AWS Config must read the template from a bucket in this
        # account rather than from the staging bucket.
        pack_asset = s3_assets.Asset(
            self,
            "HipaaConformancePackTemplate",
            path=str(HIPAA_CONFORMANCE_PACK_FILE),
        )
        pack_uri = self.node.try_get_context("hipaaConformancePackS3Uri") or (
            pack_asset.s3_object_url
        )
        pack = config.CfnConformancePack(
            self,
            "HipaaConformancePack",
            conformance_pack_name=HIPAA_CONFORMANCE_PACK,
            template_s3_uri=str(pack_uri),
            # No `delivery_s3_bucket`. It is optional, and when it is omitted AWS
            # Config writes the pack's own evaluation artefacts to a bucket it
            # manages itself. Naming our Config bucket here would additionally
            # require its bucket policy to grant the conformance-pack service
            # principal write access — a grant we would otherwise not make, on the
            # bucket that holds the account's configuration history.
        )
        pack.add_resource_dependency(recorder)
        pack.add_resource_dependency(channel)
        pack.node.add_dependency(start)

    def _access_analyzer(self) -> None:
        # External-access analyzer for the account: it reports any resource
        # policy that grants access outside it. Free.
        #
        # Behind a flag for the same reason as the others: an account may hold only
        # **one** external-access analyzer, so if the other owner (ADR 0001) made
        # one first, creating ours fails the whole stack. Unlike GuardDuty, this one
        # is free, so there is no cost argument for sharing theirs — but there is
        # also no way to have two. Check with `aws accessanalyzer list-analyzers
        # --type ACCOUNT` before the first deploy (infra/README.md).
        if not self._context_flag("enableAccessAnalyzer"):
            return
        accessanalyzer.CfnAnalyzer(
            self,
            "AccessAnalyzer",
            analyzer_name=resource_name(SHARED, "accessanalyzer", "account"),
            type="ACCOUNT",
        )

    def _sdk_call_log_group(self, key: kms.Key) -> logs.LogGroup:
        """The one log group of CDK's `AwsCustomResource` function.

        Every `AwsCustomResource` in a stack runs on the same singleton Lambda, and
        the first one created decides its log group. The Config recorder start and
        the Inspector enablement therefore share this group; its name predates the
        first and is kept so it never has to be replaced.
        """
        existing = self.node.try_find_child("InspectorEcrLogGroup")
        if isinstance(existing, logs.LogGroup):
            return existing
        return logs.LogGroup(
            self,
            "InspectorEcrLogGroup",
            log_group_name=f"/aws/lambda/{resource_name(SHARED, 'inspector', 'ecr')}",
            retention=LOG_GROUP_RETENTION,
            encryption_key=key,
            removal_policy=RemovalPolicy.RETAIN,
        )

    def _inspector(self, key: kms.Key) -> None:
        if not self._context_flag("enableInspector"):
            return

        # An `AwsCustomResource` is a Lambda function, and a Lambda function that
        # is not given a log group makes its own: `/aws/lambda/<generated-name>`,
        # **never expiring** and encrypted only with the CloudWatch service key.
        # In an account holding PHI that is two defects at once — an audit log
        # outside the 400-day retention baseline (plan §2.4), and a log group whose
        # encryption is not under a key we control or can revoke. The function
        # logs its own `inspector2:Enable` call and the error if it fails, which is
        # the evidence that this control was turned on and when.
        #
        # RETAIN, like every other audit log here: destroying the stack must not
        # destroy the record of what the stack did.
        log_group = self._sdk_call_log_group(key)
        # Inspector v2 has no CloudFormation resource for account enablement —
        # only filters and CIS scan configurations. The supported route is the
        # `inspector2:Enable` API, so this is a custom resource rather than a
        # gap.
        #
        # **Phase 8 added `LAMBDA` to what was an ECR-only enablement.** The
        # earlier comment said Lambda scanning "is not in scope", and that stopped
        # being true in Phase 4: the Cognito **User Migration Lambda** reads a
        # Supabase secret and sees every migrating user's password once, and the
        # estate also runs CDK's own helper functions. A function nobody scans is
        # a dependency tree nobody scans. `EC2` stays off — no EC2 instance in
        # this estate runs application code (the ops instance is an SSM jump box),
        # and EC2 scanning is the expensive meter.
        #
        # Cost: Lambda **standard** scanning is per function per month (about
        # $0.30), so at one application function plus CDK's handfuls it is under
        # a dollar. `LAMBDA_CODE` — the code-scanning tier, which is a different,
        # dearer meter — is deliberately NOT enabled.
        #
        # The logical id and the physical resource id stay `…Ecr` on purpose:
        # renaming either replaces the custom resource, and a replacement runs
        # `disable` on the old one **after** `enable` on the new one in some
        # orderings, which would switch Inspector off in an account that believes
        # it is on. The name is stale; the control is not.
        #
        # **`on_update` is not optional here, and round 1 caught its absence
        # (P8-01).** An `AwsCustomResource` with only `on_create` fires its call
        # once, when the resource is first created. Widening
        # `INSPECTOR_RESOURCE_TYPES` from `("ECR",)` to `("ECR", "LAMBDA")`
        # changes the Lambda function's properties, so CloudFormation sends an
        # **Update** — and with no `on_update` the handler does nothing, reports
        # success, and Lambda scanning is never switched on in the one account
        # that matters: the one where the stack already exists. The stack would
        # be green, the ADR would say Lambda is scanned, and it would not be.
        # `inspector2:enable` is idempotent (enabling an already-enabled type is
        # a no-op that returns the account's status), so running the same call on
        # update is safe; the physical id is repeated verbatim so the update is
        # an update and not a replacement.
        enable_call = cr.AwsSdkCall(
            service="Inspector2",
            action="enable",
            parameters={
                "accountIds": [Aws.ACCOUNT_ID],
                "resourceTypes": list(INSPECTOR_RESOURCE_TYPES),
            },
            physical_resource_id=cr.PhysicalResourceId.of(
                resource_name(SHARED, "inspector", "ecr")
            ),
        )
        cr.AwsCustomResource(
            self,
            "InspectorEcr",
            resource_type="Custom::Inspector2Ecr",
            on_create=enable_call,
            on_update=enable_call,
            on_delete=cr.AwsSdkCall(
                service="Inspector2",
                action="disable",
                parameters={
                    "accountIds": [Aws.ACCOUNT_ID],
                    "resourceTypes": list(INSPECTOR_RESOURCE_TYPES),
                },
            ),
            policy=cr.AwsCustomResourcePolicy.from_statements(
                [
                    iam.PolicyStatement(
                        actions=["inspector2:Enable", "inspector2:Disable", "inspector2:BatchGet*"],
                        resources=["*"],
                    ),
                    iam.PolicyStatement(
                        actions=["iam:CreateServiceLinkedRole"],
                        resources=["*"],
                        conditions={
                            "StringEquals": {"iam:AWSServiceName": "inspector2.amazonaws.com"}
                        },
                    ),
                ]
            ),
            install_latest_aws_sdk=False,
            log_group=log_group,
        )

    # ------------------------------------------------------------ break glass

    def _breakglass_role(self) -> iam.Role:
        """Emergency administrator access — 45 CFR 164.312(a)(2)(ii), *required*.

        It is not a convenience. Assuming it fires the `breakglass-assumed`
        alarm above and starts the rotation procedure in
        `docs/runbooks/break-glass.md`. Trust is the account root principal —
        meaning any principal in this account that an IAM policy also allows —
        **with MFA required**, and the session is capped at one hour.
        """
        return iam.Role(
            self,
            "BreakGlassRole",
            role_name=resource_name(SHARED, "iam", "breakglass"),
            description="Emergency administrator access. Every assumption is alarmed.",
            assumed_by=iam.AccountRootPrincipal().with_conditions(
                {"Bool": {"aws:MultiFactorAuthPresent": "true"}}
            ),
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name("AdministratorAccess")
            ],
            max_session_duration=Duration.hours(1),
        )

    # ---------------------------------------------------------------- budgets

    def _budgets(self, topic: sns.Topic) -> None:
        """Plan §5 / Phase 1 step 7.

        Each environment gets one budget whose limit is the upper figure and
        whose first notification fires at the lower one, so "$150/$250" and
        "$30/$75" both appear: warn at the lower actual spend, warn again when
        the forecast crosses the limit. The account budget has no filter and
        therefore also covers the other owner's spend (ADR 0001).

        **The per-environment filter has a manual precondition.** It is
        `user:Environment$<env>` — a *cost-allocation* tag, which is a different
        thing from the resource tag the Aspect applies. A resource tag becomes a
        cost-allocation tag only when it is activated once, per account, in
        Billing:

            aws ce update-cost-allocation-tags-status --cost-allocation-tags-status \
              TagKey=Environment,Status=Active TagKey=Project,Status=Active

        Until that is done the filter matches **nothing**, both environment budgets
        sit at $0.00 for ever, and the first sign of trouble is the unfiltered
        account budget at $300. Worse, activation is not retroactive and takes up to
        24 hours to appear, so it has to happen before the spend it is meant to
        catch. `infra/README.md` ("Pre-deploy checks") has the verification command;
        `TAG_KEY_ENVIRONMENT` below is asserted against the Aspect's own tag key so
        that renaming one and not the other fails a test rather than a budget.
        """
        for env_name, cfg in ENV_CONFIG.items():
            self._budget(
                topic,
                key=env_name.capitalize(),
                budget_name=resource_name(env_name, "budgets", "monthly"),
                limit_usd=cfg.budget_limit_usd,
                warn_usd=cfg.budget_warn_usd,
                cost_filters={"TagKeyValue": [f"user:{TAG_KEY_ENVIRONMENT}${env_name}"]},
            )
        self._budget(
            topic,
            key="Account",
            budget_name=resource_name(SHARED, "budgets", "account"),
            limit_usd=ACCOUNT_BUDGET_USD,
            warn_usd=int(ACCOUNT_BUDGET_USD * 0.8),
            cost_filters=None,
        )

    def _budget(
        self,
        topic: sns.Topic,
        *,
        key: str,
        budget_name: str,
        limit_usd: int,
        warn_usd: int,
        cost_filters: dict[str, list[str]] | None,
    ) -> None:
        subscriber = budgets.CfnBudget.SubscriberProperty(
            subscription_type="SNS", address=topic.topic_arn
        )
        budgets.CfnBudget(
            self,
            f"Budget{key}",
            # `AWS::Budgets::Budget` is one of the L1s the tag Aspect cannot see: it
            # has no `Tags` property, only `ResourceTags`, so `Tags.of(...)` never
            # reaches it and `RequiredTagsAspect` returns `None` rather than
            # failing. That makes it the one resource in this stack where the six
            # tags have to be written by hand — and it is worth doing, because a
            # budget with no `Project` tag is invisible to the same cost reports the
            # budget exists to enforce.
            resource_tags=[
                budgets.CfnBudget.ResourceTagProperty(key=tag_key, value=tag_value)
                for tag_key, tag_value in {
                    **common_tags(
                        SHARED if key == "Account" else key.lower(),
                        owner=DEFAULT_OWNER,
                        cost_center=DEFAULT_COST_CENTER,
                    ),
                    "DataClassification": "internal",
                }.items()
            ],
            budget=budgets.CfnBudget.BudgetDataProperty(
                budget_name=budget_name,
                budget_type="COST",
                time_unit="MONTHLY",
                budget_limit=budgets.CfnBudget.SpendProperty(amount=limit_usd, unit="USD"),
                cost_filters=cost_filters,
            ),
            notifications_with_subscribers=[
                budgets.CfnBudget.NotificationWithSubscribersProperty(
                    notification=budgets.CfnBudget.NotificationProperty(
                        notification_type="ACTUAL",
                        comparison_operator="GREATER_THAN",
                        threshold=round(warn_usd / limit_usd * 100, 2),
                        threshold_type="PERCENTAGE",
                    ),
                    subscribers=[subscriber],
                ),
                budgets.CfnBudget.NotificationWithSubscribersProperty(
                    notification=budgets.CfnBudget.NotificationProperty(
                        notification_type="FORECASTED",
                        comparison_operator="GREATER_THAN",
                        threshold=100,
                        threshold_type="PERCENTAGE",
                    ),
                    subscribers=[subscriber],
                ),
            ],
        )

    # ----------------------------------------------------- cost anomaly detection

    def _cost_anomaly_detection(self, topic: sns.Topic) -> None:
        """Two or three anomaly monitors and one subscription. **Free**, and not a budget.

        **What it adds over the budgets.** A budget is a *total* measured against a
        line, and it can only tell you something is wrong at the end of the month or
        when a forecast crosses. Cost Anomaly Detection learns each monitor's normal
        daily shape from history and reports a **step change** — "this looked like
        $1.20/day and today it is $23" — on day three rather than on day thirty. The
        failure mode it catches is the one that actually happens here: a NAT gateway
        left running after a staging teardown, a Config recorder suddenly seeing
        another owner's resources, a forgotten `cdk deploy` into the wrong
        environment. The budgets stay; these are the early signal, not a replacement.

        **Three monitors, on purpose — but only two of them are ours to create.**

        * One `CUSTOM` monitor **per environment**, scoped by the `Environment`
          cost-allocation tag. A per-environment baseline is the useful one: staging
          is torn down between sessions, so its normal shape is spiky and a spike
          there means nothing, while the same spike in production means something.
          One combined monitor would average the two and learn neither. `CUSTOM`
          monitors have no per-account limit, so these two are always created.
        * One `DIMENSIONAL` monitor on `SERVICE`, **account-wide and unfiltered**.
          It has no tag filter, so it sees the other owner's spend too (ADR 0001) —
          which is the point: it is the only thing that notices an untagged resource
          or a service nobody meant to turn on. The per-environment monitors are blind
          to exactly that, because an untagged resource carries no `Environment` tag.

        **H-G: AWS allows exactly ONE `DIMENSIONAL`/`SERVICE` monitor per account, and
        this account already has one.** Cost Explorer creates `Default-Services-Monitor`
        the first time anomaly detection is opened in the console, and the account is
        shared (ADR 0001), so it is already there:

            aws ce get-anomaly-monitors \
              --query "AnomalyMonitors[?MonitorType=='DIMENSIONAL'].[MonitorArn,MonitorName]"

        Creating a second one fails with `ValidationException`, and because the
        foundation stack is a single changeset that failure **rolls the whole stack
        back** — the CloudTrail, the alarms, the budgets, all of it. So:

        * `enableServiceAnomalyMonitor` — **default `false`**, the opposite of every
          other `enable*` flag in this stack, because the read-only check above already
          says the answer for this account. Set it to `true` only in an account where
          `get-anomaly-monitors` returns no `DIMENSIONAL` monitor.
        * `existingServiceAnomalyMonitorArn` — when the flag is false, the ARN of the
          monitor that is already there. The subscription then **attaches to it**;
          nothing in this stack reads, updates or deletes it, because
          `AWS::CE::AnomalySubscription` only names monitors, and an ARN in
          `MonitorArnList` is a reference, not ownership. It is an identifier and
          carries the account id, so it is passed with `-c` and never committed
          (ADR 0001).

        With neither set, the subscription still covers the two `CUSTOM` monitors and
        synth prints a warning: the environments are watched, the untagged-spend
        backstop is not.

        **The same precondition as the budgets, and it is easy to miss.** The two
        `CUSTOM` monitors filter on `user:Environment`, a *cost-allocation* tag, which
        a resource tag becomes only after it is activated once in Billing
        (`aws ce update-cost-allocation-tags-status …`, `infra/README.md` →
        "Pre-deploy checks"). Until then they monitor nothing, quietly. The
        `SERVICE`-dimension monitor needs no activation and works from day one, which
        is a second reason it exists.

        **`$20`, absolute, daily.** `ThresholdExpression` with
        `ANOMALY_TOTAL_IMPACT_ABSOLUTE` means "tell me when the unexpected spend is
        more than $20", not "more than 20 % above normal" — a percentage threshold on
        a ~$40/month account fires on rounding. $20 is about 8 % of the ~$250 ceiling
        and roughly half a month of an accidentally-standing NAT gateway.
        `IMMEDIATE` frequency, because the subscriber is the SNS alerts topic and
        Cost Explorer accepts SNS only on `IMMEDIATE` — `DAILY`/`WEEKLY` take email
        subscribers alone, and the first deploy (2026-10-02) failed on exactly that.
        At a $20 absolute threshold the extra noise is nil.

        **Region.** `AWS::CE::*` is a global service with a `us-east-1`-only endpoint,
        and CloudFormation will only create these resources in a `us-east-1` stack.
        The whole estate is in `us-east-1` (plan §1), so this is satisfied today and
        is worth stating because it is a real constraint on ever moving the foundation
        stack elsewhere: the monitors would have to stay behind.

        **Cost: $0.** Cost Anomaly Detection is free, including the notifications.
        `docs/reports/phase-1-cost-estimate.md` carries the line so the zero is
        explicit rather than an omission.
        """
        monitors: list[ce.CfnAnomalyMonitor] = []

        for env_name in ENV_CONFIG:
            monitors.append(
                ce.CfnAnomalyMonitor(
                    self,
                    f"AnomalyMonitor{env_name.capitalize()}",
                    monitor_name=resource_name(env_name, "ce", "anomaly-monitor"),
                    monitor_type="CUSTOM",
                    # A Cost Explorer filter expression, as JSON. `CostCategories`
                    # and `Dimensions` are the other two shapes; `Tags` with
                    # `MatchOptions: EQUALS` is an exact match on one tag value.
                    monitor_specification=json.dumps(
                        {
                            "Tags": {
                                "Key": TAG_KEY_ENVIRONMENT,
                                "Values": [env_name],
                                "MatchOptions": ["EQUALS"],
                            }
                        }
                    ),
                )
            )

        # ------------------------------------------- the account-wide SERVICE monitor
        # One per account, ever. See the docstring: this account already has AWS's
        # own `Default-Services-Monitor`, so the flag defaults to OFF and the
        # subscription attaches to the existing monitor by ARN instead.
        self.create_service_anomaly_monitor = self._context_flag(
            "enableServiceAnomalyMonitor", default=False
        )
        existing_arn = self.node.try_get_context("existingServiceAnomalyMonitorArn")
        self.existing_service_anomaly_monitor_arn = str(existing_arn) if existing_arn else None

        monitor_arns: list[str] = [monitor.attr_monitor_arn for monitor in monitors]

        if self.create_service_anomaly_monitor and self.existing_service_anomaly_monitor_arn:
            raise ValueError(
                "enableServiceAnomalyMonitor=true and existingServiceAnomalyMonitorArn "
                "are mutually exclusive: AWS allows one DIMENSIONAL/SERVICE anomaly "
                "monitor per account, so creating ours while pointing at somebody "
                "else's would fail the whole foundation stack. Pass one or the other."
            )

        if self.create_service_anomaly_monitor:
            monitors.append(
                ce.CfnAnomalyMonitor(
                    self,
                    "AnomalyMonitorServices",
                    monitor_name=resource_name(SHARED, "ce", "anomaly-monitor"),
                    monitor_type="DIMENSIONAL",
                    # The only dimension AWS accepts for a dimensional monitor. It
                    # evaluates every service in the account independently, which is
                    # what makes it the backstop for untagged spend.
                    monitor_dimension="SERVICE",
                )
            )
            monitor_arns.append(monitors[-1].attr_monitor_arn)
        elif self.existing_service_anomaly_monitor_arn:
            # Referenced, never managed. Nothing here can change or delete it.
            monitor_arns.append(self.existing_service_anomaly_monitor_arn)
        else:
            Annotations.of(self).add_warning(
                "No account-wide SERVICE anomaly monitor is attached to the alert "
                "subscription: enableServiceAnomalyMonitor is false (the default, "
                "because this account already has one) and "
                "existingServiceAnomalyMonitorArn is unset. The two per-environment "
                "monitors still work, but UNTAGGED spend is unwatched. Run "
                "`aws ce get-anomaly-monitors --query \"AnomalyMonitors[?MonitorType=="
                "'DIMENSIONAL'].MonitorArn\"` and pass the result with "
                "-c existingServiceAnomalyMonitorArn=arn:aws:ce::...:anomalymonitor/... "
                "(infra/README.md, Pre-deploy checks)."
            )

        ce.CfnAnomalySubscription(
            self,
            "AnomalySubscription",
            subscription_name=resource_name(SHARED, "ce", "anomaly-alerts"),
            frequency="IMMEDIATE",
            monitor_arn_list=monitor_arns,
            subscribers=[
                ce.CfnAnomalySubscription.SubscriberProperty(type="SNS", address=topic.topic_arn)
            ],
            # Absolute dollars, not a percentage. See the docstring.
            threshold_expression=json.dumps(
                {
                    "Dimensions": {
                        "Key": "ANOMALY_TOTAL_IMPACT_ABSOLUTE",
                        "Values": [str(ANOMALY_THRESHOLD_USD)],
                        "MatchOptions": ["GREATER_THAN_OR_EQUAL"],
                    }
                }
            ),
        )

    # -------------------------------------------------------------- CI / OIDC

    def _github_oidc_provider(self) -> None:
        """The account's one GitHub OIDC provider — Phase 1 step 8. No stored AWS keys, ever.

        **The two `meridian-<env>-iam-ci-deploy` roles that used to be created
        here are gone (Codex CX-INF-02 follow-up, 2026-09-17).** They trusted a
        *branch* (`repo:…:ref:refs/heads/<branch>`) and could assume every
        `cdk-*` bootstrap role — exactly the reach the environment-bound
        `meridian-shared-iam-github-deploy` was narrowed to remove. Nothing in
        `.github/workflows/` ever assumed them (`deploy.yml` uses
        `vars.AWS_DEPLOY_ROLE_ARN`, the shared role), so keeping them was keeping a
        second, wider door with the same key. The provider stays: both remaining
        roles trust it by ARN.
        """
        if self._context_flag("createGithubOidcProvider"):
            iam.CfnOIDCProvider(
                self,
                "GitHubOidcProvider",
                url=GITHUB_OIDC_URL,
                client_id_list=["sts.amazonaws.com"],
                thumbprint_list=[GITHUB_OIDC_THUMBPRINT],
            )

    def _github_deploy_role(self) -> iam.Role:
        """`meridian-shared-iam-github-deploy` — the role `.github/workflows/deploy.yml` assumes.

        **The one deploy identity.** `deploy.yml` has to log in to ECR, push two
        images, run `cdk deploy` on one stack and then ask ECS whether the
        services came back stable, so this role is scoped to exactly the
        resources that one workflow touches, and it is `shared` because a single
        workflow file uses it. (The per-environment `meridian-<env>-iam-ci-deploy`
        roles that preceded it were removed on 2026-09-17 — see
        `_github_oidc_provider`.)

        **The trust policy is `StringEquals`, not `StringLike`.** The
        per-environment roles use `StringLike` on one `sub` each; this role names
        one exact subject — the `staging` GitHub Environment, see
        `GITHUB_DEPLOY_ENVIRONMENTS` — and a wildcard operator on a value that
        contains no wildcard only invites someone to add one later. `aud` is pinned to
        `sts.amazonaws.com`, because a token minted for another audience was
        minted for somebody else's purpose.

        **The one `Resource: "*"`, and why it has to be.**
        `ecr:GetAuthorizationToken` takes no resource: it is the call that returns
        the 12-hour registry password, there is no ARN to name, and IAM rejects the
        statement if you try. It grants nothing by itself — every push and every
        pull is authorized separately, against the two repositories below.

        Nothing else is unscoped. Direct CloudFormation is one stack, ECR is two
        repositories, ECS is the two services inside one cluster, and
        `iam:PassRole` is the three roles those task definitions name (and only to
        `ecs-tasks.amazonaws.com`).

        **`sts:AssumeRole` on the bootstrap roles is the real deploy grant — and
        it is wider than the statement above it** (P5AR3-03). `cdk deploy` barely
        uses the caller's own permissions: it assumes
        `cdk-<qualifier>-deploy-role-<account>-<region>` to drive CloudFormation,
        `...-file-publishing-role-...` to stage assets into the bootstrap bucket,
        and `...-lookup-role-...` for context lookups. Those roles are created by
        `cdk bootstrap` and this file does not get to scope them: the deploy role
        is account-wide and passes `cdk-<qualifier>-cfn-exec-role`, which this
        estate bootstrapped with `AdministratorAccess`. Round 2 recorded, here and
        in four other places, that "CloudFormation permission on one stack" meant
        CI could not reach `data` or `auth`. **That was false**, and the
        correction is the point of this paragraph: the `CloudFormationOnTheCompute
        StackOnly` statement narrows what this role can do *by itself*, which is
        not the path a deploy takes.

        What is true, and what the boundary actually rests on:

        * **`--exclusively` in `.github/workflows/deploy.yml`.** CDK deploys the
          named stack and nothing it depends on. It is a flag in a tracked file,
          so removing it is a reviewable diff.
        * **The trust policy.** Only this repository, only `aws-migration` and
          `main`, only `sts.amazonaws.com` as the audience, one hour maximum. A
          fork, a tag, a `pull_request` run and a feature branch all fail
          `AssumeRoleWithWebIdentity` outright, so dispatching this workflow
          already requires a commit on a protected branch.
        * **The workflow is `workflow_dispatch`-only with a typed confirm.**

        The fix — a staging-only bootstrap qualifier whose
        `--cloudformation-execution-policies` cannot touch `data` or `auth`, and
        this role pointed at those bootstrap roles — is a `docs/migration-tracker.md`
        row owned by Andres, due before the first dispatch. Until it lands, the
        honest sentence is "branch-restricted and `--exclusively`", not "scoped by
        IAM to one stack".

        The bootstrap roles are named **by pattern with the account and region
        tokens**, never literals, because no account id is written down in
        `infra/` (ADR 0001) — and the pattern is narrower than the `cdk-*` the
        older roles use: it pins the qualifier, the `-role-` segment, and this
        account and region. `image-publishing-role` is deliberately **not** among
        them (P5AR3-12): this workflow builds with buildx and pushes to the two
        `meridian-staging-ecr-*` repositories as the runner's own identity, and
        the CDK asset registry is not a thing it ever writes to.
        """
        provider_arn = (
            f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:oidc-provider/{GITHUB_OIDC_CLAIM}"
        )
        role = iam.Role(
            self,
            "GitHubDeployRole",
            role_name=resource_name(SHARED, "iam", "github-deploy"),
            description=(
                f"GitHub Actions build-and-deploy role for {GITHUB_DEPLOY_STACK}; trusts only "
                f"{GITHUB_REPO} jobs in the "
                + " and ".join(GITHUB_DEPLOY_ENVIRONMENTS)
                + " GitHub Environment."
            ),
            max_session_duration=Duration.hours(1),
            assumed_by=iam.WebIdentityPrincipal(
                provider_arn,
                {
                    "StringEquals": {
                        f"{GITHUB_OIDC_CLAIM}:aud": "sts.amazonaws.com",
                        f"{GITHUB_OIDC_CLAIM}:sub": [
                            f"repo:{GITHUB_REPO}:environment:{env}"
                            for env in GITHUB_DEPLOY_ENVIRONMENTS
                        ],
                    }
                },
            ),
        )

        registry = f"arn:{Aws.PARTITION}:ecr:{Aws.REGION}:{Aws.ACCOUNT_ID}:repository"
        role.add_to_policy(
            iam.PolicyStatement(
                sid="EcrLogin",
                actions=["ecr:GetAuthorizationToken"],
                resources=["*"],  # documented above: this action takes no resource
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="EcrPushTheTwoMeridianRepositories",
                actions=[
                    "ecr:BatchCheckLayerAvailability",
                    "ecr:BatchGetImage",
                    "ecr:CompleteLayerUpload",
                    "ecr:DescribeImages",
                    "ecr:DescribeRepositories",
                    "ecr:GetDownloadUrlForLayer",
                    "ecr:InitiateLayerUpload",
                    "ecr:PutImage",
                    "ecr:UploadLayerPart",
                ],
                resources=[
                    f"{registry}/{resource_name(GITHUB_DEPLOY_ENV, 'ecr', purpose)}"
                    for purpose in ("api", "web")
                ],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="CloudFormationOnTheComputeStackOnly",
                actions=["cloudformation:*"],
                resources=[
                    f"arn:{Aws.PARTITION}:cloudformation:{Aws.REGION}:{Aws.ACCOUNT_ID}:"
                    f"stack/{GITHUB_DEPLOY_STACK}/*"
                ],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadCdkBootstrapVersion",
                actions=["ssm:GetParameter", "ssm:GetParameters"],
                resources=[
                    f"arn:{Aws.PARTITION}:ssm:{Aws.REGION}:{Aws.ACCOUNT_ID}:"
                    f"parameter/cdk-bootstrap/{CDK_BOOTSTRAP_QUALIFIER}/*"
                ],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="AssumeTheThreeCdkBootstrapRoles",
                actions=["sts:AssumeRole"],
                resources=[
                    f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:role/"
                    f"cdk-{CDK_BOOTSTRAP_QUALIFIER}-{purpose}-role-{Aws.ACCOUNT_ID}-{Aws.REGION}"
                    # `image-publishing` is NOT here (P5AR3-12): the images are
                    # built and pushed by the runner to the two application
                    # repositories, not staged as CDK assets.
                    for purpose in ("deploy", "file-publishing", "lookup")
                ],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="WaitForTheTwoServicesToStabilize",
                actions=["ecs:DescribeServices"],
                resources=[
                    f"arn:{Aws.PARTITION}:ecs:{Aws.REGION}:{Aws.ACCOUNT_ID}:service/"
                    f"{resource_name(GITHUB_DEPLOY_ENV, 'ecs', 'main')}/"
                    f"{resource_name(GITHUB_DEPLOY_ENV, 'ecs', f'svc-{purpose}')}"
                    for purpose in ("api", "web")
                ],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="PassOnlyTheComputeStacksThreeRoles",
                actions=["iam:PassRole"],
                resources=[
                    f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:role/"
                    f"{resource_name(GITHUB_DEPLOY_ENV, 'iam', purpose)}"
                    for purpose in ("ecs-execution", "ecs-api-task", "ecs-web-task")
                ],
                conditions={"StringEquals": {"iam:PassedToService": "ecs-tasks.amazonaws.com"}},
            )
        )
        return role

    def _github_diff_role(self) -> iam.Role:
        """`meridian-shared-iam-github-diff` — the READ-ONLY role `cdk diff` in CI assumes.

        **Why a second role.** `meridian-shared-iam-github-deploy` is a deploy
        identity: its whole power is `sts:AssumeRole` on the `cdk-*` bootstrap
        roles, and the
        `cdk-…-deploy-role` that follows from that passes an
        `AdministratorAccess` execution role. Handing that to a CI job at all is
        the opposite of what a diff job is for. So `cdk diff` gets an identity of
        its own that **cannot deploy anything**, and the tracker row "`cdk diff`
        does not run in CI" closes against this role rather than against a
        widened deploy role.

        **It is trusted on the same two branches as the deploy role, and on
        nothing else** (P8-03). It was briefly trusted on `pull_request` too;
        that is withdrawn, because `cdk diff` runs the diffed branch's own Python
        on a runner holding these credentials, and "read-only" over a PHI estate
        is not a small grant — see `GITHUB_DIFF_SUBJECTS` and threat model
        §13.7.5.

        **What `cdk diff` actually needs**, and nothing beyond it:

        * `sts:AssumeRole` on exactly one bootstrap role —
          `cdk-<qualifier>-lookup-role`. That role is read-only *by design*:
          `cdk bootstrap` creates it with `ReadOnlyAccess` plus an explicit deny
          on `kms:Decrypt`, so it can answer a context lookup (a VPC id, an AMI,
          a hosted zone) and can do nothing else. `deploy`, `file-publishing`
          and `cfn-exec` are **not** here, which is the whole difference between
          this role and the deploy one.
        * `cloudformation:DescribeStacks`, `GetTemplate` and
          `ListStackResources` on `meridian-*` stacks — how the CLI fetches the
          deployed template to compare the synthesized one against.
          `ListStackResources` rather than `DescribeStackResources` (P8-14):
          both answer "what is in this stack", `List*` is the paginated,
          purely-enumerative one, and preferring it keeps the policy's verbs to
          the smallest set that works.
        * `ssm:GetParameter` on the bootstrap version parameter, which the CLI
          reads to decide whether the bootstrap stack is new enough.

        **And nothing for a change set, deliberately.** `cdk diff` defaults to
        `--method=auto`: it asks CloudFormation to compute the diff by
        creating a change set, which needs `cloudformation:CreateChangeSet`,
        `DescribeChangeSet` and `DeleteChangeSet` **and** assumes the
        `cdk-<qualifier>-deploy-role` to do it. That is precisely the role this
        one may not assume, so `.github/workflows/backend.yml` passes
        `--method=template`, which computes the diff from the two templates
        alone. Without that flag the claim "only the lookup role is assumed"
        is false and the job degrades to a warning nobody reads (P8-04).

        There is **no `Resource: "*"`** and **no write action** in the policy, and
        two tests assert both — this role is the one place in the estate where
        "read-only" is a property a reader can verify by looking, rather than a
        claim in a comment.

        **Not a boundary against everything.** `cdk diff` renders the CDK app,
        which is arbitrary Python from the branch's own tree, and that code runs
        on the runner with these credentials. Read-only is therefore the ceiling
        that matters, and it is why this role may not assume
        `cdk-…-deploy-role`: the worst a malicious diff can do is read Meridian's
        templates and whatever the lookup role allows — which, since the lookup
        role is `ReadOnlyAccess`, is most of the account's metadata and log
        content. Restricting the trust to post-review pushes is what bounds
        *who* can put such code there.
        """
        provider_arn = (
            f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:oidc-provider/{GITHUB_OIDC_CLAIM}"
        )
        role = iam.Role(
            self,
            "GitHubDiffRole",
            role_name=resource_name(SHARED, "iam", "github-diff"),
            description=(
                f"GitHub Actions READ-ONLY cdk-diff role; trusts only {GITHUB_REPO} on "
                + " and ".join(f"refs/heads/{branch}" for branch in GITHUB_DEPLOY_BRANCHES)
                + " (post-review pushes only; no pull_request subject)."
                + " It cannot deploy: the only bootstrap role it may assume is lookup."
            ),
            max_session_duration=Duration.hours(1),
            assumed_by=iam.WebIdentityPrincipal(
                provider_arn,
                {
                    "StringEquals": {
                        f"{GITHUB_OIDC_CLAIM}:aud": "sts.amazonaws.com",
                        f"{GITHUB_OIDC_CLAIM}:sub": list(GITHUB_DIFF_SUBJECTS),
                    }
                },
            ),
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="AssumeOnlyTheReadOnlyLookupRole",
                actions=["sts:AssumeRole"],
                resources=[
                    f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:role/"
                    f"cdk-{CDK_BOOTSTRAP_QUALIFIER}-lookup-role-{Aws.ACCOUNT_ID}-{Aws.REGION}"
                ],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadMeridianStackTemplates",
                actions=[
                    "cloudformation:DescribeStacks",
                    "cloudformation:ListStackResources",
                    "cloudformation:GetTemplate",
                ],
                resources=[
                    f"arn:{Aws.PARTITION}:cloudformation:{Aws.REGION}:{Aws.ACCOUNT_ID}:"
                    f"stack/{GITHUB_DIFF_STACK_PREFIX}/*"
                ],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadCdkBootstrapVersion",
                actions=["ssm:GetParameter"],
                resources=[
                    f"arn:{Aws.PARTITION}:ssm:{Aws.REGION}:{Aws.ACCOUNT_ID}:"
                    f"parameter/cdk-bootstrap/{CDK_BOOTSTRAP_QUALIFIER}/version"
                ],
            )
        )
        return role
