"""`meridian-shared-dns` — the Route 53 public hosted zone and SES sending identity.

Plan Phase 1 step 3 (`docs/aws-migration-plan.md`), ADR 0014 (email on SES) and
ADR 0017 (the zone itself). Account-level like the foundation stack: there is one
`meridiansgrp.com` and one SES domain identity for the whole account, not one per
environment.

**Why a Route 53 zone at all.** GoDaddy DNS cannot alias the bare domain at a
CloudFront distribution — it only offers an A record with a fixed IP, and
CloudFront has no fixed IP. Route 53 ALIAS records can, so Phase 9's edge work
(ADR 0015) needs the zone to exist and the nameservers to have been switched.
The *registrar* stays GoDaddy; only the nameservers move.

**Why every existing record is copied here verbatim.** The nameserver switch is
the moment the internet stops asking GoDaddy and starts asking Route 53. Anything
missing from this file goes dark at that moment — mail first. So the zone is built
to be a byte-for-byte replacement of the GoDaddy zone as it stands today, and the
runbook `docs/runbooks/dns-nameserver-switch.md` verifies each one against the
Route 53 nameservers *before* the switch.

**The record list is checked in, not remembered.** `infra/dns/meridiansgrp.com.zone.json`
is an export of the live GoDaddy zone (**twenty-three** record sets this stack copies, last
refreshed from GoDaddy's own zone-file export on 2026-10-12), and
`infra/tests/test_dns.py` asserts that every entry in it appears in the synthesized
template with the same type, TTL and values. Re-export it and re-run the tests
whenever anyone adds a record at GoDaddy; a record that exists there and not here is
a record that disappears at the switch.

The Phase 0 inventory in `docs/architecture/dns.md` listed only five records. It was
wrong — it missed the Microsoft 365 / GoDaddy CNAMEs and the two Skype for Business
SRV records below. The first `dig` export found fourteen; a **candidate-name sweep**
(`docs/runbooks/dns-nameserver-switch.md` §3) then found two more, `ai` and
`_domainconnect`, bringing it to sixteen. Both directions are needed: an export tells
you about the records someone thought to export, and the sweep asks the nameservers
directly about names nobody wrote down.

The 2026-10-12 zone-file export (`docs/runbooks/dns-move-audit-2026-10-12.md`) found
**seven more** that had been added at GoDaddy since: the other owner's `origin.ai` and two
ACM validation CNAMEs, GoDaddy's `pay` link host, and the three Resend records that carry
the production app's mail today. A name sweep had no way to find them; the export did.

**Four of the twenty-three are not ours.** `ai.meridiansgrp.com`, `origin.ai` and the two
ACM validation CNAMEs under them belong to the other owner's application (ADR 0001). See
`EXISTING_CNAMES` below.

Two consequences worth stating out loud:

* **Inbound mail is not moving.** The MX records point at Proofpoint Essentials
  and stay pointing there. SES only ever sends.
* **The apex SPF record gains nothing for SES.** SES signs as
  `mail.meridiansgrp.com` (a custom MAIL FROM subdomain), and that subdomain
  carries its own SPF record, created automatically below. Adding
  `include:amazonses.com` to the apex would spend one of SPF's ten DNS lookups
  for no benefit and widen who may send as the bare domain.
"""

from __future__ import annotations

from typing import Any

from aws_cdk import (
    Aws,
    CfnOutput,
    CfnParameter,
    Duration,
    Fn,
    RemovalPolicy,
    Stack,
    Tags,
)
from aws_cdk import (
    aws_iam as iam,
)
from aws_cdk import (
    aws_route53 as route53,
)
from aws_cdk import (
    aws_ses as ses,
)
from aws_cdk import (
    aws_sns as sns,
)
from constructs import Construct

#: The domain, overridable with `-c domain=...` so that a test or a second
#: domain does not need a code change. Defined once, in `config`, beside the
#: per-environment web addresses built on it (ADR 0050).
from ..config import DEFAULT_DOMAIN
from ..naming import SHARED, resource_name

#: The MAIL FROM subdomain SES signs with. A *sub*domain on purpose: it keeps the
#: apex SPF record — which Proofpoint and GoDaddy both appear in — untouched.
MAIL_FROM_PREFIX = "mail"

#: The one mailbox everything Meridian sends comes from — Cognito's own mail
#: (`stacks/auth.py`) and the application's invites and run notices
#: (`src/email_service.py`, Phase 7). It lives here, next to the identity that
#: makes it deliverable, because the api task role's `ses:SendEmail` grant
#: carries a `ses:FromAddress` condition on exactly this address: two copies of
#: the string in two stacks would be an IAM condition that silently stops
#: matching the `From` the application sends.
NO_REPLY_LOCAL_PART = "no-reply"

#: Inbound mail, unchanged: Proofpoint Essentials, sold through GoDaddy/M365.
#: All three at priority 0, exactly as GoDaddy serves them today.
PROOFPOINT_MX = ("mx1-usg2.ppe-hosted.com", "mx2-usg2.ppe-hosted.com", "mx3-usg2.ppe-hosted.com")

#: The apex TXT record set. DNS allows exactly **one** TXT record set per name,
#: so the SPF policy and the Microsoft 365 tenant verification string are two
#: values of one record, not two records — splitting them into two `TxtRecord`
#: constructs would be a CloudFormation conflict on the same name and type.
#:
#: No `include:amazonses.com` here. See the module docstring.
APEX_SPF = "v=spf1 include:_spf-usg2.ppe-hosted.com include:secureserver.net ~all"
MICROSOFT_TENANT_TXT = "NETORGFT20419956.onmicrosoft.com"

#: Relaxed alignment (`adkim=r`, `aspf=r`) is what lets SES sign as
#: `mail.meridiansgrp.com` and still align with `meridiansgrp.com`. Do not
#: tighten it to `s` without re-reading ADR 0014.
DMARC_POLICY = "v=DMARC1; p=quarantine; adkim=r; aspf=r; rua=mailto:dmarc_rua@onsecureserver.net;"

#: The thirteen CNAMEs GoDaddy serves today, as `(record_name, target)`.
#:
#: Six are Microsoft 365: `autodiscover` (Outlook client configuration),
#: `selector1`/`selector2._domainkey` (**Microsoft's** DKIM, unrelated to the SES
#: Easy DKIM CNAMEs this stack also writes — different names, no collision),
#: `lyncdiscover`/`sip`/`msoid` (Skype for Business / Teams and the
#: Microsoft Online sign-in endpoint). `email` is GoDaddy's own webmail
#: redirector and `_domainconnect` is GoDaddy's Domain Connect discovery record.
#:
#: **`ai` is not ours.** It is the *other* owner's application (ADR 0001 — one AWS
#: account, two owners): its production hostname, pointed at its own CloudFront
#: distribution. It is here for exactly one reason — it is in the live GoDaddy
#: zone, so Route 53 has to keep answering it the instant the nameservers move,
#: or that application goes dark and the cause is a change we made. **We never
#: repoint it, never remove it, and never assume it is stale.** The distribution
#: hostname is public DNS — anyone can `dig` it — so writing it down here leaks
#: nothing. After any DNS work, `https://ai.meridiansgrp.com` is part of the
#: post-change check (`docs/runbooks/dns-nameserver-switch.md` §5).
#:
#: **`origin.ai` and the two `_<token>.ai` / `_<token>.origin.ai` CNAMEs are the same
#: other owner's**, found by the 2026-10-12 zone-file export: `origin.ai` is its load
#: balancer origin, and the two underscore names are the ACM DNS-validation records
#: for its `ai` and `origin.ai` certificates. Losing `origin.ai` is an outage in their
#: product on day one; losing a validation CNAME is a certificate that silently fails
#: to auto-renew months later. Same rule as `ai`: copied, never changed.
#:
#: `pay` is GoDaddy Payments' pay-link host (`pay.meridiansgrp.com`).
#:
#: None of these move to AWS. They are here only so the switch changes who
#: answers, not what is answered — losing `autodiscover` breaks every Outlook
#: profile in the company, and losing a `selector*._domainkey` breaks outbound
#: DKIM for Microsoft 365, which is a mail failure that looks like a spam
#: problem rather than a DNS one.
EXISTING_CNAMES: tuple[tuple[str, str], ...] = (
    ("autodiscover", "autodiscover.outlook.com"),
    (
        "selector1._domainkey",
        "selector1-meridiansgrp-com._domainkey.netorgft20419956.n-v1.dkim.mail.microsoft",
    ),
    (
        "selector2._domainkey",
        "selector2-meridiansgrp-com._domainkey.netorgft20419956.n-v1.dkim.mail.microsoft",
    ),
    ("email", "email.secureserver.net"),
    ("lyncdiscover", "webdir.online.lync.com"),
    ("sip", "sipdir.online.lync.com"),
    ("msoid", "clientconfig.microsoftonline-p.net"),
    # NOT OURS — the other owner's production application. Never remove.
    ("ai", "d159v1qnwsd8mk.cloudfront.net"),
    # GoDaddy Domain Connect discovery. Inert once GoDaddy stops being
    # authoritative, copied anyway because the zone is a byte-for-byte copy and
    # deciding which live records "do not matter" is how records go dark.
    ("_domainconnect", "_domainconnect.gd.domaincontrol.com"),
    # NOT OURS — the other owner's load balancer origin and its two ACM
    # validation records (2026-10-12 export). Never repoint or remove.
    ("origin.ai", "meridian-alb-1064237917.us-east-1.elb.amazonaws.com"),
    (
        "_3a76167a4347ecb50f0bea492dd6aa2f.ai",
        "_b9610c27c74ff69ce86addc7198b7f5d.jkddzztszm.acm-validations.aws",
    ),
    (
        "_ca552b8e33c5217aaad223574627efd0.origin.ai",
        "_9ae19446168f1d5e485a014dbb89c097.jkddzztszm.acm-validations.aws",
    ),
    # GoDaddy Payments pay links (2026-10-12 export).
    ("pay", "paylinks.commerce.godaddy.com"),
)

#: The one comment every record of the other owner's carries. ASCII only, like every
#: string that reaches the template: the deployed copy of this stack's template shows
#: an em dash as `?`, so a non-ASCII comment is a phantom change on every deploy.
NOT_MERIDIAN_COMMENT = (
    "NOT MERIDIAN - the other account owner's application. Never repoint or delete."
)

#: Per-record Route 53 comments where "copied from GoDaddy" is not the whole
#: story. Anything not named here gets the default comment.
CNAME_COMMENTS: dict[str, str] = {
    "ai": NOT_MERIDIAN_COMMENT,
    "origin.ai": NOT_MERIDIAN_COMMENT,
    "_3a76167a4347ecb50f0bea492dd6aa2f.ai": NOT_MERIDIAN_COMMENT,
    "_ca552b8e33c5217aaad223574627efd0.origin.ai": NOT_MERIDIAN_COMMENT,
    "_domainconnect": "GoDaddy Domain Connect discovery. Inert after the switch; copied anyway.",
    "pay": "GoDaddy Payments pay links. Copied from GoDaddy.",
}

#: **Resend — live production mail transport until the Phase 7 flip after Phase 9
#: (tracker T:41). Remove when the Resend account closes.** Resend sends the
#: production app's invites and password resets from the `updates.` subdomain, and
#: these three records are what make that mail deliverable. Missing at the switch,
#: they fail as "invites stopped arriving", not as DNS. Found by the 2026-10-12
#: zone-file export (`docs/runbooks/dns-move-audit-2026-10-12.md`).
#:
#: `send.updates` is Resend's bounce / return-path domain: an MX and its SPF. Resend
#: runs on SES underneath, hence the `amazonses.com` host — the same values as the
#: SES MAIL FROM records on `mail.`, but a different name and owned by Resend's SES
#: account, not ours. `resend._domainkey.updates` is Resend's DKIM public key.
RESEND_RETURN_PATH = "send.updates"
RESEND_RETURN_PATH_MX = "feedback-smtp.us-east-1.amazonses.com"
RESEND_RETURN_PATH_SPF = "v=spf1 include:amazonses.com ~all"
RESEND_DKIM_NAME = "resend._domainkey.updates"
#: Copied from the GoDaddy zone-file export, never retyped: base64, case-sensitive,
#: and a single wrong character fails DKIM silently. 218 characters, so one TXT
#: string. (Were it ever longer than 255, `TxtRecord` splits it into 255-character
#: strings inside the one value itself — which is what Route 53 requires.)
RESEND_DKIM_PUBLIC_KEY = (
    "p=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC5h9ruwN6G+QDw1Ej7TZ8B5a2Vqw8/gEu78kaUP9w64hb"
    "36NkZDI+YGPO3ccxbwLg4KKxQu0xy8yQx5MYJySX3dUKk5fnPuy8S03BZXzFIPIJ/Eg8mo0fAS1p14MrOPJfZ"
    "rp82P1zg30TQdwj2KT2ItWUWRafV7TR/FxDGhqIQNQIDAQAB"
)

#: The two Skype for Business / Teams SRV records, as
#: `(record_name, priority, weight, port, target)`. SRV is the one record type a
#: hand-copy gets wrong silently, because the four numbers are positional.
EXISTING_SRV: tuple[tuple[str, int, int, int, str], ...] = (
    ("_sipfederationtls._tcp", 100, 1, 5061, "sipfed.online.lync.com"),
    ("_sip._tls", 100, 1, 443, "sipdir.online.lync.com"),
)

#: Render, today's host. **Phase 9 replaces both of these with CloudFront
#: aliases** (ADR 0015): the apex A record becomes an ALIAS to the distribution —
#: the whole reason the zone exists — and `www` becomes an ALIAS too. Until then
#: they are copied exactly so that switching nameservers changes nothing a
#: visitor can see.
#:
#: **Only these two names move at cutover** (ADR 0050). `app`, `api`,
#: `staging-app` and `staging-api` are new names that Render never answered for,
#: so there is nothing here to remove for them: `meridian-<env>-edge` creates
#: their ALIAS records whenever it is given the zone id, well before Phase 9.
#: After cutover the apex only redirects to `www`, and `www` serves the public
#: website and redirects every app path to `app`.
RENDER_APEX_IP = "216.24.57.1"
RENDER_WWW_HOST = "meridian-web-c2sv.onrender.com"

#: The context flag that removes the two Render records — `-c renderRecords=false`.
#:
#: **Why a flag here and not a move into `edge.py`.** The apex and `www` cannot be
#: two things at once: Route 53 refuses a second A record set at the apex, and a
#: `www` CNAME cannot coexist with a `www` A/AAAA alias at all. So the Render
#: records and the CloudFront aliases are mutually exclusive, and something has to
#: make that mutual exclusion deployable. Two options were considered:
#:
#: 1. **Move both records into `edge.py`**, under the same `createDnsAliases` flag
#:    inverted, so one stack and one deploy swap them atomically. **Rejected.**
#:    `EdgeStack` does not own the zone and deliberately does not depend on
#:    `DnsStack` (see `EdgeStack._hosted_zone`: no `from_lookup`, no cross-stack
#:    export). It reads the zone id from `-c hostedZoneId`, and **without that
#:    context value it creates no records at all** — so a production deploy that
#:    forgot the flag would silently take the bare domain dark. Worse, `DnsStack`
#:    is the checked-in, byte-for-byte copy of the GoDaddy zone
#:    (`infra/dns/meridiansgrp.com.zone.json`, asserted by
#:    `infra/tests/test_dns.py`); moving two of its records into a per-environment
#:    stack breaks the one property the nameserver switch rests on.
#: 2. **Keep them here behind this flag.** Chosen. The cutover is then a
#:    *two-stack sequence* — `meridian-shared-dns` with `-c renderRecords=false`
#:    first, then `meridian-production-edge` with `-c createDnsAliases=true` —
#:    with a short dark window between the two deploys. `docs/runbooks/cutover.md`
#:    step 7 states that window and its length, and the rollback is "re-add and
#:    deploy", not a console edit.
#:
#: Default **true**: today's production answer is Render, and a deploy that forgot
#: the flag must not change that.
RENDER_RECORDS_FLAG = "renderRecords"

#: Short on purpose. The plan's Phase 9 precondition is a 300-second TTL on the
#: records that move at cutover, at least a day beforehand; starting there means
#: it is never a forgotten chore.
CUTOVER_TTL = Duration.seconds(300)

#: Mail records do not move at cutover, so they keep an ordinary TTL.
MAIL_TTL = Duration.hours(1)

#: The CloudWatch dimension SES publishes `RenderingFailure` under (tracker T:39).
#: Its value is the `env` message tag `src/email_service.py` puts on every send, so
#: staging's and production's failures are separate metrics in one shared
#: configuration set; a send without the tag lands under `SES_ENV_DIMENSION_DEFAULT`.
SES_ENV_DIMENSION = "env"
SES_ENV_DIMENSION_DEFAULT = "untagged"


def _flag(scope: Construct, name: str, *, default: bool) -> bool:
    """A boolean CDK context value. `-c name=false` arrives as the *string* "false"."""
    raw = scope.node.try_get_context(name)
    if raw is None:
        return default
    if isinstance(raw, bool):
        return raw
    return str(raw).strip().lower() in ("1", "true", "yes", "on")


def _construct_id(record_name: str) -> str:
    """A CloudFormation-safe construct id from a DNS label.

    Construct ids are alphanumeric; `_sip._tls` and `selector1._domainkey` are not.
    Stripping the punctuation and title-casing the parts keeps the ids readable
    (`SipTls`, `Selector1Domainkey`) and, more importantly, **stable** — a changed
    construct id is a delete-and-recreate of the record, which during a nameserver
    switch is an outage.
    """
    return "".join(part.capitalize() for part in record_name.replace(".", "_").split("_") if part)


class DnsStack(Stack):
    """The public hosted zone, its existing records, and the SES sending identity."""

    def __init__(self, scope: Construct, construct_id: str, **kwargs: Any) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # A DNS zone is, by definition, world-readable: anyone can `dig` it.
        # Nothing here is PHI or internal.
        Tags.of(self).add("DataClassification", "public")

        self.domain = str(self.node.try_get_context("domain") or DEFAULT_DOMAIN)
        self.mail_from_domain = f"{MAIL_FROM_PREFIX}.{self.domain}"
        #: The `From` every Meridian message carries, and the value the api task
        #: role's `ses:FromAddress` condition names (`stacks/compute.py`).
        self.no_reply_address = f"{NO_REPLY_LOCAL_PART}@{self.domain}"
        #: The configuration set's name as a **plain string**, computed before the
        #: construct exists. `configuration_set.configuration_set_name` is a
        #: CloudFormation token, and a token handed to another stack becomes an
        #: export — which would make `meridian-<env>-compute` unable to deploy
        #: before the shared DNS stack and unable to be destroyed after it. The
        #: name is ours, deterministic and already in the naming convention, so
        #: the two stacks can agree on the text without a dependency arrow.
        self.configuration_set_name = resource_name(SHARED, "ses", "default")

        #: `-c renderRecords=false` removes the apex A and `www` CNAME that point at
        #: Render, so that `meridian-production-edge` can claim those two names as
        #: CloudFront aliases. See `RENDER_RECORDS_FLAG` for why the two records live
        #: here rather than in `edge.py`, and `docs/runbooks/cutover.md` step 7 for the
        #: two-deploy sequence and its dark window.
        self.render_records = _flag(self, RENDER_RECORDS_FLAG, default=True)

        self.zone = self._hosted_zone()
        self._existing_records(self.zone)

        self.email_events = self._email_events_topic()
        self.configuration_set = self._configuration_set(self.email_events)
        self.email_identity = self._email_identity(self.zone, self.configuration_set)

        self._outputs()

    # ------------------------------------------------------------------- zone

    def _hosted_zone(self) -> route53.PublicHostedZone:
        zone = route53.PublicHostedZone(
            self,
            "PublicZone",
            zone_name=self.domain,
            comment=(
                "Meridian authoritative DNS. Registrar remains GoDaddy; only the "
                "nameservers point here. See docs/adr/0017-route53-zone.md."
            ),
        )
        # Deleting the zone deletes every record in it, including the MX records
        # that carry the company's inbound mail. `cdk destroy` should not be able
        # to take mail down by accident.
        zone.apply_removal_policy(RemovalPolicy.RETAIN)
        return zone

    def _existing_records(self, zone: route53.PublicHostedZone) -> None:
        """Every record GoDaddy serves today, copied exactly.

        The list is closed: if `dig` finds a record at GoDaddy that is not here,
        it disappears at the nameserver switch. The runbook diffs the two zones —
        and sweeps for names neither zone file mentions — before anyone touches
        the registrar.

        **Two of them are conditional**: the apex A record and the `www`
        CNAME that point at Render sit behind `-c renderRecords=false`
        (`RENDER_RECORDS_FLAG`), which the Phase 9 cutover sets so that
        `meridian-production-edge` can create CloudFront aliases at those names.
        Default true — nothing but the cutover removes them.
        """
        route53.MxRecord(
            self,
            "InboundMx",
            zone=zone,
            ttl=MAIL_TTL,
            comment="Proofpoint Essentials. Inbound mail does NOT move to AWS.",
            values=[route53.MxRecordValue(priority=0, host_name=host) for host in PROOFPOINT_MX],
        )

        route53.TxtRecord(
            self,
            "ApexTxt",
            zone=zone,
            ttl=MAIL_TTL,
            comment=(
                "SPF plus the Microsoft 365 tenant verification string. One record "
                "set, two values — DNS allows only one TXT set per name."
            ),
            values=[APEX_SPF, MICROSOFT_TENANT_TXT],
        )

        route53.TxtRecord(
            self,
            "DmarcTxt",
            zone=zone,
            record_name="_dmarc",
            ttl=MAIL_TTL,
            comment="Relaxed alignment; this is what lets the SES MAIL FROM subdomain align.",
            values=[DMARC_POLICY],
        )

        if self.render_records:
            route53.ARecord(
                self,
                "ApexToRender",
                zone=zone,
                ttl=CUTOVER_TTL,
                comment="Render today. Phase 9 replaces this with a CloudFront ALIAS (ADR 0015).",
                target=route53.RecordTarget.from_ip_addresses(RENDER_APEX_IP),
            )

            route53.CnameRecord(
                self,
                "WwwToRender",
                zone=zone,
                record_name="www",
                ttl=CUTOVER_TTL,
                comment=("Render today. Phase 9 replaces this with a CloudFront ALIAS (ADR 0015)."),
                domain_name=RENDER_WWW_HOST,
            )

        for record_name, target in EXISTING_CNAMES:
            route53.CnameRecord(
                self,
                f"Existing{_construct_id(record_name)}Cname",
                zone=zone,
                record_name=record_name,
                ttl=MAIL_TTL,
                comment=CNAME_COMMENTS.get(
                    record_name, "Copied from GoDaddy. Does not move to AWS."
                ),
                domain_name=target,
            )

        for record_name, priority, weight, port, target in EXISTING_SRV:
            route53.SrvRecord(
                self,
                f"Existing{_construct_id(record_name)}Srv",
                zone=zone,
                record_name=record_name,
                ttl=MAIL_TTL,
                comment="Copied from GoDaddy. Skype for Business / Teams federation.",
                values=[
                    route53.SrvRecordValue(
                        priority=priority, weight=weight, port=port, host_name=target
                    )
                ],
            )

        # Resend: the production app's mail transport today. See `RESEND_RETURN_PATH`.
        route53.MxRecord(
            self,
            "ResendReturnPathMx",
            zone=zone,
            record_name=RESEND_RETURN_PATH,
            ttl=MAIL_TTL,
            comment="Resend return path. Live production mail until the Phase 7 flip (T:41).",
            values=[route53.MxRecordValue(priority=10, host_name=RESEND_RETURN_PATH_MX)],
        )
        route53.TxtRecord(
            self,
            "ResendReturnPathSpfTxt",
            zone=zone,
            record_name=RESEND_RETURN_PATH,
            ttl=MAIL_TTL,
            comment="Resend return-path SPF. Live production mail until the Phase 7 flip (T:41).",
            values=[RESEND_RETURN_PATH_SPF],
        )
        route53.TxtRecord(
            self,
            "ResendDkimTxt",
            zone=zone,
            record_name=RESEND_DKIM_NAME,
            ttl=MAIL_TTL,
            comment="Resend DKIM key. Live production mail until the Phase 7 flip (T:41).",
            values=[RESEND_DKIM_PUBLIC_KEY],
        )

    # -------------------------------------------------------------------- ses

    def _email_events_topic(self) -> sns.Topic:
        """Where SES publishes bounces, complaints and rejects.

        Separate from the foundation stack's `security-alerts` topic on purpose:
        a bounce is an operational signal about one recipient, not a security
        event, and mixing the two trains people to ignore both.
        """
        alert_email = CfnParameter(
            self,
            "EmailEventsAddress",
            type="String",
            min_length=3,
            description=(
                "Mailbox that receives SES bounce, complaint and reject notifications. "
                "Passed at deploy time (--parameters EmailEventsAddress=...), never committed."
            ),
        )

        topic = sns.Topic(
            self,
            "EmailEvents",
            topic_name=resource_name(SHARED, "sns", "email-events"),
            display_name="Meridian SES delivery events",
            # Not KMS-encrypted, matching the foundation stack's alerts topic:
            # the payload is a bounce type and a recipient address.
            master_key=None,
        )
        # A bounce notification names the person who did not receive the mail.
        # That is not PHI, but it is not public either.
        Tags.of(topic).add("DataClassification", "internal")

        topic.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowSesPublish",
                principals=[iam.ServicePrincipal("ses.amazonaws.com")],
                actions=["sns:Publish"],
                resources=[topic.topic_arn],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )

        subscription = sns.Subscription(
            self,
            "EmailEventsSubscription",
            topic=topic,
            protocol=sns.SubscriptionProtocol.EMAIL,
            endpoint=alert_email.value_as_string,
        )
        Tags.of(subscription).add("DataClassification", "internal")
        return topic

    def _configuration_set(self, topic: sns.Topic) -> ses.ConfigurationSet:
        """The default configuration set every Meridian send goes through.

        `tls_policy=REQUIRE` is the load-bearing one: it refuses to deliver over
        an unencrypted connection rather than silently downgrading. Mail from
        this domain can carry a patient's name in a subject line by accident, so
        opportunistic TLS is not good enough (ADR 0014, plan §2.3).

        **Suppression list — policy, not just a setting.**
        `suppression_reasons=BOUNCES_AND_COMPLAINTS` puts an address that hard-
        bounced or complained onto the account suppression list, and SES then
        refuses to send to it until somebody removes it. That is deliberate:
        continuing to mail an address that has already bounced is what costs a
        sending reputation, and the reputation is shared by every invite anyone
        will ever send from this domain. Three rules follow, and they are in
        `docs/runbooks/email-cutover.md`:

        * The list is **empty before the flip** and is checked then
          (`aws sesv2 list-suppressed-destinations`).
        * An entry is removed **only** after the address has been confirmed with
          its owner by another channel — never in bulk, never "to see if it
          works now".
        * A suppressed recipient is a *silent* non-delivery to the application:
          `SesEmailSender.send` returns `{"success": False, ...}` and the invite
          row still exists. That is the same contract Resend had, and it is why
          the bounce topic, not the application log, is where non-delivery is
          noticed.
        """
        configuration_set = ses.ConfigurationSet(
            self,
            "DefaultConfigurationSet",
            configuration_set_name=self.configuration_set_name,
            tls_policy=ses.ConfigurationSetTlsPolicy.REQUIRE,
            # Bounce and complaint rates, per configuration set, in CloudWatch.
            # Without these the first sign of a reputation problem is AWS
            # suspending the account.
            reputation_metrics=True,
            suppression_reasons=ses.SuppressionReasons.BOUNCES_AND_COMPLAINTS,
        )

        ses.ConfigurationSetEventDestination(
            self,
            "EmailEventsDestination",
            configuration_set=configuration_set,
            # `meridian-shared-ses-events`: the naming convention applies here like
            # anywhere else. It is not a free-text label — it is the name that
            # appears in `aws sesv2 get-configuration-set-event-destinations`, and
            # a stray `sns-delivery-events` in an account shared with another owner
            # (ADR 0001) is a resource nobody can attribute.
            configuration_set_event_destination_name=resource_name(SHARED, "ses", "events"),
            destination=ses.EventDestination.sns_topic(topic),
            # Deliberately not DELIVERY/OPEN/CLICK: those are marketing
            # telemetry and would bury the four events that mean something is
            # wrong.
            #
            # `RENDERING_FAILURE` joined the set in Phase 7. It fires when SES
            # cannot render a message — and it is the one failure mode that
            # produces NO bounce, NO complaint and no delivery: the message
            # simply never exists. Without it, a template that breaks in
            # production looks exactly like an invite nobody has opened yet.
            events=[
                ses.EmailSendingEvent.BOUNCE,
                ses.EmailSendingEvent.COMPLAINT,
                ses.EmailSendingEvent.REJECT,
                ses.EmailSendingEvent.RENDERING_FAILURE,
            ],
        )

        # **A metric for the one event no alarm could otherwise see** (tracker T:39).
        # Bounce and complaint RATES already reach CloudWatch through
        # `reputation_metrics=True` above (`Reputation.BounceRate` /
        # `Reputation.ComplaintRate`, dimension `ses:configuration-set`), and each
        # environment's observability stack alarms on them. A rendering failure has
        # no rate and no reputation metric: SES publishes a count only through a
        # CloudWatch event destination, so this is that destination, for that one
        # event, dimensioned by the `env` message tag so each environment alarms on
        # its own. It publishes only when a template actually breaks, so on an
        # ordinary month it costs nothing.
        ses.ConfigurationSetEventDestination(
            self,
            "RenderingFailureMetricDestination",
            configuration_set=configuration_set,
            configuration_set_event_destination_name=resource_name(SHARED, "ses", "metrics"),
            destination=ses.EventDestination.cloud_watch_dimensions(
                [
                    ses.CloudWatchDimension(
                        name=SES_ENV_DIMENSION,
                        source=ses.CloudWatchDimensionSource.MESSAGE_TAG,
                        default_value=SES_ENV_DIMENSION_DEFAULT,
                    )
                ]
            ),
            events=[ses.EmailSendingEvent.RENDERING_FAILURE],
        )
        return configuration_set

    def _email_identity(
        self,
        zone: route53.PublicHostedZone,
        configuration_set: ses.ConfigurationSet,
    ) -> ses.EmailIdentity:
        """The verified `meridiansgrp.com` sending identity.

        Handing it the hosted zone is what makes verification self-completing:
        CDK writes the three Easy DKIM CNAMEs, plus the MAIL FROM MX
        (`feedback-smtp.<region>.amazonses.com`) and the MAIL FROM SPF TXT
        (`v=spf1 include:amazonses.com ~all`) into the zone. Nobody copies a
        CNAME by hand, so nobody mistypes one.

        Caveat the runbook repeats: those records only take effect once the
        nameservers point at Route 53. Deploying this stack while GoDaddy is
        still authoritative leaves the identity `Pending`, which is expected,
        not a failure.
        """
        return ses.EmailIdentity(
            self,
            "DomainIdentity",
            identity=ses.Identity.public_hosted_zone(zone),
            # 2048-bit: 1024 is SES's legacy default and is no longer an
            # acceptable signing key length under our own crypto baseline.
            dkim_identity=ses.DkimIdentity.easy_dkim(ses.EasyDkimSigningKeyLength.RSA_2048_BIT),
            dkim_signing=True,
            mail_from_domain=self.mail_from_domain,
            # USE_DEFAULT_VALUE: if the MAIL FROM MX record ever goes missing,
            # SES falls back to `amazonses.com` and the mail still goes out
            # (DKIM still aligns under `adkim=r`). REJECT_MESSAGE would turn a
            # DNS glitch into an outage of every password reset.
            mail_from_behavior_on_mx_failure=ses.MailFromBehaviorOnMxFailure.USE_DEFAULT_VALUE,
            configuration_set=configuration_set,
        )

    # ---------------------------------------------------------------- outputs

    def _outputs(self) -> None:
        """The four nameservers, so the GoDaddy switch is copy-and-paste.

        `hosted_zone_name_servers` is a CloudFormation list attribute; it is
        split into four named outputs because the GoDaddy form has four boxes.
        """
        nameservers = self.zone.hosted_zone_name_servers or []
        for index in range(4):
            CfnOutput(
                self,
                f"NameServer{index + 1}",
                value=Fn.select(index, nameservers),
                description=(
                    f"Route 53 nameserver {index + 1} of 4. Paste into GoDaddy's custom "
                    f"nameserver form — see docs/runbooks/dns-nameserver-switch.md."
                ),
            )

        CfnOutput(
            self,
            "HostedZoneId",
            value=self.zone.hosted_zone_id,
            description="Zone id for the Phase 9 CloudFront ALIAS records.",
        )
        CfnOutput(
            self,
            "SesIdentityName",
            value=self.email_identity.email_identity_name,
            description="SES domain identity. Phase 4 (Cognito) and Phase 7 send as this.",
        )
        CfnOutput(
            self,
            "SesConfigurationSetName",
            value=self.configuration_set.configuration_set_name,
            description="Configuration set every Meridian send must specify (Phase 4 / Phase 7).",
        )
        CfnOutput(
            self,
            "SesNoReplyAddress",
            value=self.no_reply_address,
            description=(
                "The From address. Set as MERIDIAN_SES_FROM_EMAIL wherever the app runs; "
                "the api task role's ses:FromAddress condition names this exact value."
            ),
        )
        CfnOutput(
            self,
            "SesMailFromDomain",
            value=self.mail_from_domain,
            description="Custom MAIL FROM subdomain; carries SES's own SPF, not the apex.",
        )
