"""`meridian-shared-identity` — IAM Identity Center permission sets and the MFA guardrail.

Plan Phase 1 step 2, the IAM triage that is a **hard precondition of Phase 3**
(no PHI lands in the account until it is done). The order is not negotiable and
is written out in `docs/runbooks/identity-center-bootstrap.md`:

1. IAM Identity Center with an admin permission set, and **sign-in verified**;
2. MFA on `andres-cli` and `meridian-app`;
3. `AdministratorAccess` on `andres-cli` replaced with an assumed role;
4. **only then** the long-lived access key deactivated.

Doing (4) first strands you on root-only recovery.

## Why this is its own stack, not part of `foundation`

The foundation stack is the account's security floor: deployed once, then left
alone, and a failed update to it is a bad day. This stack is the opposite — it
changes whenever a person is added or a permission set is retuned, and two of its
three resource groups only exist when identifiers that were created *by hand*
are passed in as context. Keeping them apart means a typo in an Identity Center
ARN cannot roll back CloudTrail, GuardDuty and the break-glass role.

## Why the instance itself is not here — and which *kind* of instance it must be

**CloudFormation cannot create an IAM Identity Center instance.** There is no
resource type for it, so it is made once, by hand, before this stack's second
deploy.

**It has to be an *organization* instance, and that is a decision, not a
detail.** Identity Center comes in two kinds:

* an **organization instance**, enabled from the Identity Center console in the
  management account of an AWS Organization. Permission sets and assignments
  (`AWS::SSO::PermissionSet`, `AWS::SSO::Assignment` — everything below) only
  exist in this kind.
* an **account instance**, which `aws sso-admin create-instance` produces on a
  standalone account. It supports application assignments only. It **cannot
  carry permission sets, cannot grant access to the AWS console, and cannot be
  converted** into an organization instance — the only way out is to delete it.

The account today is standalone, so enabling the organization instance means
first creating an AWS Organization with this account as its management account
(`aws organizations create-organization --feature-set ALL` — free, no SCPs, and
it also makes the plan's future account split routine rather than a migration).
That decision is Andres's and is **step 0 of
`docs/runbooks/identity-center-bootstrap.md`**, which also carries the documented
fallback: no Identity Center at all, and IAM users with enforced MFA assuming
roles instead — a path this stack already supports, because the require-MFA
policy and the humans group below are unconditional.

Once the instance exists, its ARN and the two users' principal ids are passed in
as context at deploy time:

    npx cdk deploy meridian-shared-identity \\
      -c ssoInstanceArn=arn:aws:sso:::instance/ssoins-... \\
      -c ssoAdminPrincipalId=... \\
      -c ssoReadOnlyPrincipalId=...

Those values are **identifiers, so they are never written into this repository**
(ADR 0001) — not in `cdk.json`, not here. Keep them in `infra/cdk.context.json`,
which is gitignored and which the CDK CLI reads automatically, so that every
deploy picks them up without anyone retyping them.

## Why a missing `ssoInstanceArn` is an error, not a shrug

Without the ARN this stack still has useful content — the MFA policy and the
humans group — so an earlier version simply skipped the permission sets. That is
the wrong default in one specific and expensive way: **CDK synthesizes the whole
template every time, so a deploy without the context values does not "skip" the
permission sets, it deletes the ones already deployed**, along with both
assignments, logging everybody out of the account.

So a missing `ssoInstanceArn` raises. Saying "yes, I know, this is the first
pass" is one flag:

    npx cdk synth -c env=staging -c allowNoIdentityCenter=true

which is also what CI passes, since CI has no identifiers and never deploys this
stack.
"""

from __future__ import annotations

from typing import Any

from aws_cdk import (
    Aws,
    CfnOutput,
    Stack,
    Tags,
)
from aws_cdk import (
    aws_iam as iam,
)
from aws_cdk import (
    aws_sso as sso,
)
from constructs import Construct

from ..naming import SHARED, resource_name

#: AWS-managed policies the two permission sets attach. Read-only access plus
#: SecurityAudit is the pair an auditor (or a future session doing a review)
#: needs: `ReadOnlyAccess` sees configuration, `SecurityAudit` adds the IAM and
#: credential-report reads it deliberately withholds.
ADMIN_MANAGED_POLICIES = ("arn:aws:iam::aws:policy/AdministratorAccess",)
READONLY_MANAGED_POLICIES = (
    "arn:aws:iam::aws:policy/ReadOnlyAccess",
    "arn:aws:iam::aws:policy/SecurityAudit",
)
#: Builds and changes resources but cannot manage users, roles or permissions
#: (PowerUserAccess withholds IAM and Organizations). Andres's "write" user,
#: decided 2026-10-01.
WRITE_MANAGED_POLICIES = ("arn:aws:iam::aws:policy/PowerUserAccess",)

#: The break-glass role created by `meridian-shared-foundation`. Named here, not
#: imported, because the two stacks are deliberately independent — a failed
#: update to this one must not be able to roll back CloudTrail — and a name is
#: not a cross-stack reference. `infra/tests/test_identity.py` asserts the two
#: spellings agree.
BREAK_GLASS_ROLE_NAME = resource_name(SHARED, "iam", "breakglass")

#: ISO-8601 duration. Four hours is long enough for a working session and short
#: enough that a walked-away-from laptop is not an admin session overnight.
SESSION_DURATION = "PT4H"

#: The actions a signed-in human may take *before* presenting MFA — exactly
#: enough to enrol a device and no more. Anything absent from this list is
#: denied by `DenyEverythingElseWithoutMfa` below.
_MFA_SETUP_ACTIONS = (
    "iam:CreateVirtualMFADevice",
    "iam:EnableMFADevice",
    "iam:ListMFADevices",
    "iam:ListVirtualMFADevices",
    "iam:ResyncMFADevice",
    "iam:DeactivateMFADevice",
    "iam:ChangePassword",
    "iam:GetUser",
    "iam:GetAccountPasswordPolicy",
    "iam:ListUsers",
    # Without this, a user who has enrolled a device cannot exchange their
    # password for an MFA-bearing session, and the deny below locks them out
    # permanently.
    "sts:GetSessionToken",
)


class IdentityStack(Stack):
    """Identity Center permission sets, their assignments, and the MFA guardrail."""

    def __init__(self, scope: Construct, construct_id: str, **kwargs: Any) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # Principal names and permission-set definitions. No PHI, but not public.
        Tags.of(self).add("DataClassification", "internal")

        self.instance_arn = self._context("ssoInstanceArn")
        self.admin_principal_id = self._context("ssoAdminPrincipalId")
        self.readonly_principal_id = self._context("ssoReadOnlyPrincipalId")
        self.write_principal_id = self._context("ssoWritePrincipalId")
        self._require_instance_arn_or_explicit_waiver()

        self.break_glass_role_arn = self.format_arn(
            service="iam",
            region="",  # IAM is global
            resource="role",
            resource_name=BREAK_GLASS_ROLE_NAME,
        )

        self.require_mfa_policy = self._require_mfa_policy()
        self.humans_group = self._humans_group(self.require_mfa_policy)

        self.admin_permission_set: sso.CfnPermissionSet | None = None
        self.readonly_permission_set: sso.CfnPermissionSet | None = None
        self.write_permission_set: sso.CfnPermissionSet | None = None
        if self.instance_arn:
            self.admin_permission_set = self._permission_set(
                "AdminPermissionSet",
                name=resource_name(SHARED, "sso", "admin"),
                description=(
                    "Full administrative access for the two workforce members. "
                    "Replaces the long-lived AdministratorAccess key on andres-cli."
                ),
                managed_policies=ADMIN_MANAGED_POLICIES,
            )
            self.readonly_permission_set = self._permission_set(
                "ReadOnlyPermissionSet",
                name=resource_name(SHARED, "sso", "readonly"),
                description=(
                    "Read-only plus SecurityAudit: reviews, audits and evidence "
                    "gathering without the ability to change anything."
                ),
                managed_policies=READONLY_MANAGED_POLICIES,
            )
            self.write_permission_set = self._permission_set(
                "WritePermissionSet",
                name=resource_name(SHARED, "sso", "write"),
                description=(
                    "Builds and changes resources; cannot manage users, roles "
                    "or permissions."
                ),
                managed_policies=WRITE_MANAGED_POLICIES,
            )
            self._assignments()

        self._outputs()

    # ------------------------------------------------------------------ context

    def _require_instance_arn_or_explicit_waiver(self) -> None:
        """Fail synthesis when the Identity Center context is silently missing.

        The failure this prevents is not "the permission sets were not created".
        It is the *second* deploy: CDK renders the whole template each time, so
        running `cdk deploy meridian-shared-identity` without the `-c` values
        after a successful one removes both permission sets and both assignments
        — and the person running it is signed in through one of them.

        The waiver is deliberately a separate, explicit flag rather than a
        default, so that "I have not set Identity Center up yet" and "I forgot to
        paste the ARN" stop looking identical.
        """
        if self.instance_arn:
            return
        waiver = self.node.try_get_context("allowNoIdentityCenter")
        if isinstance(waiver, bool):
            allowed = waiver
        else:
            allowed = str(waiver or "").strip().lower() in ("1", "true", "yes")
        if allowed:
            return
        raise ValueError(
            "meridian-shared-identity needs -c ssoInstanceArn=arn:aws:sso:::instance/ssoins-... "
            "(plus -c ssoAdminPrincipalId / -c ssoReadOnlyPrincipalId). Deploying without them "
            "DELETES any permission sets and assignments already created, which locks every "
            "Identity Center user out of the account.\n"
            "  - Set the three values once in infra/cdk.context.json (gitignored; the CDK CLI "
            "reads it automatically) — see docs/runbooks/identity-center-bootstrap.md.\n"
            "  - Or, if Identity Center genuinely does not exist yet (first pass, or the "
            "IAM-users-with-MFA fallback in that runbook's step 0), say so explicitly: "
            "-c allowNoIdentityCenter=true"
        )

    def _context(self, key: str) -> str | None:
        """Read a deploy-time identifier from context, treating blank as absent."""
        value = self.node.try_get_context(key)
        if value is None:
            return None
        text = str(value).strip()
        return text or None

    # -------------------------------------------------------------- identity centre

    def _permission_set(
        self,
        construct_id: str,
        *,
        name: str,
        description: str,
        managed_policies: tuple[str, ...],
    ) -> sso.CfnPermissionSet:
        if self.instance_arn is None:
            raise AssertionError('self.instance_arn is not None')
        return sso.CfnPermissionSet(
            self,
            construct_id,
            instance_arn=self.instance_arn,
            name=name,
            description=description,
            managed_policies=list(managed_policies),
            session_duration=SESSION_DURATION,
        )

    def _assignments(self) -> None:
        """Grant each permission set to its user, when that user's id is known.

        The two are independent: the admin assignment can exist before the
        read-only user does. `PrincipalType=USER` rather than `GROUP` because
        there are two workforce members (plan §2.1) and a group of two is
        indirection without benefit.
        """
        if self.instance_arn is None:
            raise AssertionError('self.instance_arn is not None')
        pairs = (
            ("AdminAssignment", self.admin_principal_id, self.admin_permission_set),
            ("ReadOnlyAssignment", self.readonly_principal_id, self.readonly_permission_set),
            ("WriteAssignment", self.write_principal_id, self.write_permission_set),
        )
        for construct_id, principal_id, permission_set in pairs:
            if not principal_id or permission_set is None:
                continue
            sso.CfnAssignment(
                self,
                construct_id,
                instance_arn=self.instance_arn,
                permission_set_arn=permission_set.attr_permission_set_arn,
                principal_id=principal_id,
                principal_type="USER",
                # This account. `Aws.ACCOUNT_ID` is a pseudo-parameter resolved
                # at deploy time — no account id appears in this repository.
                target_id=Aws.ACCOUNT_ID,
                target_type="AWS_ACCOUNT",
            )

    # -------------------------------------------------------------------- mfa

    def _require_mfa_policy(self) -> iam.ManagedPolicy:
        """Deny everything to an IAM user who has not presented MFA.

        The shape is AWS's own "manage your own credentials" reference policy,
        and the important clause is the last one: a **`NotAction` deny** with
        `BoolIfExists aws:MultiFactorAuthPresent = false`. `BoolIfExists`, not
        `Bool`, because service-linked and role-based calls do not carry the key
        at all and `Bool` would deny them too.

        This binds IAM *users* — `andres-cli` and `meridian-app`. Identity Center
        sign-ins get their MFA requirement from the Identity Center instance
        itself, which the runbook sets to "always require".
        """
        policy = iam.ManagedPolicy(
            self,
            "RequireMfa",
            managed_policy_name=resource_name(SHARED, "iam", "require-mfa"),
            description=(
                "Denies every action to an IAM user who has not presented MFA, except "
                "the calls needed to enrol a device and start an MFA session."
            ),
            statements=[
                iam.PolicyStatement(
                    sid="AllowViewAccountInfo",
                    actions=["iam:GetAccountPasswordPolicy", "iam:ListVirtualMFADevices"],
                    resources=["*"],
                ),
                iam.PolicyStatement(
                    sid="AllowManageOwnPasswordAndUser",
                    actions=["iam:ChangePassword", "iam:GetUser"],
                    resources=[f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:user/${{aws:username}}"],
                ),
                iam.PolicyStatement(
                    sid="AllowManageOwnVirtualMfaDevice",
                    actions=["iam:CreateVirtualMFADevice"],
                    resources=[f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:mfa/${{aws:username}}"],
                ),
                iam.PolicyStatement(
                    sid="AllowManageOwnUserMfa",
                    actions=[
                        "iam:DeactivateMFADevice",
                        "iam:EnableMFADevice",
                        "iam:ListMFADevices",
                        "iam:ResyncMFADevice",
                    ],
                    resources=[f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:user/${{aws:username}}"],
                ),
                iam.PolicyStatement(
                    sid="DenyEverythingElseWithoutMfa",
                    effect=iam.Effect.DENY,
                    not_actions=list(_MFA_SETUP_ACTIONS),
                    resources=["*"],
                    conditions={"BoolIfExists": {"aws:MultiFactorAuthPresent": "false"}},
                ),
            ],
        )
        return policy

    def _humans_group(self, policy: iam.ManagedPolicy) -> iam.Group:
        """The group every human IAM user belongs to.

        Membership is **not** declared here. Adding a user to the group from CDK
        would mean naming that user in this repository, and the runbook adds them
        with one `aws iam add-user-to-group` call instead. The group is the thing
        that has to exist and be correct; who is in it is an operational fact
        that the runbook and the credential report record.

        The group also carries the **break-glass grant**. The role's own trust
        policy (foundation stack) trusts the account root principal with MFA,
        which in IAM means "any principal in this account *that an IAM policy also
        allows*" — a trust policy alone grants nothing. Without the statement
        below, the emergency access procedure required by 45 CFR 164.312(a)(2)(ii)
        fails with `AccessDenied` at the moment it is needed, and the only
        remaining path is the account root user. Discovering that during the
        emergency is the failure the drill in `docs/runbooks/break-glass.md`
        exists to catch; granting it here is how the drill passes.
        """
        group = iam.Group(
            self,
            "Humans",
            group_name=resource_name(SHARED, "iam", "humans"),
            managed_policies=[policy],
        )
        group.add_to_policy(
            iam.PolicyStatement(
                sid="AssumeBreakGlassRole",
                actions=["sts:AssumeRole"],
                # `format_arn`, so the account id is a deploy-time pseudo-parameter
                # and no account literal enters this repository (ADR 0001). IAM is
                # global: the region segment is empty on purpose.
                resources=[self.break_glass_role_arn],
            )
        )
        # The MFA deny in `require_mfa_policy` still applies to this call, and the
        # role's own trust policy requires MFA again. Both are doing work: the
        # first stops a plain access key from reaching for the role at all, the
        # second stops a role chain from laundering its way in.
        return group

    # ---------------------------------------------------------------- outputs

    def _outputs(self) -> None:
        CfnOutput(
            self,
            "RequireMfaPolicyArn",
            value=self.require_mfa_policy.managed_policy_arn,
            description="Attach to any human IAM user outside the humans group.",
        )
        CfnOutput(
            self,
            "BreakGlassRoleArn",
            value=self.break_glass_role_arn,
            description=(
                "The role members of the humans group may assume in an emergency. "
                "Procedure: docs/runbooks/break-glass.md."
            ),
        )
        CfnOutput(
            self,
            "HumansGroupName",
            value=self.humans_group.group_name,
            description=(
                "Add each human IAM user to this group: "
                "aws iam add-user-to-group --group-name <this> --user-name <user>"
            ),
        )
        if self.admin_permission_set is not None:
            CfnOutput(
                self,
                "AdminPermissionSetArn",
                value=self.admin_permission_set.attr_permission_set_arn,
                description="meridian-shared-sso-admin.",
            )
        if self.readonly_permission_set is not None:
            CfnOutput(
                self,
                "ReadOnlyPermissionSetArn",
                value=self.readonly_permission_set.attr_permission_set_arn,
                description="meridian-shared-sso-readonly.",
            )
        if self.write_permission_set is not None:
            CfnOutput(
                self,
                "WritePermissionSetArn",
                value=self.write_permission_set.attr_permission_set_arn,
                description="meridian-shared-sso-write.",
            )
