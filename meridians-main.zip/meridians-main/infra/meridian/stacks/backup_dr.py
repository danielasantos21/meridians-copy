"""`meridian-<env>-dr` — the second region's locked backup vault, and nothing else.

**What it is for.** ADR 0007 buys an 8-business-hour RTO with backups rather than with a
standby, and a backup that only exists in `us-east-1` does not cover the loss of
`us-east-1`. The `data` stack's backup plan copies every recovery point here. This stack
is the *destination*: one vault, one CMK, both in the DR region, both locked.

**Why it is a separate stack.** A CloudFormation stack lives in exactly one region, so a
vault in `us-west-2` cannot be a resource of a `us-east-1` stack. The region comes from
`-c drRegion` (default `us-west-2`).

**It is always in the app (M-5).** An earlier version of this docstring — and of
`app.py` — said the stack was added "only when `CDK_DEFAULT_REGION` is set", on the theory
that pinning a stack needs a concrete account as well as a concrete region. It does not:
only the region has to be concrete, and the account stays unresolved like every other
stack here, so `cdk synth` still runs with no credentials at all. Worse, the CDK CLI sets
`CDK_DEFAULT_REGION` from whatever credentials are in use, so under the CLI the stack was
*always* present and the conditional only ever hid it from the in-process tests — which is
exactly the place a missing DR vault goes unnoticed. The conditional is gone and a test
asserts the stack is there in both environments.

The deploy order is an ordering rule rather than a CloudFormation dependency, and it is in
`docs/runbooks/restore-drill.md` §1 as well as here:

    cdk deploy meridian-<env>-dr      # first
    cdk deploy meridian-<env>-data    # the copy action names the vault above

The `data` stack does not import this stack's vault — it **constructs the ARN** from
pseudo-parameters (`DataStack.dr_vault_arn`), because there is no cross-region export and
CDK's cross-region reference support works by putting a custom-resource Lambda in the
path. A composed ARN needs no Lambda and writes down no account id. It also means the
`data` stack synthesizes identically whether or not this one is in the app, which is what
keeps CI's two byte-identical synths byte-identical.

**Only production writes into it on a schedule (M-2).** The staging `data` stack has the
vault, the lock and the role but no backup plan, because a nightly job against an instance
that the 02:00 stop schedule turned off three hours earlier fails every night. Staging's
recovery points come from PITR and from the one on-demand job `scripts/staging_session.sh
down` runs; those are not copied here, so this vault holds production only.

**The key is a separate CMK from the `data` stack's `backups` key**, and has to be: a KMS
key is regional, and a `us-east-1` key cannot encrypt anything in `us-west-2`. AWS Backup
re-encrypts on copy with the destination vault's key.
"""

from __future__ import annotations

from typing import Any

from aws_cdk import Aws, CfnOutput, Duration, RemovalPolicy, Tags
from aws_cdk import aws_backup as backup
from aws_cdk import aws_iam as iam
from aws_cdk import aws_kms as kms
from constructs import Construct

from ..config import EnvConfig
from ..naming import resource_name
from .base import EnvStack
from .data import (
    VAULT_CHANGEABLE_FOR_DAYS,
    VAULT_MAX_RETENTION_DAYS,
    VAULT_MIN_RETENTION_DAYS,
)


class BackupDrStack(EnvStack):
    """One compliance-locked backup vault and its CMK, in the DR region."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_config: EnvConfig,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            scope, construct_id, env_config=env_config, data_classification="phi", **kwargs
        )

        # Note: `assert_edge_region` is deliberately NOT called. This is the one stack in
        # the estate that is not in us-east-1, and that is its entire purpose.

        self.key = kms.Key(
            self,
            "KeyBackupsDr",
            alias=f"alias/{resource_name(self.env_name, 'kms', 'backups-dr')}",
            description=(
                f"The DR backup vault's key ({self.env_name}). Regional: the "
                "us-east-1 backups key cannot encrypt anything here."
            ),
            enable_key_rotation=True,
            removal_policy=RemovalPolicy.RETAIN,
        )
        self.key.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowThisEnvironmentsRoles",
                principals=[iam.AccountRootPrincipal()],
                actions=[
                    "kms:Encrypt",
                    "kms:Decrypt",
                    "kms:ReEncrypt*",
                    "kms:GenerateDataKey*",
                    "kms:DescribeKey",
                    "kms:CreateGrant",
                ],
                resources=["*"],
                conditions={
                    "ArnLike": {
                        "aws:PrincipalArn": (
                            f"arn:{Aws.PARTITION}:iam::{Aws.ACCOUNT_ID}:role/"
                            f"meridian-{self.env_name}-*"
                        )
                    }
                },
            )
        )
        # AWS Backup copies into this vault using a service-linked role in the source
        # region; the destination key has to admit the service itself, not a named role.
        self.key.add_to_resource_policy(
            iam.PolicyStatement(
                sid="AllowAwsBackupToCopyIntoThisRegion",
                principals=[iam.ServicePrincipal("backup.amazonaws.com")],
                actions=[
                    "kms:Encrypt",
                    "kms:Decrypt",
                    "kms:ReEncrypt*",
                    "kms:GenerateDataKey*",
                    "kms:DescribeKey",
                    "kms:CreateGrant",
                ],
                resources=["*"],
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            )
        )

        self.vault = backup.BackupVault(
            self,
            "DrBackupVault",
            # The name the `data` stack composes into an ARN. It is a contract between
            # the two stacks; changing it here breaks the copy action there silently, at
            # the first copy job rather than at deploy.
            backup_vault_name=resource_name(self.env_name, "backup", "dr"),
            encryption_key=self.key,
            removal_policy=RemovalPolicy.RETAIN,
            lock_configuration=backup.LockConfiguration(
                min_retention=Duration.days(VAULT_MIN_RETENTION_DAYS),
                max_retention=Duration.days(VAULT_MAX_RETENTION_DAYS),
                changeable_for=Duration.days(VAULT_CHANGEABLE_FOR_DAYS),
            ),
        )
        Tags.of(self.vault).add("DataClassification", "phi")
        Tags.of(self.key).add("DataClassification", "phi")

        CfnOutput(
            self,
            "DrBackupVaultArn",
            value=self.vault.backup_vault_arn,
            description=(
                "The cross-region copy destination. meridian-<env>-data composes this "
                "same ARN from pseudo-parameters; deploy this stack first."
            ),
        )
