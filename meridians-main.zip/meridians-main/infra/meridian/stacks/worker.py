"""The Phase 11 generic worker's AWS side (tasks H1/H2, `docs/reports/phase-11-plan.md` §3.8).

**Built by `ComputeStack` only with `-c worker_enabled=true`, off by default** (the flag is
`meridian/config.py`'s). Off, nothing in this module is instantiated and every template is
byte-identical to the one before it existed (`infra/tests/test_worker.py`). On, it adds:

* **SQS `meridian-<env>-sqs-jobs`** and its DLQ `-sqs-jobs-dlq`: the `phi` CMK, TLS only,
  visibility 900 s, receive wait 20 s, redrive after 3 receives, DLQ kept 14 days.
* **The sweep tick**: EventBridge Scheduler, `rate(15 minutes)`, in its own schedule group,
  sending the D5 `sweep` message to the job queue through a role that may do exactly that.
* **`meridian-<env>-ecs-svc-worker`**: one Fargate task of the **api image** with
  `command: ["python", "-m", "workers"]`, ARM64 0.5 vCPU / 1 GB, `stopTimeout` 120 s, no
  load balancer, rolling deploys with the circuit breaker.
* **`meridian-<env>-iam-ecs-worker-task`**: its own task role, least privilege (below).
* **The api task's side**: `sqs:SendMessage` on the job queue only (plan §3.8), and both
  queue URLs in its environment for D4's `enqueue()`.
* **With `-c enableApiPlatform=true` as well** (Phase 12 T19): `WEBHOOK_EVENT_BUS` in the
  worker's environment and `events:PutEvents` on that one bus, for the settle's after-commit
  publish of the run's `api_events` row; and **the 5-minute outbox sweep tick** (decision
  D17): a second schedule in the same group, through the same role, sending
  `workers.contract.OutboxSweepMessage` to the job queue — the worker runs the pass that
  re-publishes what a failed publish left, and (critic Stage 1 M-8) re-enqueues webhook
  deliveries whose delayed message was lost — so the worker also gets `WEBHOOK_QUEUE_URL`
  and `sqs:SendMessage` on that one queue (plus the `logs` CMK through SQS).

The five alarms (H2) are `observability`'s (`_worker_alarms`), on the constructs this
module exposes.

WHY `compute` AND NOT `api` (a deviation from plan §3.8's "`api.py`" row)
-----------------------------------------------------------------------
Two facts decided it. **The deploy workflow deploys `meridian-<env>-compute` alone**
(`.github/workflows/deploy.yml`, `--exclusively`, with `-c apiImageTag=<sha>`): a worker
anywhere else would keep running the previous commit's code after every api deploy, and
the api and the worker share the message contract and the handlers. And **the queue has to
exist before the worker's first task starts**: a worker whose queue is in `api` — which
imports from `compute`, so `compute` deploys first — would crash-loop on
`QueueDoesNotExist`, the deployment circuit breaker would fail the new service, and the
whole `compute` update would roll back. So the queue, the schedule and the service live
together, in the stack that already owns the image, the cluster and the api task role.

THE KEY IS `phi`, NOT `logs`
----------------------------
The webhook queues are on the `logs` CMK because their messages are ids and a reason code.
A job message is ids too — plus each input's storage key, which ends in the uploaded file's
own name (`src/process_inputs.object_name`), and billing exports get called things like
`<surname>_Aug.xlsx` (`src/storage.py`). The DLQ keeps a refused message for 14 days.
So the queue fails closed to the key of the bucket that name points into; nothing else on
the queue's path needs a different one, and every role that touches it is a
`meridian-<env>-*` role the key policy already delegates to IAM (`data.py`).

THE DATABASE ROLE (D2's open question)
--------------------------------------
The worker connects as **`meridian_app`**, with the same `meridian-<env>-secret-db-app`
password the api uses, resolved by the same execution role. D2 granted `app.authorize_job`,
`app.claim_run` and `app.expire_stale_runs` EXECUTE to `meridian_app` for exactly this
reason: the worker is the api image with another command, and tenant isolation holds the
same way for both (RLS on `app.org_id`, set only after `authorize_job` says yes).

WHAT THE WORKER ROLE MAY DO, AND WHAT IT MAY NOT
------------------------------------------------
May: receive / delete / change the visibility of messages on the job queue; send to the
DLQ (the transport's `dead_letter`, a refusal with a reason code); read the run's inputs
(`{org}/{run}/uploads/*` in the `phi` bucket — object, version, tags and version tags,
because `materialize_inputs` reads the GuardDuty verdict *of the exact version*); read and
write state objects (`{org}/{run}/state/*`); write the processors' outputs under
`{org}/{batch}/{journal_entries,data,reports,bundle}/*` (`src/storage.BUCKET_BY_SUBFOLDER`);
use the two bucket keys through S3 and the `phi` key through SQS; send mail as the one
verified mailbox through the one configuration set (the processors' completion notice);
with the api platform on, `PutEvents` on `meridian-<env>-events-api` and no other bus, and
`SendMessage` on `meridian-<env>-sqs-webhooks` alone (the stalled-delivery sweep) with the
`logs` key through SQS; `kms:GenerateDataKey` / `kms:Decrypt` on `meridian-<env>-kms-tokens` only, conditioned on
the `purpose=qbo-token` encryption context (ADR 0044 — the api task role holds the same,
with or without this flag).

May not: delete any object; list any bucket (`S3StateBackend.keys` is not on the worker's
path; a handler that needs it asks for `s3:ListBucket` with an `s3:prefix` condition);
write under `uploads/` (PS-15: only the api writes there); read the `phi-hmac-key` or
`db-phi` secret; ECS Exec; anything with `Resource: "*"` or a wildcard action.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from aws_cdk import ArnFormat, Aws, CfnOutput, Duration, RemovalPolicy, Tags
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_ecs as ecs
from aws_cdk import aws_iam as iam
from aws_cdk import aws_logs as logs
from aws_cdk import aws_scheduler as scheduler
from aws_cdk import aws_sqs as sqs
from constructs import Construct

from ..api_platform import event_bus_name, queue_url, webhook_queue_name
from ..config import api_platform_enabled
from ..naming import resource_name
from .data import (
    LOG_RETENTION,
    QBO_TOKEN_KMS_ACTIONS,
    QBO_TOKEN_KMS_KEY_ENV,  # noqa: F401 re-exported: the worker's tests import it here
    QBO_TOKEN_KMS_PURPOSE,
)
from .vpc import SUBNET_APP

if TYPE_CHECKING:
    from .compute import ComputeStack

#: The container name, the log stream prefix and the last segment of every name.
WORKER = "worker"

#: ARM64, 0.5 vCPU / 1 GB: the starting size; the memory alarm is what would move it.
WORKER_CPU = 512
WORKER_MEMORY_MIB = 1024

#: **One** worker. A second is a cost line, not a correctness one — the lease (ADR 0030)
#: makes two safe.
WORKER_DESIRED_COUNT = 1

#: The api image's second command (task D6: `Dockerfile.api` smoke-tests it at build).
WORKER_COMMAND = ("python", "-m", "workers")

#: 15 minutes, and it is `workers/transport.DEFAULT_VISIBILITY_SECONDS` (a test reads that
#: file rather than retyping the number). Every job's `timeout_s` must stay under it, and
#: the worker heartbeats every 120 s (`workers/run_job.HEARTBEAT_SECONDS`).
JOBS_VISIBILITY_TIMEOUT = Duration.seconds(900)

#: Long polling: one receive every 20 s from an idle worker, not one per second.
JOBS_RECEIVE_WAIT = Duration.seconds(20)

#: Plan §3.5 / D1: the third receive is the last; `app.expire_stale_runs` fails a run at
#: `attempts >= 3` with the same number, and `workers/transport.DEFAULT_MAX_RECEIVE_COUNT`
#: is what the in-process queue redrives at.
JOBS_MAX_RECEIVES = 3

#: SQS's own default, written down: a job nobody took in four days is not a job any more.
JOBS_RETENTION = Duration.days(4)

#: Plan §3.5: 14 days (the SQS maximum), so a refusal is still there after a long weekend.
JOBS_DLQ_RETENTION = Duration.days(14)

#: Plan §3.5 (D5): the sweeper's tick.
SWEEP_SCHEDULE = "rate(15 minutes)"

#: The sweep message the schedule sends: D1's `SweepMessage`, exactly (a test parses it
#: with `workers/contract.parse_body`). **Its `job_id` is a constant** — Scheduler's own
#: execution id is not a uuid4, the contract requires one, and a sweep has no run, no lease
#: and no dedupe: the id only ever appears in a log line, and a duplicate tick is harmless
#: (a second sweep finds nothing to move).
SWEEP_JOB_ID = "03010eb0-0330-4309-a9e8-3da847584dd5"
SWEEP_MESSAGE = {"v": 1, "job_id": SWEEP_JOB_ID, "kind": "sweep"}

#: Scheduler retries a failed send twice within ten minutes, then drops the tick and counts
#: it in `AWS/Scheduler` `InvocationDroppedCount` — which the `sweep-dropped` alarm reads.
#: The next tick is fifteen minutes away anyway.
SWEEP_RETRIES = 2
SWEEP_MAX_EVENT_AGE = Duration.minutes(10)

#: Plan §3.7 / risk R9: "sweep every 5 min re-publishes rows with published_at IS NULL".
OUTBOX_SWEEP_SCHEDULE = "rate(5 minutes)"

#: The outbox tick (decision D17): `workers.contract.OutboxSweepMessage`, exactly. A constant
#: `job_id` for the same reason as `SWEEP_JOB_ID`; a duplicate tick is harmless (the second
#: pass finds nothing, or publishes what is still there).
OUTBOX_SWEEP_JOB_ID = "0368679c-144a-40ed-9ba0-ac4322aebe63"
OUTBOX_SWEEP_MESSAGE = {"v": 1, "job_id": OUTBOX_SWEEP_JOB_ID, "kind": "outbox_sweep"}

#: Two retries inside four minutes, so a retried tick never overlaps the next one; a dropped
#: tick is counted by the same group-wide `sweep-dropped` alarm.
OUTBOX_SWEEP_MAX_EVENT_AGE = Duration.minutes(4)

#: The api task's variables that the worker takes **verbatim** — read off
#: `ComputeStack._api_environment()` rather than retyped, so the worker can never be
#: pointed at another database, bucket, key or mailbox than the api. Deliberately absent:
#: `PORT` and `FORWARDED_ALLOW_IPS` (nothing listens), every `COGNITO_*` and
#: `AUTH_ACCEPT_SUPABASE_TOKENS` (the worker authenticates nobody; `AUTH_BACKEND` is still
#: passed because `src/settings.py` refuses to start with any backend switch unset, and a
#: handler that ever reached `use_cognito_auth()` would then raise rather than be handed
#: the web client's secret), and the webhook variables (the webhook sender is its own
#: Lambda).
WORKER_ENV_FROM_API = (
    "APP_ENV",
    "FLASK_ENV",
    "DATABASE_BACKEND",
    "STORAGE_BACKEND",
    "AUTH_BACKEND",
    "EMAIL_BACKEND",
    "PGHOST",
    "PGPORT",
    "PGDATABASE",
    "PGUSER",
    "PGSSLMODE",
    "PG_SSLROOTCERT",
    "MERIDIAN_S3_ARTIFACTS_BUCKET",
    "MERIDIAN_S3_PHI_BUCKET",
    "MERIDIAN_S3_KMS_KEY_ARN",
    "MERIDIAN_S3_PHI_KMS_KEY_ARN",
    "MERIDIAN_SES_FROM_EMAIL",
    "MERIDIAN_SES_CONFIGURATION_SET",
    # Only present on `-c emailBackend=resend`; copied when it is.
    "RESEND_FROM_EMAIL",
    # ADR 0050: the app origin every link in a message the worker sends points at.
    "PUBLIC_APP_URL",
    # ADR 0044: the key the QuickBooks tokens are sealed under (the qbo_push job reads them).
    "QBO_TOKEN_KMS_KEY_ARN",
    # M-10: which Intuit environment the push talks to. The redirect URI is not copied:
    # the worker never starts an OAuth flow.
    "QBO_ENVIRONMENT",
    # Critic Stage 1 round 2 M1: set on the api only with `-c enableApiPlatform=true`
    # (`ComputeStack._api_platform_environment`), so copied only then. It tells the worker
    # the webhook platform is deployed, and `src/webhooks/ports.check_worker_configuration`
    # then refuses to start without `WEBHOOK_EVENT_BUS` and `WEBHOOK_QUEUE_URL`.
    "MERIDIAN_API_V3",
)


#: `src/settings.JOBS_QUEUE_URL_ENV` / `JOBS_DLQ_URL_ENV`.
JOBS_QUEUE_URL_ENV = "MERIDIAN_JOBS_QUEUE_URL"
JOBS_DLQ_URL_ENV = "MERIDIAN_JOBS_DLQ_URL"

#: Output subfolders a processor writes, by bucket (`src/storage.BUCKET_BY_SUBFOLDER`).
#: Keys are `{org}/{batch}/{subfolder}/{file}`.
OUTPUT_SUBFOLDERS = {
    "artifacts": ("journal_entries",),
    "phi": ("data", "reports", "bundle"),
}

#: The fixed log line `workers/sweep.run_sweep_job` writes after every successful sweep.
#: The `sweep-stalled` alarm counts it; a test reads `workers/sweep.py` for the literal.
SWEEP_DONE_MESSAGE = "sweep done"
SWEEP_DONE_METRIC = "WorkerSweepsCompleted"


def jobs_queue_name(env: str) -> str:
    """`meridian-<env>-sqs-jobs`."""
    return resource_name(env, "sqs", "jobs")


def jobs_dlq_name(env: str) -> str:
    """`meridian-<env>-sqs-jobs-dlq`."""
    return resource_name(env, "sqs", "jobs-dlq")


def worker_schedule_group_name(env: str) -> str:
    """`meridian-<env>-schedule-worker`: the group `AWS/Scheduler` metrics are cut by."""
    return resource_name(env, "schedule", "worker")


class JobWorker(Construct):
    """The job queue, its DLQ, the sweep schedule and the worker service. See the module."""

    def __init__(self, scope: Construct, construct_id: str, *, compute: ComputeStack) -> None:
        super().__init__(scope, construct_id)
        self.compute = compute
        env = compute.env_name
        self.env_name = env
        self.transient = compute.env_config.destroyed_between_phases
        self._removal = RemovalPolicy.DESTROY if self.transient else RemovalPolicy.RETAIN
        self.data = compute.data
        self.queue_key = self.data.keys["phi"]

        self.dlq, self.queue = self._queues()
        self.schedule_group, self.sweep_schedule = self._sweep_schedule()
        self.outbox_sweep_schedule = (
            self._outbox_sweep_schedule() if api_platform_enabled(compute) else None
        )
        self.log_group = self._log_group()
        self.task_role = self._task_role()
        self.task_definition = self._task_definition()
        self.service = self._service()
        self._api_may_enqueue()
        self._token_key_grants()
        self._outputs()

    # ------------------------------------------------------------- queues
    def _queues(self) -> tuple[sqs.Queue, sqs.Queue]:
        dlq = sqs.Queue(
            self,
            "JobsDlq",
            queue_name=jobs_dlq_name(self.env_name),
            encryption=sqs.QueueEncryption.KMS,
            encryption_master_key=self.queue_key,
            enforce_ssl=True,
            retention_period=JOBS_DLQ_RETENTION,
            removal_policy=self._removal,
        )
        queue = sqs.Queue(
            self,
            "JobsQueue",
            queue_name=jobs_queue_name(self.env_name),
            encryption=sqs.QueueEncryption.KMS,
            encryption_master_key=self.queue_key,
            enforce_ssl=True,
            visibility_timeout=JOBS_VISIBILITY_TIMEOUT,
            receive_message_wait_time=JOBS_RECEIVE_WAIT,
            retention_period=JOBS_RETENTION,
            dead_letter_queue=sqs.DeadLetterQueue(queue=dlq, max_receive_count=JOBS_MAX_RECEIVES),
            removal_policy=self._removal,
        )
        for q in (dlq, queue):
            Tags.of(q).add("DataClassification", "phi")
        return dlq, queue

    def _queue_kms(self, sid: str) -> iam.PolicyStatement:
        """Encrypt/decrypt job messages with the queue's CMK, through SQS only."""
        return iam.PolicyStatement(
            sid=sid,
            actions=["kms:GenerateDataKey", "kms:Decrypt"],
            resources=[self.queue_key.key_arn],
            conditions={"StringEquals": {"kms:ViaService": f"sqs.{Aws.REGION}.amazonaws.com"}},
        )

    # ------------------------------------------------------------ sweeper
    def _sweep_schedule(self) -> tuple[scheduler.CfnScheduleGroup, scheduler.CfnSchedule]:
        """Every 15 minutes, the D5 `sweep` message onto the job queue.

        **Its own schedule group**, because `AWS/Scheduler` publishes per group and not per
        schedule: without one, a dropped sweep would be counted together with every other
        schedule in the default group (the idle-client sweep's, the other owner's). A group
        costs nothing and carries the six tags; a schedule cannot carry tags at all.

        The role may send to this queue and encrypt with its key, nothing else; its trust
        is pinned to this account and this schedule group (the confused-deputy conditions
        AWS documents for Scheduler).
        """
        env = self.env_name
        group_name = worker_schedule_group_name(env)
        group = scheduler.CfnScheduleGroup(self, "ScheduleGroup", name=group_name)
        group_arn = self.compute.format_arn(
            service="scheduler", resource="schedule-group", resource_name=group_name
        )
        role = iam.Role(
            self,
            "SweepSchedulerRole",
            role_name=resource_name(env, "iam", "sweep-scheduler"),
            assumed_by=iam.ServicePrincipal(
                "scheduler.amazonaws.com",
                conditions={
                    "StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID},
                    "ArnEquals": {"aws:SourceArn": group_arn},
                },
            ),
            description="EventBridge Scheduler: send the run sweeper's tick to the job queue.",
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="SendTheSweepTick",
                actions=["sqs:SendMessage"],
                resources=[self.queue.queue_arn],
            )
        )
        role.add_to_policy(self._queue_kms("EncryptTheSweepTick"))
        self.sweep_scheduler_role = role
        schedule = scheduler.CfnSchedule(
            self,
            "SweepSchedule",
            name=resource_name(env, "schedule", "sweep-runs"),
            group_name=group.ref,
            description=(
                "Run sweeper (plan 3.5, D5): expire stale draft/needs_input runs, fail runs "
                "whose worker lease lapsed on the third attempt."
            ),
            schedule_expression=SWEEP_SCHEDULE,
            flexible_time_window=scheduler.CfnSchedule.FlexibleTimeWindowProperty(mode="OFF"),
            state="ENABLED",
            target=scheduler.CfnSchedule.TargetProperty(
                arn=self.queue.queue_arn,
                role_arn=role.role_arn,
                input=json.dumps(SWEEP_MESSAGE, separators=(",", ":")),
                retry_policy=scheduler.CfnSchedule.RetryPolicyProperty(
                    maximum_retry_attempts=SWEEP_RETRIES,
                    maximum_event_age_in_seconds=int(SWEEP_MAX_EVENT_AGE.to_seconds()),
                ),
            ),
        )
        return group, schedule

    def _outbox_sweep_schedule(self) -> scheduler.CfnSchedule:
        """Every 5 minutes, the D17 `outbox_sweep` tick onto the job queue.

        Only with the api platform on (the outbox is its webhooks' source). **The same group
        and the same role as the TTL sweep's**: the role may already send to this queue and
        nothing else, and its trust is pinned to this group, so the tick needs no new
        principal. The worker hands it to `workers.outbox_sweep.run_outbox_sweep_job`.
        """
        return scheduler.CfnSchedule(
            self,
            "OutboxSweepSchedule",
            name=resource_name(self.env_name, "schedule", "outbox-sweep"),
            group_name=self.schedule_group.ref,
            description=(
                "Webhook outbox sweep (T19, D17): the worker re-publishes run events a failed "
                "after-commit publish left."
            ),
            schedule_expression=OUTBOX_SWEEP_SCHEDULE,
            flexible_time_window=scheduler.CfnSchedule.FlexibleTimeWindowProperty(mode="OFF"),
            state="ENABLED",
            target=scheduler.CfnSchedule.TargetProperty(
                arn=self.queue.queue_arn,
                role_arn=self.sweep_scheduler_role.role_arn,
                input=json.dumps(OUTBOX_SWEEP_MESSAGE, separators=(",", ":")),
                retry_policy=scheduler.CfnSchedule.RetryPolicyProperty(
                    maximum_retry_attempts=SWEEP_RETRIES,
                    maximum_event_age_in_seconds=int(OUTBOX_SWEEP_MAX_EVENT_AGE.to_seconds()),
                ),
            ),
        )

    # ---------------------------------------------------------------- logs
    def _log_group(self) -> logs.LogGroup:
        """`/meridian/<env>/ecs/worker`, on the `logs` CMK, 400 days — like the api's.

        The name is inside `/meridian/<env>/*`, which is what the `logs` key policy admits
        (`meridian/log_groups.py`). The worker logs ids and codes only (`workers/`), and the
        same `lint_no_phi_logging.py` gate covers it.
        """
        return logs.LogGroup(
            self,
            "LogGroup",
            log_group_name=f"/meridian/{self.env_name}/ecs/{WORKER}",
            retention=LOG_RETENTION,
            encryption_key=self.data.keys["logs"],
            removal_policy=self._removal,
        )

    # --------------------------------------------------------------- role
    def _task_role(self) -> iam.Role:
        """The worker's own permissions. See the module docstring for the whole list."""
        # Deferred, as every `.compute` import in this module is: `compute` imports this
        # module from inside its flag-gated method, so a top-level import would be circular.
        from .compute import _allow_ses_send

        compute = self.compute
        phi = self.data.buckets["phi"]
        artifacts = self.data.buckets["artifacts"]
        role = iam.Role(
            self,
            "TaskRole",
            role_name=resource_name(self.env_name, "iam", "ecs-worker-task"),
            assumed_by=iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            description=f"Meridian {self.env_name}: the job worker's own permissions.",
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ConsumeJobs",
                actions=[
                    "sqs:ReceiveMessage",
                    "sqs:DeleteMessage",
                    "sqs:ChangeMessageVisibility",
                ],
                resources=[self.queue.queue_arn],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="DeadLetterRefusedJobs",
                actions=["sqs:SendMessage"],
                resources=[self.dlq.queue_arn],
            )
        )
        role.add_to_policy(self._queue_kms("JobMessagesThroughSqs"))
        # `GetObject` + `GetObjectVersion` because every read names a VersionId;
        # `GetObjectTagging` + `GetObjectVersionTagging` because the GuardDuty verdict is
        # read for that exact version (`src/process_inputs.S3InputStore.scan_status`).
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadRunUploads",
                actions=[
                    "s3:GetObject",
                    "s3:GetObjectVersion",
                    "s3:GetObjectTagging",
                    "s3:GetObjectVersionTagging",
                ],
                resources=[phi.arn_for_objects("*/*/uploads/*")],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadWriteRunState",
                actions=["s3:PutObject", "s3:GetObject", "s3:GetObjectVersion"],
                resources=[phi.arn_for_objects("*/*/state/*")],
            )
        )
        outputs = [
            bucket.arn_for_objects(f"*/*/{subfolder}/*")
            for role_name, bucket in (("artifacts", artifacts), ("phi", phi))
            for subfolder in OUTPUT_SUBFOLDERS[role_name]
        ]
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadWriteProcessOutputs",
                actions=["s3:PutObject", "s3:GetObject", "s3:GetObjectVersion"],
                resources=outputs,
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="BucketKeysThroughS3",
                actions=["kms:GenerateDataKey", "kms:Decrypt"],
                resources=[self.data.keys["phi"].key_arn, self.data.keys["artifacts"].key_arn],
                conditions={"StringEquals": {"kms:ViaService": f"s3.{Aws.REGION}.amazonaws.com"}},
            )
        )
        # The completion notice the processors send (`email_service.send_processing_complete`),
        # scoped exactly as the api's is: one identity, one configuration set, one From.
        _allow_ses_send(
            role,
            compute,
            compute.ses_identity_name,
            compute.ses_configuration_set_name,
            compute.ses_from_address,
            compute.ses_region,
        )
        # Phase 12 T19, only with `-c enableApiPlatform=true` as well: the worker's settle
        # publishes the run's `api_events` row after commit (`src/webhooks/outbox.py`), so it
        # may `PutEvents` on the one bus the `api` stack creates — by ARN composed from the
        # shared name, because `api` imports from this stack and not the other way round.
        if api_platform_enabled(compute):
            role.add_to_policy(
                iam.PolicyStatement(
                    sid="PublishRunEvents",
                    actions=["events:PutEvents"],
                    resources=[self.event_bus_arn()],
                )
            )
            # Critic Stage 1 M-8: the same 5-minute outbox tick re-enqueues webhook
            # deliveries whose delayed message was lost (`engine.sweep_due_deliveries`).
            # SendMessage on the webhook queue only — never receive, never the DLQ — and
            # the queue's `logs` CMK through SQS only.
            role.add_to_policy(
                iam.PolicyStatement(
                    sid="RequeueStalledWebhookDeliveries",
                    actions=["sqs:SendMessage"],
                    resources=[self.webhook_queue_arn()],
                )
            )
            role.add_to_policy(
                iam.PolicyStatement(
                    sid="WebhookMessagesThroughSqs",
                    actions=["kms:GenerateDataKey", "kms:Decrypt"],
                    resources=[self.data.keys["logs"].key_arn],
                    conditions={
                        "StringEquals": {"kms:ViaService": f"sqs.{Aws.REGION}.amazonaws.com"}
                    },
                )
            )
        # It reads the bucket that holds the patients, like the api task role.
        Tags.of(role).add("DataClassification", "phi")
        return role

    def event_bus_arn(self) -> str:
        """`meridian-<env>-events-api`'s ARN, composed from its name (`api_platform.py`)."""
        return self.compute.format_arn(
            service="events", resource="event-bus", resource_name=event_bus_name(self.env_name)
        )

    def webhook_queue_arn(self) -> str:
        """`meridian-<env>-sqs-webhooks`'s ARN, composed from its name (`api_platform.py`)."""
        return self.compute.format_arn(
            service="sqs",
            resource=webhook_queue_name(self.env_name),
            arn_format=ArnFormat.NO_RESOURCE_NAME,
        )

    # ------------------------------------------------------ task definition
    def _task_definition(self) -> ecs.FargateTaskDefinition:
        """The api image, the worker command, the api's database/storage/mail settings.

        **The execution role is the api's** (`meridian-<env>-iam-ecs-execution`): it already
        pulls this repository and resolves `PGPASSWORD` from `meridian-<env>-secret-db-app`,
        which is the worker's credential too (see the module docstring). CDK adds this log
        group to its log-write statement. The worker's container maps only `PGPASSWORD`, the
        QuickBooks OAuth client (`QBO_CLIENT_ID`/`QBO_CLIENT_SECRET`, M-10: the push refreshes
        tokens) and `RESEND_API_KEY` on the rollback — never `COGNITO_CLIENT_SECRET`.
        """
        from .compute import API, STOP_TIMEOUT

        compute = self.compute
        task_definition = ecs.FargateTaskDefinition(
            self,
            "TaskDefinition",
            family=resource_name(self.env_name, "ecs", WORKER),
            cpu=WORKER_CPU,
            memory_limit_mib=WORKER_MEMORY_MIB,
            execution_role=compute.execution_role,
            task_role=self.task_role,
            runtime_platform=ecs.RuntimePlatform(
                cpu_architecture=ecs.CpuArchitecture.ARM64,
                operating_system_family=ecs.OperatingSystemFamily.LINUX,
            ),
        )
        api_environment = compute._api_environment()
        environment = {
            name: api_environment[name] for name in WORKER_ENV_FROM_API if name in api_environment
        }
        if api_platform_enabled(compute):
            # T19: where the settle's after-commit publish goes (`outbox.get_publisher`).
            environment["WEBHOOK_EVENT_BUS"] = event_bus_name(self.env_name)
            # Critic Stage 1 M-8: where the outbox tick re-enqueues stalled deliveries
            # (`ports.webhook_queue_from_env`). Composed from the name, like the api's.
            environment["WEBHOOK_QUEUE_URL"] = queue_url(webhook_queue_name(self.env_name))
        environment.update(
            {
                # boto3 needs it and `workers/main.py` reads it by name; Fargate injects it
                # too, but a worker that depends on an injected variable is one platform
                # change from a KeyError at start.
                "AWS_REGION": Aws.REGION,
                JOBS_QUEUE_URL_ENV: self.queue.queue_url,
                JOBS_DLQ_URL_ENV: self.dlq.queue_url,
            }
        )
        secrets = {"PGPASSWORD": ecs.Secret.from_secrets_manager(compute.db_app_secret, "password")}
        if compute.resend_api_key is not None:
            secrets["RESEND_API_KEY"] = ecs.Secret.from_secrets_manager(compute.resend_api_key)
        # M-10: the push refreshes QuickBooks tokens, which needs the OAuth client.
        secrets.update(compute.qbo_secrets())
        task_definition.add_container(
            WORKER,
            container_name=WORKER,
            # The SAME repository and the SAME tag as the api container: one build, one
            # scan, one sha (plan §7.1, D6).
            image=ecs.ContainerImage.from_ecr_repository(
                compute.repositories[API], compute.image_tags[API]
            ),
            command=list(WORKER_COMMAND),
            # SIGTERM → the worker stops receiving, releases the lease of the job it is
            # running and makes its message visible at once (`workers/main.py`); two
            # minutes, then SIGKILL.
            stop_timeout=STOP_TIMEOUT,
            logging=ecs.LogDriver.aws_logs(stream_prefix=WORKER, log_group=self.log_group),
            environment=environment,
            secrets=secrets,
        )
        return task_definition

    # ------------------------------------------------------------ service
    def _service(self) -> ecs.FargateService:
        """One task, no load balancer, rolling deploys (100/200) with the circuit breaker.

        Rolling, unlike the api's stop-then-start: two workers for the length of a deploy are
        safe, because a run is claimed by lease (ADR 0030) and the old task releases its
        lease on SIGTERM. Private-app subnets, the `app` security group — the group the
        database admits on 5432 and whose egress reaches SQS, S3 and SES; its only ingress is
        the ALB on the api and web ports, and nothing in this container listens.
        """
        compute = self.compute
        return ecs.FargateService(
            self,
            "Service",
            service_name=resource_name(self.env_name, "ecs", f"svc-{WORKER}"),
            cluster=compute.cluster,
            task_definition=self.task_definition,
            desired_count=WORKER_DESIRED_COUNT,
            assign_public_ip=False,
            vpc_subnets=ec2.SubnetSelection(subnet_group_name=SUBNET_APP),
            security_groups=[compute.app_sg],
            min_healthy_percent=100,
            max_healthy_percent=200,
            circuit_breaker=ecs.DeploymentCircuitBreaker(enable=True, rollback=True),
            enable_execute_command=False,
            enable_ecs_managed_tags=True,
            propagate_tags=ecs.PropagatedTagSource.SERVICE,
        )

    # ------------------------------------------------------------ the api
    def _api_may_enqueue(self) -> None:
        """Plan §3.8: the api task role gains `sqs:SendMessage` on the job queue — only.

        Not the DLQ: only the worker dead-letters. The queue URLs reach the api's
        environment from `ComputeStack._api_environment`, composed from the same names.
        """
        role = self.compute.api_task_role
        role.add_to_policy(
            iam.PolicyStatement(
                sid="EnqueueJobs",
                actions=["sqs:SendMessage"],
                resources=[self.queue.queue_arn],
            )
        )
        role.add_to_policy(self._queue_kms("EncryptJobMessagesThroughSqs"))

    # ------------------------------------------------------- QuickBooks tokens
    def _token_key_grants(self) -> None:
        """ADR 0044: the worker (the qbo_push job's refresh) may make and unwrap
        QuickBooks-token data keys — on `meridian-<env>-kms-tokens` only, and only with
        `purpose=qbo-token` in the encryption context, so the grant cannot be spent on
        anything the application does not seal as a token. The api task role holds the
        same statement independently of this flag (`ComputeStack._api_task_role`, T:186).

        Direct KMS use, not `kms:ViaService`: the application calls KMS itself (envelope
        encryption), no AWS service does it on the role's behalf.
        """
        self.task_role.add_to_policy(
            iam.PolicyStatement(
                sid="SealQboTokens",
                actions=list(QBO_TOKEN_KMS_ACTIONS),
                resources=[self.data.token_key.key_arn],
                conditions={
                    "StringEquals": {"kms:EncryptionContext:purpose": QBO_TOKEN_KMS_PURPOSE}
                },
            )
        )

    # ------------------------------------------------------------ outputs
    def _outputs(self) -> None:
        CfnOutput(
            self,
            "JobsQueueUrl",
            value=self.queue.queue_url,
            description="The job queue (MERIDIAN_JOBS_QUEUE_URL).",
        )
        CfnOutput(
            self,
            "JobsDlqUrl",
            value=self.dlq.queue_url,
            description="Refused and exhausted jobs (docs/runbooks/alerts.md, Job DLQ).",
        )
        CfnOutput(
            self,
            "ServiceName",
            value=self.service.service_name,
            description="worker ECS service - `update-service --force-new-deployment`.",
        )
