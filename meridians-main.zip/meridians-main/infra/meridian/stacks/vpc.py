"""`meridian-<env>-vpc` — the persistent half of the network: VPC, subnets, SGs, endpoints.

**This stack is never destroyed.** It is the other half of the Phase 3 split described in
ADR 0020: what used to be one `meridian-<env>-network` stack is now

* `meridian-<env>-vpc`  — **persistent**, and costs **$0/month**: a VPC, six subnets, an
  internet gateway, two free gateway endpoints and four security groups. None of those is
  billed by the hour.
* `meridian-<env>-edge` — **transient**, and holds every hourly charge: the NAT gateway,
  the ALB, CloudFront, the WAF, the VPC flow log and the ops instance. Staging destroys it
  at the end of every session (ADR 0008 / D-15).

**Why the split had to happen in Phase 3.** The `data` stack now holds the RDS instance,
and an RDS instance needs subnets and a security group. The `data` stack must survive a
staging teardown (D-15: "the `data` stack stays with RDS stopped"), so whatever it depends
on must survive too — a CloudFormation export cannot outlive its producer. Before the
split, everything network lived in a stack staging destroys every session, so `data` could
not depend on it without making the database transient as well. Splitting the free,
durable part out is what lets `data` depend on the network and still persist.

The dependency direction is therefore::

    vpc  ←  data  (keys, secret, RDS, buckets, backup)
     ↑        ↑
     └──── edge  (NAT, ALB, CloudFront, WAF, flow logs, ops)

`edge` is the only consumer that is ever destroyed, and it is a consumer of both — so a
`cdk destroy` of `edge` can never reach the VPC or the database. ADR 0020 §2 has the
alternatives that were rejected.

**The NAT gateway is not here**, and that is the one piece of subtlety in this file. CDK's
`Vpc` construct creates the NAT gateway *and* the private subnets' default routes together
and refuses `nat_gateways=0` alongside a `PRIVATE_WITH_EGRESS` tier. So the persistent VPC
declares **every** private tier as `PRIVATE_ISOLATED` — which is exactly "a subnet with a
route table and no routes in it" — and the `edge` stack adds the NAT gateway plus one
`CfnRoute` per `private-app` route table on top. `private-data` never gets a route, in
either stack: the database has no business reaching the internet, so it cannot.

**What this stack must never do** (ADR 0001): peer with, route through, or reference the
other owner's VPC or the default VPC where the trial instance lives. There is no
`from_lookup` anywhere in this file, for that reason and because a lookup would break the
credential-free `cdk synth` CI depends on.
"""

from __future__ import annotations

from typing import Any

from aws_cdk import CfnOutput
from aws_cdk import aws_ec2 as ec2
from constructs import Construct

from ..config import EnvConfig, api_platform_enabled
from ..naming import resource_name
from .base import EnvStack

#: One /16 per environment, deliberately non-overlapping. Nothing peers today
#: (ADR 0001 forbids it), but overlapping ranges are the one mistake that cannot
#: be undone later without renumbering a live VPC.
VPC_CIDR: dict[str, str] = {
    "staging": "10.20.0.0/16",
    "production": "10.30.0.0/16",
}

#: The three subnet tiers.
#:
#: `private-data` is isolated in the real sense — no route to anything, ever, in either
#: stack. `private-app` is *declared* isolated here and becomes routable when `edge` adds
#: the NAT gateway and the default route; see this module's docstring. The tier names are
#: the contract between the two stacks: every subnet selection in `edge`, `compute` and
#: `api` is `SubnetSelection(subnet_group_name=...)` against one of these three strings,
#: never `SubnetType`, precisely because the type of `private-app` is an implementation
#: detail of how the NAT gets built.
SUBNET_PUBLIC = "public"
SUBNET_APP = "private-app"
SUBNET_DATA = "private-data"

#: Container ports. The `web` task is Next.js standalone, the `api` task is
#: Flask/FastAPI behind the same ALB (plan §2.5). Phase 5a attaches the services;
#: the security-group rules exist now.
WEB_PORT = 3000
API_PORT = 8000

#: PostgreSQL. The only port the `data` security group admits, from exactly two sources.
POSTGRES_PORT = 5432

#: `com.amazonaws.global.cloudfront.origin-facing`. AWS publishes it per region and
#: the id is *not* a secret, but it is an identifier, and `PrefixList.from_lookup`
#: would need credentials at synth time — which CI does not have and must not need.
#: So it is context, with a placeholder that is deliberately **not** a usable id:
#: deploying without `-c cloudfrontPrefixListId=...` fails in CloudFormation rather
#: than silently opening the load balancer. Look it up once per account with:
#:
#:   aws ec2 describe-managed-prefix-lists --region us-east-1 \
#:     --filters Name=prefix-list-name,Values=com.amazonaws.global.cloudfront.origin-facing \
#:     --query 'PrefixLists[0].PrefixListId' --output text
PLACEHOLDER_PREFIX_LIST_ID = "pl-fffffffffffffffff"


class VpcStack(EnvStack):
    """The environment's VPC, subnets, gateway endpoints and four security groups.

    Everything in here is free and everything in here persists. If a resource in this
    file ever starts costing money by the hour, it belongs in `edge` instead — that is
    the whole rule the split encodes.
    """

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_config: EnvConfig,
        **kwargs: Any,
    ) -> None:
        super().__init__(scope, construct_id, env_config=env_config, **kwargs)

        self.prefix_list_id = str(
            self.node.try_get_context("cloudfrontPrefixListId") or PLACEHOLDER_PREFIX_LIST_ID
        )

        self.vpc = self._vpc()
        self._gateway_endpoints()
        self._security_groups()
        #: Phase 12 T21, behind `-c enableApiPlatform=true` (default off).
        self.webhook_sender_sg: ec2.SecurityGroup | None = (
            self._webhook_sender_security_group() if api_platform_enabled(self) else None
        )
        self._outputs()

    # ------------------------------------------------------------------ network

    def _vpc(self) -> ec2.Vpc:
        """Two AZs, three subnet tiers, **no NAT gateway in this stack**.

        `nat_gateways=0` is not "no NAT" — `edge` builds one. It is "no NAT *here*",
        because a NAT gateway is $37.50/month of standing charge and this stack is the
        one that never goes away. ADR 0018 §1 already decided there is exactly one NAT
        rather than one per AZ; ADR 0020 decides which stack owns it.

        The consequence is the `PRIVATE_ISOLATED` type on `private-app`: CDK's `Vpc`
        refuses `nat_gateways=0` when any tier is `PRIVATE_WITH_EGRESS`, because the
        construct creates the gateway and the default routes as one unit. An isolated
        subnet is the same subnet with an empty route table, and `edge` fills it in.
        """
        return ec2.Vpc(
            self,
            "Vpc",
            vpc_name=resource_name(self.env_name, "vpc", "main"),
            ip_addresses=ec2.IpAddresses.cidr(VPC_CIDR[self.env_name]),
            max_azs=2,
            # See the docstring: the NAT lives in `edge`.
            nat_gateways=0,
            enable_dns_hostnames=True,
            enable_dns_support=True,
            # Strips every rule from the VPC's default security group, which is
            # otherwise a usable, unnamed, unreviewed path into the VPC.
            #
            # **M-2, stated so nobody rediscovers it as a finding.** CDK implements
            # this with a helper custom resource (`Custom::VpcRestrictDefaultSG`),
            # which is a Lambda, and a Lambda creates its log group *implicitly* on
            # first invocation: AWS's default settings, never-expire retention and no
            # customer-managed key, with no construct property to override either.
            #
            # The exception is accepted rather than worked around. The alternative to
            # the helper is *not* an explicit rule: the default security group cannot
            # be deleted and CloudFormation has no resource that removes rules from a
            # group it does not own, so refusing it means leaving the default group
            # open — strictly worse. The content is a handful of lines of CDK-internal
            # logging with no PHI in it.
            #
            # It is tracked: docs/migration-tracker.md carries a row, and Phase 6 closes
            # it with a CloudWatch **account-level** retention and encryption policy,
            # which reaches implicit log groups that no construct property can.
            restrict_default_security_group=True,
            subnet_configuration=[
                ec2.SubnetConfiguration(
                    name=SUBNET_PUBLIC,
                    subnet_type=ec2.SubnetType.PUBLIC,
                    cidr_mask=24,
                    # Only the load balancer and the NAT live here, and both get
                    # their addresses explicitly. Nothing else gets a public IP.
                    map_public_ip_on_launch=False,
                ),
                ec2.SubnetConfiguration(
                    name=SUBNET_APP,
                    # Isolated *in this stack*. `edge` adds the NAT route. See the
                    # module docstring — this is the load-bearing line of the split.
                    subnet_type=ec2.SubnetType.PRIVATE_ISOLATED,
                    cidr_mask=22,
                ),
                ec2.SubnetConfiguration(
                    name=SUBNET_DATA,
                    # Isolated, and stays isolated: no route to the NAT at all, in
                    # either stack. The database has no business reaching the
                    # internet, so it cannot.
                    subnet_type=ec2.SubnetType.PRIVATE_ISOLATED,
                    cidr_mask=24,
                ),
            ],
        )

    def _gateway_endpoints(self) -> None:
        """S3 and DynamoDB gateway endpoints — and nothing else. **D-19 / ADR 0009.**

        Gateway endpoints are free, which is also why they are in the persistent stack:
        there is nothing to save by tearing them down. Interface endpoints are
        $7.30/month *per AZ* plus $0.01/GB, and the usual reason to buy them — deleting
        the NAT — does not apply: Intuit QuickBooks, Google and Microsoft sign-in and
        the User Migration Lambda's target have no VPC endpoint, so the NAT stays
        either way.

        S3 still gets the private path for free, which matters twice over now: every
        PHI object travels over it, and so does every RDS backup that AWS Backup copies.
        """
        self.vpc.add_gateway_endpoint("S3Endpoint", service=ec2.GatewayVpcEndpointAwsService.S3)
        self.vpc.add_gateway_endpoint(
            "DynamoDbEndpoint", service=ec2.GatewayVpcEndpointAwsService.DYNAMODB
        )

    def _security_groups(self) -> None:
        """Four groups, each admitting exactly one named source. No CIDR ingress anywhere.

        * `alb`  — **443 only**, from CloudFront's managed prefix list only. Not
          `0.0.0.0/0`: the internet reaches the edge, never the origin. There is no
          :80 rule because there is no :80 listener (L-3).
        * `app`  — the `web` and `api` Fargate tasks: only from `alb`.
        * `data` — RDS: 5432 from `app` and from `ops`, nothing else.
        * `ops`  — the SSM instance: **zero ingress rules**. Session Manager is an
          outbound connection to the SSM service; an inbound rule would be a path
          that does not need to exist (plan §2.4, "no open ports").

        **All four live here, not in `edge`,** although only `data` is used by a
        persistent resource. A security group is free, and splitting them across the two
        stacks would mean the `alb` ↔ `app` rules referenced a group in another stack —
        a cross-stack export in both directions, which is the one thing that would make
        the teardown order fragile. Free and together beats clever and coupled.

        **Egress is narrowed too, where narrowing means something** (L-2). A security
        group is stateful, so egress rules do not affect replies to traffic the group
        already admitted; they constrain what the thing can *start*.

        * `alb`  — outbound only to `app` on 3000 and 8000. A load balancer has
          exactly two things to talk to.
        * `ops`  — outbound to 443 (Session Manager, and every AWS API it uses) and to
          `data` on 5432. Nothing else. It is a jump box.
        * `data` — `allow_all_outbound=False`, in a subnet with no route to anywhere.
        * `app`  — **keeps default (allow-all) egress, deliberately.** The application
          tasks call Intuit QuickBooks, Google and Microsoft sign-in, SES and a dozen
          AWS APIs, over 443, to addresses that change without notice. Writing a
          narrower list here would be a list that goes stale silently and fails as
          "QuickBooks stopped working"; egress filtering that means something needs a
          proxy, not a security group. **Trigger to revisit:** a control-matrix row
          requiring egress allow-listing, at which point the answer is an egress proxy
          and the cost is recorded as a control.
        """
        self.alb_sg = ec2.SecurityGroup(
            self,
            "AlbSecurityGroup",
            vpc=self.vpc,
            security_group_name=resource_name(self.env_name, "sg", "alb"),
            description="ALB: CloudFront origin-facing prefix list only, 443 only.",
            # Narrowed below to the two container ports. See the docstring.
            allow_all_outbound=False,
        )
        cloudfront_edge = ec2.Peer.prefix_list(self.prefix_list_id)
        # 443 and nothing else. There is no port-80 listener (L-3): the ONLY client
        # of this load balancer is CloudFront, the origin protocol policy is
        # `https-only`, and so no request ever arrives on :80. A listener that
        # redirects traffic which cannot exist is a door with no road to it — and it
        # is a door, because it is reachable by every CloudFront distribution in the
        # world (the prefix list is AWS's, not ours).
        self.alb_sg.add_ingress_rule(
            cloudfront_edge, ec2.Port.tcp(443), "CloudFront origin-facing edge locations"
        )

        self.app_sg = ec2.SecurityGroup(
            self,
            "AppSecurityGroup",
            vpc=self.vpc,
            security_group_name=resource_name(self.env_name, "sg", "app"),
            description="ECS api/web/worker tasks: only from the ALB.",
            allow_all_outbound=True,
        )
        self.app_sg.add_ingress_rule(self.alb_sg, ec2.Port.tcp(API_PORT), "ALB to the api task")
        self.app_sg.add_ingress_rule(self.alb_sg, ec2.Port.tcp(WEB_PORT), "ALB to the web task")

        self.ops_sg = ec2.SecurityGroup(
            self,
            "OpsSecurityGroup",
            vpc=self.vpc,
            security_group_name=resource_name(self.env_name, "sg", "ops"),
            description="SSM-managed ops instance. ZERO ingress rules, by design.",
            # Narrowed below to 443 and Postgres. See the docstring.
            allow_all_outbound=False,
        )

        self.data_sg = ec2.SecurityGroup(
            self,
            "DataSecurityGroup",
            vpc=self.vpc,
            security_group_name=resource_name(self.env_name, "sg", "data"),
            description="RDS PostgreSQL: from the app tasks and the ops instance only.",
            allow_all_outbound=False,
        )
        self.data_sg.add_ingress_rule(self.app_sg, ec2.Port.tcp(POSTGRES_PORT), "Application tasks")
        self.data_sg.add_ingress_rule(
            self.ops_sg,
            ec2.Port.tcp(POSTGRES_PORT),
            "SSM port-forwarding session (docs/runbooks/db-access.md)",
        )

        # --- egress (L-2) ---------------------------------------------------
        # Declared after every group exists, because these rules name each other.
        self.alb_sg.add_egress_rule(
            self.app_sg, ec2.Port.tcp(WEB_PORT), "ALB to the web task and nothing else"
        )
        self.alb_sg.add_egress_rule(
            self.app_sg, ec2.Port.tcp(API_PORT), "ALB to the api task and nothing else"
        )
        # Session Manager is an outbound HTTPS connection from the instance to the
        # SSM, SSM Messages and EC2 Messages endpoints. There are no VPC interface
        # endpoints for them (ADR 0009 — gateway endpoints only), so it goes out
        # through the NAT `edge` builds: 443 to anywhere, and nothing else. Without
        # this rule the instance is unreachable, not merely restricted.
        self.ops_sg.add_egress_rule(
            ec2.Peer.any_ipv4(),
            ec2.Port.tcp(443),
            "SSM Session Manager and the AWS APIs it uses. No interface endpoints exist.",
        )
        self.ops_sg.add_egress_rule(
            self.data_sg,
            ec2.Port.tcp(POSTGRES_PORT),
            "psql over an SSM port-forwarding session (docs/runbooks/db-access.md)",
        )

    def _webhook_sender_security_group(self) -> ec2.SecurityGroup:
        """The webhook sender Lambda's own group (ADR 0038, plan §3.7). Free.

        **Why its own group and not `app`.** The sender calls URLs a partner chose; the
        api and worker tasks read PHI and post to QuickBooks. Separate groups (and
        separate IAM roles) keep "talks to anyone on the internet" and "reads patient
        data" from ever being the same principal (plan R7).

        * **No ingress at all.** A Lambda is invoked through its API, never over the
          network.
        * **Egress: 443 to anywhere, and 5432 to the database group — nothing else.**
          443 is the partner endpoints (arbitrary public addresses, so no narrower rule
          is possible — the SSRF guard in `src/webhooks/ssrf.py` is the real control,
          and it refuses the VPC range itself) plus the AWS APIs the sender uses (SQS,
          Secrets Manager) through the NAT. 5432 is the delivery rows: the tenant
          re-check reads them on every attempt (ADR 0038 decision 3).

        It lives here rather than in `api` for the same reason every other group does:
        the database group's ingress rule names it, and both ends of a rule belong in
        one persistent stack.
        """
        sg = ec2.SecurityGroup(
            self,
            "WebhookSenderSecurityGroup",
            vpc=self.vpc,
            security_group_name=resource_name(self.env_name, "sg", "webhook-sender"),
            description="Webhook sender Lambda: 443 out and Postgres only. No ingress.",
            allow_all_outbound=False,
        )
        sg.add_egress_rule(
            ec2.Peer.any_ipv4(),
            ec2.Port.tcp(443),
            "Partner webhook endpoints and the AWS APIs, through the NAT",
        )
        sg.add_egress_rule(
            self.data_sg, ec2.Port.tcp(POSTGRES_PORT), "Delivery rows (tenant re-check)"
        )
        self.data_sg.add_ingress_rule(
            sg, ec2.Port.tcp(POSTGRES_PORT), "Webhook sender Lambda (Phase 12, ADR 0038)"
        )
        return sg

    # ------------------------------------------------------------------ outputs

    def _outputs(self) -> None:
        CfnOutput(
            self,
            "VpcId",
            value=self.vpc.vpc_id,
            description="The environment's VPC. Persistent — a staging teardown never touches it.",
        )
        CfnOutput(
            self,
            "DataSecurityGroupId",
            value=self.data_sg.security_group_id,
            description="The RDS security group. Consumed by meridian-<env>-data.",
        )
        CfnOutput(
            self,
            "PrivateDataSubnetIds",
            value=",".join(
                subnet.subnet_id
                for subnet in self.vpc.select_subnets(subnet_group_name=SUBNET_DATA).subnets
            ),
            description="Isolated subnets holding RDS. No route to anything, by design.",
        )
