"""`meridian-<env>-observability` — alarms, metric filters, dashboards, the canary.

Phase 6 (`docs/aws-migration-plan.md` "Phase 6 — Observability and audit", ADR 0024).
Nothing here serves traffic and nothing here holds data: this stack is the part of the
estate whose entire job is to notice.

**Everything pages one place: `meridian-<env>-sns-alerts`**, the topic the `data` stack
owns. It is in `data` rather than here on purpose — `data` is never destroyed (ADR 0020),
and an SNS subscription is confirmed once, by a human clicking a link in an email. A topic
re-created by a staging teardown would come back with that subscription unconfirmed and
nobody would be told. `data.py` owns the topic's whole resource policy and the matching
`logs` CMK grants, for **both** `cloudwatch.amazonaws.com` (alarm actions) and
`events.amazonaws.com` (the rule targets below), each conditioned on `aws:SourceAccount`
(ADR 0020 §7c, ADR 0024 §6). Without the key half the publish fails *inside SNS*, the alarm
still shows ALARM in the console, and nobody is paged.

**Alarms notify on ALARM only — no `ok_actions` (ADR 0024 §2a, reversed 2026-10-07).**
Staging's database starts on demand, and every start flipped each RDS alarm from
INSUFFICIENT_DATA to OK and emailed. Recovery is read on the dashboard.

**`treat_missing_data` is chosen per alarm and the choice is argued in a comment**, never
left to the CDK default. The rule applied throughout: a metric that is only published when
something *happens* (5xx counts, WAF blocks, Lambda errors) is `NOT_BREACHING` when absent
— no data means no errors. A metric that is published continuously while the thing is
alive (`HealthyHostCount`, RDS CPU, task count) is `BREACHING` when absent, because
"stopped publishing" is the outage. A metric on a resource that is *deliberately* stopped
some of the time — staging's RDS instance overnight (D-15) — is `MISSING`, which is
CloudWatch's "carry the previous state forward": a stopped database is not a page.

**Evaluation periods are sized so a deploy does not page.** An ECS rolling deployment with
the circuit breaker (ADR 0022) takes a few minutes and briefly halves capacity, so the
latency, 5xx and task-count alarms use `evaluation_periods` × `period` windows longer than
a rollout, with `datapoints_to_alarm` below `evaluation_periods` where the signal is spiky.

**No PHI, anywhere in this file.** A CloudWatch alarm description, a dashboard widget
title, a metric dimension and a metric-filter *pattern* are all readable by anyone with
`cloudwatch:Describe*`, and the retention on everything here is 400 days. The metric
filters below match on **structured JSON fields only** (`$.error.code`, `$.http.status`),
never on a free-text substring: a substring pattern is a standing invitation to match a
log line whose text happens to contain a person, and the value that matched is then
carried in the filter's own definition for as long as it exists.

## The log-format contract

`_log_metric_filters` assumes the api and web containers emit **one JSON object per line**
with these fields, and no others that matter here:

| Field | Meaning |
|---|---|
| `env` | `staging` or `production`. **The dimension every filter below publishes on.** |
| `event` | A fixed, enumerated event name — including `artifact_download`. Never interpolated text. |
| `level` | `INFO`, `WARNING`, `ERROR`. |
| `request_id` | `req_<32 hex>`, minted by `api/main.py`'s middleware. |
| `http.method`, `http.path`, `http.status` | The route as matched, never the raw URL (a path parameter can be an id). |
| `error.code` | The envelope code from `src/api/v2/errors.py` — `INTERNAL_ERROR`, `AUTH_REQUIRED`, … |
| `exception.type` | The bare class name of an unhandled exception: `PoolTimeout`, `PgWriteRefused`. |
| `duration_ms` | Integer. |

**`env` is not decoration.** `Meridian/App` is one namespace in one account, and both
environments write into it (ADR 0001). Without a dimension, staging's 5xx count and
production's are the *same metric*: a staging load test would raise the production alarm
and a production incident would be averaged away by staging's zeroes. Every filter below
therefore carries `dimensions={"Environment": "$.env"}`, and every alarm and dashboard
metric that reads one of them pins `Environment=<this env>`.

**A dimensioned metric filter cannot also have a `default_value`** — CloudWatch Logs
rejects the pair, because a default would have to invent a dimension value for a record
that did not match. So the metrics below have *no datapoints* until a matching line is
written, rather than a flat zero. The alarms on them are `NOT_BREACHING` on missing data, so that
reads as OK rather than as INSUFFICIENT_DATA; the dashboard header and the alarm
descriptions say in words that an empty graph is not evidence of health.

**Both containers now write that contract** (the note that said neither did, dated
2026-09-16, is superseded). The api installs `src/log_setup.JsonFormatter` at start
(`api/main.py`, `log_setup.configure_logging()`), and so does the Phase 11 worker
(`workers/main.py`); the web container's Next.js server writes the same shape from
`web/src/instrumentation.ts` (`web/src/lib/server-log.ts`, one `http_request` line per
request and an `unhandled_exception` line per caught error). **`env` comes from `APP_ENV`
in each task definition** — the web task sets it too (`compute.py`), without which every
web line said `development` and the web 5xx filter, read with this environment's name,
counted nothing. A field-based filter that is silent until a field is right is still the
deliberate choice over a free-text filter that works today and is a PHI hazard; ADR 0024 §4
carries the contract.

`audit.phi_access` gaps are **not expressible here at all**, and that is worth stating
rather than leaving as a hole. `src/phi.py` writes its two rows to a Postgres table and
logs nothing — "Nothing is logged here, not even the count." The auditor's question (an
opened row with no matching closed row) is a SQL query against `audit.phi_access`, not a
log pattern. What *is* expressible, and is built below, is the audit trail failing to be
written at all, which `src/phi.py` does log.

## What is deliberately not here

* **The account-wide security alarms** — CloudTrail drift, root usage, break-glass, IAM
  policy changes — belong to the account, not an environment, and are in `foundation.py`.
* **Shield Advanced.** $3,000/month; the prompt forbids it without asking.
* **CloudWatch anomaly detection and Contributor Insights.** Both are per-metric or
  per-rule monthly charges against ≈ $11 of headroom (`docs/reports/phase-1-cost-estimate.md`
  §3). Tracker rows, not resources — see ADR 0024 §7.

Staging's observability stack is destroyed between phases (ADR 0008 / D-15), which is why
the three account-scoped finding rules below exist only in production.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import jsii
from aws_cdk import (
    ArnFormat,
    Aws,
    CfnOutput,
    Duration,
    RemovalPolicy,
    Tags,
)
from aws_cdk import (
    aws_cloudwatch as cloudwatch,
)
from aws_cdk import (
    aws_cloudwatch_actions as cw_actions,
)
from aws_cdk import (
    aws_elasticloadbalancingv2 as elbv2,
)
from aws_cdk import (
    aws_events as events,
)
from aws_cdk import (
    aws_events_targets as events_targets,
)
from aws_cdk import (
    aws_iam as iam,
)
from aws_cdk import (
    aws_lambda as lambda_,
)
from aws_cdk import (
    aws_logs as logs,
)
from aws_cdk import (
    aws_pipes as pipes,
)
from aws_cdk import (
    aws_s3 as s3,
)
from aws_cdk import (
    aws_sns as sns,
)
from aws_cdk import (
    aws_synthetics as synthetics,
)
from aws_cdk.interfaces import (
    aws_events as events_interfaces,
)
from constructs import Construct

from .. import log_groups as log_group_names
from ..config import EnvConfig
from ..naming import resource_name
from .base import EnvStack
from .compute import API, API_DESIRED_COUNT, WEB, WEB_DESIRED_COUNT, ComputeStack
from .data import LOG_RETENTION, STOP_DLQ_ERROR_ATTRIBUTE, STOP_DLQ_EXPECTED_ERROR, DataStack
from .dns import SES_ENV_DIMENSION
from .edge import EdgeStack

# ---------------------------------------------------------------- metric namespaces

#: Where the log metric filters publish. A namespace of our own, so that a filter that
#: has started matching the wrong thing is visible next to the others rather than lost in
#: `AWS/*`.
APP_NAMESPACE = "Meridian/App"

#: The dimension key every `Meridian/App` metric carries. One account, two environments,
#: one namespace: without it staging and production publish into the *same* metric. The
#: value comes from the log record's `$.env` field on the filter side and from
#: `self.env_name` on the alarm and dashboard side, and the two have to agree.
ENVIRONMENT_DIMENSION = "Environment"

#: CloudFront publishes only into `us-east-1`, whatever the distribution is "in". The whole
#: estate is `us-east-1` (`base.py`), so this is documentation rather than a correction —
#: but it is stated because a future second region would break silently without it.
CLOUDFRONT_NAMESPACE = "AWS/CloudFront"
WAF_NAMESPACE = "AWS/WAFV2"
LAMBDA_NAMESPACE = "AWS/Lambda"
SES_NAMESPACE = "AWS/SES"

#: AWS's SES review thresholds (tracker T:39), as the fractions CloudWatch publishes.
SES_BOUNCE_RATE_THRESHOLD = 0.05
SES_COMPLAINT_RATE_THRESHOLD = 0.001

# ------------------------------------------------------------------------ thresholds

#: ALB p95 target response time, in seconds. The api does a revenue run synchronously
#: today; 2 s is the line above which a person notices, not the line above which the
#: server is unhealthy.
LATENCY_P95_SECONDS = 2.0

#: ALB-generated 5xx (the load balancer had nowhere to send the request) in a 5-minute
#: window. Five, not one: a single 502 during a task replacement is a rolling deploy.
ALB_5XX_THRESHOLD = 5

#: Target-generated 5xx in a 5-minute window. Higher than the ALB's, because this is the
#: application answering badly rather than not answering, and a burst of ten inside five
#: minutes is the smallest thing worth waking someone for.
TARGET_5XX_THRESHOLD = 10

#: ECS CPU and memory, percent. 85 leaves room to act before the task is throttled or
#: OOM-killed; the `api` task is 1 vCPU / 2 GB and has nowhere to burst to (ADR 0022).
ECS_CPU_THRESHOLD = 85
ECS_MEMORY_THRESHOLD = 85

#: RDS CPU, percent. A `t4g` burstable that sits above 80 for half an hour is spending
#: credits it will not have during the next period close.
RDS_CPU_THRESHOLD = 80

#: RDS free storage, in bytes. `max_allocated_storage` autoscales, but autoscaling has a
#: cooldown and a period close can fill faster than it; 4 GiB is roughly a day of headroom.
RDS_FREE_STORAGE_BYTES = 4 * 1024 * 1024 * 1024

#: RDS freeable memory, in bytes. Below ~200 MiB a `t4g.micro` starts evicting its page
#: cache and every query gets slower at once, which reads as "the app is broken".
RDS_FREEABLE_MEMORY_BYTES = 200 * 1024 * 1024

#: RDS read/write latency, in seconds. gp3 at this size should answer in single-digit
#: milliseconds; 50 ms sustained means contention, not a slow disk.
RDS_LATENCY_SECONDS = 0.05

#: PostgreSQL's default `max_connections` on RDS is
#: `LEAST({DBInstanceClassMemory/9531392}, 5000)`. Worked through for the two instance
#: classes the estate uses, so that the connection alarm is a fraction of the real ceiling
#: rather than a number somebody liked:
#:
#: * `t3.micro` — 1 GiB → 1073741824 / 9531392 = 112
#: * `t4g.small` — 2 GiB → 2147483648 / 9531392 = 225
#:
#: If `db_instance_type` gains a third class this map has to gain a row; `_max_connections`
#: raises rather than guessing, because a guessed ceiling produces an alarm that is either
#: permanently quiet or permanently loud.
MAX_CONNECTIONS = {"t3.micro": 112, "t4g.small": 225}

#: Alarm when connections pass this fraction of `max_connections`. The repository layer
#: pools (ADR 0022), so approaching the ceiling means leaked connections, not load.
CONNECTION_HEADROOM = 0.8

#: WAF blocked requests in five minutes. The WAF blocks a steady trickle of internet
#: background noise, so this is a *spike* threshold: 100 in five minutes is somebody
#: working through the rule set, not a scanner.
WAF_BLOCKED_SPIKE = 100

#: CloudFront 5xx error rate, percent of requests in five minutes.
CLOUDFRONT_5XX_PERCENT = 5.0

#: Artifact downloads in five minutes, per environment, before the export-volume alarm
#: fires — and it has to be *sustained* (three consecutive windows) rather than spiky,
#: because a period close legitimately pulls every journal-entry CSV at once. A hundred
#: downloads in five minutes, three times running, is three hundred files in a quarter of
#: an hour, which is a bulk extraction and not a close. CC6.7's "unusual export volume".
EXPORT_VOLUME_THRESHOLD = 100

#: Cognito allows a User Migration trigger **5 seconds** and then fails the sign-in. The
#: alarm is at 4 s on p99 so that it fires while there is still margin, not after people
#: have started being turned away. `MIGRATION_TIMEOUT` in `auth.py` is the hard stop.
LAMBDA_DURATION_BUDGET_MS = 4000

# -------------------------------------------------------------------------- canary

#: Every 5 minutes: ~8,640 runs/month at roughly $0.0012 per canary run, so **≈ $10.40 per
#: environment per month** — the single largest line this stack adds, and more than the
#: ≈ $11 of headroom the cost estimate has against the ~$250 ceiling
#: (`docs/reports/phase-1-cost-estimate.md` §3). **It is therefore a cost-approval item,
#: not a decision this stack makes**: the canary is behind `-c enableCanary=true` and is
#: off by default in both environments, with a tracker row and a steady-state table row
#: carrying the delta. Turning it on in production only is ≈ $10.40; both is ≈ $20.80.
CANARY_RATE = Duration.minutes(5)
CANARY_COST_PER_RUN_USD = 0.0012
CANARY_CONTEXT_FLAG = "enableCanary"

#: `-c structuredLogsLive=true`. **Off by default, and it arms one alarm: the heartbeat.**
#:
#: Every `Meridian/App` alarm is `NOT_BREACHING` on missing data, because the application
#: does not emit JSON logs yet and a page every five minutes for "no datapoints" would be
#: turned off within a day (tracker rows 46 and 53). The cost of that is the failure this
#: flag exists to close: if the formatter never ships — or ships, then regresses, or has
#: its field names changed — **every one of those alarms reads OK for ever** and the only
#: symptom is a dashboard of flat lines nobody is looking at.
#:
#: So one alarm watches the *pipeline* rather than the application, and it is the mirror
#: image of the others: it fires when the metric is ABSENT. It cannot be on by default,
#: because today absence is the expected state and it would page continuously. It is
#: turned on in the same change that deploys the formatter — that is the deadline on
#: tracker row 46 — and from then on it is what notices the pipeline going quiet again.
STRUCTURED_LOGS_CONTEXT_FLAG = "structuredLogsLive"

#: The window the heartbeat looks at. It watches `HttpRequests` — one datapoint per
#: `http_request` line, health checks included, so the ALB alone publishes one every
#: thirty seconds — and a day is kept so that a stopped staging task over a weekend
#: pages once, not every five minutes. It used to watch `FiveXxResponses`, which a
#: 5xx-free day left empty: a heartbeat that paged on good days (tracker T:138).
STRUCTURED_LOGS_HEARTBEAT_PERIOD = Duration.days(1)

#: `-c guardDutyDetectorId=<id>`. GuardDuty's `FindingCount` is per-detector and does not
#: exist without the `DetectorId` dimension; the detector belongs to the account, not to an
#: environment, and importing it from `meridian-shared-foundation` would make a
#: never-destroyed stack a dependency of one that is destroyed every session. Absent, the
#: dashboard omits the widget rather than drawing an empty one.
GUARD_DUTY_DETECTOR_CONTEXT = "guardDutyDetectorId"

#: Synthetics artifacts are screenshots and HAR files of a *health endpoint* — no session,
#: no identifier — but they go on the `logs` CMK like everything else this stack writes,
#: and they expire at 30 days. There is no reason to keep four hundred days of screenshots
#: of `{"status":"ok"}`, and a bucket with no lifecycle rule is a bucket that grows for ever.
CANARY_ARTIFACT_RETENTION = Duration.days(30)

#: `syn-nodejs-puppeteer-9.1` and older are deprecated by AWS on a rolling schedule; this is
#: the newest Node/Puppeteer runtime aws-cdk-lib 2.269.0 offers as a typed constant, which
#: is the version the estate is pinned to (`infra/requirements.txt`). A runtime is a
#: property of the canary and is changed by a deploy, not by AWS, so an unpinned "latest"
#: does not exist to choose.
CANARY_RUNTIME = synthetics.Runtime.SYNTHETICS_NODEJS_PUPPETEER_13_0

#: The path the ALB target group, CloudFront and the container's own `HEALTHCHECK` already
#: use (`api/routers/health.py`). Hitting anything else would test a different thing from
#: the one the load balancer believes.
HEALTH_PATH = "/api/v1/health"

# ------------------------------------------------------- the stop-schedule routing

#: The `source` the Pipe stamps on every event it puts on the bus. It must NOT start with
#: `aws.` — EventBridge reserves that prefix for AWS's own events and refuses a `PutEvents`
#: that claims it. Both rules below match on it, so a second producer on the same bus
#: cannot be mistaken for a stop-schedule failure.
STOP_EVENT_SOURCE = "meridian.stop-schedule"

#: The `detail-type` on the same events. It is what the CloudWatch Logs target writes as
#: the log line's `message` when the default target input is used, so it is written for a
#: human reading `aws logs filter-log-events`, not for a machine.
STOP_EVENT_DETAIL_TYPE = "Stop schedule dead letter"

#: 400 days and the `logs` CMK, like every other log group in the estate — the
#: stop-schedule log group is the evidence that a cost control ran, and the estate-wide
#: log-group audit in `infra/tests/test_observability.py` has no exception list.
STOP_SCHEDULE_LOG_RETENTION = logs.RetentionDays.THIRTEEN_MONTHS

# ------------------------------------------------ the two housekeeping Lambdas

#: The Lambda sources live at the repo root (`lambda/<name>/handler.py`), like the
#: user-migration and webhook-sender functions. Anchored on this file so synth and the
#: tests work from any working directory.
_REPO_ROOT = Path(__file__).resolve().parents[3]
LOG_GOVERNOR_SOURCE = _REPO_ROOT / "lambda" / "log_governor"
BACKUP_FRESHNESS_SOURCE = _REPO_ROOT / "lambda" / "backup_freshness"

#: How often the log-group governor sweeps (T:60/T:65). It also runs on every
#: `CreateLogGroup` CloudTrail event under its prefixes; the sweep is the backstop for
#: groups created while this (staging-transient) stack was not deployed.
LOG_GOVERNOR_RATE = Duration.hours(6)

#: The retention the governor gives an implicit group, in days: the estate's floor.
LOG_GOVERNOR_RETENTION_DAYS = 400

#: Backup freshness (T:160, Codex G-M1). The daily plan runs at 05:00 UTC with a 6-hour
#: completion window; 26 h is "yesterday's backup and then some" and 32 h leaves the
#: cross-region copy its own lag. The PITR edge normally trails by ~5 minutes; an hour
#: is ADR 0007's RPO.
BACKUP_FRESHNESS_RATE = Duration.hours(6)
BACKUP_NAMESPACE = "Meridian/Backup"
BACKUP_LOCAL_MAX_AGE_HOURS = 26
BACKUP_DR_MAX_AGE_HOURS = 32
RESTORABLE_MAX_LAG_HOURS = 1
#: The heartbeat window: a checker that ran four times a day and published nothing for a
#: whole day has stopped running (or raises before its last line).
BACKUP_HEARTBEAT_PERIOD = Duration.days(1)


def _flag_is_on(value: object) -> bool:
    """`-c <flag>=true|1|yes`, case-insensitively. Everything else — including absent — is off.

    Context values arrive as whatever the CLI or a test passed: a string from `-c`, a real
    `bool` from `App(context=...)`, or `None`. One reading of that, in one place, so two
    flags cannot disagree about what "true" means.
    """
    return str(value or "").lower() in ("1", "true", "yes")


@jsii.implements(events.IRuleTarget)
class _PlainRuleTarget:
    """An EventBridge rule target that is **only an ARN** — no generated side effects.

    The two `aws_events_targets` constructs this replaces each write something extra that
    is wrong for this estate, and in both cases the thing they write is a permission
    grant that this codebase wants to write itself, conditioned:

    * `CloudWatchLogGroup` writes the log group's resource policy through an
      `AwsCustomResource` — a Lambda, a role with `logs:PutResourcePolicy` on
      `Resource: "*"`, and an **implicit log group with no CMK and no retention**, which is
      exactly what this stack's estate-wide log-group audit exists to prevent.
      `AWS::Logs::ResourcePolicy` is a plain CloudFormation resource; the caller writes one.
    * `SnsTopic` appends an **unconditioned** `sns:Publish` for `events.amazonaws.com` to
      the topic's resource policy. An unconditioned Allow beside a conditioned one is not a
      confused-deputy guard — the permissive statement still applies — so the only way to
      make `aws:SourceAccount` mean anything on that topic is for nothing to write the
      statement without it. `data.py` owns the whole topic policy (ADR 0020 §7c).

    `target_resource` is still passed so that CDK orders the rule after the resource.
    """

    def __init__(self, resource: Any, *, arn: str) -> None:
        self._resource = resource
        self._arn = arn

    # `rule` and `id` are the jsii interface's own parameter names and cannot be renamed.
    def bind(
        self, rule: events_interfaces.IRuleRef, id: str | None = None
    ) -> events.RuleTargetConfig:
        return events.RuleTargetConfig(arn=self._arn, target_resource=self._resource)


class ObservabilityStack(EnvStack):
    """Alarms, log metric filters, dashboards, the stop-schedule routing and the canary."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        env_config: EnvConfig,
        data_stack: DataStack,
        edge_stack: EdgeStack,
        compute_stack: ComputeStack,
        **kwargs: Any,
    ) -> None:
        super().__init__(scope, construct_id, env_config=env_config, **kwargs)

        self.data = data_stack
        self.edge = edge_stack
        self.compute = compute_stack

        #: Everything publishes here. See the module docstring.
        self.topic: sns.ITopic = data_stack.alerts
        self._alarm_action = cw_actions.SnsAction(self.topic)

        #: Kept so that the tests can assert the count, and so that the dashboard can be
        #: built from the same objects the alarms use rather than a parallel list.
        self.alarms: list[cloudwatch.Alarm] = []

        self._alb_alarms()
        self._ecs_alarms()
        self._rds_alarms()
        self._edge_alarms()
        self._lambda_alarms()
        self._backup_alarms()
        self._secret_rotation_alarms()
        self._queue_alarms()
        # Phase 11 H2: only when `compute` was built with `-c worker_enabled=true`.
        if self.compute.worker is not None:
            self._worker_alarms()
        self._ses_alarms()
        self._account_finding_rules()
        #: T:60/T:65 — retention and the CMK for the implicit log groups.
        self.log_governor = self._log_group_governor()
        #: T:160 — production only (staging has no scheduled plan); None in staging.
        self.backup_freshness = self._backup_freshness()

        self.metric_filters = self._log_metric_filters()
        #: Set by `_stop_schedule_routing` in staging; all three stay `None` in production,
        #: which has no stop schedule and therefore no dead letters to route.
        self.stop_event_bus: events.EventBus | None = None
        self.stop_schedule_log_group: logs.LogGroup | None = None
        self.stop_dlq_pipe = self._stop_schedule_routing()
        self.canary = self._canary()

        self.dashboard = self._dashboard()
        self._outputs()

    # ------------------------------------------------------------------ helpers

    def _alarm(
        self,
        construct_id: str,
        *,
        purpose: str,
        metric: cloudwatch.IMetric,
        threshold: float,
        description: str,
        comparison: cloudwatch.ComparisonOperator = (
            cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD
        ),
        evaluation_periods: int = 3,
        datapoints_to_alarm: int | None = None,
        treat_missing_data: cloudwatch.TreatMissingData = (cloudwatch.TreatMissingData.MISSING),
    ) -> cloudwatch.Alarm:
        """One alarm, wired to the topic on **both** transitions.

        `purpose` is the last segment of `meridian-<env>-alarm-<purpose>`; `naming.py`
        rejects anything that is not lowercase-hyphenated, which is deliberate — an alarm
        name is what arrives in the email at 3am and it is the only identifier the reader
        gets.
        """
        alarm = cloudwatch.Alarm(
            self,
            construct_id,
            alarm_name=resource_name(self.env_name, "alarm", purpose),
            alarm_description=description,
            metric=metric,
            threshold=threshold,
            comparison_operator=comparison,
            evaluation_periods=evaluation_periods,
            datapoints_to_alarm=datapoints_to_alarm,
            treat_missing_data=treat_missing_data,
        )
        alarm.add_alarm_action(self._alarm_action)
        self.alarms.append(alarm)
        return alarm

    def _app_metric(
        self,
        metric_name: str,
        *,
        statistic: str = "Sum",
        period: Duration | None = None,
        label: str | None = None,
    ) -> cloudwatch.Metric:
        """A `Meridian/App` metric, pinned to **this** environment.

        Every read of a log-filter metric goes through here. The dimension is not optional
        and must match the filter's `dimensions={"Environment": "$.env"}` exactly: a
        dimension on the filter and no dimension on the alarm reads a metric that is never
        published, which is an alarm that can never fire and looks identical to one that
        never needed to.
        """
        return cloudwatch.Metric(
            namespace=APP_NAMESPACE,
            metric_name=metric_name,
            dimensions_map={ENVIRONMENT_DIMENSION: self.env_name},
            statistic=statistic,
            period=period,
            label=label,
        )

    def _event_rule_to_topic(
        self,
        construct_id: str,
        *,
        purpose: str,
        description: str,
        event_pattern: events.EventPattern,
        event_bus: events.IEventBus | None = None,
    ) -> events.Rule:
        """An EventBridge rule whose first target is the alerts topic.

        **Both permissions this needs are written in `data.py`, conditioned**: the topic
        policy's `sns:Publish` for `events.amazonaws.com` and the `logs` CMK's
        `kms:GenerateDataKey*`/`kms:Decrypt` for the same principal, each with
        `aws:SourceAccount` (ADR 0020 §7c). Neither is generated here, because the CDK
        construct that would generate the first one writes it **without** the condition —
        see `_PlainRuleTarget`. Without the key half the publish fails *inside SNS* and
        nobody is paged while the console shows a healthy alarm.

        `event_bus` is left `None` for the AWS-service rules, which must live on the
        default bus because that is where AWS delivers its own events. The stop-schedule
        rules pass our custom bus.
        """
        rule = events.Rule(
            self,
            construct_id,
            rule_name=resource_name(self.env_name, "rule", purpose),
            description=description,
            event_pattern=event_pattern,
            event_bus=event_bus,
        )
        # `_PlainRuleTarget`, not `events_targets.SnsTopic`: the construct would append an
        # UNCONDITIONED `sns:Publish` for `events.amazonaws.com` to the topic policy, and
        # an unconditioned Allow next to a conditioned one is not a guard. See `data.py`.
        rule.add_target(_PlainRuleTarget(self.topic, arn=self.topic.topic_arn))
        return rule

    # ---------------------------------------------------------------------- ALB

    def _alb_alarms(self) -> None:
        """The load balancer: is it answering, how fast, and is anything behind it.

        `HealthyHostCount` gets **two** alarms per target group and they are not
        redundant:

        * `< 1` — nothing is serving. The outage alarm.
        * `> 1` on the **api** target group — the plan's `HealthyHostCount > 1` line,
          which reads oddly until you know that `API_DESIRED_COUNT` is 1 *by design*
          until Phase 11 (ADR 0022). Two healthy api tasks means somebody scaled the
          service, and two api tasks can each pick up the same revenue run and book the
          same journal entry twice. It is a correctness alarm wearing a capacity alarm's
          clothes, and it is the reason the api service is pinned at one.

        Both are `BREACHING` on missing data: `HealthyHostCount` is published every minute
        for as long as the target group has any registered target, so silence is either
        the target group emptied or the ALB gone, and both are the outage.
        """
        alb = self.edge.alb

        self._alarm(
            "AlbFiveXx",
            purpose="alb-5xx",
            metric=alb.metrics.http_code_elb(
                elbv2.HttpCodeElb.ELB_5XX_COUNT,
                statistic="Sum",
                period=Duration.minutes(5),
            ),
            threshold=ALB_5XX_THRESHOLD,
            description=(
                "The load balancer itself returned 5xx: it had no healthy target, or the "
                "target closed the connection. Check the ECS service events first, then "
                "the api log group. Runbook: docs/runbooks/alerts.md."
            ),
            # Only published when a 5xx happens, so absence is health, not silence.
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            # 3 x 5 min, alarming on 2: longer than a rolling deploy, and one bad
            # five-minute window during a task replacement does not page.
            evaluation_periods=3,
            datapoints_to_alarm=2,
        )

        self._alarm(
            "TargetFiveXx",
            purpose="target-5xx",
            metric=alb.metrics.http_code_target(
                elbv2.HttpCodeTarget.TARGET_5XX_COUNT,
                statistic="Sum",
                period=Duration.minutes(5),
            ),
            threshold=TARGET_5XX_THRESHOLD,
            description=(
                "The application answered 5xx. This is the app failing, not the "
                "infrastructure: start at the api log group's unhandled-exception filter "
                "and the request ids it counted."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=3,
            datapoints_to_alarm=2,
        )

        self._alarm(
            "LatencyP95",
            purpose="alb-latency-p95",
            metric=alb.metrics.target_response_time(
                statistic="p95",
                period=Duration.minutes(5),
            ),
            threshold=LATENCY_P95_SECONDS,
            description=(
                f"95% of requests are now slower than {LATENCY_P95_SECONDS}s. Usually RDS: "
                "check the connection-count and CPU alarms, and Performance Insights for "
                "the statement holding the single burstable vCPU."
            ),
            # p95 needs requests to exist. Overnight staging has none, and a quiet hour in
            # production is not a latency problem.
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=3,
            datapoints_to_alarm=2,
        )

        # The `api` window is deliberately *longer than the outage a deploy causes*.
        # `compute.py` pins `api` to `min_healthy_percent=0` / `max_healthy_percent=100`
        # (one task by design until Phase 11, ADR 0022), which means ECS stops the old
        # task **before** it starts the new one: **3–6 minutes with zero healthy hosts,
        # every single api deploy, by design**. At 3 of 5 one-minute datapoints this alarm
        # would page on every deploy — and an alarm that pages on every deploy is an alarm
        # that is muted within a month, which is worse than not having it. 7 of 8 is just
        # past the top of that window. `web` runs `min_healthy_percent=100` and never goes
        # to zero during a rollout, so it keeps the fast 3-of-5.
        #
        # This asymmetry disappears in Phase 11, when `api` stops being one task.
        for purpose, target_group, evaluations, datapoints in (
            (API, self.edge.api_target_group, 8, 7),
            (WEB, self.edge.web_target_group, 5, 3),
        ):
            deploy_note = (
                (
                    " This alarm waits 7 of 8 minutes on purpose: an api deploy has 3-6 "
                    "minutes of zero healthy hosts by design (ADR 0022 / ADR 0024 §2c), "
                    "so check for a running deployment first."
                )
                if purpose == API
                else ""
            )
            self._alarm(
                f"{purpose.capitalize()}NoHealthyHost",
                purpose=f"{purpose}-no-healthy-host",
                metric=target_group.metrics.healthy_host_count(
                    statistic="Minimum",
                    period=Duration.minutes(1),
                ),
                threshold=1,
                comparison=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
                description=(
                    f"No healthy {purpose} target. The site is down or serving from the "
                    "other target group only. Check ECS service events for a task that "
                    f"will not start, then the container health check.{deploy_note}"
                ),
                # Published continuously while a target is registered: silence IS the
                # outage. See the method docstring.
                treat_missing_data=cloudwatch.TreatMissingData.BREACHING,
                evaluation_periods=evaluations,
                datapoints_to_alarm=datapoints,
            )

        self._alarm(
            "ApiScaledBeyondOne",
            purpose="api-scaled-beyond-one",
            metric=self.edge.api_target_group.metrics.healthy_host_count(
                statistic="Maximum",
                period=Duration.minutes(5),
            ),
            threshold=API_DESIRED_COUNT,
            comparison=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            description=(
                "More than one healthy api task. `api` runs exactly one task by design "
                "until Phase 11 (ADR 0022): two tasks can each pick up the same revenue "
                "run and book the same journal entry twice. Scale it back to 1 and find "
                "out who changed it."
            ),
            # Never breaching when absent: no api task at all is the previous alarm's job,
            # and having this one fire too would send two pages for one event.
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            # Slow on purpose. A rolling deploy legitimately shows two healthy tasks while
            # the new one drains the old, so 6 x 5 min = half an hour of two tasks is what
            # distinguishes "somebody set desiredCount to 2" from "a deploy is running".
            evaluation_periods=6,
            datapoints_to_alarm=6,
        )

    # ---------------------------------------------------------------------- ECS

    def _ecs_alarms(self) -> None:
        """Per service: saturation, and whether the tasks it is supposed to have exist.

        CPU and memory are `NOT_BREACHING` when missing because a service scaled to zero
        — staging between sessions — publishes nothing, and that is a cost control rather
        than an incident. The running-task-count alarm is the one that catches a service
        that should be up and is not, and it is `BREACHING` for exactly that reason.
        """
        desired = {API: API_DESIRED_COUNT, WEB: WEB_DESIRED_COUNT[self.env_name]}

        for purpose, service in ((API, self.compute.api_service), (WEB, self.compute.web_service)):
            self._alarm(
                f"{purpose.capitalize()}Cpu",
                purpose=f"{purpose}-cpu",
                metric=service.metric_cpu_utilization(
                    statistic="Average", period=Duration.minutes(5)
                ),
                threshold=ECS_CPU_THRESHOLD,
                description=(
                    f"The {purpose} service has been above {ECS_CPU_THRESHOLD}% CPU for "
                    "15 minutes. Fargate does not burst: this is the ceiling, not a "
                    "warning shot."
                ),
                treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
                evaluation_periods=3,
                datapoints_to_alarm=3,
            )
            self._alarm(
                f"{purpose.capitalize()}Memory",
                purpose=f"{purpose}-memory",
                metric=service.metric_memory_utilization(
                    statistic="Average", period=Duration.minutes(5)
                ),
                threshold=ECS_MEMORY_THRESHOLD,
                description=(
                    f"The {purpose} service has been above {ECS_MEMORY_THRESHOLD}% memory "
                    "for 15 minutes. The next step is an OOM kill, which looks like a "
                    "random 502 to a user."
                ),
                treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
                evaluation_periods=3,
                datapoints_to_alarm=3,
            )
            self._alarm(
                f"{purpose.capitalize()}TaskCount",
                purpose=f"{purpose}-task-count",
                # There is no L2 helper for RunningTaskCount; it is a Container Insights
                # metric (`ECS/ContainerInsights`), which the cluster has enabled
                # (ADR 0022). Written out rather than approximated from HealthyHostCount,
                # because a task that is running but failing its health check is a
                # different fault from a task that never started.
                metric=cloudwatch.Metric(
                    namespace="ECS/ContainerInsights",
                    metric_name="RunningTaskCount",
                    dimensions_map={
                        "ClusterName": self.compute.cluster.cluster_name,
                        "ServiceName": service.service_name,
                    },
                    statistic="Minimum",
                    period=Duration.minutes(5),
                ),
                threshold=desired[purpose],
                comparison=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
                description=(
                    f"The {purpose} service is running fewer than its desired "
                    f"{desired[purpose]} task(s). Check the service's deployment events: "
                    "the circuit breaker may have rolled back, or the task cannot pull "
                    "its image."
                ),
                # A service that should be running and publishes nothing has no tasks.
                treat_missing_data=cloudwatch.TreatMissingData.BREACHING,
                # 4 x 5 min on 3: comfortably longer than a rolling deploy's dip.
                evaluation_periods=4,
                datapoints_to_alarm=3,
            )

    # ---------------------------------------------------------------------- RDS

    def _max_connections(self) -> int:
        """`max_connections` for this environment's instance class, or refuse to guess."""
        try:
            return MAX_CONNECTIONS[self.env_config.db_instance_type]
        except KeyError as exc:  # pragma: no cover - guarded by a test
            raise ValueError(
                f"No max_connections figure for db_instance_type "
                f"{self.env_config.db_instance_type!r}. Work it out from "
                "LEAST({DBInstanceClassMemory/9531392}, 5000) and add it to "
                "MAX_CONNECTIONS in meridian/stacks/observability.py — a guessed ceiling "
                "gives an alarm that is either permanently quiet or permanently loud."
            ) from exc

    def _rds_alarms(self) -> None:
        """The database. Six metrics, and the one that is really about connection leaks.

        **The missing-data behaviour differs by environment, and that is the point.**

        * **Staging is `MISSING`.** Its instance is stopped every night by the D-15
          schedule and a stopped instance publishes nothing. `BREACHING` would page every
          night at 11pm for a cost control working exactly as designed. `MISSING` carries
          the last known state forward, which is the honest answer to "we cannot see it".
        * **Production is `BREACHING`.** The production instance is **never** stopped
          (there is no stop schedule and no DLQ in production), so RDS going silent is not
          a cost control — it is the database being unreachable, which is the outage.
          `MISSING` there would hold the last *healthy* state forward for ever and report
          green through a total failure, which is exactly the fault ADR 0024 §2b names.

        `destroyed_between_phases` is the environment predicate for both: it is true in
        staging, where the stop schedule lives, and false in production.
        """
        database = self.data.database
        period = Duration.minutes(5)
        #: `MISSING` in staging (stopped nightly), `BREACHING` in production (never
        #: stopped, so silence is the outage). See the docstring.
        stopped_or_gone = (
            cloudwatch.TreatMissingData.MISSING
            if self.env_config.destroyed_between_phases
            else cloudwatch.TreatMissingData.BREACHING
        )

        self._alarm(
            "RdsCpu",
            purpose="rds-cpu",
            metric=database.metric_cpu_utilization(statistic="Average", period=period),
            threshold=RDS_CPU_THRESHOLD,
            description=(
                f"RDS above {RDS_CPU_THRESHOLD}% CPU for 15 minutes. A t4g burstable is "
                "spending CPU credits it will want during the next period close. "
                "Performance Insights shows which statement."
            ),
            treat_missing_data=stopped_or_gone,
            evaluation_periods=3,
            datapoints_to_alarm=3,
        )
        self._alarm(
            "RdsFreeStorage",
            purpose="rds-free-storage",
            metric=database.metric_free_storage_space(statistic="Minimum", period=period),
            threshold=RDS_FREE_STORAGE_BYTES,
            comparison=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
            description=(
                "RDS free storage below 4 GiB. Storage autoscaling has a cooldown and a "
                "period close can outrun it; a full volume takes the database read-only."
            ),
            treat_missing_data=stopped_or_gone,
            # Storage does not recover on its own, so one datapoint is enough and two
            # would only delay the page.
            evaluation_periods=1,
        )
        self._alarm(
            "RdsFreeableMemory",
            purpose="rds-freeable-memory",
            metric=database.metric_freeable_memory(statistic="Minimum", period=period),
            threshold=RDS_FREEABLE_MEMORY_BYTES,
            comparison=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
            description=(
                "RDS freeable memory below 200 MiB. The page cache is being evicted and "
                "every query is about to get slower at once."
            ),
            treat_missing_data=stopped_or_gone,
            evaluation_periods=3,
            datapoints_to_alarm=2,
        )

        connection_ceiling = int(self._max_connections() * CONNECTION_HEADROOM)
        self._alarm(
            "RdsConnections",
            purpose="rds-connections",
            metric=database.metric_database_connections(statistic="Maximum", period=period),
            threshold=connection_ceiling,
            description=(
                f"RDS connections above {connection_ceiling}, which is "
                f"{int(CONNECTION_HEADROOM * 100)}% of the "
                f"{self._max_connections()} this instance class allows. The repository "
                "layer pools, so this is a leak — a connection not returned on an error "
                "path — long before it is load. Past the ceiling, new connections are "
                "refused and that includes the migration runner."
            ),
            treat_missing_data=stopped_or_gone,
            evaluation_periods=3,
            datapoints_to_alarm=2,
        )

        for name, purpose in (
            ("ReadLatency", "rds-read-latency"),
            ("WriteLatency", "rds-write-latency"),
        ):
            self._alarm(
                f"Rds{name}",
                purpose=purpose,
                # No L2 helper for these two; `metric()` is the documented escape hatch and
                # it fills in the `DBInstanceIdentifier` dimension itself.
                metric=database.metric(name, statistic="Average", period=period),
                threshold=RDS_LATENCY_SECONDS,
                description=(
                    f"RDS {name} above {int(RDS_LATENCY_SECONDS * 1000)}ms on average. "
                    "gp3 at this size answers in single-digit milliseconds, so this is "
                    "contention or burst-balance exhaustion, not a slow disk."
                ),
                treat_missing_data=stopped_or_gone,
                evaluation_periods=3,
                datapoints_to_alarm=2,
            )

    # -------------------------------------------------------------------- edge

    def _edge_alarms(self) -> None:
        """WAF blocks and CloudFront 5xx — the two things a user hits before the ALB.

        Both dimension sets are written out rather than taken from an L2 helper, because
        neither `CfnWebACL` nor `Distribution` exposes one. The WAF web ACL is
        `CLOUDFRONT`-scoped, so its metrics are published with `Region: Global` — using the
        stack's region here would produce an alarm on a metric that is never written.
        """
        self._alarm(
            "WafBlockedSpike",
            purpose="waf-blocked-spike",
            metric=cloudwatch.Metric(
                namespace=WAF_NAMESPACE,
                metric_name="BlockedRequests",
                dimensions_map={
                    "WebACL": self.edge.web_acl.name or "",
                    "Rule": "ALL",
                    # `Global`, not the region. See the method docstring.
                    "Region": "Global",
                },
                statistic="Sum",
                period=Duration.minutes(5),
            ),
            threshold=WAF_BLOCKED_SPIKE,
            description=(
                f"The WAF blocked more than {WAF_BLOCKED_SPIKE} requests in five minutes. "
                "Background internet noise is a trickle; this is somebody working through "
                "the rule set. Check the WAF log group for the source and the rule."
            ),
            # Blocks are only published when they happen.
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=2,
            datapoints_to_alarm=2,
        )

        # A *rate*, not a count: CloudFront serves static assets, so an absolute 5xx count
        # says nothing without the denominator. `5xxErrorRate` is already a percentage.
        self._alarm(
            "CloudFrontFiveXx",
            purpose="cloudfront-5xx",
            metric=cloudwatch.Metric(
                namespace=CLOUDFRONT_NAMESPACE,
                metric_name="5xxErrorRate",
                dimensions_map={
                    "DistributionId": self.edge.distribution.distribution_id,
                    # CloudFront's only legal value for this dimension.
                    "Region": "Global",
                },
                statistic="Average",
                period=Duration.minutes(5),
            ),
            threshold=CLOUDFRONT_5XX_PERCENT,
            description=(
                f"More than {CLOUDFRONT_5XX_PERCENT}% of CloudFront responses are 5xx. If "
                "the ALB alarms are quiet, suspect the origin-verify header: a rotation "
                "that moved one end and not the other returns 403 from the ALB and 5xx "
                "from CloudFront. docs/runbooks/rotate-origin-verify-secret.md."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=3,
            datapoints_to_alarm=2,
        )

    # ------------------------------------------------------------------ lambda

    def _lambda_alarms(self) -> None:
        """The Cognito User Migration trigger: errors, and the 5-second budget.

        **Addressed by function name, not by importing the `auth` stack.** The name is
        `resource_name(env, "lambda", "user-migration")` — the same convention every
        resource follows — so a metric dimension reproduces it exactly without a
        CloudFormation export. That matters: an export from `auth` would make `auth`
        undeletable while this stack exists, and this is the stack that is destroyed
        between staging phases (ADR 0008). A dimension naming a function that does not
        exist yields no data, which is what `NOT_BREACHING` below already handles.
        """
        function_name = resource_name(self.env_name, "lambda", "user-migration")

        self._alarm(
            "UserMigrationErrors",
            purpose="user-migration-errors",
            metric=cloudwatch.Metric(
                namespace=LAMBDA_NAMESPACE,
                metric_name="Errors",
                dimensions_map={"FunctionName": function_name},
                statistic="Sum",
                period=Duration.minutes(5),
            ),
            threshold=1,
            description=(
                "The User Migration Lambda errored. It fails closed, so every error is a "
                "person who was told sign-in is unavailable. "
                "docs/runbooks/cognito-user-migration.md."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            # One datapoint. A failed sign-in is not something to wait fifteen minutes to
            # confirm, and the function is invoked only on a first-ever sign-in.
            evaluation_periods=1,
        )
        self._alarm(
            "UserMigrationDuration",
            purpose="user-migration-duration",
            metric=cloudwatch.Metric(
                namespace=LAMBDA_NAMESPACE,
                metric_name="Duration",
                dimensions_map={"FunctionName": function_name},
                statistic="p99",
                period=Duration.minutes(5),
            ),
            threshold=LAMBDA_DURATION_BUDGET_MS,
            description=(
                "The User Migration Lambda's p99 is within a second of Cognito's 5-second "
                "trigger budget. Past 5s Cognito abandons the sign-in — the person is "
                "turned away and nothing in the Lambda's own metrics calls that an error. "
                "It talks to Supabase over the public internet, so suspect Supabase."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=2,
            datapoints_to_alarm=2,
        )

        # T:163: the nightly Cognito identity export (`auth.py` `_cognito_export`), by
        # name for the same reason. One run a night, so one errored run is the signal.
        self._alarm(
            "CognitoExportErrors",
            purpose="cognito-export-errors",
            metric=cloudwatch.Metric(
                namespace=LAMBDA_NAMESPACE,
                metric_name="Errors",
                dimensions_map={
                    "FunctionName": resource_name(self.env_name, "lambda", "cognito-export")
                },
                statistic="Sum",
                period=Duration.hours(1),
            ),
            threshold=1,
            description=(
                "The nightly Cognito identity export errored: tonight's cognito_export/ "
                "object in the archive bucket is missing, so a pool loss would restore "
                "from an older one. Re-run by hand with scripts/cognito_export.py "
                "(docs/runbooks/restore-drill.md §3)."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=1,
        )

    # ------------------------------------------------------------------ backups

    def _backup_alarms(self) -> None:
        """Backup job failures, via EventBridge rather than a metric.

        AWS Backup publishes `NumberOfBackupJobsFailed` to CloudWatch, but only for the
        *account*, only hourly, and with no way to say which vault — so an alarm on it
        cannot tell a failed Meridian job from a failed job belonging to the other owner of
        this shared account (ADR 0001). The `Backup Job State Change` event carries the
        backup vault name and the resource ARN, so the rule filters on state and the
        message a human receives names the thing that failed.

        `COMPLETED` is deliberately not in the pattern: a success notification per day per
        resource is how a mailbox filter gets written, and a filtered mailbox is how the
        failure is missed.
        """
        self._event_rule_to_topic(
            "BackupJobFailed",
            purpose="backup-job-failed",
            description=(
                "AWS Backup job failed, expired or was aborted. The daily plan protects "
                "RDS and the three buckets; a missed window is a shortened recovery "
                "point. docs/runbooks/restore-drill.md."
            ),
            event_pattern=events.EventPattern(
                source=["aws.backup"],
                detail_type=["Backup Job State Change"],
                detail={"state": ["FAILED", "ABORTED", "EXPIRED"]},
            ),
        )
        self._event_rule_to_topic(
            "CopyJobFailed",
            purpose="backup-copy-failed",
            description=(
                "The cross-region copy into the us-west-2 vault failed. The local "
                "recovery point may still be fine; the DR one is not. ADR 0020 §8."
            ),
            event_pattern=events.EventPattern(
                source=["aws.backup"],
                detail_type=["Copy Job State Change"],
                detail={"state": ["FAILED"]},
            ),
        )

    # ---------------------------------------------------------------- rotation

    def _secret_rotation_alarms(self) -> None:
        """Secrets Manager rotation failures.

        Secrets Manager emits no CloudWatch metric for a failed rotation. It emits a
        CloudTrail event, and EventBridge can match on the error code — which is the
        documented route and the one the prompt's "AWS hygiene" section asks for in place
        of a hand-rolled Lambda.

        The pattern is scoped to `meridian-<env>/` secrets by prefix. It cannot be scoped
        by ARN because the account is shared and the other owner's secrets would otherwise
        page us.
        """
        self._event_rule_to_topic(
            "SecretRotationFailed",
            purpose="secret-rotation-failed",
            description=(
                "A Secrets Manager rotation failed. The old value still works until it "
                "does not; a database credential rotation that failed halfway leaves the "
                "app on AWSPREVIOUS. docs/runbooks/rotate-secrets.md."
            ),
            event_pattern=events.EventPattern(
                source=["aws.secretsmanager"],
                detail_type=["AWS API Call via CloudTrail"],
                detail={
                    "eventSource": ["secretsmanager.amazonaws.com"],
                    "eventName": ["RotationFailed", "RotationAbandoned"],
                    "requestParameters": {"secretId": [{"prefix": f"meridian-{self.env_name}/"}]},
                },
            ),
        )

    # -------------------------------------------------------------------- queues

    def _queue_alarms(self) -> None:
        """The stop-schedule DLQ's *age*, not its depth. ADR 0020 §7c.

        A depth alarm on this queue was withdrawn and the reasoning is worth restating,
        because the obvious fix is to put it back. Most nights the staging instance is
        already stopped, `StopDBInstance` answers `InvalidDBInstanceState`, and one
        expected message lands. **A night whose only message is a real failure has exactly
        the same depth as an ordinary night**, so no threshold on depth can separate them.
        The Pipe and the two rules below do the real work, by reading the error code after
        the message has been delivered rather than by counting messages.

        What is left for an alarm is the thing none of them can see: a message that nobody
        has consumed. With a one-day retention, an oldest message older than six hours
        means the Pipe is not running — and a Pipe that is not running is the one fault the
        routing cannot report about itself.
        """
        if self.data.stop_dlq is None:
            # Production has no stop schedule and therefore no DLQ: the production
            # database is never stopped.
            return

        self._alarm(
            "StopDlqUnconsumed",
            purpose="stop-dlq-unconsumed",
            metric=self.data.stop_dlq.metric_approximate_age_of_oldest_message(
                statistic="Maximum", period=Duration.minutes(30)
            ),
            threshold=Duration.hours(6).to_seconds(),
            description=(
                "A message has sat in the stop-schedule dead-letter queue for six hours. "
                "The EventBridge Pipe that drains it is not running, so a real stop "
                "failure would go unreported. This is NOT a depth alarm — see ADR 0020 "
                "§7c for why a depth threshold cannot work here."
            ),
            # An empty queue publishes no age. That is the normal state.
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=2,
            datapoints_to_alarm=2,
        )

    # --------------------------------------------------------------------- worker

    def _worker_alarms(self) -> None:
        """The Phase 11 job worker (H2, plan §3.8): five alarms, all to the alerts topic.

        Built only with `-c worker_enabled=true`, off the constructs `compute` exposes
        (`stacks/worker.py`), so each names the queue, service and schedule group CDK
        actually created. They are in the alarm carpet on the dashboard with the rest.

        * `jobs-dlq` — **any** message in the DLQ. Every refusal (wrong org, wrong actor,
          stale input version, malformed body, `no_handler`) is dead-lettered with a reason
          code, and so is a job that failed its third receive; each is a person's run that
          did not happen. This also covers the plan's `job_refused` filter: a refusal
          always lands here, so a second alarm on the log line would page twice.
        * `jobs-age` — the oldest job has waited more than 15 minutes (the visibility
          timeout, plan §3.8). A job in flight counts too, so a run that has been working
          for 15 minutes trips it — that is itself worth a look at this scale.
        * `worker-task-count` — fewer than one running worker task. Written like the
          api/web task-count alarms (`_ecs_alarms`), BREACHING on missing data: a service
          that should be running and publishes nothing has no tasks.
        * `sweep-stalled` — no successful sweep for an hour (four ticks). Counted from the
          worker's own fixed `sweep done` line, so it catches every way the sweeper can
          stop: the schedule not firing or not delivering, the worker down or stuck, the
          database refusing the sweep. **Staging is `MISSING`**: its database is stopped
          overnight by the D-15 schedule and every sweep then fails, which is not a page.
        * `sweep-dropped` — Scheduler gave up on a tick after its retries
          (`AWS/Scheduler` `InvocationDroppedCount`, cut by the worker's own schedule
          group): the role, the key or the queue refused the send. The specific cause the
          stalled alarm cannot name.

        **The one `$.message` filter in this file.** The worker's JSON records carry no
        `event` field yet, so the sweep filter matches the record's `message` for
        **equality** with a fixed string `workers/sweep.py` writes — not a substring, so it
        cannot match a line that merely contains the words (see the module docstring's rule;
        `infra/tests/test_worker.py` reads the literal from the worker's source).
        """
        from .worker import (
            JOBS_VISIBILITY_TIMEOUT,
            SWEEP_DONE_MESSAGE,
            SWEEP_DONE_METRIC,
            WORKER_DESIRED_COUNT,
            worker_schedule_group_name,
        )

        worker = self.compute.worker
        if worker is None:
            raise AssertionError('worker is not None')
        five = Duration.minutes(5)

        self._alarm(
            "JobsDlqDepth",
            purpose="jobs-dlq",
            metric=worker.dlq.metric_approximate_number_of_messages_visible(
                statistic="Maximum", period=five
            ),
            threshold=1,
            description=(
                "A job is in the worker's dead-letter queue: refused (reason code in the "
                "message attributes) or failed three times. Someone's run did not happen. "
                "Triage: docs/runbooks/alerts.md, 'Job DLQ'."
            ),
            # SQS stops publishing for an idle queue; no data means nothing arrived.
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=1,
        )
        self._alarm(
            "JobsOldestMessageAge",
            purpose="jobs-age",
            metric=worker.queue.metric_approximate_age_of_oldest_message(
                statistic="Maximum", period=five
            ),
            threshold=JOBS_VISIBILITY_TIMEOUT.to_seconds(),
            comparison=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            description=(
                "A job has waited (or been running) more than 15 minutes. The worker is "
                "down, stuck, or losing every lease. docs/runbooks/alerts.md, 'Job queue age'."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=1,
        )
        self._alarm(
            "WorkerTaskCount",
            purpose="worker-task-count",
            metric=cloudwatch.Metric(
                namespace="ECS/ContainerInsights",
                metric_name="RunningTaskCount",
                dimensions_map={
                    "ClusterName": self.compute.cluster.cluster_name,
                    "ServiceName": worker.service.service_name,
                },
                statistic="Minimum",
                period=five,
            ),
            threshold=WORKER_DESIRED_COUNT,
            comparison=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
            description=(
                f"The worker service is running fewer than its {WORKER_DESIRED_COUNT} "
                "task(s): nothing is taking jobs off the queue. Read the service's "
                "deployments and events (circuit breaker, image pull, a crash at start)."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.BREACHING,
            # 4 x 5 min on 3, as for the api and web: longer than a rolling deploy's dip.
            evaluation_periods=4,
            datapoints_to_alarm=3,
        )

        logs.MetricFilter(
            self,
            "WorkerSweepDoneFilter",
            log_group=worker.log_group,
            filter_pattern=logs.FilterPattern.string_value("$.message", "=", SWEEP_DONE_MESSAGE),
            metric_namespace=APP_NAMESPACE,
            metric_name=SWEEP_DONE_METRIC,
            metric_value="1",
            dimensions={ENVIRONMENT_DIMENSION: "$.env"},
        )
        self._alarm(
            "SweepStalled",
            purpose="sweep-stalled",
            metric=self._app_metric(
                SWEEP_DONE_METRIC, statistic="Sum", period=Duration.minutes(30)
            ),
            threshold=1,
            comparison=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
            description=(
                "No run sweep has completed for an hour (it should run every 15 minutes). "
                "Expired drafts are not expiring and lapsed runs are not being failed. "
                "docs/runbooks/alerts.md, 'Sweeper'."
            ),
            treat_missing_data=(
                cloudwatch.TreatMissingData.MISSING
                if self.env_config.destroyed_between_phases
                else cloudwatch.TreatMissingData.BREACHING
            ),
            evaluation_periods=2,
            datapoints_to_alarm=2,
        )
        self._alarm(
            "SweepDropped",
            purpose="sweep-dropped",
            metric=cloudwatch.Metric(
                namespace="AWS/Scheduler",
                metric_name="InvocationDroppedCount",
                dimensions_map={"ScheduleGroup": worker_schedule_group_name(self.env_name)},
                statistic="Sum",
                period=Duration.minutes(15),
            ),
            threshold=1,
            description=(
                "EventBridge Scheduler dropped a sweep tick after its retries: the "
                "scheduler role, the queue's key or the queue refused the send. "
                "docs/runbooks/alerts.md, 'Sweeper'."
            ),
            # Published only when something is dropped.
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=1,
        )

    # ---------------------------------------------------------------------- email

    def _ses_alarms(self) -> None:
        """SES bounce rate, complaint rate, and rendering failures (tracker T:39).

        This replaces the *manual* 24-hour watch in `docs/runbooks/email-cutover.md` §3.

        **The two rates are the account's, and they are production only** — the same
        reasoning as `_account_finding_rules`. `Reputation.BounceRate` and
        `Reputation.ComplaintRate` with no dimension are the numbers AWS itself reviews
        and pauses sending on, for the whole account (shared with another owner, ADR
        0001), so they are the ones worth waking someone for; one alarm in the
        environment that is never destroyed, not two emails per breach. Thresholds are
        AWS's review lines: bounces above 5 %, complaints above 0.1 %.

        **Rendering failures are per environment.** No rate or reputation metric counts
        them — a template that breaks produces no bounce, no complaint and no delivery,
        the message simply never exists. `meridian-shared-dns` publishes the event to
        CloudWatch through a dedicated event destination dimensioned by the `env`
        message tag, so each environment alarms on its own sends.

        All three are `NOT_BREACHING` on missing data: no mail sent is no problem, and
        both publish only when there is something to report.
        """
        self._alarm(
            "SesRenderingFailure",
            purpose="ses-rendering-failure",
            metric=cloudwatch.Metric(
                namespace=SES_NAMESPACE,
                metric_name="RenderingFailure",
                dimensions_map={SES_ENV_DIMENSION: self.env_name},
                statistic="Sum",
                period=Duration.minutes(5),
            ),
            threshold=1,
            description=(
                "SES could not render a message: a template or its data is broken, and "
                "the email was never sent. No bounce and no complaint will follow — this "
                "is the only signal. docs/runbooks/email-cutover.md §3."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=1,
        )
        if self.env_config.destroyed_between_phases:
            return
        for construct_id, purpose, metric_name, threshold, what in (
            (
                "SesBounceRate",
                "ses-bounce-rate",
                "Reputation.BounceRate",
                SES_BOUNCE_RATE_THRESHOLD,
                "bounce rate is above 5 %, AWS's review threshold; above 10 % it may "
                "pause sending for the whole account",
            ),
            (
                "SesComplaintRate",
                "ses-complaint-rate",
                "Reputation.ComplaintRate",
                SES_COMPLAINT_RATE_THRESHOLD,
                "complaint rate is above 0.1 %, AWS's review threshold — on this volume "
                "that can be a single complaint",
            ),
        ):
            self._alarm(
                construct_id,
                purpose=purpose,
                metric=cloudwatch.Metric(
                    namespace=SES_NAMESPACE,
                    metric_name=metric_name,
                    statistic="Maximum",
                    period=Duration.hours(1),
                ),
                threshold=threshold,
                comparison=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
                description=(
                    f"The account's SES {what}. Account-wide (shared account, ADR 0001), so "
                    "check whose sends bounced before acting. docs/runbooks/email-cutover.md §3."
                ),
                treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
                evaluation_periods=1,
            )

    # ------------------------------------------------ housekeeping Lambdas

    def _housekeeping_function(
        self,
        *,
        purpose: str,
        source: Path,
        description: str,
        environment: dict[str, str],
        statements: list[iam.PolicyStatement],
    ) -> lambda_.Function:
        """One small scheduled Lambda: its own named role, its own CMK log group.

        `meridian-<env>-lambda-<purpose>` / `meridian-<env>-iam-lambda-<purpose>`. The
        log group is created here — never implicitly — on the `logs` CMK with the
        estate's retention, and the role may write only to it. No bundling: the handler
        needs nothing beyond the runtime's own boto3.
        """
        name = resource_name(self.env_name, "lambda", purpose)
        log_group = logs.LogGroup(
            self,
            f"{purpose.title().replace('-', '')}LogGroup",
            log_group_name=f"/aws/lambda/{name}",
            retention=LOG_RETENTION,
            encryption_key=self.data.keys["logs"],
            removal_policy=(
                RemovalPolicy.DESTROY
                if self.env_config.destroyed_between_phases
                else RemovalPolicy.RETAIN
            ),
        )
        role = iam.Role(
            self,
            f"{purpose.title().replace('-', '')}Role",
            role_name=resource_name(self.env_name, "iam", f"lambda-{purpose}"),
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            description=description,
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="WriteOwnLogs",
                actions=["logs:CreateLogStream", "logs:PutLogEvents"],
                resources=[log_group.log_group_arn, f"{log_group.log_group_arn}:*"],
            )
        )
        for statement in statements:
            role.add_to_policy(statement)
        return lambda_.Function(
            self,
            f"{purpose.title().replace('-', '')}Function",
            function_name=name,
            description=description,
            runtime=lambda_.Runtime.PYTHON_3_12,
            architecture=lambda_.Architecture.ARM_64,
            handler="handler.handler",
            code=lambda_.Code.from_asset(str(source), exclude=["__pycache__", "*.pyc"]),
            role=role,
            timeout=Duration.minutes(2),
            memory_size=128,
            log_group=log_group,
            environment=environment,
        )

    def _log_group_governor(self) -> lambda_.Function:
        """Retention and the `logs` CMK for the log groups no construct can configure.

        Tracker T:60 (the canary's `/aws/lambda/cwsyn-<canary>-*`) and T:65 (the CDK
        helper Lambdas' `/aws/lambda/meridian-<env>-<stack>-Custom…`). Both rows asked
        for "a CloudWatch account-level default retention and encryption policy", and
        **there is no such thing**: `AWS::Logs::AccountPolicy` covers data protection,
        subscription filters, field indexes, transformers and metric extraction —
        nothing that sets a retention or a key. So the control is this function
        (`lambda/log_governor/handler.py`): every six hours, and on every
        `CreateLogGroup` CloudTrail event, it sets the estate's 400-day retention on a
        group that has none and associates this environment's `logs` CMK with a group
        that has no key. It never shortens a retention or replaces a key.

        **Scoped to two prefixes of THIS environment** — `/aws/lambda/meridian-<env>-`
        and the canary's `/aws/lambda/cwsyn-<canary>-` — in its environment, in its
        role's `Resource` and in the event rule, so it cannot reach the other
        environment's groups or the other owner's in the shared account (ADR 0001). Both
        prefixes are in the `logs` key policy's admitted list (`meridian/log_groups.py`),
        which is what lets CloudWatch Logs accept the association at all.

        The one `log-group:*` resource is `logs:DescribeLogGroups`, which IAM authorizes
        only against the account's log-group wildcard; it reads names and settings, never
        events.
        """
        prefixes = [
            f"/aws/lambda/meridian-{self.env_name}-",
            f"/aws/lambda/cwsyn-{log_group_names.canary_name(self.env_name)}-",
        ]
        log_group_arn = f"arn:{Aws.PARTITION}:logs:{Aws.REGION}:{Aws.ACCOUNT_ID}:log-group:"
        function = self._housekeeping_function(
            purpose="log-governor",
            source=LOG_GOVERNOR_SOURCE,
            description=(
                "Sets 400-day retention and the logs CMK on this environment's implicit "
                "log groups (CDK helpers, the canary). Tracker T:60/T:65."
            ),
            environment={
                "LOG_GROUP_PREFIXES": json.dumps(prefixes),
                "RETENTION_DAYS": str(LOG_GOVERNOR_RETENTION_DAYS),
                "KMS_KEY_ARN": self.data.keys["logs"].key_arn,
            },
            statements=[
                iam.PolicyStatement(
                    sid="ListLogGroupSettings",
                    actions=["logs:DescribeLogGroups"],
                    resources=[f"{log_group_arn}*"],
                ),
                iam.PolicyStatement(
                    sid="SetRetentionAndKeyOnOwnPrefixesOnly",
                    actions=["logs:PutRetentionPolicy", "logs:AssociateKmsKey"],
                    resources=[f"{log_group_arn}{prefix}*" for prefix in prefixes],
                ),
            ],
        )
        target = events_targets.LambdaFunction(function)
        events.Rule(
            self,
            "LogGovernorSchedule",
            rule_name=resource_name(self.env_name, "rule", "log-governor-sweep"),
            description="Sweep this environment's implicit log groups (T:60/T:65).",
            schedule=events.Schedule.rate(LOG_GOVERNOR_RATE),
            targets=[target],
        )
        events.Rule(
            self,
            "LogGovernorOnCreate",
            rule_name=resource_name(self.env_name, "rule", "log-governor-create"),
            description="A log group was created under one of this environment's prefixes.",
            event_pattern=events.EventPattern(
                source=["aws.logs"],
                detail_type=["AWS API Call via CloudTrail"],
                detail={
                    "eventSource": ["logs.amazonaws.com"],
                    "eventName": ["CreateLogGroup"],
                    "requestParameters": {
                        "logGroupName": [{"prefix": prefix} for prefix in prefixes]
                    },
                },
            ),
            targets=[target],
        )
        return function

    def _backup_freshness(self) -> lambda_.Function | None:
        """Alarm on backups that STOPPED, not only on backups that failed (T:160).

        Codex G-M1. `_backup_alarms` sees a job that ran and failed. A disabled plan, a
        selection tag that changed, or an S3 opt-in switched off produces no job and no
        event, and nothing notices until a restore. `lambda/backup_freshness/handler.py`
        asks the vaults what they hold every six hours and publishes ages to
        `Meridian/Backup`; the alarms below read them:

        * each protected resource's newest local recovery point older than 26 h;
        * the newest DR-vault copy older than 32 h;
        * RDS's `LatestRestorableTime` more than an hour behind (the PITR edge);
        * any of those with no recovery point at all (`MissingRecoveryPoints`);
        * **the checker itself silent for a day** — `CheckerRuns` is published last, so
          a run that raises, a disabled schedule and a deleted function all look the
          same: no heartbeat, `BREACHING` on missing data.

        **Production only.** Staging has no scheduled plan by design (M-2, `data.py`
        `_backups`) and its instance is stopped overnight, so every one of these would
        be red for ever there.

        The role lists recovery points in exactly two vaults (the local one and the DR
        one, by ARN), describes one database instance, and publishes to one metric
        namespace. It cannot start, restore or delete anything.
        """
        if self.env_config.destroyed_between_phases:
            return None

        database = self.data.database
        resources = {
            "rds": database.instance_arn,
            "artifacts": self.data.buckets["artifacts"].bucket_arn,
            "phi": self.data.buckets["phi"].bucket_arn,
        }
        dr_region = self.data.dr_region
        dr_vault_name = resource_name(self.env_name, "backup", "dr")
        function = self._housekeeping_function(
            purpose="backup-freshness",
            source=BACKUP_FRESHNESS_SOURCE,
            description=(
                "Publishes the age of the newest recovery point per protected resource, "
                "the DR copy and the PITR edge. Tracker T:160 (Codex G-M1)."
            ),
            environment={
                "ENVIRONMENT": self.env_name,
                "BACKUP_VAULT_NAME": self.data.backup_vault.backup_vault_name,
                "DR_BACKUP_VAULT_NAME": dr_vault_name,
                "DR_REGION": dr_region,
                "DB_INSTANCE_IDENTIFIER": log_group_names.rds_instance_identifier(self.env_name),
                "PROTECTED_RESOURCES": self.to_json_string(resources),
            },
            statements=[
                iam.PolicyStatement(
                    sid="ListRecoveryPointsInTheTwoVaults",
                    actions=["backup:ListRecoveryPointsByBackupVault"],
                    resources=[self.data.backup_vault.backup_vault_arn, self.data.dr_vault_arn],
                ),
                iam.PolicyStatement(
                    sid="DescribeTheOneDatabase",
                    actions=["rds:DescribeDBInstances"],
                    resources=[database.instance_arn],
                ),
                # `PutMetricData` has no resource-level permission in IAM; the namespace
                # condition is the documented way to confine it.
                iam.PolicyStatement(
                    sid="PublishBackupMetricsOnly",
                    actions=["cloudwatch:PutMetricData"],
                    resources=["*"],
                    conditions={"StringEquals": {"cloudwatch:namespace": BACKUP_NAMESPACE}},
                ),
            ],
        )
        events.Rule(
            self,
            "BackupFreshnessSchedule",
            rule_name=resource_name(self.env_name, "rule", "recovery-point-ages"),
            description="Check the age of every recovery point (T:160).",
            schedule=events.Schedule.rate(BACKUP_FRESHNESS_RATE),
            targets=[events_targets.LambdaFunction(function)],
        )

        def backup_metric(
            name: str, statistic: str, resource: str | None = None
        ) -> cloudwatch.Metric:
            dimensions = {ENVIRONMENT_DIMENSION: self.env_name}
            if resource:
                dimensions["Resource"] = resource
            return cloudwatch.Metric(
                namespace=BACKUP_NAMESPACE,
                metric_name=name,
                dimensions_map=dimensions,
                statistic=statistic,
                period=BACKUP_FRESHNESS_RATE,
            )

        # Age alarms are NOT_BREACHING on missing data: a resource that has no age has
        # no recovery point, which `MissingRecoveryPoints` says, and a checker that
        # published nothing is the heartbeat's job. Each alarm has one job.
        for label, limit in (
            ("rds", BACKUP_LOCAL_MAX_AGE_HOURS),
            ("artifacts", BACKUP_LOCAL_MAX_AGE_HOURS),
            ("phi", BACKUP_LOCAL_MAX_AGE_HOURS),
            ("dr", BACKUP_DR_MAX_AGE_HOURS),
        ):
            where = (
                "the us-west-2 DR vault's newest copy"
                if label == "dr"
                else (f"the newest {label} recovery point in the local vault")
            )
            self._alarm(
                f"BackupAge{label.title()}",
                purpose=f"backup-age-{label}",
                metric=backup_metric("RecoveryPointAgeHours", "Maximum", label),
                threshold=limit,
                comparison=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
                description=(
                    f"{where.capitalize()} is older than {limit} hours: the daily plan did "
                    "not produce one, and no job FAILED to say so (disabled plan, changed "
                    "selection tag, S3 opt-in off). docs/runbooks/alerts.md §6."
                ),
                treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
                evaluation_periods=1,
            )
        self._alarm(
            "BackupRestorableLag",
            purpose="backup-pitr-lag",
            metric=backup_metric("RestorableLagHours", "Maximum", "rds"),
            threshold=RESTORABLE_MAX_LAG_HOURS,
            comparison=cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
            description=(
                "RDS's LatestRestorableTime is more than an hour behind: point-in-time "
                "recovery could not restore the last hour, which is the RPO (ADR 0007). "
                "docs/runbooks/alerts.md §6."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=1,
        )
        self._alarm(
            "BackupMissing",
            purpose="backup-missing",
            metric=backup_metric("MissingRecoveryPoints", "Maximum"),
            threshold=1,
            description=(
                "A protected resource, the DR vault or the PITR edge has NO recovery point "
                "at all. The function's log names which. docs/runbooks/alerts.md §6."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=1,
        )
        self._alarm(
            "BackupCheckerSilent",
            purpose="backup-checker-silent",
            metric=cloudwatch.Metric(
                namespace=BACKUP_NAMESPACE,
                metric_name="CheckerRuns",
                dimensions_map={ENVIRONMENT_DIMENSION: self.env_name},
                statistic="SampleCount",
                period=BACKUP_HEARTBEAT_PERIOD,
            ),
            threshold=1,
            comparison=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
            description=(
                "The backup-freshness checker has not completed a run in 24 hours, so the "
                "age alarms are reading nothing. Check the function's errors and its "
                "schedule rule. docs/runbooks/alerts.md §6."
            ),
            # The whole point: absence of the heartbeat is the alarm.
            treat_missing_data=cloudwatch.TreatMissingData.BREACHING,
            evaluation_periods=1,
        )
        return function

    # ------------------------------------------------- account-scoped findings

    def _account_finding_rules(self) -> None:
        """GuardDuty, Security Hub and Config findings → the alerts topic.

        **Production only, and the reason is not thrift.** These three services are
        enabled once for the whole account by `meridian-shared-foundation`, and their
        findings are account-scoped: a GuardDuty finding is not "a staging finding". A rule
        in each environment would send two emails for one finding, and a rule that lives
        only in staging would disappear with the next teardown (ADR 0008 / D-15). One rule,
        in the environment that is never destroyed, is the shape that matches the facts.

        The severity filters are numeric ranges because that is how the two services
        express severity in the event: GuardDuty 7.0-8.9 is High and 9.0+ is Critical;
        Security Hub's normalized severity puts High at 70 and Critical at 90. Filtering to
        High and above is what keeps this from being a daily digest of informational
        findings that nobody reads.
        """
        if self.env_config.destroyed_between_phases:
            return

        self._event_rule_to_topic(
            "GuardDutyFinding",
            purpose="guardduty-finding",
            description=(
                "GuardDuty found something at High or Critical severity. Triage per "
                "docs/runbooks/incident-response.md; account-scoped, so it may not be ours."
            ),
            event_pattern=events.EventPattern(
                source=["aws.guardduty"],
                detail_type=["GuardDuty Finding"],
                detail={"severity": [{"numeric": [">=", 7]}]},
            ),
        )
        self._event_rule_to_topic(
            "SecurityHubFinding",
            purpose="securityhub-finding",
            description=(
                "A Security Hub finding at HIGH or CRITICAL became active. The HIPAA "
                "conformance pack and the CIS standard both feed this."
            ),
            event_pattern=events.EventPattern(
                source=["aws.securityhub"],
                detail_type=["Security Hub Findings - Imported"],
                detail={
                    "findings": {
                        "Severity": {"Label": ["HIGH", "CRITICAL"]},
                        "Workflow": {"Status": ["NEW"]},
                        "RecordState": ["ACTIVE"],
                    }
                },
            ),
        )
        self._event_rule_to_topic(
            "ConfigNonCompliant",
            purpose="config-non-compliant",
            description=(
                "An AWS Config rule went NON_COMPLIANT. The HIPAA conformance pack is the "
                "evidence the control matrix points at, so a rule going non-compliant is "
                "an evidence gap as well as a control gap."
            ),
            event_pattern=events.EventPattern(
                source=["aws.config"],
                detail_type=["Config Rules Compliance Change"],
                detail={
                    "messageType": ["ComplianceChangeNotification"],
                    "newEvaluationResult": {
                        "complianceType": ["NON_COMPLIANT"],
                    },
                },
            ),
        )

    # ------------------------------------------------------- log metric filters

    def _log_metric_filters(self) -> dict[str, logs.MetricFilter]:
        """Field-based metric filters over the api and web log groups.

        **Read the module docstring's "log-format contract" section before changing any
        pattern here.** Every one of these matches on a JSON *field*; none matches a
        substring. That is a PHI decision, not a style one: `{ $.message = "*failed*" }`
        would happily count — and, in the filter's own stored definition, advertise — a log
        line that quoted a spreadsheet cell.

        Both the api and the web container emit JSON now (see the module docstring); a
        filter that reads a field a container does not write stays silent rather than
        wrong, which is the point of matching on fields.

        **Every filter carries `Environment` as a dimension**, taken from the record's
        `$.env` field. One namespace, one account, two environments: without it staging's
        counts and production's are literally the same metric. CloudWatch Logs will not
        accept a `default_value` alongside dimensions, so these metrics have no datapoints
        rather than a flat zero until a matching line is written — see the module docstring.

        **Construct ids are built from the `API`/`WEB` purpose constants, never from a log
        group's name.** `log_group.log_group_name` for a group owned by another stack is an
        unresolved CloudFormation token (`${Token[TOKEN.nnn]}`), so slicing it produced ids
        that changed whenever an unrelated resource shifted the token numbering — and a
        changed construct id is a **replaced** metric filter with a new logical id, which
        CloudFormation deletes and recreates. A test pins the logical ids.
        """
        groups_by_purpose: dict[str, logs.ILogGroup] = {
            API: self.compute.log_groups[API],
            WEB: self.compute.log_groups[WEB],
        }

        #: `(construct id, metric name, pattern, purposes)`.
        #:
        #: The auth-failure and 5xx patterns are `||` chains over the exact code constants
        #: in `src/api/v2/errors.py` rather than a status-code range, so that adding a code
        #: to the catalogue without adding it here shows up as a flat line rather than as
        #: silently-correct-looking data.
        specs: list[tuple[str, str, str, list[str]]] = [
            (
                # Every request, from `api/request_log.py`: what the heartbeat counts.
                # A field match on the fixed event name, like the rest — never a path.
                "HttpRequests",
                "HttpRequests",
                '{ $.event = "http_request" }',
                [API],
            ),
            (
                "FiveXxEnvelope",
                "FiveXxResponses",
                "{ $.http.status >= 500 }",
                [API, WEB],
            ),
            (
                "PoolTimeout",
                "PoolTimeout",
                '{ $.exception.type = "PoolTimeout" }',
                [API],
            ),
            (
                "PgWriteRefused",
                "PgWriteRefused",
                '{ $.exception.type = "PgWriteRefused" }',
                [API],
            ),
            (
                "CompensatingDeleteIncomplete",
                "CompensatingDeleteIncomplete",
                '{ $.exception.type = "CompensatingDeleteIncomplete" }',
                [API],
            ),
            (
                # The request id is matched for EXISTENCE, never captured as a value: it is
                # `req_<uuid4 hex>` and carries nothing, but the rule is that a filter
                # names fields and counts, and the operator reads the ids from the log.
                "UnhandledException",
                "UnhandledExceptions",
                '{ $.event = "unhandled_exception" && $.request_id = "req_*" }',
                [API],
            ),
            (
                "AuthFailures",
                "AuthFailures",
                (
                    '{ ($.error.code = "AUTH_REQUIRED") '
                    '|| ($.error.code = "SESSION_EXPIRED") '
                    '|| ($.error.code = "INVALID_CREDENTIALS") '
                    '|| ($.error.code = "MFA_CHALLENGE_INVALID") '
                    '|| ($.error.code = "PERMISSION_DENIED") '
                    '|| ($.error.code = "CSRF_INVALID") '
                    '|| ($.error.code = "ORG_REQUIRED") }'
                ),
                [API],
            ),
            (
                # CC6.7's "unusual export volume", built rather than asserted. The control
                # matrix used to claim this existed; it did not. It is a *field* match on
                # the download envelope — `$.event = "artifact_download"` — and counts
                # events, never the object key: a key is a filename and a filename in this
                # estate can carry a person's name.
                "ArtifactDownload",
                "ArtifactDownloads",
                '{ $.event = "artifact_download" }',
                [API],
            ),
            (
                # NOT a `phi_access` gap detector. `src/phi.py` logs nothing on the happy
                # path — "Nothing is logged here, not even the count" — so gap detection is
                # a SQL query against `audit.phi_access`, not a log pattern (module
                # docstring; ADR 0024 §4). What this counts is the audit write *failing*,
                # which is the one PHI-audit fault that does reach a log.
                "PhiAuditWriteFailed",
                "PhiAuditWriteFailures",
                '{ $.event = "phi_audit_write_failed" }',
                [API],
            ),
        ]

        filters: dict[str, logs.MetricFilter] = {}
        for construct_id, metric_name, pattern, purposes in specs:
            for purpose in purposes:
                # The purpose constant, not a slice of a cross-stack token. See docstring.
                suffix = "" if len(purposes) == 1 else purpose.capitalize()
                filters[f"{construct_id}{suffix}"] = logs.MetricFilter(
                    self,
                    f"{construct_id}Filter{suffix}",
                    log_group=groups_by_purpose[purpose],
                    filter_pattern=logs.FilterPattern.literal(pattern),
                    metric_namespace=APP_NAMESPACE,
                    metric_name=metric_name,
                    metric_value="1",
                    # `$.env` from the record. CloudWatch Logs refuses `default_value`
                    # alongside dimensions — it would have to invent a dimension value for
                    # a record that did not match — so these metrics are *absent* rather
                    # than zero until the formatter lands, and every alarm on them is
                    # NOT_BREACHING so that absence reads as OK and not as a page.
                    dimensions={ENVIRONMENT_DIMENSION: "$.env"},
                )

        # Two of these are worth paging on by themselves; the rest are dashboard and
        # forensic material. A metric filter with no alarm is not waste — it is what makes
        # the dashboard answer "was it like this yesterday?".
        self._alarm(
            "PoolTimeoutAlarm",
            purpose="pool-timeout",
            metric=self._app_metric("PoolTimeout", period=Duration.minutes(5)),
            threshold=1,
            description=(
                "A request could not get a database connection from the pool. Connections "
                "are leaking or RDS is refusing them; check the rds-connections alarm "
                "next. NOTE: silent until the app emits JSON logs — see the tracker."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=1,
        )
        self._alarm(
            "PhiAuditWriteFailedAlarm",
            purpose="phi-audit-write-failed",
            metric=self._app_metric("PhiAuditWriteFailures", period=Duration.minutes(5)),
            threshold=1,
            description=(
                "An `audit.phi_access` row could not be written. PHI was accessed and the "
                "audit trail for it does not exist — 45 CFR 164.312(b). Treat as an "
                "incident, not a bug. NOTE: silent until the app emits JSON logs."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=1,
        )
        self._alarm(
            "AuthFailureSpike",
            purpose="auth-failure-spike",
            metric=self._app_metric("AuthFailures", period=Duration.minutes(5)),
            # Fifty in five minutes. Below that is people mistyping passwords; the prompt's
            # "auth-failure spike" control (API SECURITY → Detection) is about the shape of
            # a credential-stuffing run, not about a bad morning.
            threshold=50,
            description=(
                "More than 50 authentication or authorization failures in five minutes. "
                "Check the WAF log group for a single source before assuming it is real "
                "users. NOTE: silent until the app emits JSON logs."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            evaluation_periods=2,
            datapoints_to_alarm=2,
        )
        self._alarm(
            "UnusualExportVolume",
            purpose="unusual-export-volume",
            metric=self._app_metric("ArtifactDownloads", period=Duration.minutes(5)),
            threshold=EXPORT_VOLUME_THRESHOLD,
            description=(
                f"More than {EXPORT_VOLUME_THRESHOLD} artifact downloads in each of three "
                "consecutive five-minute windows — roughly three hundred files in a "
                "quarter of an hour. A period close pulls a burst and then stops; a "
                "sustained rate is a bulk extraction. Find the org and the actor in the "
                "api log group and treat it as a possible disclosure (CC6.7). NOTE: "
                "silent until the app emits JSON logs."
            ),
            treat_missing_data=cloudwatch.TreatMissingData.NOT_BREACHING,
            # Sustained, not spiky: 3 of 3. See EXPORT_VOLUME_THRESHOLD.
            evaluation_periods=3,
            datapoints_to_alarm=3,
        )

        # ---- the one alarm that fires when the metrics are ABSENT (critic P6R2-04)
        #
        # Everything above is NOT_BREACHING on missing data, which is right today and is
        # also a hole: if the JSON formatter never ships, or ships and then regresses, or
        # has `$.env` renamed under it, all four read OK for ever and nothing says so.
        # This is the mirror: `SampleCount` on a filter metric, `LESS_THAN` one, and
        # BREACHING on missing — so no datapoint at all is the ALARM state.
        #
        # It is behind `-c structuredLogsLive=true` and off by default because absence is
        # the expected state *until* the formatter deploys; arming it is part of that
        # change, not of this one. See STRUCTURED_LOGS_CONTEXT_FLAG and tracker row 46.
        if _flag_is_on(self.node.try_get_context(STRUCTURED_LOGS_CONTEXT_FLAG)):
            self._alarm(
                "StructuredLogHeartbeat",
                purpose="structured-logs-silent",
                metric=self._app_metric(
                    "HttpRequests",
                    statistic="SampleCount",
                    period=STRUCTURED_LOGS_HEARTBEAT_PERIOD,
                ),
                threshold=1,
                comparison=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
                description=(
                    "No `Meridian/App` log-filter datapoint in 24 hours. The application "
                    "has stopped emitting the JSON log contract (ADR 0024 §4), or a field "
                    "name has changed under the filters, or the `env` dimension is no "
                    "longer being written — and while that is true EVERY log-derived "
                    "alarm reads OK and cannot fire. Check that the api task is logging "
                    "JSON before assuming it is quiet: the metric counts every request, "
                    "health checks included, so a quiet day does not trip it."
                ),
                # The whole point: absent metric == broken pipeline.
                treat_missing_data=cloudwatch.TreatMissingData.BREACHING,
                evaluation_periods=1,
            )

        return filters

    # ------------------------------------------- the stop-schedule dead letters

    def _stop_schedule_routing(self) -> pipes.CfnPipe | None:
        """SQS → **an event bus** → two rules: page the unexpected, log the expected.

        ADR 0020 §7c named "an EventBridge Pipe filtered on `ERROR_CODE`" as Phase 6's
        durable fix for a queue no depth alarm can watch. The first build took that
        literally and put the filter on the **Pipe source**, which was wrong in a way worth
        writing down, because it is the obvious design:

        **A Pipe source filter does not route. It discards.** A message the filter does not
        match is dropped *and deleted from the queue* — Pipes polls, evaluates, and
        acknowledges either way. So the expected `InvalidDBInstanceState` messages, which
        are the evidence that a stop was *attempted and refused*, were consumed and thrown
        away. `scripts/staging_session.sh up` then drained a queue
        that was empty every time and printed nothing, and a schedule that had been
        silently disabled looked exactly like one that was working — which is the precise
        failure ADR 0020 §7c exists to prevent, reintroduced by its own fix.

        So: **no source filter at all.** Every dead letter is delivered, and the routing is
        done downstream where routing can be done without deleting anything:

        * `meridian-<env>-events-alerts` — a **custom** bus, not the default one. The
          default bus carries every AWS-service event in the account, and the account is
          shared (ADR 0001): a rule there is a rule evaluated against somebody else's
          traffic, and a `source` prefix is a convention rather than a boundary. A bus of
          our own costs nothing and is the boundary.
        * `meridian-<env>-rule-stop-dlq-unexpected` → the **alerts topic**. An unexpected
          failure is emailed within a minute instead of at the next session, which is the
          latency the Pipe was for.
        * `meridian-<env>-rule-stop-dlq-expected` → the **log group**
          `meridian-<env>-logs-stop-schedule`, on the `logs` CMK with the estate's 400-day
          retention. `staging_session.sh up` reads it with `aws logs filter-log-events`
          instead of draining SQS. A log group is the right shape for it in a way a queue
          never was: it is a *history*, so a session can ask "did it happen last night,
          and every night while the stack was up", where a drained queue could only ever
          answer once and then forget. (The 400 days is the estate's retention floor, not
          a window this group ever fills: in staging it is `DESTROY`d with the stack at
          the end of every session — see below.)

        The unexpected rule **also** targets the log group, so the script's "UNEXPECTED"
        reporting keeps working from the same single source and the operator does not have
        to correlate a mailbox with a console.

        **What this log group is evidence OF — and what it is not** (critic P6R2-02). A
        dead letter exists only when the stop was *attempted and refused*, which on a
        staging instance that was already stopped is the ordinary nightly case. A
        **successful** stop dead-letters nothing, so on the one night that matters most —
        the session ran late, the instance was up, the schedule stopped it — this log
        group is **empty**, and a script that treated empty as "nothing ran" warned about
        a schedule that had just done its job. So the log group is the confirmation for
        the **refusal** case only. The positive confirmation of a successful stop is RDS's
        own event stream, and `staging_session.sh up` reads it there:

            aws rds describe-events --source-identifier meridian-staging-rds-main \\
              --source-type db-instance --duration 2160 --event-categories availability

        — "DB instance stopped" in the last 36 hours. `up` warns only when **neither**
        that event nor a log-group line exists, which is the only state that actually
        means the schedule did not run. `rds:DescribeEvents` is therefore in the script
        header's operator-permissions list; CloudTrail `lookup-events` on `StopDBInstance`
        would answer the same question and was not chosen, because it needs a permission
        the operator does not otherwise have and `describe-events` needs none beyond RDS.

        The unexpected pattern is an `$or`, and the second branch is not redundant:
        `anything-but` does **not** match a record where the field is absent, so a
        dead-lettered invocation with no `ERROR_CODE` at all — a malformed target, a
        Scheduler failure before the API call — would have matched neither rule and
        vanished. `{"exists": false}` on the same leaf is what makes "no code" count as
        unexpected, which is the safe reading.

        The staging log group is `DESTROY`, not `RETAIN`: this stack is destroyed at the
        end of every session (ADR 0008 / D-15) and a retained log group would block the
        next deploy on "a log group with this name already exists". The DLQ's own
        one-day retention means the window that matters — last night — survives the gap
        anyway: the Pipe drains it into the fresh log group within seconds of `up`.
        """
        queue = self.data.stop_dlq
        if queue is None:
            # Production has no stop schedule, so no DLQ, no bus, no rules and no Pipe.
            return None

        # ---- the bus
        self.stop_event_bus = events.EventBus(
            self,
            "StopEventBus",
            event_bus_name=resource_name(self.env_name, "events", "alerts"),
            description=(
                "Stop-schedule dead letters, delivered by the Pipe and routed by two "
                "rules. A bus of our own: the default bus is shared with the other owner "
                "of this account (ADR 0001)."
            ),
        )

        # ---- the log group the expected case lands in
        log_group = logs.LogGroup(
            self,
            "StopScheduleLog",
            log_group_name=resource_name(self.env_name, "logs", "stop-schedule"),
            retention=STOP_SCHEDULE_LOG_RETENTION,
            encryption_key=self.data.keys["logs"],
            # Destroyed with the stack in staging; see the docstring. Production never
            # reaches this line (it has no DLQ), and RETAIN is the safe branch anyway.
            removal_policy=(
                RemovalPolicy.DESTROY
                if self.env_config.destroyed_between_phases
                else RemovalPolicy.RETAIN
            ),
        )
        # An error code and a timestamp. No row, no identifier.
        Tags.of(log_group).add("DataClassification", "internal")
        self.stop_schedule_log_group = log_group

        log_group_arn = self.format_arn(
            service="logs",
            resource="log-group",
            resource_name=log_group.log_group_name,
            arn_format=ArnFormat.COLON_RESOURCE_NAME,
        )
        # EventBridge writes into a log group through a **resource** policy, not through a
        # role. `AWS::Logs::ResourcePolicy` is a plain CloudFormation resource; the CDK
        # target construct that would write it uses a Lambda-backed custom resource
        # instead — see `_PlainRuleTarget` (critic P6R2-07: this comment used to name a
        # class that does not exist).
        #
        # **Two principals, no condition** — this is AWS's documented policy for a log
        # group that is an EventBridge rule target, copied rather than improvised
        # (critic P6R2-03):
        #
        #     "Principal": {"Service": ["events.amazonaws.com",
        #                               "delivery.logs.amazonaws.com"]},
        #     "Action": ["logs:CreateLogStream", "logs:PutLogEvents"],
        #
        # https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-use-resource-based.html#eb-cloudwatchlogs-permissions
        #
        # `delivery.logs.amazonaws.com` is the principal the delivery path actually writes
        # as — CDK's own `CloudWatchLogGroup` target puts both into the policy it
        # generates — and the first build named only `events.amazonaws.com`, so the
        # expected nightly refusal could have been dropped on the floor by the delivery
        # side with nothing to show for it. The AWS example carries **no** `Condition`,
        # and the first build's `aws:SourceAccount` was an improvisation on top of it; a
        # condition the writing service may not populate is a silent deny, and silence
        # here is exactly the failure ADR 0020 §7c exists to prevent. The boundary that
        # remains is the resource: the ARN is this account's log group and nothing else.
        logs.ResourcePolicy(
            self,
            "StopScheduleLogPolicy",
            resource_policy_name=resource_name(self.env_name, "logs", "stop-schedule"),
            policy_statements=[
                iam.PolicyStatement(
                    sid="AllowEventBridgeToWriteHere",
                    principals=[
                        iam.ServicePrincipal("events.amazonaws.com"),
                        iam.ServicePrincipal("delivery.logs.amazonaws.com"),
                    ],
                    actions=["logs:PutLogEvents", "logs:CreateLogStream"],
                    resources=[f"{log_group_arn}:*"],
                )
            ],
        )
        log_target = _PlainRuleTarget(log_group, arn=log_group_arn)

        # ---- rule 1: anything that is not the expected refusal, including no code at all
        unexpected = self._event_rule_to_topic(
            "StopDlqUnexpected",
            purpose="stop-dlq-unexpected",
            description=(
                "A stop-schedule invocation dead-lettered for a reason that is NOT the "
                f"expected {STOP_DLQ_EXPECTED_ERROR}, or with no error code at all. The "
                "nightly stop is not working. ADR 0020 §7c, ADR 0024 §5."
            ),
            event_pattern=events.EventPattern(
                source=[STOP_EVENT_SOURCE],
                detail={
                    "$or": [
                        {
                            "messageAttributes": {
                                STOP_DLQ_ERROR_ATTRIBUTE: {
                                    "stringValue": [{"anything-but": [STOP_DLQ_EXPECTED_ERROR]}]
                                }
                            }
                        },
                        # `anything-but` does not match an ABSENT field. Without this
                        # branch a dead letter with no ERROR_CODE matches neither rule.
                        {
                            "messageAttributes": {
                                STOP_DLQ_ERROR_ATTRIBUTE: {"stringValue": [{"exists": False}]}
                            }
                        },
                    ]
                },
            ),
            event_bus=self.stop_event_bus,
        )
        # Also to the log group, so that `staging_session.sh` reads one place.
        unexpected.add_target(log_target)

        # ---- rule 2: the expected refusal, to the log group only. Never to the topic:
        # an email every night for a cost control working as designed is how a mailbox
        # filter gets written, and a filtered mailbox is how the real failure is missed.
        expected = events.Rule(
            self,
            "StopDlqExpected",
            rule_name=resource_name(self.env_name, "rule", "stop-dlq-expected"),
            event_bus=self.stop_event_bus,
            description=(
                "The expected nightly refusal: the staging instance was already stopped. "
                "Logged, never emailed — it is the positive confirmation that the "
                "schedule ran, which `scripts/staging_session.sh up` reads."
            ),
            event_pattern=events.EventPattern(
                source=[STOP_EVENT_SOURCE],
                detail={
                    "messageAttributes": {
                        STOP_DLQ_ERROR_ATTRIBUTE: {"stringValue": [STOP_DLQ_EXPECTED_ERROR]}
                    }
                },
            ),
        )
        expected.add_target(log_target)

        # ---- the Pipe itself
        role = iam.Role(
            self,
            "StopDlqPipeRole",
            role_name=resource_name(self.env_name, "iam", "stop-dlq-pipe"),
            assumed_by=iam.ServicePrincipal(
                "pipes.amazonaws.com",
                # The same confused-deputy guard the Scheduler role carries (ADR 0020
                # §12a): both ARNs are derivable from the naming convention.
                conditions={"StringEquals": {"aws:SourceAccount": Aws.ACCOUNT_ID}},
            ),
            description="EventBridge Pipe: stop-schedule DLQ onto the alerts event bus.",
        )
        # Source: this one queue, these three actions. `grant_consume_messages` would also
        # grant `sqs:ChangeMessageVisibility` on a queue the pipe never needs to extend.
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadThisQueueOnly",
                actions=[
                    "sqs:ReceiveMessage",
                    "sqs:DeleteMessage",
                    "sqs:GetQueueAttributes",
                ],
                resources=[queue.queue_arn],
            )
        )
        # The queue is KMS-encrypted with the `logs` key, so receiving is also a Decrypt.
        self.data.keys["logs"].grant_decrypt(role)
        # Target: this one bus. The Pipe no longer publishes to SNS at all — the rule does
        # — so the role has no `sns:Publish` and the topic policy needs nothing for pipes.
        self.stop_event_bus.grant_put_events_to(role)

        return pipes.CfnPipe(
            self,
            "StopDlqPipe",
            name=resource_name(self.env_name, "pipe", "stop-dlq"),
            description=(
                "Delivers EVERY stop-schedule dead-letter message to "
                f"{resource_name(self.env_name, 'events', 'alerts')}. It does not filter: "
                "a Pipe source filter deletes what it does not match, and the expected "
                "message is the evidence. ADR 0024 §5."
            ),
            role_arn=role.role_arn,
            source=queue.queue_arn,
            target=self.stop_event_bus.event_bus_arn,
            source_parameters=pipes.CfnPipe.PipeSourceParametersProperty(
                # **No `filter_criteria`.** See the docstring: a source filter discards.
                sqs_queue_parameters=pipes.CfnPipe.PipeSourceSqsQueueParametersProperty(
                    # One at a time: each message is one failed invocation and one event.
                    # A batch of ten would arrive as one event containing ten, which is
                    # harder to read at 3am, not easier.
                    batch_size=1,
                    maximum_batching_window_in_seconds=0,
                ),
            ),
            target_parameters=pipes.CfnPipe.PipeTargetParametersProperty(
                event_bridge_event_bus_parameters=(
                    pipes.CfnPipe.PipeTargetEventBridgeEventBusParametersProperty(
                        # Not `aws.*`: EventBridge reserves that prefix and refuses the
                        # PutEvents outright.
                        source=STOP_EVENT_SOURCE,
                        detail_type=STOP_EVENT_DETAIL_TYPE,
                    )
                )
            ),
        )

    # -------------------------------------------------------------------- canary

    def _canary(self) -> synthetics.Canary | None:
        """A Synthetics canary on the public health endpoint, behind a cost flag.

        **Off by default in both environments.** ~8,640 runs a month at ≈ $0.0012 a run is
        ≈ $10.40 per environment per month, against ≈ $11 of headroom in
        `docs/reports/phase-1-cost-estimate.md` §3. That is a spend decision, and a stack
        does not get to make one — `-c enableCanary=true` is how it is made, and the
        tracker carries the approval row.

        What it buys that the ALB health check does not: the ALB checks from *inside* the
        VPC, so it is green when CloudFront is broken, when the certificate has expired,
        when DNS is wrong, and when the origin-verify header has been half-rotated. The
        canary checks the same path a person would, from outside, through everything.

        It has no VPC configuration on purpose — a canary inside the VPC would bypass
        CloudFront and test less than the ALB health check already does.
        """
        if not _flag_is_on(self.node.try_get_context(CANARY_CONTEXT_FLAG)):
            return None

        # Synthetics caps a canary's physical name at **21 characters** and prefixes it
        # with `cwsyn-`, so `meridian-<env>-canary-health` (28) cannot be the name — the
        # estate's `meridian-<env>-<component>-<purpose>` convention is **abandoned here**,
        # not truncated by AWS, and this is the one resource in the estate where it does
        # not hold. The name is built once, into this variable, and every reference —
        # including the role's log-group ARN below — is derived from it. It used to be
        # written out a second time in the policy, and the two spellings had already
        # drifted: the role scoped `<env>-health` while the canary was created as something
        # else, so the canary could not write its own logs.
        canary_name = log_group_names.canary_name(self.env_name)
        # Staging's observability stack is destroyed between phases (ADR 0008 / D-15), and
        # this bucket has a **fixed name**: RETAIN leaves it behind, and the next `up`
        # fails on "bucket already exists" on a bucket that holds thirty-day-old
        # screenshots of a health endpoint. Production keeps RETAIN, because a production
        # bucket is never deleted by a script.
        transient = self.env_config.destroyed_between_phases

        bucket = s3.Bucket(
            self,
            "CanaryArtifacts",
            bucket_name=resource_name(self.env_name, "s3", "canary-artifacts"),
            encryption=s3.BucketEncryption.KMS,
            encryption_key=self.data.keys["logs"],
            bucket_key_enabled=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            enforce_ssl=True,
            object_ownership=s3.ObjectOwnership.BUCKET_OWNER_ENFORCED,
            versioned=True,
            removal_policy=RemovalPolicy.DESTROY if transient else RemovalPolicy.RETAIN,
            # A versioned bucket is not empty when CloudFormation asks S3 to delete it, so
            # DESTROY alone leaves the stack stuck in DELETE_FAILED. Only in the transient
            # environment, and only for screenshots of `{"status":"ok"}`.
            auto_delete_objects=transient,
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="expire-canary-artifacts",
                    enabled=True,
                    expiration=CANARY_ARTIFACT_RETENTION,
                    noncurrent_version_expiration=CANARY_ARTIFACT_RETENTION,
                    abort_incomplete_multipart_upload_after=Duration.days(7),
                )
            ],
        )
        # Screenshots of a health endpoint: no session, no identifier, no PHI.
        Tags.of(bucket).add("DataClassification", "internal")

        role = iam.Role(
            self,
            "CanaryRole",
            role_name=resource_name(self.env_name, "iam", "canary"),
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            description="Synthetics canary: write artifacts and its own logs, nothing else.",
        )
        # Scoped by hand rather than with a managed policy. `CloudWatchSyntheticsFullAccess`
        # is `s3:*` on every bucket in the account, in an account shared with another owner.
        role.add_to_policy(
            iam.PolicyStatement(
                sid="WriteArtifactsToThisBucketOnly",
                actions=["s3:PutObject", "s3:GetBucketLocation", "s3:AbortMultipartUpload"],
                resources=[bucket.bucket_arn, bucket.arn_for_objects("*")],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="OwnLogGroupOnly",
                actions=["logs:CreateLogStream", "logs:PutLogEvents", "logs:CreateLogGroup"],
                # Built from `canary_name`, the same variable the canary is created with.
                # Two spellings of one name is how a canary ends up unable to log.
                resources=[
                    f"arn:{Aws.PARTITION}:logs:{Aws.REGION}:{Aws.ACCOUNT_ID}:"
                    f"log-group:/aws/lambda/cwsyn-{canary_name}-*"
                ],
            )
        )
        # **The one documented `Resource: "*"` in this stack.** `s3:ListAllMyBuckets` and
        # `cloudwatch:PutMetricData` have no resource-level permission at all — IAM rejects
        # any ARN on either — so a narrower statement is not possible, only a wrong one.
        # `PutMetricData` is confined with a namespace condition instead, which is the
        # documented substitute; `ListAllMyBuckets` returns bucket *names*, which are
        # already in this file.
        role.add_to_policy(
            iam.PolicyStatement(
                sid="ActionsWithNoResourceLevelPermission",
                actions=["s3:ListAllMyBuckets"],
                resources=["*"],
            )
        )
        role.add_to_policy(
            iam.PolicyStatement(
                sid="PublishCanaryMetricsOnly",
                actions=["cloudwatch:PutMetricData"],
                resources=["*"],
                conditions={"StringEquals": {"cloudwatch:namespace": "CloudWatchSynthetics"}},
            )
        )
        self.data.keys["logs"].grant_encrypt_decrypt(role)

        canary = synthetics.Canary(
            self,
            "HealthCanary",
            # The 21-character cap. See `canary_name` above for why the estate naming
            # convention is abandoned for this one resource rather than truncated.
            canary_name=canary_name,
            runtime=CANARY_RUNTIME,
            schedule=synthetics.Schedule.rate(CANARY_RATE),
            role=role,
            artifacts_bucket_location=synthetics.ArtifactsBucketLocation(
                bucket=bucket, prefix="canary"
            ),
            artifact_s3_encryption_mode=synthetics.ArtifactsEncryptionMode.KMS,
            artifact_s3_kms_key=self.data.keys["logs"],
            # 30 days on the artifacts themselves, matching the bucket lifecycle. Two
            # places, because Synthetics expires its own records independently of S3.
            success_retention_period=CANARY_ARTIFACT_RETENTION,
            failure_retention_period=CANARY_ARTIFACT_RETENTION,
            # Well inside the 5-minute interval: a canary that overruns its schedule
            # silently skips runs.
            timeout=Duration.seconds(60),
            start_after_creation=True,
            test=synthetics.Test.custom(
                handler="index.handler",
                code=synthetics.Code.from_inline(self._canary_script()),
            ),
        )

        self._alarm(
            "CanaryFailed",
            purpose="canary-failed",
            metric=canary.metric_success_percent(statistic="Average", period=Duration.minutes(5)),
            threshold=100,
            comparison=cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
            description=(
                f"The health canary could not fetch {HEALTH_PATH} from the public "
                "internet. Unlike the ALB health check this crosses DNS, the certificate, "
                "CloudFront, the WAF and the origin-verify header — so check those before "
                "the application."
            ),
            # A canary that has stopped running is a canary that cannot tell you anything,
            # which is the same as a failure.
            treat_missing_data=cloudwatch.TreatMissingData.BREACHING,
            # Two consecutive 5-minute windows: one missed run is a transient.
            evaluation_periods=2,
            datapoints_to_alarm=2,
        )
        return canary

    def _canary_script(self) -> str:
        """The canary body: one GET, status and shape checked, nothing logged.

        Inline rather than a bundled asset because it is eleven lines and an asset would
        put the canary's behaviour in a second file that no test reads. It deliberately
        does **not** log the response body: `/api/v1/health` returns no identifier today,
        but a canary artifact is a file in S3 for thirty days and the endpoint's contract
        can change without anyone thinking about this script.
        """
        url = f"https://{self.edge.public_hostname}{HEALTH_PATH}"
        return f"""
const synthetics = require('Synthetics');
const log = require('SyntheticsLogger');

const apiCanary = async function () {{
  const page = await synthetics.getPage();
  const response = await page.goto('{url}', {{
    waitUntil: 'domcontentloaded',
    timeout: 30000,
  }});
  if (!response) {{
    throw new Error('No response from the health endpoint');
  }}
  if (response.status() !== 200) {{
    // The status only. The body is never logged: see _canary_script.
    throw new Error('Health endpoint returned ' + response.status());
  }}
  log.info('Health endpoint answered 200');
}};

exports.handler = async () => {{
  return await apiCanary();
}};
"""

    # ----------------------------------------------------------------- dashboard

    def _dashboard(self) -> cloudwatch.Dashboard:
        """One dashboard per environment, laid out as the four golden signals.

        Latency, traffic, errors, saturation — in that order, because that is the order
        somebody reads them in during an incident: how slow, how much, how broken, how
        full. Then the things that are not request-shaped: the Lambda, backups, and a
        security row.

        **No widget shows a log line.** `LogQueryWidget` is deliberately absent from this
        file: a dashboard is the most-screenshotted surface in the estate, and a log query
        widget renders raw log *bodies* into it. The log-derived numbers below are counts
        from the metric filters, which carry no text. A test asserts the absence.
        """
        alb = self.edge.alb
        function_name = resource_name(self.env_name, "lambda", "user-migration")

        dashboard = cloudwatch.Dashboard(
            self,
            "Dashboard",
            dashboard_name=resource_name(self.env_name, "dashboard", "golden-signals"),
            # Three hours: long enough to see the shape of an incident, short enough that
            # the widgets are not averaging it away.
            start="-PT3H",
        )

        dashboard.add_widgets(
            cloudwatch.TextWidget(
                markdown=(
                    f"# Meridian {self.env_name} — golden signals\n"
                    "Latency · traffic · errors · saturation, then the Lambda, backups and "
                    "security.\n\n"
                    "Counts in the **errors** row come from log metric filters and have "
                    "**no data until the application emits JSON logs** "
                    "(`docs/migration-tracker.md`). An empty graph there is not yet "
                    "evidence of health. They are dimensioned on "
                    f"`Environment={self.env_name}`, so this dashboard never shows the "
                    "other environment's numbers.\n\n"
                    "Alarm meanings and first actions: `docs/runbooks/alerts.md`."
                ),
                width=24,
                height=4,
            )
        )

        # ---- latency
        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="Latency — ALB target response time",
                left=[
                    alb.metrics.target_response_time(statistic="p50", label="p50"),
                    alb.metrics.target_response_time(statistic="p95", label="p95"),
                    alb.metrics.target_response_time(statistic="p99", label="p99"),
                ],
                left_annotations=[
                    cloudwatch.HorizontalAnnotation(
                        value=LATENCY_P95_SECONDS, label="p95 alarm", color=cloudwatch.Color.RED
                    )
                ],
                width=12,
                height=6,
            ),
            cloudwatch.GraphWidget(
                title="Latency — RDS read/write",
                left=[
                    self.data.database.metric("ReadLatency", statistic="Average", label="read"),
                    self.data.database.metric("WriteLatency", statistic="Average", label="write"),
                ],
                width=12,
                height=6,
            ),
        )

        # ---- traffic
        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="Traffic — ALB requests",
                left=[alb.metrics.request_count(statistic="Sum", label="requests")],
                width=8,
                height=6,
            ),
            cloudwatch.GraphWidget(
                title="Traffic — CloudFront",
                left=[
                    cloudwatch.Metric(
                        namespace=CLOUDFRONT_NAMESPACE,
                        metric_name="Requests",
                        dimensions_map={
                            "DistributionId": self.edge.distribution.distribution_id,
                            "Region": "Global",
                        },
                        statistic="Sum",
                        label="requests",
                    )
                ],
                width=8,
                height=6,
            ),
            cloudwatch.GraphWidget(
                title="Traffic — per target group",
                left=[
                    self.edge.api_target_group.metrics.request_count(statistic="Sum", label="api"),
                    self.edge.web_target_group.metrics.request_count(statistic="Sum", label="web"),
                ],
                width=8,
                height=6,
            ),
        )

        # ---- errors
        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="Errors — ALB and target 5xx",
                left=[
                    alb.metrics.http_code_elb(
                        elbv2.HttpCodeElb.ELB_5XX_COUNT, statistic="Sum", label="elb 5xx"
                    ),
                    alb.metrics.http_code_target(
                        elbv2.HttpCodeTarget.TARGET_5XX_COUNT, statistic="Sum", label="target 5xx"
                    ),
                ],
                width=8,
                height=6,
            ),
            cloudwatch.GraphWidget(
                title="Errors — CloudFront 5xx rate (%)",
                left=[
                    cloudwatch.Metric(
                        namespace=CLOUDFRONT_NAMESPACE,
                        metric_name="5xxErrorRate",
                        dimensions_map={
                            "DistributionId": self.edge.distribution.distribution_id,
                            "Region": "Global",
                        },
                        statistic="Average",
                        label="5xx rate",
                    )
                ],
                width=8,
                height=6,
            ),
            cloudwatch.GraphWidget(
                title="Errors — from the log metric filters (counts only, no log bodies)",
                left=[
                    # `_app_metric`, so every series is pinned to this environment. A
                    # dimensionless read here would draw staging and production as one
                    # line, which is worse than drawing nothing.
                    self._app_metric(name, label=name)
                    for name in (
                        "FiveXxResponses",
                        "UnhandledExceptions",
                        "PoolTimeout",
                        "PgWriteRefused",
                        "CompensatingDeleteIncomplete",
                        "AuthFailures",
                        "PhiAuditWriteFailures",
                    )
                ],
                width=8,
                height=6,
            ),
        )

        # ---- saturation
        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="Saturation — ECS CPU / memory",
                left=[
                    self.compute.api_service.metric_cpu_utilization(label="api cpu"),
                    self.compute.web_service.metric_cpu_utilization(label="web cpu"),
                ],
                right=[
                    self.compute.api_service.metric_memory_utilization(label="api mem"),
                    self.compute.web_service.metric_memory_utilization(label="web mem"),
                ],
                width=8,
                height=6,
            ),
            cloudwatch.GraphWidget(
                title="Saturation — RDS",
                left=[self.data.database.metric_cpu_utilization(label="cpu %")],
                right=[
                    self.data.database.metric_database_connections(label="connections"),
                    self.data.database.metric_freeable_memory(label="freeable memory"),
                ],
                right_annotations=[
                    cloudwatch.HorizontalAnnotation(
                        value=int(self._max_connections() * CONNECTION_HEADROOM),
                        label="connection alarm",
                        color=cloudwatch.Color.RED,
                    )
                ],
                width=8,
                height=6,
            ),
            cloudwatch.GraphWidget(
                title="Saturation — healthy hosts and RDS storage",
                left=[
                    self.edge.api_target_group.metrics.healthy_host_count(
                        statistic="Minimum", label="api healthy"
                    ),
                    self.edge.web_target_group.metrics.healthy_host_count(
                        statistic="Minimum", label="web healthy"
                    ),
                ],
                right=[
                    self.data.database.metric_free_storage_space(
                        statistic="Minimum", label="free storage"
                    )
                ],
                width=8,
                height=6,
            ),
        )

        # ---- the pieces that are not request-shaped
        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="User Migration Lambda",
                left=[
                    cloudwatch.Metric(
                        namespace=LAMBDA_NAMESPACE,
                        metric_name="Errors",
                        dimensions_map={"FunctionName": function_name},
                        statistic="Sum",
                        label="errors",
                    ),
                    cloudwatch.Metric(
                        namespace=LAMBDA_NAMESPACE,
                        metric_name="Invocations",
                        dimensions_map={"FunctionName": function_name},
                        statistic="Sum",
                        label="invocations",
                    ),
                ],
                right=[
                    cloudwatch.Metric(
                        namespace=LAMBDA_NAMESPACE,
                        metric_name="Duration",
                        dimensions_map={"FunctionName": function_name},
                        statistic="p99",
                        label="p99 ms (5s budget)",
                    )
                ],
                right_annotations=[
                    cloudwatch.HorizontalAnnotation(
                        value=LAMBDA_DURATION_BUDGET_MS,
                        label="Cognito budget",
                        color=cloudwatch.Color.RED,
                    )
                ],
                width=12,
                height=6,
            ),
            cloudwatch.GraphWidget(
                title="Backups — jobs by outcome (account-wide; AWS Backup has no vault dimension)",
                left=[
                    cloudwatch.Metric(
                        namespace="AWS/Backup",
                        metric_name=metric_name,
                        statistic="Sum",
                        label=label,
                    )
                    for metric_name, label in (
                        ("NumberOfBackupJobsCompleted", "completed"),
                        ("NumberOfBackupJobsFailed", "failed"),
                        ("NumberOfCopyJobsFailed", "copy failed"),
                    )
                ],
                width=12,
                height=6,
            ),
        )

        # ---- security
        #
        # **Two widgets were removed here and it is worth saying why, because both look
        # like obvious additions.**
        #
        # *Security Hub.* There is no `AWS/SecurityHub` CloudWatch namespace. Security Hub
        # publishes findings to EventBridge, not metrics to CloudWatch, so the widget that
        # used to be here rendered an empty graph for ever — a blank chart under a
        # security heading, which reads as "no findings". The finding *rule* in
        # `_account_finding_rules` is the real control; the dashboard does not get to
        # imply a second one.
        #
        # *GuardDuty.* `AWS/GuardDuty` does exist, but `FindingCount` is published **per
        # detector** and is meaningless without the `DetectorId` dimension — a
        # dimensionless read returns nothing. The detector is created once for the account
        # by `meridian-shared-foundation`, and this stack cannot import its id without
        # making a never-destroyed shared stack a dependency of a stack that is destroyed
        # every session (ADR 0008 / D-15). So it is passed in: `-c guardDutyDetectorId=<id>`
        # renders the widget, and **without the flag the widget is simply not there**. An
        # absent widget is honest; an empty one is not.
        security_widgets: list[cloudwatch.IWidget] = [
            cloudwatch.GraphWidget(
                title="Security — WAF",
                left=[
                    cloudwatch.Metric(
                        namespace=WAF_NAMESPACE,
                        metric_name=metric_name,
                        dimensions_map={
                            "WebACL": self.edge.web_acl.name or "",
                            "Rule": "ALL",
                            "Region": "Global",
                        },
                        statistic="Sum",
                        label=label,
                    )
                    for metric_name, label in (
                        ("BlockedRequests", "blocked"),
                        ("AllowedRequests", "allowed"),
                        ("CountedRequests", "counted"),
                    )
                ],
                width=8,
                height=6,
            ),
        ]

        detector_id = self.node.try_get_context(GUARD_DUTY_DETECTOR_CONTEXT)
        if detector_id:
            security_widgets.append(
                cloudwatch.GraphWidget(
                    title="Security — GuardDuty findings (account-wide, ADR 0001)",
                    left=[
                        cloudwatch.Metric(
                            namespace="AWS/GuardDuty",
                            metric_name="FindingCount",
                            # Required. Without it the metric does not exist.
                            dimensions_map={"DetectorId": str(detector_id)},
                            statistic="Sum",
                            label="findings",
                        )
                    ],
                    width=8,
                    height=6,
                )
            )

        security_widgets.append(
            cloudwatch.GraphWidget(
                title="Security — auth failures and artifact downloads (log filters)",
                left=[
                    self._app_metric("AuthFailures", label="auth failures"),
                    self._app_metric("ArtifactDownloads", label="artifact downloads"),
                ],
                width=8,
                height=6,
            )
        )
        dashboard.add_widgets(*security_widgets)

        # The alarm carpet. Every alarm this stack owns, in one widget, so that "what is
        # red right now" is one glance rather than a tour of the CloudWatch console.
        dashboard.add_widgets(
            cloudwatch.AlarmStatusWidget(
                title="Every alarm in this environment",
                alarms=self.alarms,
                width=24,
                height=max(3, 1 + len(self.alarms) // 6),
            )
        )
        return dashboard

    # ------------------------------------------------------------------- outputs

    def _outputs(self) -> None:
        CfnOutput(
            self,
            "AlertsTopicArn",
            value=self.topic.topic_arn,
            description=(
                "Subscribe a human to this by hand, once, and confirm the email. Until "
                "somebody does, every alarm here fires into nothing."
            ),
        )
        CfnOutput(
            self,
            "DashboardName",
            value=self.dashboard.dashboard_name,
            description="CloudWatch dashboard: the golden signals for this environment.",
        )
        CfnOutput(
            self,
            "AlarmCount",
            value=str(len(self.alarms)),
            description="How many alarms this environment has. docs/runbooks/alerts.md.",
        )
