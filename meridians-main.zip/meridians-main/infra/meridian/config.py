"""Per-environment settings that the stacks read.

Everything here is a *shape* decision, not a secret and not an identifier. No
account id, no ARN of anything that already exists, no connection string. Real
values that vary per deploy (the alert email, the conformance-pack template
location) come from CDK context or a CloudFormation parameter.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from .naming import ENVIRONMENTS


@dataclass(frozen=True)
class EnvConfig:
    """One environment's knobs."""

    #: `staging` or `production`.
    name: str
    #: Budget alarm: notify at this actual spend, in USD.
    budget_warn_usd: int
    #: Budget limit, in USD. Forecast crossing it notifies too.
    budget_limit_usd: int
    #: Retained for the data stack (D-15): staging is destroyed between phases,
    #: production never is, so removal policies and deletion protection differ.
    destroyed_between_phases: bool
    #: The RDS instance class (plan §3 Phase 3 step 6, D-14). `db.t4g.small` in
    #: production, `db.t4g.micro` in staging — a Graviton burstable, the cheapest
    #: thing that runs PostgreSQL 17 with a real backup story.
    db_instance_type: str
    #: **Performance Insights, on in both environments.** An earlier note here claimed
    #: AWS does not support it on `db.t4g.micro` / `db.t4g.small`. That is a MySQL and
    #: MariaDB rule, not a PostgreSQL one (H-3): `aws rds
    #: describe-orderable-db-instance-options --engine postgres --engine-version 17`
    #: lists both classes with `SupportsPerformanceInsights: true`. The free tier —
    #: 7 days of retention, default metrics — costs $0/month, and it is the only view of
    #: which statement is holding the single burstable vCPU during a revenue run.
    #: Encrypted with the environment's `rds` CMK, because the dashboard shows SQL text.
    performance_insights: bool = True


#: Plan §5 and Phase 1 step 7: production $150/$250, staging $30/$75.
ENV_CONFIG: dict[str, EnvConfig] = {
    "staging": EnvConfig(
        name="staging",
        budget_warn_usd=30,
        budget_limit_usd=75,
        destroyed_between_phases=True,
        # ponytail: t3, not t4g — db.t4g.micro is not orderable for postgres in this
        # account/region (2026-10-03, describe-orderable-db-instance-options returns 0).
        # Same 1 GiB / 2 vCPU burstable, ~$0.002/h more. Retry t4g.micro if AWS offers it.
        db_instance_type="t3.micro",
    ),
    "production": EnvConfig(
        name="production",
        budget_warn_usd=150,
        budget_limit_usd=250,
        destroyed_between_phases=False,
        db_instance_type="t4g.small",
    ),
}

#: The registered domain every environment's web addresses sit under. `-c domain=...`
#: overrides it for a test zone (`stacks/dns.py`, `stacks/edge.py`).
DEFAULT_DOMAIN = "meridiansgrp.com"


@dataclass(frozen=True)
class SiteHosts:
    """One environment's web addresses (ADR 0050 — www / app / api).

    * `app` — the Meridian app: sign-in, dashboard, processes, settings, `/api/v2`,
      `/auth/*`. Every link the backend builds (e-mail, OAuth and QuickBooks
      callbacks) points here.
    * `api` — the partner API only: `/v3/...` (rewritten at the edge to the backend's
      `/api/v3/...`) and `/api/v3/...` as-is. Anything else answers 404.
    * `www` — the public website only (the Next.js `(marketing)` route group). Any
      other path on it is a permanent redirect to the same path on `app`. `None` in
      staging: there the marketing pages are served on `app`, unsplit.
    * `apex` — the bare domain; a permanent redirect to `www`, nothing more. `None`
      in staging.
    """

    app: str
    api: str
    www: str | None = None
    apex: str | None = None

    @property
    def viewer_aliases(self) -> list[str]:
        """Every name CloudFront answers for, apex first (a fixed order)."""
        return [host for host in (self.apex, self.www, self.app, self.api) if host]

    @property
    def cutover_aliases(self) -> list[str]:
        """The names Render answers for today. Their DNS moves at Phase 9, not before."""
        return [host for host in (self.apex, self.www) if host]

    @property
    def new_aliases(self) -> list[str]:
        """Names nothing resolves today, so their DNS can point at AWS early."""
        return [self.app, self.api]


def site_hosts(env_name: str, domain: str = DEFAULT_DOMAIN) -> SiteHosts:
    """The web addresses of `env_name` under `domain` (ADR 0050).

    | Environment | apex | www | app | api |
    |---|---|---|---|---|
    | production | `meridiansgrp.com` → www | `www.` | `app.` | `api.` |
    | staging | — | — (marketing on `staging-app.`) | `staging-app.` | `staging-api.` |

    `origin-<env>.<domain>` is not here: it is CloudFront's origin name, not a
    viewer-facing one (`EdgeStack.origin_host`).
    """
    assert_known_env(env_name)
    if env_name == "production":
        return SiteHosts(app=f"app.{domain}", api=f"api.{domain}", www=f"www.{domain}", apex=domain)
    return SiteHosts(app=f"{env_name}-app.{domain}", api=f"{env_name}-api.{domain}")


#: Plan §5: the whole-account ceiling is ~$250/mo for Meridian; $300 is the
#: "something is wrong" line, and it covers the other owner's spend too
#: (ADR 0001 — one bill, shared account), so it is deliberately not the sum of
#: the two environment budgets.
ACCOUNT_BUDGET_USD = 300

#: Cost Anomaly Detection: report an anomaly whose total unexpected impact is at
#: least this many dollars. **Absolute, not a percentage** — a percentage threshold
#: on a ~$40/month account fires on rounding. $20 is about 8 % of the ~$250 ceiling
#: and roughly half a month of an accidentally-standing NAT gateway.
ANOMALY_THRESHOLD_USD = 20

#: The GitHub repository whose OIDC tokens the CI roles trust.
GITHUB_REPO = "andressbj45/meridians"

#: The header CloudFront adds to every origin request and the ALB insists on
#: (ADR 0015, ADR 0018). It lives here rather than in `stacks/edge.py` because
#: the **data** stack owns the secret behind it (it has to survive a staging
#: teardown) and the **edge** stack owns both ends that use it; a constant in
#: either stack would make the other import it.
ORIGIN_VERIFY_HEADER = "X-Origin-Verify"

#: Secrets Manager staging labels. `AWSCURRENT` is whatever `put-secret-value`
#: wrote last; `AWSPREVIOUS` is the value it displaced. They are *labels*, not
#: versions: they move when the secret is rotated.
#:
#: **Neither end of the origin-verify header may keep using them past the first
#: deploy** (finding H-F). A label renders the same `{{resolve:...}}` template text at
#: every rotation, and CloudFormation only re-resolves a property whose text changed —
#: so a labelled listener rule silently keeps the value it was given on the deploy that
#: first wrote it, while CloudFront's pinned version id moves. They survive here only
#: as the values the *first* deploy uses, when no version id exists yet to name, and so
#: that `_origin_verify_reference` can tell a label from a uuid.
#: See `docs/runbooks/rotate-origin-verify-secret.md`.
SECRET_STAGE_CURRENT = "AWSCURRENT"  # noqa: S105 a name, not a secret
SECRET_STAGE_PREVIOUS = "AWSPREVIOUS"  # noqa: S105 a name, not a secret

#: Tag defaults. `Owner` is a role, not a person's mailbox, so that the tag does
#: not have to change when the mailbox does.
DEFAULT_OWNER = "meridian-platform"
DEFAULT_COST_CENTER = "meridian"


def assert_known_env(env: str) -> str:
    """Raise unless `env` is one of the two real environments."""
    if env not in ENVIRONMENTS:
        raise ValueError(
            f"env must be one of {', '.join(ENVIRONMENTS)}, got {env!r}. "
            f"Pass it as context: npx cdk synth -c env=staging"
        )
    return env


#: `-c enableApiPlatform=true`. **Off by default in both environments** (Phase 12 T21).
#:
#: It turns on everything the `/api/v3` platform needs from AWS in one move: the full
#: machine-scope catalogue on the Cognito resource server (and the placeholder machine
#: client's removal), the api task's app-client admin and webhook permissions, the
#: EventBridge bus and rule, the `sqs-webhooks` queue and its DLQ, the webhook sender
#: Lambda with its own security group and role, the WAF `/api/v3` rate rule, the
#: alarms, and the daily idle-client sweep. Off, a deploy of this branch changes
#: nothing that is already deployed.
#:
#: It is a cost-approval item, not a decision the stacks make: the lines it adds are in
#: `docs/reports/phase-1-cost-estimate.md`, "Phase 12 — pending approval", and nothing
#: is deployed with it on until Andres approves them.
API_PLATFORM_CONTEXT_FLAG = "enableApiPlatform"


def flag_is_on(value: object) -> bool:
    """`-c <flag>=true|1|yes|on`, case-insensitively. Absent, or anything else, is off."""
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in ("1", "true", "yes", "on")


def api_platform_enabled(scope: object) -> bool:
    """True when `-c enableApiPlatform=true` was passed. `scope` is any construct."""
    node = getattr(scope, "node")
    return flag_is_on(node.try_get_context(API_PLATFORM_CONTEXT_FLAG))


#: `-c worker_enabled=true`. **Off by default in both environments** (Phase 11 H1/H2,
#: `docs/reports/phase-11-plan.md` §3.8). The name is the plan's, snake_case, not the
#: camelCase of the older flags: the plan, the tracker and the runbooks already say
#: `worker_enabled`, and one spelling everywhere beats a consistent-looking one here.
#:
#: On, it adds the generic process worker in one move: the SQS job queue and its DLQ,
#: the 15-minute sweep schedule and its role, the `svc-worker` ECS service on the api
#: image, its task role, the api task's `sqs:SendMessage` on the job queue and the two
#: queue URLs in its environment (all `compute`), and five alarms (`observability`).
#: Off, every template is byte-identical to the one before the flag existed
#: (`infra/tests/test_worker.py`). It is a cost-approval item: the worker task runs
#: around the clock (Phase 11 report, H1 tag cell).
WORKER_CONTEXT_FLAG = "worker_enabled"


def worker_enabled(scope: object) -> bool:
    """True when `-c worker_enabled=true` was passed. `scope` is any construct."""
    node = getattr(scope, "node")
    return flag_is_on(node.try_get_context(WORKER_CONTEXT_FLAG))


#: `-c qboOAuth=true`: give the **api** task the QuickBooks OAuth client — `QBO_CLIENT_ID` /
#: `QBO_CLIENT_SECRET` from the hand-created `meridian-<env>/qbo-oauth` secret (execution-role
#: read on that one secret), plus `QBO_ENVIRONMENT` and `QBO_REDIRECT_URI` — without the
#: worker (ADR 0044 amendment, T:186). Off by default because the secret is created by hand
#: (`docs/runbooks/rotate-secrets.md` §6) and a task that names a missing secret does not
#: start. **Production compute must pass it once that secret exists**: Render's production
#: app connects QuickBooks today, so the AWS api has to as well. `worker_enabled` implies it
#: (the worker's `qbo_push` refresh needs the same client), so either flag gives the api the
#: same four variables.
QBO_OAUTH_CONTEXT_FLAG = "qboOAuth"


def qbo_oauth_enabled(scope: object) -> bool:
    """True with `-c qboOAuth=true` or `-c worker_enabled=true`. `scope` is any construct."""
    node = getattr(scope, "node")
    return flag_is_on(node.try_get_context(QBO_OAUTH_CONTEXT_FLAG)) or worker_enabled(scope)


#: `-c qboEnvironment=production|sandbox` picks the Intuit environment the api (and worker)
#: talk to. Default: production on production, sandbox elsewhere. Staging's `qbo-oauth` secret
#: holds Daniela's production-app keys, which the sandbox refuses, so `staging_deploy.sh`
#: passes `production` to let staging connect the real companies (2026-10-15).
QBO_ENVIRONMENT_CONTEXT_KEY = "qboEnvironment"


def qbo_environment(scope: object, env_name: str) -> str:
    """The `QBO_ENVIRONMENT` value for `env_name`; refuses anything but production/sandbox."""
    chosen = getattr(scope, "node").try_get_context(QBO_ENVIRONMENT_CONTEXT_KEY)
    chosen = chosen or ("production" if env_name == "production" else "sandbox")
    if chosen not in ("production", "sandbox"):
        raise ValueError(f"-c {QBO_ENVIRONMENT_CONTEXT_KEY} must be production or sandbox, not {chosen!r}")
    return chosen


#: Ask Meridian (T:254, owner decision 2026-10-18, overrides OD-5 "off for now"): the api task
#: calls Amazon Bedrock in this region (`BEDROCK_REGION`, read by `src/bi_ask.make_client`) and
#: the app stops asking once the month's estimated spend reaches `ASK_MONTHLY_CAP_USD`
#: (`BI_ASK_MONTHLY_CAP_USD`, read by `src/api/v2/bi_routes`). `us-east-1` because the models'
#: prices in `src/bi_ask.PRICES` are the us-east-1 rate card and the stacks live there.
#: `-c bedrockRegion=...` overrides it. The cap is an app-side estimate, not an AWS limit.
BEDROCK_REGION_CONTEXT_KEY = "bedrockRegion"
DEFAULT_BEDROCK_REGION = "us-east-1"
ASK_MONTHLY_CAP_USD = "10"


def bedrock_region(scope: object) -> str:
    """The Bedrock region for Ask Meridian: `-c bedrockRegion=...` or `us-east-1`."""
    chosen = getattr(scope, "node").try_get_context(BEDROCK_REGION_CONTEXT_KEY)
    return str(chosen).strip() if chosen else DEFAULT_BEDROCK_REGION


#: `-c ecwDb=true` maps `ECW_DB_HOST` / `ECW_DB_NAME` / `ECW_DB_USER` / `ECW_DB_PASSWORD`
#: (`src/pnl_logic/sources/ecw_client.py`, the P&L run's read-only eCW data mart) into the
#: api from the hand-created `meridian-<env>/ecw-db` secret, the `qboOAuth` way: off by
#: default so a deploy before the secret exists still starts, and every later `compute`
#: deploy must pass it again or the P&L run goes back to `ECW_NOT_CONNECTED`. The data mart
#: is in another AWS account and only admits allowlisted addresses: this environment's NAT
#: address has to be on that list too.
ECW_DB_CONTEXT_FLAG = "ecwDb"


def ecw_db_enabled(scope: object) -> bool:
    """True with `-c ecwDb=true`. `scope` is any construct."""
    return flag_is_on(getattr(scope, "node").try_get_context(ECW_DB_CONTEXT_FLAG))


#: `-c ecwMart=true -c ecwOrgId=<uuid>` puts the nightly copy of the eCW data mart on AWS
#: (ADR 0053, `docs/runbooks/ecw-mart.md`): the api gets `MART_DB_HOST` / `_PORT` / `_NAME` /
#: `_USER` / `_PASSWORD` (the read-only `meridian_mart_reader` login) and `ECW_ORG_ID`, and a
#: `mart-sync` task (api image, `scripts/sync_data_mart.py --target rds`) runs every night
#: from EventBridge Scheduler. Off by default, the `ecwDb` way: a deploy before the roles
#: exist (Alembic 0048) and before the first load still starts, and **every later `compute`
#: deploy must pass both flags again** or the api loses `MART_DB_*` and BI goes back to
#: `ECW_NOT_CONNECTED` and the schedule is deleted. The loader reads the eCW data mart
#: through the same `meridian-<env>/ecw-db` secret and the same NAT address the P&L run
#: needs, so the allowlist note on `ECW_DB_CONTEXT_FLAG` applies here too. The org id is
#: passed at deploy and never committed.
ECW_MART_CONTEXT_FLAG = "ecwMart"
ECW_ORG_ID_CONTEXT = "ecwOrgId"

#: Nightly at 05:00 Central, after the mart's own overnight refresh and before the day starts.
MART_SYNC_SCHEDULE = "cron(0 5 * * ? *)"
MART_SYNC_TIMEZONE = "America/Chicago"

#: `-c ecwMartSourceSslMode=require` is the documented fallback if the source server's
#: certificate does not verify against the bundle in the image (the loader accepts only
#: these two values, never weaker). Default `verify-full`.
ECW_MART_SOURCE_SSLMODE_CONTEXT = "ecwMartSourceSslMode"
ECW_MART_SOURCE_SSLMODES = ("verify-full", "require")
DEFAULT_ECW_MART_SOURCE_SSLMODE = "verify-full"

#: The `ecw-db` secret holds host / dbname / user / password and no port, so the loader's
#: source port is a plain setting (`MART_SOURCE_PORT`).
ECW_MART_SOURCE_PORT = "5432"

#: The database name the loader insists the source session reports (`current_database()`),
#: so a mistyped secret can never be copied from. Both environments' `ecw-db` secrets point at
#: `ecw_mart`, a copy inside their own RDS (the outside mart is closed to the AWS NAT addresses),
#: filled by `scripts/copy_ecw_mart_to_aws.sh` (2026-10-18).
ECW_MART_SOURCE_DB = {"staging": "ecw_mart", "production": "ecw_mart"}

_UUID = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE
)


def ecw_mart_enabled(scope: object) -> bool:
    """True with `-c ecwMart=true`. `scope` is any construct."""
    return flag_is_on(getattr(scope, "node").try_get_context(ECW_MART_CONTEXT_FLAG))


def ecw_org_id(scope: object) -> str:
    """The organization the mart belongs to: `-c ecwOrgId=<uuid>`. Raises `ValueError`."""
    value = getattr(scope, "node").try_get_context(ECW_ORG_ID_CONTEXT)
    if not value or not _UUID.match(str(value).strip()):
        raise ValueError(
            f"-c {ECW_MART_CONTEXT_FLAG}=true needs -c {ECW_ORG_ID_CONTEXT}=<organization uuid> "
            "(passed at deploy, never committed)."
        )
    return str(value).strip().lower()


def ecw_mart_source_sslmode(scope: object) -> str:
    """`-c ecwMartSourceSslMode=verify-full|require` (default `verify-full`). Raises `ValueError`."""
    value = getattr(scope, "node").try_get_context(ECW_MART_SOURCE_SSLMODE_CONTEXT)
    if value is None or str(value).strip() == "":
        return DEFAULT_ECW_MART_SOURCE_SSLMODE
    mode = str(value).strip()
    if mode not in ECW_MART_SOURCE_SSLMODES:
        raise ValueError(
            f"-c {ECW_MART_SOURCE_SSLMODE_CONTEXT} must be one of {ECW_MART_SOURCE_SSLMODES}, "
            f"not {mode!r}."
        )
    return mode
