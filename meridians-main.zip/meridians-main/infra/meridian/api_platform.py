"""Names the `/api/v3` platform resources share across stacks (Phase 12 T21).

The `api` stack creates the webhook queue, its DLQ and the event bus; the `compute`
stack tells the api task where they are. `compute` cannot import them as constructs —
`api` already imports from `compute` (the task role, the cluster, the log group), so
the reverse would be a cycle — and so both stacks build the same names from here and
the task composes the queue URL from the name, the region and the account. One
definition of each name; neither stack types it.
"""

from __future__ import annotations

from aws_cdk import Aws

from .naming import resource_name

#: `src/webhooks/ports.EVENT_SOURCE`. The rule matches on it, so a second producer on
#: the same bus cannot be mistaken for a run event.
RUN_EVENT_SOURCE = "meridian.runs"


def event_bus_name(env: str) -> str:
    """`meridian-<env>-events-api`: the bus `PutEvents` publishes run events to."""
    return resource_name(env, "events", "api")


def webhook_queue_name(env: str) -> str:
    """`meridian-<env>-sqs-webhooks`: fan-out and delivery messages."""
    return resource_name(env, "sqs", "webhooks")


def webhook_dlq_name(env: str) -> str:
    """`meridian-<env>-sqs-webhooks-dlq`: dead deliveries (the DLQ-depth alarm)."""
    return resource_name(env, "sqs", "webhooks-dlq")


def webhook_sender_name(env: str) -> str:
    """`meridian-<env>-lambda-webhook-sender`."""
    return resource_name(env, "lambda", "webhook-sender")


def webhook_secret_prefix(env: str) -> str:
    """`meridian-<env>-webhook-`: `src/webhooks/ports.secret_name`'s prefix.

    One Secrets Manager secret per subscription is named with it; the IAM policies
    for the api (create/rotate/delete) and the sender (read) are scoped to it.
    """
    return f"meridian-{env}-webhook-"


def webhook_secret_arn_pattern(env: str) -> str:
    """Every webhook signing secret in this environment, and nothing else."""
    return (
        f"arn:{Aws.PARTITION}:secretsmanager:{Aws.REGION}:{Aws.ACCOUNT_ID}:secret:"
        f"{webhook_secret_prefix(env)}*"
    )


def queue_url(name: str) -> str:
    """An SQS queue URL composed from its name — no import of the queue construct."""
    return f"https://sqs.{Aws.REGION}.{Aws.URL_SUFFIX}/{Aws.ACCOUNT_ID}/{name}"
