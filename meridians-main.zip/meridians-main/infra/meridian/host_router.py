"""The CloudFront viewer-request function that splits the web addresses (ADR 0050).

One distribution answers for every name in `SiteHosts.viewer_aliases`, so what a
request may do has to be decided by the name it arrived on, before it reaches the
origin. That is this function, attached to every behaviour:

| Arrived on | Path | Answer |
|---|---|---|
| apex (`meridiansgrp.com`) | any | **301** to `https://www.<domain>` + same path and query |
| `api` | `/v3` or `/v3/...` | rewritten to `/api/v3/...`, passed on |
| `api` | `/api/v3/...` | passed on unchanged (the paths the generated clients call) |
| `api` | anything else | **404**, JSON, from the edge |
| `www` | a marketing page, `/_next/*`, `/brand/*` | passed on |
| `www` | anything else | **308** to the same path and query on `app` |
| `app` (only when `www` exists) | `/` | **302** to `/dashboard` (which sends a signed-out visitor to `/login`) |
| `app` (only when `www` exists) | another marketing page | **308** to the same path on `www` |
| anything else | any | passed on |

**308, not 301, between `www` and `app`.** A 301 lets a browser turn a POST into a
GET on the way; 308 keeps the method and body, so a stale form or bookmarklet that
POSTs to `www` still lands where it meant to. The apex is 301 because nothing
POSTs to a bare domain and 301 is the redirect every crawler already understands.

**Every redirect carries `Cache-Control: max-age=3600`.** A browser otherwise keeps a
permanent redirect with no expiry, and the cutover's rollback (`docs/runbooks/cutover.md`
step 7) puts the app back on `www` at Render: a browser that had cached `www/login →
app/login` for ever would keep leaving Render for the rolled-back AWS stack. An hour
bounds that; search engines still read 301/308 as permanent.

**The marketing list is read, not retyped.** It is `MARKETING_ROUTES` in
`web/src/lib/public-routes.ts` — the same set the React shell uses to decide that a
page has no portal chrome — and `web/src/lib/public-routes.test.ts` holds that set
equal to the `(marketing)` route group on disk. So a new marketing page is one file
in `web/`, and this function learns about it at the next synth.

**Where the same rule runs twice.** `web/src/middleware.ts` applies the `www`/`app`
half again inside the Next.js app, keyed on `PUBLIC_WWW_URL` / `PUBLIC_APP_URL`.
On AWS the edge answers first and the middleware never disagrees with it; the
middleware exists so that the web service is correct on its own (a direct hit on
the origin, a local `next start` with both variables set). Neither is configured on
Render or on a laptop, so nothing is split there.

Nothing here touches AWS: it is a pure function from host names and a text file to
JavaScript, unit-tested by running the JavaScript (`infra/tests/test_host_router.py`).
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from .config import SiteHosts

#: `infra/meridian/host_router.py` → the repository root.
REPO_ROOT = Path(__file__).resolve().parents[2]

#: The file the marketing page list is read from.
PUBLIC_ROUTES_PATH = REPO_ROOT / "web" / "src" / "lib" / "public-routes.ts"

#: What `www` serves besides the marketing pages themselves: Next's own build
#: output (hashed scripts, CSS, self-hosted fonts, the image optimizer) and the
#: brand assets under `web/public/brand` (logo, favicon). Everything else under
#: `web/public` belongs to the app.
WWW_ASSET_PREFIXES: tuple[str, ...] = ("/_next/", "/brand/")

#: The partner API's public prefix and the backend prefix it maps to.
API_PUBLIC_PREFIX = "/v3"
API_BACKEND_PREFIX = "/api/v3"

#: Where `app`'s own `/` sends a visitor once `www` has the home page.
APP_ROOT_REDIRECT = "/dashboard"

#: How long a browser may keep any redirect this function answers (see the docstring).
REDIRECT_CACHE_CONTROL = "max-age=3600"

#: CloudFront Functions reject code larger than this many bytes.
MAX_FUNCTION_BYTES = 10 * 1024

_MARKETING_SET = re.compile(
    r"MARKETING_ROUTES\s*:\s*ReadonlySet<string>\s*=\s*new\s+Set\(\s*\[(?P<body>.*?)\]\s*\)",
    re.DOTALL,
)
_STRING = re.compile(r"""['"]([^'"]+)['"]""")


def marketing_paths(path: Path | None = None) -> list[str]:
    """`MARKETING_ROUTES` from `web/src/lib/public-routes.ts`, in file order."""
    text = (path or PUBLIC_ROUTES_PATH).read_text(encoding="utf-8")
    match = _MARKETING_SET.search(text)
    if match is None:
        raise ValueError(
            f"no `MARKETING_ROUTES ... new Set([...])` found in {PUBLIC_ROUTES_PATH}. "
            "The edge host router reads the marketing page list from it — if it was "
            "renamed or restructured, update infra/meridian/host_router.py deliberately."
        )
    paths = _STRING.findall(match.group("body"))
    if not paths or any(not p.startswith("/") for p in paths):
        raise ValueError(f"MARKETING_ROUTES must be a non-empty list of absolute paths: {paths}")
    return paths


def host_router_code(hosts: SiteHosts, marketing: list[str] | None = None) -> str:
    """The function's JavaScript (`cloudfront-js-2.0`), for one environment."""
    pages = marketing_paths() if marketing is None else marketing
    config = {
        "apex": hosts.apex or "",
        "www": hosts.www or "",
        "app": hosts.app,
        "api": hosts.api,
    }
    code = _fill(
        _TEMPLATE,
        HOSTS=json.dumps(config, sort_keys=True),
        MARKETING=json.dumps({page: True for page in pages}, sort_keys=True),
        ASSETS=json.dumps(list(WWW_ASSET_PREFIXES)),
        API_PUBLIC=json.dumps(API_PUBLIC_PREFIX),
        API_BACKEND=json.dumps(API_BACKEND_PREFIX),
        APP_ROOT=json.dumps(APP_ROOT_REDIRECT),
        CACHE_CONTROL=json.dumps(REDIRECT_CACHE_CONTROL),
    )
    if len(code.encode("utf-8")) > MAX_FUNCTION_BYTES:
        raise ValueError("the host router is larger than CloudFront Functions allow (10 KB)")
    return code


def _fill(template: str, **values: str) -> str:
    """Replace `@NAME@` markers — not `string.Template`, whose `$` JavaScript uses."""
    out = template
    for name, value in values.items():
        out = out.replace(f"@{name}@", value)
    if re.search(r"@[A-Z_]+@", out):
        raise ValueError("an @NAME@ marker was left unsubstituted")
    return out


_TEMPLATE = """var HOSTS = @HOSTS@;
var MARKETING = @MARKETING@;
var ASSETS = @ASSETS@;
var API_PUBLIC = @API_PUBLIC@;
var API_BACKEND = @API_BACKEND@;
var APP_ROOT = @APP_ROOT@;
var CACHE_CONTROL = @CACHE_CONTROL@;

function query(qs) {
  var parts = [];
  for (var key in qs) {
    var item = qs[key];
    if (item.multiValue) {
      for (var i = 0; i < item.multiValue.length; i++) {
        parts.push(key + '=' + item.multiValue[i].value);
      }
    } else {
      parts.push(key + '=' + item.value);
    }
  }
  return parts.length ? '?' + parts.join('&') : '';
}

var REASONS = { 301: 'Moved Permanently', 302: 'Found', 308: 'Permanent Redirect' };

function redirect(status, location) {
  return {
    statusCode: status,
    statusDescription: REASONS[status],
    headers: {
      location: { value: location },
      'cache-control': { value: CACHE_CONTROL }
    }
  };
}

function isAsset(uri) {
  for (var i = 0; i < ASSETS.length; i++) {
    if (uri.indexOf(ASSETS[i]) === 0) return true;
  }
  return false;
}

function handler(event) {
  var request = event.request;
  var host = request.headers.host ? request.headers.host.value.toLowerCase() : '';
  var uri = request.uri;

  if (HOSTS.apex && host === HOSTS.apex) {
    return redirect(301, 'https://' + HOSTS.www + uri + query(request.querystring));
  }

  if (host === HOSTS.api) {
    if (uri === API_PUBLIC || uri.indexOf(API_PUBLIC + '/') === 0) {
      request.uri = API_BACKEND + uri.substring(API_PUBLIC.length);
      return request;
    }
    if (uri === API_BACKEND || uri.indexOf(API_BACKEND + '/') === 0) {
      return request;
    }
    return {
      statusCode: 404,
      statusDescription: 'Not Found',
      headers: { 'content-type': { value: 'application/json' } },
      body: {
        encoding: 'text',
        data: '{"error":{"code":"not_found","message":"The partner API lives under /v3/."}}'
      }
    };
  }

  if (HOSTS.www && host === HOSTS.www) {
    if (MARKETING[uri] === true || isAsset(uri)) return request;
    return redirect(308, 'https://' + HOSTS.app + uri + query(request.querystring));
  }

  if (HOSTS.www && host === HOSTS.app) {
    if (uri === '/') return redirect(302, APP_ROOT);
    if (MARKETING[uri] === true) {
      return redirect(308, 'https://' + HOSTS.www + uri + query(request.querystring));
    }
  }

  return request;
}
"""
