"""The Meridian CDK app's constructs: naming, tags, per-environment config, stacks."""
