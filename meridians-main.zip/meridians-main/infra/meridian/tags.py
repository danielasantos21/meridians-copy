"""The six mandatory tags, and the CDK Aspect that enforces them.

`docs/aws-migration-prompt.md` ("Conventions") and ADR 0001 make these tags
load-bearing, not decoration: cost allocation per environment reads
`Project`/`Environment`, IAM conditions read `aws:ResourceTag/Environment`, and
the PHI controls read `DataClassification`. So CI has to fail on an untagged
resource rather than trust anyone to remember.

An **Aspect** is CDK's visitor: it is handed every construct in the tree just
before the CloudFormation template is written. `Tags.of(...).add(...)` is itself
an Aspect, which is why ordering matters — the tag-applying Aspects run at
priority `MUTATING` (200) and this checker is applied at `READONLY` (500), so by
the time it looks, every tag has been written. The `aspectPrioritiesMutating`
feature flag in `cdk.json` is what guarantees that order; do not remove it.
"""

from __future__ import annotations

from typing import Any

import jsii
from aws_cdk import Annotations, CfnResource, IAspect
from constructs import IConstruct

#: The tag keys every taggable resource must carry.
REQUIRED_TAG_KEYS = (
    "Project",
    "Environment",
    "Owner",
    "DataClassification",
    "CostCenter",
    "ManagedBy",
)

#: Allowed values for `DataClassification`. `phi` is reserved for the data stack's
#: `phi` bucket, the RDS instance and their keys — never for logs or build output.
DATA_CLASSIFICATIONS = ("phi", "internal", "public")

#: `ManagedBy` has exactly one legal value: if a resource was not made by CDK it
#: does not belong to us (ADR 0001 — the account is shared with another owner).
MANAGED_BY = "cdk"


def common_tags(
    env: str,
    *,
    owner: str,
    cost_center: str,
    project: str = "meridian",
) -> dict[str, str]:
    """The five tags applied at stack level.

    `DataClassification` is deliberately absent: each stack (and, where it
    differs, each construct) declares its own, so that nobody inherits `phi`
    by accident or, worse, inherits `internal` onto a PHI bucket.
    """
    return {
        "Project": project,
        "Environment": env,
        "Owner": owner,
        "CostCenter": cost_center,
        "ManagedBy": MANAGED_BY,
    }


def _rendered_tags(resource: CfnResource) -> dict[str, str] | None:
    """Best-effort read of the tags CDK will actually write for `resource`.

    Returns `None` when the resource type does not support tags at all, or
    renders them in a shape we cannot read (a handful of L1s use a bespoke
    property); those are not failed, because a false failure that blocks every
    deploy is worse than a gap the control matrix records.
    """
    manager = getattr(resource, "tags", None)
    if manager is None:
        return None
    try:
        rendered: Any = manager.render_tags()
    except Exception:  # pragma: no cover - defensive; L1s vary
        return None
    if rendered is None:
        return {}
    if isinstance(rendered, dict):
        return {str(k): str(v) for k, v in rendered.items()}
    if isinstance(rendered, list):
        out: dict[str, str] = {}
        for item in rendered:
            if isinstance(item, dict) and "key" in item and "value" in item:
                out[str(item["key"])] = str(item["value"])
            elif isinstance(item, dict) and "Key" in item and "Value" in item:
                out[str(item["Key"])] = str(item["Value"])
            else:  # an unresolved token — unreadable, so not judged
                return None
        return out
    return None


@jsii.implements(IAspect)
class RequiredTagsAspect:
    """Fails synthesis when a taggable resource is missing a mandatory tag.

    Apply it once per app at `AspectPriority.READONLY`:

        Aspects.of(app).add(RequiredTagsAspect(), priority=AspectPriority.READONLY)
    """

    def visit(self, node: IConstruct) -> None:
        if not isinstance(node, CfnResource):
            return
        tags = _rendered_tags(node)
        if tags is None:
            return

        missing = [key for key in REQUIRED_TAG_KEYS if not tags.get(key)]
        if missing:
            Annotations.of(node).add_error(
                f"{node.cfn_resource_type} is missing required tag(s): "
                f"{', '.join(missing)}. Every AWS resource carries "
                f"{', '.join(REQUIRED_TAG_KEYS)} — see infra/meridian/tags.py."
            )
            return

        classification = tags["DataClassification"]
        if classification not in DATA_CLASSIFICATIONS:
            Annotations.of(node).add_error(
                f"{node.cfn_resource_type} has DataClassification={classification!r}; "
                f"it must be one of {', '.join(DATA_CLASSIFICATIONS)}."
            )

        if tags["ManagedBy"] != MANAGED_BY:
            Annotations.of(node).add_error(
                f"{node.cfn_resource_type} has ManagedBy={tags['ManagedBy']!r}; "
                f"it must be {MANAGED_BY!r}."
            )
