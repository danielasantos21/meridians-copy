# `infra/` — the Meridian AWS estate, as code

Every AWS resource Meridian owns is defined here, in **AWS CDK written in Python**
(ADR 0006). CDK is AWS's own tool: you write ordinary Python, and it emits
CloudFormation templates that AWS applies.

**Nothing is created in the console. Ever.** A resource clicked into existence has
no review trail, no diff, and nothing an auditor can read — and the foundation
stack alarms on exactly that (`meridian-shared-alarm-console-create-delete`). If
you find yourself in the console changing something, stop, change it here, and
deploy.

## What lives here

| Path | What |
|---|---|
| `app.py` | The CDK app. Picks the environment from context, builds the stacks, applies the tags. |
| `meridian/naming.py` | `resource_name(env, component, purpose)` → `meridian-<env>-<component>-<purpose>`. |
| `meridian/tags.py` | The six mandatory tags and the Aspect that fails synthesis without them. |
| `meridian/config.py` | Per-environment knobs: CI branch, budget figures, the RDS instance class. No secrets, no identifiers. |
| `meridian/stacks/foundation.py` | Account-level: CloudTrail, alarms, GuardDuty, Security Hub, Config + HIPAA pack, Access Analyzer, Inspector, break-glass, budgets, GitHub OIDC. Deployed **once**. |
| `meridian/stacks/dns.py` | Account-level: the `meridiansgrp.com` Route 53 zone with every record it has today, and the SES sending identity (DKIM, custom MAIL FROM, configuration set). Deployed **once**. ADR 0017. |
| `meridian/stacks/identity.py` | Account-level: IAM Identity Center permission sets and assignments, plus the require-MFA policy and the humans group. Deployed **once**. |
| `meridian/stacks/vpc.py` | Per-environment, **persistent, $0/month**: VPC, six subnets, the two free gateway endpoints and the four security groups. Never destroyed — `data` depends on it. ADR 0020. |
| `meridian/stacks/data.py` | Per-environment, **persistent**: the five KMS keys, four secrets, the RDS instance, three S3 buckets and the locked AWS Backup vault. ADR 0020. |
| `meridian/stacks/edge.py` | Per-environment, **transient**: the NAT gateway and its routes, VPC flow logs, the ALB and ACM certificate, CloudFront, the WAF, and the SSM ops instance — everything billed by the hour. Destroyed at the end of every staging session. ADR 0018, ADR 0020. |
| `meridian/stacks/backup_dr.py` | The `us-west-2` backup vault the daily plan copies into. The only stack outside `us-east-1`, and it is added only when `CDK_DEFAULT_REGION` is set. ADR 0020 §8. |
| `meridian/edge_paths.py` | Generates the ALB's `api` path patterns from `web/next.config.mjs`. Never a hand-typed list. |
| `meridian/host_router.py` | Generates the CloudFront Function that splits the web addresses (ADR 0050): apex → `www`, `www` = marketing only, `app` = the app, `api` = `/v3`. Reads the marketing page list from `web/src/lib/public-routes.ts`; the host names come from `config.site_hosts`. |
| `meridian/stacks/auth.py` | Per-environment, **persistent**: the Cognito user pool (MFA `ON` TOTP-only, threat protection `AUDIT` on the Plus tier, `DeletionProtection=ACTIVE`, `custom:app_uid`), the confidential web client and the client-credentials machine client, the hosted domain, the two federated-IdP placeholder secrets, and the User Migration Lambda. ADR 0003, ADR 0021. |
| `meridian/stacks/compute.py` | Per-environment, **transient**: the two ECR repositories (immutable tags, scan on push, last 10 images), the ECS Fargate cluster with Container Insights and audited ECS Exec, the `api` and `web` task definitions (ARM64; api 1 vCPU / 2 GB / 40 GiB, `stopTimeout` 120) and the two services, registered into the `edge` stack's target groups with a rolling-back deployment circuit breaker. **`api` runs exactly one task in both environments until Phase 11** — see the module docstring for why and what it costs. ADR 0022. **With `-c worker_enabled=true` (off by default)** it also holds the Phase 11 job worker (`meridian/stacks/worker.py`, H1): the `sqs-jobs` queue + DLQ on the `phi` CMK, the 15-minute sweep schedule, and `svc-worker` — one task of the api image running `python -m workers`, its own least-privilege task role, and the api task's `sqs:SendMessage` on the job queue. |
| `meridian/stacks/worker.py` | The job worker's resources, built by `compute` only with `-c worker_enabled=true`. Its docstring says why they are in `compute` rather than `api` (the deploy workflow ships `compute` alone; the queue must exist before the worker starts), why the queue is on the `phi` key, and the whole IAM list. Its five alarms are `observability`'s (`_worker_alarms`, H2). |
| `../.github/workflows/deploy.yml` | The staging deploy: `pytest tests` → buildx `linux/arm64` → Trivy → push `${{ github.sha }}` → `cdk deploy meridian-staging-compute --exclusively` → `aws ecs wait services-stable`. **`workflow_dispatch` only, and it stays that way until the cost approval** — it has no `push` trigger, and it refuses to run unless `confirm` is typed as `deploy-staging`. It assumes `meridian-shared-iam-github-deploy` by OIDC (no stored keys) and it has never been run. `docs/runbooks/deploy-staging.md`. |
| `meridian/stacks/observability.py` | Per-environment, **transient**: ~27 alarms into the `data` stack's `meridian-<env>-sns-alerts` (every one with `ok_actions` and an argued `treat_missing_data`), seven field-based log metric filters, one golden-signals dashboard with no log widget, the EventBridge Pipe that drains the stop-schedule DLQ (ADR 0020 §7c), the three account-scoped finding rules (**production only**), and a Synthetics health canary behind `-c enableCanary=true` because it costs more than the budget's headroom. Several alarms are **silent by construction** until the app emits JSON logs. ADR 0024. Since the Phase 8 infra pass (2026-09-24) it also carries the SES alarms (T:39), the **log-group governor** Lambda that gives the implicit CDK-helper and canary log groups a retention and the `logs` CMK — CloudWatch has no account-level policy for either (T:60/T:65) — and, **production only**, the **backup-freshness** Lambda and its age/missing/heartbeat alarms (T:160). Both Lambdas' sources are in `../lambda/`. |
| `meridian/stacks/api.py` | Per-environment, **transient**, and **empty unless `-c enableApiPlatform=true`** (Phase 12 T21): the `/api/v3` event bus, the `sqs-webhooks` queue + DLQ on the `logs` CMK, the webhook sender Lambda (own role, own security group in `vpc`, no PHI reach), the api task's Cognito app-client and webhook IAM (on `compute`'s role, scoped to `auth`'s pool), the DLQ-depth and machine-token-refusal alarms, the daily idle API-client sweep, and (T19) the 5-minute webhook outbox sweep (`python -m workers.outbox_sweep` as a one-off api task). Both sweeps name the api task definition by its FAMILY ARN, never the imported revision ARN, which would block every `compute` deploy once this stack held a schedule. ADR 0037, ADR 0038. Phase 11's job queue was pencilled in here and went to `compute` instead (`meridian/stacks/worker.py`). |
| `meridian/api_platform.py` | The names the `api` and `compute` stacks share (bus, queues, sender, `meridian-<env>-webhook-*` secret prefix), so `compute` can point the api task at them without importing `api`. |
| `meridian/log_groups.py` | The log-group name patterns each environment's `logs` and `phi` CMKs admit (CX-INF-04), plus the canary name and the RDS instance id they are built from. `data` writes them into the key policies; a test walks every synthesized log group against them. |
| `pins/rds-global-bundle.sha256` + `meridian/pins.py` | The SHA-256 the RDS CA bundle must hash to, for `Dockerfile.api` and the webhook sender's bundling (CX-INF-03). Written by `scripts/pin_rds_ca_bundle.py`; `UNPINNED` means both builds refuse to run. |
| `dns/meridiansgrp.com.zone.json` | A `dig` export of the live GoDaddy zone. The tests assert every entry in it exists in the synthesized zone, so a record added at GoDaddy and forgotten here fails CI instead of going dark at the nameserver switch. |
| `conformance-packs/` | The AWS-published HIPAA Config pack, vendored and published as a CDK asset. Its README has the source URL, commit and checksum. |
| `../lambda/user_migration/` | The Cognito User Migration trigger's source, bundled by `meridian/stacks/auth.py` as a CDK asset. It lives outside `infra/` because it is application code, not infrastructure. Phase 4 step 3 ships a placeholder that fails closed; step 6 replaces the body. |
| `tests/` | `pytest` + `aws_cdk.assertions`. No AWS calls, no credentials. |

## What does **not** live here

- **No account id.** Anywhere. Account and region come from the CLI environment at
  deploy time (`CDK_DEFAULT_ACCOUNT` / `CDK_DEFAULT_REGION`). The account id is
  written down in exactly one place, `docs/aws-migration-plan.md` §1 (ADR 0001),
  and `tests/test_no_account_id.py` keeps it out of here.
- **No secrets.** Connection strings, keys, the ACH numbers, the alert mailbox —
  none of it. Credentials live in Secrets Manager; the alert address is a
  CloudFormation parameter passed at deploy time.
- **No data.** No exports, no PDFs, no client files, no PHI. Generated output goes
  to S3. `cdk.out/` is generated and gitignored.
- **No application code**, and no Terraform.

## Running it

The CDK *library* is Python and pinned in `requirements.txt`; the CDK *CLI* is a
Node tool and pinned in `package.json`, so it is always run with `npx`.

```bash
# once
../venv/bin/pip install -r requirements.txt
npm ci

# every day  (run with the repo venv on PATH, or from an activated venv)
npx cdk synth -c env=staging          # write templates to cdk.out/
npx cdk synth -c env=production
npx cdk diff  -c env=staging          # drift detection: what would change
../venv/bin/python -m pytest tests -q
```

Until Identity Center exists, add `-c allowNoIdentityCenter=true` to the `synth` and
`diff` lines — or put the three `sso*` values in `infra/cdk.context.json`, which the CLI
reads automatically. See "Deploying" below for why a missing ARN is an error rather than
a silent skip.

`-c env=...` is **required in practice**. `app.py` falls back to `staging` so a
bare `cdk synth` is still useful, but deploying without it is how you deploy the
wrong environment.

`cdk synth` needs **no AWS credentials** — prove it any time:

```bash
env -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY -u AWS_PROFILE npx cdk synth -c env=staging
```

That is also how CI runs it (`.github/workflows/backend.yml`, job `infra`) — plus
`-c allowNoIdentityCenter=true`, because CI has no identifiers and never deploys
`meridian-shared-identity`.

### Deploying

```bash
# The three account-level stacks. Order between them does not matter — they share
# no resources — but all three come before any per-environment stack.
npx cdk deploy meridian-shared-dns        --parameters EmailEventsAddress=<mailbox>
npx cdk deploy meridian-shared-foundation --parameters AlertEmail=<mailbox>
npx cdk deploy meridian-shared-identity \
  -c ssoInstanceArn=... -c ssoAdminPrincipalId=... -c ssoReadOnlyPrincipalId=... -c ssoWritePrincipalId=...

# Per environment, in dependency order. `dr` is first and is in us-west-2: the data
# stack's backup copy action names its vault by a composed ARN, so there is no
# CloudFormation dependency to enforce the order (ADR 0020 §8).
npx cdk deploy -c env=staging meridian-staging-dr
npx cdk deploy -c env=staging -c cloudfrontPrefixListId=pl-... meridian-staging-vpc
npx cdk deploy -c env=staging meridian-staging-data
npx cdk deploy -c env=staging -c cloudfrontPrefixListId=pl-... -c hostedZoneId=Z... \
  meridian-staging-edge
```

`meridian-<env>-vpc` and `meridian-<env>-edge` take several identifiers as context, and none is committed
(ADR 0001). Besides the two below, three govern the origin-verify header (ADR 0018 §7,
`docs/runbooks/rotate-origin-verify-secret.md`):

| Context | Default | What it is |
|---|---|---|
| `originVerifyActiveVersion` | `AWSCURRENT` | The primary secret **version id** the **ALB** accepts. The default label is correct on the very first deploy only. |
| `originVerifyPreviousVersion` | unset | A second **version id** the ALB also accepts — the one being replaced. Unset before the first rotation; it is what holds the window open between the two rotation deploys. |
| `originVerifyCloudFrontVersionId` | unset → `AWSCURRENT` | The one **version id** CloudFront sends. Being set is what marks "not the first deploy". |

**All three take version ids, not staging labels, after the first deploy** (finding
H-F). A `{{resolve:...}}` reference is resolved by the deploy that *writes* it, and
CloudFormation only re-writes a property whose template text changed — `AWSCURRENT` is
the same characters every time, so labelled listener rules silently keep the value from
the deploy that first wrote them while CloudFront's pinned id moves. `cdk synth` warns
when a label is still in use once `originVerifyCloudFrontVersionId` is set. Rotating is
then **two deploys**: widen the ALB, then move the edge —
`docs/runbooks/rotate-origin-verify-secret.md` has the exact `cdk diff` expected at each
step.


`meridian-<env>-compute` takes two of its own, and neither is an identifier — they are
what a deploy is *for*:

| Context | Default | What it is |
|---|---|---|
| `apiImageTag` | `imageTag`, then `bootstrap` | The ECR tag the `api` task definition pulls. |
| `enableCanary` | off | Creates the Synthetics health canary, its artifacts bucket and its alarm in `meridian-<env>-observability`. **Off because it costs ≈ $10.40/environment/month against ≈ $11 of headroom** — see `docs/reports/phase-1-cost-estimate.md` §3 and ADR 0024 §8. It is a spend decision, not a deploy flag. |
| `enableApiPlatform` | off | Phase 12 T21: every AWS resource and permission the `/api/v3` platform needs, across `auth`, `vpc`, `edge`, `compute` and `api` (see the `api.py` row above). **Off until Andres approves the Phase 12 lines** in `docs/reports/phase-1-cost-estimate.md` §3b; off, a deploy changes nothing. Synth with it on builds the webhook sender's Lambda asset in Docker. |
| `apiIdleSweepActor` | unset | With `enableApiPlatform`: the superadmin user id the daily idle-client sweep acts as. A person's id, so passed with `-c`, never committed; unset means no schedule and a synth warning. |
| `webImageTag` | `imageTag`, then `bootstrap` | The same for `web`. |
| `worker_enabled` | off | Phase 11 H1/H2: the job queue + DLQ, the sweep schedule and the `svc-worker` service in `compute`, and five alarms in `observability` (`meridian/stacks/worker.py`). **Off until Andres approves the line** (≈ $15.4/month pre-tax per environment it runs in, almost all the always-on Fargate task); off, every template is byte-identical to before the flag. Turning it off again after a deploy: `observability` first, then `compute`, both `--exclusively` — `observability` imports the worker's queue, service and log group from `compute`, and CloudFormation refuses to drop an export still in use. |

`.github/workflows/deploy.yml` passes both as `${{ github.sha }}`, so a normal deploy ships
two images built from one commit. They are separate keys because a rollback is frequently
one of them — pinning `web` to the last good sha while `api` moves forward is the difference
between a two-minute fix and reverting a merge. `imageTag` is the older single key and still
sets both. The default, `bootstrap`, is a tag no build ever pushes: deliberately **not**
`latest`, which under `imageTagMutability: IMMUTABLE` could be pushed exactly once and would
be a lie from the second deploy on.

| Context | What | Where it comes from |
|---|---|---|
| `cloudfrontPrefixListId` | AWS's managed prefix list `com.amazonaws.global.cloudfront.origin-facing` — the **only** source the ALB security group admits | `aws ec2 describe-managed-prefix-lists --filters Name=prefix-list-name,Values=com.amazonaws.global.cloudfront.origin-facing --query 'PrefixLists[0].PrefixListId' --output text` |
| `hostedZoneId` | The `meridian-shared-dns` zone, for ACM's DNS validation and the CloudFront origin record | `aws cloudformation describe-stacks --stack-name meridian-shared-dns --query "Stacks[0].Outputs[?OutputKey=='HostedZoneId'].OutputValue" --output text` |

They are passed with `-c` rather than looked up so that `cdk synth` still needs no
credentials. **Omitting the prefix list id does not open the load balancer** — the stack
synthesizes with a placeholder id that does not exist and CloudFormation refuses it.

Two more switches, both documented in `cdk.json`: `createDnsAliases` (default `false`;
**Phase 9** turns it on, and doing it early moves live traffic off Render) and
`createOpsInstance` (default `true` for staging, `false` for production).

The three `meridian-shared-*` stacks are deployed **once for the account**; the six
per-environment stacks are deployed once per environment.

**`meridian-shared-dns` can go first, and probably should.** It has no dependency on the
foundation stack, and the sooner the zone exists the sooner its records can be verified
against the Route 53 nameservers ahead of the switch — which has a 48-hour tail
(`docs/runbooks/dns-nameserver-switch.md`, ADR 0017). Nothing per-environment depends on it
until Phase 9.

**`meridian-shared-identity` deploys in two passes.** CloudFormation cannot create an IAM
Identity Center instance — there is no resource type for it, and it has to be an
**organization** instance (an account instance cannot carry permission sets and cannot be
converted). So the first deploy installs only the require-MFA policy, the
`meridian-shared-iam-humans` group and its break-glass grant; you then enable the instance
and create the two users by hand (`docs/runbooks/identity-center-bootstrap.md` — step 0 is
a decision, read it before running anything) and deploy again with the three `-c` values,
which adds the permission sets and the assignments.

**Synth refuses without `ssoInstanceArn`**, and the reason is the *second* deploy, not the
first. CDK renders the whole template every time, so deploying this stack with the
identifiers missing does not leave the permission sets alone — it deletes them and both
assignments, signing everyone out of the account. There is no error to notice. Two ways
past it, and they mean different things:

```bash
# You have the identifiers. Put them somewhere the CLI picks up automatically.
cat infra/cdk.context.json
# {
#   "ssoInstanceArn": "arn:aws:sso:::instance/ssoins-XXXXXXXX",
#   "ssoAdminPrincipalId": "<admin UserId>",
#   "ssoReadOnlyPrincipalId": "<readonly UserId>",
#   "ssoWritePrincipalId": "<write UserId>"
# }

# You genuinely have no Identity Center yet (first pass, CI, or the runbook's
# IAM-users-with-MFA fallback). Say so explicitly.
npx cdk synth -c env=staging -c allowNoIdentityCenter=true
```

`cdk.context.json` is **gitignored** (`infra/.gitignore`): it holds identifiers, and no
identifier is committed (ADR 0001). The CDK CLI reads it on every command, so the three
values stop being something to retype — which is what made forgetting them plausible in
the first place. `cdk.json`, by contrast, *is* committed, so nothing identifying goes in it.

## Bootstrap — read this before the first deploy

CDK needs a small set of its own resources in each account/region before it can
deploy anything (a staging bucket, an ECR repo, and the `cdk-*` deploy roles):

```bash
npx cdk bootstrap aws://<account>/<region>     # once per account and region
```

**`cdk bootstrap` creates its own state bucket.** Never point it at, reuse, or
otherwise touch the pre-existing Terraform state bucket (plan §1) — that is the
other owner's Terraform state in this shared account (ADR 0001), and it is
off-limits along with every other resource we did not create.

### What bootstrap actually creates, and what it trusts

Worth knowing before running it, because two of its defaults are security decisions
made on your behalf.

**The qualifier** is the string in every bootstrapped resource's name. The default is
`hnb659fds` — not random, just a fixed constant AWS ships — which is why the roles are
`cdk-hnb659fds-deploy-role-<account>-<region>` and why the CI roles here are scoped to
`role/cdk-*`. We use the default. A custom qualifier (`--qualifier`) isolates two CDK
apps that must not share a staging bucket; there is one app in this account, so a
custom one would only be a value to remember and to keep in sync with `cdk.json`.

**The trust.** Bootstrapping creates five roles, and the `deploy-role` trusts
*whatever account you pass to `--trust`*. Passing nothing trusts only this account,
which is what we want: GitHub Actions reaches the deploy path by assuming
`meridian-shared-iam-github-deploy` (OIDC, only jobs in the `staging` GitHub Environment
of one repository) which then assumes the named `cdk-*` roles from inside the account. Never `--trust` another account without a
written reason — it is a standing grant to deploy arbitrary CloudFormation here.

**The execution policy.** `--cloudformation-execution-policies` decides what
CloudFormation itself may do while applying a template. The default is
`arn:aws:iam::aws:policy/AdministratorAccess`, and bootstrap will refuse to run without
an explicit choice:

```bash
npx cdk bootstrap aws://<account>/<region> \
  --cloudformation-execution-policies arn:aws:iam::aws:policy/AdministratorAccess
```

We take the default, deliberately. This app creates IAM roles, KMS keys, an
Object-Locked bucket and account-level detection services — a narrower policy would
have to grant essentially all of that anyway, and the failure mode of getting it wrong
is a deploy that half-applies. The control that matters is not the execution policy's
breadth but **who can reach it**: only the two OIDC-trusted CI roles and an Identity
Center admin session, both short-lived and both alarmed. Revisit this if the account
ever hosts a second, less-trusted CDK app.

## The HIPAA conformance pack — no upload step

The foundation stack creates an AWS Config conformance pack from the AWS-published
`Operational-Best-Practices-for-HIPAA-Security` control set (130 rules). That YAML is
**vendored into `infra/conformance-packs/`** and published with `aws_s3_assets.Asset`,
so `cdk deploy` uploads it and hands CloudFormation the resulting S3 URL. There is
nothing to do by hand.

This used to be a manual upload, and it is worth saying why it is not any more: the
stack deployed cleanly whether or not anyone had uploaded the file. The conformance
pack resource was created, CloudFormation was satisfied, and the 130 rules were simply
absent — a control believed to be in place and silently not. `infra/conformance-packs/README.md`
records the source URL, the upstream commit and the checksum, and how to take a newer
version.

## Pre-deploy checks

Everything below is **read-only**: nothing here creates, changes or costs anything.
Run it once before the first `cdk deploy`, because each line decides a context flag,
and getting one wrong fails the whole foundation stack rather than one resource.

The account is shared with another owner's application (ADR 0001), and most of these
services are **singletons per account**: if theirs already exists, ours cannot be
created alongside it.

```bash
# GuardDuty — any detector at all means -c enableGuardDuty=false
aws guardduty list-detectors

# Security Hub — "ResourceNotFoundException" is the answer you want
aws securityhub describe-hub

# AWS Config — ONE configuration recorder per account per region
aws configservice describe-configuration-recorders
aws configservice describe-delivery-channels

# GitHub OIDC provider — one per issuer URL
aws iam list-open-id-connect-providers

# Inspector v2 — "ENABLED" for this account means -c enableInspector=false
aws inspector2 batch-get-account-status --query 'accounts[].state.status'

# IAM Access Analyzer — one external-access analyzer per account
aws accessanalyzer list-analyzers --type ACCOUNT

# Identity Center — see the note below; this decides how meridian-shared-identity deploys
aws sso-admin list-instances

# Cost Anomaly Detection — ONE DIMENSIONAL/SERVICE monitor per account, and Cost
# Explorer creates `Default-Services-Monitor` by itself the first time the console
# is opened. Copy the ARN this prints; you will pass it with -c.
aws ce get-anomaly-monitors \
  --query "AnomalyMonitors[?MonitorType=='DIMENSIONAL'].[MonitorArn,MonitorName]" \
  --output table

# AWS Backup S3 opt-in — the one line here that is NOT read-only, and the one that
# cannot be expressed in CloudFormation. Without it the RDS backups run and the S3
# ones SILENTLY do not (ADR 0020 §7a).
aws backup describe-region-settings --region us-east-1 \
  --query 'ResourceTypeOptInPreference.{RDS:RDS,S3:S3}'
# If either is false:
#   aws backup update-region-settings --region us-east-1 \
#     --resource-type-opt-in-preference S3=true,RDS=true
```

### One thing that is not reversible

`meridian-<env>-data` and `meridian-<env>-dr` create **compliance-locked** resources: two
AWS Backup vaults with Vault Lock, and an Object-Locked `audit` bucket with a seven-year
default retention. After the three-day cooling-off window a vault lock cannot be removed
by anyone, including the account root user and AWS Support, and neither vault can be
deleted while it still holds a recovery point (up to 35 days). That is the control
working — it is what stops the credential that can delete the database from deleting every
recovery point — but it means deploying the data stack has a tail. Deploy it deliberately.
See ADR 0020 §7 and `docs/runbooks/staging-teardown.md` §2c.

| Finds something | Do |
|---|---|
| a GuardDuty detector | `-c enableGuardDuty=false` |
| a Security Hub | `-c enableSecurityHub=false` |
| a configuration recorder | `-c enableConfigRecorder=false`, and add our conformance pack to theirs by hand |
| `token.actions.githubusercontent.com` | `-c createGithubOidcProvider=false` (the deploy and diff roles still trust it by ARN) |
| Inspector already `ENABLED` | `-c enableInspector=false` |
| an `ACCOUNT` analyzer | `-c enableAccessAnalyzer=false` |
| a `DIMENSIONAL` anomaly monitor | leave `enableServiceAnomalyMonitor` at its default (`false`) and pass `-c existingServiceAnomalyMonitorArn=<that ARN>` |
| **no** `DIMENSIONAL` anomaly monitor | `-c enableServiceAnomalyMonitor=true` |

**The anomaly row is the one that bites, and it is the opposite shape to the others**
(finding H-G). Every other flag here defaults to `true` and is turned off when the other
owner got there first. `enableServiceAnomalyMonitor` defaults to **`false`**, because
`get-anomaly-monitors` on *this* account already returns AWS's own
`Default-Services-Monitor` — Cost Explorer creates it unprompted. A second
`DIMENSIONAL`/`SERVICE` monitor is rejected with `ValidationException` **part way
through the changeset**, which rolls the entire foundation stack back: CloudTrail, the
alarms, the budgets, the conformance pack, all of it. Passing the existing ARN attaches
the alert subscription to that monitor; the ARN appears only in `MonitorArnList`, so
nothing in this stack can read, change or delete the monitor itself.

With neither value passed the stack still deploys and still watches both environments,
and `cdk synth` warns that untagged spend is unwatched. The ARN carries the account id,
so it is a `-c` value and is never committed (ADR 0001).

Record the reason for every flag you turn off in `docs/compliance/`. Do not adopt,
modify or import the other owner's resource.

### Identity Center: which *kind* of instance

`aws sso-admin list-instances` tells you more than whether one exists:

- an **organization instance** has `OwnerAccountId` set and **no** `Name`. This is the
  one that works: permission sets and console access only exist here.
- an **account instance** (what `aws sso-admin create-instance` makes on a standalone
  account) has a `Name` and no `OwnerAccountId`. It **cannot carry permission sets and
  cannot be converted** — deleting it is the only way out.
- an empty list means nothing is enabled yet, and
  `docs/runbooks/identity-center-bootstrap.md` step 0 is the decision to make first.

### Resources CDK cannot tag, and what covers them instead

`RequiredTagsAspect` fails synthesis when a **taggable** resource is missing one of the
six mandatory tags. A handful of L1 resources are not taggable at all — CloudFormation
exposes no `Tags` property for them — so the Aspect reads `None` and passes them rather
than failing a deploy over something no code can fix. They are listed here because an
untagged resource is invisible to the per-environment budgets and to the tag-driven AWS
Backup selections, and that has to be a recorded gap rather than a discovered one.

| Resource | Where | Consequence | Covered by |
|---|---|---|---|
| `AWS::Scheduler::Schedule` | `meridian-staging-data`, the nightly RDS stop (L-3) | Its (zero) cost is unattributed; it holds no data | Nothing to back up. Its DLQ, alarm, topic and role **are** tagged |
| `AWS::Scheduler::Schedule` | `meridian-<env>-compute`, the worker's 15-minute sweep tick (`-c worker_enabled=true`) | Same: inside Scheduler's free tier, holds no data | Its schedule group, role and target queue **are** tagged; the group is what `AWS/Scheduler` metrics are cut by |
| `AWS::GuardDuty::MalwareProtectionPlan` | `meridian-<env>-data` | Per-GB scan charges land on the account, not the environment | Tagged via `Tags.of(...)` where the L1 accepts it; the bucket it scans is tagged |

If AWS adds `Tags` to `AWS::Scheduler::Schedule`, delete the row and let the Aspect do it.

### Cost-allocation tags — activate them, and do it early

The per-environment budgets filter on `user:Environment$<env>`. That is a
**cost-allocation** tag, which is not the same thing as the resource tag the Aspect
writes: a resource tag becomes a cost-allocation tag only once it is activated, once,
per account, in Billing. Until then the filter matches nothing, both environment
budgets sit at $0.00 for ever, and the only budget doing any work is the unfiltered
$300 account one.

```bash
# Activate. Run from the management/payer account; one-time, free.
aws ce update-cost-allocation-tags-status \
  --cost-allocation-tags-status TagKey=Environment,Status=Active TagKey=Project,Status=Active

# Verify — both must show Status: Active
aws ce list-cost-allocation-tags --status Active \
  --query 'CostAllocationTags[?TagKey==`Environment` || TagKey==`Project`]'
```

Two properties make the timing matter:

- **It is not retroactive.** Spend tagged before activation is not re-attributed.
- **It takes up to 24 hours** for the activated tag to appear in cost data.

So activate before the resources exist, not after the first surprising bill. AWS also
cannot activate a tag key it has never seen, so if the command reports the key as
unknown, deploy one tagged stack, wait a day, and run it again.

## Context switches (see `cdk.json` for the full notes)

The AWS account is shared with another owner's application (ADR 0001), and
GuardDuty, Security Hub, the Config recorder, Inspector and the GitHub OIDC
provider are **singletons per account**. If one already exists, creating a second
fails the whole stack. Each sits behind a context flag — `enableGuardDuty`,
`enableSecurityHub`, `enableConfigRecorder`, `enableInspector`,
`enableAccessAnalyzer`, `createGithubOidcProvider` — all defaulting to `true`. Turn
one off only when the other owner got there first, and record the reason in
`docs/compliance/`. Do not adopt or modify their resource. "Pre-deploy checks" above
has the read-only command that decides each one.

`enableServiceAnomalyMonitor` is the exception that proves the pattern: same shape, but
it defaults to **`false`**, because the singleton it guards already exists on this
account by default rather than by someone else's choice. Its companion,
`existingServiceAnomalyMonitorArn`, is the only context value in this stack that names a
resource we do not own.

### The edge stacks are `us-east-1` only, and now say so

`meridian-shared-foundation` and `meridian-<env>-edge` raise at synth if their
resolved region is anything but `us-east-1`. (`meridian-<env>-dr` is the deliberate
exception — it exists to be somewhere else, and does not call the guard.) Three things make that non-negotiable: the
`CLOUDFRONT`-scoped WAF web ACL, the ACM certificate CloudFront uses, and `AWS::CE::*`.
The check is skipped when the region is an unresolved token, which is every offline
`cdk synth` and every CI run — so it costs nothing there and fires exactly when real
credentials point somewhere wrong.

## Phase 1 Verify — the steps only a human can do

Everything in this repository is asserted by `pytest` and re-proved by `cdk diff`.
These are the ones that are not, because they need a browser, a mailbox, a phone or a
decision. Phase 1 is not finished until each is done **and dated** — in
`docs/compliance/`, which is the evidence an assessment reads.

| | Step | Where |
|---|---|---|
| ☐ | Andres approves the cost estimate, in writing | `docs/reports/phase-1-cost-estimate.md` §5 |
| ☐ | Decide: create an AWS Organization, or take the IAM-users-with-MFA fallback | `docs/runbooks/identity-center-bootstrap.md` §0 |
| ☐ | Activate `Environment` and `Project` as cost-allocation tags, then verify 24h later | "Pre-deploy checks", above |
| ☐ | Sign in through the Identity Center portal and enrol MFA — **both** members | identity-center runbook §4 |
| ☐ | Finish the IAM triage in order: MFA → drop `AdministratorAccess` → deactivate the key | identity-center runbook §6–§8 |
| ☐ | Confirm the SNS subscription emails (security alerts, SES events) — an unconfirmed subscription delivers nothing | inbox |
| ☐ | **Run the break-glass drill.** Assume the role, confirm the alarm email arrives, record the elapsed time | `docs/runbooks/break-glass.md` — "Drill" |
| ☐ | File the SES production-access request | `docs/runbooks/dns-nameserver-switch.md` §7 |

The break-glass drill is on this list rather than in the runbook's own schedule for a
reason: it is the only test of the emergency access procedure that exists, and it
exercises three things at once that nothing else does — that a member of
`meridian-shared-iam-humans` can actually assume the role (a trust policy grants
nothing by itself), that CloudTrail is delivering to CloudWatch Logs, and that the SNS
subscription is confirmed. A drill that does not produce the email is a failed drill,
and finding that out during an emergency is the whole thing being prevented.

## Staging teardown (ADR 0008 / plan D-15)

Staging exists only while a staging session is running; a standing staging
environment would blow the ~$250/month ceiling on its own.

**At the end of a session** — the full procedure is
`docs/runbooks/staging-teardown.md`, wrapped by `scripts/staging_session.sh down`:

```bash
npx cdk destroy -c env=staging \
  meridian-staging-observability meridian-staging-api \
  meridian-staging-compute meridian-staging-edge
```

**`compute` has to go before `edge`, and the order above is not incidental.** Since
Phase 5a the ECS services register into the `edge` stack's two ALB target groups, so
`compute` imports from `edge` — the one import ADR 0020's split did not have. The CDK
CLI works the order out from the dependency graph when all four names are given in one
command, as they are here; destroying `edge` on its own first is refused by
CloudFormation, which will not delete a stack whose exports are in use. That is a
refusal rather than an outage, which is the point of letting the graph carry the rule.

`compute` also imports from `auth` (T:102): the pool id, the web client id, the hosted
domain and the ARN of `meridian-<env>/cognito-web-client` — the web client's secret,
which CloudFormation copies into Secrets Manager so the api task receives it through
`secrets:` like the database password. `auth` is persistent, so this import never
touches a staging teardown; it does mean `auth` must be deployed before `compute`.

**`-c emailBackend=resend`** (default `ses`) is the SES → Resend rollback on ECS:
`EMAIL_BACKEND=resend`, `RESEND_FROM_EMAIL`, and `RESEND_API_KEY` mapped from a secret
named `meridian-<env>/resend-api-key` that a human creates first
(`docs/runbooks/email-cutover.md` §2). Any other value is refused at synth.

**Staging has no scheduled AWS Backup plan (M-2).** The nightly stop schedule turns the
instance off at 02:00 America/Chicago, so a 05:00 UTC plan would fail every night. Staging
keeps the locked vault and the backup role; `scripts/staging_session.sh down` starts one
on-demand job before it stops the instance, and PITR (7 days) covers the rest. The
scheduled daily plan and its two selections exist in **production only**.

**Leave `meridian-staging-vpc`, `meridian-staging-data` and `meridian-staging-auth`
alone.** `vpc` costs nothing and `data` depends on it (ADR 0020), so CloudFormation
refuses to destroy it anyway. The data stack holds the KMS keys, the secrets, the
buckets and the RDS instance; the instance stops itself on a schedule (RDS restarts
itself after 7 days stopped, so the schedule is part of the stack, not a chore), and
`scripts/staging_session.sh up` starts it again. Destroying the stack would schedule
the keys for deletion, and a scheduled key deletion is how encrypted backups quietly
become unreadable. Everything in it is `RemovalPolicy.RETAIN` so that this is
structural rather than a promise. **It also holds the origin-verify secret**
(ADR 0018 §7), which is why the teardown no longer has to force-delete anything: the
name is never taken out of circulation and the secret's version history — which the
rotation procedure depends on — survives.

**At the start of the next session, name the four stacks. Never `--all`:**

```bash
npx cdk deploy -c env=staging \
  -c cloudfrontPrefixListId=pl-... \
  -c hostedZoneId=Z... \
  -c originVerifyCloudFrontVersionId=<version id> \
  meridian-staging-edge meridian-staging-compute \
  meridian-staging-api meridian-staging-observability
```

`--all` pulls in `meridian-shared-foundation`, `meridian-shared-dns`,
`meridian-shared-identity`, `meridian-staging-vpc`, `meridian-staging-data` and
`meridian-staging-auth` — the six stacks the paragraph above says to leave alone. It also needs the deploy-time
parameters the shared stacks require, so the likely outcome is a failed deploy; the
*worse* outcome is a successful one that re-renders `meridian-shared-identity` without
the Identity Center identifiers and deletes the permission sets.

If `infra/cdk.context.json` has no `ssoInstanceArn`, add
`-c allowNoIdentityCenter=true`. That is a **synth** waiver, not a deploy one — it
only lets the app render, and none of the four stacks above is the identity stack.
`scripts/staging_session.sh` adds it for you when the file lacks the value.

~15 minutes. Every session re-proves the whole app from empty, which is exactly the
rehearsal a future account split needs.

## Conventions this code enforces

- **Naming:** `meridian-<env>-<component>-<purpose>`; stacks are
  `meridian-<env>-<component>`, with `shared` as the pseudo-environment for the three
  account-level ones (`foundation`, `dns`, `identity`).
- **Tags:** `Project`, `Environment`, `Owner`, `DataClassification`
  (`phi|internal|public`), `CostCenter`, `ManagedBy=cdk` on every taggable
  resource. Synthesis fails without them, so CI fails without them. They are not
  decoration: per-environment budgets filter on `Environment`, IAM conditions read
  `aws:ResourceTag/Environment`, and the PHI controls read `DataClassification`.
- **`phi` is a claim, not a default.** It belongs to the data stack's RDS
  instance, `phi` bucket and their keys. Audit logs are `internal` — they record
  access *to* PHI, they do not contain it.

### The two names that do not follow the convention

Both are fixed by AWS, not chosen by us. Listing them here so that a future session
does not "fix" one and break something:

| Name | Why it cannot be `meridian-shared-…` |
|---|---|
| `Operational-Best-Practices-for-HIPAA-Security` | The conformance pack keeps AWS's published name. It is how the control set is identifiable as the standard HIPAA pack rather than a local variant — in Security Hub, in Config's console, and to anyone comparing our results against AWS's documentation. Renaming it would make a 130-rule AWS artefact look bespoke. |
| `/aws/cloudtrail/…` and `/aws/lambda/…` log groups | CloudWatch reserves the `/aws/<service>/` prefix, and Lambda in particular resolves its log group by that path. The *suffix* still follows the convention (`/aws/cloudtrail/meridian-shared-cloudtrail-audit`, `/aws/lambda/meridian-shared-inspector-ecr`), so the resource is still attributable in a shared account. |

Everything else — including the SES configuration set and its event destination
(`meridian-shared-ses-events`) — follows the convention, because in an account shared
with another owner (ADR 0001) an unattributable resource name is a real cost.
