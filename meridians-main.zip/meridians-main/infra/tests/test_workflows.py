"""The two workflows' infrastructure decisions, as text assertions.

* **`deploy.yml` never deploys production (T:124).** Decided, not pending: the input
  offers `staging` only, the guard accepts only `deploy-staging`, and
  `docs/runbooks/cutover.md` precondition C is written to match. A production target
  added here without changing the runbook would make the cutover checklist wrong.
* **`infra-diff` passes the two edge identifiers (T:136)** from the same repository
  variables `deploy.yml` uses, so `vpc` and `edge` stop diffing against their synth
  placeholders on every run.

Read as text rather than parsed: no YAML library is a dependency of the infra job.
"""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DEPLOY = (ROOT / ".github" / "workflows" / "deploy.yml").read_text()
BACKEND = (ROOT / ".github" / "workflows" / "backend.yml").read_text()


def _job(text: str, name: str) -> str:
    """One top-level job's block: from `  name:` to the next two-space key or EOF."""
    match = re.search(rf"^  {re.escape(name)}:\n(.*?)(?=^  [\w-]+:\n|\Z)", text, re.M | re.S)
    assert match, f"no job {name}"
    return match.group(1)


def test_deploy_offers_staging_and_nothing_else() -> None:
    options = re.search(r"options:\s*\[([^\]]*)\]", DEPLOY)
    assert options and [o.strip() for o in options.group(1).split(",")] == ["staging"]
    assert "!= \"deploy-staging\"" in DEPLOY
    assert "deploy-production" not in DEPLOY


def test_the_decision_is_written_where_the_cutover_reads_it() -> None:
    assert "PRODUCTION IS NEVER DEPLOYED FROM HERE" in DEPLOY
    cutover = (ROOT / "docs" / "runbooks" / "cutover.md").read_text()
    assert "Decided (T:124)" in cutover


def test_infra_diff_passes_both_edge_identifiers_from_repository_variables() -> None:
    job = _job(BACKEND, "infra-diff")
    assert "MERIDIAN_CF_PREFIX_LIST_ID: ${{ vars.MERIDIAN_CF_PREFIX_LIST_ID }}" in job
    assert "MERIDIAN_HOSTED_ZONE_ID: ${{ vars.MERIDIAN_HOSTED_ZONE_ID }}" in job
    command = re.sub(r"\\\n\s*", " ", job)
    diff = re.search(r"npx cdk diff ([^\n]*)", command)
    assert diff, "no cdk diff in infra-diff"
    assert '-c cloudfrontPrefixListId="$MERIDIAN_CF_PREFIX_LIST_ID"' in diff.group(1)
    assert '-c hostedZoneId="$MERIDIAN_HOSTED_ZONE_ID"' in diff.group(1)
    # Still read-only: template mode, never a change set.
    assert "--method=template" in diff.group(1)
    # And never a secret: identifiers are variables, not `secrets.*`.
    assert "secrets." not in job


def test_an_empty_identifier_is_the_same_as_none() -> None:
    """Unset repository variables arrive as "" — both stacks must read that as unset."""
    import app as cdk_app
    import aws_cdk as cdk
    from conftest import NO_IDENTITY_CENTER

    application = cdk.App(
        context={
            "env": "staging",
            **NO_IDENTITY_CENTER,
            "cloudfrontPrefixListId": "",
            "hostedZoneId": "",
        }
    )
    cdk_app.build(application)
    assembly = application.synth()
    vpc = str(assembly.get_stack_by_name("meridian-staging-vpc").template)
    from meridian.stacks.vpc import PLACEHOLDER_PREFIX_LIST_ID

    assert PLACEHOLDER_PREFIX_LIST_ID in vpc
    edge = assembly.get_stack_by_name("meridian-staging-edge").template
    record_sets = [r for r in edge["Resources"].values() if r["Type"] == "AWS::Route53::RecordSet"]
    assert record_sets == []
