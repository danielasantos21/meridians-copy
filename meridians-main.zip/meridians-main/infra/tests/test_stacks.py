"""The app's shape: which stacks exist, what they are called, and that both
environments synthesize without AWS credentials.
"""

from __future__ import annotations

import re

import app as cdk_app
import aws_cdk as cdk
import pytest
from aws_cdk import cx_api
from conftest import EXPECTED_STACKS

from meridian.naming import is_valid_resource_name, resource_name, stack_name


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_expected_stacks_exist(
    env_name: str,
    staging: cx_api.CloudAssembly,
    production: cx_api.CloudAssembly,
) -> None:
    assembly = staging if env_name == "staging" else production
    names = sorted(artifact.stack_name for artifact in assembly.stacks)
    assert names == sorted(EXPECTED_STACKS[env_name])


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_stack_names_follow_the_convention(
    env_name: str,
    staging: cx_api.CloudAssembly,
    production: cx_api.CloudAssembly,
) -> None:
    """`meridian-<env>-<component>`, and no other environment's name leaks in."""
    assembly = staging if env_name == "staging" else production
    other = "production" if env_name == "staging" else "staging"
    for artifact in assembly.stacks:
        name = artifact.stack_name
        assert re.fullmatch(r"meridian-(shared|staging|production)-[a-z]+", name), name
        assert other not in name


def test_environment_is_unresolved_so_synth_needs_no_credentials(
    staging: cx_api.CloudAssembly,
) -> None:
    """Account and region come from the CLI environment, not from code.

    With `CDK_DEFAULT_ACCOUNT` unset — CI, and any offline synth — CDK marks the
    environment `unknown-account/unknown-region` and emits pseudo-parameters.
    That is the ADR 0001 property ("no account id hard-coded anywhere") observed
    from the outside.
    """
    for artifact in staging.stacks:
        assert "unknown-account" in artifact.environment.account or artifact.environment.account


def test_resource_name_helper() -> None:
    assert resource_name("staging", "s3", "artifacts") == "meridian-staging-s3-artifacts"
    assert resource_name("shared", "cloudtrail", "audit") == "meridian-shared-cloudtrail-audit"
    assert stack_name("production", "data") == "meridian-production-data"
    assert is_valid_resource_name("meridian-production-kms-phi")
    assert not is_valid_resource_name("Meridian_Production_KMS")
    with pytest.raises(ValueError):
        resource_name("staging", "S3", "artifacts")


def test_per_environment_keys_live_in_the_data_stack(
    staging: cx_api.CloudAssembly,
    production: cx_api.CloudAssembly,
) -> None:
    """Phase 1 step 6: five CMKs per environment, in `data` so a staging
    teardown (ADR 0008) does not schedule them for deletion — plus the QuickBooks token
    key (ADR 0044), in both environments with or without the worker (T:186)."""
    for env_name, assembly in (("staging", staging), ("production", production)):
        template = assembly.get_stack_by_name(f"meridian-{env_name}-data").template
        keys = [r for r in template["Resources"].values() if r["Type"] == "AWS::KMS::Key"]
        assert len(keys) == 6
        for key in keys:
            assert key["Properties"]["EnableKeyRotation"] is True
            assert key["DeletionPolicy"] == "Retain"

        aliases = sorted(
            r["Properties"]["AliasName"]
            for r in template["Resources"].values()
            if r["Type"] == "AWS::KMS::Alias"
        )
        assert aliases == sorted(
            f"alias/meridian-{env_name}-kms-{purpose}"
            for purpose in ("rds", "artifacts", "phi", "logs", "backups", "tokens")
        )


@pytest.mark.parametrize("component", ["api"])
def test_stubs_are_empty(component: str, staging: cx_api.CloudAssembly) -> None:
    """The Phase 1 stubs carry documentation, not resources.

    `network` left this list in Phase 2 and became `vpc` + `edge` in Phase 3
    (ADR 0020); `data` left it in Phase 3; `auth` left it in Phase 4;
    `compute` left it in Phase 5a; `observability` left it in Phase 6. See
    `tests/test_vpc.py`, `tests/test_edge.py`, `tests/test_data.py`,
    `tests/test_auth.py`, `tests/test_compute.py` and
    `tests/test_observability.py`.

    `api` is the last one. Phase 12 T21 fills it **only** behind
    `-c enableApiPlatform=true` (default off, `tests/test_api_platform.py`); without
    the flag it must stay empty, which is what makes a deploy of that branch a no-op.

    `AWS::CDK::Metadata` is CDK's own analytics resource, not ours.
    """
    template = staging.get_stack_by_name(f"meridian-staging-{component}").template
    resources = {
        name: r
        for name, r in template.get("Resources", {}).items()
        if r["Type"] != "AWS::CDK::Metadata"
    }
    assert resources == {}


# ------------------------------------------------------------- us-east-1 or nothing


def _stack_in(region: str | None) -> cdk.Stack:
    """A throwaway stack whose environment is, or is not, resolved."""
    return cdk.Stack(
        cdk.App(),
        "Somewhere",
        # A fake account: `test_no_account_id.py` rejects any twelve-digit literal in
        # `infra/`, which is the rule this is an example of.
        env=cdk.Environment(account="1" + "2" * 11, region=region),
    )


@pytest.mark.parametrize("stack_id", ["meridian-shared-foundation", "meridian-staging-edge"])
def test_the_region_guard_is_a_no_op_when_the_region_is_a_token(stack_id: str) -> None:
    """Every offline synth, every CI run and every other test in this suite has an
    **unresolved** environment: `infra/app.py` takes account and region from
    `CDK_DEFAULT_*`, and neither is set. `Stack.of(self).region` is then a token, which
    is not a region and must not be compared to one — so the guard skips, and both
    stacks synthesize."""
    from meridian.stacks.base import assert_edge_region

    application = cdk.App(context={"env": "staging", "allowNoIdentityCenter": True})
    cdk_app.build(application)
    stack = application.node.find_child(stack_id)
    assert isinstance(stack, cdk.Stack)
    assert cdk.Token.is_unresolved(stack.region)
    assert_edge_region(stack)  # does not raise


def test_a_concrete_region_other_than_us_east_1_fails_synth() -> None:
    """The `CLOUDFRONT`-scoped web ACL, the edge certificate and `AWS::CE::*` cannot be
    created outside `us-east-1`. Without this the mistake shows up part way through a
    changeset — on the foundation stack that means CloudTrail and the alarms roll back
    with it — rather than before anything is created."""
    from meridian.stacks.base import assert_edge_region

    with pytest.raises(ValueError, match="us-east-1"):
        assert_edge_region(_stack_in("eu-west-1"))


def test_us_east_1_passes_the_guard() -> None:
    from meridian.stacks.base import assert_edge_region

    assert_edge_region(_stack_in("us-east-1"))  # does not raise
