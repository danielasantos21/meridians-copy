"""`meridian-<env>-vpc`: subnets, gateway endpoints, security groups — and that it is free.

The security-group sweep is the test that matters. Everything else here would be
caught by a deploy failing; an accidentally open port succeeds, works, and is only
noticed by whoever finds it first.

The other load-bearing tests are the ADR 0020 ones at the bottom: **nothing billed by
the hour is in this stack**, and **this stack imports nothing from `edge` or `data`**.
Together those are what make `cdk destroy meridian-staging-edge` safe, which is the whole
reason the split exists.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import pytest
from aws_cdk import assertions, cx_api
from conftest import NETWORK_CONTEXT, synth_with, vpc_template

from meridian.stacks.vpc import PLACEHOLDER_PREFIX_LIST_ID, VPC_CIDR

ENVIRONMENTS = ("staging", "production")

#: The ports an open ingress rule would be worst on. 22 is SSH, which this estate
#: does not use at all (SSM Session Manager instead); 5432 is PostgreSQL.
FORBIDDEN_OPEN_PORTS = (22, 5432)

OPEN_CIDRS = ("0.0.0.0/0", "::/0")

#: Resource types AWS bills by the hour whether or not anything uses them. None of them
#: may appear in the persistent stack — see `test_nothing_billed_by_the_hour_is_in_here`.
HOURLY_BILLED_TYPES = (
    "AWS::EC2::NatGateway",
    "AWS::EC2::Instance",
    "AWS::ElasticLoadBalancingV2::LoadBalancer",
    "AWS::RDS::DBInstance",
    "AWS::WAFv2::WebACL",
    "AWS::CloudFront::Distribution",
)


def _resources(template: assertions.Template, type_name: str) -> Mapping[str, Any]:
    return template.find_resources(type_name)


# ----------------------------------------------------------------- subnet layout


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_two_azs_and_three_subnet_tiers(env_name: str) -> None:
    """2 AZs × (public, private-app, private-data) = 6 subnets."""
    template = vpc_template(env_name)
    subnets = _resources(template, "AWS::EC2::Subnet")
    assert len(subnets) == 6

    names: list[str] = []
    for subnet in subnets.values():
        tags = {tag["Key"]: tag["Value"] for tag in subnet["Properties"].get("Tags", [])}
        names.append(tags["aws-cdk:subnet-name"])
    assert sorted(names) == sorted(["public"] * 2 + ["private-app"] * 2 + ["private-data"] * 2)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_only_routes_here_are_the_public_ones(env_name: str) -> None:
    """**ADR 0020, from the routing side.** The persistent stack has two routes: public
    subnet → internet gateway. Both private tiers have a route table with nothing in it.

    `private-app`'s default route to the NAT is added by `edge`, because the NAT is
    $37.50/month and belongs in the stack staging destroys. `private-data` never gets a
    route in either stack — the database has no business reaching the internet, so it
    cannot, and that property does not depend on which stacks happen to be deployed.
    """
    template = vpc_template(env_name)
    routes = _resources(template, "AWS::EC2::Route")
    assert len(routes) == 2
    for route in routes.values():
        assert "GatewayId" in route["Properties"], route
        assert "NatGatewayId" not in route["Properties"], route


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_no_nat_gateway_lives_in_the_persistent_stack(env_name: str) -> None:
    """The NAT is the largest hourly charge in a staging session. It is in `edge`."""
    template = vpc_template(env_name)
    assert _resources(template, "AWS::EC2::NatGateway") == {}
    assert _resources(template, "AWS::EC2::EIP") == {}


def test_the_two_environments_do_not_share_a_cidr() -> None:
    assert VPC_CIDR["staging"] != VPC_CIDR["production"]
    for env_name in ENVIRONMENTS:
        template = vpc_template(env_name)
        template.has_resource_properties("AWS::EC2::VPC", {"CidrBlock": VPC_CIDR[env_name]})


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_nothing_peers_with_anything(env_name: str) -> None:
    """ADR 0001: no peering with the other owner's VPC or the default VPC, ever."""
    template = vpc_template(env_name)
    assert _resources(template, "AWS::EC2::VPCPeeringConnection") == {}
    assert _resources(template, "AWS::EC2::TransitGatewayAttachment") == {}


# --------------------------------------------------------------- VPC endpoints


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_only_the_two_free_gateway_endpoints(env_name: str) -> None:
    """D-19 / ADR 0009: S3 and DynamoDB, both free, and **no interface endpoint**.

    An interface endpoint is $7.30/month per AZ and cannot remove the NAT here, so
    one appearing is a cost regression rather than a security improvement — and it
    would mean someone re-decided D-19 without writing it down. It is also the thing
    that would otherwise make this stack stop being free.
    """
    template = vpc_template(env_name)
    endpoints = _resources(template, "AWS::EC2::VPCEndpoint")
    assert len(endpoints) == 2

    services = []
    for endpoint in endpoints.values():
        props = endpoint["Properties"]
        # Gateway is the default; an interface endpoint says so explicitly.
        assert props.get("VpcEndpointType", "Gateway") == "Gateway"
        services.append(str(props["ServiceName"]))
    assert any("s3" in service for service in services)
    assert any("dynamodb" in service for service in services)


# -------------------------------------------------------------- security groups


def _ingress_rules(template: assertions.Template) -> list[dict[str, Any]]:
    """Every ingress rule, whether inline on a group or a separate resource."""
    rules: list[dict[str, Any]] = []
    for group in _resources(template, "AWS::EC2::SecurityGroup").values():
        rules.extend(group["Properties"].get("SecurityGroupIngress") or [])
    for rule in _resources(template, "AWS::EC2::SecurityGroupIngress").values():
        rules.append(rule["Properties"])
    return rules


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_no_security_group_anywhere_is_open_to_the_internet(env_name: str) -> None:
    """Plan §3 Phase 2 step 3, stated as a test.

    Not "no 22 or 5432 from 0.0.0.0/0" — *no CIDR ingress at all*. Every rule's
    source is a named security group or CloudFront's managed prefix list, which is
    a stronger property and an easier one to check.
    """
    template = vpc_template(env_name)
    for rule in _ingress_rules(template):
        assert rule.get("CidrIp") not in OPEN_CIDRS, rule
        assert rule.get("CidrIpv6") not in OPEN_CIDRS, rule
        assert "CidrIp" not in rule and "CidrIpv6" not in rule, rule
        assert "SourceSecurityGroupId" in rule or "SourcePrefixListId" in rule, rule
        assert rule.get("FromPort") != 22, "SSH is not a thing here; SSM Session Manager is"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_forbidden_ports_are_never_reachable_from_a_cidr(env_name: str) -> None:
    template = vpc_template(env_name)
    for rule in _ingress_rules(template):
        if rule.get("FromPort") in FORBIDDEN_OPEN_PORTS:
            assert "SourceSecurityGroupId" in rule, rule


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_four_named_groups_and_what_each_admits(env_name: str) -> None:
    template = vpc_template(env_name)
    names = {
        group["Properties"]["GroupName"]
        for group in _resources(template, "AWS::EC2::SecurityGroup").values()
    }
    assert names == {f"meridian-{env_name}-sg-{part}" for part in ("alb", "app", "data", "ops")}

    rules = _ingress_rules(template)
    # alb: 443 ONLY, from the CloudFront prefix list only. There is no :80 rule
    # because there is no :80 listener (L-3) — CloudFront dials the origin
    # https-only, so nothing ever arrives on 80 except somebody else's
    # distribution, which the prefix list cannot distinguish from ours.
    prefix_rules = [r for r in rules if "SourcePrefixListId" in r]
    assert sorted(r["FromPort"] for r in prefix_rules) == [443]
    assert all(
        r["SourcePrefixListId"] == NETWORK_CONTEXT["cloudfrontPrefixListId"] for r in prefix_rules
    )

    # data: 5432 twice — from `app` and from `ops`, and from nothing else.
    postgres = [r for r in rules if r.get("FromPort") == 5432]
    assert len(postgres) == 2

    # app: the two container ports, from the ALB.
    assert sorted(r["FromPort"] for r in rules if r.get("FromPort") in (3000, 8000)) == [3000, 8000]


def _egress_rules(template: assertions.Template) -> list[dict[str, Any]]:
    """Every egress rule, whether inline on a group or a separate resource."""
    rules: list[dict[str, Any]] = []
    for group in _resources(template, "AWS::EC2::SecurityGroup").values():
        for rule in group["Properties"].get("SecurityGroupEgress") or []:
            rules.append({**rule, "_group": group["Properties"]["GroupName"]})
    for rule in _resources(template, "AWS::EC2::SecurityGroupEgress").values():
        rules.append(rule["Properties"])
    return rules


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_alb_can_only_reach_the_two_container_ports(env_name: str) -> None:
    """L-2. A security group is stateful, so egress rules do not affect replies to
    traffic the group already admitted — they constrain what the thing can *start*. A
    load balancer has exactly two things to start a connection to."""
    template = vpc_template(env_name)
    alb_group = next(
        name
        for name, group in _resources(template, "AWS::EC2::SecurityGroup").items()
        if group["Properties"]["GroupName"].endswith("-sg-alb")
    )
    egress = [
        rule
        for rule in _resources(template, "AWS::EC2::SecurityGroupEgress").values()
        if rule["Properties"].get("GroupId", {}).get("Fn::GetAtt", [None])[0] == alb_group
    ]
    assert sorted(r["Properties"]["FromPort"] for r in egress) == [3000, 8000]
    for rule in egress:
        assert "DestinationSecurityGroupId" in rule["Properties"], rule
        assert "CidrIp" not in rule["Properties"], rule


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_ops_instance_can_only_reach_443_and_postgres(env_name: str) -> None:
    """L-2. 443 to anywhere is not a concession: SSM Session Manager is an outbound
    HTTPS call to AWS public endpoints, and ADR 0009 buys no interface endpoints. The
    instance is a jump box; 5432 to `data` is the only other thing it may start."""
    template = vpc_template(env_name)
    groups = _resources(template, "AWS::EC2::SecurityGroup")
    ops_group = next(
        name
        for name, group in groups.items()
        if group["Properties"]["GroupName"].endswith("-sg-ops")
    )
    inline = groups[ops_group]["Properties"].get("SecurityGroupEgress") or []
    separate = [
        rule["Properties"]
        for rule in _resources(template, "AWS::EC2::SecurityGroupEgress").values()
        if rule["Properties"].get("GroupId", {}).get("Fn::GetAtt", [None])[0] == ops_group
    ]
    egress = [*inline, *separate]
    assert sorted(rule["FromPort"] for rule in egress) == [443, 5432]

    to_internet = [rule for rule in egress if rule.get("CidrIp") == "0.0.0.0/0"]
    assert [rule["FromPort"] for rule in to_internet] == [443]
    postgres = [rule for rule in egress if rule["FromPort"] == 5432]
    assert all("DestinationSecurityGroupId" in rule for rule in postgres)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_app_tasks_keep_default_egress_deliberately(env_name: str) -> None:
    """L-2, the exception. The app calls Intuit, Google, Microsoft, SES and a dozen AWS
    APIs at addresses that change without notice. A narrower list here is a list that
    goes stale silently and fails as "QuickBooks stopped working". Egress filtering
    that means something needs a proxy, not a security group — ADR 0018 records the
    trigger."""
    template = vpc_template(env_name)
    app_group = next(
        group["Properties"]
        for group in _resources(template, "AWS::EC2::SecurityGroup").values()
        if group["Properties"]["GroupName"].endswith("-sg-app")
    )
    egress = app_group["SecurityGroupEgress"]
    assert any(
        rule.get("CidrIp") == "0.0.0.0/0" and rule.get("IpProtocol") == "-1" for rule in egress
    )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_ops_group_has_zero_ingress(env_name: str) -> None:
    """Session Manager is an outbound connection. An inbound rule here would be a
    path that does not need to exist (plan §2.4)."""
    template = vpc_template(env_name)
    ops_group = [
        (name, group)
        for name, group in _resources(template, "AWS::EC2::SecurityGroup").items()
        if group["Properties"]["GroupName"].endswith("-sg-ops")
    ]
    assert len(ops_group) == 1
    logical_id, group = ops_group[0]
    assert not group["Properties"].get("SecurityGroupIngress")

    for rule in _resources(template, "AWS::EC2::SecurityGroupIngress").values():
        target = rule["Properties"]["GroupId"]
        if isinstance(target, dict):
            assert target.get("Fn::GetAtt", [None])[0] != logical_id


# --------------------------------------------------------- the ADR 0020 contract


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_nothing_billed_by_the_hour_is_in_here(env_name: str) -> None:
    """**ADR 0020's dividing line, as an assertion.**

    This stack persists for ever in both environments, so anything with a standing
    hourly charge in it is a charge that never stops. The split is only worth having
    while that stays true: the day someone puts the NAT or a database back here, staging
    idle stops costing ~$13/month and starts costing ~$50, silently.
    """
    template = vpc_template(env_name)
    for type_name in HOURLY_BILLED_TYPES:
        assert _resources(template, type_name) == {}, type_name


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_persistent_stack_imports_nothing_from_the_transient_one(env_name: str) -> None:
    """**The other half of ADR 0020's safety property.**

    CloudFormation refuses to delete a stack whose exports are in use. So as long as
    every reference points *from* `edge` *to* `vpc` and never back, `cdk destroy` of
    `edge` cannot touch the VPC, the subnets or — through `data`, which also imports from
    here — the database. A single `Fn::ImportValue` in this template would reverse that
    and make the teardown refuse, or worse, succeed on a stack it should not have.
    """
    body = str(vpc_template(env_name).to_json())
    assert "Fn::ImportValue" not in body


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_data_stack_imports_the_security_group_and_subnets_from_here(env_name: str) -> None:
    """The dependency runs `data` → `vpc`, which is what lets the database persist
    while the edge does not. Asserted from the `data` side: the RDS instance's security
    group is an import, not a local resource."""
    from conftest import stack_template

    data = stack_template(env_name, "data")
    instance = next(iter(data.find_resources("AWS::RDS::DBInstance").values()))
    groups = str(instance["Properties"]["VPCSecurityGroups"])
    assert "Fn::ImportValue" in groups
    assert f"meridian-{env_name}-vpc" in groups


# ------------------------------------------------------------------ whole-stack


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_synthesizes_without_credentials_or_errors(env_name: str) -> None:
    """The same property CI relies on: no lookups, no account id, no AWS calls.

    Synthesized here *without* the placeholder context, which is the bare
    `npx cdk synth -c env=...` path.
    """
    assembly: cx_api.CloudAssembly = synth_with(env_name)
    artifact = assembly.get_stack_by_name(f"meridian-{env_name}-vpc")
    errors = [m for m in artifact.messages if m.entry.type == "aws:cdk:error"]
    assert errors == []
    assert artifact.template["Resources"]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_resource_in_the_stack_carries_the_six_tags(env_name: str) -> None:
    template = vpc_template(env_name)
    required = ("Project", "Environment", "Owner", "DataClassification", "CostCenter", "ManagedBy")
    checked = 0
    for name, resource in template.to_json()["Resources"].items():
        tags = resource.get("Properties", {}).get("Tags")
        if not isinstance(tags, list) or not tags or not isinstance(tags[0], dict):
            continue
        keys = {tag.get("Key") for tag in tags}
        assert keys.issuperset(required), name
        checked += 1
    assert checked > 15


def test_without_the_context_value_the_alb_gets_the_fail_closed_placeholder() -> None:
    """No `-c cloudfrontPrefixListId` means a prefix list id that does not exist,
    so the stack fails in CloudFormation rather than deploying an open ALB."""
    template = assertions.Template.from_json(
        synth_with("staging").get_stack_by_name("meridian-staging-vpc").template
    )
    sources = {
        rule["Properties"]["SourcePrefixListId"]
        for rule in template.find_resources("AWS::EC2::SecurityGroupIngress").values()
        if "SourcePrefixListId" in rule["Properties"]
    }
    assert sources == {PLACEHOLDER_PREFIX_LIST_ID}
