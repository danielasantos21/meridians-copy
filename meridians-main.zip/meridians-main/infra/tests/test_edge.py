"""`meridian-<env>-edge`: NAT, flow logs, ALB, listener rules, CloudFront, WAF, ops.

Two of these are load-bearing rather than descriptive:

* `test_the_api_patterns_cover_every_rewrite_in_the_real_next_config` parses
  `web/next.config.mjs` itself. If someone adds a proxied screen to the Next app and
  not to the edge, this fails — instead of the screen 404ing on the live domain.
* `test_every_listener_rule_requires_the_origin_verify_header` is the assertion that
  a direct request to the load balancer cannot reach the application.
* `test_the_alb_claims_every_proxy_handler_prefix` is what makes `web/src/lib/proxy.ts`'s
  "these handlers never run on ECS" a fact rather than a comment (P5AR5-01).
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

import pytest
from aws_cdk import assertions
from conftest import data_template, edge_stack, edge_template

from meridian.edge_paths import (
    MAX_PATTERNS_PER_CONDITION,
    PINNED_API_PATH_PATTERNS,
    api_path_patterns,
    chunked,
    jinja_auth_families,
    jinja_families,
    literal_rewrite_sources,
    next_source_to_alb_patterns,
    read_next_config,
)

ENVIRONMENTS = ("staging", "production")
DOMAIN = "meridiansgrp.com"

#: ADR 0050 — the names each environment's distribution answers for.
VIEWER_ALIASES = {
    "production": [DOMAIN, f"www.{DOMAIN}", f"app.{DOMAIN}", f"api.{DOMAIN}"],
    "staging": [f"staging-app.{DOMAIN}", f"staging-api.{DOMAIN}"],
}
APP_HOST = {"production": f"app.{DOMAIN}", "staging": f"staging-app.{DOMAIN}"}
API_HOST = {"production": f"api.{DOMAIN}", "staging": f"staging-api.{DOMAIN}"}
ORIGIN_VERIFY_HEADER = "X-Origin-Verify"

#: AWS managed cache/origin-request policy ids. They are stable, documented
#: constants, and asserting on them is how "no caching, forward everything" is
#: checked from the outside.
CACHING_DISABLED = "4135ea2d-6df8-44a3-9df3-4b5a84be39ad"
CACHING_OPTIMIZED = "658327ea-f89d-4fab-a63d-7e88639e58f6"
#: `AllViewerAndCloudFrontHeaders-2022`. Not `ALL_VIEWER`
#: (216adef6-5c7f-47e4-b989-5492eafa07d3): that one forwards viewer headers only,
#: and the header the API needs is one CloudFront writes about the viewer —
#: `CloudFront-Viewer-Address` (P5AR3-02 / P5AR4-02).
ALL_VIEWER_AND_CLOUDFRONT = "33f36d7e-f396-46d9-90e0-52428a34d9dc"


def _resources(template: assertions.Template, type_name: str) -> Mapping[str, Any]:
    return template.find_resources(type_name)


def _distribution_config(template: assertions.Template) -> dict[str, Any]:
    distributions = _resources(template, "AWS::CloudFront::Distribution")
    assert len(distributions) == 1
    config: dict[str, Any] = next(iter(distributions.values()))["Properties"]["DistributionConfig"]
    return config


# ------------------------------------------------- edge_paths.py, on its own


def test_the_generated_patterns_match_the_pinned_list() -> None:
    """The pin is the review gate: changing `next.config.mjs` changes this list,
    and the change has to be made here on purpose."""
    assert tuple(api_path_patterns()) == PINNED_API_PATH_PATTERNS
    assert len(PINNED_API_PATH_PATTERNS) == 3  # 0 Jinja families × 2, + 3 literals


def test_one_next_source_becomes_the_right_alb_patterns() -> None:
    assert next_source_to_alb_patterns("/profile") == ["/profile", "/profile/*"]
    assert next_source_to_alb_patterns("/api/:path*") == ["/api/*"]
    assert next_source_to_alb_patterns("/static/:path*") == ["/static/*"]


def test_the_rollback_hatch_paths_are_excluded() -> None:
    """`/login` and `/dashboard` only exist behind `MERIDIAN_JINJA_AUTH=1`. Routing
    `/login` to Flask at the edge would make the React sign-in unreachable."""
    config = read_next_config()
    assert jinja_auth_families(config) == ["/login", "/dashboard"]
    assert "/login" not in api_path_patterns()
    assert "/dashboard" not in api_path_patterns()


def test_the_api_patterns_cover_every_rewrite_in_the_real_next_config() -> None:
    """Parses the live file. One omission here is a hard 404 on a production screen."""
    config = read_next_config()
    patterns = set(api_path_patterns(config))

    for family in jinja_families(config):
        assert family in patterns, family
        assert f"{family}/*" in patterns, family
    for source in literal_rewrite_sources(config):
        for pattern in next_source_to_alb_patterns(source):
            assert pattern in patterns, source

    assert {"/api/*", "/auth/*", "/static/*"} <= patterns


def test_the_chunks_respect_the_five_values_per_condition_quota() -> None:
    chunks = chunked(list(PINNED_API_PATH_PATTERNS))
    assert all(len(chunk) <= MAX_PATTERNS_PER_CONDITION for chunk in chunks)
    assert [p for chunk in chunks for p in chunk] == list(PINNED_API_PATH_PATTERNS)
    assert len(chunks) == 1


# ------------------------------------------------------------------------- ALB


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_alb_attributes(env_name: str) -> None:
    template = edge_template(env_name)
    balancers = _resources(template, "AWS::ElasticLoadBalancingV2::LoadBalancer")
    assert len(balancers) == 1
    props = next(iter(balancers.values()))["Properties"]
    assert props["Scheme"] == "internet-facing"
    assert props["Name"] == f"meridian-{env_name}-alb-edge"

    attributes = {a["Key"]: a["Value"] for a in props["LoadBalancerAttributes"]}
    assert attributes["routing.http.drop_invalid_header_fields.enabled"] == "true"
    assert attributes["idle_timeout.timeout_seconds"] == "120"
    assert attributes["access_logs.s3.enabled"] == "true"
    assert attributes["access_logs.s3.prefix"] == "alb"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_there_is_no_port_80_listener_at_the_origin(env_name: str) -> None:
    """L-3. CloudFront dials the origin `https-only`, so nothing legitimate ever
    arrives on :80 — and the prefix list that guards the ALB is AWS's list of
    *every* CloudFront distribution, so a :80 redirect listener could only ever have
    been used by somebody else's. The viewer-facing http→https redirect is
    CloudFront's `REDIRECT_TO_HTTPS` and happens at the edge."""
    template = edge_template(env_name)
    ports = {
        listener["Properties"]["Port"]
        for listener in _resources(template, "AWS::ElasticLoadBalancingV2::Listener").values()
    }
    assert ports == {443}


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_https_listener_refuses_by_default(env_name: str) -> None:
    """Anything that matches no rule — i.e. anything without the origin-verify
    header — gets a fixed 403. The load balancer is not a fallback web server."""
    template = edge_template(env_name)
    listeners = [
        listener["Properties"]
        for listener in _resources(template, "AWS::ElasticLoadBalancingV2::Listener").values()
        if listener["Properties"]["Port"] == 443
    ]
    assert len(listeners) == 1
    action = listeners[0]["DefaultActions"][0]
    assert action["Type"] == "fixed-response"
    assert action["FixedResponseConfig"]["StatusCode"] == "403"
    assert listeners[0]["SslPolicy"].startswith("ELBSecurityPolicy-TLS13-1-2")


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_listener_rule_requires_the_origin_verify_header(env_name: str) -> None:
    template = edge_template(env_name)
    rules = _resources(template, "AWS::ElasticLoadBalancingV2::ListenerRule")
    assert len(rules) == 2  # one api chunk + the web catch-all

    for name, rule in rules.items():
        fields = [c["Field"] for c in rule["Properties"]["Conditions"]]
        assert "http-header" in fields, name
        header = next(c for c in rule["Properties"]["Conditions"] if c["Field"] == "http-header")
        assert header["HttpHeaderConfig"]["HttpHeaderName"] == ORIGIN_VERIFY_HEADER
        # The value is a Secrets Manager dynamic reference, never a literal.
        assert "resolve:secretsmanager" in json.dumps(header["HttpHeaderConfig"]["Values"])


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_api_rules_carry_exactly_the_generated_patterns(env_name: str) -> None:
    template = edge_template(env_name)
    api_target = None
    for name, group in _resources(template, "AWS::ElasticLoadBalancingV2::TargetGroup").items():
        if group["Properties"]["Name"] == f"meridian-{env_name}-tg-api":
            api_target = name
    assert api_target is not None

    patterns: list[str] = []
    for rule in _resources(template, "AWS::ElasticLoadBalancingV2::ListenerRule").values():
        forwarded = rule["Properties"]["Actions"][0].get("TargetGroupArn", {})
        if forwarded.get("Ref") != api_target:
            continue
        for condition in rule["Properties"]["Conditions"]:
            if condition["Field"] == "path-pattern":
                values = condition["PathPatternConfig"]["Values"]
                assert len(values) <= MAX_PATTERNS_PER_CONDITION
                patterns.extend(values)

    assert patterns == list(PINNED_API_PATH_PATTERNS)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_both_target_groups_are_ip_type_with_the_right_health_checks(env_name: str) -> None:
    """`TargetType.IP` because Fargate tasks are ENIs. No targets yet — Phase 5a."""
    template = edge_template(env_name)
    groups = {
        group["Properties"]["Name"]: group["Properties"]
        for group in _resources(template, "AWS::ElasticLoadBalancingV2::TargetGroup").values()
    }
    assert set(groups) == {f"meridian-{env_name}-tg-web", f"meridian-{env_name}-tg-api"}
    for props in groups.values():
        assert props["TargetType"] == "ip"
        assert "Targets" not in props

    assert groups[f"meridian-{env_name}-tg-api"]["HealthCheckPath"] == "/api/v1/health"  # D-25
    assert groups[f"meridian-{env_name}-tg-web"]["HealthCheckPath"] == "/"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_alb_access_log_bucket_is_sse_s3_and_expires(env_name: str) -> None:
    """SSE-S3, not SSE-KMS: ELB log delivery cannot write to a KMS-encrypted bucket,
    and the failure mode is silence rather than an error."""
    template = edge_template(env_name)
    buckets = {
        bucket["Properties"]["BucketName"]: bucket["Properties"]
        for bucket in _resources(template, "AWS::S3::Bucket").values()
    }
    props = buckets[f"meridian-{env_name}-s3-alb-logs"]
    algorithms = [
        rule["ServerSideEncryptionByDefault"]["SSEAlgorithm"]
        for rule in props["BucketEncryption"]["ServerSideEncryptionConfiguration"]
    ]
    assert algorithms == ["AES256"]
    assert props["PublicAccessBlockConfiguration"]["BlockPublicAcls"] is True
    expirations = [
        rule.get("ExpirationInDays") for rule in props["LifecycleConfiguration"]["Rules"]
    ]
    assert 400 in expirations


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_both_log_buckets_are_tls_only(env_name: str) -> None:
    template = edge_template(env_name)
    policies = json.dumps(
        [p["Properties"] for p in _resources(template, "AWS::S3::BucketPolicy").values()]
    )
    assert policies.count('"aws:SecureTransport": "false"') == 2


# ------------------------------------------------------------------ CloudFront


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_cloudfront_talks_to_the_origin_over_https_only(env_name: str) -> None:
    template = edge_template(env_name)
    config = _distribution_config(template)
    origins = config["Origins"]
    assert len(origins) == 1
    custom = origins[0]["CustomOriginConfig"]
    assert custom["OriginProtocolPolicy"] == "https-only"
    assert custom["OriginSSLProtocols"] == ["TLSv1.2"]
    assert origins[0]["DomainName"] == f"origin-{env_name}.{DOMAIN}"

    headers = origins[0]["OriginCustomHeaders"]
    assert [h["HeaderName"] for h in headers] == [ORIGIN_VERIFY_HEADER]
    assert "resolve:secretsmanager" in json.dumps(headers[0]["HeaderValue"])


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_viewer_tls_and_aliases(env_name: str) -> None:
    template = edge_template(env_name)
    config = _distribution_config(template)
    assert config["ViewerCertificate"]["MinimumProtocolVersion"] == "TLSv1.2_2021"
    assert config["ViewerCertificate"]["SslSupportMethod"] == "sni-only"
    assert config["DefaultCacheBehavior"]["ViewerProtocolPolicy"] == "redirect-to-https"

    assert sorted(config["Aliases"]) == sorted(VIEWER_ALIASES[env_name])


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_host_router_runs_on_every_behaviour(env_name: str) -> None:
    """ADR 0050. One behaviour without it would let `api.` serve that path pattern,
    or `www.` serve the app — so every behaviour, the cached one included."""
    template = edge_template(env_name)
    (function_id,) = _resources(template, "AWS::CloudFront::Function")
    function = _resources(template, "AWS::CloudFront::Function")[function_id]["Properties"]
    assert function["Name"] == f"meridian-{env_name}-cff-host-router"
    assert function["FunctionConfig"]["Runtime"] == "cloudfront-js-2.0"
    assert function["AutoPublish"] is True
    assert APP_HOST[env_name] in function["FunctionCode"]
    assert API_HOST[env_name] in function["FunctionCode"]

    config = _distribution_config(template)
    behaviours = [config["DefaultCacheBehavior"], *config["CacheBehaviors"]]
    assert len(behaviours) == 4
    for behaviour in behaviours:
        (association,) = behaviour["FunctionAssociations"]
        assert association["EventType"] == "viewer-request"
        assert association["FunctionARN"] == {"Fn::GetAtt": [function_id, "FunctionARN"]}


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_dynamic_behaviours_cache_nothing_and_forward_everything(env_name: str) -> None:
    """`/api/*` and `/auth/*` carry session cookies. Caching either would serve one
    tenant's response to another."""
    template = edge_template(env_name)
    config = _distribution_config(template)
    behaviours = {b["PathPattern"]: b for b in config["CacheBehaviors"]}

    for pattern in ("/api/*", "/auth/*"):
        assert behaviours[pattern]["CachePolicyId"] == CACHING_DISABLED
        # The `CloudFront-*` family travels too, which is what gives
        # `api.deps.client_address` the viewer's own address instead of an edge
        # node shared by everybody behind it.
        assert behaviours[pattern]["OriginRequestPolicyId"] == ALL_VIEWER_AND_CLOUDFRONT
        assert "POST" in behaviours[pattern]["AllowedMethods"]

    # The default behaviour is uncached too, for now: the app sets cookies on
    # ordinary page responses.
    assert config["DefaultCacheBehavior"]["CachePolicyId"] == CACHING_DISABLED
    assert config["DefaultCacheBehavior"]["OriginRequestPolicyId"] == ALL_VIEWER_AND_CLOUDFRONT

    # The one thing that is cached: content-hashed Next.js assets.
    assert behaviours["/_next/static/*"]["CachePolicyId"] == CACHING_OPTIMIZED


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_cloudfront_logs_to_an_sse_s3_bucket(env_name: str) -> None:
    """CloudFront standard logging writes with an ACL and does not support SSE-KMS."""
    template = edge_template(env_name)
    config = _distribution_config(template)
    assert config["Logging"]["Prefix"] == "cloudfront/"
    assert config["Logging"]["IncludeCookies"] is False

    buckets = {
        bucket["Properties"]["BucketName"]: bucket["Properties"]
        for bucket in _resources(template, "AWS::S3::Bucket").values()
    }
    props = buckets[f"meridian-{env_name}-s3-cdn-logs"]
    algorithms = [
        rule["ServerSideEncryptionByDefault"]["SSEAlgorithm"]
        for rule in props["BucketEncryption"]["ServerSideEncryptionConfiguration"]
    ]
    assert algorithms == ["AES256"]
    ownership = props["OwnershipControls"]["Rules"][0]["ObjectOwnership"]
    assert ownership == "BucketOwnerPreferred"  # ACLs on, as log delivery requires


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_web_acl_is_attached_to_the_distribution(env_name: str) -> None:
    template = edge_template(env_name)
    config = _distribution_config(template)
    assert "WebACLId" in config
    assert config["WebACLId"] == {"Fn::GetAtt": ["WebAcl", "Arn"]}


# ------------------------------------------------------------------------- WAF


def _web_acl(template: assertions.Template) -> dict[str, Any]:
    acls = _resources(template, "AWS::WAFv2::WebACL")
    assert len(acls) == 1
    props: dict[str, Any] = next(iter(acls.values()))["Properties"]
    return props


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_six_waf_rules(env_name: str) -> None:
    template = edge_template(env_name)
    acl = _web_acl(template)
    assert acl["Scope"] == "CLOUDFRONT"
    assert acl["Name"] == f"meridian-{env_name}-waf-edge"

    names = [rule["Name"] for rule in acl["Rules"]]
    assert names == [
        "meridian-body-size-non-upload",
        "AWSManagedRulesCommonRuleSet",
        "AWSManagedRulesKnownBadInputsRuleSet",
        "AWSManagedRulesAmazonIpReputationList",
        "RateLimitPerIp",
        "RateLimitAuthPerIp",
    ]
    # Priority order is evaluation order, and the size rule has to run before the
    # group whose body rules are counted.
    assert [rule["Priority"] for rule in acl["Rules"]] == [0, 1, 2, 3, 4, 5]

    for rule in acl["Rules"]:
        visibility = rule["VisibilityConfig"]
        assert visibility["CloudWatchMetricsEnabled"] is True
        # Never sampled: samples are unredacted full requests (Codex, 2026-09-17).
        assert visibility["SampledRequestsEnabled"] is False

    # The three managed groups keep their own actions — `count` would turn the
    # whole group into logging only.
    for rule in acl["Rules"][1:4]:
        assert rule["OverrideAction"] == {"None": {}}


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_oversized_bodies_are_blocked_off_the_upload_prefix(env_name: str) -> None:
    """**M-K.** The three Count overrides cannot be scoped to the upload paths: a
    managed rule group may be referenced only once per web ACL, and
    `RuleActionOverrides` takes rule names, not conditions. So every POST in the
    product gets an uninspected body, not just the multipart uploads the overrides
    were loosened for.

    This rule puts a floor back under the rest of the surface: over 64 KB, and not
    under `/api/v2/`, is refused before any managed group sees it. It does not restore
    body inspection and does not cover the upload prefix itself — ADR 0018 §8 carries
    that as a dated accepted risk, closed in Phase 5a.
    """
    from meridian.stacks.edge import NON_UPLOAD_BODY_LIMIT_BYTES, UPLOAD_PATH_PREFIX

    rules = {rule["Name"]: rule for rule in _web_acl(edge_template(env_name))["Rules"]}
    rule = rules["meridian-body-size-non-upload"]

    assert rule["Action"] == {"Block": {}}
    assert rule["Priority"] == 0, "must evaluate before the managed groups"

    size, negated = rule["Statement"]["AndStatement"]["Statements"]

    constraint = size["SizeConstraintStatement"]
    assert constraint["ComparisonOperator"] == "GT"
    assert constraint["Size"] == NON_UPLOAD_BODY_LIMIT_BYTES == 16384
    # `MATCH`, never `CONTINUE`: WAF compares only the bytes it inspected (at most the
    # 16 KB limit), so with CONTINUE a "> limit" rule can never fire. MATCH makes an
    # oversized body satisfy the statement outright.
    assert constraint["FieldToMatch"] == {"Body": {"OversizeHandling": "MATCH"}}

    # ADR 0050: the exemption is `/api/v2/` ON THE APP HOST — `www` and `api` take
    # no uploads, so a big body there is refused like anywhere else.
    host, uri = negated["NotStatement"]["Statement"]["AndStatement"]["Statements"]
    host = host["ByteMatchStatement"]
    assert host["FieldToMatch"] == {"SingleHeader": {"Name": "host"}}
    assert host["PositionalConstraint"] == "EXACTLY"
    assert host["SearchString"] == APP_HOST[env_name]
    assert host["TextTransformations"] == [{"Priority": 0, "Type": "LOWERCASE"}]

    uri = uri["ByteMatchStatement"]
    assert uri["FieldToMatch"] == {"UriPath": {}}
    assert uri["PositionalConstraint"] == "STARTS_WITH"
    assert uri["SearchString"] == UPLOAD_PATH_PREFIX == "/api/v2/"
    # The URI is lower-cased first, so `/API/V2/...` cannot dodge the exemption in
    # either direction.
    assert uri["TextTransformations"] == [{"Priority": 0, "Type": "LOWERCASE"}]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_two_rate_rules_block_at_the_documented_limits(env_name: str) -> None:
    template = edge_template(env_name)
    rules = {rule["Name"]: rule for rule in _web_acl(template)["Rules"]}

    broad = rules["RateLimitPerIp"]["Statement"]["RateBasedStatement"]
    assert broad["Limit"] == 2000
    assert broad["EvaluationWindowSec"] == 300
    assert broad["AggregateKeyType"] == "IP"
    assert "ScopeDownStatement" not in broad
    assert rules["RateLimitPerIp"]["Action"] == {"Block": {}}

    auth = rules["RateLimitAuthPerIp"]["Statement"]["RateBasedStatement"]
    assert auth["Limit"] == 100
    assert auth["EvaluationWindowSec"] == 300
    assert rules["RateLimitAuthPerIp"]["Action"] == {"Block": {}}
    scoped = json.dumps(auth["ScopeDownStatement"])
    assert "/api/v2/auth/" in scoped
    assert "/login" in scoped


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_body_inspection_rules_are_counted_not_blocked(env_name: str) -> None:
    """**H-2, and it is the difference between the product working and not.**

    Every Meridian upload is a multipart POST of an Excel workbook, routinely several
    megabytes. `SizeRestrictions_BODY` blocks any body over 8 KB — WAF inspects only
    the first 8 KB and blocks what it cannot see — so left at Block it 403s the core
    workflow at the edge, before the ALB, before Flask, with nothing in the
    application logs. `CrossSiteScripting_BODY` and `GenericRFI_BODY` match patterns
    in that same first 8 KB, which for an `.xlsx` upload is MIME boundaries and ZIP
    header bytes.

    They are set to **Count**, not excluded: a counted rule still evaluates and still
    emits metrics and redacted log entries, so Phase 5a's staging session has evidence to
    tighten against. This test pins the override so that "we turned it off and forgot"
    cannot happen quietly in either direction.
    """
    from meridian.stacks.edge import COMMON_RULE_SET_COUNT_OVERRIDES

    rules = {rule["Name"]: rule for rule in _web_acl(edge_template(env_name))["Rules"]}
    common = rules["AWSManagedRulesCommonRuleSet"]["Statement"]["ManagedRuleGroupStatement"]
    overrides = {o["Name"]: o["ActionToUse"] for o in common["RuleActionOverrides"]}

    assert set(overrides) == set(COMMON_RULE_SET_COUNT_OVERRIDES)
    assert "SizeRestrictions_BODY" in overrides
    assert all(action == {"Count": {}} for action in overrides.values())
    # Every override carries a written reason, so the next reader does not have to
    # guess whether it was deliberate.
    assert all(reason.strip() for reason in COMMON_RULE_SET_COUNT_OVERRIDES.values())

    # The group as a whole still uses its own actions. A group-level `Count` would
    # turn the entire rule set into logging, which is not what any of this is.
    assert rules["AWSManagedRulesCommonRuleSet"]["OverrideAction"] == {"None": {}}


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_only_the_common_rule_set_has_overrides(env_name: str) -> None:
    """The other two managed groups are untouched — they do not inspect bodies."""
    rules = {rule["Name"]: rule for rule in _web_acl(edge_template(env_name))["Rules"]}
    for name in ("AWSManagedRulesKnownBadInputsRuleSet", "AWSManagedRulesAmazonIpReputationList"):
        statement = rules[name]["Statement"]["ManagedRuleGroupStatement"]
        assert "RuleActionOverrides" not in statement


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_waf_logs_to_a_cmk_encrypted_group_with_credentials_redacted(env_name: str) -> None:
    """L-4. Metrics say how many; only the log says which request — and the counted
    overrides above are evidence-based only if the evidence exists."""
    template = edge_template(env_name)

    configs = _resources(template, "AWS::WAFv2::LoggingConfiguration")
    assert len(configs) == 1
    props = next(iter(configs.values()))["Properties"]
    assert props["ResourceArn"] == {"Fn::GetAtt": ["WebAcl", "Arn"]}

    # `authorization` carries the bearer token and `cookie` the session. A 400-day
    # store of live credentials is a worse exposure than whatever it was opened to
    # investigate.
    redacted = {field["SingleHeader"]["Name"] for field in props["RedactedFields"]}
    assert redacted == {"authorization", "cookie"}

    groups = {
        group["Properties"]["LogGroupName"]: group["Properties"]
        for group in _resources(template, "AWS::Logs::LogGroup").values()
    }
    # AWS REQUIRES the `aws-waf-logs-` prefix; PutLoggingConfiguration rejects any
    # other name. That is why this one group does not follow the naming convention.
    waf_group = groups[f"aws-waf-logs-meridian-{env_name}"]
    assert waf_group["RetentionInDays"] == 400
    assert "KmsKeyId" in waf_group


def test_shield_advanced_is_never_enabled() -> None:
    """ADR 0015: Shield Standard is automatic and free; Advanced is $3,000/month."""
    for env_name in ENVIRONMENTS:
        template = edge_template(env_name)
        assert _resources(template, "AWS::Shield::Protection") == {}
        assert _resources(template, "AWS::Shield::Subscription") == {}


# ------------------------------------------------------------- certificate, DNS


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_one_certificate_covering_every_name_the_edge_answers_for(env_name: str) -> None:
    template = edge_template(env_name)
    certificates = _resources(template, "AWS::CertificateManager::Certificate")
    assert len(certificates) == 1
    props = next(iter(certificates.values()))["Properties"]
    assert props["ValidationMethod"] == "DNS"

    # Every viewer name, because the viewer's Host is forwarded and CloudFront checks
    # the ALB's certificate against it — plus `origin-<env>`, the name it dials.
    primary, *alternates = [*VIEWER_ALIASES[env_name], f"origin-{env_name}.{DOMAIN}"]
    assert props["DomainName"] == primary
    assert props["SubjectAlternativeNames"] == alternates


def test_staging_never_requests_a_certificate_for_a_production_name() -> None:
    """M-1, and this is the load-bearing half of it.

    A certificate is an assertion of identity, and staging must not be able to make
    production's. It is also an operational trap: the ACM DNS-validation records
    belong to the stack that requested the certificate, and staging's stack is
    destroyed every session (ADR 0008) — so a shared name would mean a staging
    teardown deleting a record production's renewal depends on.
    """
    template = edge_template("staging")
    props = next(iter(_resources(template, "AWS::CertificateManager::Certificate").values()))[
        "Properties"
    ]
    names = {props["DomainName"], *props.get("SubjectAlternativeNames", [])}
    assert names.isdisjoint(VIEWER_ALIASES["production"])
    assert f"origin-production.{DOMAIN}" not in names


def test_production_never_requests_the_staging_name() -> None:
    """The other direction: production would otherwise sit in PENDING_VALIDATION on a
    record for a name it never answers for."""
    template = edge_template("production")
    props = next(iter(_resources(template, "AWS::CertificateManager::Certificate").values()))[
        "Properties"
    ]
    names = {props["DomainName"], *props.get("SubjectAlternativeNames", [])}
    assert names.isdisjoint(VIEWER_ALIASES["staging"])
    assert f"origin-staging.{DOMAIN}" not in names


def test_the_two_certificates_cover_disjoint_names_so_validation_cannot_collide() -> None:
    """ACM derives each validation CNAME's owner name from the name being validated,
    so disjoint subject lists give disjoint records. ADR 0017 states it; this pins it."""

    def names(env_name: str) -> set[str]:
        props = next(
            iter(
                _resources(edge_template(env_name), "AWS::CertificateManager::Certificate").values()
            )
        )["Properties"]
        return {props["DomainName"], *props.get("SubjectAlternativeNames", [])}

    assert names("staging") & names("production") == set()
    assert names("staging") | names("production") == {
        DOMAIN,
        f"www.{DOMAIN}",
        f"app.{DOMAIN}",
        f"api.{DOMAIN}",
        f"staging-app.{DOMAIN}",
        f"staging-api.{DOMAIN}",
        f"origin-staging.{DOMAIN}",
        f"origin-production.{DOMAIN}",
    }


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_only_the_new_names_are_created_by_default(env_name: str) -> None:
    """**Phase 9 flips the apex and `www`, not Phase 2.** Creating either now would
    move live traffic off Render months early. `app` and `api` (and staging's two)
    are names nothing resolves today, so they are created as soon as the zone is
    known (ADR 0050)."""
    template = edge_template(env_name)
    records = _resources(template, "AWS::Route53::RecordSet")
    names = {record["Properties"]["Name"] for record in records.values()}
    new = [APP_HOST[env_name], API_HOST[env_name]]
    assert names == {f"origin-{env_name}.{DOMAIN}.", *(f"{host}." for host in new)}
    assert not names & {f"{DOMAIN}.", f"www.{DOMAIN}."}
    # A and AAAA for each new name, plus the origin A record.
    assert len(records) == 2 * len(new) + 1


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_flag_creates_the_viewer_aliases(env_name: str) -> None:
    template = edge_template(env_name, createDnsAliases="true")
    records = _resources(template, "AWS::Route53::RecordSet")
    names = {record["Properties"]["Name"] for record in records.values()}
    expected = {f"origin-{env_name}.{DOMAIN}."}
    aliases = VIEWER_ALIASES[env_name]
    expected |= {f"{alias}." for alias in aliases}
    assert names == expected
    # A and AAAA for each alias, plus the origin A record.
    assert len(records) == 2 * len(aliases) + 1


def test_without_a_zone_id_no_records_are_created_at_all() -> None:
    """The stack still synthesizes and deploys; the certificate then waits on
    validation records added by hand."""
    from conftest import synth_with

    assembly = synth_with("staging", createDnsAliases="true")
    template = assertions.Template.from_json(
        assembly.get_stack_by_name("meridian-staging-edge").template
    )
    assert _resources(template, "AWS::Route53::RecordSet") == {}


# --------------------------------------------------------------- origin-verify


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_origin_verify_secret_is_generated_not_written_down(env_name: str) -> None:
    """L-6: the secret is owned by the **data** stack, which survives a staging
    teardown. The edge stack only reads it."""
    data = data_template(env_name)
    secrets = _resources(data, "AWS::SecretsManager::Secret")
    # Phase 3 added three more secrets to that stack (db-app, db-phi, phi-hmac-key), so
    # this one is found by name rather than by being the only one.
    logical_id, secret = next(
        (logical, s)
        for logical, s in secrets.items()
        if s["Properties"]["Name"] == f"meridian-{env_name}-secret-origin-verify"
    )
    props = secret["Properties"]
    generator = props["GenerateSecretString"]
    assert generator["PasswordLength"] == 64
    assert generator["ExcludePunctuation"] is True
    assert "SecretString" not in props  # no literal value, ever

    # RETAIN in BOTH environments, unlike the rest of the edge stack: the data
    # stack is never destroyed, and a deleted secret keeps its NAME reserved for the
    # recovery window, which is what used to break the next session's deploy.
    assert secret["DeletionPolicy"] == "Retain", logical_id


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_edge_stack_owns_no_secret_of_its_own(env_name: str) -> None:
    """L-6. Staging's edge stack is destroyed every session; anything durable in it
    is a thing the teardown has to remember to rescue."""
    assert _resources(edge_template(env_name), "AWS::SecretsManager::Secret") == {}


# ---------------------------------------- origin-verify: versioned references (H-1)


def _header_condition_values(template: assertions.Template) -> list[Any]:
    """The origin-verify values one listener rule accepts. Every rule is identical."""
    rules = _resources(template, "AWS::ElasticLoadBalancingV2::ListenerRule")
    rule = next(iter(rules.values()))
    header = next(c for c in rule["Properties"]["Conditions"] if c["Field"] == "http-header")
    values: list[Any] = header["HttpHeaderConfig"]["Values"]
    return values


def _cloudfront_header_value(template: assertions.Template) -> str:
    origins = _distribution_config(template)["Origins"]
    return json.dumps(origins[0]["OriginCustomHeaders"][0]["HeaderValue"])


#: Three successive versions of the secret, as the runbook names them.
V1 = "1111aaaa-1111-1111-1111-1111aaaa1111"
V2 = "2222bbbb-2222-2222-2222-2222bbbb2222"
V3 = "3333cccc-3333-3333-3333-3333cccc3333"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_alb_accepts_two_versions_and_cloudfront_pins_one(env_name: str) -> None:
    """**H-1, and this is the assertion the whole fix exists for.**

    Before it, both ends rendered the same version-less
    `{{resolve:secretsmanager:<arn>:SecretString:::}}`, which always means
    `AWSCURRENT`. A rotation therefore moved CloudFront and the ALB in the *same*
    deploy, and for the 5-10 minutes CloudFront takes to propagate, every edge still
    sending the old value hit an ALB that no longer accepted it.

    The fix is an asymmetry of *timing*, not of reference kind: the ALB accepts two
    explicit version ids — the new one and the one before it — while CloudFront is
    pinned to one, and the two are moved by separate deploys. This asserts the state
    in between: the ALB accepts both, CloudFront still sends the old one.
    """
    template = edge_template(
        env_name,
        originVerifyActiveVersion=V2,
        originVerifyPreviousVersion=V1,
        originVerifyCloudFrontVersionId=V1,
    )

    values = _header_condition_values(template)
    assert len(values) == 2, "the ALB must accept the current AND the previous value"
    rendered = [json.dumps(value) for value in values]
    assert all("resolve:secretsmanager" in value for value in rendered)
    assert any(V2 in value for value in rendered)
    assert any(V1 in value for value in rendered)
    assert rendered[0] != rendered[1], "two references, not the same one twice"

    cloudfront_value = _cloudfront_header_value(template)
    assert "resolve:secretsmanager" in cloudfront_value
    assert V1 in cloudfront_value
    # The point of the pin: CloudFront must NOT follow a label.
    assert "AWSCURRENT" not in cloudfront_value
    assert "AWSPREVIOUS" not in cloudfront_value

    # And the two ends genuinely differ mid-rotation — which is the window.
    assert cloudfront_value in rendered
    assert any(cloudfront_value != value for value in rendered)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_a_second_rotation_changes_the_listener_rule_values(env_name: str) -> None:
    """**H-F: the finding that makes explicit ids mandatory on the ALB side too.**

    The first repair had the ALB follow the `AWSCURRENT`/`AWSPREVIOUS` labels. That
    survives rotation #1 and breaks on rotation #2, because a `{{resolve:...}}`
    dynamic reference is resolved by the deploy that *writes* it, and CloudFormation
    only re-writes a property whose template text changed. `AWSCURRENT` is the same
    eleven characters at every rotation: no diff, no re-resolve, so the listener rules
    keep the strings from the first deploy while CloudFront's pinned id moves to the
    new value. The ALB then refuses everything the edge sends.

    So the test is not "the values are version ids", it is **"rotation #2's template
    differs from rotation #1's in exactly the listener rules' Values"**. With labels
    this assertion fails; with ids it passes.
    """
    rotation_1 = _header_condition_values(
        edge_template(
            env_name,
            originVerifyActiveVersion=V2,
            originVerifyPreviousVersion=V1,
            originVerifyCloudFrontVersionId=V2,
        )
    )
    rotation_2 = _header_condition_values(
        edge_template(
            env_name,
            originVerifyActiveVersion=V3,
            originVerifyPreviousVersion=V2,
            originVerifyCloudFrontVersionId=V2,
        )
    )

    assert json.dumps(rotation_1) != json.dumps(rotation_2), (
        "the listener rules rendered identical text at two different rotations, so "
        "CloudFormation would never re-resolve them — this is finding H-F"
    )
    assert V3 in json.dumps(rotation_2) and V3 not in json.dumps(rotation_1)
    # V2 is carried into the new accepted set, which is what keeps the window open.
    assert V2 in json.dumps(rotation_2)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_a_label_on_the_alb_side_after_the_first_deploy_warns(env_name: str) -> None:
    """Being pinned is what marks "this is not the first deploy". A label on the ALB
    side from then on is the rotation-#2 trap above, so synth says so out loud."""
    stack = edge_stack(
        env_name,
        originVerifyPreviousVersion="AWSPREVIOUS",
        originVerifyCloudFrontVersionId=V2,
    )
    assertions.Annotations.from_stack(stack).has_warning(
        "*",
        assertions.Match.string_like_regexp(".*staging LABEL.*"),
    )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_explicit_ids_on_both_alb_values_do_not_warn(env_name: str) -> None:
    """The steady state after step 2 of the runbook: no warning at all."""
    stack = edge_stack(
        env_name,
        originVerifyActiveVersion=V2,
        originVerifyPreviousVersion=V1,
        originVerifyCloudFrontVersionId=V1,
    )
    assertions.Annotations.from_stack(stack).has_no_warning(
        "*",
        assertions.Match.string_like_regexp(".*(staging LABEL|originVerifyCloudFront).*"),
    )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_unpinned_output_points_at_the_command_that_reads_the_version_id(
    env_name: str,
) -> None:
    """**L-F.** `AWS::SecretsManager::Secret` exposes no version-id attribute — `Ref`
    is the ARN and the only `Fn::GetAtt` is `Id` — so on a first deploy the stack
    cannot print the id CloudFront actually resolved. Printing `AWSCURRENT` looked
    like an answer and was not, which is how step 0 of the runbook got skipped. The
    output names the one command that can read it instead.
    """
    unpinned = json.dumps(edge_template(env_name).find_outputs("OriginVerifyCloudFrontVersion"))
    assert "UNPINNED" in unpinned
    assert "describe-secret" in unpinned
    assert "VersionIdsToStages" in unpinned

    pinned = json.dumps(
        edge_template(env_name, originVerifyCloudFrontVersionId=V2).find_outputs(
            "OriginVerifyCloudFrontVersion"
        )
    )
    assert V2 in pinned
    assert "describe-secret" not in pinned


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_before_the_first_rotation_the_alb_accepts_one_value(env_name: str) -> None:
    """`originVerifyPreviousVersion` is unset by default on purpose: a brand-new secret
    has no `AWSPREVIOUS`, and a dynamic reference to a label that does not exist fails
    the deploy."""
    template = edge_template(env_name)
    values = _header_condition_values(template)
    assert len(values) == 1
    assert "AWSCURRENT" in json.dumps(values[0])


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_an_explicit_active_version_is_rendered_as_a_version_id_not_a_stage(
    env_name: str,
) -> None:
    """A uuid and a staging label go in *different* positions of the resolve syntax.
    The stack tells them apart so that whoever passes the context value does not have
    to."""
    active = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    template = edge_template(env_name, originVerifyActiveVersion=active)
    rendered = json.dumps(_header_condition_values(template))
    assert f"SecretString:::{active}" in rendered


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_distribution_is_updated_after_the_listener_rules(env_name: str) -> None:
    """Update order, on a rotation deploy. If CloudFront moved first there would be a
    gap in which edges send a value the ALB has not learned yet. `DependsOn` constrains
    updates as well as creates."""
    template = edge_template(env_name)
    distributions = _resources(template, "AWS::CloudFront::Distribution")
    depends_on = next(iter(distributions.values()))["DependsOn"]
    rules = set(_resources(template, "AWS::ElasticLoadBalancingV2::ListenerRule"))
    assert rules <= set(depends_on)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_same_version_cannot_be_both_active_and_previous(env_name: str) -> None:
    """Then the ALB would accept one value twice and there would be no window at all."""
    with pytest.raises(ValueError, match="originVerifyPreviousVersion"):
        edge_template(
            env_name,
            originVerifyActiveVersion="AWSCURRENT",
            originVerifyPreviousVersion="AWSCURRENT",
        )


# ------------------------------------------------------- no shadowing Next.js routes


#: The one Route Handler allowed under `/api`. It is the runtime reverse proxy
#: (`web/src/lib/proxy.ts`), which forwards to Flask rather than answering
#: instead of it — see the test below for why that distinction is the whole
#: rule.
PROXY_HANDLER = "web/src/app/api/[...path]/route.ts"


def test_no_next_js_route_handler_shadows_the_flask_api() -> None:
    """L-7. `/api/*` forwards to the `api` target group at the ALB, so a Next.js Route
    Handler at `web/src/app/api/**/route.ts` cannot *serve* a request on AWS — the edge
    decides before Next.js is asked. A handler with an implementation of its own would
    look like it worked locally (where Next serves it) and 404 on AWS.

    **The runtime proxy is the exception, and it is not an exception to the rule.** It
    holds no implementation: every method is `forward` from `@/lib/proxy`, which sends
    the request to Flask unchanged. On AWS the ALB gets there first and the file never
    runs; on Render and in `npm run dev` it is what makes `/api/*` reach Flask at all,
    now that `rewrites()` no longer bakes the origin into the build (P5A-01). So the
    invariant this test defends — **`/api/*` is answered by Flask, wherever the request
    lands** — is exactly what the file preserves.

    Anything else under `web/src/app/api/` is still a hard failure.
    """
    from meridian.edge_paths import REPO_ROOT

    api_dir = REPO_ROOT / "web" / "src" / "app" / "api"
    found = sorted(str(p.relative_to(REPO_ROOT)) for p in api_dir.rglob("route.ts"))
    offenders = [path for path in found if path != PROXY_HANDLER]
    assert offenders == [], (
        "These Next.js Route Handlers sit under a path the ALB sends to Flask, so "
        f"they can never run on AWS: {offenders}. Give the feature its own prefix "
        "(e.g. /bff/*) and add it to next.config.mjs and infra/meridian/edge_paths.py."
    )
    assert found == [PROXY_HANDLER], (
        f"{PROXY_HANDLER} is the runtime proxy and every /api/* path depends on it "
        "off AWS; it must exist."
    )

    # And it must still be a pass-through. A body added to this file would be the
    # thing the rule above forbids, wearing the name of the thing it allows.
    source = (REPO_ROOT / PROXY_HANDLER).read_text(encoding="utf-8")
    assert 'from "@/lib/proxy"' in source
    for method in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
        assert f"export const {method} = forward;" in source, method


def _proxy_handler_prefixes() -> dict[str, bool]:
    """Every URL prefix `web/src/lib/proxy.ts` answers for → is the bare path served too.

    Read off the filesystem rather than from a list, because the handlers ARE the
    list: `web/src/lib/proxy-routes.test.ts` checks the same set from the other
    side (every family in `next.config.mjs` has a handler). A `[...path]` segment
    needs at least one path segment, an optional `[[...path]]` also answers at the
    bare family path — the same distinction `next_source_to_alb_patterns` makes.
    """
    from meridian.edge_paths import REPO_ROOT

    app_dir = REPO_ROOT / "web" / "src" / "app"
    prefixes: dict[str, bool] = {}
    for handler in sorted(app_dir.rglob("route.ts")):
        if 'from "@/lib/proxy"' not in handler.read_text(encoding="utf-8"):
            continue
        parts = handler.relative_to(app_dir).parts[:-1]
        bare_path_too = parts[-1].startswith("[[")
        prefixes["/" + "/".join(p for p in parts if not p.startswith("["))] = bare_path_too
    return prefixes


def test_the_alb_claims_every_proxy_handler_prefix() -> None:
    """The enforcement behind "the route handlers are dead on ECS" (P5AR5-01).

    `proxy.ts` says it is the DEV and RENDER path: on ECS the ALB forwards these
    prefixes to the `api` target group before the `/*` rule that reaches the
    `web` task, so Next.js is never asked. That claim is only true while every
    handler's prefix is in the api rules — a new `web/src/app/<x>/[...path]`
    proxy handler with no matching ALB pattern would be live on AWS, sending a
    request back out through the edge and re-writing `CloudFront-Viewer-Address`
    on the way (the P5AR4-02 failure, from the other end).

    This is also why the `web` task holds no origin-verify secret: there is no
    web→api hop to prove anything about.
    """
    patterns = set(api_path_patterns())
    handlers = _proxy_handler_prefixes()

    assert handlers, "the runtime proxy handlers are what make /api/* work off AWS"
    for prefix, bare_path_too in sorted(handlers.items()):
        assert f"{prefix}/*" in patterns, (
            f"{prefix}/* is served by a Next.js route handler but no ALB rule claims it, "
            "so that handler would run on ECS. Add the prefix to next.config.mjs "
            "(edge_paths.py reads it) or delete the handler."
        )
        if bare_path_too:
            assert prefix in patterns, prefix


# ------------------------------------------- the NAT gateway and the ADR 0020 split


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_exactly_one_nat_gateway_and_it_is_in_this_stack(env_name: str) -> None:
    """**ADR 0020.** The NAT is $37.50/month whether or not anything uses it, so it
    lives in the stack staging destroys — and there is exactly one of it, not one per
    AZ (ADR 0018 §1: the second buys AZ-redundant *egress* while the database itself is
    single-AZ, which is paying for the cheaper half of a failure)."""
    template = edge_template(env_name)
    assert len(_resources(template, "AWS::EC2::NatGateway")) == 1
    assert len(_resources(template, "AWS::EC2::EIP")) == 1


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_nat_routes_attach_to_the_persistent_route_tables(env_name: str) -> None:
    """Two routes — one per `private-app` subnet — each pointing at the NAT and each
    written onto a route table that lives in `meridian-<env>-vpc`.

    The `Fn::ImportValue` is the assertion: the route table is not this stack's, which
    is what lets the subnets outlive the gateway routed through them. And **no route is
    added for `private-data`**: two routes, not four. The database's isolation is a
    property of the code, not of what happens to be deployed."""
    template = edge_template(env_name)
    routes = _resources(template, "AWS::EC2::Route")
    assert len(routes) == 2
    for route in routes.values():
        props = route["Properties"]
        assert props["DestinationCidrBlock"] == "0.0.0.0/0"
        assert "NatGatewayId" in props
        assert "Fn::ImportValue" in str(props["RouteTableId"]), props


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_edge_owns_no_vpc_subnet_or_security_group(env_name: str) -> None:
    """Everything durable and free is in `meridian-<env>-vpc`. If one of these appeared
    here it would be destroyed with the session — and, for a security group, silently
    recreated with a new id that nothing else references."""
    template = edge_template(env_name)
    for type_name in ("AWS::EC2::VPC", "AWS::EC2::Subnet", "AWS::EC2::SecurityGroup"):
        assert _resources(template, type_name) == {}, type_name


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_edge_holds_no_database_bucket_of_record_or_key(env_name: str) -> None:
    """The mirror of the above, for `data`. A destroy of this stack must not be able to
    reach an RDS instance, a CMK or a secret — so none may be declared here."""
    template = edge_template(env_name)
    for type_name in (
        "AWS::RDS::DBInstance",
        "AWS::KMS::Key",
        "AWS::SecretsManager::Secret",
        "AWS::Backup::BackupVault",
    ):
        assert _resources(template, type_name) == {}, type_name


# ------------------------------------------------------------------- flow logs


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_flow_logs_are_kms_encrypted_and_kept_400_days(env_name: str) -> None:
    template = edge_template(env_name)
    groups = {
        group["Properties"]["LogGroupName"]: group["Properties"]
        for group in _resources(template, "AWS::Logs::LogGroup").values()
    }
    # Two explicit groups: VPC flow logs and WAF logs (L-4). The RDS log groups are in
    # the data stack, because they have to exist while this stack does not.
    assert set(groups) == {
        f"meridian-{env_name}-logs-vpc-flow",
        f"aws-waf-logs-meridian-{env_name}",
    }
    props = groups[f"meridian-{env_name}-logs-vpc-flow"]
    assert props["RetentionInDays"] == 400
    # The key is the data stack's `logs` CMK, arriving as a cross-stack import.
    assert "KmsKeyId" in props

    template.has_resource_properties(
        "AWS::EC2::FlowLog",
        {"TrafficType": "ALL", "ResourceType": "VPC", "LogDestinationType": "cloud-watch-logs"},
    )


def test_staging_flow_log_group_is_destroyed_and_production_is_retained() -> None:
    """D-15: staging's edge stack is rebuilt every session, so a retained log group
    would block its own recreation. Production's is kept."""
    staging = edge_template("staging").find_resources("AWS::Logs::LogGroup")
    production = edge_template("production").find_resources("AWS::Logs::LogGroup")
    assert {g["DeletionPolicy"] for g in staging.values()} == {"Delete"}
    assert {g["DeletionPolicy"] for g in production.values()} == {"Retain"}


def test_the_logs_key_policy_lives_with_the_key_not_here() -> None:
    """The statement CloudWatch Logs needs on the `logs` CMK moved to the data stack in
    Phase 3, because the RDS log groups need it while this stack is destroyed. If it
    were added from both places the key would carry two statements with the same Sid,
    which is not a valid policy."""
    from conftest import stack_template

    data = str(stack_template("staging", "data").to_json())
    assert "AllowCloudWatchLogsToUseThisKey" in data
    assert "AllowCloudWatchLogsToUseThisKey" not in str(edge_template("staging").to_json())


# ------------------------------------------------------------------ ops instance


def test_staging_gets_an_ops_instance_and_production_does_not_by_default() -> None:
    """`createOpsInstance` defaults to true for staging only. Production opts in
    when there is a production database to reach — ECS Exec is the alternative."""
    assert _resources(edge_template("staging"), "AWS::EC2::Instance")
    assert _resources(edge_template("production"), "AWS::EC2::Instance") == {}


def test_production_can_opt_in_and_staging_can_opt_out() -> None:
    assert _resources(edge_template("production", createOpsInstance="true"), "AWS::EC2::Instance")
    assert (
        _resources(edge_template("staging", createOpsInstance="false"), "AWS::EC2::Instance") == {}
    )


def test_the_ops_instance_has_no_key_pair_and_requires_imdsv2() -> None:
    template = edge_template("staging")
    instances = _resources(template, "AWS::EC2::Instance")
    assert len(instances) == 1
    props = next(iter(instances.values()))["Properties"]
    assert props["InstanceType"] == "t4g.nano"
    # No SSH path exists, so a key pair would only be a credential to lose.
    assert "KeyName" not in props or props["KeyName"] is None

    volume = props["BlockDeviceMappings"][0]["Ebs"]
    assert volume["Encrypted"] is True
    assert "KmsKeyId" in volume  # the environment's own CMK, from the data stack

    # `require_imdsv2` is rendered as a launch template the instance references.
    template.has_resource_properties(
        "AWS::EC2::LaunchTemplate",
        {"LaunchTemplateData": {"MetadataOptions": {"HttpTokens": "required"}}},
    )


def test_ops_launch_template_names_do_not_collide_across_environments() -> None:
    """Launch template names are unique per account+region. Staging keeps its deployed
    name (renaming would replace its instance); production must not reuse it."""

    def names(env: str) -> set[str]:
        return {
            r["Properties"]["LaunchTemplateName"]
            for r in _resources(
                edge_template(env, createOpsInstance="true"), "AWS::EC2::LaunchTemplate"
            ).values()
        }

    assert names("staging") == {"OpsInstanceLaunchTemplate"}
    assert names("production") == {"OpsInstanceProductionLaunchTemplate"}


def test_the_ops_instance_waits_for_its_default_route() -> None:
    """Session Manager is an outbound connection over the NAT. An instance created
    before its route exists misses the SSM registration window, and there is no SSH to
    fall back on."""
    template = edge_template("staging")
    instance = next(iter(_resources(template, "AWS::EC2::Instance").values()))
    depends = set(instance["DependsOn"])
    routes = set(_resources(template, "AWS::EC2::Route"))
    assert routes <= depends, (routes, depends)


def test_the_ops_instance_can_only_do_ssm() -> None:
    template = edge_template("staging")
    roles = [
        role
        for role in _resources(template, "AWS::IAM::Role").values()
        if role["Properties"].get("RoleName") == "meridian-staging-iam-ops-instance"
    ]
    assert len(roles) == 1
    policies = str(roles[0]["Properties"]["ManagedPolicyArns"])
    assert "AmazonSSMManagedInstanceCore" in policies


# ------------------------------------------------------------------ whole-stack


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_synthesizes_without_credentials_or_errors(env_name: str) -> None:
    """The same property CI relies on: no lookups, no account id, no AWS calls."""
    from conftest import synth_with

    assembly = synth_with(env_name)
    artifact = assembly.get_stack_by_name(f"meridian-{env_name}-edge")
    errors = [m for m in artifact.messages if m.entry.type == "aws:cdk:error"]
    assert errors == []
    assert artifact.template["Resources"]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_resource_in_the_edge_carries_the_six_tags(env_name: str) -> None:
    template = edge_template(env_name)
    required = ("Project", "Environment", "Owner", "DataClassification", "CostCenter", "ManagedBy")
    checked = 0
    for name, resource in template.to_json()["Resources"].items():
        tags = resource.get("Properties", {}).get("Tags")
        if not isinstance(tags, list) or not tags or not isinstance(tags[0], dict):
            continue
        assert {tag.get("Key") for tag in tags}.issuperset(required), name
        checked += 1
    assert checked > 10


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_alb_admits_nothing_but_cloudfronts_prefix_list(env_name: str) -> None:
    """No ingress rule of this stack's own, and that is the P5AR5-01 deletion.

    There was one: a `/32` for this VPC's NAT elastic IP, so the `web` task's
    proxy hop could dial `origin-<env>` directly. The hop never existed — the
    listener rules send `/api/*`, `/auth/*` and `/static/*` to the `api` target
    group before the `/*` rule that reaches the `web` task — so the rule, the
    task's origin-verify secret and the runbook step that rotated it all went
    together. The ALB security group is back to CloudFront's managed prefix
    list alone (declared in `vpc`), which is control #1 of ADR 0018 §3.
    """
    template = edge_template(env_name)
    assert _resources(template, "AWS::EC2::SecurityGroupIngress") == {}
