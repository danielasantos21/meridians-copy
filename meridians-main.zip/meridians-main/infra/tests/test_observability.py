"""`meridian-<env>-observability`: alarms, filters, the pipe, the dashboard, the canary.

These assert the properties that make monitoring *trustworthy* rather than merely present.
An alarm that emails on recovery floods the inbox every time staging's database starts
(ADR 0024 §2a, reversed 2026-10-07). An alarm with CDK's default
`treat_missing_data` silently reports health when the metric stops arriving. A metric
filter matching a free-text substring is a PHI hazard with a 400-day retention. A dashboard
with a log widget renders log bodies into the most-screenshotted surface in the estate.
None of those fails a deploy, and all of them fail here.

The last section is not about this stack at all: it walks **every log group in every
synthesized stack** and asserts retention and encryption, because "every log group has a
CMK and a retention" is the kind of estate-wide claim that is true until one construct is
added without it.
"""

from __future__ import annotations

import json
import pathlib
import re
from collections.abc import Mapping
from typing import Any

import pytest
from aws_cdk import assertions
from conftest import stack_template, synth_with

from meridian.config import ENV_CONFIG
from meridian.stacks.compute import API_DESIRED_COUNT
from meridian.stacks.data import STOP_DLQ_ERROR_ATTRIBUTE, STOP_DLQ_EXPECTED_ERROR
from meridian.stacks.observability import (
    CANARY_ARTIFACT_RETENTION,
    CANARY_CONTEXT_FLAG,
    CANARY_RATE,
    CANARY_RUNTIME,
    CONNECTION_HEADROOM,
    HEALTH_PATH,
    LATENCY_P95_SECONDS,
    MAX_CONNECTIONS,
    SES_BOUNCE_RATE_THRESHOLD,
    SES_COMPLAINT_RATE_THRESHOLD,
    STOP_EVENT_SOURCE,
    STRUCTURED_LOGS_CONTEXT_FLAG,
    STRUCTURED_LOGS_HEARTBEAT_PERIOD,
    ObservabilityStack,
)

ENVIRONMENTS = ("staging", "production")

#: `AWS::Logs::LogGroup`s allowed to be missing a CMK or a 400-day retention. **It is
#: empty, and the point is that it is empty.** If a log group has to be added here it
#: needs a written reason and a `docs/migration-tracker.md` row, not just an entry.
#:
#: Note what this list does *not* and cannot cover: the log groups CDK's own helper
#: Lambdas create *implicitly* on first invocation (`Custom::VpcRestrictDefaultSG`,
#: `Custom::S3AutoDeleteObjects`). Those are never in a template, so no template assertion
#: can reach them. CloudWatch has no account-level retention or encryption policy, so
#: they are handled at run time by the log-group governor Lambda (T:60/T:65), whose scope
#: the tests further down assert.
LOG_GROUP_EXCEPTIONS: frozenset[str] = frozenset()

#: The estate's retention floor, in days (`RetentionDays.THIRTEEN_MONTHS`).
MINIMUM_RETENTION_DAYS = 400

#: The two IAM statements in this stack allowed to say `Resource: "*"`. Both name actions
#: that have **no resource-level permission in IAM at all**, so a narrower statement is not
#: possible — only a wrong one. See `_canary` in the stack.
DOCUMENTED_WILDCARD_SIDS = {
    "ActionsWithNoResourceLevelPermission",
    "PublishCanaryMetricsOnly",
    # The backup-freshness checker (T:160): `PutMetricData` again, confined to
    # `Meridian/Backup` by the same namespace condition.
    "PublishBackupMetricsOnly",
}


def observability(env: str, **context: object) -> assertions.Template:
    return stack_template(env, "observability", **context)


def _resources(template: assertions.Template, type_name: str) -> Mapping[str, Any]:
    return template.find_resources(type_name)


def _alarms(template: assertions.Template) -> dict[str, dict[str, Any]]:
    return dict(_resources(template, "AWS::CloudWatch::Alarm"))


def _session_script() -> str:
    """`scripts/staging_session.sh`, as text. Read by the stop-schedule assertions."""
    return (
        pathlib.Path(__file__).resolve().parents[2] / "scripts" / "staging_session.sh"
    ).read_text()


def _alarm_named(template: assertions.Template, name: str) -> dict[str, Any]:
    for alarm in _alarms(template).values():
        if alarm["Properties"]["AlarmName"] == name:
            return alarm["Properties"]
    raise AssertionError(f"no alarm named {name}")


@pytest.fixture(scope="module")
def staging_obs() -> assertions.Template:
    return observability("staging")


@pytest.fixture(scope="module")
def production_obs() -> assertions.Template:
    return observability("production")


# --------------------------------------------------------------- every alarm, always


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_alarm_notifies_the_alerts_topic_on_alarm_only(env_name: str) -> None:
    """**`AlarmActions` on every alarm, `OKActions` on none** (ADR 0024 §2a, reversed
    2026-10-07): staging's database starts on demand, and each start moved every RDS alarm
    to OK and emailed once per alarm. The topic is `meridian-<env>-sns-alerts`, imported
    from the `data` stack, so the subscription a human confirmed by email survives a
    staging teardown.
    """
    template = observability(env_name)
    alarms = _alarms(template)
    assert alarms, "the observability stack has no alarms at all"

    for logical_id, alarm in alarms.items():
        properties = alarm["Properties"]
        alarm_actions = properties.get("AlarmActions")
        assert alarm_actions, f"{logical_id} has no AlarmActions"
        assert not properties.get("OKActions"), f"{logical_id} emails on recovery"
        assert len(alarm_actions) == 1
        assert "Fn::ImportValue" in json.dumps(alarm_actions[0]), (
            f"{logical_id} does not use the imported data-stack topic"
        )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_alarm_chooses_its_missing_data_behaviour(env_name: str) -> None:
    """`TreatMissingData` is set explicitly on every alarm, never left to the default.

    CDK's default is `missing`, which is sometimes right and is never *argued*. The three
    values in use here and the rule behind each are in the stack's module docstring; this
    test only enforces that a choice was made, and that it is one of the three the estate
    reasons about (`ignore` is excluded: it means "never change state", which is an alarm
    that cannot fire).
    """
    for logical_id, alarm in _alarms(observability(env_name)).items():
        value = alarm["Properties"].get("TreatMissingData")
        assert value in {"notBreaching", "breaching", "missing"}, (
            f"{logical_id} has TreatMissingData={value!r}"
        )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_alarm_names_and_descriptions_follow_the_conventions(env_name: str) -> None:
    """`meridian-<env>-alarm-<purpose>`, and every alarm says what to do about it.

    The name is what arrives in the email and is often the only identifier the reader
    gets, so it cannot be a CDK-generated logical id. The description is the first line of
    the runbook.
    """
    other = "production" if env_name == "staging" else "staging"
    for logical_id, alarm in _alarms(observability(env_name)).items():
        properties = alarm["Properties"]
        name = properties["AlarmName"]
        assert re.fullmatch(rf"meridian-{env_name}-alarm-[a-z0-9]+(-[a-z0-9]+)*", name), name
        assert other not in name
        description = properties.get("AlarmDescription", "")
        assert len(description) > 40, f"{logical_id} has no useful description"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_a_rolling_deploy_does_not_page(env_name: str) -> None:
    """Every alarm's window is longer than an ECS rolling deployment.

    A deploy replaces a task, which briefly halves capacity and can produce a 502. An
    alarm that fires on that is an alarm that is muted within a month. The rule applied
    is `evaluation_periods x period >= 5 minutes` for everything except the two alarms
    where waiting is itself the fault: free storage (it does not recover on its own) and
    a User Migration error (each one is a person who was refused sign-in).
    """
    immediate = {
        f"meridian-{env_name}-alarm-rds-free-storage",
        f"meridian-{env_name}-alarm-user-migration-errors",
        f"meridian-{env_name}-alarm-pool-timeout",
        f"meridian-{env_name}-alarm-phi-audit-write-failed",
    }
    for alarm in _alarms(observability(env_name)).values():
        properties = alarm["Properties"]
        if properties["AlarmName"] in immediate:
            continue
        window = properties["EvaluationPeriods"] * properties["Period"]
        assert window >= 300, f"{properties['AlarmName']} alarms inside 5 minutes"

    # **`api-no-healthy-host` is the one alarm where 5 minutes is not enough**, and it is
    # the one that used to page on every single api deploy. `compute.py` pins the api
    # service to `min_healthy_percent=0` / `max_healthy_percent=100` because two api tasks
    # mis-book journal entries (ADR 0022), which means ECS stops the old task before it
    # starts the new one: **3-6 minutes of zero healthy hosts, by design, every deploy**.
    # The window has to be past the top of that, and `datapoints_to_alarm` has to be
    # inside it too — 3 of 5 would fire in three minutes however long the window is.
    api_down = _alarm_named(
        observability(env_name), f"meridian-{env_name}-alarm-api-no-healthy-host"
    )
    assert api_down["DatapointsToAlarm"] * api_down["Period"] > 360, (
        "api-no-healthy-host can fire inside the 3-6 minute outage an api deploy causes "
        "by design; it will be muted within a month"
    )
    assert api_down["EvaluationPeriods"] >= api_down["DatapointsToAlarm"]
    # `web` runs at `min_healthy_percent=100` and never drops to zero during a rollout,
    # so it keeps the fast window. The asymmetry is the point.
    web_down = _alarm_named(
        observability(env_name), f"meridian-{env_name}-alarm-web-no-healthy-host"
    )
    assert web_down["DatapointsToAlarm"] * web_down["Period"] < 360


# ------------------------------------------------------------------- the thresholds


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_api_target_group_has_both_healthy_host_alarms(env_name: str) -> None:
    """`< 1` is the outage alarm. `> 1` is the correctness alarm, and it is the
    interesting one.

    `API_DESIRED_COUNT` is 1 **by design** until Phase 11 (ADR 0022): two api tasks can
    each pick up the same revenue run and book the same journal entry twice. So "somebody
    scaled the api service" is a data-integrity event, and the plan's oddly-worded
    `HealthyHostCount > 1` line is what catches it before it mis-books.
    """
    template = observability(env_name)

    down = _alarm_named(template, f"meridian-{env_name}-alarm-api-no-healthy-host")
    assert down["ComparisonOperator"] == "LessThanThreshold"
    assert down["Threshold"] == 1
    # Silence is the outage: HealthyHostCount publishes continuously.
    assert down["TreatMissingData"] == "breaching"

    up = _alarm_named(template, f"meridian-{env_name}-alarm-api-scaled-beyond-one")
    assert up["ComparisonOperator"] == "GreaterThanThreshold"
    assert up["Threshold"] == API_DESIRED_COUNT == 1
    # Half an hour of two tasks: longer than any rolling deploy holds two.
    assert up["EvaluationPeriods"] * up["Period"] >= 1800


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_rds_connection_alarm_is_a_fraction_of_the_real_ceiling(env_name: str) -> None:
    """The threshold is derived from the instance class, not chosen.

    PostgreSQL on RDS defaults `max_connections` to
    `LEAST({DBInstanceClassMemory/9531392}, 5000)`, which is 112 on `t4g.micro` and 225 on
    `t4g.small`. A threshold that is not a fraction of that number is an alarm that is
    either permanently quiet or permanently loud, and both read as "monitored".
    """
    instance_class = ENV_CONFIG[env_name].db_instance_type
    expected = int(MAX_CONNECTIONS[instance_class] * CONNECTION_HEADROOM)
    alarm = _alarm_named(observability(env_name), f"meridian-{env_name}-alarm-rds-connections")
    assert alarm["Threshold"] == expected
    # Staging's instance is stopped every night by the D-15 schedule and publishes
    # nothing, so `missing` carries the last state forward there. Production's is never
    # stopped, so silence is the outage and it is `breaching`.
    assert alarm["TreatMissingData"] == (
        "missing" if ENV_CONFIG[env_name].destroyed_between_phases else "breaching"
    )


def test_an_unknown_instance_class_refuses_to_guess_a_connection_ceiling() -> None:
    """A third instance class must add a row to `MAX_CONNECTIONS`, not fall back."""
    assert set(MAX_CONNECTIONS) == {config.db_instance_type for config in ENV_CONFIG.values()}, (
        "MAX_CONNECTIONS and the configured instance classes have drifted apart"
    )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_rds_alarm_treats_a_stopped_instance_as_unknown(env_name: str) -> None:
    """Six RDS alarms, `missing` in staging and `breaching` in production.

    Staging's database is stopped nightly (D-15). `breaching` there would page at 11pm
    every night for a cost control working as designed, so it is `missing`, which carries
    the last state forward.

    **Production is the opposite and the distinction matters.** The production instance is
    never stopped — there is no stop schedule and no DLQ in production — so RDS going
    silent is not a cost control, it is the database being unreachable. `missing` would
    hold the last *healthy* state forward for ever and report green through a total
    failure, which is the exact fault ADR 0024 §2b's second row names.
    """
    template = observability(env_name)
    rds_alarms = [
        alarm["Properties"]
        for alarm in _alarms(template).values()
        if "-alarm-rds-" in alarm["Properties"]["AlarmName"]
    ]
    assert len(rds_alarms) == 6
    expected = "missing" if ENV_CONFIG[env_name].destroyed_between_phases else "breaching"
    for properties in rds_alarms:
        assert properties["TreatMissingData"] == expected, properties["AlarmName"]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_latency_alarm_is_p95_at_the_documented_threshold(env_name: str) -> None:
    alarm = _alarm_named(observability(env_name), f"meridian-{env_name}-alarm-alb-latency-p95")
    assert alarm["Threshold"] == LATENCY_P95_SECONDS
    assert alarm["ExtendedStatistic"] == "p95"
    # A quiet hour publishes no p95 and is not a latency problem.
    assert alarm["TreatMissingData"] == "notBreaching"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_waf_and_cloudfront_alarms_use_the_global_region_dimension(env_name: str) -> None:
    """A `CLOUDFRONT`-scoped web ACL publishes with `Region: Global`, not `us-east-1`.

    Using the stack's region here produces a syntactically perfect alarm on a metric that
    is never written — permanently `INSUFFICIENT_DATA`, and read as "quiet".
    """
    template = observability(env_name)
    for name in (
        f"meridian-{env_name}-alarm-waf-blocked-spike",
        f"meridian-{env_name}-alarm-cloudfront-5xx",
    ):
        alarm = _alarm_named(template, name)
        dimensions = {d["Name"]: d["Value"] for d in alarm["Dimensions"]}
        assert dimensions["Region"] == "Global", name


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_user_migration_lambda_is_watched_by_name_not_by_import(env_name: str) -> None:
    """The dimension reproduces `meridian-<env>-lambda-user-migration` from the naming
    convention rather than importing it from the `auth` stack.

    An export from `auth` would make `auth` undeletable while this stack exists — and this
    is the stack a staging teardown destroys (ADR 0008 / D-15). The p99 alarm sits below
    Cognito's hard 5-second trigger budget, because past 5s Cognito abandons the sign-in
    and nothing in the Lambda's own metrics calls that an error.
    """
    template = observability(env_name)
    for suffix in ("errors", "duration"):
        alarm = _alarm_named(template, f"meridian-{env_name}-alarm-user-migration-{suffix}")
        dimensions = {d["Name"]: d["Value"] for d in alarm["Dimensions"]}
        assert dimensions == {"FunctionName": f"meridian-{env_name}-lambda-user-migration"}

    duration = _alarm_named(template, f"meridian-{env_name}-alarm-user-migration-duration")
    assert duration["ExtendedStatistic"] == "p99"
    assert duration["Threshold"] < 5000, "the alarm must fire before Cognito gives up at 5s"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_nightly_cognito_export_errors_page_the_alerts_topic(env_name: str) -> None:
    """T:163: one errored nightly run is the signal, watched by name (no `auth` import)."""
    alarm = _alarm_named(
        observability(env_name), f"meridian-{env_name}-alarm-cognito-export-errors"
    )
    dimensions = {d["Name"]: d["Value"] for d in alarm["Dimensions"]}
    assert dimensions == {"FunctionName": f"meridian-{env_name}-lambda-cognito-export"}
    assert alarm["MetricName"] == "Errors" and alarm["Statistic"] == "Sum"
    assert alarm["Threshold"] == 1 and alarm["EvaluationPeriods"] == 1
    assert alarm["TreatMissingData"] == "notBreaching"
    assert len(alarm["AlarmActions"]) == 1


# ------------------------------------------------------------ backups and findings


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_backup_failures_arrive_by_eventbridge_and_success_does_not(env_name: str) -> None:
    """Failure, abort and expiry are forwarded; `COMPLETED` deliberately is not.

    A success notification per resource per day is how a mailbox filter gets written, and
    a filtered mailbox is how the failure is missed. EventBridge rather than the
    `NumberOfBackupJobsFailed` metric because that metric is account-wide with no vault
    dimension, and the account is shared (ADR 0001).
    """
    rules = _resources(observability(env_name), "AWS::Events::Rule")
    backup_rules = {
        rule["Properties"]["Name"]: rule["Properties"]
        for rule in rules.values()
        if "backup" in rule["Properties"]["Name"]
    }
    assert set(backup_rules) == {
        f"meridian-{env_name}-rule-backup-job-failed",
        f"meridian-{env_name}-rule-backup-copy-failed",
    }
    for name, properties in backup_rules.items():
        pattern = properties["EventPattern"]
        assert pattern["source"] == ["aws.backup"]
        assert "COMPLETED" not in json.dumps(pattern), f"{name} would page on success"
        assert "FAILED" in json.dumps(pattern)
        assert len(properties["Targets"]) == 1


def test_account_scoped_findings_are_wired_once_in_production_only(
    staging_obs: assertions.Template, production_obs: assertions.Template
) -> None:
    """GuardDuty, Security Hub and Config are enabled once for the whole account.

    Their findings are therefore not "a staging finding". A rule in each environment sends
    two emails for one finding; a rule that lives only in staging disappears with the next
    teardown (ADR 0008 / D-15). One rule, in the environment that is never destroyed.
    """
    finding_rules = {
        "rule-guardduty-finding",
        "rule-securityhub-finding",
        "rule-config-non-compliant",
    }

    production_names = {
        rule["Properties"]["Name"]
        for rule in _resources(production_obs, "AWS::Events::Rule").values()
    }
    for suffix in finding_rules:
        assert f"meridian-production-{suffix}" in production_names

    staging_names = {
        rule["Properties"]["Name"] for rule in _resources(staging_obs, "AWS::Events::Rule").values()
    }
    for suffix in finding_rules:
        assert f"meridian-staging-{suffix}" not in staging_names


def test_finding_rules_filter_to_high_and_critical(production_obs: assertions.Template) -> None:
    """Below High this becomes a daily digest, and a digest is not read.

    GuardDuty expresses severity as a number (7.0-8.9 High, 9.0+ Critical); Security Hub
    uses a normalized label. Both are filtered in the rule rather than in a mailbox.
    """
    rules = {
        rule["Properties"]["Name"]: rule["Properties"]["EventPattern"]
        for rule in _resources(production_obs, "AWS::Events::Rule").values()
        # The housekeeping Lambdas' schedule rules have no pattern.
        if "EventPattern" in rule["Properties"]
    }
    guardduty = rules["meridian-production-rule-guardduty-finding"]
    assert guardduty["detail"]["severity"] == [{"numeric": [">=", 7]}]

    security_hub = rules["meridian-production-rule-securityhub-finding"]
    severity = security_hub["detail"]["findings"]["Severity"]["Label"]
    assert sorted(severity) == ["CRITICAL", "HIGH"]

    config_rule = rules["meridian-production-rule-config-non-compliant"]
    assert config_rule["detail"]["newEvaluationResult"]["complianceType"] == ["NON_COMPLIANT"]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_secret_rotation_failures_are_scoped_to_this_environments_secrets(env_name: str) -> None:
    """The account is shared, so the other owner's secrets must not page us.

    Scoped by the `meridian-<env>/` name prefix rather than by ARN, because the rule is
    written before the secrets' ARNs are knowable and a prefix is what the naming
    convention actually guarantees.
    """
    rules = {
        rule["Properties"]["Name"]: rule["Properties"]["EventPattern"]
        for rule in _resources(observability(env_name), "AWS::Events::Rule").values()
        if "EventPattern" in rule["Properties"]
    }
    pattern = rules[f"meridian-{env_name}-rule-secret-rotation-failed"]
    assert pattern["source"] == ["aws.secretsmanager"]
    assert pattern["detail"]["requestParameters"]["secretId"] == [
        {"prefix": f"meridian-{env_name}/"}
    ]
    assert "RotationFailed" in pattern["detail"]["eventName"]


# --------------------------------------------------------------- log metric filters


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_metric_filter_matches_a_field_and_never_free_text(env_name: str) -> None:
    """**The PHI rule of this stack, as a test.**

    A filter pattern is stored in the filter's own definition and is readable by anyone
    with `logs:DescribeMetricFilters`, for as long as the filter exists. A substring
    pattern (`{ $.message = "*failed*" }`, or worse a bare space-delimited term) will
    happily match — and thereby advertise — a log line that quoted a spreadsheet cell. So
    every pattern here is a JSON *field* comparison, and none of them may compare against
    `$.message`, `$.msg` or `$.detail`, which are the fields free text lives in.
    """
    filters = _resources(observability(env_name), "AWS::Logs::MetricFilter")
    assert filters, "no metric filters at all"

    for logical_id, metric_filter in filters.items():
        pattern = metric_filter["Properties"]["FilterPattern"]
        assert isinstance(pattern, str), logical_id
        assert pattern.startswith("{") and pattern.endswith("}"), (
            f"{logical_id} is not a JSON filter pattern: {pattern}"
        )
        # Every term names a field.
        assert "$." in pattern, logical_id
        for free_text_field in ("$.message", "$.msg", "$.detail", "$.text", "$.body"):
            assert free_text_field not in pattern, (
                f"{logical_id} matches on {free_text_field}, which can carry PHI"
            )
        transformation = metric_filter["Properties"]["MetricTransformations"][0]
        # **Every filter carries the `Environment` dimension, from the record's `$.env`.**
        # One namespace, one account, two environments: without it staging's counts and
        # production's are the same metric, so a staging load test raises the production
        # alarm and a production incident is averaged away by staging's zeroes.
        assert transformation["Dimensions"] == [{"Key": "Environment", "Value": "$.env"}], (
            f"{logical_id} publishes to Meridian/App with no Environment dimension"
        )
        assert transformation["MetricNamespace"] == "Meridian/App"
        # And therefore NO `DefaultValue`: CloudWatch Logs refuses the pair, because a
        # default would have to invent a dimension value for a record that did not match.
        # The consequence is deliberate and documented — these metrics are *absent* rather
        # than zero until the formatter lands, and the alarms on them are `notBreaching`.
        assert "DefaultValue" not in transformation, (
            f"{logical_id} sets DefaultValue alongside Dimensions; CloudWatch rejects that"
        )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_filters_cover_the_named_failure_modes(env_name: str) -> None:
    """The specific patterns Phase 6 owes, by metric name.

    `PoolTimeout`, `PgWriteRefused` and `CompensatingDeleteIncomplete` are **exception
    classes** in `src/pg.py` and `src/database.py`, not envelope codes — on the wire they
    all surface as `INTERNAL_ERROR` — so they are matched on `$.exception.type`, which is
    a field the log-format contract (ADR 0024 §4) owes and the app does not emit yet.
    """
    filters = _resources(observability(env_name), "AWS::Logs::MetricFilter")
    by_metric = {
        metric_filter["Properties"]["MetricTransformations"][0]["MetricName"]: metric_filter[
            "Properties"
        ]["FilterPattern"]
        for metric_filter in filters.values()
    }

    assert {
        "FiveXxResponses",
        "PoolTimeout",
        "PgWriteRefused",
        "CompensatingDeleteIncomplete",
        "UnhandledExceptions",
        "AuthFailures",
        "PhiAuditWriteFailures",
        # CC6.7's unusual-export-volume control, which the control matrix used to claim
        # existed before it did.
        "ArtifactDownloads",
    } <= set(by_metric)

    # A field match on the download envelope, never the object key: a key is a filename
    # and a filename in this estate can carry a person's name.
    assert by_metric["ArtifactDownloads"] == '{ $.event = "artifact_download" }'

    assert by_metric["FiveXxResponses"] == "{ $.http.status >= 500 }"
    # The heartbeat's metric: one per `http_request` line, which `api/request_log.py`
    # writes for every request (tests/test_log_setup.py pins the app side).
    assert by_metric["HttpRequests"] == '{ $.event = "http_request" }'
    assert by_metric["PoolTimeout"] == '{ $.exception.type = "PoolTimeout" }'
    # The auth filter enumerates the exact codes from `src/api/v2/errors.py`, so that a
    # code added to the catalogue and not here shows up as a flat line rather than as
    # silently-correct-looking data.
    for code in (
        "AUTH_REQUIRED",
        "SESSION_EXPIRED",
        "INVALID_CREDENTIALS",
        "MFA_CHALLENGE_INVALID",
        "PERMISSION_DENIED",
        "CSRF_INVALID",
        "ORG_REQUIRED",
    ):
        assert f'$.error.code = "{code}"' in by_metric["AuthFailures"]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_five_xx_filter_covers_both_application_log_groups(env_name: str) -> None:
    """api and web. The web container answers its own 5xx and they are invisible in the
    api group."""
    filters = _resources(observability(env_name), "AWS::Logs::MetricFilter")
    groups = {
        json.dumps(metric_filter["Properties"]["LogGroupName"])
        for metric_filter in filters.values()
        if metric_filter["Properties"]["MetricTransformations"][0]["MetricName"]
        == "FiveXxResponses"
    }
    assert len(groups) == 2

    # **The logical ids are stable names, not slices of a cross-stack token.** The two
    # application log groups belong to `meridian-<env>-compute`, so `log_group_name` here
    # is an unresolved `${Token[TOKEN.nnn]}` whose number moves when any unrelated
    # resource is added. Building a construct id out of it produced ids that changed
    # between synths — and a changed construct id is a REPLACED metric filter. The stack
    # uses the `API`/`WEB` purpose constants instead.
    ids = sorted(filters)
    for prefix in ("FiveXxEnvelopeFilterApi", "FiveXxEnvelopeFilterWeb", "PoolTimeoutFilter"):
        assert any(logical_id.startswith(prefix) for logical_id in ids), (prefix, ids)
    for logical_id in ids:
        assert "Token" not in logical_id, logical_id


#: What the web container's logger (`web/src/lib/server-log.ts`) writes for a
#: fixed clock and request id — pinned as that module's exact output by
#: `web/src/lib/server-log.test.ts`. Read here so that the filter is evaluated
#: against a line the logger really produces, not one restated by hand.
WEB_LOG_CONTRACT = (
    pathlib.Path(__file__).resolve().parents[2] / "web" / "src" / "lib" / "server-log.contract.json"
)

_TERM = re.compile(r'^\$\.([A-Za-z_][\w.]*)\s*(>=|<=|!=|=|>|<)\s*(".*"|[-\w.*]+)$')


def _field(record: Mapping[str, Any], dotted: str) -> Any:
    value: Any = record
    for part in dotted.split("."):
        if not isinstance(value, Mapping) or part not in value:
            return None
        value = value[part]
    return value


def _term_matches(term: str, record: Mapping[str, Any]) -> bool:
    """One `$.a.b OP value` comparison, with CloudWatch's semantics for the forms
    this stack uses: numeric comparison, and string equality where `*` is a
    wildcard. A missing field never matches."""
    parsed = _TERM.match(term.strip().strip("()").strip())
    assert parsed, f"not a term this evaluator understands: {term!r}"
    field, op, raw = parsed.groups()
    actual = _field(record, field)
    if actual is None:
        return False
    if raw.startswith('"'):
        wanted = re.compile("^" + re.escape(raw[1:-1]).replace(r"\*", ".*") + "$")
        hit = isinstance(actual, str) and bool(wanted.match(actual))
        return hit if op == "=" else not hit if op == "!=" else False
    if isinstance(actual, bool) or not isinstance(actual, (int, float)):
        return False
    number = float(raw)
    return {
        "=": actual == number,
        "!=": actual != number,
        ">=": actual >= number,
        "<=": actual <= number,
        ">": actual > number,
        "<": actual < number,
    }[op]


def _pattern_matches(pattern: str, record: Mapping[str, Any]) -> bool:
    """A JSON metric-filter pattern (`{ … }`, `&&` binding tighter than `||`)."""
    body = pattern.strip()
    assert body.startswith("{") and body.endswith("}"), pattern
    return any(
        all(_term_matches(term, record) for term in alternative.split("&&"))
        for alternative in body[1:-1].split("||")
    )


def test_the_pattern_evaluator_is_not_vacuous() -> None:
    """Its own known-bad control: a line the filter must NOT count is not counted,
    and a missing field is not a match."""
    assert _pattern_matches("{ $.http.status >= 500 }", {"http": {"status": 503}})
    assert not _pattern_matches("{ $.http.status >= 500 }", {"http": {"status": 404}})
    assert not _pattern_matches("{ $.http.status >= 500 }", {"status": 500})
    assert _pattern_matches(
        '{ $.event = "x" && $.request_id = "req_*" }', {"event": "x", "request_id": "req_1"}
    )
    assert not _pattern_matches('{ $.event = "x" && $.request_id = "req_*" }', {"event": "x"})
    assert _pattern_matches('{ ($.a = "1") || ($.a = "2") }', {"a": "2"})


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_web_five_xx_filter_matches_a_line_the_web_logger_writes(env_name: str) -> None:
    """Tracker: "the web container does not write JSON, so FiveXxEnvelopeFilterWeb
    matches nothing". It does now; this proves the synthesized filter counts the
    web logger's 500 line, ignores its 200 line, and can dimension it on `$.env`."""
    filters = _resources(observability(env_name), "AWS::Logs::MetricFilter")
    (web_filter,) = [
        metric_filter
        for logical_id, metric_filter in filters.items()
        if logical_id.startswith("FiveXxEnvelopeFilterWeb")
    ]
    pattern = web_filter["Properties"]["FilterPattern"]
    dimension = web_filter["Properties"]["MetricTransformations"][0]["Dimensions"][0]["Value"]

    lines = json.loads(WEB_LOG_CONTRACT.read_text())
    requests = [line for line in lines if line.get("event") == "http_request"]
    statuses = {line["http"]["status"]: _pattern_matches(pattern, line) for line in requests}
    assert statuses == {200: False, 500: True}, statuses

    # The `Environment` dimension resolves on every counted line to an
    # environment the alarms pin — a line without `env` would publish nothing.
    counted = [line for line in lines if _pattern_matches(pattern, line)]
    assert counted
    assert {_field(line, dimension.removeprefix("$.")) for line in counted} <= {
        "staging",
        "production",
    }


# ------------------------------------------------ the structured-log heartbeat


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_structured_log_heartbeat_is_off_by_default(env_name: str) -> None:
    """Critic P6R2-04, half one. **Absent until the formatter ships.**

    Every log-derived alarm is `NOT_BREACHING` on missing data, which is right while the
    application emits no JSON logs — and is why the heartbeat cannot be on yet. Today the
    absence it watches for is the *expected* state, so arming it now would page every
    twenty-four hours until somebody deleted it, which is how an estate learns to ignore
    its alarms.
    """
    names = {
        alarm["Properties"]["AlarmName"] for alarm in _alarms(observability(env_name)).values()
    }
    assert f"meridian-{env_name}-alarm-structured-logs-silent" not in names


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_structured_log_heartbeat_fires_on_ABSENCE_when_armed(env_name: str) -> None:
    """Critic P6R2-04, half two. **The one alarm that treats missing data as BREACHING.**

    Without it, "the formatter never shipped", "the formatter regressed" and "a field was
    renamed under the filters" all read as healthy alarms for ever, because every one of
    them is deliberately `NOT_BREACHING`. This is the inverse reading of the same metric —
    `SampleCount`, below one, breaching when absent — so no datapoint at all is an ALARM
    instead of a flat green line.

    It is armed with `-c structuredLogsLive=true`, in the deploy that ships the JSON
    formatter. Tracker row 46 carries the deadline.
    """
    template = observability(env_name, **{STRUCTURED_LOGS_CONTEXT_FLAG: True})
    alarm = _alarm_named(template, f"meridian-{env_name}-alarm-structured-logs-silent")

    assert alarm["Namespace"] == "Meridian/App"
    # Every request, not every 5xx (tracker T:138): a 5xx-free day must not page.
    assert alarm["MetricName"] == "HttpRequests"
    assert alarm["Statistic"] == "SampleCount"
    assert alarm["Period"] == STRUCTURED_LOGS_HEARTBEAT_PERIOD.to_seconds()
    assert alarm["Threshold"] == 1
    assert alarm["ComparisonOperator"] == "LessThanThreshold"
    # The whole point of the alarm.
    assert alarm["TreatMissingData"] == "breaching"
    # And it reads THIS environment's metric, like every other `Meridian/App` alarm.
    assert {"Name": "Environment", "Value": env_name} in alarm["Dimensions"]

    # The flag adds one alarm and nothing else.
    assert len(_alarms(template)) == len(_alarms(observability(env_name))) + 1


# ------------------------------------------------------------------------ the pipe


def test_the_pipe_does_not_filter_at_the_source(staging_obs: assertions.Template) -> None:
    """**The Pipe delivers everything. A source filter would delete the evidence.**

    The first build of this put an `anything-but` filter on the Pipe *source*, which reads
    like routing and is not: a Pipes source filter causes the message to be dropped AND
    acknowledged off the queue. The expected `InvalidDBInstanceState` messages — the only
    positive confirmation anywhere that the nightly stop schedule ran — were therefore
    consumed and thrown away before `scripts/staging_session.sh up` could read them, which
    is the exact failure ADR 0020 §7c exists to prevent.

    So: no `FilterCriteria`, an EventBridge bus as the target, and the routing done by two
    rules that can copy rather than consume.
    """
    pipes = _resources(staging_obs, "AWS::Pipes::Pipe")
    assert len(pipes) == 1
    properties = next(iter(pipes.values()))["Properties"]
    assert properties["Name"] == "meridian-staging-pipe-stop-dlq"

    assert "FilterCriteria" not in properties["SourceParameters"], (
        "a Pipes source filter DELETES what it does not match; see ADR 0024 §5"
    )
    # One message, one event. A batch of ten arrives as one event containing ten, which is
    # harder to read at 3am, not easier.
    assert properties["SourceParameters"]["SqsQueueParameters"]["BatchSize"] == 1

    # The target is the custom bus, stamped with a source both rules match on.
    bus_params = properties["TargetParameters"]["EventBridgeEventBusParameters"]
    assert bus_params["Source"] == STOP_EVENT_SOURCE
    assert not bus_params["Source"].startswith("aws."), (
        "EventBridge reserves the `aws.` source prefix and refuses the PutEvents"
    )

    buses = _resources(staging_obs, "AWS::Events::EventBus")
    assert [bus["Properties"]["Name"] for bus in buses.values()] == [
        "meridian-staging-events-alerts"
    ]


def test_the_two_rules_split_expected_from_unexpected(staging_obs: assertions.Template) -> None:
    """Unexpected → the alerts topic **and** the log group. Expected → the log group only.

    An email every night for a cost control working as designed is how a mailbox filter
    gets written, and a filtered mailbox is how the real failure is missed. So the expected
    refusal is logged and never emailed — and it is logged rather than dropped because it
    is the evidence that the schedule ran at all.
    """
    rules = {
        rule["Properties"]["Name"]: rule["Properties"]
        for rule in _resources(staging_obs, "AWS::Events::Rule").values()
        if "stop-dlq" in rule["Properties"].get("Name", "")
    }
    assert set(rules) == {
        "meridian-staging-rule-stop-dlq-unexpected",
        "meridian-staging-rule-stop-dlq-expected",
    }

    unexpected = rules["meridian-staging-rule-stop-dlq-unexpected"]
    expected = rules["meridian-staging-rule-stop-dlq-expected"]

    # Both are on the custom bus, not the default one the whole shared account uses.
    for properties in (unexpected, expected):
        assert "EventBusName" in properties
        assert properties["EventPattern"]["source"] == [STOP_EVENT_SOURCE]

    # ---- the unexpected pattern: anything-but, OR the field being absent.
    #
    # `anything-but` does NOT match a record where the leaf is missing. Without the second
    # branch a dead letter with no ERROR_CODE at all — a malformed target, a Scheduler
    # failure before the API call — matches neither rule and vanishes silently. Treating
    # "no code" as unexpected is the safe reading.
    branches = unexpected["EventPattern"]["detail"]["$or"]
    leaves = [
        branch["messageAttributes"][STOP_DLQ_ERROR_ATTRIBUTE]["stringValue"] for branch in branches
    ]
    assert [{"anything-but": [STOP_DLQ_EXPECTED_ERROR]}] in leaves
    assert [{"exists": False}] in leaves

    # ---- the expected pattern: the one code, exactly.
    assert expected["EventPattern"]["detail"]["messageAttributes"][STOP_DLQ_ERROR_ATTRIBUTE][
        "stringValue"
    ] == [STOP_DLQ_EXPECTED_ERROR]

    # ---- targets
    log_group_name = "meridian-staging-logs-stop-schedule"
    log_groups = {
        group["Properties"]["LogGroupName"]: group["Properties"]
        for group in _resources(staging_obs, "AWS::Logs::LogGroup").values()
    }
    assert log_group_name in log_groups
    # It is the evidence trail, so it gets the estate's CMK and retention like everything
    # else — the estate-wide audit at the bottom of this file has no exception list.
    assert log_groups[log_group_name]["RetentionInDays"] == MINIMUM_RETENTION_DAYS
    assert "KmsKeyId" in log_groups[log_group_name]

    unexpected_targets = json.dumps(unexpected["Targets"])
    assert "Fn::ImportValue" in unexpected_targets, "the unexpected rule does not page SNS"
    assert "log-group" in unexpected_targets, "the operator cannot read it back in one place"
    expected_targets = json.dumps(expected["Targets"])
    assert "log-group" in expected_targets
    assert "Fn::ImportValue" not in expected_targets, (
        "the expected nightly refusal must never be emailed"
    )

    # EventBridge writes into a log group through a RESOURCE policy. It is a plain
    # CloudFormation resource, deliberately: the CDK log-group target writes it with a
    # Lambda-backed custom resource, which would add an implicit log group with no CMK and
    # no retention.
    #
    # **Both principals, and no condition** (critic P6R2-03). AWS's documented policy for
    # an EventBridge → CloudWatch Logs target names `events.amazonaws.com` AND
    # `delivery.logs.amazonaws.com`, with no `Condition`:
    # https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-use-resource-based.html#eb-cloudwatchlogs-permissions
    # The first build named one principal and added an `aws:SourceAccount` of its own —
    # a write the delivery path makes as the other principal would have been refused, and
    # a refused write here is the nightly confirmation vanishing silently.
    policies = _resources(staging_obs, "AWS::Logs::ResourcePolicy")
    assert len(policies) == 1
    # `PolicyDocument` here is a JSON *string* built by `Fn::Join` around the log-group
    # ARN's tokens, so it is matched as text rather than parsed.
    document = json.dumps(next(iter(policies.values()))["Properties"]["PolicyDocument"])
    assert "events.amazonaws.com" in document
    assert "delivery.logs.amazonaws.com" in document
    assert "Condition" not in document
    assert "aws:SourceAccount" not in document


def test_the_pipe_role_reaches_exactly_one_queue_and_one_bus(
    staging_obs: assertions.Template,
) -> None:
    """Scoped by hand: no `sqs:*`, no second resource, and **no `sns:Publish` any more**.

    The Pipe used to publish to the alerts topic directly. It does not now — it puts the
    message on the bus and a rule publishes — so the role loses `sns:Publish` entirely and
    the topic policy needs nothing for `pipes.amazonaws.com`. A permission that is no
    longer needed and is left behind is a permission nobody will ever remove.

    The trust policy carries `aws:SourceAccount`, the same confused-deputy guard the
    Scheduler role got in ADR 0020 §12a — both role ARNs are derivable from the naming
    convention, so a role that trusts `pipes.amazonaws.com` unconditionally can be assumed
    on behalf of a pipe in any account that guesses the name.
    """
    roles = {
        role["Properties"]["RoleName"]: role["Properties"]
        for role in _resources(staging_obs, "AWS::IAM::Role").values()
    }
    role = roles["meridian-staging-iam-stop-dlq-pipe"]
    trust = role["AssumeRolePolicyDocument"]["Statement"][0]
    assert trust["Principal"]["Service"] == "pipes.amazonaws.com"
    assert "aws:SourceAccount" in json.dumps(trust["Condition"])

    document = json.dumps(
        [
            policy["Properties"]["PolicyDocument"]
            for policy in _resources(staging_obs, "AWS::IAM::Policy").values()
            if "StopDlqPipeRole" in json.dumps(policy["Properties"]["Roles"])
        ]
    )
    assert "sqs:ReceiveMessage" in document
    assert "events:PutEvents" in document
    assert "sns:Publish" not in document, "the Pipe no longer publishes to SNS"
    assert '"sqs:*"' not in document
    assert '"events:*"' not in document


def test_production_has_no_stop_schedule_and_therefore_no_routing(
    production_obs: assertions.Template,
) -> None:
    """The production database is never stopped, so there is no DLQ, no Pipe, no bus, no
    rules, no stop-schedule log group and no unconsumed-message alarm."""
    assert _resources(production_obs, "AWS::Pipes::Pipe") == {}
    assert _resources(production_obs, "AWS::Events::EventBus") == {}
    assert _resources(production_obs, "AWS::Logs::ResourcePolicy") == {}
    rule_names = {
        rule["Properties"].get("Name")
        for rule in _resources(production_obs, "AWS::Events::Rule").values()
    }
    assert not any("stop-dlq" in (name or "") for name in rule_names)
    names = {alarm["Properties"]["AlarmName"] for alarm in _alarms(production_obs).values()}
    assert "meridian-production-alarm-stop-dlq-unconsumed" not in names


def test_the_dlq_alarm_is_on_age_not_depth(staging_obs: assertions.Template) -> None:
    """The withdrawn alarm stays withdrawn.

    What replaces it watches for a message **nobody consumed** — which is the Pipe being
    broken, a fault neither the Pipe nor the script can report about itself.
    """
    alarm = _alarm_named(staging_obs, "meridian-staging-alarm-stop-dlq-unconsumed")
    assert alarm["MetricName"] == "ApproximateAgeOfOldestMessage"
    assert alarm["Threshold"] == 6 * 60 * 60
    assert "ApproximateNumberOfMessagesVisible" not in json.dumps(alarm)


def test_the_session_script_reads_the_log_group_and_no_longer_drains_the_queue() -> None:
    """`scripts/staging_session.sh up` reads CloudWatch Logs. It must not read SQS.

    This is the assertion that would have caught the original fault. The script used to
    `sqs receive-message` the dead-letter queue to print the expected
    `InvalidDBInstanceState` confirmation — and the Pipe's source filter was silently
    consuming exactly those messages first, so the drain found an empty queue on a working
    night and an empty queue on a broken one.

    Reading SQS is now wrong twice over: the messages are gone (the Pipe consumes every
    one of them, by design), and a drain destroys the evidence it just read, so the same
    question cannot be asked again next session. The log group can be re-read for the rest
    of the session and every night the stack stays up.
    """
    script = _session_script()
    assert STOP_DLQ_EXPECTED_ERROR in script
    assert "logs filter-log-events" in script
    assert "meridian-staging-logs-stop-schedule" in script
    assert "aws sqs receive-message" not in script, (
        "the script is draining SQS again; the Pipe consumes every message first"
    )
    assert "sqs delete-message" not in script

    # Both halves of the report survive: the positive confirmation and the failure.
    assert "ok: $STOP_DLQ_EXPECTED_ERROR" in script
    assert "UNEXPECTED" in script

    docstring = ObservabilityStack._stop_schedule_routing.__doc__ or ""
    assert "staging_session.sh" in docstring
    assert "discards" in docstring or "deletes" in docstring


def test_the_session_script_reads_rds_events_for_a_SUCCESSFUL_stop() -> None:
    """Critic P6R2-02. **The log group is evidence of a REFUSED stop, and only that.**

    A dead letter exists only when `StopDBInstance` was called and refused — the ordinary
    night, when staging's instance was already stopped. The night the schedule does the
    work the cost control exists for, it stops a *running* instance, succeeds, and
    dead-letters nothing. The first build read only the log group, so that night reported
    "NO stop-schedule result" about a schedule that had just worked: silence meant two
    opposite things and the script picked the wrong one.

    So `up` also reads RDS's own event stream — `describe-events`, not CloudTrail
    `lookup-events`, because `rds:DescribeEvents` sits beside the start/stop permissions
    the operator already has and a CloudTrail read does not. Either piece of evidence is a
    pass; only the absence of both is a warning.

    It also waits for the Pipe to be `RUNNING` (P6R2-06): the deploy immediately above
    recreated it, and a Pipe that has not polled yet leaves the log group empty for a
    reason that has nothing to do with the schedule.
    """
    script = _session_script()

    assert "aws rds describe-events" in script
    assert "--source-type db-instance" in script
    assert "--event-categories availability" in script
    # `--duration` is in MINUTES; 36 hours is the same window the log-group read uses.
    assert "STOP_LOOKBACK_MINUTES=$(( STOP_LOG_LOOKBACK_HOURS * 60 ))" in script
    assert "cloudtrail lookup-events" not in script

    # The Pipe is polled for RUNNING before the log group is believed to be empty.
    assert "aws pipes describe-pipe" in script
    assert "--query CurrentState" in script
    assert 'PIPE_STATE" = "RUNNING"' in script

    # The operator-permissions list in the header gained the one new permission.
    assert "rds:DescribeEvents" in script

    # A successful stop with no dead letter is NOT a warning any more.
    assert "no dead letter, which is what a successful stop looks like" in script
    assert "NO stop-schedule evidence" in script

    docstring = ObservabilityStack._stop_schedule_routing.__doc__ or ""
    assert "describe-events" in docstring
    assert "refusal" in docstring.lower()
    # P6R2-05: the staging group is destroyed every session, so it is not a 400-day history.
    assert "every night while the stack was up" in docstring


# ------------------------------------------------------------------- the dashboard


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_dashboard_shows_no_log_line_bodies(env_name: str) -> None:
    """**No `log` widget, in either environment.**

    A dashboard is the most-screenshotted surface in the estate, and a `LogQueryWidget`
    renders raw log *bodies* into it. The log-derived numbers on this dashboard are counts
    from the metric filters, which carry no text. The absence is the control, so it is a
    test rather than a comment.
    """
    dashboards = _resources(observability(env_name), "AWS::CloudWatch::Dashboard")
    assert len(dashboards) == 1
    properties = next(iter(dashboards.values()))["Properties"]
    assert properties["DashboardName"] == f"meridian-{env_name}-dashboard-golden-signals"

    body = json.dumps(properties["DashboardBody"])
    assert '\\"type\\":\\"log\\"' not in body and '"type": "log"' not in body
    for forbidden in ("SOURCE ", "fields @message", "@message", "LogQuery"):
        assert forbidden not in body, f"the dashboard references {forbidden}"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_dashboard_covers_the_four_golden_signals_and_security(env_name: str) -> None:
    """Latency, traffic, errors, saturation — then the Lambda, backups and security.

    Asserted by widget title, because the titles are what the reader navigates by at 3am
    and a renamed widget is a reader who cannot find the graph.
    """
    properties = next(
        iter(_resources(observability(env_name), "AWS::CloudWatch::Dashboard").values())
    )["Properties"]
    # `ensure_ascii=False`: the widget titles contain em dashes, and the default
    # `json.dumps` would escape them to `—` and never match.
    body = json.dumps(properties["DashboardBody"], ensure_ascii=False)
    for title in (
        "Latency — ALB target response time",
        "Latency — RDS read/write",
        "Traffic — ALB requests",
        "Traffic — CloudFront",
        "Errors — ALB and target 5xx",
        "Errors — CloudFront 5xx rate",
        "Saturation — ECS CPU / memory",
        "Saturation — RDS",
        "User Migration Lambda",
        "Backups — jobs by outcome",
        "Security — WAF",
        # GuardDuty is NOT in this list: its widget needs a `DetectorId` that only
        # `-c guardDutyDetectorId=` supplies, and Security Hub has no CloudWatch namespace
        # at all. See `test_the_dashboard_shows_no_metric_that_does_not_exist`.
        "Security — auth failures",
    ):
        assert title in body, f"the dashboard has no {title!r} widget"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_dashboard_warns_that_the_log_metrics_are_not_live_yet(env_name: str) -> None:
    """A flat zero on the errors row is not yet evidence of health.

    The metric filters match nothing until the application emits JSON logs, so the
    dashboard says so in its header. Without that line, "zero unhandled exceptions" reads
    as a result rather than as an absence of data.
    """
    properties = next(
        iter(_resources(observability(env_name), "AWS::CloudWatch::Dashboard").values())
    )["Properties"]
    body = json.dumps(properties["DashboardBody"])
    assert "no data until the application emits JSON logs" in body
    assert "migration-tracker" in body
    # And it says which environment it is showing, because the metrics are dimensioned.
    assert f"Environment={env_name}" in body


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_dashboard_shows_no_metric_that_does_not_exist(env_name: str) -> None:
    """Two security widgets were removed, and neither may come back as it was.

    *Security Hub* has **no CloudWatch namespace at all** — it publishes findings to
    EventBridge. The widget that used to be here rendered an empty graph for ever: a blank
    chart under a security heading, which reads as "no findings". The finding rule in
    `_account_finding_rules` is the control; the dashboard does not get to imply a second.

    *GuardDuty* does have a namespace, but `FindingCount` is published **per detector** and
    returns nothing without the `DetectorId` dimension. The detector belongs to the account
    (ADR 0001), so its id is passed in with `-c guardDutyDetectorId=`; without the flag the
    widget is simply absent, because an absent widget is honest and an empty one is not.
    """
    body = json.dumps(
        next(iter(_resources(observability(env_name), "AWS::CloudWatch::Dashboard").values()))[
            "Properties"
        ]["DashboardBody"]
    )
    assert "AWS/SecurityHub" not in body, "there is no AWS/SecurityHub namespace"
    assert "AWS/GuardDuty" not in body, "GuardDuty needs a DetectorId; omit the widget"

    with_detector = json.dumps(
        next(
            iter(
                _resources(
                    observability(env_name, guardDutyDetectorId="d-0"),
                    "AWS::CloudWatch::Dashboard",
                ).values()
            )
        )["Properties"]["DashboardBody"]
    )
    assert "AWS/GuardDuty" in with_detector
    assert "DetectorId" in with_detector
    assert "d-0" in with_detector


# ----------------------------------------------------------------------- the canary


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_canary_is_off_until_its_cost_is_approved(env_name: str) -> None:
    """≈ $10.40 per environment per month against ≈ $11 of headroom.

    That is a spend decision, and a stack does not get to make one. Default off, in both
    environments, behind `-c enableCanary=true`.
    """
    template = observability(env_name)
    assert _resources(template, "AWS::Synthetics::Canary") == {}
    names = {alarm["Properties"]["AlarmName"] for alarm in _alarms(template).values()}
    assert f"meridian-{env_name}-alarm-canary-failed" not in names


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_canary_hits_the_public_health_path_every_five_minutes(env_name: str) -> None:
    template = observability(env_name, **{CANARY_CONTEXT_FLAG: True})
    canaries = _resources(template, "AWS::Synthetics::Canary")
    assert len(canaries) == 1
    properties = next(iter(canaries.values()))["Properties"]

    assert properties["Schedule"]["Expression"] == f"rate({CANARY_RATE.to_minutes()} minutes)"
    assert properties["RuntimeVersion"] == CANARY_RUNTIME.name
    # The same path the ALB target group, CloudFront and the container HEALTHCHECK use.
    # Hitting anything else would test a different thing from the one the load balancer
    # believes.
    assert HEALTH_PATH in properties["Code"]["Script"]
    assert "https://" in properties["Code"]["Script"]
    # The body is never logged: a canary artifact is a file in S3 for thirty days, and the
    # health endpoint's contract can change without anyone thinking about this script.
    assert "response.text()" not in properties["Code"]["Script"]
    assert "log.info(JSON" not in properties["Code"]["Script"]

    # No VPC: a canary inside the VPC bypasses CloudFront and tests less than the ALB
    # health check already does.
    assert "VPCConfig" not in properties

    retention = CANARY_ARTIFACT_RETENTION.to_days()
    assert properties["SuccessRetentionPeriod"] == retention
    assert properties["FailureRetentionPeriod"] == retention


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_canary_artifacts_bucket_is_encrypted_and_expires(env_name: str) -> None:
    """The `logs` CMK and a 30-day lifecycle. There is no reason to keep four hundred days
    of screenshots of `{"status":"ok"}`, and a bucket with no lifecycle rule grows for
    ever."""
    template = observability(env_name, **{CANARY_CONTEXT_FLAG: True})
    buckets = _resources(template, "AWS::S3::Bucket")
    assert len(buckets) == 1
    properties = next(iter(buckets.values()))["Properties"]
    assert properties["BucketName"] == f"meridian-{env_name}-s3-canary-artifacts"

    encryption = properties["BucketEncryption"]["ServerSideEncryptionConfiguration"][0]
    assert encryption["ServerSideEncryptionByDefault"]["SSEAlgorithm"] == "aws:kms"
    assert "KMSMasterKeyID" in encryption["ServerSideEncryptionByDefault"]

    rule = properties["LifecycleConfiguration"]["Rules"][0]
    assert rule["ExpirationInDays"] == CANARY_ARTIFACT_RETENTION.to_days()
    assert properties["PublicAccessBlockConfiguration"]["BlockPublicAcls"] is True

    # **The bucket has a FIXED name, in a stack staging destroys every session.** RETAIN
    # there leaves it behind and the next `up` fails on "bucket already exists" — on a
    # bucket holding thirty-day-old screenshots of a health endpoint. Production keeps
    # RETAIN: a production bucket is never deleted by a script.
    bucket_resource = next(iter(_resources(template, "AWS::S3::Bucket").values()))
    transient = ENV_CONFIG[env_name].destroyed_between_phases
    assert bucket_resource["DeletionPolicy"] == ("Delete" if transient else "Retain")
    assert bucket_resource["UpdateReplacePolicy"] == ("Delete" if transient else "Retain")
    # A versioned bucket is not empty when CloudFormation asks S3 to delete it, so DESTROY
    # alone leaves the stack in DELETE_FAILED.
    assert bool(_resources(template, "Custom::S3AutoDeleteObjects")) is transient


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_canary_role_is_scoped_and_its_wildcards_are_documented(env_name: str) -> None:
    """No `CloudWatchSyntheticsFullAccess` — it is `s3:*` on every bucket in an account
    shared with another owner (ADR 0001).

    Two statements say `Resource: "*"` and both are named here. `s3:ListAllMyBuckets` and
    `cloudwatch:PutMetricData` have **no resource-level permission in IAM at all**, so a
    narrower statement is not possible, only a wrong one. `PutMetricData` is confined with
    a namespace condition instead, which is the documented substitute.
    """
    template = observability(env_name, **{CANARY_CONTEXT_FLAG: True})

    wildcard_sids = set()
    for policy in _resources(template, "AWS::IAM::Policy").values():
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]:
            resource = statement.get("Resource")
            if resource == "*" or resource == ["*"]:
                sid = statement.get("Sid")
                assert sid, f"an undocumented wildcard statement: {statement}"
                wildcard_sids.add(sid)
                if sid == "PublishCanaryMetricsOnly":
                    assert (
                        statement["Condition"]["StringEquals"]["cloudwatch:namespace"]
                        == "CloudWatchSynthetics"
                    )
                if sid == "PublishBackupMetricsOnly":
                    assert (
                        statement["Condition"]["StringEquals"]["cloudwatch:namespace"]
                        == "Meridian/Backup"
                    )

    assert wildcard_sids <= DOCUMENTED_WILDCARD_SIDS, (
        f"undocumented Resource: '*' statements: {wildcard_sids - DOCUMENTED_WILDCARD_SIDS}"
    )

    document = json.dumps(
        [
            policy["Properties"]["PolicyDocument"]
            for policy in _resources(template, "AWS::IAM::Policy").values()
        ]
    )
    assert '"s3:*"' not in document
    assert "CloudWatchSyntheticsFullAccess" not in document

    # **The log-group statement is scoped to THIS canary's own log group**, and the name
    # in it has to be the canary's actual name. Synthetics caps a canary name at 21
    # characters, so the estate naming convention is abandoned for this one resource — and
    # the role used to spell the abandoned name a second time, by hand, differently. A
    # canary that cannot write its own logs fails silently: the runs happen, the artifacts
    # land, and there is nothing to read when one of them fails.
    canary_name = next(iter(_resources(template, "AWS::Synthetics::Canary").values()))[
        "Properties"
    ]["Name"]
    own_log_group = [
        statement
        for policy in _resources(template, "AWS::IAM::Policy").values()
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
        if statement.get("Sid") == "OwnLogGroupOnly"
    ]
    assert len(own_log_group) == 1
    resource = json.dumps(own_log_group[0]["Resource"])
    assert f"/aws/lambda/cwsyn-{canary_name}-*" in resource, resource


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_canary_alarm_treats_a_stopped_canary_as_a_failure(env_name: str) -> None:
    """A canary that has stopped running cannot tell you anything, which is the same as a
    failure. `notBreaching` here would mean a deleted canary reads as a healthy site."""
    template = observability(env_name, **{CANARY_CONTEXT_FLAG: True})
    alarm = _alarm_named(template, f"meridian-{env_name}-alarm-canary-failed")
    assert alarm["TreatMissingData"] == "breaching"
    assert alarm["ComparisonOperator"] == "LessThanThreshold"
    assert alarm["Threshold"] == 100


# ------------------------------------------------- the estate-wide log group audit


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_log_group_in_every_stack_is_encrypted_and_expires(env_name: str) -> None:
    """**Not about this stack. About all of them.**

    A log group with no retention keeps PHI-adjacent records for ever and bills for it; a
    log group on the AWS-managed key has no key policy we control and no CloudTrail
    `Decrypt` event naming a key we own. Both are silent: nothing fails, and the gap is
    only visible if somebody goes and looks at every log group in the account.

    So this walks every `AWS::Logs::LogGroup` in every synthesized stack, in both
    environments. `LOG_GROUP_EXCEPTIONS` is empty and is meant to stay that way.

    What it cannot reach: the log groups CDK's own helper Lambdas create *implicitly* on
    first invocation. They never appear in a template and default to never-expire and no
    CMK; the log-group governor (`_log_group_governor`, T:60/T:65) fixes them at run time.
    """
    assembly = synth_with(
        env_name,
        cloudfrontPrefixListId="pl-0aaaaaaaaaaaaaaaa",
        hostedZoneId="Z0AAAAAABBBBBBCCCCCC",
        **{CANARY_CONTEXT_FLAG: True},
    )

    seen = 0
    for artifact in assembly.stacks:
        for logical_id, resource in artifact.template.get("Resources", {}).items():
            if resource["Type"] != "AWS::Logs::LogGroup":
                continue
            where = f"{artifact.stack_name}/{logical_id}"
            if where in LOG_GROUP_EXCEPTIONS:
                continue
            seen += 1
            properties = resource["Properties"]
            retention = properties.get("RetentionInDays")
            assert retention is not None, f"{where} has no retention: it keeps logs for ever"
            assert retention >= MINIMUM_RETENTION_DAYS, (
                f"{where} retains {retention} days, below the estate's "
                f"{MINIMUM_RETENTION_DAYS}-day floor"
            )
            assert properties.get("KmsKeyId"), (
                f"{where} has no customer-managed key: no key policy we control, and no "
                "CloudTrail Decrypt event naming a key we own"
            )

    # A test that walks nothing passes. This is the guard against that.
    assert seen >= 10, f"only {seen} log groups found — did the walk break?"


# ------------------------------------------------------------ SES (tracker T:39)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_a_rendering_failure_pages_its_own_environment(env_name: str) -> None:
    """The one email failure with no bounce and no complaint behind it."""
    alarm = _alarm_named(
        observability(env_name), f"meridian-{env_name}-alarm-ses-rendering-failure"
    )
    assert alarm["Namespace"] == "AWS/SES"
    assert alarm["MetricName"] == "RenderingFailure"
    # The dimension the shared configuration set's CloudWatch destination publishes.
    assert alarm["Dimensions"] == [{"Name": "env", "Value": env_name}]
    assert alarm["Threshold"] == 1
    assert alarm["EvaluationPeriods"] == 1
    assert alarm["TreatMissingData"] == "notBreaching"


def test_the_reputation_rates_alarm_once_in_production(
    staging_obs: assertions.Template, production_obs: assertions.Template
) -> None:
    """Account-level rates are the ones AWS pauses sending on; one alarm, not two emails."""
    bounce = _alarm_named(production_obs, "meridian-production-alarm-ses-bounce-rate")
    complaint = _alarm_named(production_obs, "meridian-production-alarm-ses-complaint-rate")
    for alarm, metric, threshold in (
        (bounce, "Reputation.BounceRate", SES_BOUNCE_RATE_THRESHOLD),
        (complaint, "Reputation.ComplaintRate", SES_COMPLAINT_RATE_THRESHOLD),
    ):
        assert alarm["Namespace"] == "AWS/SES"
        assert alarm["MetricName"] == metric
        assert "Dimensions" not in alarm, "the account-level metric has no dimension"
        assert alarm["Threshold"] == threshold
        assert alarm["ComparisonOperator"] == "GreaterThanThreshold"
        assert alarm["TreatMissingData"] == "notBreaching"
    assert SES_BOUNCE_RATE_THRESHOLD == 0.05
    assert SES_COMPLAINT_RATE_THRESHOLD == 0.001

    staging_names = {a["Properties"]["AlarmName"] for a in _alarms(staging_obs).values()}
    assert not {n for n in staging_names if "bounce-rate" in n or "complaint-rate" in n}


def test_the_shared_configuration_set_publishes_rendering_failures_by_env() -> None:
    """The metric the alarm above reads exists only because of this destination."""
    dns = assertions.Template.from_json(
        synth_with("staging").get_stack_by_name("meridian-shared-dns").template
    )
    destinations = [
        body["Properties"]["EventDestination"]
        for body in _resources(dns, "AWS::SES::ConfigurationSetEventDestination").values()
        if "CloudWatchDestination" in body["Properties"]["EventDestination"]
    ]
    assert len(destinations) == 1
    (destination,) = destinations
    assert destination["MatchingEventTypes"] == ["renderingFailure"]
    (dimension,) = destination["CloudWatchDestination"]["DimensionConfigurations"]
    assert dimension["DimensionName"] == "env"
    assert dimension["DimensionValueSource"] == "messageTag"
    assert destination["Name"] == "meridian-shared-ses-metrics"


# ------------------------------------------- the log-group governor (T:60 / T:65)


def _function(template: assertions.Template, name: str) -> dict[str, Any]:
    (function,) = [
        body["Properties"]
        for body in _resources(template, "AWS::Lambda::Function").values()
        if body["Properties"].get("FunctionName") == name
    ]
    return function


def _role_statements(template: assertions.Template, role_name: str) -> list[dict[str, Any]]:
    role_ids = [
        logical_id
        for logical_id, body in _resources(template, "AWS::IAM::Role").items()
        if body["Properties"].get("RoleName") == role_name
    ]
    assert len(role_ids) == 1, role_name
    return [
        statement
        for body in _resources(template, "AWS::IAM::Policy").values()
        if {"Ref": role_ids[0]} in body["Properties"]["Roles"]
        for statement in body["Properties"]["PolicyDocument"]["Statement"]
    ]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_log_governor_reaches_only_this_environments_implicit_groups(env_name: str) -> None:
    """No account-level retention/encryption policy exists, so a scoped Lambda is the control."""
    template = observability(env_name)
    other = "production" if env_name == "staging" else "staging"
    function = _function(template, f"meridian-{env_name}-lambda-log-governor")
    environment = function["Environment"]["Variables"]
    prefixes = json.loads(environment["LOG_GROUP_PREFIXES"])
    assert prefixes == [
        f"/aws/lambda/meridian-{env_name}-",
        f"/aws/lambda/cwsyn-{env_name[:4]}-health-",
    ]
    assert environment["RETENTION_DAYS"] == str(MINIMUM_RETENTION_DAYS)
    assert "KeyLogs" in json.dumps(environment["KMS_KEY_ARN"])

    statements = {
        s["Sid"]: s
        for s in _role_statements(template, f"meridian-{env_name}-iam-lambda-log-governor")
    }
    write = statements["SetRetentionAndKeyOnOwnPrefixesOnly"]
    assert sorted(write["Action"]) == ["logs:AssociateKmsKey", "logs:PutRetentionPolicy"]
    resources = json.dumps(write["Resource"])
    for prefix in prefixes:
        assert f"log-group:{prefix}*" in resources
    assert other not in resources and "log-group:*" not in resources
    assert statements["ListLogGroupSettings"]["Action"] == "logs:DescribeLogGroups"
    # Nothing but those, and its own log stream.
    assert set(statements) == {
        "WriteOwnLogs",
        "ListLogGroupSettings",
        "SetRetentionAndKeyOnOwnPrefixesOnly",
    }


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_log_governor_runs_on_a_schedule_and_on_create(env_name: str) -> None:
    rules = {
        rule["Properties"]["Name"]: rule["Properties"]
        for rule in _resources(observability(env_name), "AWS::Events::Rule").values()
    }
    sweep = rules[f"meridian-{env_name}-rule-log-governor-sweep"]
    assert sweep["ScheduleExpression"] == "rate(6 hours)"
    on_create = rules[f"meridian-{env_name}-rule-log-governor-create"]["EventPattern"]
    assert on_create["detail"]["eventName"] == ["CreateLogGroup"]
    assert on_create["detail"]["requestParameters"]["logGroupName"] == [
        {"prefix": f"/aws/lambda/meridian-{env_name}-"},
        {"prefix": f"/aws/lambda/cwsyn-{env_name[:4]}-health-"},
    ]


# --------------------------------------------- backup freshness (T:160, G-M1)


def test_backup_freshness_is_production_only(staging_obs: assertions.Template) -> None:
    """Staging has no scheduled plan (M-2); every freshness alarm would be red for ever."""
    names = {
        body["Properties"].get("FunctionName")
        for body in _resources(staging_obs, "AWS::Lambda::Function").values()
    }
    assert "meridian-staging-lambda-backup-freshness" not in names
    alarm_names = {a["Properties"]["AlarmName"] for a in _alarms(staging_obs).values()}
    assert not {n for n in alarm_names if "-backup-" in n}


def test_backup_freshness_alarms_cover_age_absence_and_silence(
    production_obs: assertions.Template,
) -> None:
    for label, limit in (("rds", 26), ("artifacts", 26), ("phi", 26), ("dr", 32)):
        alarm = _alarm_named(production_obs, f"meridian-production-alarm-backup-age-{label}")
        assert alarm["Namespace"] == "Meridian/Backup"
        assert alarm["MetricName"] == "RecoveryPointAgeHours"
        assert {"Name": "Resource", "Value": label} in alarm["Dimensions"]
        assert alarm["Threshold"] == limit
        assert alarm["ComparisonOperator"] == "GreaterThanThreshold"

    pitr = _alarm_named(production_obs, "meridian-production-alarm-backup-pitr-lag")
    assert pitr["MetricName"] == "RestorableLagHours" and pitr["Threshold"] == 1

    missing = _alarm_named(production_obs, "meridian-production-alarm-backup-missing")
    assert missing["MetricName"] == "MissingRecoveryPoints"
    assert missing["Threshold"] == 1

    # The heartbeat: a checker that never runs, raises, or lost its schedule alarms too.
    silent = _alarm_named(production_obs, "meridian-production-alarm-backup-checker-silent")
    assert silent["MetricName"] == "CheckerRuns"
    assert silent["Statistic"] == "SampleCount"
    assert silent["ComparisonOperator"] == "LessThanThreshold"
    assert silent["TreatMissingData"] == "breaching"
    assert silent["Period"] == 24 * 60 * 60


def test_backup_freshness_can_list_and_describe_and_nothing_else(
    production_obs: assertions.Template,
) -> None:
    statements = {
        s["Sid"]: s
        for s in _role_statements(production_obs, "meridian-production-iam-lambda-backup-freshness")
    }
    assert set(statements) == {
        "WriteOwnLogs",
        "ListRecoveryPointsInTheTwoVaults",
        "DescribeTheOneDatabase",
        "PublishBackupMetricsOnly",
    }
    vaults = statements["ListRecoveryPointsInTheTwoVaults"]
    assert vaults["Action"] == "backup:ListRecoveryPointsByBackupVault"
    assert len(vaults["Resource"]) == 2
    assert "meridian-production-backup-dr" in json.dumps(vaults["Resource"])
    assert statements["DescribeTheOneDatabase"]["Action"] == "rds:DescribeDBInstances"

    function = _function(production_obs, "meridian-production-lambda-backup-freshness")
    variables = function["Environment"]["Variables"]
    assert variables["DR_BACKUP_VAULT_NAME"] == "meridian-production-backup-dr"
    assert variables["DB_INSTANCE_IDENTIFIER"] == "meridian-production-rds-main"
    protected = json.dumps(variables["PROTECTED_RESOURCES"])
    for label in ("rds", "artifacts", "phi"):
        assert f'\\"{label}\\"' in protected or f'"{label}"' in protected
