"""The foundation stack's load-bearing properties.

These are not "does CDK work" tests. Each one asserts a control that a HIPAA
assessment or the plan's §6 data-safety argument depends on, and that a
plausible future edit could silently remove.
"""

from __future__ import annotations

import json
import re
from typing import Any

import pytest
from aws_cdk import assertions
from conftest import synth_with

from meridian.config import ANOMALY_THRESHOLD_USD
from meridian.stacks.foundation import (
    AUDIT_RETENTION_DAYS,
    CONSOLE_DRIFT_PATTERN,
    GUARDDUTY_FEATURES,
    HIPAA_CONFORMANCE_PACK_FILE,
    INSPECTOR_RESOURCE_TYPES,
    SECURITY_HUB_STANDARDS,
    TAG_KEY_ENVIRONMENT,
)
from meridian.tags import REQUIRED_TAG_KEYS


def _resources(template: assertions.Template, type_name: str) -> list[Any]:
    return list(template.find_resources(type_name).values())


def _json_path(event: dict[str, Any], path: str) -> Any:
    """Resolve a CloudWatch Logs `$.a.b.c` selector against a sample event."""
    node: Any = event
    for part in path.removeprefix("$.").split("."):
        if not isinstance(node, dict) or part not in node:
            return _MISSING
        node = node[part]
    return node


_MISSING = object()


def _term(event: dict[str, Any], term: str) -> bool:
    """Evaluate one CloudWatch Logs filter term against a sample event.

    Enough of the grammar to cover the drift pattern, and no more: `NOT EXISTS`,
    `=` with an optional trailing `*` wildcard, and `!=`. The point is to be able
    to say "this record matches and that one does not" in a test, rather than
    only that the pattern string has not changed.
    """
    term = term.strip()
    if term.endswith("NOT EXISTS"):
        return _json_path(event, term.removesuffix("NOT EXISTS").strip()) is _MISSING

    match = re.fullmatch(r'(\$\.[\w.]+)\s*(!=|=)\s*"([^"]*)"', term)
    assert match, f"unsupported filter term: {term!r}"
    path, operator, expected = match.groups()
    actual = _json_path(event, path)

    if operator == "=":
        if actual is _MISSING:
            return False
        if expected.endswith("*"):
            return str(actual).startswith(expected[:-1])
        return str(actual) == expected
    # `!=` is a literal comparison — CloudWatch does not wildcard it, which is
    # the bug this pattern was rewritten to avoid. A missing field is not equal.
    return actual is _MISSING or str(actual) != expected


def _matches_drift_pattern(event: dict[str, Any]) -> bool:
    """Evaluate `CONSOLE_DRIFT_PATTERN` against a sample CloudTrail record.

    The pattern is a conjunction of four groups; the last is itself a
    disjunction. Parsing it by splitting on `&&` and `||` is crude but exact for
    this shape, and it keeps the test honest about what the deployed filter does.
    """
    body = CONSOLE_DRIFT_PATTERN.strip().removeprefix("{").removesuffix("}")
    groups = re.split(r"&&(?![^(]*\))", body)
    for group in groups:
        group = group.strip().removeprefix("(").removesuffix(")").strip()
        if "||" in group:
            if not any(_term(event, part) for part in group.split("||")):
                return False
        elif not _term(event, group):
            return False
    return True


def test_trail_has_log_file_validation_and_is_multi_region(
    foundation: assertions.Template,
) -> None:
    trails = _resources(foundation, "AWS::CloudTrail::Trail")
    assert len(trails) == 1, "exactly one trail of ours; the Terraform one is not adopted"
    props = trails[0]["Properties"]
    assert props["TrailName"] == "meridian-shared-cloudtrail-audit"
    assert props["EnableLogFileValidation"] is True
    assert props["IsMultiRegionTrail"] is True
    assert props["IncludeGlobalServiceEvents"] is True
    assert props["IsLogging"] is True
    # Without the CloudWatch Logs copy there are no metric filters and so no
    # drift tripwire.
    assert "CloudWatchLogsLogGroupArn" in props
    assert "KMSKeyId" in props


def test_trail_logs_management_events_and_meridian_s3_data_events(
    foundation: assertions.Template,
) -> None:
    props = _resources(foundation, "AWS::CloudTrail::Trail")[0]["Properties"]
    selectors = props["AdvancedEventSelectors"]
    fields = [{f["Field"]: f for f in selector["FieldSelectors"]} for selector in selectors]

    management = [f for f in fields if f["eventCategory"]["Equals"] == ["Management"]]
    assert management, "management events must be logged"

    data = [f for f in fields if f["eventCategory"]["Equals"] == ["Data"]]
    assert data, "S3 data events must be logged — today nothing logs object access"
    assert data[0]["resources.type"]["Equals"] == ["AWS::S3::Object"]
    # Scoped by ARN prefix so the future meridian-<env>-s3-* buckets are covered
    # before they exist, and the other owner's buckets never are (ADR 0001).
    starts_with = data[0]["resources.ARN"]["StartsWith"]
    assert len(starts_with) == 1
    rendered = str(starts_with[0])
    assert "meridian-" in rendered and "s3" in rendered


def test_audit_bucket_is_object_locked_in_compliance_mode(
    foundation: assertions.Template,
) -> None:
    """Compliance mode is the whole point: for seven years nobody, including the
    account root, can delete or overwrite an audit object version."""
    buckets = {r["Properties"]["BucketName"]: r for r in _resources(foundation, "AWS::S3::Bucket")}
    audit = buckets["meridian-shared-s3-audit"]["Properties"]
    assert audit["ObjectLockEnabled"] is True
    rule = audit["ObjectLockConfiguration"]["Rule"]["DefaultRetention"]
    assert rule["Mode"] == "COMPLIANCE"
    assert rule["Days"] == AUDIT_RETENTION_DAYS
    assert audit["VersioningConfiguration"]["Status"] == "Enabled"
    assert audit["PublicAccessBlockConfiguration"] == {
        "BlockPublicAcls": True,
        "BlockPublicPolicy": True,
        "IgnorePublicAcls": True,
        "RestrictPublicBuckets": True,
    }
    encryption = audit["BucketEncryption"]["ServerSideEncryptionConfiguration"][0]
    assert encryption["ServerSideEncryptionByDefault"]["SSEAlgorithm"] == "aws:kms"
    transitions = audit["LifecycleConfiguration"]["Rules"][0]["Transitions"]
    assert transitions[0] == {"StorageClass": "GLACIER", "TransitionInDays": 90}


def test_audit_bucket_rejects_plaintext_http(foundation: assertions.Template) -> None:
    policies = _resources(foundation, "AWS::S3::BucketPolicy")
    statements = [
        statement
        for policy in policies
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
    ]
    denies = [
        s
        for s in statements
        if s["Effect"] == "Deny"
        and s.get("Condition", {}).get("Bool", {}).get("aws:SecureTransport") == "false"
    ]
    assert denies, "every audit bucket needs the TLS-only deny statement"


def test_every_log_group_is_encrypted_and_kept_for_400_days(
    foundation: assertions.Template,
) -> None:
    """Both of them: the trail's copy, and the Inspector custom resource's.

    The second one is the easy one to miss. An `AwsCustomResource` that is not
    handed a log group makes its own, never-expiring and encrypted with the
    CloudWatch service key rather than a key we control — in an account holding
    PHI that is an audit log outside the retention baseline *and* outside the key
    hierarchy. The assertion is over *all* log groups precisely so that the next
    custom resource added here cannot reintroduce it.
    """
    groups = _resources(foundation, "AWS::Logs::LogGroup")
    assert len(groups) == 2
    names = {str(g["Properties"]["LogGroupName"]) for g in groups}
    assert "/aws/lambda/meridian-shared-inspector-ecr" in names
    for group in groups:
        props = group["Properties"]
        assert props["RetentionInDays"] == 400
        assert "KmsKeyId" in props
        assert group["DeletionPolicy"] == "Retain"


def test_the_four_security_alarms_exist_and_page_sns(
    foundation: assertions.Template,
) -> None:
    alarms = {
        r["Properties"]["AlarmName"]: r["Properties"]
        for r in _resources(foundation, "AWS::CloudWatch::Alarm")
    }
    assert set(alarms) == {
        "meridian-shared-alarm-console-create-delete",
        "meridian-shared-alarm-root-usage",
        "meridian-shared-alarm-breakglass-assumed",
        "meridian-shared-alarm-iam-policy-change",
    }
    for props in alarms.values():
        assert props["AlarmActions"], "an alarm with no action is a dashboard, not a control"
        assert props["Threshold"] == 1


def test_drift_tripwire_matches_the_human_path_positively(
    foundation: assertions.Template,
) -> None:
    """It must name who a *person* is, not try to exclude who a robot is.

    The earlier shape was `sessionIssuer.userName != "cdk-*"`. CloudWatch Logs
    filter patterns do not wildcard on `!=` — that was a literal comparison
    against the five characters `cdk-*`, true for every session in the account,
    so it excluded nothing and the alarm fired on every CDK deploy. An alarm that
    fires on every deploy gets muted, and a muted alarm is not a control.

    The two ways a human reaches this account are an IAM user and an Identity
    Center session (`AWSReservedSSO_*`, where `=` *does* wildcard). Matching those
    positively is why this cannot silently degrade again.
    """
    filters = _resources(foundation, "AWS::Logs::MetricFilter")
    patterns = [f["Properties"]["FilterPattern"] for f in filters]
    tripwire = [p for p in patterns if "Create*" in p]
    assert len(tripwire) == 1
    assert tripwire[0] == CONSOLE_DRIFT_PATTERN

    assert '$.userIdentity.type = "IAMUser"' in tripwire[0]
    assert 'sessionIssuer.userName = "AWSReservedSSO_*"' in tripwire[0]
    # Service-initiated calls are not somebody in a console.
    assert "$.userIdentity.invokedBy NOT EXISTS" in tripwire[0]
    # The broken exclusion must not come back. `!=` survives only on
    # `$.eventType`, where it is compared against a literal and needs no wildcard.
    negations = re.findall(r'(\$\.[\w.]+)\s*!=', tripwire[0])
    assert negations == ["$.eventType"], negations
    assert "cdk-" not in tripwire[0]


def test_drift_tripwire_accepts_a_human_sample_and_rejects_a_deploy_sample() -> None:
    """Evaluate the pattern against two CloudTrail records, not just read it.

    `sample_a` is Andres creating a bucket in the console; `sample_b` is the same
    call made by CloudFormation under a `cdk-*` bootstrap role. The first must
    match and the second must not — which is the whole behaviour, and it is the
    part the old pattern got backwards.
    """
    sample_human = {
        "eventName": "CreateBucket",
        "eventType": "AwsApiCall",
        "userIdentity": {"type": "IAMUser", "userName": "andres-cli"},
    }
    sample_sso = {
        "eventName": "DeleteBucket",
        "eventType": "AwsApiCall",
        "userIdentity": {
            "type": "AssumedRole",
            "sessionContext": {
                "sessionIssuer": {"userName": "AWSReservedSSO_meridian-shared-sso-admin_abc"}
            },
        },
    }
    sample_deploy = {
        "eventName": "CreateBucket",
        "eventType": "AwsApiCall",
        "userIdentity": {
            "type": "AssumedRole",
            "sessionContext": {"sessionIssuer": {"userName": "cdk-hnb659fds-cfn-exec-role"}},
        },
    }
    sample_service = {
        "eventName": "CreateServiceLinkedRole",
        "eventType": "AwsApiCall",
        "userIdentity": {"type": "IAMUser", "invokedBy": "config.amazonaws.com"},
    }

    assert _matches_drift_pattern(sample_human)
    assert _matches_drift_pattern(sample_sso)
    assert not _matches_drift_pattern(sample_deploy)
    assert not _matches_drift_pattern(sample_service)


def test_guardduty_features_are_pinned_to_the_cost_estimate(
    foundation: assertions.Template,
) -> None:
    """Base detector plus S3 data events; everything else explicitly off.

    Left to AWS's defaults, the enabled feature set is whatever AWS ships on the
    day of the deploy — which means the cost estimate Andres approved is not a
    statement about what will actually be billed. EBS malware protection is the
    expensive one, and it scans EC2 volumes Meridian does not run.
    """
    detector = _resources(foundation, "AWS::GuardDuty::Detector")[0]["Properties"]
    features = {f["Name"]: f["Status"] for f in detector["Features"]}
    assert features == dict(GUARDDUTY_FEATURES)
    assert features["S3_DATA_EVENTS"] == "ENABLED"
    assert features["EBS_MALWARE_PROTECTION"] == "DISABLED"


def test_the_conformance_pack_comes_from_an_asset_not_a_hand_uploaded_key(
    foundation: assertions.Template,
) -> None:
    """The control set that deploys is the YAML in this repository.

    A hand-uploaded key is a precondition that lives only in a README: the stack
    deploys, the pack points at a bucket path, and if nobody uploaded the file the
    130 HIPAA rules are simply not there. A CDK asset cannot be forgotten —
    `cdk deploy` publishes it — and its hash changes when the YAML does, so
    `cdk diff` sees a control-set change.
    """
    pack = _resources(foundation, "AWS::Config::ConformancePack")[0]["Properties"]
    uri = pack["TemplateS3Uri"]

    # An asset URL is assembled from the bootstrap staging bucket, so it is a
    # CloudFormation intrinsic, not a literal string.
    assert isinstance(uri, dict), f"expected an asset reference, got the literal {uri!r}"
    rendered = json.dumps(uri)
    assert "cdk-" in rendered and "assets" in rendered, rendered
    assert "conformance-packs/" not in rendered, "that is the old hand-uploaded key"

    # `DeliveryS3Bucket` named our Config bucket without granting the
    # conformance-pack service principal write access to it. Omitted: AWS Config
    # uses a bucket it manages itself.
    assert "DeliveryS3Bucket" not in pack


def test_the_vendored_conformance_pack_is_present_and_is_the_hipaa_one() -> None:
    """The asset has to point at a real file, and at the right one."""
    assert HIPAA_CONFORMANCE_PACK_FILE.is_file()
    text = HIPAA_CONFORMANCE_PACK_FILE.read_text()
    assert "Operational Best Practices for HIPAA Security" in text
    assert "AWS::Config::ConfigRule" in text


def test_detection_services_are_enabled(foundation: assertions.Template) -> None:
    assert _resources(foundation, "AWS::GuardDuty::Detector")[0]["Properties"]["Enable"] is True
    assert _resources(foundation, "AWS::SecurityHub::Hub")
    standards = _resources(foundation, "AWS::SecurityHub::Standard")
    assert len(standards) == len(SECURITY_HUB_STANDARDS)
    assert _resources(foundation, "AWS::AccessAnalyzer::Analyzer")
    assert _resources(foundation, "AWS::Config::ConfigurationRecorder")
    assert _resources(foundation, "AWS::Config::DeliveryChannel")
    pack = _resources(foundation, "AWS::Config::ConformancePack")[0]["Properties"]
    assert pack["ConformancePackName"] == "Operational-Best-Practices-for-HIPAA-Security"
    # Inspector v2 has no CloudFormation resource; it is a custom resource.
    assert foundation.find_resources("Custom::Inspector2Ecr")


def test_the_three_security_hub_standards_are_enabled_by_name(
    foundation: assertions.Template,
) -> None:
    """FSBP, NIST 800-53 Rev 5 and CIS v3 — the Phase 8 verify list, asserted.

    Counting standards proves nothing about *which* ones, and the plan's Phase 8
    list names two of them (FSBP and the CIS benchmark) explicitly. A future edit
    that swaps CIS v3 for a version that does not exist, or that reverts to
    `enable_default_standards`, fails here.
    """
    arns = [
        json.dumps(s["Properties"]["StandardsArn"])
        for s in _resources(foundation, "AWS::SecurityHub::Standard")
    ]
    rendered = " ".join(arns)
    assert "aws-foundational-security-best-practices/v/1.0.0" in rendered
    assert "cis-aws-foundations-benchmark/v/3.0.0" in rendered
    assert "nist-800-53/v/5.0.0" in rendered
    # CIS v1.2.0 is the one standard with a region-less `ruleset/` ARN; v3 is not
    # it, and writing v3 in the v1.2.0 shape deploys nothing.
    assert "ruleset/" not in rendered
    hub = _resources(foundation, "AWS::SecurityHub::Hub")[0]["Properties"]
    assert hub["EnableDefaultStandards"] is False


def test_inspector_scans_ecr_and_lambda(foundation: assertions.Template) -> None:
    """ECR **and** Lambda — Phase 8 widened an ECR-only enablement.

    The User Migration Lambda (Phase 4) sees a password in clear text once per
    migrating user; a function nobody scans is a dependency tree nobody scans.
    EC2 stays off: no EC2 instance here runs application code, and it is the
    expensive meter.
    """
    resource = list(foundation.find_resources("Custom::Inspector2Ecr").values())[0]
    rendered = json.dumps(resource["Properties"])
    assert '\\"ECR\\"' in rendered or '"ECR"' in rendered
    assert "LAMBDA" in rendered
    assert "EC2" not in rendered
    # The code-scanning tier is a separate, dearer meter and is not enabled.
    assert "LAMBDA_CODE" not in rendered
    assert tuple(INSPECTOR_RESOURCE_TYPES) == ("ECR", "LAMBDA")


def test_inspector_re_enables_on_update_not_only_on_create(
    foundation: assertions.Template,
) -> None:
    """P8-01. Widening the resource types must not be a silent no-op.

    An `AwsCustomResource` with only a `Create` call fires once, when the
    resource is first created. In an account where the foundation stack already
    exists, adding `LAMBDA` changes the custom resource's properties,
    CloudFormation sends an **Update**, and a handler with no `Update` call
    reports success having done nothing: the stack goes green, the ADR says
    Lambda is scanned, and it is not. `inspector2:enable` is idempotent, so the
    same call serves both.
    """
    properties = list(foundation.find_resources("Custom::Inspector2Ecr").values())[0]["Properties"]
    assert "Create" in properties, "no Create call on the Inspector custom resource"
    update = properties.get("Update")
    assert update is not None, "no Update call: widening the resource types would be a no-op"
    rendered = json.dumps(update)
    assert "LAMBDA" in rendered and "ECR" in rendered
    assert "enable" in rendered
    # Byte-identical to Create, which is what keeps the physical resource id the
    # same: a different id makes the update a replacement, and a replacement can
    # run `disable` on the old resource after `enable` on the new one.
    assert json.dumps(properties["Create"]) == rendered


def test_breakglass_role_requires_mfa(foundation: assertions.Template) -> None:
    roles = {
        r["Properties"]["RoleName"]: r["Properties"]
        for r in _resources(foundation, "AWS::IAM::Role")
        if "RoleName" in r["Properties"]
    }
    breakglass = roles["meridian-shared-iam-breakglass"]
    statement = breakglass["AssumeRolePolicyDocument"]["Statement"][0]
    assert statement["Condition"]["Bool"]["aws:MultiFactorAuthPresent"] == "true"
    assert breakglass["MaxSessionDuration"] == 3600


def test_no_branch_trusted_deploy_role_exists(foundation: assertions.Template) -> None:
    """Codex CX-INF-02 follow-up (2026-09-17): the per-environment
    `meridian-<env>-iam-ci-deploy` roles trusted a branch and could assume every
    `cdk-*` bootstrap role — the exact reach the environment-bound deploy role was
    narrowed to remove. No role may trust a `ref:` subject, and no statement may
    grant `sts:AssumeRole` on a `cdk-*` wildcard."""
    roles = _resources(foundation, "AWS::IAM::Role")
    names = {r["Properties"].get("RoleName") for r in roles}
    assert not {n for n in names if n and n.endswith("-iam-ci-deploy")}
    for role in roles:
        for statement in role["Properties"]["AssumeRolePolicyDocument"]["Statement"]:
            for values in statement.get("Condition", {}).values():
                subjects = values.get("token.actions.githubusercontent.com:sub")
                if subjects is None:
                    continue
                for subject in [subjects] if isinstance(subjects, str) else subjects:
                    assert ":ref:" not in subject or role["Properties"]["RoleName"].endswith(
                        "-github-diff"
                    ), subject
    for policy in _resources(foundation, "AWS::IAM::Policy"):
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]:
            if statement.get("Action") == "sts:AssumeRole":
                assert "cdk-*" not in str(statement["Resource"])


def test_budgets_cover_both_environments_and_the_account(
    foundation: assertions.Template,
) -> None:
    budgets = {
        r["Properties"]["Budget"]["BudgetName"]: r["Properties"]
        for r in _resources(foundation, "AWS::Budgets::Budget")
    }
    assert set(budgets) == {
        "meridian-staging-budgets-monthly",
        "meridian-production-budgets-monthly",
        "meridian-shared-budgets-account",
    }
    limits = {name: props["Budget"]["BudgetLimit"]["Amount"] for name, props in budgets.items()}
    assert limits["meridian-staging-budgets-monthly"] == 75
    assert limits["meridian-production-budgets-monthly"] == 250
    assert limits["meridian-shared-budgets-account"] == 300
    # Per-environment budgets filter on the Environment cost-allocation tag,
    # which is why the tag Aspect is not optional.
    staging_filter = budgets["meridian-staging-budgets-monthly"]["Budget"]["CostFilters"]
    assert staging_filter == {"TagKeyValue": ["user:Environment$staging"]}
    for props in budgets.values():
        assert len(props["NotificationsWithSubscribers"]) == 2


def test_the_budget_filter_key_is_the_tag_key_the_aspect_applies(
    foundation: assertions.Template,
) -> None:
    """`user:Environment$staging` only matches if `Environment` is the tag written.

    Two independent strings have to agree for a per-environment budget to see any
    spend at all: the tag key `RequiredTagsAspect` enforces on every resource, and
    the key inside the budget's `TagKeyValue` filter. Rename one and the budget
    silently reports $0.00 for ever — there is no error, because a cost filter
    that matches nothing is a valid cost filter. This is the test that turns that
    into a failure.

    (It does not, and cannot, assert the *other* precondition: the tag must also
    be activated once as a cost-allocation tag in Billing. That is a manual
    account-level step with a 24-hour lag — `infra/README.md`, "Pre-deploy
    checks".)
    """
    assert TAG_KEY_ENVIRONMENT in REQUIRED_TAG_KEYS

    for name, props in {
        r["Properties"]["Budget"]["BudgetName"]: r["Properties"]
        for r in _resources(foundation, "AWS::Budgets::Budget")
    }.items():
        cost_filters = props["Budget"].get("CostFilters")
        if cost_filters is None:
            assert name == "meridian-shared-budgets-account"
            continue
        for value in cost_filters["TagKeyValue"]:
            key = value.removeprefix("user:").split("$", 1)[0]
            assert key == TAG_KEY_ENVIRONMENT
            assert key in REQUIRED_TAG_KEYS


def _monitors(template: assertions.Template) -> dict[str, Any]:
    return {
        body["Properties"]["MonitorName"]: body["Properties"]
        for body in template.find_resources("AWS::CE::AnomalyMonitor").values()
    }


def _foundation_with(**context: object) -> assertions.Template:
    """The foundation stack synthesized with extra context values."""
    return assertions.Template.from_json(
        synth_with("staging", **context).get_stack_by_name("meridian-shared-foundation").template
    )


def test_two_custom_anomaly_monitors_one_per_environment(
    foundation: assertions.Template,
) -> None:
    """H-3. A budget is a total against a line and speaks at month end; an anomaly
    monitor learns a daily shape and speaks on day three. The two are not substitutes.

    Two `CUSTOM` monitors, not one: a per-environment baseline is the useful one
    (staging is spiky by design, production is not, and one combined monitor learns
    neither). `CUSTOM` monitors have no per-account limit, so these two are always
    created — unlike the `SERVICE` one below.
    """
    monitors = _monitors(foundation)
    assert set(monitors) == {
        "meridian-staging-ce-anomaly-monitor",
        "meridian-production-ce-anomaly-monitor",
    }

    for env_name in ("staging", "production"):
        props = monitors[f"meridian-{env_name}-ce-anomaly-monitor"]
        assert props["MonitorType"] == "CUSTOM"
        specification = json.loads(props["MonitorSpecification"])
        # The same cost-allocation tag the budgets filter on, and the same manual
        # activation precondition — see `_budgets`.
        assert specification["Tags"]["Key"] == TAG_KEY_ENVIRONMENT
        assert specification["Tags"]["Values"] == [env_name]


def test_the_service_anomaly_monitor_is_off_by_default_because_the_account_has_one(
    foundation: assertions.Template,
) -> None:
    """**H-G, and it would have rolled the whole foundation stack back.**

    AWS allows exactly ONE `DIMENSIONAL`/`SERVICE` anomaly monitor per account, and
    this one already has `Default-Services-Monitor` (`aws ce get-anomaly-monitors`).
    Creating a second fails with `ValidationException` part way through the changeset,
    which takes CloudTrail, the alarms and the budgets back with it. So
    `enableServiceAnomalyMonitor` is the one `enable*` flag in this stack that defaults
    to **false**.
    """
    assert all(props["MonitorType"] != "DIMENSIONAL" for props in _monitors(foundation).values())

    subscription = next(iter(foundation.find_resources("AWS::CE::AnomalySubscription").values()))[
        "Properties"
    ]
    assert len(subscription["MonitorArnList"]) == 2, "the two CUSTOM monitors only"


def test_an_existing_service_monitor_is_attached_by_arn_and_never_managed() -> None:
    """The subscription *references* the monitor AWS already created. An ARN in
    `MonitorArnList` is a reference, not ownership: no `AWS::CE::AnomalyMonitor` is
    added, so nothing here can update or delete the other owner's monitor.

    The ARN carries the account id, so it is context at deploy time and is never
    committed (ADR 0001) — hence the obviously fake one here.
    """
    # Assembled rather than written out: `test_no_account_id.py` rejects any
    # twelve-digit literal in `infra/`, which is the rule this ARN is an example of.
    arn = f"arn:aws:ce::{'0' * 12}:anomalymonitor/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    template = _foundation_with(existingServiceAnomalyMonitorArn=arn)

    assert set(_monitors(template)) == {
        "meridian-staging-ce-anomaly-monitor",
        "meridian-production-ce-anomaly-monitor",
    }, "the existing monitor is referenced, not re-created"

    subscription = next(iter(template.find_resources("AWS::CE::AnomalySubscription").values()))[
        "Properties"
    ]
    assert len(subscription["MonitorArnList"]) == 3
    assert arn in subscription["MonitorArnList"]


def test_the_service_monitor_is_created_when_the_account_has_none() -> None:
    """The other path: a fresh account, where `get-anomaly-monitors` comes back empty.
    It is unfiltered on purpose — it sees the other owner's spend too (ADR 0001), which
    is the point, because it is the only thing that notices an **untagged** resource or
    a service nobody meant to turn on. The tag-filtered pair are blind to exactly that.
    """
    template = _foundation_with(enableServiceAnomalyMonitor=True)

    monitors = _monitors(template)
    account_wide = monitors["meridian-shared-ce-anomaly-monitor"]
    assert account_wide["MonitorType"] == "DIMENSIONAL"
    assert account_wide["MonitorDimension"] == "SERVICE"
    assert "MonitorSpecification" not in account_wide  # unfiltered, on purpose

    subscription = next(iter(template.find_resources("AWS::CE::AnomalySubscription").values()))[
        "Properties"
    ]
    assert len(subscription["MonitorArnList"]) == 3


def test_creating_and_adopting_a_service_monitor_are_mutually_exclusive() -> None:
    """Both at once is the failure the flag exists to prevent, one step removed."""
    with pytest.raises(ValueError, match="one DIMENSIONAL/SERVICE anomaly"):
        _foundation_with(
            enableServiceAnomalyMonitor=True,
            existingServiceAnomalyMonitorArn=f"arn:aws:ce::{'0' * 12}:anomalymonitor/x",
        )


def test_the_anomaly_subscription_pages_security_alerts_immediately_at_twenty_dollars(
    foundation: assertions.Template,
) -> None:
    """Absolute dollars, not a percentage: on a ~$40/month account a percentage
    threshold fires on rounding. $20 is roughly half a month of a NAT gateway somebody
    forgot to destroy, which is the anomaly this is actually for."""
    subscriptions = list(foundation.find_resources("AWS::CE::AnomalySubscription").values())
    assert len(subscriptions) == 1
    props = subscriptions[0]["Properties"]

    assert props["SubscriptionName"] == "meridian-shared-ce-anomaly-alerts"
    assert props["Frequency"] == "IMMEDIATE"
    assert len(props["MonitorArnList"]) == 2  # both CUSTOM monitors; see H-G above

    assert props["Subscribers"] == [{"Type": "SNS", "Address": {"Ref": "SecurityAlertsF84E29CE"}}]

    threshold = json.loads(props["ThresholdExpression"])
    assert threshold["Dimensions"]["Key"] == "ANOMALY_TOTAL_IMPACT_ABSOLUTE"
    assert threshold["Dimensions"]["Values"] == [str(ANOMALY_THRESHOLD_USD)]
    assert ANOMALY_THRESHOLD_USD == 20


def test_cost_anomaly_detection_can_publish_to_the_alerts_topic(
    foundation: assertions.Template,
) -> None:
    """It publishes as `costalerts.amazonaws.com`, not as Budgets. Without the
    statement the subscription is created and then silently never delivers — and
    "silently never delivers" is the failure mode this whole control exists to avoid
    in the first place."""
    policies = json.dumps(list(foundation.find_resources("AWS::SNS::TopicPolicy").values()))
    assert "costalerts.amazonaws.com" in policies


def test_budgets_carry_the_six_tags_by_hand(foundation: assertions.Template) -> None:
    """`AWS::Budgets::Budget` has `ResourceTags`, not `Tags`.

    Which means `Tags.of(...)` never reaches it and the tag Aspect returns `None`
    rather than failing — the one resource in this stack where the six tags have
    to be written explicitly, and therefore the one where they can go missing
    without anything complaining.
    """
    for body in _resources(foundation, "AWS::Budgets::Budget"):
        tags = {t["Key"]: t["Value"] for t in body["Properties"]["ResourceTags"]}
        assert set(tags) == set(REQUIRED_TAG_KEYS)
        assert tags["Project"] == "meridian"
        assert tags["ManagedBy"] == "cdk"
        assert tags["DataClassification"] == "internal"

    names = {
        r["Properties"]["Budget"]["BudgetName"]: {
            t["Key"]: t["Value"] for t in r["Properties"]["ResourceTags"]
        }
        for r in _resources(foundation, "AWS::Budgets::Budget")
    }
    assert names["meridian-staging-budgets-monthly"]["Environment"] == "staging"
    assert names["meridian-production-budgets-monthly"]["Environment"] == "production"
    assert names["meridian-shared-budgets-account"]["Environment"] == "shared"


def test_the_conformance_pack_carries_the_six_tags(foundation: assertions.Template) -> None:
    """L7: the Aspect can read `AWS::Config::ConformancePack`, so it must pass."""
    pack = _resources(foundation, "AWS::Config::ConformancePack")[0]["Properties"]
    tags = {t["Key"]: t["Value"] for t in pack["Tags"]}
    assert set(tags) == set(REQUIRED_TAG_KEYS)
    assert tags["Environment"] == "shared"


def test_alert_email_is_a_deploy_time_parameter(foundation: assertions.Template) -> None:
    """It is a mailbox, so it is a parameter, not a literal in a tracked file."""
    assert "AlertEmail" in foundation.to_json()["Parameters"]


# ---------------------------------------------------------------------------
# meridian-shared-iam-github-deploy — the role `.github/workflows/deploy.yml`
# assumes. Phase 5a. Every one of these is a boundary: the two branches that may
# assume it, the one stack it may deploy, and the absence of any wildcard the
# module docstring has not accounted for.
# ---------------------------------------------------------------------------

#: The role, and the inline policy CDK writes for it, are found by logical id
#: rather than by name, because the policy's own name is generated.
GITHUB_DEPLOY_ROLE_NAME = "meridian-shared-iam-github-deploy"

#: The only statement in that role's policy allowed to say `Resource: "*"`, and
#: the reason it has to. `ecr:GetAuthorizationToken` takes no resource — IAM
#: rejects the statement if you give it one — and it grants nothing on its own:
#: every push is authorized separately against the two named repositories.
GITHUB_DEPLOY_ALLOWED_WILDCARD = {"ecr:GetAuthorizationToken"}


def _github_deploy_role(foundation: assertions.Template) -> tuple[str, dict[str, Any]]:
    """The role's logical id and properties."""
    found = [
        (logical_id, body["Properties"])
        for logical_id, body in foundation.find_resources("AWS::IAM::Role").items()
        if body["Properties"].get("RoleName") == GITHUB_DEPLOY_ROLE_NAME
    ]
    assert len(found) == 1, f"expected exactly one {GITHUB_DEPLOY_ROLE_NAME}, found {len(found)}"
    return found[0]


def _github_deploy_statements(foundation: assertions.Template) -> list[dict[str, Any]]:
    """Every statement in the inline policy attached to that role, and only that role."""
    logical_id, _ = _github_deploy_role(foundation)
    statements: list[dict[str, Any]] = []
    for body in foundation.find_resources("AWS::IAM::Policy").values():
        roles = json.dumps(body["Properties"].get("Roles", []))
        if logical_id in roles:
            statements.extend(body["Properties"]["PolicyDocument"]["Statement"])
    assert statements, "the github-deploy role has no inline policy"
    return statements


def test_the_github_deploy_role_trusts_one_environment_of_one_repository(
    foundation: assertions.Template,
) -> None:
    _, props = _github_deploy_role(foundation)
    statement = props["AssumeRolePolicyDocument"]["Statement"][0]
    assert statement["Action"] == "sts:AssumeRoleWithWebIdentity"
    condition = statement["Condition"]
    # StringEquals, not StringLike: both subjects are exact, and a wildcard
    # operator on a value with no wildcard in it only invites one later.
    assert set(condition) == {"StringEquals"}
    equals = condition["StringEquals"]
    assert equals["token.actions.githubusercontent.com:aud"] == "sts.amazonaws.com"
    # The environment subject, not a branch one: only a job that declares
    # `environment: staging` gets it, and the Environment's own branch policy
    # is what limits which branches may (CX-INF-02).
    assert equals["token.actions.githubusercontent.com:sub"] == [
        "repo:andressbj45/meridians:environment:staging",
    ]
    # A workflow token is good for an hour at most, and the role carries no
    # managed policy — everything it may do is in the inline policy below.
    assert props["MaxSessionDuration"] == 3600
    assert not props.get("ManagedPolicyArns")


def test_the_github_deploy_role_has_one_documented_wildcard_and_no_other(
    foundation: assertions.Template,
) -> None:
    """A fourth `Resource: "*"` is a new blast radius, and it fails here first."""
    offenders = []
    for statement in _github_deploy_statements(foundation):
        if "*" not in json.dumps(statement["Resource"]).replace("cdk-", ""):
            continue
        if statement["Resource"] != "*":
            continue
        actions = statement["Action"]
        actions = set(actions if isinstance(actions, list) else [actions])
        if actions != GITHUB_DEPLOY_ALLOWED_WILDCARD:
            offenders.append(statement)
    assert not offenders, (
        "undocumented Resource: '*' in meridian-shared-iam-github-deploy:\n"
        + json.dumps(offenders, indent=2)
    )


def test_the_github_deploy_roles_boundary_is_the_branch_and_exclusively(
    foundation: assertions.Template,
) -> None:
    """What the deploy boundary IS, now that round 3 withdrew what it is not.

    This test used to be `..._may_deploy_only_the_compute_stack`, and it asserted
    a true fact (`cloudformation:*` names one stack ARN) under a false heading.
    `cdk deploy` assumes `cdk-hnb659fds-deploy-role`, which `cdk bootstrap`
    created account-wide and which passes an `AdministratorAccess` execution
    role, so the direct CloudFormation grant is not the path a deploy takes and
    is not what keeps CI out of `data` and `auth` (P5AR3-03). Three things are
    true and are what this asserts:

    * the direct CloudFormation grant is one stack ARN and no other;
    * the subjects are two branches of one repository, exactly;
    * the bootstrap roles this role may assume are named, and there are three.

    The boundary that stops CI deploying `auth` is `--exclusively` in
    `.github/workflows/deploy.yml` plus those two branch subjects. The tracker
    row for a staging-only bootstrap qualifier with scoped
    `--cloudformation-execution-policies` is what would let this test say more.
    """
    cfn = [
        s
        for s in _github_deploy_statements(foundation)
        if "cloudformation:*" in json.dumps(s["Action"])
    ]
    assert len(cfn) == 1
    resource = json.dumps(cfn[0]["Resource"])
    assert "stack/meridian-staging-compute/*" in resource
    # No SECOND stack is named directly, and no `cloudformation:*` on `*`.
    assert "meridian-staging-auth" not in resource
    assert "meridian-staging-data" not in resource
    assert cfn[0]["Resource"] != "*"

    # Environment-restricted trust is half of the real boundary, so it is
    # asserted here as well as in its own test: this is the property the
    # docstring, the workflow comment, the runbook and the control matrix cite.
    _, props = _github_deploy_role(foundation)
    subjects = props["AssumeRolePolicyDocument"]["Statement"][0]["Condition"]["StringEquals"][
        "token.actions.githubusercontent.com:sub"
    ]
    assert subjects == ["repo:andressbj45/meridians:environment:staging"]

    # And the assumable set is named rather than `cdk-*`, which is what makes
    # widening it a reviewable diff rather than an invisible one.
    assume = [
        s
        for s in _github_deploy_statements(foundation)
        if s.get("Sid") == "AssumeTheThreeCdkBootstrapRoles"
    ]
    assert len(assume) == 1
    assumable = json.dumps(assume[0]["Resource"])
    for purpose in ("deploy", "file-publishing", "lookup"):
        assert f"role/cdk-hnb659fds-{purpose}-role-" in assumable
    assert "role/cdk-*" not in assumable


def test_the_github_deploy_role_pushes_only_the_two_meridian_repositories(
    foundation: assertions.Template,
) -> None:
    push = [
        s
        for s in _github_deploy_statements(foundation)
        if "ecr:PutImage" in json.dumps(s["Action"])
    ]
    assert len(push) == 1
    resource = json.dumps(push[0]["Resource"])
    assert "repository/meridian-staging-ecr-api" in resource
    assert "repository/meridian-staging-ecr-web" in resource
    assert '"*"' not in resource


def test_the_github_deploy_role_assumes_the_three_named_bootstrap_roles(
    foundation: assertions.Template,
) -> None:
    """`cdk deploy` runs almost entirely as the bootstrap roles, not as the caller.

    They are named by pattern with the account and region **tokens** — never a
    literal (ADR 0001) — and the pattern pins the qualifier and the `-role-`
    segment, which is narrower than the `cdk-*` the per-environment CI roles use.

    **Three, not four** (P5AR3-12). `image-publishing-role` stages CDK *asset*
    images into the bootstrap registry; this workflow builds both images with
    buildx and pushes them to `meridian-staging-ecr-api` / `-web` as the runner,
    under the `EcrPushTheTwoMeridianRepositories` statement. The fourth role was
    never used, and an unused assumable role is a grant with no purpose to weigh
    it against.
    """
    assume = [
        s
        for s in _github_deploy_statements(foundation)
        if s.get("Sid") == "AssumeTheThreeCdkBootstrapRoles"
    ]
    assert len(assume) == 1
    assert assume[0]["Action"] == "sts:AssumeRole"
    resource = json.dumps(assume[0]["Resource"])
    for purpose in ("deploy", "file-publishing", "lookup"):
        assert f"role/cdk-hnb659fds-{purpose}-role-" in resource
    assert "image-publishing" not in resource
    assert len(assume[0]["Resource"]) == 3
    assert '"Ref": "AWS::AccountId"' in resource
    assert '"Ref": "AWS::Region"' in resource
    assert "role/cdk-*" not in resource


def test_the_github_deploy_role_passes_only_the_three_compute_roles(
    foundation: assertions.Template,
) -> None:
    pass_role = [
        s
        for s in _github_deploy_statements(foundation)
        if "iam:PassRole" in json.dumps(s["Action"])
    ]
    assert len(pass_role) == 1
    resource = json.dumps(pass_role[0]["Resource"])
    for purpose in ("ecs-execution", "ecs-api-task", "ecs-web-task"):
        assert f"role/meridian-staging-iam-{purpose}" in resource
    assert '"*"' not in resource
    # PassRole without this condition hands the role to any service that will
    # take it; the task roles may only ever become ECS tasks.
    assert pass_role[0]["Condition"] == {
        "StringEquals": {"iam:PassedToService": "ecs-tasks.amazonaws.com"}
    }


def test_the_github_deploy_role_may_only_watch_the_two_services(
    foundation: assertions.Template,
) -> None:
    """`aws ecs wait services-stable` is a read, and it is scoped to one cluster."""
    watch = [
        s
        for s in _github_deploy_statements(foundation)
        if s.get("Sid") == "WaitForTheTwoServicesToStabilize"
    ]
    assert len(watch) == 1
    assert watch[0]["Action"] == "ecs:DescribeServices"
    resource = json.dumps(watch[0]["Resource"])
    assert "service/meridian-staging-ecs-main/meridian-staging-ecs-svc-api" in resource
    assert "service/meridian-staging-ecs-main/meridian-staging-ecs-svc-web" in resource
    assert '"*"' not in resource


def test_no_account_id_literal_reaches_the_github_deploy_policy(
    foundation: assertions.Template,
) -> None:
    """ADR 0001, asserted on the rendered template rather than on the source.

    `infra/tests/test_no_account_id.py` greps the Python; this greps what
    CloudFormation is actually handed, which is where a literal would do harm.
    """
    rendered = json.dumps(_github_deploy_statements(foundation))
    assert not re.search(r"(?<!\d)\d{12}(?!\d)", rendered)


# ---------------------------------------------------------------------------
# meridian-shared-iam-github-diff — the READ-ONLY role `cdk diff` in CI assumes.
# Phase 8. Every one of these asserts the same property from a different side:
# this identity can read Meridian's stacks and it cannot change anything. A
# future edit that widens it — one more bootstrap role, one more action, one
# `Resource: "*"` — fails here before it reaches an account.
# ---------------------------------------------------------------------------

GITHUB_DIFF_ROLE_NAME = "meridian-shared-iam-github-diff"

#: Every action the diff role is allowed to hold. Anything outside this set is a
#: write, or a read nobody argued for, and `test_the_diff_role_holds_no_write_action`
#: fails on it. Kept as a literal rather than derived from the source so that the
#: test states the intended permission set independently of the code under test.
GITHUB_DIFF_ALLOWED_ACTIONS = {
    "sts:AssumeRole",
    "cloudformation:DescribeStacks",
    "cloudformation:ListStackResources",
    "cloudformation:GetTemplate",
    "ssm:GetParameter",
}


def _github_diff_role(foundation: assertions.Template) -> tuple[str, dict[str, Any]]:
    found = [
        (logical_id, body["Properties"])
        for logical_id, body in foundation.find_resources("AWS::IAM::Role").items()
        if body["Properties"].get("RoleName") == GITHUB_DIFF_ROLE_NAME
    ]
    assert len(found) == 1, f"expected exactly one {GITHUB_DIFF_ROLE_NAME}, found {len(found)}"
    return found[0]


def _github_diff_statements(foundation: assertions.Template) -> list[dict[str, Any]]:
    logical_id, _ = _github_diff_role(foundation)
    statements: list[dict[str, Any]] = []
    for body in foundation.find_resources("AWS::IAM::Policy").values():
        if logical_id in json.dumps(body["Properties"].get("Roles", [])):
            statements.extend(body["Properties"]["PolicyDocument"]["Statement"])
    assert statements, "the github-diff role has no inline policy"
    return statements


def test_the_diff_role_trusts_the_two_branches_and_nothing_else(
    foundation: assertions.Template,
) -> None:
    """Two exact subjects of one repository, and no third.

    **`pull_request` is deliberately absent** (P8-03). It was here in round 1, on
    the reasoning that a diff is worth having before a merge. The problem is what
    the role reaches: `cdk diff` renders the diffed branch's own Python on the
    runner, and the `cdk-...-lookup-role` it may assume is `ReadOnlyAccess` over
    an account that will hold PHI -- CloudWatch Logs content, Cognito
    `ListUsers`, `rds:Describe*`, secret names and metadata, every non-CMK S3
    object. Trusting `pull_request` handed all of that to pre-review code.

    The subject list is now exactly the deploy role's, so every run is
    post-review, and a fork is excluded by the fact that it cannot push to these
    branches -- not by a workflow condition somebody could delete.
    """
    _, props = _github_diff_role(foundation)
    statement = props["AssumeRolePolicyDocument"]["Statement"][0]
    assert statement["Action"] == "sts:AssumeRoleWithWebIdentity"
    condition = statement["Condition"]
    # StringEquals only: no operator that could match a subject nobody listed.
    assert set(condition) == {"StringEquals"}
    equals = condition["StringEquals"]
    subjects = equals["token.actions.githubusercontent.com:sub"]
    assert equals["token.actions.githubusercontent.com:aud"] == "sts.amazonaws.com"
    assert subjects == [
        "repo:andressbj45/meridians:ref:refs/heads/aws-migration",
        "repo:andressbj45/meridians:ref:refs/heads/main",
    ]
    assert not any("pull_request" in subject for subject in subjects), (
        "the pull_request subject is withdrawn (P8-03); re-adding it needs a new ADR"
    )
    assert props["MaxSessionDuration"] == 3600
    assert not props.get("ManagedPolicyArns")


def test_the_diff_role_may_assume_only_the_lookup_bootstrap_role(
    foundation: assertions.Template,
) -> None:
    """The one line between "can read the account" and "can deploy to it".

    `cdk bootstrap` creates `lookup-role` with `ReadOnlyAccess` and a deny on
    `kms:Decrypt`. `deploy-role` passes an `AdministratorAccess` execution role.
    A diff job needs the first and must never reach the second, so the resource
    is the full lookup-role ARN pattern — not `cdk-*`, which would include it.
    """
    assumes = [s for s in _github_diff_statements(foundation) if s["Action"] == "sts:AssumeRole"]
    assert len(assumes) == 1
    resource = json.dumps(assumes[0]["Resource"])
    assert "cdk-hnb659fds-lookup-role-" in resource
    for forbidden in ("deploy-role", "cfn-exec-role", "file-publishing-role", "cdk-*"):
        assert forbidden not in resource


def test_the_diff_role_reads_only_meridian_stacks(foundation: assertions.Template) -> None:
    read = [
        s
        for s in _github_diff_statements(foundation)
        if s.get("Sid") == "ReadMeridianStackTemplates"
    ]
    assert len(read) == 1
    assert set(read[0]["Action"]) == {
        "cloudformation:DescribeStacks",
        "cloudformation:ListStackResources",
        "cloudformation:GetTemplate",
    }
    resource = json.dumps(read[0]["Resource"])
    assert "stack/meridian-*/*" in resource
    assert '"*"' not in resource


def test_the_diff_role_has_no_wildcard_resource(foundation: assertions.Template) -> None:
    """Unlike the deploy role, this one has no documented exception and never needs one."""
    offenders = [s for s in _github_diff_statements(foundation) if s["Resource"] == "*"]
    assert not offenders, "Resource: '*' in meridian-shared-iam-github-diff:\n" + json.dumps(
        offenders, indent=2
    )


def test_the_diff_role_holds_no_write_action(foundation: assertions.Template) -> None:
    """Read-only, asserted as a property of the rendered policy.

    Two checks, because either alone can be fooled: every action is on the
    allowlist above, and no action is one of the verbs that change something.
    """
    actions: set[str] = set()
    for statement in _github_diff_statements(foundation):
        action = statement["Action"]
        actions.update(action if isinstance(action, list) else [action])
    assert actions <= GITHUB_DIFF_ALLOWED_ACTIONS, (
        f"unexpected action(s) on the diff role: {sorted(actions - GITHUB_DIFF_ALLOWED_ACTIONS)}"
    )
    write_verbs = (
        "Create",
        "Delete",
        "Update",
        "Put",
        "Execute",
        "Set",
        "Modify",
        "Attach",
        "PassRole",
        ":*",
    )
    for candidate in sorted(actions):
        # `sts:AssumeRole` is the one action that is a verb without being a write:
        # it mints a session on a role whose own policy is ReadOnlyAccess.
        assert not any(verb in candidate for verb in write_verbs), candidate


def test_no_account_id_literal_reaches_the_github_diff_policy(
    foundation: assertions.Template,
) -> None:
    rendered = json.dumps(_github_diff_statements(foundation))
    assert not re.search(r"(?<!\d)\d{12}(?!\d)", rendered)


def test_the_config_recorder_is_created_stopped_and_started_after_its_channel(
    foundation: assertions.Template,
) -> None:
    """AWS Config needs the recorder before it accepts a delivery channel, and the
    CloudFormation handler waits for a channel when told to start on create — a
    deadlock that rolled back the first deploy (2026-10-02)."""
    recorder_id, recorder = next(
        iter(foundation.find_resources("AWS::Config::ConfigurationRecorder").items())
    )
    assert recorder["Properties"]["StartedOnCreate"] is False

    channel_id, channel = next(
        iter(foundation.find_resources("AWS::Config::DeliveryChannel").items())
    )
    assert recorder_id in channel["DependsOn"]

    starts = foundation.find_resources("Custom::ConfigRecorderStart")
    assert len(starts) == 1
    start_id, start = next(iter(starts.items()))
    assert channel_id in start["DependsOn"]

    pack = next(iter(foundation.find_resources("AWS::Config::ConformancePack").values()))
    assert start_id in pack["DependsOn"]

    # Deleted before the channel, so it must stop the recorder or the channel
    # delete fails with LastDeliveryChannelDeleteFailedException.
    assert "stopConfigurationRecorder" in json.dumps(start["Properties"]["Delete"])


def test_the_cloudtrail_logs_role_can_write_its_log_streams(
    foundation: assertions.Template,
) -> None:
    """`Fn::GetAtt LogGroup.Arn` ends in `:*`; suffixing it with `:log-stream:*`
    matches nothing and CloudTrail refuses the trail with AccessDenied."""
    policies = foundation.find_resources("AWS::IAM::Policy")
    statement = next(
        body["Properties"]["PolicyDocument"]["Statement"][0]
        for logical_id, body in policies.items()
        if logical_id.startswith("TrailToLogsRole")
    )
    rendered = json.dumps(statement["Resource"])
    assert "GetAtt" not in rendered
    assert ":log-group:" in rendered and ":log-stream:*" in rendered
