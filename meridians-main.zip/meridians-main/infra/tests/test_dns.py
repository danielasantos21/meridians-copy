"""`meridian-shared-dns`: the zone is a faithful copy, and SES signs from a subdomain.

The point of these tests is not that the CDK works. It is that the record set
is *complete and unchanged*. The nameserver switch replaces GoDaddy's answers
with Route 53's in one step; a record missing from `dns.py` goes dark at that
moment, and the most expensive one to lose is the company's inbound mail.

So the assertions here are deliberately literal — the exact MX hosts, the exact
SPF string — and they will fail loudly if someone edits the stack. Failing is
the right behaviour: a change to any of these belongs in
`docs/architecture/dns.md` and the runbook first.

The completeness check is **not** a count. It is a comparison against
`infra/dns/meridiansgrp.com.zone.json`, a `dig` export of the live GoDaddy zone:
every entry in that file must exist in the synthesized template with the same
type, TTL and values. A count test passed happily for months while nine live
records — seven Microsoft 365 / GoDaddy CNAMEs and two Skype SRV records — were
missing from the stack entirely.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

import pytest
from aws_cdk import assertions, cx_api

from meridian.stacks.dns import (
    APEX_SPF,
    DMARC_POLICY,
    EXISTING_CNAMES,
    EXISTING_SRV,
    MICROSOFT_TENANT_TXT,
    PROOFPOINT_MX,
    RENDER_APEX_IP,
    RENDER_WWW_HOST,
    RESEND_DKIM_NAME,
    RESEND_DKIM_PUBLIC_KEY,
    RESEND_RETURN_PATH,
    RESEND_RETURN_PATH_MX,
    RESEND_RETURN_PATH_SPF,
)

DOMAIN = "meridiansgrp.com"

#: The checked-in `dig` export of the live GoDaddy zone. This file, not a number
#: in this module, is the definition of "complete".
ZONE_EXPORT = Path(__file__).resolve().parents[1] / "dns" / f"{DOMAIN}.zone.json"

#: The five records SES writes into the zone itself and which therefore have no
#: GoDaddy counterpart: three Easy DKIM CNAMEs, the MAIL FROM MX, the MAIL FROM
#: SPF TXT.
SES_OWN_RECORD_SETS = 5


def _zone_export() -> list[dict[str, Any]]:
    return list(json.loads(ZONE_EXPORT.read_text())["records"])


def _copied_records() -> list[dict[str, Any]]:
    """The export entries this stack copies verbatim.

    Two flags mark the ones it does not: `ses_interim` (GoDaddy's hand-added copies of
    the five records SES writes into Route 53 itself, runbook §3e) and
    `self_delegation` (the `staging-*` NS records that point GoDaddy at this same zone;
    inside the zone they would delegate the name back to itself).
    """
    return [
        record
        for record in _zone_export()
        if not record.get("ses_interim") and not record.get("self_delegation")
    ]


def _normalize(value: str) -> str:
    """Drop the trailing dot `dig` prints and CloudFormation does not."""
    return value[:-1] if value.endswith(".") else value


def _records(dns: assertions.Template) -> Mapping[str, Mapping[str, Any]]:
    return dns.find_resources("AWS::Route53::RecordSet")


def _by_name_and_type(dns: assertions.Template, name: str, type_: str) -> Mapping[str, Any]:
    matches = [
        body["Properties"]
        for body in _records(dns).values()
        if body["Properties"].get("Name") == name and body["Properties"].get("Type") == type_
    ]
    assert len(matches) == 1, f"expected exactly one {type_} at {name}, got {len(matches)}"
    return matches[0]


# ------------------------------------------------------------------- the zone


def test_one_public_hosted_zone_for_the_domain(dns: assertions.Template) -> None:
    dns.resource_count_is("AWS::Route53::HostedZone", 1)
    dns.has_resource_properties("AWS::Route53::HostedZone", {"Name": f"{DOMAIN}."})


def test_the_zone_is_retained_so_cdk_destroy_cannot_take_mail_down(
    dns: assertions.Template,
) -> None:
    zone = next(iter(dns.find_resources("AWS::Route53::HostedZone").values()))
    assert zone["DeletionPolicy"] == "Retain"


@pytest.mark.parametrize(
    "expected", _copied_records(), ids=lambda record: f"{record['type']}:{record['name']}"
)
def test_every_record_godaddy_serves_today_is_in_the_zone(
    expected: dict[str, Any], dns: assertions.Template
) -> None:
    """The real completeness check: the checked-in `dig` export, entry by entry.

    A count is not enough — it passes just as happily when one record is dropped
    and another added. This compares name, type, TTL and values against
    `infra/dns/meridiansgrp.com.zone.json`, which is what GoDaddy actually
    answers. Anything in that file and not in the synthesized template goes dark
    at the nameserver switch.
    """
    props = _by_name_and_type(dns, expected["name"], expected["type"])

    assert int(props["TTL"]) == expected["ttl"], (
        f"{expected['type']} {expected['name']}: TTL {props['TTL']}, export says {expected['ttl']}"
    )
    assert sorted(_normalize(value) for value in props["ResourceRecords"]) == sorted(
        _normalize(value) for value in expected["values"]
    )


def test_the_zone_holds_nothing_the_export_does_not_explain(dns: assertions.Template) -> None:
    """An *extra* record is as much a surprise as a missing one.

    Everything in the zone is either in the export (GoDaddy serves it today) or
    one of the five SES writes into the zone. There is no third category, and a
    record that appears without one of those two reasons is drift.
    """
    assert len(_records(dns)) == len(_copied_records()) + SES_OWN_RECORD_SETS


def test_the_export_and_the_stack_constants_do_not_drift_apart(
    dns: assertions.Template,
) -> None:
    """The export covers every constant the stack defines, and vice versa.

    Both halves matter. Adding a CNAME to `EXISTING_CNAMES` without exporting it
    means the export stops being the source of truth; exporting one without
    adding it fails the parametrized test above.
    """
    exported = {(record["name"], record["type"]) for record in _copied_records()}
    for record_name, _ in EXISTING_CNAMES:
        assert (f"{record_name}.{DOMAIN}.", "CNAME") in exported
    for record_name, *_ in EXISTING_SRV:
        assert (f"{record_name}.{DOMAIN}.", "SRV") in exported


def test_inbound_mail_still_points_at_proofpoint(dns: assertions.Template) -> None:
    mx = _by_name_and_type(dns, f"{DOMAIN}.", "MX")
    assert mx["ResourceRecords"] == [f"0 {host}" for host in PROOFPOINT_MX]


def test_apex_txt_carries_spf_and_the_microsoft_tenant_in_one_record(
    dns: assertions.Template,
) -> None:
    """DNS permits one TXT record set per name; both values live in it."""
    txt = _by_name_and_type(dns, f"{DOMAIN}.", "TXT")
    assert txt["ResourceRecords"] == [f'"{APEX_SPF}"', f'"{MICROSOFT_TENANT_TXT}"']


def test_no_ses_include_on_the_apex_spf(dns: assertions.Template) -> None:
    """SES's SPF belongs to the MAIL FROM subdomain, not the bare domain.

    `include:amazonses.com` at the apex would spend one of SPF's ten permitted
    DNS lookups for nothing and widen who may send as `meridiansgrp.com`.
    """
    txt = _by_name_and_type(dns, f"{DOMAIN}.", "TXT")
    assert "amazonses" not in json.dumps(txt["ResourceRecords"])


def test_dmarc_keeps_relaxed_alignment(dns: assertions.Template) -> None:
    """`adkim=r`/`aspf=r` is what lets `mail.` align with the bare domain."""
    txt = _by_name_and_type(dns, f"_dmarc.{DOMAIN}.", "TXT")
    assert txt["ResourceRecords"] == [f'"{DMARC_POLICY}"']
    assert "adkim=r" in DMARC_POLICY and "aspf=r" in DMARC_POLICY


def test_render_records_are_copied_exactly_and_have_a_cutover_ttl(
    dns: assertions.Template,
) -> None:
    apex = _by_name_and_type(dns, f"{DOMAIN}.", "A")
    assert apex["ResourceRecords"] == [RENDER_APEX_IP]
    assert apex["TTL"] == "300"

    www = _by_name_and_type(dns, f"www.{DOMAIN}.", "CNAME")
    assert www["ResourceRecords"] == [RENDER_WWW_HOST]
    assert www["TTL"] == "300"


def test_the_microsoft_365_cnames_are_copied(dns: assertions.Template) -> None:
    """`autodiscover` and the two DKIM selectors are the expensive ones to lose.

    Losing `autodiscover` breaks every Outlook profile in the company at once.
    Losing a `selector*._domainkey` breaks outbound DKIM for Microsoft 365, which
    presents as "our mail started going to spam" rather than as a DNS fault, so
    it can run for days before anyone connects it to the switch.
    """
    for record_name, target in EXISTING_CNAMES:
        cname = _by_name_and_type(dns, f"{record_name}.{DOMAIN}.", "CNAME")
        assert cname["ResourceRecords"] == [target]
        assert cname["TTL"] == "3600"


def test_the_other_owners_application_hostname_is_carried_unchanged(
    dns: assertions.Template,
) -> None:
    """`ai.meridiansgrp.com` is **not Meridian's**.

    It is the other account owner's production application (ADR 0001), a CNAME to
    their own CloudFront distribution. It is in this zone for exactly one reason: the
    nameserver switch must not take somebody else's product down. Removing it, or
    "tidying" it because it is not ours, is an outage we cause in a product we do not
    own — and one nobody here would think to check.

    It was not in the first `dig` export. The candidate-name sweep in
    `docs/runbooks/dns-nameserver-switch.md` §3a found it, which is that sweep's whole
    justification.
    """
    record = _by_name_and_type(dns, f"ai.{DOMAIN}.", "CNAME")
    assert [_normalize(v) for v in record["ResourceRecords"]] == ["d159v1qnwsd8mk.cloudfront.net"]
    assert int(record["TTL"]) == 3600
    assert "NOT MERIDIAN" in record["Comment"]
    assert ("ai", "d159v1qnwsd8mk.cloudfront.net") in EXISTING_CNAMES


def test_godaddys_domain_connect_record_is_carried_too(dns: assertions.Template) -> None:
    """Inert the moment GoDaddy stops being authoritative, and copied anyway.

    Deciding which live records "do not matter" is how records go dark, and the cost
    of being wrong is asymmetric: carrying a useless CNAME costs nothing, dropping a
    load-bearing one costs an outage nobody diagnoses as DNS.
    """
    record = _by_name_and_type(dns, f"_domainconnect.{DOMAIN}.", "CNAME")
    assert [_normalize(v) for v in record["ResourceRecords"]] == [
        "_domainconnect.gd.domaincontrol.com"
    ]


def test_the_export_carries_thirty_one_record_sets(dns: assertions.Template) -> None:
    """Not a completeness check — that is the parametrized test above, against the
    export file. This is a *change* check: the count moved 14 → 16 when the sweep found
    `ai` and `_domainconnect`, and 16 → 31 with GoDaddy's 2026-10-12 zone-file export
    (7 records the stack now copies, 5 SES interim copies, 3 self-delegations). A
    silent move in either direction is worth a failing build."""
    assert len(_zone_export()) == 31
    assert len(_copied_records()) == 23
    assert sum(1 for record in _zone_export() if record.get("ses_interim")) == 5
    assert sum(1 for record in _zone_export() if record.get("self_delegation")) == 3
    assert len(EXISTING_CNAMES) == 13
    assert len(EXISTING_SRV) == 2


# ----------------------------------------- the 2026-10-12 zone-file export's seven


@pytest.mark.parametrize(
    ("record_name", "target"),
    [
        ("origin.ai", "meridian-alb-1064237917.us-east-1.elb.amazonaws.com"),
        (
            "_3a76167a4347ecb50f0bea492dd6aa2f.ai",
            "_b9610c27c74ff69ce86addc7198b7f5d.jkddzztszm.acm-validations.aws",
        ),
        (
            "_ca552b8e33c5217aaad223574627efd0.origin.ai",
            "_9ae19446168f1d5e485a014dbb89c097.jkddzztszm.acm-validations.aws",
        ),
    ],
)
def test_the_other_owners_origin_and_certificate_validations_are_carried_unchanged(
    record_name: str, target: str, dns: assertions.Template
) -> None:
    """Three more of the other owner's records (ADR 0001), found by the 2026-10-12 export.

    `origin.ai` dark is an outage in their product on day one. A validation CNAME dark
    is quieter and later: their ACM certificate fails to auto-renew months after the
    switch, and nobody connects it to DNS. Same rule as `ai`: copied, never touched.
    """
    record = _by_name_and_type(dns, f"{record_name}.{DOMAIN}.", "CNAME")
    assert record["ResourceRecords"] == [target]
    assert record["TTL"] == "3600"
    assert "NOT MERIDIAN" in record["Comment"]


def test_godaddy_pay_links_are_carried(dns: assertions.Template) -> None:
    record = _by_name_and_type(dns, f"pay.{DOMAIN}.", "CNAME")
    assert record["ResourceRecords"] == ["paylinks.commerce.godaddy.com"]
    assert record["TTL"] == "3600"


def test_resend_return_path_mx_and_spf(dns: assertions.Template) -> None:
    """Resend is the production app's mail transport today (T:41). Its bounce domain
    needs both records: the MX for bounces, the SPF so every message passes SPF."""
    assert RESEND_RETURN_PATH == "send.updates"
    mx = _by_name_and_type(dns, f"send.updates.{DOMAIN}.", "MX")
    assert mx["ResourceRecords"] == ["10 feedback-smtp.us-east-1.amazonses.com"]
    assert RESEND_RETURN_PATH_MX == "feedback-smtp.us-east-1.amazonses.com"
    assert mx["TTL"] == "3600"
    txt = _by_name_and_type(dns, f"send.updates.{DOMAIN}.", "TXT")
    assert txt["ResourceRecords"] == ['"v=spf1 include:amazonses.com ~all"']
    assert RESEND_RETURN_PATH_SPF == "v=spf1 include:amazonses.com ~all"
    assert txt["TTL"] == "3600"


def test_resend_dkim_key_is_the_exported_one_in_valid_txt_strings(
    dns: assertions.Template,
) -> None:
    """The DKIM key, exactly as GoDaddy serves it, in strings Route 53 accepts.

    Route 53 rejects a TXT character-string over 255 characters. The key is 218, so it
    is one string; were it longer, it must be split into several quoted strings inside
    ONE value (`"part1" "part2"`), never into two values. Asserting the split rather
    than the length keeps this test right if the key is ever rotated to a longer one.
    """
    assert RESEND_DKIM_NAME == "resend._domainkey.updates"
    record = _by_name_and_type(dns, f"resend._domainkey.updates.{DOMAIN}.", "TXT")
    assert record["TTL"] == "3600"
    assert len(record["ResourceRecords"]) == 1
    value = record["ResourceRecords"][0]
    assert value.startswith('"') and value.endswith('"')
    strings = value[1:-1].split('" "')
    assert all(len(part) <= 255 for part in strings)
    assert "".join(strings) == RESEND_DKIM_PUBLIC_KEY

    exported = next(
        r for r in _zone_export() if r["name"] == f"resend._domainkey.updates.{DOMAIN}."
    )
    assert exported["values"] == [f'"{RESEND_DKIM_PUBLIC_KEY}"']


def test_the_self_delegations_are_not_copied_into_the_zone(dns: assertions.Template) -> None:
    """GoDaddy delegates `staging-app`, `staging-api` and `origin-staging` to this zone.

    Inside the zone an NS record at those names would delegate them back to the zone
    itself and break staging. Route 53 answers them directly, so the stack holds no NS
    record below the apex at all.
    """
    flagged = [r for r in _zone_export() if r.get("self_delegation")]
    assert {r["name"] for r in flagged} == {
        f"staging-app.{DOMAIN}.",
        f"staging-api.{DOMAIN}.",
        f"origin-staging.{DOMAIN}.",
    }
    assert all(r["type"] == "NS" for r in flagged)
    assert not [body for body in _records(dns).values() if body["Properties"]["Type"] == "NS"]


def test_the_ses_interim_entries_match_what_the_stack_writes(dns: assertions.Template) -> None:
    """The five GoDaddy copies are duplicates of SES's own records, not new ones.

    The MAIL FROM pair has a literal name and is compared value for value. The three
    DKIM CNAMEs are named by SES at deploy time (`DkimDNSTokenName1..3`), so only their
    shape can be asserted here; `scripts/dns_zone_diff.py --route53` compares the real
    names after a deploy.
    """
    interim = [r for r in _zone_export() if r.get("ses_interim")]
    mail_from = [r for r in interim if r["name"] == f"mail.{DOMAIN}."]
    assert {r["type"] for r in mail_from} == {"MX", "TXT"}

    def _in_us_east_1(value: Any) -> str:
        # The MAIL FROM MX host is `Fn::Join` over `AWS::Region`; the account's SES
        # identity is in us-east-1, which is what GoDaddy's copy says.
        if isinstance(value, str):
            return _normalize(value)
        parts = value["Fn::Join"][1]
        return "".join("us-east-1" if part == {"Ref": "AWS::Region"} else part for part in parts)

    for record in mail_from:
        props = _by_name_and_type(dns, record["name"], record["type"])
        assert [_in_us_east_1(v) for v in props["ResourceRecords"]] == record["values"]
        assert int(props["TTL"]) == record["ttl"]
    dkim = [r for r in interim if r["type"] == "CNAME"]
    assert len(dkim) == 3
    for record in dkim:
        assert record["name"].endswith(f"._domainkey.{DOMAIN}.")
        assert record["values"][0].endswith(".dkim.amazonses.com")


def test_record_comments_are_ascii(dns: assertions.Template) -> None:
    """The deployed copy of this template shows each em dash as `?`, so a non-ASCII
    record comment differs from the live template on every deploy. Every record stays
    ASCII except the pre-existing apex TXT comment, the one known exception."""
    for logical_id, body in _records(dns).items():
        if logical_id.startswith("ApexTxt"):
            continue
        comment = body["Properties"].get("Comment", "")
        assert comment.isascii(), f"{logical_id}: {comment!r}"


def test_the_skype_srv_records_keep_their_priority_weight_and_port(
    dns: assertions.Template,
) -> None:
    """SRV is positional: `100 1 5061 host`. Swap two numbers and it fails silently."""
    for record_name, priority, weight, port, target in EXISTING_SRV:
        srv = _by_name_and_type(dns, f"{record_name}.{DOMAIN}.", "SRV")
        assert srv["ResourceRecords"] == [f"{priority} {weight} {port} {target}"]


def test_microsoft_dkim_selectors_do_not_collide_with_ses_easy_dkim(
    dns: assertions.Template,
) -> None:
    """Two DKIM systems sign for this domain; they must use different selectors.

    Microsoft uses `selector1`/`selector2._domainkey`. SES Easy DKIM uses three
    token names of its own. If they ever collided, CloudFormation would fail on a
    duplicate record set — but it is cheaper to assert it than to find out.
    """
    microsoft = {f"{name}.{DOMAIN}." for name, _ in EXISTING_CNAMES}
    ses = {
        json.dumps(body["Properties"]["Name"])
        for body in _records(dns).values()
        if "DkimDNSTokenName" in json.dumps(body["Properties"].get("Name"))
    }
    assert not microsoft & ses


# -------------------------------------------------------------------- the ses


def test_dkim_cnames_are_written_into_the_zone(dns: assertions.Template) -> None:
    """Three Easy DKIM CNAMEs, produced by the identity rather than typed."""
    cnames = [
        body["Properties"]
        for body in _records(dns).values()
        if body["Properties"].get("Type") == "CNAME"
        and "DkimDNSTokenName" in json.dumps(body["Properties"].get("Name"))
    ]
    assert len(cnames) == 3


def test_mail_from_mx_and_spf_exist_on_the_subdomain(dns: assertions.Template) -> None:
    mx = _by_name_and_type(dns, f"mail.{DOMAIN}.", "MX")
    assert "feedback-smtp" in json.dumps(mx["ResourceRecords"])
    assert "amazonses.com" in json.dumps(mx["ResourceRecords"])

    txt = _by_name_and_type(dns, f"mail.{DOMAIN}.", "TXT")
    assert txt["ResourceRecords"] == ['"v=spf1 include:amazonses.com ~all"']


def test_email_identity_uses_2048_bit_easy_dkim_and_the_custom_mail_from(
    dns: assertions.Template,
) -> None:
    dns.has_resource_properties(
        "AWS::SES::EmailIdentity",
        {
            "EmailIdentity": DOMAIN,
            "DkimAttributes": {"SigningEnabled": True},
            "DkimSigningAttributes": {"NextSigningKeyLength": "RSA_2048_BIT"},
            "MailFromAttributes": {
                "MailFromDomain": f"mail.{DOMAIN}",
                # A missing MX must degrade to `amazonses.com`, not stop every
                # password reset in the product.
                "BehaviorOnMxFailure": "USE_DEFAULT_VALUE",
            },
        },
    )


def test_configuration_set_requires_tls_and_publishes_reputation_metrics(
    dns: assertions.Template,
) -> None:
    dns.has_resource_properties(
        "AWS::SES::ConfigurationSet",
        {
            "Name": "meridian-shared-ses-default",
            "DeliveryOptions": {"TlsPolicy": "REQUIRE"},
            "ReputationOptions": {"ReputationMetricsEnabled": True},
        },
    )


def test_bounces_complaints_rejects_and_rendering_failures_go_to_their_own_sns_topic(
    dns: assertions.Template,
) -> None:
    dns.has_resource_properties(
        "AWS::SNS::Topic", {"TopicName": "meridian-shared-sns-email-events"}
    )
    destination = next(
        iter(dns.find_resources("AWS::SES::ConfigurationSetEventDestination").values())
    )
    event_destination = destination["Properties"]["EventDestination"]
    # Named like everything else. In an account shared with another owner
    # (ADR 0001), a resource called `sns-delivery-events` is one nobody can
    # attribute from the console.
    assert event_destination["Name"] == "meridian-shared-ses-events"
    assert event_destination["Enabled"] is True
    # `renderingFailure` (Phase 7) is the one failure with no bounce and no
    # delivery: the message is never built. Without it in this list, a broken
    # template in production is indistinguishable from mail nobody has opened.
    assert sorted(event_destination["MatchingEventTypes"]) == [
        "bounce",
        "complaint",
        "reject",
        "renderingFailure",
    ]
    assert "SnsDestination" in event_destination


def test_only_ses_in_this_account_may_publish_to_the_email_events_topic(
    dns: assertions.Template,
) -> None:
    """`ses.amazonaws.com` plus `aws:SourceAccount` — the confused-deputy pair.

    The service principal alone would let SES in ANY AWS account publish to this
    topic, because `ses.amazonaws.com` is the same principal for everybody. The
    `aws:SourceAccount` condition is what makes it ours.
    """
    policy = next(iter(dns.find_resources("AWS::SNS::TopicPolicy").values()))
    statements = policy["Properties"]["PolicyDocument"]["Statement"]
    ses_statements = [
        statement
        for statement in statements
        if statement.get("Principal", {}).get("Service") == "ses.amazonaws.com"
    ]
    # Two: the one written by hand in `dns.py` and the one CDK adds for the
    # event destination (which also pins `aws:SourceArn`). Neither may be
    # unconditional, so the assertion is over all of them.
    assert ses_statements
    for statement in ses_statements:
        assert statement["Action"] == "sns:Publish"
        assert statement["Effect"] == "Allow"
        # IAM condition keys are case-insensitive, and the two statements do not
        # agree on the spelling: ours says `aws:SourceAccount`, CDK's own says
        # `AWS:SourceAccount`. Both mean the same thing to IAM.
        conditions = {
            key.lower(): value for key, value in statement["Condition"]["StringEquals"].items()
        }
        assert conditions["aws:sourceaccount"] == {"Ref": "AWS::AccountId"}


def test_the_suppression_list_covers_bounces_and_complaints(dns: assertions.Template) -> None:
    """An address that hard-bounced is not mailed again until a human says so."""
    dns.has_resource_properties(
        "AWS::SES::ConfigurationSet",
        {"SuppressionOptions": {"SuppressedReasons": ["BOUNCE", "COMPLAINT"]}},
    )


def test_the_from_address_is_on_the_verified_domain(dns: assertions.Template) -> None:
    """One string, exported, and named by the api task role's IAM condition."""
    from meridian.stacks.dns import NO_REPLY_LOCAL_PART

    outputs = dns.find_outputs("*")
    assert outputs["SesNoReplyAddress"]["Value"] == f"{NO_REPLY_LOCAL_PART}@{DOMAIN}"


def test_the_email_events_topic_is_not_classified_public(dns: assertions.Template) -> None:
    """A bounce notification names a recipient. The zone is public; this is not."""
    topic = next(iter(dns.find_resources("AWS::SNS::Topic").values()))
    tags = {tag["Key"]: tag["Value"] for tag in topic["Properties"]["Tags"]}
    assert tags["DataClassification"] == "internal"


# ----------------------------------------------------------------- the outputs


def test_the_four_nameservers_are_outputs(dns: assertions.Template) -> None:
    """So that the GoDaddy switch is copy-and-paste from `cdk deploy`."""
    outputs = dns.find_outputs("*")
    for index in range(1, 5):
        assert f"NameServer{index}" in outputs


def test_ses_names_are_exported_for_phase_4_and_phase_7(dns: assertions.Template) -> None:
    outputs = dns.find_outputs("*")
    assert "SesIdentityName" in outputs
    assert "SesConfigurationSetName" in outputs


# -------------------------------------------------------------------- the tags


def test_the_hosted_zone_carries_the_six_tags(dns: assertions.Template) -> None:
    """`HostedZoneTags`, not `Tags` — which is why the generic sweep misses it."""
    zone = next(iter(dns.find_resources("AWS::Route53::HostedZone").values()))
    tags = {tag["Key"]: tag["Value"] for tag in zone["Properties"]["HostedZoneTags"]}
    assert tags == {
        "Project": "meridian",
        "Environment": "shared",
        "Owner": "meridian-platform",
        "DataClassification": "public",
        "CostCenter": "meridian",
        "ManagedBy": "cdk",
    }


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_the_dns_stack_is_identical_in_both_environments(
    env_name: str,
    staging: cx_api.CloudAssembly,
    production: cx_api.CloudAssembly,
) -> None:
    """It is account-level: there is one domain, not one per environment.

    Synthesizing it under both `-c env=` values and getting the same template is
    how we know nothing environment-specific leaked in — and it doubles as the
    credential-free synth check for this stack.
    """
    assembly = staging if env_name == "staging" else production
    template = assembly.get_stack_by_name("meridian-shared-dns").template
    reference = staging.get_stack_by_name("meridian-shared-dns").template
    assert template == reference


# ---------------------------------------------------------------------------
# The Phase 9 cutover flag (`renderRecords`)
# ---------------------------------------------------------------------------
def _record_names(template: assertions.Template) -> set[tuple[str, str]]:
    """Every record set as `(name, type)`.

    Some names are CloudFormation tokens rather than strings — SES Easy DKIM's
    three CNAMEs are `Fn::Join`s over the identity's generated selectors — so the
    name is JSON-encoded when it is not already text, which keeps it hashable and
    still compares equal between two synths of the same stack.
    """
    return {
        (
            body["Properties"]["Name"]
            if isinstance(body["Properties"]["Name"], str)
            else json.dumps(body["Properties"]["Name"], sort_keys=True),
            body["Properties"]["Type"],
        )
        for body in template.find_resources("AWS::Route53::RecordSet").values()
    }


def _dns_with(**context: object) -> assertions.Template:
    from conftest import synth_with

    return assertions.Template.from_json(
        synth_with("production", **context).get_stack_by_name("meridian-shared-dns").template
    )


def test_render_records_exist_by_default() -> None:
    """Default true: a deploy that forgot the flag must not take the apex dark."""
    template = _dns_with()
    assert _by_name_and_type(template, f"{DOMAIN}.", "A")["ResourceRecords"] == [RENDER_APEX_IP]
    assert _by_name_and_type(template, f"www.{DOMAIN}.", "CNAME")["ResourceRecords"] == [
        RENDER_WWW_HOST
    ]


def test_render_records_false_removes_exactly_those_two_records() -> None:
    """`-c renderRecords=false` is the first of the cutover's two deploys.

    The apex A and the `www` CNAME go, because Route 53 will not hold a second A
    set at the apex and will not hold a `www` CNAME beside a `www` alias. Nothing
    else may move: the mail records are what a mistake here takes down.
    """
    names = _record_names(_dns_with(renderRecords="false"))
    assert (f"{DOMAIN}.", "A") not in names
    assert (f"www.{DOMAIN}.", "CNAME") not in names
    assert (f"{DOMAIN}.", "MX") in names
    assert (f"{DOMAIN}.", "TXT") in names
    assert (f"_dmarc.{DOMAIN}.", "TXT") in names
    for record_name, _target in EXISTING_CNAMES:
        assert (f"{record_name}.{DOMAIN}.", "CNAME") in names


def test_removing_the_render_records_is_all_that_changes() -> None:
    """Exactly two record sets fewer, and they are the two named ones."""
    before = _record_names(_dns_with())
    after = _record_names(_dns_with(renderRecords="false"))
    assert before - after == {(f"{DOMAIN}.", "A"), (f"www.{DOMAIN}.", "CNAME")}
    assert after - before == set()
