"""`meridian-<env>-data`: RDS, S3, secrets and AWS Backup (Phase 3 steps 6-9).

Most of these assert a control rather than a shape. The database being single-AZ, the
buckets refusing an unencrypted put, the vault being locked and the staging instance
stopping itself are each a decision with a number attached — and each is the kind of thing
that survives a deploy while being quietly wrong, which is why it is a test and not a
comment.
"""

from __future__ import annotations

import fnmatch
import json
import pathlib
import re
from collections.abc import Mapping
from typing import Any

import pytest
from aws_cdk import assertions
from conftest import stack_template, synth_with

from meridian.api_platform import webhook_sender_name
from meridian.config import ENV_CONFIG
from meridian.log_groups import logs_key_log_group_patterns, phi_key_log_group_patterns
from meridian.stacks.data import (
    BACKUP_RETENTION_DAYS,
    IDLE_IN_TRANSACTION_TIMEOUT_MS,
    MALWARE_VALIDATION_OBJECT_KEY,
    MASTER_USERNAME,
    RAW_UPLOAD_TAG,
    STATEMENT_TIMEOUT_MS,
    STOP_DLQ_EXPECTED_ERROR,
    URL_UNSAFE_CHARACTERS,
    VAULT_MAX_RETENTION_DAYS,
    VAULT_MIN_RETENTION_DAYS,
    VAULT_RETENTION_DAYS,
)
from meridian.stacks.observability import CANARY_CONTEXT_FLAG

ENVIRONMENTS = ("staging", "production")


def data(env: str, **context: object) -> assertions.Template:
    return stack_template(env, "data", **context)


def _resources(template: assertions.Template, type_name: str) -> Mapping[str, Any]:
    return template.find_resources(type_name)


def _instance(template: assertions.Template) -> dict[str, Any]:
    instances = _resources(template, "AWS::RDS::DBInstance")
    assert len(instances) == 1
    return next(iter(instances.values()))


def _bucket(template: assertions.Template, env: str, purpose: str) -> dict[str, Any]:
    return next(
        bucket
        for bucket in _resources(template, "AWS::S3::Bucket").values()
        if bucket["Properties"]["BucketName"] == f"meridian-{env}-s3-{purpose}"
    )


# ------------------------------------------------------------------------- RDS


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_database_is_single_az_encrypted_and_not_public(env_name: str) -> None:
    """**D-14 / ADR 0007, and the two controls that keep it private.**

    Multi-AZ is the ~$28/month we chose not to spend; the recovery story is PITR plus the
    locked vault. `PubliclyAccessible=false` and the isolated subnet group say the same
    thing twice on purpose — the subnets have no route to anything, so even a mis-set
    flag would not produce a reachable database.
    """
    props = _instance(data(env_name))["Properties"]
    assert props["MultiAZ"] is False
    assert props["PubliclyAccessible"] is False
    assert props["StorageEncrypted"] is True
    assert props["KmsKeyId"]["Fn::GetAtt"][0].startswith("KeyRds")
    assert props["Engine"] == "postgres"
    # L-1: the MAJOR only. `auto_minor_version_upgrade=True` plus a pinned minor is a
    # template that disagrees with the instance the morning after a maintenance window.
    assert props["EngineVersion"] == "17"
    assert props["StorageType"] == "gp3"
    assert props["AllocatedStorage"] == "20"
    assert props["MasterUsername"] == MASTER_USERNAME


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_instance_class_matches_the_environment(env_name: str) -> None:
    props = _instance(data(env_name))["Properties"]
    assert props["DBInstanceClass"] == f"db.{ENV_CONFIG[env_name].db_instance_type}"


def test_production_refuses_deletion_and_staging_does_not() -> None:
    """Phase 3's documented roll-back is `cdk destroy` of the staging data stack.
    Production's is nothing of the sort."""
    assert _instance(data("production"))["Properties"]["DeletionProtection"] is True
    assert _instance(data("staging"))["Properties"]["DeletionProtection"] is False


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_instance_is_retained_even_in_staging(env_name: str) -> None:
    """D-15 says the data stack persists with RDS stopped. RETAIN makes losing it take
    two deliberate steps rather than one mistyped command."""
    assert _instance(data(env_name))["DeletionPolicy"] == "Retain"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_seven_days_of_point_in_time_recovery_and_tagged_snapshots(env_name: str) -> None:
    """Seven days of automated backups restores to any 5-minute mark, which is the
    RPO ≈ 1 hour of ADR 0007 with room. `CopyTagsToSnapshot` is what makes a snapshot
    visible to the tag-based backup selection and attributable by the budgets."""
    props = _instance(data(env_name))["Properties"]
    assert props["BackupRetentionPeriod"] == BACKUP_RETENTION_DAYS == 7
    assert props["CopyTagsToSnapshot"] is True
    assert props["DeleteAutomatedBackups"] is False


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_parameter_group_carries_every_required_setting(env_name: str) -> None:
    """TLS enforced at the server, pgaudit preloaded and configured, both timeouts, UTC."""
    groups = _resources(data(env_name), "AWS::RDS::DBParameterGroup")
    assert len(groups) == 1
    params = next(iter(groups.values()))["Properties"]["Parameters"]
    assert params["rds.force_ssl"] == "1"
    assert params["shared_preload_libraries"] == "pg_stat_statements,pgaudit"
    assert params["pgaudit.log"] == "ddl,role,write"
    assert params["log_connections"] == "1"
    assert params["log_disconnections"] == "1"
    assert params["statement_timeout"] == str(STATEMENT_TIMEOUT_MS) == "300000"
    assert params["idle_in_transaction_session_timeout"] == str(IDLE_IN_TRANSACTION_TIMEOUT_MS)
    assert params["timezone"] == "UTC"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_log_exports_go_to_our_own_encrypted_400_day_groups(env_name: str) -> None:
    """RDS makes `/aws/rds/instance/<id>/<type>` by itself, with never-expire retention
    and no customer key. Declaring the groups first is what gets the CMK and the 400 days
    — and the `DependsOn` is what stops RDS winning the race."""
    template = data(env_name)
    props = _instance(template)["Properties"]
    assert sorted(props["EnableCloudwatchLogsExports"]) == ["postgresql", "upgrade"]

    groups = {
        group["Properties"]["LogGroupName"]: group
        for group in _resources(template, "AWS::Logs::LogGroup").values()
    }
    expected = {
        f"/aws/rds/instance/meridian-{env_name}-rds-main/{log_type}"
        for log_type in ("postgresql", "upgrade")
    }
    assert set(groups) == expected
    for name in expected:
        assert groups[name]["Properties"]["RetentionInDays"] == 400
        assert "KmsKeyId" in groups[name]["Properties"]
        assert groups[name]["DeletionPolicy"] == "Retain"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_rds_log_groups_are_phi_and_carry_the_phi_key(env_name: str) -> None:
    """**M-4.** `pgaudit.log` is `ddl,role,write` instance-wide and pgaudit logs the
    *statement text*; Meridian interpolates literals client-side rather than binding
    parameters, so an `INSERT` into a PHI table arrives here with the patient account
    number in it.

    The choice was to drop `write` — losing the write trail the HIPAA control asks for —
    or to classify the log group honestly. Classifying it costs nothing: the PHI CMK
    instead of the `logs` one, `DataClassification=phi` instead of `internal`, which is
    also what moves it into the `phi` backup selection. ADR 0012 and ADR 0020 §4 record
    that reading this group is a PHI access and is audited as one from Phase 6."""
    template = data(env_name)
    groups = [
        group
        for group in _resources(template, "AWS::Logs::LogGroup").values()
        if group["Properties"]["LogGroupName"].startswith("/aws/rds/instance/")
    ]
    assert len(groups) == 2
    for group in groups:
        props = group["Properties"]
        assert props["KmsKeyId"]["Fn::GetAtt"][0].startswith("KeyPhi"), "the logs key is wrong"
        tags = {tag["Key"]: tag["Value"] for tag in props["Tags"]}
        assert tags["DataClassification"] == "phi"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_performance_insights_is_on_encrypted_and_free(env_name: str) -> None:
    """**H-3 — the earlier "t4g cannot do it" note was wrong.**

    "Performance Insights is not supported on burstable classes" is a MySQL/MariaDB rule.
    For PostgreSQL, `describe-orderable-db-instance-options --engine postgres
    --engine-version 17` returns `db.t4g.micro` and `db.t4g.small` with
    `SupportsPerformanceInsights: true`.

    Seven days of retention is the free tier, so this is $0/month; the key is the `rds`
    CMK rather than the AWS-managed one, because the dashboard shows SQL text."""
    props = _instance(data(env_name))["Properties"]
    assert props["EnablePerformanceInsights"] is True
    assert props["PerformanceInsightsRetentionPeriod"] == 7
    assert props["PerformanceInsightsKMSKeyId"]["Fn::GetAtt"][0].startswith("KeyRds")
    assert ENV_CONFIG[env_name].db_instance_type in ("t3.micro", "t4g.small")


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_master_credential_is_rds_managed_and_uses_our_key(env_name: str) -> None:
    """RDS-managed rotation needs no Lambda and no VPC egress, so it keeps working while
    the `edge` stack (and its NAT) is destroyed — which is most of a staging month. The
    key is ours rather than `aws/secretsmanager`, so the credential sits inside the same
    environment boundary as everything else it protects."""
    props = _instance(data(env_name))["Properties"]
    assert props["ManageMasterUserPassword"] is True
    assert "MasterUserPassword" not in props
    assert props["MasterUserSecret"]["KmsKeyId"]["Fn::GetAtt"][0].startswith("KeyRds")


# ------------------------------------------------------------- the stop schedule


def test_only_staging_stops_itself_every_night() -> None:
    """**D-15.** RDS restarts a stopped instance after seven days, so the stop is a
    nightly schedule rather than a one-off. Production has none: stopping the production
    database is a decision, not a cron line."""
    staging = _resources(data("staging"), "AWS::Scheduler::Schedule")
    assert len(staging) == 1
    props = next(iter(staging.values()))["Properties"]
    assert props["ScheduleExpression"] == "cron(0 2 * * ? *)"
    assert props["ScheduleExpressionTimezone"] == "America/Chicago"
    assert props["State"] == "ENABLED"
    assert props["Target"]["Arn"].endswith("aws-sdk:rds:stopDBInstance")

    assert _resources(data("production"), "AWS::Scheduler::Schedule") == {}


def test_the_schedule_input_uses_the_name_scheduler_accepts() -> None:
    """Scheduler refused `DBInstanceIdentifier` at create time on 2026-10-03: "Request
    payload is missing the following field(s): DbInstanceIdentifier"."""
    props = next(iter(_resources(data("staging"), "AWS::Scheduler::Schedule").values()))[
        "Properties"
    ]
    rendered = json.dumps(props["Target"]["Input"])
    assert "DbInstanceIdentifier" in rendered
    assert "DBInstanceIdentifier" not in rendered


def test_a_failed_stop_lands_in_a_dead_letter_queue_that_nothing_alarms_on() -> None:
    """Without a DLQ, a schedule that has never once succeeded looks exactly like one
    that works — which is how M-1's wrong input key survived review.

    The queue is KMS-encrypted (the message body is an API call and an error code) and
    keeps a message for one day. **There is deliberately no alarm on it** (critic, data
    tier, medium b): a depth threshold cannot separate the expected nightly
    `InvalidDBInstanceState` from a real failure, because a night whose only message is a
    real failure has exactly the same depth as every expected night. The queue is
    evidence, and `scripts/staging_session.sh up` is what reads it."""
    template = data("staging")
    queues = _resources(template, "AWS::SQS::Queue")
    assert len(queues) == 1
    queue_logical_id, queue = next(iter(queues.items()))
    assert queue["Properties"]["QueueName"] == "meridian-staging-sqs-rds-stop-dlq"
    assert queue["Properties"]["MessageRetentionPeriod"] == 86_400
    assert queue["Properties"]["KmsMasterKeyId"]["Fn::GetAtt"][0].startswith("KeyLogs")

    schedule = next(iter(_resources(template, "AWS::Scheduler::Schedule").values()))
    dlq_arn = schedule["Properties"]["Target"]["DeadLetterConfig"]["Arn"]
    assert dlq_arn == {"Fn::GetAtt": [queue_logical_id, "Arn"]}

    assert _resources(template, "AWS::CloudWatch::Alarm") == {}, (
        "the DLQ depth alarm was withdrawn; if one is added again it needs a filter on "
        "the error code, not a threshold on the depth. ADR 0020 §7c."
    )


def test_the_session_script_reads_the_stop_schedule_result_from_logs() -> None:
    """The alarm's replacement is a step in a script, so the script is the test.

    **Phase 6 changed where it reads from, and that is the point of this test.** It used
    to `sqs receive-message` this queue. It cannot any more: the EventBridge Pipe consumes
    every message — that is what a Pipe does — and a drain would find an empty queue on a
    working night and an empty queue on a broken one. The Pipe delivers everything to a
    bus, two rules split expected from unexpected, and both land in
    `meridian-staging-logs-stop-schedule`, which the script reads without consuming.
    ADR 0024 §5.
    """
    script = (
        pathlib.Path(__file__).resolve().parents[2] / "scripts" / "staging_session.sh"
    ).read_text()
    assert "logs filter-log-events" in script
    assert "meridian-staging-logs-stop-schedule" in script
    assert "aws sqs receive-message" not in script
    assert STOP_DLQ_EXPECTED_ERROR in script


def test_the_alerts_topic_lets_cloudwatch_publish_to_it() -> None:
    """Critic (data tier, medium a). The topic is encrypted with the `logs` CMK and
    CloudWatch publishes as a service principal, not as one of our roles — so the
    `meridian-<env>-*` statement in `_cmk` does not reach it.

    Without `kms:GenerateDataKey*`/`kms:Decrypt` the publish fails inside SNS: the alarm
    still goes to ALARM, the console still shows an action, and nobody is told. It is
    installed although no alarm exists today, because Phase 6 attaches the alarms and a
    missing grant is found the first time one matters."""
    template = data("staging")
    statements = [
        statement
        for key in _resources(template, "AWS::KMS::Key").values()
        for statement in key["Properties"]["KeyPolicy"]["Statement"]
        if statement.get("Sid") == "AllowCloudWatchAlarmsToPublishToAnEncryptedTopic"
    ]
    assert len(statements) == 1, "exactly one key (the logs CMK) carries this statement"
    statement = statements[0]
    assert statement["Principal"] == {"Service": "cloudwatch.amazonaws.com"}
    assert set(statement["Action"]) == {"kms:Decrypt", "kms:GenerateDataKey*"}
    # **No Condition** (critic P6R2-01). AWS's documented key policy for a CloudWatch alarm
    # publishing to an encrypted topic is the bare `Allow_CloudWatch_for_CMK` statement with
    # no condition (https://repost.aws/knowledge-center/cloudwatch-configure-alarm-sns), and
    # the SNS key-management guide lists no service-specific confused-deputy details for
    # CloudWatch. A condition the evaluating service never populates is not a guard, it is a
    # deny — and this one denies silently, inside SNS. The real guard is on the TOPIC policy
    # (asserted in `test_eventbridge_can_publish_to_the_encrypted_alerts_topic`), which is
    # the document SNS evaluates.
    assert "Condition" not in statement

    # And it is the key the topic actually uses.
    topic = next(iter(_resources(template, "AWS::SNS::Topic").values()))
    assert topic["Properties"]["KmsMasterKeyId"]["Fn::GetAtt"][0].startswith("KeyLogs")


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_eventbridge_can_publish_to_the_encrypted_alerts_topic(env_name: str) -> None:
    """Critic P6-06. **Half of Phase 6's notifications do not come from an alarm.**

    The backup, copy-job, rotation, finding and stop-schedule notifications are
    EventBridge *rules* whose target is this topic, and a rule publishes as
    `events.amazonaws.com` — not as CloudWatch and not as a role of ours. Both halves of
    that permission are needed, and **only one of them may carry a condition** (critic
    P6R2-01):

    * the **key** policy, or the publish fails inside SNS with `KMS.AccessDeniedException`
      while the rule shows as matched and invoked. It is **unconditioned**: AWS's SNS
      key-management guide states that "adding the `aws:SourceAccount`, `aws:SourceArn`,
      and `aws:SourceOrgID` to a AWS KMS policy is not supported for
      EventBridge-to-encrypted topics"
      (https://docs.aws.amazon.com/sns/latest/dg/sns-key-management.html), so the
      condition this used to carry failed every rule-sourced publish.
    * the **topic** policy, which SNS *does* evaluate, so `aws:SourceAccount` lives there
      and is asserted there. It has a second trap in it — any explicit
      `AWS::SNS::TopicPolicy` REPLACES the topic's default policy, so the moment one
      statement is added the default is gone and everything not named is refused.

    `pipes.amazonaws.com` is deliberately absent from both: the stop-schedule Pipe reads
    the queue under its own role and delivers to an event bus, never to this topic.
    """
    template = data(env_name)

    key_statements = {
        statement.get("Sid"): statement
        for key in _resources(template, "AWS::KMS::Key").values()
        for statement in key["Properties"]["KeyPolicy"]["Statement"]
    }
    events_key = key_statements["AllowEventBridgeRulesToPublishToAnEncryptedTopic"]
    assert events_key["Principal"] == {"Service": "events.amazonaws.com"}
    assert set(events_key["Action"]) == {"kms:Decrypt", "kms:GenerateDataKey*"}
    # Unsupported on a KMS policy for EventBridge → encrypted topic; see the docstring.
    assert "Condition" not in events_key
    assert "pipes.amazonaws.com" not in json.dumps(list(key_statements.values()))

    policies = _resources(template, "AWS::SNS::TopicPolicy")
    assert len(policies) == 1
    document = next(iter(policies.values()))["Properties"]["PolicyDocument"]
    by_sid = {statement.get("Sid"): statement for statement in document["Statement"]}
    # The owner statement is what the default policy was, restored by hand.
    assert "AllowThisAccountToOwnTheTopic" in by_sid
    for sid, service in (
        ("AllowCloudWatchAlarmsFromThisAccount", "cloudwatch.amazonaws.com"),
        ("AllowEventBridgeRulesFromThisAccount", "events.amazonaws.com"),
    ):
        statement = by_sid[sid]
        assert statement["Principal"] == {"Service": service}
        assert statement["Condition"]["StringEquals"]["aws:SourceAccount"] == {
            "Ref": "AWS::AccountId"
        }

    # **No unconditioned service statement anywhere.** An unconditioned Allow beside a
    # conditioned one is not a confused-deputy guard — the permissive one still applies.
    # This is why `observability.py` uses a plain ARN rule target instead of
    # `events_targets.SnsTopic`, which appends exactly such a statement.
    for sid, statement in by_sid.items():
        if "Service" in statement.get("Principal", {}):
            assert "Condition" in statement, f"{sid} lets any account's service publish"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_service_roles_refuse_to_be_assumed_for_another_account(env_name: str) -> None:
    """Confused-deputy guards on the two TRUST policies (critic, data tier, low).

    A service principal with no `aws:SourceAccount` can be steered by anything in any
    account that learns the role's ARN. Both roles are named by resource, so the ARN is
    guessable."""
    template = data(env_name)
    roles = {
        role["Properties"].get("RoleName"): role["Properties"]["AssumeRolePolicyDocument"]
        for role in _resources(template, "AWS::IAM::Role").values()
    }
    expected = [f"meridian-{env_name}-iam-backup"]
    if env_name == "staging":
        expected.append(f"meridian-{env_name}-iam-rds-stop")
    for name in expected:
        assert name in roles, name
        statement = roles[name]["Statement"][0]
        condition = statement.get("Condition", {}).get("StringEquals", {})
        assert condition.get("aws:SourceAccount") == {"Ref": "AWS::AccountId"}, name


def test_the_origin_verify_secret_is_on_a_key_we_own() -> None:
    """Critic (data tier, low). It is internal, not PHI, so it takes the `logs` CMK and
    not the `phi` one — the point is a key policy we control and a CloudTrail Decrypt
    event naming a key we own, not a second PHI boundary."""
    for env_name in ENVIRONMENTS:
        template = data(env_name)
        secret = next(
            s
            for s in _resources(template, "AWS::SecretsManager::Secret").values()
            if s["Properties"]["Name"] == f"meridian-{env_name}-secret-origin-verify"
        )
        assert secret["Properties"]["KmsKeyId"]["Fn::GetAtt"][0].startswith("KeyLogs")


def test_production_has_no_stop_schedule_and_therefore_no_queue_or_alarm() -> None:
    """The DLQ exists only to watch the staging stop schedule. Production has no
    schedule, so it has no queue — an idle queue would be a resource that means nothing."""
    template = data("production")
    assert _resources(template, "AWS::SQS::Queue") == {}
    assert _resources(template, "AWS::Scheduler::Schedule") == {}
    assert _resources(template, "AWS::CloudWatch::Alarm") == {}


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_alerts_topic_exists_in_both_environments(env_name: str) -> None:
    """**Phase 6 moved this above the staging-only guard, and the move matters.**

    The topic used to be created only where `destroyed_between_phases` is true — that is,
    in staging and nowhere else — because the only thing that was ever going to publish to
    it was the stop-schedule DLQ alarm, and the stop schedule is a staging cost control
    (ADR 0020 §7c). `meridian-<env>-observability` now attaches roughly thirty alarms to
    it in **both** environments, so a production-only outage had nowhere to page.

    It stays in the `data` stack rather than moving into `observability` for a reason that
    is not tidiness: an SNS subscription is confirmed once, by a human clicking a link in
    an email. `data` is never destroyed (ADR 0020); `observability` is destroyed at the end
    of every staging session (ADR 0008 / D-15). A topic re-created by a teardown comes back
    with that subscription unconfirmed, every alarm fires into nothing, and the only
    symptom is silence.
    """
    template = data(env_name)
    topics = _resources(template, "AWS::SNS::Topic")
    assert len(topics) == 1
    properties = next(iter(topics.values()))["Properties"]
    assert properties["TopicName"] == f"meridian-{env_name}-sns-alerts"
    # The `logs` CMK, whose policy names `cloudwatch.amazonaws.com` — without that grant
    # the publish fails *inside SNS*: the alarm still shows ALARM and nobody is told.
    assert properties["KmsMasterKeyId"]["Fn::GetAtt"][0].startswith("KeyLogs")


def test_the_stop_role_can_stop_exactly_one_instance_and_nothing_else() -> None:
    template = data("staging")
    statements = [
        statement
        for policy in _resources(template, "AWS::IAM::Policy").values()
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
        if statement.get("Action") == "rds:StopDBInstance"
    ]
    assert len(statements) == 1
    # The instance ARN, not "*" — a wildcard here could stop the assistant app's
    # database, which is explicitly off-limits (ADR 0001).
    assert "*" not in json.dumps(statements[0]["Resource"])
    assert "StartDBInstance" not in json.dumps(template.to_json())


# --------------------------------------------------------------------------- S3


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_four_buckets_exist_with_the_right_keys(env_name: str) -> None:
    template = data(env_name)
    names = {
        bucket["Properties"]["BucketName"]
        for bucket in _resources(template, "AWS::S3::Bucket").values()
    }
    assert names == {
        f"meridian-{env_name}-s3-{purpose}" for purpose in ("artifacts", "phi", "audit", "archive")
    }

    for purpose, key_prefix in (
        ("artifacts", "KeyArtifacts"),
        ("phi", "KeyPhi"),
        # The audit bucket deliberately reuses the `logs` CMK: its contents are the same
        # class of record as the log groups, and never a PHI value (ADR 0012).
        ("audit", "KeyLogs"),
        # The archive bucket does NOT: it holds the Phase 10 Supabase dump, which is
        # PHI, so it is on the `phi` CMK and tagged `phi`.
        ("archive", "KeyPhi"),
    ):
        props = _bucket(template, env_name, purpose)["Properties"]
        rule = props["BucketEncryption"]["ServerSideEncryptionConfiguration"][0]
        assert rule["ServerSideEncryptionByDefault"]["SSEAlgorithm"] == "aws:kms"
        assert rule["ServerSideEncryptionByDefault"]["KMSMasterKeyID"]["Fn::GetAtt"][0].startswith(
            key_prefix
        )
        assert rule["BucketKeyEnabled"] is True


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
@pytest.mark.parametrize("purpose", ["artifacts", "phi", "audit", "archive"])
def test_every_bucket_is_versioned_private_and_acl_free(env_name: str, purpose: str) -> None:
    props = _bucket(data(env_name), env_name, purpose)["Properties"]
    assert props["VersioningConfiguration"]["Status"] == "Enabled"
    public = props["PublicAccessBlockConfiguration"]
    assert all(public[flag] is True for flag in public)
    ownership = props["OwnershipControls"]["Rules"][0]["ObjectOwnership"]
    assert ownership == "BucketOwnerEnforced"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
@pytest.mark.parametrize("purpose", ["artifacts", "phi", "audit", "archive"])
def test_every_bucket_denies_plain_http_and_the_wrong_key(env_name: str, purpose: str) -> None:
    """Three deny statements, and the second and third are the ones that matter.

    S3 accepts a put with SSE-S3, or with *another* CMK, and encrypts it — just not under
    the key whose policy draws the environment boundary. Both denies turn that into a
    403, which is why `src/storage.py` sends the headers on every put and why the key ARNs
    are in `S3_REQUIRED_ENV`.
    """
    template = data(env_name)
    bucket_name = f"meridian-{env_name}-s3-{purpose}"
    policy = next(
        p
        for p in _resources(template, "AWS::S3::BucketPolicy").values()
        if bucket_name in json.dumps(p["Properties"])
        or p["Properties"]["Bucket"]["Ref"]
        in [
            logical
            for logical, b in _resources(template, "AWS::S3::Bucket").items()
            if b["Properties"]["BucketName"] == bucket_name
        ]
    )
    sids = {
        statement.get("Sid") for statement in policy["Properties"]["PolicyDocument"]["Statement"]
    }
    assert {"DenyUnencryptedObjectUploads", "DenyWrongKmsKey"} <= sids

    body = json.dumps(policy["Properties"]["PolicyDocument"])
    assert "aws:SecureTransport" in body
    assert '"aws:kms"' in body


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_audit_bucket_is_object_locked_in_compliance_mode_for_seven_years(
    env_name: str,
) -> None:
    """Compliance mode means nobody can delete or overwrite an object for the retention
    period — not an administrator, not the account root, not AWS Support. That is what
    makes an audit record evidence, and it is the same argument as the Vault Lock.

    Seven years is HIPAA's six-year documentation retention plus slack (plan §7 item 13);
    400-day log groups do not satisfy it."""
    props = _bucket(data(env_name), env_name, "audit")["Properties"]
    assert props["ObjectLockEnabled"] is True
    retention = props["ObjectLockConfiguration"]["Rule"]["DefaultRetention"]
    assert retention["Mode"] == "COMPLIANCE"
    assert retention["Days"] == 365 * 7


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_only_the_data_buckets_have_object_lock_off(env_name: str) -> None:
    """Object Lock on `artifacts` or `phi` would make an overwrite impossible, and both
    are written to on every run."""
    template = data(env_name)
    for purpose in ("artifacts", "phi"):
        assert "ObjectLockEnabled" not in _bucket(template, env_name, purpose)["Properties"]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_raw_uploads_expire_at_7_years_and_old_versions_at_90(env_name: str) -> None:
    """The 7-year raw-upload rule is on the `phi` bucket only, because that is where raw uploads go
    (`src/storage.py` maps `uploads` — and every unknown subfolder — to `phi`).

    It is a **tag** filter rather than a prefix filter, and that is forced: the key layout
    is `{org}/{batch}/uploads/{file}`, so `uploads/` is in the middle and an S3 lifecycle
    prefix matches only from the start. `S3StorageManager` has to tag its puts (Phase 5a)
    before the rule selects anything."""
    template = data(env_name)
    phi_rules = {
        rule["Id"]: rule
        for rule in _bucket(template, env_name, "phi")["Properties"]["LifecycleConfiguration"][
            "Rules"
        ]
    }
    uploads = phi_rules["expire-raw-uploads-after-7-years"]
    assert uploads["ExpirationInDays"] == 2557
    assert uploads["TagFilters"] == [{"Key": RAW_UPLOAD_TAG[0], "Value": RAW_UPLOAD_TAG[1]}]

    for purpose in ("artifacts", "phi"):
        rules = {
            rule["Id"]: rule
            for rule in _bucket(template, env_name, purpose)["Properties"][
                "LifecycleConfiguration"
            ]["Rules"]
        }
        noncurrent = rules["expire-noncurrent-versions-after-90-days"]
        assert noncurrent["NoncurrentVersionExpiration"]["NoncurrentDays"] == 90

    # The audit bucket has no expiry at all: a lifecycle expiry on a compliance-locked
    # object is a rule that cannot fire, and writing one would suggest otherwise.
    audit_rules = _bucket(template, env_name, "audit")["Properties"]["LifecycleConfiguration"][
        "Rules"
    ]
    assert all("ExpirationInDays" not in rule for rule in audit_rules)
    assert all("NoncurrentVersionExpiration" not in rule for rule in audit_rules)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_artifacts_bucket_is_not_destroyed_in_staging_either(env_name: str) -> None:
    """RETAIN on all three, in both environments. Staging's idle S3 cost is cents, so
    `DESTROY` would save nothing — and `auto_delete_objects` would add another Lambda
    custom resource with another implicit, unencrypted log group (M-2)."""
    template = data(env_name)
    for bucket in _resources(template, "AWS::S3::Bucket").values():
        assert bucket["DeletionPolicy"] == "Retain", bucket["Properties"]["BucketName"]
    # The auto-delete helper would show up as a Lambda. There is none.
    assert _resources(template, "AWS::Lambda::Function") == {}


# ---------------------------------------------------------- malware protection


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_malware_protection_covers_the_phi_bucket_and_only_that(env_name: str) -> None:
    """Every file Meridian ingests is an untrusted upload and lands in the `phi` bucket.
    The scan is billed per GB, and the other two buckets hold what this application wrote
    — so one plan, on one bucket. `Tagging: ENABLED` is the point: `meridian_app` reads
    the scan tag before it opens the file (Phase 5a, ADR 0012)."""
    template = data(env_name)
    plans = _resources(template, "AWS::GuardDuty::MalwareProtectionPlan")
    assert len(plans) == 1
    props = next(iter(plans.values()))["Properties"]
    assert props["Actions"]["Tagging"]["Status"] == "ENABLED"

    phi_logical = next(
        logical
        for logical, bucket in _resources(template, "AWS::S3::Bucket").items()
        if bucket["Properties"]["BucketName"] == f"meridian-{env_name}-s3-phi"
    )
    assert props["ProtectedResource"]["S3Bucket"]["BucketName"]["Ref"] == phi_logical


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_scan_role_matches_the_documented_prerequisite_policy(env_name: str) -> None:
    """**H-2.** The hand-written version of this role was narrower than AWS's documented
    prerequisite policy in two ways that both fail when the plan is enabled rather than
    when the stack deploys:

    * the EventBridge statement named the **default event bus**. GuardDuty does not act
      on the bus; it creates and manages a rule named
      `DO-NOT-DELETE-AmazonGuardDutyMalwareProtectionS3*`, and a bus ARN authorises none
      of `PutRule`/`PutTargets`/`RemoveTargets`/`DeleteRule` against it.
    * there was no `s3:PutObject` on
      `malware-protection-resource-validation-object`, which is the first thing the
      service writes when a plan is created.

    Source: `docs.aws.amazon.com/guardduty/latest/ug/malware-protection-s3-iam-policy-prerequisite.html`.
    """
    template = data(env_name)
    statements = [
        statement
        for policy in _resources(template, "AWS::IAM::Policy").values()
        if "Malware" in json.dumps(policy["Properties"].get("Roles", ""))
        or "malware" in json.dumps(policy["Properties"]).lower()
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
    ]
    rendered = json.dumps(statements)
    assert "rule/DO-NOT-DELETE-AmazonGuardDutyMalwareProtectionS3*" in rendered
    assert "events:PutRule" in rendered
    assert MALWARE_VALIDATION_OBJECT_KEY in rendered
    # The bus ARN authorised nothing and is gone.
    assert "event-bus/default" not in rendered

    by_action = {
        action: statement
        for statement in statements
        for action in (
            statement["Action"] if isinstance(statement["Action"], list) else [statement["Action"]]
        )
    }
    # Every events action is scoped to the managed rule, never to `*` or to the bus.
    for action in ("events:PutRule", "events:PutTargets", "events:DescribeRule"):
        resource = json.dumps(by_action[action]["Resource"])
        assert "DO-NOT-DELETE-AmazonGuardDutyMalwareProtectionS3*" in resource
    # PutRule carries the managed-by condition the document puts on it.
    assert by_action["events:PutRule"]["Condition"]["StringLike"]["events:ManagedBy"] == (
        "malware-protection-plan.guardduty.amazonaws.com"
    )
    # KMS is scoped through S3 only.
    kms_statement = by_action["kms:Decrypt"]
    assert "s3." in json.dumps(kms_statement["Condition"]["StringLike"]["kms:ViaService"])


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_phi_denies_carve_out_the_validation_object(env_name: str) -> None:
    """**H-2, the other half.** GuardDuty puts the validation object with no encryption
    headers — the bucket default encrypts it, but `s3:x-amz-server-side-encryption` is
    absent from the request, so `DenyUnencryptedObjectUploads` refuses it and enabling the
    plan fails.

    The carve-out is `NotResource`, not an `Allow`: an explicit allow cannot override a
    deny in IAM. It is safe because a *bucket* policy is only evaluated for requests
    against that bucket, so "everything except this key" cannot reach wider than the
    bucket. The other two buckets are not scanned and keep the plain denies."""
    template = data(env_name)
    policies = _resources(template, "AWS::S3::BucketPolicy")
    phi_statements = [
        statement
        for policy in policies.values()
        if "BucketPhi" in json.dumps(policy["Properties"]["Bucket"])
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
        if statement.get("Sid") in ("DenyUnencryptedObjectUploads", "DenyWrongKmsKey")
    ]
    assert len(phi_statements) == 2
    for statement in phi_statements:
        assert statement["Effect"] == "Deny"
        assert "Resource" not in statement
        assert MALWARE_VALIDATION_OBJECT_KEY in json.dumps(statement["NotResource"])

    other_statements = [
        statement
        for policy in policies.values()
        if "BucketPhi" not in json.dumps(policy["Properties"]["Bucket"])
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
        if statement.get("Sid") in ("DenyUnencryptedObjectUploads", "DenyWrongKmsKey")
    ]
    assert other_statements
    for statement in other_statements:
        assert "NotResource" not in statement
        assert statement["Resource"]


# ---------------------------------------------------------------------- secrets


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_seven_secrets_and_their_names(env_name: str) -> None:
    template = data(env_name)
    names = {
        secret["Properties"]["Name"]
        for secret in _resources(template, "AWS::SecretsManager::Secret").values()
    }
    assert names == {
        f"meridian-{env_name}-secret-{purpose}"
        for purpose in (
            "origin-verify",
            "db-app",
            "db-phi",
            "db-mart-owner",
            "db-mart-reader",
            "phi-hmac-key",
            "flask-key",
        )
    }


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_two_mart_credentials(env_name: str) -> None:
    """Alembic 0048's roles (ADR 0053): generated, retained, rds CMK, PHI-tagged, exported."""
    template = data(env_name)
    secrets = _resources(template, "AWS::SecretsManager::Secret")
    for purpose, role in (("mart-owner", "meridian_mart_owner"), ("mart-reader", "meridian_mart_reader")):
        secret = next(
            s for s in secrets.values()
            if s["Properties"]["Name"] == f"meridian-{env_name}-secret-db-{purpose}"
        )
        generator = secret["Properties"]["GenerateSecretString"]
        assert json.loads(generator["SecretStringTemplate"])["username"] == role
        assert generator["GenerateStringKey"] == "password"
        assert generator["ExcludeCharacters"] == URL_UNSAFE_CHARACTERS
        assert secret["DeletionPolicy"] == "Retain"
        assert "KmsKeyId" in secret["Properties"]
        tags = {t["Key"]: t["Value"] for t in secret["Properties"]["Tags"]}
        assert tags["DataClassification"] == "phi"
    outputs = template.find_outputs("*")
    for name in ("DatabaseMartOwnerSecretArn", "DatabaseMartReaderSecretArn"):
        assert name in outputs


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_phi_hmac_key_is_replicated_to_the_dr_region(env_name: str) -> None:
    """Codex G-H2: the cross-region backup is useless without the key that joins
    `public.transactions` to `phi.transaction_identity`."""
    template = data(env_name)
    secrets = _resources(template, "AWS::SecretsManager::Secret").values()
    hmac = next(s for s in secrets if s["Properties"]["Name"].endswith("phi-hmac-key"))
    assert [r["Region"] for r in hmac["Properties"]["ReplicaRegions"]] == ["us-west-2"]
    others = [s for s in secrets if not s["Properties"]["Name"].endswith("phi-hmac-key")]
    assert all("ReplicaRegions" not in s["Properties"] for s in others), (
        "only the HMAC key is backup-critical; the others are regenerated on restore"
    )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_no_secret_value_is_ever_written_down(env_name: str) -> None:
    """Every one of them is generated by CloudFormation. A `SecretString` property would
    mean the value is in this repository and in the template."""
    for secret in _resources(data(env_name), "AWS::SecretsManager::Secret").values():
        assert "SecretString" not in secret["Properties"], secret["Properties"]["Name"]
        assert "GenerateSecretString" in secret["Properties"]
        assert secret["DeletionPolicy"] == "Retain"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_database_passwords_exclude_every_url_breaking_character(env_name: str) -> None:
    """`MERIDIAN_DATABASE_URL` is a URL. A password containing `/`, `@`, `:` or `%`
    either terminates a component early or has to be percent-encoded by every consumer
    that builds one — psycopg2, Alembic, `psql` in a runbook, the task definition's
    dynamic reference — and the one that forgets fails as a wrong password."""
    template = data(env_name)
    for purpose in ("db-app", "db-phi", "db-mart-owner", "db-mart-reader"):
        secret = next(
            s
            for s in _resources(template, "AWS::SecretsManager::Secret").values()
            if s["Properties"]["Name"] == f"meridian-{env_name}-secret-{purpose}"
        )
        generator = secret["Properties"]["GenerateSecretString"]
        assert generator["ExcludeCharacters"] == URL_UNSAFE_CHARACTERS
        assert generator["GenerateStringKey"] == "password"
        assert generator["PasswordLength"] >= 32


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_nothing_in_this_stack_rotates_on_a_schedule_except_rds_itself(env_name: str) -> None:
    """**A deliberate absence, so it reads as a decision rather than an omission.**

    A Secrets Manager rotation schedule means a rotation Lambda in the VPC, which reaches
    Secrets Manager only through the NAT in the transient `edge` stack (ADR 0009 buys no
    interface endpoints). A rotation that silently stops working whenever staging is torn
    down is worse than one performed deliberately — so the two application credentials
    rotate by runbook (`docs/runbooks/rotate-secrets.md`) until Phase 5a can do it from an
    ECS task, and the master credential rotates inside RDS, which needs no network at all.

    The PHI HMAC key has no rotation for a different reason: rotating it breaks the join
    between `public.transactions` and `phi.transaction_identity` (ADR 0012)."""
    template = data(env_name)
    assert _resources(template, "AWS::SecretsManager::RotationSchedule") == {}
    assert _instance(template)["Properties"]["ManageMasterUserPassword"] is True


# ---------------------------------------------------------------- AWS Backup


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_vault_is_locked_in_compliance_mode(env_name: str) -> None:
    """**The control this whole section exists for.** Without the lock, the credential
    that can drop the database can delete every recovery point, and the backup is a copy
    rather than a control. `ChangeableForDays` is the three-day cooling-off window after
    which the lock is immutable for anyone, including AWS Support."""
    vaults = _resources(data(env_name), "AWS::Backup::BackupVault")
    assert len(vaults) == 1
    props = next(iter(vaults.values()))["Properties"]
    assert props["BackupVaultName"] == f"meridian-{env_name}-backup-vault"
    lock = props["LockConfiguration"]
    assert lock["MinRetentionDays"] == VAULT_MIN_RETENTION_DAYS == 35
    assert lock["MaxRetentionDays"] == VAULT_MAX_RETENTION_DAYS == 400
    assert lock["ChangeableForDays"] == 3
    assert "EncryptionKeyArn" in props


def test_the_plan_is_daily_35_days_and_copies_to_the_other_region() -> None:
    """Single-AZ RDS (D-14) makes this vault the disaster-recovery story, and a vault in
    the same region does not cover the loss of that region."""
    env_name = "production"
    plans = _resources(data(env_name), "AWS::Backup::BackupPlan")
    assert len(plans) == 1
    rule = next(iter(plans.values()))["Properties"]["BackupPlan"]["BackupPlanRule"][0]
    assert rule["ScheduleExpression"].startswith("cron(")
    assert rule["Lifecycle"]["DeleteAfterDays"] == VAULT_RETENTION_DAYS == 35

    copy_action = rule["CopyActions"][0]
    assert copy_action["Lifecycle"]["DeleteAfterDays"] == VAULT_RETENTION_DAYS
    destination = json.dumps(copy_action["DestinationBackupVaultArn"])
    assert "us-west-2" in destination
    assert f"meridian-{env_name}-backup-dr" in destination


def test_staging_has_a_locked_vault_but_no_schedule() -> None:
    """**M-2.** A daily 05:00 UTC job against an instance the 02:00 schedule stopped
    three hours earlier does not skip — AWS Backup fails it, nightly, for ever, and a job
    expected to fail makes every real failure unreadable.

    Staging keeps the vault, the compliance lock and the role; what it loses is the cron
    line and, with it, the selections. Its recovery points come from the 7-day PITR
    window and from the one on-demand `start-backup-job` that
    `scripts/staging_session.sh down` runs before it stops the instance."""
    template = data("staging")
    assert len(_resources(template, "AWS::Backup::BackupVault")) == 1
    assert _resources(template, "AWS::Backup::BackupPlan") == {}
    assert _resources(template, "AWS::Backup::BackupSelection") == {}
    roles = [
        role
        for role in _resources(template, "AWS::IAM::Role").values()
        if role["Properties"].get("RoleName") == "meridian-staging-iam-backup"
    ]
    assert len(roles) == 1, "the restore drill still needs the role"


def test_the_backup_role_names_managed_policies_that_exist() -> None:
    """The S3 backup/restore policies live at `policy/`, the RDS pair at
    `policy/service-role/`. A wrong path is a 404 at deploy time (2026-10-03)."""
    role = next(
        r
        for r in _resources(data("staging"), "AWS::IAM::Role").values()
        if r["Properties"].get("RoleName") == "meridian-staging-iam-backup"
    )
    arns = json.dumps(role["Properties"]["ManagedPolicyArns"])
    assert ":iam::aws:policy/service-role/AWSBackupServiceRolePolicyForBackup" in arns
    assert ":iam::aws:policy/service-role/AWSBackupServiceRolePolicyForRestores" in arns
    assert ":iam::aws:policy/AWSBackupServiceRolePolicyForS3Backup" in arns
    assert ":iam::aws:policy/AWSBackupServiceRolePolicyForS3Restore" in arns


def test_the_dr_region_can_be_overridden_from_context() -> None:
    template = data("production", drRegion="eu-west-1")
    rule = next(iter(_resources(template, "AWS::Backup::BackupPlan").values()))["Properties"][
        "BackupPlan"
    ]["BackupPlanRule"][0]
    assert "eu-west-1" in json.dumps(rule["CopyActions"][0]["DestinationBackupVaultArn"])


def test_the_selections_are_by_tag_and_cover_both_classifications() -> None:
    """Two selections rather than one, because AWS Backup ANDs the conditions of a single
    selection and the rule wanted is `Project AND Environment AND (phi OR internal)`.

    Selecting by tag is also why this is robust: a resource added later with the right
    tags is backed up without anyone editing the plan, and a resource without them is
    not — which is the other half of why `RequiredTagsAspect` fails the build."""
    env_name = "production"
    selections = _resources(data(env_name), "AWS::Backup::BackupSelection")
    assert len(selections) == 2

    seen = set()
    for selection in selections.values():
        conditions = selection["Properties"]["BackupSelection"]["Conditions"]["StringEquals"]
        by_key = {c["ConditionKey"]: c["ConditionValue"] for c in conditions}
        assert by_key["aws:ResourceTag/Project"] == "meridian"
        assert by_key["aws:ResourceTag/Environment"] == env_name
        seen.add(by_key["aws:ResourceTag/DataClassification"])
    assert seen == {"phi", "internal"}


def test_every_selection_names_resources_and_scopes_them_by_type() -> None:
    """**H-1 — a selection with `Conditions` and no `Resources` selects nothing.**

    AWS Backup reads `Resources` as the candidate set and `Conditions` as a filter over
    it. Empty candidates filtered by anything is empty: the plan deploys clean, the
    console shows two selections, and no job ever runs. That is the worst shape a backup
    control can take, because it is indistinguishable from a working one until the day
    somebody needs a restore."""
    for selection in _resources(data("production"), "AWS::Backup::BackupSelection").values():
        resources = selection["Properties"]["BackupSelection"]["Resources"]
        assert resources, "Conditions without Resources selects nothing"
        rendered = [json.dumps(arn) for arn in resources]
        assert any(":rds:*:*:db:*" in arn for arn in rendered)
        assert any(":s3:::*" in arn for arn in rendered)
        # No account id is written down (ADR 0001) and no region is pinned.
        assert all('"Ref": "AWS::Partition"' in arn for arn in rendered)
        assert all("AWS::AccountId" not in arn for arn in rendered)


def test_no_selection_can_reach_the_ops_instance_or_its_volume() -> None:
    """**M-3.** The `edge` stack's `t4g.nano` ops box carries `Project`, `Environment`
    and `DataClassification=internal`, so a tags-only selection would take a nightly EBS
    snapshot of a disposable jump box whose entire content is `cdk deploy` output.

    Scoping `Resources` to `rds:db` and `s3` excludes every EC2 and EBS ARN by
    construction, which is a guarantee rather than an exclusion list to maintain."""
    forbidden = (":ec2:", ":instance/", ":volume/", "ebs")
    for selection in _resources(data("production"), "AWS::Backup::BackupSelection").values():
        rendered = json.dumps(selection["Properties"]["BackupSelection"]["Resources"]).lower()
        for pattern in forbidden:
            assert pattern not in rendered, pattern


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_dr_stack_is_always_in_the_app(env_name: str) -> None:
    """**M-5.** This used to be gated on `CDK_DEFAULT_REGION`, which the CDK CLI always
    sets from the credentials in use — so the stack was always there under the CLI and
    absent only from the in-process tests, which is exactly where a missing DR vault goes
    unnoticed. Only the *region* has to be concrete for a pinned stack; the account stays
    unresolved, so `cdk synth` still needs no credentials."""
    names = {artifact.stack_name for artifact in synth_with(env_name).stacks}
    assert f"meridian-{env_name}-dr" in names


def test_the_dr_stack_follows_the_dr_region_context_value() -> None:
    assembly = synth_with("staging", drRegion="eu-west-1")
    artifact = assembly.get_stack_by_name("meridian-staging-dr")
    assert artifact.environment.region == "eu-west-1"


def test_the_data_template_pins_no_region_of_its_own() -> None:
    """The `data` stack is region-agnostic: every ARN it composes for its own region uses
    the `AWS::Region` pseudo-parameter, so the same template deploys anywhere. The one
    literal region in it is `drRegion`, which is a deliberate cross-region reference."""
    template = data("staging").to_json()
    rendered = json.dumps(template)
    assert "us-east-1" not in rendered
    assert '"Ref": "AWS::Region"' in rendered
    # The only literal region is `drRegion`, and it appears only inside backup-vault
    # ARNs — the copy destination and the output that names it for the restore drill —
    # and, since Codex G-H2, as the `ReplicaRegions` of the PHI HMAC secret.
    for fragment in re.findall(r".{60}us-west-2", rendered):
        lowered = fragment.lower()
        assert "backup" in lowered or "copy" in lowered or "replicaregions" in lowered, fragment


# ------------------------------------------------------------------ outputs


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_outputs_the_compute_stack_will_import(env_name: str) -> None:
    """The `S3_REQUIRED_ENV` mapping (`src/settings.py`), as exports the Phase 5a task
    definition can `Fn::ImportValue`."""
    outputs = data(env_name).find_outputs("*")
    for name in (
        "DatabaseEndpoint",
        "ArtifactsBucketName",
        "PhiBucketName",
        "AuditBucketName",
        "ArtifactsKeyArn",
        "PhiKeyArn",
        "DbAppSecretArn",
        "DbPhiSecretArn",
        "PhiHmacKeyArn",
        "BackupVaultName",
    ):
        assert name in outputs, name
        assert outputs[name]["Export"]["Name"] == f"meridian-{env_name}-data-{name}"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_no_output_carries_a_password(env_name: str) -> None:
    """A CloudFormation output is readable by anyone who can call `DescribeStacks`.
    `MERIDIAN_DATABASE_URL` therefore is not one: it is assembled in the task definition
    from a `secretsmanager` dynamic reference, which CloudFormation resolves at deploy
    time and never prints."""
    outputs = data(env_name).find_outputs("*")
    body = json.dumps(outputs)
    # A dynamic reference in an output would be resolved into the output's *value*.
    assert "resolve:secretsmanager" not in body
    # Every secret-shaped output is an ARN, which is a name, not a credential.
    for name, output in outputs.items():
        if "Secret" in name or "HmacKey" in name:
            assert "Ref" in output["Value"] or "Fn::GetAtt" in output["Value"], name


# --------------------------------------------------------------- whole-stack


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_resource_in_the_stack_carries_the_six_tags(env_name: str) -> None:
    template = data(env_name)
    required = ("Project", "Environment", "Owner", "DataClassification", "CostCenter", "ManagedBy")
    checked = 0
    for name, resource in template.to_json()["Resources"].items():
        tags = resource.get("Properties", {}).get("Tags")
        if not isinstance(tags, list) or not tags or not isinstance(tags[0], dict):
            continue
        assert {tag.get("Key") for tag in tags}.issuperset(required), name
        checked += 1
    assert checked > 5


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_phi_resources_are_classified_phi(env_name: str) -> None:
    """The tag is load-bearing twice over: the backup selection reads it, and so does
    every IAM condition that separates the environments (plan §2.4)."""
    template = data(env_name)

    def classification(resource: dict[str, Any]) -> str:
        # `AWS::Backup::BackupVault` spells its tags `BackupVaultTags`, and as a map
        # rather than a list — one of the handful of L1s with a bespoke tag property.
        props = resource["Properties"]
        tags = props.get("Tags", props.get("BackupVaultTags"))
        if isinstance(tags, dict):
            return str(tags["DataClassification"])
        return next(tag["Value"] for tag in tags if tag["Key"] == "DataClassification")

    assert classification(_instance(template)) == "phi"
    assert classification(_bucket(template, env_name, "phi")) == "phi"
    assert classification(_bucket(template, env_name, "artifacts")) == "internal"
    assert (
        classification(next(iter(_resources(template, "AWS::Backup::BackupVault").values())))
        == "phi"
    )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_synthesizes_twice_byte_identical(env_name: str) -> None:
    """A template that differs between two synths of the same code makes `cdk diff`
    useless, and `cdk diff` reporting no changes is the whole check at the end of the
    staging-teardown runbook. Generated names, timestamps and set iteration order are the
    usual culprits."""
    first = json.dumps(data(env_name).to_json(), sort_keys=True)
    second = json.dumps(data(env_name).to_json(), sort_keys=True)
    assert first == second


# ---------------------------------------------------------------------------
# The Phase 10 archive bucket
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_archive_bucket_is_object_locked_on_the_phi_key(env_name: str) -> None:
    """The Supabase archive is PHI, so it cannot live in the `internal` audit bucket.

    `audit` is on the `logs` CMK and tagged `internal` on purpose (ADR 0020 §4).
    A seven-year compliance-mode lock is not a mistake anyone can take back, so
    the classification has to be right before the first object lands.
    """
    props = _bucket(data(env_name), env_name, "archive")["Properties"]
    assert props["ObjectLockEnabled"] is True
    retention = props["ObjectLockConfiguration"]["Rule"]["DefaultRetention"]
    assert retention["Mode"] == "COMPLIANCE"
    assert retention["Days"] == 365 * 7
    assert props["VersioningConfiguration"]["Status"] == "Enabled"
    encryption = props["BucketEncryption"]["ServerSideEncryptionConfiguration"][0]
    assert encryption["BucketKeyEnabled"] is True
    assert encryption["ServerSideEncryptionByDefault"]["SSEAlgorithm"] == "aws:kms"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_archive_bucket_carries_no_expiry_lifecycle(env_name: str) -> None:
    """A lifecycle expiry on a locked object is a rule that cannot fire."""
    props = _bucket(data(env_name), env_name, "archive")["Properties"]
    rules = props.get("LifecycleConfiguration", {}).get("Rules", [])
    assert [rule["Id"] for rule in rules] == ["abort-incomplete-uploads"]
    for rule in rules:
        assert "ExpirationInDays" not in rule
        assert "NoncurrentVersionExpiration" not in rule


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_archive_bucket_is_classified_phi_and_retained(env_name: str) -> None:
    bucket = _bucket(data(env_name), env_name, "archive")
    tags = {tag["Key"]: tag["Value"] for tag in bucket["Properties"].get("Tags", [])}
    assert tags["DataClassification"] == "phi"
    assert bucket["DeletionPolicy"] == "Retain"


# ---------------------------------------------- CX-INF-04: which groups a key admits


def _logs_service_condition(template: assertions.Template, purpose: str) -> list[str]:
    """The `aws:logs:arn` patterns on one CMK's CloudWatch Logs statement, as text."""
    keys = [
        body
        for logical_id, body in _resources(template, "AWS::KMS::Key").items()
        if logical_id.startswith(f"Key{purpose.capitalize()}")
    ]
    assert len(keys) == 1, f"expected one {purpose} key"
    (statement,) = [
        s
        for s in keys[0]["Properties"]["KeyPolicy"]["Statement"]
        if s.get("Sid") == "AllowCloudWatchLogsToUseThisKey"
    ]
    values = statement["Condition"]["ArnLike"]["kms:EncryptionContext:aws:logs:arn"]
    values = values if isinstance(values, list) else [values]
    return [json.dumps(value) for value in values]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
@pytest.mark.parametrize("purpose", ["logs", "phi"])
def test_the_log_keys_admit_this_environments_groups_and_no_others(
    env_name: str, purpose: str
) -> None:
    """CX-INF-04: never `log-group:*`, never the other environment's names."""
    other = "production" if env_name == "staging" else "staging"
    values = _logs_service_condition(data(env_name), purpose)
    expected = (
        logs_key_log_group_patterns(env_name)
        if purpose == "logs"
        else phi_key_log_group_patterns(env_name)
    )
    assert len(values) == len(expected)
    for value, pattern in zip(values, expected, strict=True):
        assert f"log-group:{pattern}" in value
        assert not value.rstrip('"').endswith("log-group:*"), value
        assert other not in value and f"cwsyn-{other[:4]}" not in value, value


def test_the_phi_key_admits_only_the_two_rds_exports() -> None:
    values = _logs_service_condition(data("production"), "phi")
    assert len(values) == 1
    assert "/aws/rds/instance/meridian-production-rds-main/*" in values[0]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_every_cmk_encrypted_log_group_is_one_its_key_admits(env_name: str) -> None:
    """Walk every log group in every synthesized stack; each must match its key's list.

    A name the key does not admit is a group CloudWatch Logs refuses to create, so this
    is the test that finds a drifted name before a deploy does. The canary is switched on
    so its resources are in the walk too. The webhook sender's group is behind
    `enableApiPlatform`, whose bundling needs Docker, so its name is checked directly.
    """
    patterns = {
        "logs": logs_key_log_group_patterns(env_name),
        "phi": phi_key_log_group_patterns(env_name),
    }
    assembly = synth_with(
        env_name,
        cloudfrontPrefixListId="pl-0aaaaaaaaaaaaaaaa",
        hostedZoneId="Z0AAAAAABBBBBBCCCCCC",
        **{CANARY_CONTEXT_FLAG: True},
    )
    checked = 0
    for artifact in assembly.stacks:
        if not artifact.stack_name.startswith(f"meridian-{env_name}-"):
            continue
        for logical_id, resource in artifact.template.get("Resources", {}).items():
            if resource["Type"] != "AWS::Logs::LogGroup":
                continue
            key_ref = json.dumps(resource["Properties"].get("KmsKeyId", ""))
            purpose = "phi" if "KeyPhi" in key_ref else "logs" if "KeyLogs" in key_ref else None
            if purpose is None:
                continue
            name = resource["Properties"]["LogGroupName"]
            assert isinstance(name, str), f"{artifact.stack_name}/{logical_id}: token name"
            assert any(fnmatch.fnmatchcase(name, p) for p in patterns[purpose]), (
                f"{artifact.stack_name}/{logical_id} ({name}) is on the {purpose} key, "
                f"whose policy admits only {patterns[purpose]}"
            )
            checked += 1
    assert checked >= 8, f"only {checked} CMK log groups found — did the walk break?"

    sender_group = f"/aws/lambda/{webhook_sender_name(env_name)}"
    assert any(fnmatch.fnmatchcase(sender_group, p) for p in patterns["logs"])


def test_the_malware_plan_waits_for_its_role_policy_and_the_bucket_policy() -> None:
    """GuardDuty validates the role when the plan is created; a plan created before the
    role's DefaultPolicy or the phi bucket policy fails (2026-10-03)."""
    plan = next(iter(_resources(data("staging"), "AWS::GuardDuty::MalwareProtectionPlan").values()))
    depends = set(plan.get("DependsOn", []))
    assert any(k.startswith("MalwareProtectionRoleDefaultPolicy") for k in depends)
    assert any(k.startswith("BucketPhiPolicy") for k in depends)


# ---------------------------------------------------------------------------
# ECR (moved from compute, 2026-10-05)
# ---------------------------------------------------------------------------
def test_there_are_two_repositories():
    names = sorted(
        body["Properties"]["RepositoryName"]
        for body in _resources(data("staging"), "AWS::ECR::Repository").values()
    )
    assert names == ["meridian-staging-ecr-api", "meridian-staging-ecr-web"]


def test_image_tags_are_immutable():
    """A mutable tag means "which code is running" is unanswerable.

    The same `v1.4` can be re-pushed over the image a deploy approved and
    nothing in the console would show it.
    """
    for body in _resources(data("staging"), "AWS::ECR::Repository").values():
        assert body["Properties"]["ImageTagMutability"] == "IMMUTABLE"


def test_images_are_scanned_on_push():
    for body in _resources(data("staging"), "AWS::ECR::Repository").values():
        assert body["Properties"]["ImageScanningConfiguration"] == {"ScanOnPush": True}


def test_only_ten_images_are_kept():
    for body in _resources(data("staging"), "AWS::ECR::Repository").values():
        policy = json.loads(body["Properties"]["LifecyclePolicy"]["LifecyclePolicyText"])
        assert len(policy["rules"]) == 1
        rule = policy["rules"][0]
        assert rule["selection"]["countNumber"] == 10
        assert rule["action"]["type"] == "expire"


def test_repositories_survive_a_staging_teardown():
    """Destroying a repository destroys every image in it, including a good one."""
    for body in _resources(data("staging"), "AWS::ECR::Repository").values():
        assert body["DeletionPolicy"] == "Retain"
