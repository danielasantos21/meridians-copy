"""The six mandatory tags, and the Aspect that enforces them.

The negative test is the important one: a tagging rule nobody has watched fail
is a rule nobody knows is broken.
"""

from __future__ import annotations

import aws_cdk as cdk
import pytest
from aws_cdk import aws_s3 as s3
from aws_cdk import cx_api

from meridian.tags import REQUIRED_TAG_KEYS, RequiredTagsAspect, common_tags


def _synthesis_errors(assembly: cx_api.CloudAssembly, stack_name: str) -> list[str]:
    """Error-level annotations the CDK CLI turns into a failed `cdk synth`.

    `App.synth()` in-process records them as `aws:cdk:error` messages rather
    than raising; it is the CLI that refuses to write a cloud assembly when any
    are present. So this is the same failure CI sees, read from the inside.
    """
    return [
        str(message.entry.data)
        for message in assembly.get_stack_by_name(stack_name).messages
        if message.entry.type == "aws:cdk:error"
    ]


def _tag_map(resource: dict[str, object]) -> dict[str, str] | None:
    props = resource.get("Properties")
    if not isinstance(props, dict):
        return None
    tags = props.get("Tags")
    if not isinstance(tags, list):
        return None
    out: dict[str, str] = {}
    for item in tags:
        if isinstance(item, dict) and "Key" in item:
            out[str(item["Key"])] = str(item["Value"])
    return out


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_every_tagged_resource_carries_all_six_tags(
    env_name: str,
    staging: cx_api.CloudAssembly,
    production: cx_api.CloudAssembly,
) -> None:
    assembly = staging if env_name == "staging" else production
    checked = 0
    for artifact in assembly.stacks:
        for name, resource in artifact.template.get("Resources", {}).items():
            tags = _tag_map(resource)
            if tags is None:
                continue
            checked += 1
            missing = [key for key in REQUIRED_TAG_KEYS if key not in tags]
            assert not missing, f"{artifact.stack_name}/{name} missing {missing}"
            assert tags["ManagedBy"] == "cdk"
            assert tags["Project"] == "meridian"
            assert tags["DataClassification"] in ("phi", "internal", "public")
    assert checked > 20, "the sweep found suspiciously few taggable resources"


def test_environment_tag_matches_the_stack(staging: cx_api.CloudAssembly) -> None:
    for artifact in staging.stacks:
        expected = "shared" if "shared" in artifact.stack_name else "staging"
        for resource in artifact.template.get("Resources", {}).values():
            tags = _tag_map(resource)
            if tags:
                assert tags["Environment"] == expected


def test_phi_classification_is_only_on_data_stack_keys(
    production: cx_api.CloudAssembly,
) -> None:
    """`phi` is a claim about what a resource holds, not a default.

    Nothing in the foundation stack may carry it: it holds audit records *about*
    PHI access, not PHI.
    """
    foundation = production.get_stack_by_name("meridian-shared-foundation").template
    for name, resource in foundation.get("Resources", {}).items():
        tags = _tag_map(resource)
        if tags:
            assert tags["DataClassification"] == "internal", name

    data = production.get_stack_by_name("meridian-production-data").template
    phi_tagged = [
        name
        for name, resource in data.get("Resources", {}).items()
        if (tags := _tag_map(resource)) and tags["DataClassification"] == "phi"
    ]
    assert phi_tagged, "the rds, phi and backups keys are phi-classified"


def test_aspect_fails_synthesis_on_an_untagged_resource() -> None:
    """The deliberately untagged resource the plan's Phase 1 verify step asks for."""
    app = cdk.App()
    stack = cdk.Stack(app, "Untagged")
    s3.Bucket(stack, "NakedBucket")
    cdk.Aspects.of(app).add(RequiredTagsAspect(), priority=cdk.AspectPriority.READONLY)

    errors = _synthesis_errors(app.synth(), "Untagged")
    assert errors, "an untagged bucket must fail synthesis"
    assert "missing required tag" in errors[0]
    for key in REQUIRED_TAG_KEYS:
        assert key in errors[0]


def test_aspect_passes_once_the_six_tags_are_applied() -> None:
    app = cdk.App()
    stack = cdk.Stack(app, "Tagged")
    s3.Bucket(stack, "DressedBucket")
    for key, value in common_tags(
        "staging", owner="meridian-platform", cost_center="meridian"
    ).items():
        cdk.Tags.of(stack).add(key, value)
    cdk.Tags.of(stack).add("DataClassification", "internal")
    cdk.Aspects.of(app).add(RequiredTagsAspect(), priority=cdk.AspectPriority.READONLY)

    assert _synthesis_errors(app.synth(), "Tagged") == []


def test_aspect_rejects_an_unknown_data_classification() -> None:
    app = cdk.App()
    stack = cdk.Stack(app, "Misclassified")
    s3.Bucket(stack, "Bucket")
    for key, value in common_tags(
        "staging", owner="meridian-platform", cost_center="meridian"
    ).items():
        cdk.Tags.of(stack).add(key, value)
    cdk.Tags.of(stack).add("DataClassification", "confidential")
    cdk.Aspects.of(app).add(RequiredTagsAspect(), priority=cdk.AspectPriority.READONLY)

    errors = _synthesis_errors(app.synth(), "Misclassified")
    assert errors and "DataClassification" in errors[0]
