"""`meridian-<env>-auth`: the Cognito pool, its clients, and the migration trigger.

Every assertion here is a control with a consequence, not a shape:

  * MFA `ON` and TOTP-only — the gap the threat model calls G-4, and the reason
    SMS is off is that a second factor an attacker can have ported to their own
    handset is not one;
  * `custom:app_uid` **immutable** — a mutable link between a token and 30 tables
    of application rows is the UUID rewrite ADR 0003 deleted from the plan;
  * deletion protection — deleting a pool deletes every user and every MFA
    enrolment in it, and there is no restore;
  * no plaintext secret anywhere in the template — the IdP credentials are
    `{{resolve:secretsmanager:...}}` dynamic references, resolved at deploy;
  * the trigger is attached, invocable, outside the VPC and capped at 5 seconds —
    Cognito abandons a migration trigger at about that, and a VPC Lambda pays ENI
    attachment on a cold start it cannot afford.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import pytest
from aws_cdk import assertions
from aws_cdk import aws_logs as logs
from conftest import NETWORK_CONTEXT, data_template, stack_template, synth_with

from meridian.stacks.auth import (
    APP_UID_MAX_LENGTH,
    COGNITO_EXPORT_MODULE,
    COGNITO_EXPORT_PREFIX,
    ID_TOKEN_VALIDITY,
    LEGACY_SECRET_ARN_ENV,
    LOG_RETENTION,
    MACHINE_SCOPES,
    MACHINE_TOKEN_VALIDITY,
    MIGRATION_TIMEOUT,
    MIN_PASSWORD_LENGTH,
    REFRESH_TOKEN_VALIDITY,
    RESOURCE_SERVER_IDENTIFIER,
)
from meridian.stacks.data import OBJECT_LOCK_RETENTION_DAYS

ENVIRONMENTS = ("staging", "production")

#: What CloudFormation writes in place of a secret value.
DYNAMIC_REFERENCE = "{{" + "resolve:secretsmanager:"


def auth(env: str, **context: object) -> assertions.Template:
    return stack_template(env, "auth", **context)


def _resources(template: assertions.Template, type_name: str) -> Mapping[str, Any]:
    return template.find_resources(type_name)


def _pool(template: assertions.Template) -> dict[str, Any]:
    pools = _resources(template, "AWS::Cognito::UserPool")
    assert len(pools) == 1, "one pool per environment"
    return next(iter(pools.values()))


def _client(template: assertions.Template, env: str, purpose: str) -> dict[str, Any]:
    return next(
        client["Properties"]
        for client in _resources(template, "AWS::Cognito::UserPoolClient").values()
        if client["Properties"]["ClientName"] == f"meridian-{env}-auth-{purpose}"
    )


def _function(template: assertions.Template, purpose: str = "user-migration") -> dict[str, Any]:
    """One of the stack's two Lambdas (user-migration, cognito-export), by name."""
    functions = [
        body["Properties"]
        for body in _resources(template, "AWS::Lambda::Function").values()
        if body["Properties"].get("FunctionName", "").endswith(f"-lambda-{purpose}")
    ]
    assert len(functions) == 1
    return functions[0]


def _named(
    template: assertions.Template, type_name: str, prop: str, value: str
) -> dict[str, dict[str, Any]]:
    return {
        logical_id: body
        for logical_id, body in _resources(template, type_name).items()
        if body["Properties"].get(prop) == value
    }


# ------------------------------------------------------------------- the pool
@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_pool_is_named_per_environment(env_name: str) -> None:
    assert _pool(auth(env_name))["Properties"]["UserPoolName"] == f"meridian-{env_name}-auth-users"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_invitation_carries_both_placeholders_and_this_environments_link(env_name: str) -> None:
    """Cognito rejects the whole pool update without `{username}` and `{####}`."""
    template = _pool(auth(env_name))["Properties"]["AdminCreateUserConfig"]["InviteMessageTemplate"]
    body = template["EmailMessage"]
    assert "{username}" in body and "{####}" in body
    assert "__HOST__" not in body and len(body) <= 20000
    host = "staging-app" if env_name == "staging" else "app"
    assert f"https://{host}.meridiansgrp.com/login" in body


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_mfa_is_on_and_totp_is_the_only_factor(env_name: str) -> None:
    """Gap G-4 closes here. `SMS_MFA` is absent on purpose: a phone number can be
    ported to somebody else's handset, and every message costs money."""
    props = _pool(auth(env_name))["Properties"]
    assert props["MfaConfiguration"] == "ON"
    assert props["EnabledMfas"] == ["SOFTWARE_TOKEN_MFA"]


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_a_remembered_browser_skips_the_code_and_a_new_one_does_not(env_name: str) -> None:
    """Device tracking: a confirmed device is remembered without a prompt, and
    only a remembered device may skip the TOTP code."""
    props = _pool(auth(env_name))["Properties"]
    assert props["DeviceConfiguration"] == {
        "ChallengeRequiredOnNewDevice": True,
        "DeviceOnlyRememberedOnUserPrompt": False,
    }


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_app_uid_attribute_is_a_36_character_immutable_string(env_name: str) -> None:
    """`claims.get('custom:app_uid') or claims['sub']` is only safe if the
    attribute cannot change under the rows that are keyed on it."""
    schema = _pool(auth(env_name))["Properties"]["Schema"]
    app_uid = next(entry for entry in schema if entry["Name"] == "app_uid")
    assert app_uid["AttributeDataType"] == "String"
    assert app_uid["Mutable"] is False
    assert app_uid["StringAttributeConstraints"]["MaxLength"] == str(APP_UID_MAX_LENGTH) == "36"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_deletion_protection_is_active_in_both_environments(env_name: str) -> None:
    """Unlike the RDS instance, which staging may destroy. There is no restore for
    a Cognito pool: the users, and every MFA enrolment, go with it."""
    pool = _pool(auth(env_name))
    assert pool["Properties"]["DeletionProtection"] == "ACTIVE"
    assert pool["DeletionPolicy"] == "Retain"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_threat_protection_audits_on_the_plus_tier(env_name: str) -> None:
    """`AUDIT`, not `ENFORCED`. Enforcement blocks a sign-in on a risk score
    nobody has calibrated, and a two-person workforce on a new network looks
    exactly like the thing it would block. `PLUS` is the cheapest tier that can
    express any threat protection at all (~$0.02/MAU, under $1/month here)."""
    props = _pool(auth(env_name))["Properties"]
    assert props["UserPoolAddOns"]["AdvancedSecurityMode"] == "AUDIT"
    assert props["UserPoolTier"] == "PLUS"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_nobody_can_sign_themselves_up(env_name: str) -> None:
    """P-6: membership is by invite code plus `AdminCreateUser`. The hosted
    domain is reachable by anyone, so this is the only thing standing between the
    internet and an account in the pool."""
    props = _pool(auth(env_name))["Properties"]
    assert props["AdminCreateUserConfig"]["AllowAdminCreateUserOnly"] is True


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_password_policy_is_twelve_characters_and_all_four_classes(env_name: str) -> None:
    policy = _pool(auth(env_name))["Properties"]["Policies"]["PasswordPolicy"]
    assert policy["MinimumLength"] == MIN_PASSWORD_LENGTH == 12
    assert policy["RequireLowercase"] is True
    assert policy["RequireUppercase"] is True
    assert policy["RequireNumbers"] is True
    assert policy["RequireSymbols"] is True


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_email_goes_through_the_phase_1_ses_identity(env_name: str) -> None:
    """`DEVELOPER` sending mode, on the account's own verified domain and its
    configuration set. Cognito's built-in mailbox is capped at 50 messages a day
    and does not carry our DKIM, so a password reset from it is a deliverability
    problem waiting for the morning of the flip."""
    email = _pool(auth(env_name))["Properties"]["EmailConfiguration"]
    assert email["EmailSendingAccount"] == "DEVELOPER"
    assert "SourceArn" in email
    # Imported from the shared dns stack, not written out as a literal.
    rendered = json.dumps(email)
    assert "meridian-shared-dns" in rendered
    assert "ConfigurationSet" in email


# ---------------------------------------------------------------- the clients
@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_web_client_is_confidential_and_uses_the_admin_flow(env_name: str) -> None:
    """`generate_secret` is what makes `ADMIN_USER_PASSWORD_AUTH` available, and
    that flow is what lets the User Migration Lambda run — which is the whole
    reason nobody has to reset their password at the flip."""
    props = _client(auth(env_name), env_name, "web")
    assert props["GenerateSecret"] is True
    assert set(props["ExplicitAuthFlows"]) == {
        "ALLOW_ADMIN_USER_PASSWORD_AUTH",
        "ALLOW_REFRESH_TOKEN_AUTH",
    }
    assert props["PreventUserExistenceErrors"] == "ENABLED"
    assert props["EnableTokenRevocation"] is True


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_token_lifetimes_are_the_ones_adr_0021_names(env_name: str) -> None:
    """60-minute ID token, 30-day refresh. The refresh figure revises ADR 0003's
    12 hours: with MFA `ON` and revocation enabled, a 12-hour refresh means a TOTP
    challenge every morning, and that is how MFA gets switched off."""
    props = _client(auth(env_name), env_name, "web")
    assert props["IdTokenValidity"] == ID_TOKEN_VALIDITY.to_minutes() == 60
    assert props["AccessTokenValidity"] == 60
    assert props["RefreshTokenValidity"] == REFRESH_TOKEN_VALIDITY.to_minutes() == 43200
    assert props["TokenValidityUnits"]["IdToken"] == "minutes"


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_machine_client_is_client_credentials_with_fifteen_minute_tokens(
    env_name: str,
) -> None:
    """Nothing renews a machine token interactively and nobody notices when one
    leaks, so the lifetime is the control."""
    props = _client(auth(env_name), env_name, "machine")
    assert props["AllowedOAuthFlows"] == ["client_credentials"]
    assert props["AccessTokenValidity"] == MACHINE_TOKEN_VALIDITY.to_minutes() == 15
    assert props["GenerateSecret"] is True
    assert "RefreshTokenValidity" not in props


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_resource_server_carries_no_phi_scope(env_name: str) -> None:
    """A `phi:read` scope arrives with the partner API in Phase 12 (ADR 0002).
    Defining it now would be a scope nothing checks that reads as though it
    grants everything."""
    servers = _resources(auth(env_name), "AWS::Cognito::UserPoolResourceServer")
    assert len(servers) == 1
    props = next(iter(servers.values()))["Properties"]
    assert props["Identifier"] == RESOURCE_SERVER_IDENTIFIER
    names = [scope["ScopeName"] for scope in props["Scopes"]]
    assert names == [name for name, _description in MACHINE_SCOPES]
    assert not any("phi" in name for name in names)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_hosted_domain_is_meridian_dash_env(env_name: str) -> None:
    domains = _resources(auth(env_name), "AWS::Cognito::UserPoolDomain")
    assert len(domains) == 1
    assert next(iter(domains.values()))["Properties"]["Domain"] == f"meridian-{env_name}"


# -------------------------------------------------- the User Migration Lambda
@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_migration_trigger_is_attached_and_invocable(env_name: str) -> None:
    """Both halves. A trigger the service may not invoke fails every sign-in with
    an error that says nothing about permissions."""
    template = auth(env_name)
    assert "UserMigration" in _pool(template)["Properties"]["LambdaConfig"]

    permissions = _named(
        template, "AWS::Lambda::Permission", "Principal", "cognito-idp.amazonaws.com"
    )
    assert len(permissions) == 1
    props = next(iter(permissions.values()))["Properties"]
    assert props["Principal"] == "cognito-idp.amazonaws.com"
    assert props["Action"] == "lambda:InvokeFunction"
    # Scoped to this pool, not to any Cognito pool in the account.
    assert props["SourceArn"]["Fn::GetAtt"][0].startswith("UserPool")


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_lambda_is_python_312_five_seconds_and_outside_the_vpc(env_name: str) -> None:
    """The three numbers ADR 0003 fixes. `VpcConfig` absent is the load-bearing
    one: an ENI attachment on a cold start does not fit in 5 seconds, and this
    function is cold almost every time it runs."""
    props = _function(auth(env_name))
    assert props["Runtime"] == "python3.12"
    assert props["Timeout"] == MIGRATION_TIMEOUT.to_seconds() == 5
    assert "VpcConfig" not in props
    # 128 MB spent 3-5 s of a cold start importing boto3 (staging, 2026-10-08).
    assert props["MemorySize"] >= 1024


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_lambda_log_group_is_retained_and_on_the_internal_cmk(env_name: str) -> None:
    """The real Lambda logs an email **domain** and a status. That is internal
    data on a 400-day retention, so it is encrypted with a key we own and every
    `Decrypt` of it is a CloudTrail event naming that key."""
    groups = _named(
        auth(env_name),
        "AWS::Logs::LogGroup",
        "LogGroupName",
        f"/aws/lambda/meridian-{env_name}-lambda-user-migration",
    )
    assert len(groups) == 1
    group = next(iter(groups.values()))
    props = group["Properties"]
    assert LOG_RETENTION is logs.RetentionDays.THIRTEEN_MONTHS
    assert props["RetentionInDays"] == 400
    assert "KmsKeyId" in props, "the log group must be on the environment's CMK"
    # Imported from the environment's `data` stack, which is where every CMK
    # lives so that a staging teardown cannot schedule one for deletion.
    assert f"meridian-{env_name}-data" in json.dumps(props["KmsKeyId"])
    assert group["DeletionPolicy"] == "Retain"


def test_the_lambda_fails_closed_without_naming_credentials() -> None:
    """The message is the control, so it is imported and asserted, not grepped.

    A user whose account has not been migrated has done nothing wrong, and
    "invalid credentials" sends them to a password reset that cannot help them.
    The same text is correct when Supabase is unreachable: a failure to *check* a
    credential is not a failure *of* one. And it is what a deploy without a
    freshly generated `legacy_users.json` produces, which is what this asserts —
    the file is gitignored, so in this repository it is normally absent.

    The behaviour of the handler itself is `tests/test_user_migration_lambda.py`;
    what belongs here is the one property the *stack* depends on.
    """
    import importlib.util
    import pathlib

    handler_path = (
        pathlib.Path(__file__).resolve().parents[2] / "lambda" / "user_migration" / "handler.py"
    )
    spec = importlib.util.spec_from_file_location("user_migration_handler", handler_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    assert "temporarily unavailable" in module.UNAVAILABLE.lower()
    assert "credential" not in module.UNAVAILABLE.lower()
    assert "password" not in module.UNAVAILABLE.lower()

    # The snapshot is gitignored, but a developer who has just generated one
    # would otherwise see this test invert.
    setattr(module, "_snapshot_path", lambda: pathlib.Path("/nonexistent/legacy_users.json"))
    with pytest.raises(RuntimeError, match="temporarily unavailable"):
        module.handler({"triggerSource": "UserMigration_Authentication"}, None)


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_lambda_is_handed_a_secret_arn_and_never_a_credential(env_name: str) -> None:
    """The environment variable is the ARN; the values are fetched at cold start.

    A Lambda environment variable is readable by anyone holding
    `lambda:GetFunctionConfiguration`, so the anon key must not be one. The ARN
    is not a credential, and it arrives as a CloudFormation reference rather than
    a literal because the secret is created in this same stack.
    """
    template = auth(env_name)
    variables = _function(template)["Environment"]["Variables"]
    assert set(variables) == {LEGACY_SECRET_ARN_ENV}
    assert isinstance(variables[LEGACY_SECRET_ARN_ENV], dict), "the ARN is a Ref, not a literal"

    rendered = json.dumps(_function(template))
    assert "SUPABASE_ANON_KEY" not in rendered
    assert "supabase.co" not in rendered


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_lambda_role_may_read_that_one_secret_and_nothing_else(env_name: str) -> None:
    """One action, one ARN, plus the log permissions every Lambda has.

    The grant is written by hand precisely so this assertion can be this strict:
    `secret.grant_read()` would also add `secretsmanager:DescribeSecret`, and a
    role that can describe secrets is a role that can enumerate them.
    """
    template = auth(env_name)
    secret_logical_ids = {
        logical_id
        for logical_id, secret in _resources(template, "AWS::SecretsManager::Secret").items()
        if secret["Properties"]["Name"] == f"meridian-{env_name}/legacy-supabase-auth"
    }
    assert len(secret_logical_ids) == 1
    legacy_secret = next(iter(secret_logical_ids))

    secretsmanager_actions: list[str] = []
    for policy in _resources(template, "AWS::IAM::Policy").values():
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]:
            actions = statement["Action"]
            for action in actions if isinstance(actions, list) else [actions]:
                if action.startswith("logs:"):
                    continue
                assert action.startswith("secretsmanager:"), (
                    f"the auth stack's roles have grown an unrelated permission: {action}"
                )
                secretsmanager_actions.append(action)
                # And it points at the legacy secret, not at `*`.
                assert legacy_secret in json.dumps(statement["Resource"])
    assert secretsmanager_actions == ["secretsmanager:GetSecretValue"]


def test_the_snapshot_guard_is_off_by_default_and_fails_synth_when_asked(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Any
) -> None:
    """`legacy_users.json` is gitignored, so a deploy can silently ship without it.

    Without the flag, synth is unaffected — CI has no Supabase credentials and
    deploys nothing. With `-c requireLegacySnapshot=true`, a missing snapshot is
    a failed synth rather than a Lambda that fails every sign-in closed on the
    morning of the flip.

    The path is monkeypatched rather than read from the tree, because a
    developer who has just generated a real snapshot would otherwise see this
    test invert.
    """
    from meridian.stacks import auth as auth_stack

    monkeypatch.setattr(auth_stack, "LEGACY_SNAPSHOT_FILE", tmp_path / "absent.json")
    auth("staging")  # no flag: unaffected
    with pytest.raises(FileNotFoundError, match="snapshot_legacy_users"):
        auth("staging", requireLegacySnapshot="true")

    present = tmp_path / "legacy_users.json"
    present.write_text("{}", encoding="utf-8")
    monkeypatch.setattr(auth_stack, "LEGACY_SNAPSHOT_FILE", present)
    auth("staging", requireLegacySnapshot="true")


# ------------------------------------------------------------ the federated IdPs
@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_idp_secrets_exist_empty_and_the_providers_do_not(env_name: str) -> None:
    """The order ADR 0003 requires. Every federated identity is pre-created and
    pre-linked BEFORE its IdP is enabled — enabling one first auto-creates a
    duplicate empty account, and the only superadmin is Microsoft-only."""
    template = auth(env_name)
    secrets = _resources(template, "AWS::SecretsManager::Secret")
    names = sorted(secret["Properties"]["Name"] for secret in secrets.values())
    # One convention for every secret in the stack: `meridian-<env>/<purpose>`,
    # with a slash (see the note in `infra/meridian/naming.py`). Two conventions
    # inside one stack is how a runbook names a secret that does not exist.
    assert names == [
        # The one secret NOT filled in by a human: CloudFormation copies the web
        # client's secret into it (`Fn::GetAtt ClientSecret`) for the api task
        # (T:102). Asserted in test_compute.py; skipped by the emptiness check below.
        f"meridian-{env_name}/cognito-web-client",
        f"meridian-{env_name}/entra-idp",
        f"meridian-{env_name}/google-idp",
        # Not an IdP registration, but the same rule: created empty, and every
        # value in it is filled in by a human, never by this repository.
        f"meridian-{env_name}/legacy-supabase-auth",
    ]
    for secret in secrets.values():
        if secret["Properties"]["Name"].endswith("/cognito-web-client"):
            assert "Fn::GetAtt" in secret["Properties"]["SecretString"]
            continue
        # An empty JSON template: the field names the operator has to fill in,
        # and no value at all.
        assert json.loads(secret["Properties"]["SecretString"]) != {}
        assert set(json.loads(secret["Properties"]["SecretString"]).values()) == {""}

    assert _resources(template, "AWS::Cognito::UserPoolIdentityProvider") == {}
    assert _client(template, env_name, "web")["SupportedIdentityProviders"] == ["COGNITO"]


def _web_client_resource(template: assertions.Template) -> dict[str, Any]:
    return next(
        client
        for client in _resources(template, "AWS::Cognito::UserPoolClient").values()
        if client["Properties"]["ClientName"] == "meridian-staging-auth-web"
    )


def test_creating_the_idps_does_not_yet_offer_them_as_sign_in() -> None:
    """The state the linking step runs in, and it has to be reachable.

    `AdminLinkProviderForUser` needs the provider to EXIST on the pool — without
    it Cognito answers `InvalidParameterException` — while a user's first
    federated sign-in before their link exists auto-creates a duplicate empty
    account with no `custom:app_uid`. One flag doing both jobs made "link, then
    enable" impossible to execute; `googleIdp`/`entraIdp` create, and only
    `googleSignIn`/`entraSignIn` offer.
    """
    template = auth("staging", googleIdp="true", entraIdp="true")
    providers = _resources(template, "AWS::Cognito::UserPoolIdentityProvider")
    assert sorted(p["Properties"]["ProviderName"] for p in providers.values()) == [
        "Google",
        "Microsoft",
    ]
    assert sorted(p["Properties"]["ProviderType"] for p in providers.values()) == ["Google", "OIDC"]

    client = _web_client_resource(template)
    assert client["Properties"]["SupportedIdentityProviders"] == ["COGNITO"]
    # The dependency is written even here: the client has to be ordered after
    # the providers for the second deploy, and CDK does not write it itself.
    assert sorted(client["DependsOn"]) == sorted(providers)


def test_the_second_deploy_adds_the_providers_to_the_client() -> None:
    template = auth(
        "staging",
        googleIdp="true",
        entraIdp="true",
        googleSignIn="true",
        entraSignIn="true",
    )
    providers = _resources(template, "AWS::Cognito::UserPoolIdentityProvider")
    client = _web_client_resource(template)
    assert sorted(client["Properties"]["SupportedIdentityProviders"]) == [
        "COGNITO",
        "Google",
        "Microsoft",
    ]
    # CDK does not write this dependency itself; without it CloudFormation may
    # create the client before the provider it names.
    assert sorted(client["DependsOn"]) == sorted(providers)


@pytest.mark.parametrize(
    ("sign_in_key", "idp_key"),
    [("googleSignIn", "googleIdp"), ("entraSignIn", "entraIdp")],
)
def test_offering_a_provider_that_was_never_created_fails_synth(
    sign_in_key: str, idp_key: str
) -> None:
    """A client naming a provider that does not exist fails the deploy — after
    the stack has started changing. This one is a typo in a `-c` flag, so it is
    caught at synth."""
    with pytest.raises(ValueError, match=idp_key):
        auth("staging", **{sign_in_key: "true"})


def test_the_lambda_asset_excludes_the_example_snapshot_and_the_bytecode() -> None:
    """Read off the STAGED asset directory, not the template: the exclusions
    decide what is inside the zip, and the zip's contents never appear in the
    CloudFormation JSON.

    `__pycache__` makes the asset hash depend on whether anyone imported the
    handler locally, so an unchanged function redeploys and a changed one might
    not; `legacy_users.example.json` would ship a second, stale file of the same
    shape beside the real snapshot, inside the function whose entire job is
    deciding who is real.
    """
    assembly = synth_with("staging", **NETWORK_CONTEXT)
    # Other staged Lambdas have a `handler.py` too (the observability stack's log
    # governor, since the Phase 8 infra pass); the migration Lambda's is the one whose
    # handler is `lambda/user_migration/handler.py`, byte for byte.
    source = Path(__file__).resolve().parents[2] / "lambda" / "user_migration" / "handler.py"
    staged = [
        directory
        for directory in Path(assembly.directory).iterdir()
        if directory.is_dir()
        and (directory / "handler.py").exists()
        and (directory / "handler.py").read_bytes() == source.read_bytes()
    ]
    assert len(staged) == 1, "the migration Lambda's asset was not staged"
    names = {path.name for path in staged[0].rglob("*")}
    assert "handler.py" in names
    assert "legacy_users.example.json" not in names
    assert "__pycache__" not in names
    assert not any(name.endswith(".pyc") for name in names)


def test_the_idp_credentials_are_dynamic_references_and_never_literals() -> None:
    """The one test that would catch a client secret pasted into the repo.

    A `{{resolve:secretsmanager:...}}` string is a CloudFormation instruction, not
    a value: what is in the template is the *name* of a secret, and the value is
    fetched at deploy time. So every credential field must be a `Fn::Join`
    producing one of those, and never a plain string.
    """
    template = auth("staging", googleIdp="true", entraIdp="true")

    credential_fields = {"client_id", "client_secret", "oidc_issuer"}
    seen = set()
    for provider in _resources(template, "AWS::Cognito::UserPoolIdentityProvider").values():
        details = provider["Properties"]["ProviderDetails"]
        for field in credential_fields & set(details):
            value = details[field]
            assert isinstance(value, dict), (
                f"{field} is a literal string in the template; a credential has to be "
                "a Secrets Manager dynamic reference"
            )
            assert DYNAMIC_REFERENCE in json.dumps(value)
            seen.add(field)
    assert seen == credential_fields

    # And nothing anywhere else in the template holds a secret VALUE: the
    # placeholders are empty, and the web client's copy is a `GetAtt` that
    # CloudFormation resolves at deploy time (T:102) — never a literal.
    for secret in _resources(template, "AWS::SecretsManager::Secret").values():
        value = secret["Properties"]["SecretString"]
        if isinstance(value, dict):
            assert list(value) == ["Fn::GetAtt"] and value["Fn::GetAtt"][1] == "ClientSecret"
            continue
        assert set(json.loads(value).values()) == {""}


# -------------------------------------------- the callback URLs, per environment
def test_the_default_callback_url_is_this_environments_own_origin() -> None:
    """One default for both environments sent staging's sign-in to production.

    An allowed callback URL is where a real authorization code is delivered.
    Defaulting a non-production pool's callback to the production host crosses
    the two environments at the one moment a credential is in flight — which is
    worse than having no default at all.
    """
    assert _client(auth("staging"), "staging", "web")["CallbackURLs"] == [
        "https://staging-app.meridiansgrp.com/auth/callback"
    ]
    assert _client(auth("production"), "production", "web")["CallbackURLs"] == [
        "https://app.meridiansgrp.com/auth/callback"
    ]


def test_explicit_callback_urls_win_over_the_default() -> None:
    template = auth("staging", authCallbackUrls="https://a.example/cb,https://b.example/cb")
    assert _client(template, "staging", "web")["CallbackURLs"] == [
        "https://a.example/cb",
        "https://b.example/cb",
    ]


# ------------------------------------------------- the migration Lambda's role
def _migration_role(template: assertions.Template) -> dict[str, Any]:
    roles = _resources(template, "AWS::IAM::Role")
    # The migration Lambda's and the nightly export's (T:163) -- nothing else.
    assert {body["Properties"]["RoleName"].rsplit("-iam-", 1)[1] for body in roles.values()} == {
        "user-migration",
        "cognito-export",
    }
    return next(
        body["Properties"]
        for body in roles.values()
        if body["Properties"]["RoleName"].endswith("-iam-user-migration")
    )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_migration_lambda_logs_to_its_own_group_and_nothing_else(env_name: str) -> None:
    """No `AWSLambdaBasicExecutionRole`, and no `Resource: "*"` anywhere.

    CDK's default execution role grants `logs:*` on every log group in the
    account — including `audit` and the PHI-adjacent application groups — to a
    function whose only job is to check one password. The inline policy names
    this function's own group and stops there. `logs:CreateLogGroup` is absent
    too: the group is declared in the stack, with the retention and the CMK the
    estate requires, and a function that cannot create one cannot make a group
    outside that policy.
    """
    template = auth(env_name)
    role = _migration_role(template)
    assert role["RoleName"] == f"meridian-{env_name}-iam-user-migration"
    assert "ManagedPolicyArns" not in role

    statements = [
        statement
        for policy in role.get("Policies", [])
        for statement in policy["PolicyDocument"]["Statement"]
    ]
    assert all(
        action.startswith("logs:")
        for statement in statements
        for action in (
            statement["Action"] if isinstance(statement["Action"], list) else [statement["Action"]]
        )
    ), "the migration role's inline policy is its own log group and nothing else"
    # Anything CDK attaches later lands in a separate `AWS::IAM::Policy`; the
    # wildcard check has to cover that too or it checks the wrong document.
    statements += [
        statement
        for policy in _resources(template, "AWS::IAM::Policy").values()
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
    ]
    assert statements, "the role has no inline policy, so the Lambda cannot log at all"
    for statement in statements:
        resources = statement["Resource"]
        resources = resources if isinstance(resources, list) else [resources]
        assert "*" not in resources, f"wildcard resource in the migration role: {statement}"
        assert "logs:CreateLogGroup" not in statement["Action"]

    # And the role really is the function's.
    function = _function(template)
    role_ids = set(
        _named(template, "AWS::IAM::Role", "RoleName", f"meridian-{env_name}-iam-user-migration")
    )
    assert function["Role"]["Fn::GetAtt"][0] in role_ids


# ---------------------------------------------------------------------------
# The Phase 10 legacy-migration cut-off (`legacyMigration`)
# ---------------------------------------------------------------------------
def test_the_user_migration_trigger_is_wired_by_default() -> None:
    """Default true: the trigger is a live dependency of production sign-in."""
    template = auth("production")
    pools = template.find_resources("AWS::Cognito::UserPool")
    (pool,) = pools.values()
    assert "UserMigration" in pool["Properties"]["LambdaConfig"]
    functions = template.find_resources("AWS::Lambda::Function")
    assert any(
        body["Properties"].get("FunctionName") == "meridian-production-lambda-user-migration"
        for body in functions.values()
    )


def test_legacy_migration_false_removes_the_trigger_lambda_and_secret() -> None:
    """Phase 10 step 1, done in CloudFormation rather than in `update-user-pool`.

    The CLI form replaces the whole `LambdaConfig`, so a literal
    `--lambda-config '{}'` silently removes any other trigger too. Deploying the
    stack changes only the key CDK wrote, and the rollback is the flag back.
    """
    template = auth("production", legacyMigration="false")
    (pool,) = template.find_resources("AWS::Cognito::UserPool").values()
    assert "LambdaConfig" not in pool["Properties"]

    names = {
        body["Properties"].get("FunctionName")
        for body in template.find_resources("AWS::Lambda::Function").values()
    }
    assert "meridian-production-lambda-user-migration" not in names

    secrets = {
        body["Properties"].get("Name")
        for body in template.find_resources("AWS::SecretsManager::Secret").values()
    }
    assert "meridian-production/legacy-supabase-auth" not in secrets
    # The IdP secrets are not part of this cut-off and must survive it.
    assert "meridian-production/google-idp" in secrets or any(
        name and "idp" in name for name in secrets
    )


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_schema_holds_no_standard_attribute(env_name: str) -> None:
    """Any standard attribute in `Schema` fails every user-pool UPDATE (2026-10-05):
    the handler sends it to AddCustomAttributes. Only `app_uid` may be listed."""
    schema = _pool(auth(env_name))["Properties"]["Schema"]
    assert [entry["Name"] for entry in schema] == ["app_uid"]


# ---------------------------------------------- the nightly identity export (T:163)
def _export_role(template: assertions.Template, env_name: str) -> tuple[str, dict[str, Any]]:
    (item,) = _named(
        template, "AWS::IAM::Role", "RoleName", f"meridian-{env_name}-iam-cognito-export"
    ).items()
    return item[0], item[1]["Properties"]


def _statements(role: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        statement["Sid"]: statement
        for policy in role["Policies"]
        for statement in policy["PolicyDocument"]["Statement"]
    }


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_identity_export_runs_nightly_from_the_shared_script(env_name: str) -> None:
    """Decision D15: one export a night, per environment. The handler is
    `scripts/cognito_export.py`'s own -- the CLI and the Lambda are one module."""
    template = auth(env_name)
    props = _function(template, "cognito-export")
    assert props["FunctionName"] == f"meridian-{env_name}-lambda-cognito-export"
    assert props["Handler"] == f"{COGNITO_EXPORT_MODULE}.handler"
    # The same runtime as the user-migration Lambda; small and short.
    assert props["Runtime"] == _function(template)["Runtime"] == "python3.12"
    assert 128 <= props["MemorySize"] <= 256
    assert props["Timeout"] <= 300
    assert "VpcConfig" not in props
    variables = props["Environment"]["Variables"]
    assert set(variables) == {"USER_POOL_ID", "EXPORT_BUCKET", "EXPORT_KMS_KEY_ID"}
    assert variables["EXPORT_BUCKET"] == f"meridian-{env_name}-s3-archive"
    # The phi key's ARN, imported from `data` -- the archive bucket refuses any other key.
    assert "KeyPhi" in json.dumps(variables["EXPORT_KMS_KEY_ID"])

    (rule,) = _named(
        template, "AWS::Events::Rule", "Name", f"meridian-{env_name}-rule-cognito-export"
    ).values()
    assert rule["Properties"]["ScheduleExpression"] == "cron(0 6 * * ? *)"
    assert rule["Properties"]["State"] == "ENABLED"
    (target,) = rule["Properties"]["Targets"]
    function_id = next(
        logical_id
        for logical_id, body in _resources(template, "AWS::Lambda::Function").items()
        if body["Properties"]["FunctionName"].endswith("-lambda-cognito-export")
    )
    assert target["Arn"] == {"Fn::GetAtt": [function_id, "Arn"]}
    (permission,) = _named(
        template, "AWS::Lambda::Permission", "Principal", "events.amazonaws.com"
    ).values()
    assert permission["Properties"]["FunctionName"] == {"Fn::GetAtt": [function_id, "Arn"]}


@pytest.mark.parametrize("env_name", ENVIRONMENTS)
def test_the_identity_export_role_is_scoped_to_one_pool_one_prefix_one_key(env_name: str) -> None:
    """Least privilege, exactly: no wildcard action, no `Resource: "*"`, no managed
    policy, nothing attached outside the inline document."""
    template = auth(env_name)
    role_id, role = _export_role(template, env_name)
    assert "ManagedPolicyArns" not in role
    assert _function(template, "cognito-export")["Role"] == {"Fn::GetAtt": [role_id, "Arn"]}
    for policy in _resources(template, "AWS::IAM::Policy").values():
        assert role_id not in json.dumps(policy["Properties"]["Roles"])

    statements = _statements(role)
    assert {sid: statements[sid]["Action"] for sid in statements} == {
        "WriteOwnLogs": ["logs:CreateLogStream", "logs:PutLogEvents"],
        "ListThisPoolsUsers": "cognito-idp:ListUsers",
        "PutExportsOnly": "s3:PutObject",
        "EncryptWithThePhiKey": ["kms:GenerateDataKey", "kms:Encrypt"],
    }
    for statement in statements.values():
        actions = statement["Action"]
        assert not any("*" in a for a in (actions if isinstance(actions, list) else [actions]))
        resources = statement["Resource"]
        assert "*" not in (resources if isinstance(resources, list) else [resources])

    pool_id = next(iter(_resources(template, "AWS::Cognito::UserPool")))
    assert statements["ListThisPoolsUsers"]["Resource"] == {"Fn::GetAtt": [pool_id, "Arn"]}
    put = json.dumps(statements["PutExportsOnly"]["Resource"])
    assert f":s3:::meridian-{env_name}-s3-archive/{COGNITO_EXPORT_PREFIX}*" in put
    assert "KeyPhi" in json.dumps(statements["EncryptWithThePhiKey"]["Resource"])
    log_group = f"/aws/lambda/meridian-{env_name}-lambda-cognito-export"
    (group,) = _named(template, "AWS::Logs::LogGroup", "LogGroupName", log_group).values()
    assert group["Properties"]["RetentionInDays"] == 400
    assert f"meridian-{env_name}-data" in json.dumps(group["Properties"]["KmsKeyId"])


def test_the_export_lands_where_seven_years_is_already_enforced() -> None:
    """D15's seven years is the `archive` bucket's compliance-mode Object Lock, so the
    export needs no rule of its own -- but only while that stays true. The prefix
    is the script's, and the bucket keeps its lock, its key and no expiry."""
    import importlib.util

    script = Path(__file__).resolve().parents[2] / "scripts" / "cognito_export.py"
    spec = importlib.util.spec_from_file_location("cognito_export_for_infra", script)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.S3_PREFIX == COGNITO_EXPORT_PREFIX

    assert OBJECT_LOCK_RETENTION_DAYS >= 7 * 365
    for env_name in ENVIRONMENTS:
        data = data_template(env_name)
        (archive,) = _named(
            data, "AWS::S3::Bucket", "BucketName", f"meridian-{env_name}-s3-archive"
        ).values()
        lock = archive["Properties"]["ObjectLockConfiguration"]["Rule"]["DefaultRetention"]
        assert lock == {"Mode": "COMPLIANCE", "Days": OBJECT_LOCK_RETENTION_DAYS}
        rules = archive["Properties"]["LifecycleConfiguration"]["Rules"]
        assert not any("ExpirationInDays" in rule for rule in rules)


def test_the_export_asset_is_the_one_script() -> None:
    """The staged asset is `scripts/` filtered to `cognito_export.py`: no other script,
    no bytecode, nothing that holds an address."""
    assembly = synth_with("staging", **NETWORK_CONTEXT)
    source = Path(__file__).resolve().parents[2] / "scripts" / f"{COGNITO_EXPORT_MODULE}.py"
    staged = [
        directory
        for directory in Path(assembly.directory).iterdir()
        if directory.is_dir() and (directory / source.name).exists()
    ]
    assert len(staged) == 1, "the export Lambda's asset was not staged"
    assert (staged[0] / source.name).read_bytes() == source.read_bytes()
    assert sorted(path.name for path in staged[0].rglob("*")) == [source.name]
