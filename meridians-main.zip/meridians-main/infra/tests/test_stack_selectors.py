"""Every `cdk deploy|destroy|diff <name>` written down anywhere must resolve.

**The CDK CLI selects stacks by CONSTRUCT ID, not by `stack_name`.** For most of
this migration the two differed — the construct id was `Edge` and the stack name
was `meridian-production-edge` — so every runbook line that said

    npx cdk deploy meridian-production-edge

failed with `No stacks match the name(s) meridian-production-edge`, and so did
`.github/workflows/deploy.yml`'s deploy step and `scripts/staging_session.sh`.
None of it had ever been run, which is why nobody noticed (runbook critic round 2,
RBR2-01).

`infra/app.py` now gives every stack a construct id **equal to** its stack name,
which makes all of those selectors correct as written. This module is what keeps
them that way: it reads the selectors back out of the documents themselves, so a
new runbook that invents `meridian-production-network` fails here rather than at
3 a.m. in the middle of a cutover.

It asserts nothing about prose. It only looks at tokens that appear in the
argument position of a `cdk deploy` / `cdk destroy` / `cdk diff` command and that
start with `meridian-`, which is exactly the set the CLI would have to resolve.
"""

from __future__ import annotations

import re
from functools import cache
from pathlib import Path

import app as cdk_app
import aws_cdk as cdk
import pytest
from conftest import NO_IDENTITY_CENTER  # noqa: PLC2701 -- the suite's own helper

REPO_ROOT = Path(__file__).resolve().parents[2]

#: Where a `cdk` invocation may be written down. Anything else that grows one
#: should be added here rather than left unchecked.
SEARCHED_FILES: tuple[Path, ...] = (
    *sorted((REPO_ROOT / "docs" / "runbooks").glob("*.md")),
    *sorted((REPO_ROOT / ".github" / "workflows").glob("*.yml")),
    REPO_ROOT / "scripts" / "staging_session.sh",
)

#: `npx cdk deploy`, `cdk destroy`, `cdk diff` … up to the end of the command.
#: Shell and YAML line continuations are folded first (see `_selectors`), so a
#: multi-line `cdk destroy \` + four stack names is one match.
_COMMAND = re.compile(r"\bcdk\s+(?:deploy|destroy|diff)\b([^\n`]*)")

#: A stack selector: a bare `meridian-…` token. Placeholders (`<env>`, `${{ … }}`)
#: are expanded before this runs.
_SELECTOR = re.compile(r"(?<![\w/.-])meridian-[a-z0-9-]+(?![\w.-])")

#: What the documents write where a real environment name goes at run time. They are
#: rewritten to `_ENV_MARKER` before the selector regex runs — otherwise a `${{ … }}`
#: or a `$ENV` would simply break the token in half and the selector would be missed,
#: which is the failure mode this whole module exists to prevent.
_PLACEHOLDERS = (
    "${{ inputs.environment }}",
    "${{inputs.environment}}",
    "<env>",
    "${ENV_NAME}",
    "$ENV_NAME",
    "${ENV}",
    "$ENV",
)

#: Lowercase and hyphen-free so it survives `_SELECTOR` as an ordinary segment.
_ENV_MARKER = "envplaceholder"

#: `scripts/staging_session.sh` does not spell its stacks on the `cdk` line — it
#: passes `"${TRANSIENT_STACKS[@]}"`. Expanding bash array references from their
#: literal definition in the same file is what lets that script be checked at all,
#: and it is the file the check most needs to cover: it is the only one of the three
#: that runs unattended.
_ARRAY_REF = re.compile(r"\$\{(\w+)\[@\]\}")


@cache
def _construct_ids(env: str) -> frozenset[str]:
    """Every construct id the CLI could match for one `-c env=…`."""
    application = cdk.App(context={"env": env, **NO_IDENTITY_CENTER})
    cdk_app.build(application)
    # The CLI matches against the cloud assembly's stack ids, which for a
    # top-level stack is its construct id.
    return frozenset(artifact.id for artifact in application.synth().stacks)


def _selectors(text: str) -> set[str]:
    """Every `meridian-…` stack selector named by a cdk command in `text`."""
    # Fold line continuations so a multi-stack `cdk destroy \` is one command,
    # and stop at a blank line so the rest of a code block is not swept in.
    folded = re.sub(r"\\\n\s*", " ", text)
    for placeholder in _PLACEHOLDERS:
        folded = folded.replace(placeholder, _ENV_MARKER)
    found: set[str] = set()
    for command in _COMMAND.finditer(folded):
        argument = _ARRAY_REF.sub(lambda m: _bash_array(folded, m.group(1)), command.group(1))
        found.update(_SELECTOR.findall(argument))
    return found


def _bash_array(text: str, name: str) -> str:
    """The elements of `NAME=( … )`, flattened, or "" when there is no such array."""
    match = re.search(rf"^{re.escape(name)}=\((.*?)\)", text, re.MULTILINE | re.DOTALL)
    if match is None:
        return ""
    return " ".join(part.strip().strip("\"'") for part in match.group(1).split())


def _expand(selector: str) -> set[str]:
    """`meridian-<env>-auth` → both real environments; anything else → itself."""
    if _ENV_MARKER in selector:
        return {selector.replace(_ENV_MARKER, env) for env in ("staging", "production")}
    return {selector}


def _raw_selectors() -> list[tuple[Path, str]]:
    pairs: list[tuple[Path, str]] = []
    for path in SEARCHED_FILES:
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        for selector in _selectors(text):
            pairs.append((path, selector))
    return sorted(pairs)


RAW_SELECTORS = _raw_selectors()


def test_the_documents_actually_contain_selectors() -> None:
    """A regex that silently matches nothing would make every test below vacuous."""
    assert len(RAW_SELECTORS) >= 10, RAW_SELECTORS
    paths = {path.name for path, _ in RAW_SELECTORS}
    assert "cutover.md" in paths
    assert "deploy.yml" in paths
    assert "staging_session.sh" in paths


@pytest.mark.parametrize(
    ("source", "selector"),
    RAW_SELECTORS,
    ids=[f"{path.name}:{selector}" for path, selector in RAW_SELECTORS],
)
def test_every_written_cdk_selector_is_a_real_construct_id(source: Path, selector: str) -> None:
    """`npx cdk deploy <selector>` must find a stack, for every selector written down.

    `<env>` placeholders are checked against **both** environments, because a
    runbook that says `meridian-<env>-auth` is used for both.
    """
    for concrete in sorted(_expand(selector)):
        env = "production" if "production" in concrete else "staging"
        ids = _construct_ids(env)
        assert concrete in ids, (
            f"{source.relative_to(REPO_ROOT)} names `{concrete}` in a cdk command, but the "
            f"app's construct ids for env={env} are {sorted(ids)}. The CDK CLI selects by "
            f"construct id, so this command would fail with 'No stacks match'."
        )


#: The stacks that other stacks depend on and that read context of their own
#: (`hostedZoneId`, `cloudfrontPrefixListId`, `renderRecords`). A `cdk deploy` of
#: one of these without `--exclusively` also deploys `vpc`, `data`, `edge` and
#: `dns` at whatever context the command happens to carry — which after the DNS
#: flip means deleting the production aliases and writing the CloudFront
#: prefix-list placeholder into the ALB security group, from a command whose only
#: intended effect was an environment variable (runbook critic round 3, RBR3-01).
#:
#: `-edge` joined the list in round 4 (RBR4-03). It is the stack whose own context
#: the other entries are protected *from*, so it has a second way to be safe: a
#: deploy that passes `cloudfrontPrefixListId` AND `hostedZoneId` itself cannot
#: re-synthesize `edge` at the defaults, because it is not at the defaults. Either
#: form is accepted; `--exclusively` is the one to write in new text.
_DEPENDENT_SUFFIXES = ("-compute", "-auth", "-observability", "-edge")

#: The context keys an `edge` deploy must carry when it does not carry
#: `--exclusively`. Both, or neither counts.
_EDGE_CONTEXT_KEYS = ("cloudfrontPrefixListId", "hostedZoneId")


def _deploy_commands(text: str) -> list[str]:
    """The argument text of every `cdk deploy …` in `text`, continuations folded."""
    folded = re.sub(r"\\\n\s*", " ", text)
    for placeholder in _PLACEHOLDERS:
        folded = folded.replace(placeholder, _ENV_MARKER)
    return [m.group(1) for m in re.finditer(r"\bcdk\s+deploy\b([^\n`]*)", folded)]


def _dependent_deploys() -> list[tuple[Path, str]]:
    """Every runbook `cdk deploy` that names a compute/auth/observability stack."""
    pairs: list[tuple[Path, str]] = []
    for path in sorted((REPO_ROOT / "docs" / "runbooks").glob("*.md")):
        for argument in _deploy_commands(path.read_text(encoding="utf-8")):
            selected = _SELECTOR.findall(argument)
            if any(name.endswith(_DEPENDENT_SUFFIXES) for name in selected):
                pairs.append((path, " ".join(argument.split())))
    return pairs


DEPENDENT_DEPLOYS = _dependent_deploys()


def test_the_runbooks_actually_contain_dependent_deploys() -> None:
    """Anti-vacuity: the check below must have real commands to check."""
    assert len(DEPENDENT_DEPLOYS) >= 6, DEPENDENT_DEPLOYS
    paths = {path.name for path, _ in DEPENDENT_DEPLOYS}
    assert {
        "cutover.md",
        "decommission-supabase-render.md",
        "cognito-user-migration.md",
    } <= paths, paths


@pytest.mark.parametrize(
    ("source", "command"),
    DEPENDENT_DEPLOYS,
    ids=[f"{path.name}:{index}" for index, (path, _) in enumerate(DEPENDENT_DEPLOYS)],
)
def test_every_dependent_deploy_is_exclusive(source: Path, command: str) -> None:
    """`cdk deploy` of compute/auth/observability must carry `--exclusively`.

    These stacks have dependencies that read context the deploying command does
    not pass, so a non-exclusive deploy re-synthesizes them at their defaults.
    """
    if "--exclusively" in command:
        return
    only_edge = all(
        name.endswith("-edge")
        for name in _SELECTOR.findall(command)
        if name.endswith(_DEPENDENT_SUFFIXES)
    )
    spells_its_own_context = all(f"-c {key}" in command for key in _EDGE_CONTEXT_KEYS)
    assert only_edge and spells_its_own_context, (
        f"{source.relative_to(REPO_ROOT)} runs `cdk deploy{command}` without `--exclusively`. "
        f"CDK would also deploy this stack's dependencies (vpc/data/edge/dns) at this "
        f"command's context, which after the cutover deletes the production aliases and "
        f"writes the CloudFront prefix-list placeholder. Add `--exclusively` — or, for an "
        f"`edge` deploy only, pass both "
        f"{' and '.join('`-c ' + key + '`' for key in _EDGE_CONTEXT_KEYS)} so the synth cannot "
        f"fall back to the defaults."
    )


def test_staging_session_passes_both_edge_context_keys() -> None:
    """`scripts/staging_session.sh` deploys `edge` non-exclusively, so it must spell them.

    It is the one caller here that runs unattended, and it builds its flags in a
    `CTX` array rather than on the `cdk deploy` line, so the check above cannot see
    them. This is that check, done against the array (runbook critic round 4, RBR4-06).

    Each key is added only when its value is non-empty (`if [ -n "$VAR" ]; then
    CTX+=...`), and the test asserts that exact guard. Leaving the key out when the
    value is empty is safe here because the script
    only ever targets staging (`ENV_NAME=staging`): no prefix list gives the
    placeholder id, which fails the deploy in CloudFormation (and the script warns);
    no zone id means no alias records, and the only aliases at stake are
    `staging-app`/`staging-api`, never production's (round 5, T:146).
    """
    script = (REPO_ROOT / "scripts" / "staging_session.sh").read_text(encoding="utf-8")
    assert re.search(r"^ENV_NAME=staging$", script, re.MULTILINE), (
        "scripts/staging_session.sh no longer pins ENV_NAME=staging; omitting an empty "
        "edge context key is only safe on staging."
    )
    for key in _EDGE_CONTEXT_KEYS:
        guarded = re.search(
            rf'^if \[ -n "\$(\w+)" \]; then CTX\+=\(-c "{key}=\$\1"\); fi$',
            script,
            re.MULTILINE,
        )
        assert guarded, (
            f"scripts/staging_session.sh must add `-c {key}` to CTX, and only when its "
            f'value is non-empty (`if [ -n "$VAR" ]; then CTX+=(-c "{key}=$VAR"); fi`). '
            f"It deploys the edge stack without `--exclusively`: without the key the "
            f"synth falls back to the default."
        )


@pytest.mark.parametrize("env", ["staging", "production"])
def test_every_construct_id_equals_its_stack_name(env: str) -> None:
    """The property the selectors rest on, asserted directly.

    If this fails, the parametrized test above starts failing in a confusing way;
    this one says why in one line.
    """
    application = cdk.App(context={"env": env, **NO_IDENTITY_CENTER})
    cdk_app.build(application)
    mismatched = {
        artifact.id: artifact.stack_name
        for artifact in application.synth().stacks
        if artifact.id != artifact.stack_name
    }
    assert not mismatched, mismatched
