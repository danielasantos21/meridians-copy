"""Phase 11 H1/H2: the job worker's AWS side, behind `-c worker_enabled=true`.

Two halves, and the first is the one that protects what is deployed today:

* **Off (the default), nothing moves.** An explicit `worker_enabled=false` synthesizes
  byte-for-byte what an absent flag does, no template names anything the worker adds, and
  — the property that would catch a change leaking out from behind the flag — turning it
  ON only ADDS: every resource, output and permission of the off templates is still there,
  unchanged, and the few resources the flag legitimately touches (the api task's
  environment and role, the execution role's log-group grant, the dashboard's alarm
  carpet) change only by addition. The one-time proof against the pre-H1 commit — every
  template of both environments byte-identical — is recorded in
  `docs/reports/phase-11-plan.md` (H1 tag cell).
* **On, every control plan §3.8 names is present** — KMS on both queues, redrive after 3,
  a visibility longer than the longest `timeout_s` in the registry (read from the
  manifests, not retyped), no wildcard action, no `Resource: "*"`, no delete, and five
  alarms that page on both transitions.

The worker's own code is read, never imported into this process: `infra/` does not put
the repository root on `sys.path` (the CDK app's `app` module would collide), so the
facts the tests need from `src/processes` and `workers/` come from one subprocess of the
same interpreter.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest
from aws_cdk import cx_api
from conftest import synth_with

from meridian.config import API_PLATFORM_CONTEXT_FLAG, WORKER_CONTEXT_FLAG
from meridian.log_groups import logs_key_log_group_patterns
from meridian.stacks.api import IDLE_SWEEP_ACTOR_CONTEXT
from meridian.stacks.compute import QBO_CALLBACK_PATH, QBO_OAUTH_SECRET_NAME
from meridian.stacks.worker import (
    JOBS_DLQ_URL_ENV,
    JOBS_MAX_RECEIVES,
    JOBS_QUEUE_URL_ENV,
    JOBS_VISIBILITY_TIMEOUT,
    OUTBOX_SWEEP_MESSAGE,
    OUTBOX_SWEEP_SCHEDULE,
    QBO_TOKEN_KMS_ACTIONS,
    QBO_TOKEN_KMS_KEY_ENV,
    SWEEP_DONE_MESSAGE,
    SWEEP_DONE_METRIC,
    SWEEP_MESSAGE,
    SWEEP_SCHEDULE,
    WORKER_COMMAND,
    WORKER_DESIRED_COUNT,
    WORKER_ENV_FROM_API,
    jobs_dlq_name,
    jobs_queue_name,
    worker_schedule_group_name,
)

REPO_ROOT = Path(__file__).resolve().parents[2]
ENVIRONMENTS = ("staging", "production")
ON = {WORKER_CONTEXT_FLAG: "true"}

#: Strings that exist only because of the worker. None may appear with the flag off.
WORKER_MARKERS = (
    "sqs-jobs",
    "svc-worker",
    "ecs-worker",
    "schedule-worker",
    "sweep-scheduler",
    "schedule-sweep-runs",
    JOBS_QUEUE_URL_ENV,
    JOBS_DLQ_URL_ENV,
    SWEEP_DONE_METRIC,
    "/ecs/worker",
    # M-10: the QuickBooks OAuth client exists only with the token key.
    QBO_OAUTH_SECRET_NAME,
    "QBO_CLIENT_ID",
    "QBO_CLIENT_SECRET",
    "QBO_ENVIRONMENT",
    "QBO_REDIRECT_URI",
)

#: The api container's secrets the flag adds (M-10).
QBO_SECRETS = {"QBO_CLIENT_ID", "QBO_CLIENT_SECRET"}
#: ...and its plain variables.
QBO_ENV = {"QBO_ENVIRONMENT", "QBO_REDIRECT_URI"}

#: The five H2 alarms, by the last segment of `meridian-<env>-alarm-<purpose>`.
WORKER_ALARMS = ("jobs-dlq", "jobs-age", "worker-task-count", "sweep-stalled", "sweep-dropped")
#: …and by construct id (the dashboard's alarm carpet references them by `Fn::GetAtt`).
WORKER_ALARM_IDS = (
    "JobsDlqDepth",
    "JobsOldestMessageAge",
    "WorkerTaskCount",
    "SweepStalled",
    "SweepDropped",
)

_FACTS_SCRIPT = r"""
import json, sys
from src.processes import REGISTRY
from workers import contract, run_job, transport
from src import qbo_token_crypto
message = contract.parse_body(sys.argv[1])
outbox_tick = contract.parse_body(sys.argv[2])
print(json.dumps({
    "timeouts": {
        f"{pid}:{kind}": job.timeout_s
        for pid, manifest in REGISTRY.items()
        for kind, job in manifest.jobs.items()
    },
    "visibility": transport.DEFAULT_VISIBILITY_SECONDS,
    "max_receives": transport.DEFAULT_MAX_RECEIVE_COUNT,
    "max_wait": transport.MAX_WAIT_SECONDS,
    "heartbeat": run_job.HEARTBEAT_SECONDS,
    "sweep_kind": message.kind,
    "outbox_kind": outbox_tick.kind,
    "outbox_class": type(outbox_tick).__name__,
    "qbo_token_env": qbo_token_crypto.KMS_KEY_ENV,
    "qbo_token_purpose": qbo_token_crypto.PURPOSE,
}))
"""


# ------------------------------------------------------------------ fixtures
@pytest.fixture(scope="module")
def facts() -> dict[str, Any]:
    """What the registry and the worker code say, from a subprocess at the repo root."""
    out = subprocess.run(
        [
            sys.executable,
            "-c",
            _FACTS_SCRIPT,
            json.dumps(SWEEP_MESSAGE, separators=(",", ":")),
            json.dumps(OUTBOX_SWEEP_MESSAGE, separators=(",", ":")),
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=True,
        timeout=120,
    )
    return dict(json.loads(out.stdout.strip().splitlines()[-1]))


@pytest.fixture(scope="module", params=ENVIRONMENTS)
def pair(
    request: pytest.FixtureRequest,
    staging: cx_api.CloudAssembly,
    production: cx_api.CloudAssembly,
) -> tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly]:
    """`(env, off, on)`: the default synth (flag absent) and the same with the flag on."""
    env = str(request.param)
    off = staging if env == "staging" else production
    return env, off, synth_with(env, **ON)


def _template(assembly: cx_api.CloudAssembly, env: str, component: str) -> dict[str, Any]:
    return dict(assembly.get_stack_by_name(f"meridian-{env}-{component}").template)


def _resources(template: dict[str, Any], type_name: str) -> dict[str, Any]:
    return {
        name: resource
        for name, resource in template.get("Resources", {}).items()
        if resource["Type"] == type_name
    }


def _one(template: dict[str, Any], type_name: str, prefix: str) -> dict[str, Any]:
    found = [
        r["Properties"]
        for name, r in _resources(template, type_name).items()
        if name.startswith(prefix)
    ]
    assert len(found) == 1, (type_name, prefix, len(found))
    return dict(found[0])


def _as_list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, list) else [value]


def _grants(policy: dict[str, Any]) -> set[tuple[str, str, str, str]]:
    """A policy document as (effect, action, resource, condition) rows — merge-proof."""
    rows: set[tuple[str, str, str, str]] = set()
    for statement in policy["PolicyDocument"]["Statement"]:
        for action in _as_list(statement["Action"]):
            for resource in _as_list(statement["Resource"]):
                rows.add(
                    (
                        statement["Effect"],
                        action,
                        json.dumps(resource, sort_keys=True),
                        json.dumps(statement.get("Condition"), sort_keys=True),
                    )
                )
    return rows


def _worker_policy(compute: dict[str, Any]) -> dict[str, Any]:
    return _one(compute, "AWS::IAM::Policy", "WorkerTaskRoleDefaultPolicy")


def _statements(policy: dict[str, Any]) -> list[dict[str, Any]]:
    return list(policy["PolicyDocument"]["Statement"])


def _container(compute: dict[str, Any], prefix: str) -> dict[str, Any]:
    task = _one(compute, "AWS::ECS::TaskDefinition", prefix)
    (container,) = task["ContainerDefinitions"]
    return dict(container)


def _env(container: dict[str, Any]) -> dict[str, Any]:
    return {item["Name"]: item["Value"] for item in container.get("Environment", [])}


# =============================================================== off: nothing moves
@pytest.mark.parametrize("env", ENVIRONMENTS)
def test_an_explicit_false_is_byte_identical_to_no_flag(
    env: str, staging: cx_api.CloudAssembly, production: cx_api.CloudAssembly
) -> None:
    absent = staging if env == "staging" else production
    false = synth_with(env, **{WORKER_CONTEXT_FLAG: "false"})
    assert sorted(s.stack_name for s in absent.stacks) == sorted(s.stack_name for s in false.stacks)
    for artifact in absent.stacks:
        other = false.get_stack_by_name(artifact.stack_name).template
        assert json.dumps(artifact.template) == json.dumps(other), artifact.stack_name


@pytest.mark.parametrize("env", ENVIRONMENTS)
def test_off_no_template_names_anything_the_worker_adds(
    env: str, staging: cx_api.CloudAssembly, production: cx_api.CloudAssembly
) -> None:
    assembly = staging if env == "staging" else production
    for artifact in assembly.stacks:
        rendered = json.dumps(artifact.template)
        for marker in WORKER_MARKERS:
            assert marker not in rendered, (artifact.stack_name, marker)


#: The resources the flag is allowed to CHANGE (by addition only), per stack.
ADDITIVELY_CHANGED = {
    "compute": ("ApiTaskDefinition", "ApiTaskRoleDefaultPolicy", "ExecutionRoleDefaultPolicy"),
    "observability": ("Dashboard",),
}


def test_on_only_adds(pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly]) -> None:
    """Every off resource and output survives the flag unchanged, or changes by addition.

    This is what makes "off is byte-identical" durable: a later edit that moved anything
    out from behind the flag would change a resource the worker does not own.
    """
    env, off, on = pair
    for artifact in off.stacks:
        before = artifact.template
        after = on.get_stack_by_name(artifact.stack_name).template
        component = artifact.stack_name.removeprefix(f"meridian-{env}-")
        allowed = ADDITIVELY_CHANGED.get(component, ())
        for key in set(before) | set(after):
            if key not in ("Resources", "Outputs"):
                assert before.get(key) == after.get(key), (artifact.stack_name, key)
        for name, resource in before.get("Resources", {}).items():
            new = after["Resources"].get(name)
            assert new is not None, (artifact.stack_name, name, "removed")
            if new == resource:
                continue
            assert name.startswith(allowed), (artifact.stack_name, name, "changed")
            _assert_changed_by_addition(name, resource, new)
        for name, output in before.get("Outputs", {}).items():
            if name == "AlarmCount":
                assert int(after["Outputs"][name]["Value"]) == int(output["Value"]) + len(
                    WORKER_ALARMS
                )
                continue
            assert after["Outputs"].get(name) == output, (artifact.stack_name, name)


def _assert_changed_by_addition(name: str, before: dict[str, Any], after: dict[str, Any]) -> None:
    if before["Type"] == "AWS::IAM::Policy":
        assert _grants(before["Properties"]) < _grants(after["Properties"]), name
        rest = {k: v for k, v in before["Properties"].items() if k != "PolicyDocument"}
        assert rest == {k: v for k, v in after["Properties"].items() if k != "PolicyDocument"}
    elif before["Type"] == "AWS::ECS::TaskDefinition":
        (old,) = before["Properties"]["ContainerDefinitions"]
        (new,) = after["Properties"]["ContainerDefinitions"]
        added = {k: v for k, v in _env(new).items() if k not in _env(old)}
        assert set(added) == {JOBS_QUEUE_URL_ENV, JOBS_DLQ_URL_ENV, *QBO_ENV}, name
        assert all(_env(new)[k] == v for k, v in _env(old).items()), name
        old_secrets = {s["Name"]: s for s in old.get("Secrets", [])}
        new_secrets = {s["Name"]: s for s in new.get("Secrets", [])}
        assert set(new_secrets) - set(old_secrets) == QBO_SECRETS, name
        assert all(new_secrets[k] == v for k, v in old_secrets.items()), name
        assert {k: v for k, v in old.items() if k not in ("Environment", "Secrets")} == {
            k: v for k, v in new.items() if k not in ("Environment", "Secrets")
        }
        assert {k: v for k, v in before["Properties"].items() if k != "ContainerDefinitions"} == {
            k: v for k, v in after["Properties"].items() if k != "ContainerDefinitions"
        }
    elif before["Type"] == "AWS::CloudWatch::Dashboard":
        # The alarm carpet lists every alarm; nothing else on the dashboard may move.
        rest = {k: v for k, v in before["Properties"].items() if k != "DashboardBody"}
        assert rest == {k: v for k, v in after["Properties"].items() if k != "DashboardBody"}
        body = json.dumps(after["Properties"]["DashboardBody"])
        for logical in WORKER_ALARM_IDS:
            assert logical in body and logical not in json.dumps(before["Properties"]), logical
    else:  # pragma: no cover - ADDITIVELY_CHANGED names only the three types above
        raise AssertionError(f"{name}: {before['Type']} may not change")


# =================================================================== on: the queues
def test_both_queues_are_on_the_phi_key_tls_only_and_tagged_phi(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    queues = {
        q["Properties"]["QueueName"]: (name, q["Properties"])
        for name, q in _resources(compute, "AWS::SQS::Queue").items()
    }
    assert set(queues) == {jobs_queue_name(env), jobs_dlq_name(env)}
    for logical, props in queues.values():
        assert "KeyPhi" in json.dumps(props["KmsMasterKeyId"]), logical
        tags = {t["Key"]: t["Value"] for t in props["Tags"]}
        assert tags["DataClassification"] == "phi"
    tls_denies = [
        (json.dumps(policy["Properties"]["Queues"]), statement)
        for policy in _resources(compute, "AWS::SQS::QueuePolicy").values()
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
        if statement["Effect"] == "Deny"
        and statement.get("Condition") == {"Bool": {"aws:SecureTransport": "false"}}
    ]
    covered = {
        logical for logical, _ in queues.values() if any(logical in q for q, _ in tls_denies)
    }
    assert covered == {logical for logical, _ in queues.values()}


def test_the_queue_settings_are_the_ones_the_worker_code_assumes(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly], facts: dict[str, Any]
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    queue = next(
        q["Properties"]
        for q in _resources(compute, "AWS::SQS::Queue").values()
        if q["Properties"]["QueueName"] == jobs_queue_name(env)
    )
    dlq = next(
        q["Properties"]
        for q in _resources(compute, "AWS::SQS::Queue").values()
        if q["Properties"]["QueueName"] == jobs_dlq_name(env)
    )
    assert queue["VisibilityTimeout"] == 900 == facts["visibility"]
    assert queue["ReceiveMessageWaitTimeSeconds"] == 20 == facts["max_wait"]
    assert queue["RedrivePolicy"]["maxReceiveCount"] == JOBS_MAX_RECEIVES == 3
    assert facts["max_receives"] == JOBS_MAX_RECEIVES
    assert "WorkerJobsDlq" in json.dumps(queue["RedrivePolicy"]["deadLetterTargetArn"])
    assert dlq["MessageRetentionPeriod"] == 14 * 24 * 3600


def test_visibility_outlasts_every_job_in_the_registry(facts: dict[str, Any]) -> None:
    """Plan §3.8: visibility > the longest `timeout_s`, read from the manifests."""
    assert facts["timeouts"], "the registry declares no jobs"
    longest = max(facts["timeouts"].values())
    assert JOBS_VISIBILITY_TIMEOUT.to_seconds() > longest
    # And the heartbeat comes round well inside it.
    assert facts["heartbeat"] < JOBS_VISIBILITY_TIMEOUT.to_seconds() / 2


# ================================================================ on: the sweeper
def test_the_sweep_schedule_sends_the_d5_message_every_fifteen_minutes(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly], facts: dict[str, Any]
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    schedule = _one(compute, "AWS::Scheduler::Schedule", "WorkerSweepSchedule")
    assert schedule["ScheduleExpression"] == SWEEP_SCHEDULE == "rate(15 minutes)"
    assert schedule["State"] == "ENABLED"
    assert schedule["Name"] == f"meridian-{env}-schedule-sweep-runs"
    target = schedule["Target"]
    assert target["Arn"] == {"Fn::GetAtt": [_logical(compute, jobs_queue_name(env)), "Arn"]}
    assert json.loads(target["Input"]) == SWEEP_MESSAGE
    # `workers/contract.parse_body` accepts it, strictly, as a `sweep`.
    assert facts["sweep_kind"] == "sweep"
    group = _one(compute, "AWS::Scheduler::ScheduleGroup", "WorkerScheduleGroup")
    assert group["Name"] == worker_schedule_group_name(env)
    assert {t["Key"] for t in group["Tags"]} >= {"Project", "Environment", "DataClassification"}


def _logical(template: dict[str, Any], queue_name: str) -> str:
    return next(
        name
        for name, q in _resources(template, "AWS::SQS::Queue").items()
        if q["Properties"]["QueueName"] == queue_name
    )


def test_the_scheduler_role_may_send_the_tick_and_nothing_else(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    role = _one(compute, "AWS::IAM::Role", "WorkerSweepSchedulerRole")
    assert role["RoleName"] == f"meridian-{env}-iam-sweep-scheduler"
    (trust,) = role["AssumeRolePolicyDocument"]["Statement"]
    assert trust["Principal"] == {"Service": "scheduler.amazonaws.com"}
    assert "aws:SourceAccount" in trust["Condition"]["StringEquals"]
    assert f"schedule-group/{worker_schedule_group_name(env)}" in json.dumps(
        trust["Condition"]["ArnEquals"]["aws:SourceArn"]
    )
    policy = _one(compute, "AWS::IAM::Policy", "WorkerSweepSchedulerRoleDefaultPolicy")
    actions = sorted(a for s in _statements(policy) for a in _as_list(s["Action"]))
    assert actions == ["kms:Decrypt", "kms:GenerateDataKey", "sqs:SendMessage"]
    for statement in _statements(policy):
        if statement["Action"] == "sqs:SendMessage":
            assert statement["Resource"] == {
                "Fn::GetAtt": [_logical(compute, jobs_queue_name(env)), "Arn"]
            }
        else:
            assert "sqs." in json.dumps(statement["Condition"])


# ================================================================== on: the worker
def test_the_worker_runs_the_api_image_with_the_worker_command(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    task = _one(compute, "AWS::ECS::TaskDefinition", "WorkerTaskDefinition")
    assert task["Family"] == f"meridian-{env}-ecs-worker"
    assert task["RuntimePlatform"]["CpuArchitecture"] == "ARM64"
    assert (task["Cpu"], task["Memory"]) == ("512", "1024")
    worker = _container(compute, "WorkerTaskDefinition")
    api = _container(compute, "ApiTaskDefinition")
    assert worker["Command"] == list(WORKER_COMMAND) == ["python", "-m", "workers"]
    assert worker["StopTimeout"] == 120
    # One repository, one tag: the api's image, byte for byte.
    assert worker["Image"] == api["Image"]
    assert "PortMappings" not in worker and "HealthCheck" not in worker
    assert (
        task["ExecutionRoleArn"]
        == _one(compute, "AWS::ECS::TaskDefinition", "ApiTask")["ExecutionRoleArn"]
    )


def test_the_worker_environment_is_the_apis_plus_the_queues(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    worker = _env(_container(compute, "WorkerTaskDefinition"))
    api = _env(_container(compute, "ApiTaskDefinition"))
    for name in WORKER_ENV_FROM_API:
        if name in api:
            assert worker[name] == api[name], name
    assert worker[JOBS_QUEUE_URL_ENV] == {"Ref": _logical(compute, jobs_queue_name(env))}
    assert worker[JOBS_DLQ_URL_ENV] == {"Ref": _logical(compute, jobs_dlq_name(env))}
    assert worker["AWS_REGION"] == {"Ref": "AWS::Region"}
    assert set(worker) == {n for n in WORKER_ENV_FROM_API if n in api} | {
        "AWS_REGION",
        JOBS_QUEUE_URL_ENV,
        JOBS_DLQ_URL_ENV,
    }
    assert not any(n.startswith(("COGNITO_", "WEBHOOK_")) for n in worker)
    # ADR 0044: the one `TOKEN` name is a KMS key ARN (an import from `data`), not a token.
    assert worker[QBO_TOKEN_KMS_KEY_ENV] == api[QBO_TOKEN_KMS_KEY_ENV]
    assert "KeyTokens" in json.dumps(worker[QBO_TOKEN_KMS_KEY_ENV])
    for name in worker:
        if name != QBO_TOKEN_KMS_KEY_ENV:
            assert not re.search(r"PASSWORD|SECRET|TOKEN", name), name
    # The push talks to the api's Intuit environment; it never starts an OAuth flow.
    assert worker["QBO_ENVIRONMENT"] == api["QBO_ENVIRONMENT"]
    assert "QBO_REDIRECT_URI" not in worker


def test_the_worker_holds_the_database_password_and_the_qbo_client_only(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    worker = _container(_template(on, env, "compute"), "WorkerTaskDefinition")
    assert sorted(s["Name"] for s in worker["Secrets"]) == [
        "PGPASSWORD",
        "QBO_CLIENT_ID",
        "QBO_CLIENT_SECRET",
    ]
    assert "DbAppSecret" in json.dumps(worker["Secrets"])


def test_the_resend_rollback_reaches_the_worker_too() -> None:
    compute = _template(synth_with("staging", **ON, emailBackend="resend"), "staging", "compute")
    worker = _container(compute, "WorkerTaskDefinition")
    assert sorted(s["Name"] for s in worker["Secrets"]) == [
        "PGPASSWORD",
        "QBO_CLIENT_ID",
        "QBO_CLIENT_SECRET",
        "RESEND_API_KEY",
    ]
    assert _env(worker)["EMAIL_BACKEND"] == "resend"
    assert "RESEND_FROM_EMAIL" in _env(worker)


def test_one_worker_task_rolling_with_the_circuit_breaker_and_no_load_balancer(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    service = _one(compute, "AWS::ECS::Service", "WorkerService")
    assert service["ServiceName"] == f"meridian-{env}-ecs-svc-worker"
    assert service["DesiredCount"] == WORKER_DESIRED_COUNT == 1
    assert "LoadBalancers" not in service
    deployment = service["DeploymentConfiguration"]
    assert (deployment["MinimumHealthyPercent"], deployment["MaximumPercent"]) == (100, 200)
    assert deployment["DeploymentCircuitBreaker"] == {"Enable": True, "Rollback": True}
    assert service["EnableExecuteCommand"] is False
    network = service["NetworkConfiguration"]["AwsvpcConfiguration"]
    assert network["AssignPublicIp"] == "DISABLED"
    assert "AppSecurityGroup" in json.dumps(network["SecurityGroups"])
    assert "privateapp" in json.dumps(network["Subnets"])
    # H5: the api stays at one task; the flag does not touch it.
    api = _one(compute, "AWS::ECS::Service", "ServiceApi")
    assert api["DesiredCount"] == 1


# ============================================================= on: least privilege
EXPECTED_WORKER_ACTIONS = {
    "sqs:ReceiveMessage",
    "sqs:DeleteMessage",
    "sqs:ChangeMessageVisibility",
    "sqs:SendMessage",
    "kms:GenerateDataKey",
    "kms:Decrypt",
    "s3:GetObject",
    "s3:GetObjectVersion",
    "s3:GetObjectTagging",
    "s3:GetObjectVersionTagging",
    "s3:PutObject",
    "ses:SendEmail",
    "ses:SendRawEmail",
}


def test_the_worker_role_holds_exactly_the_listed_actions(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    role = _one(compute, "AWS::IAM::Role", "WorkerTaskRole")
    assert role["RoleName"] == f"meridian-{env}-iam-ecs-worker-task"
    assert "ManagedPolicyArns" not in role and "Policies" not in role
    statements = _statements(_worker_policy(compute))
    actions = {a for s in statements for a in _as_list(s["Action"])}
    assert actions == EXPECTED_WORKER_ACTIONS
    for statement in statements:
        assert statement["Effect"] == "Allow"
        assert not any("*" in a for a in _as_list(statement["Action"])), statement["Sid"]
        for resource in _as_list(statement["Resource"]):
            assert resource != "*", statement["Sid"]
    # Nothing on this role reaches another principal's policy: no other policy names it.
    attached = [
        p
        for p in _resources(compute, "AWS::IAM::Policy").values()
        if "WorkerTaskRole" in json.dumps(p["Properties"]["Roles"])
    ]
    assert len(attached) == 1


def test_the_worker_queue_rights_are_split_consume_versus_dead_letter(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    queue, dlq = _logical(compute, jobs_queue_name(env)), _logical(compute, jobs_dlq_name(env))
    by_sid = {s["Sid"]: s for s in _statements(_worker_policy(compute))}
    assert by_sid["ConsumeJobs"]["Resource"] == {"Fn::GetAtt": [queue, "Arn"]}
    assert by_sid["DeadLetterRefusedJobs"]["Action"] == "sqs:SendMessage"
    assert by_sid["DeadLetterRefusedJobs"]["Resource"] == {"Fn::GetAtt": [dlq, "Arn"]}


def test_the_worker_s3_rights_are_prefix_scoped_and_never_delete_or_list(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    statements = _statements(_worker_policy(_template(on, env, "compute")))
    s3 = [s for s in statements if any(a.startswith("s3:") for a in _as_list(s["Action"]))]
    suffixes: dict[str, set[str]] = {}
    for statement in s3:
        for resource in _as_list(statement["Resource"]):
            suffix = resource["Fn::Join"][1][-1]
            suffixes.setdefault(suffix, set()).update(_as_list(statement["Action"]))
    assert suffixes == {
        "/*/*/uploads/*": {
            "s3:GetObject",
            "s3:GetObjectVersion",
            "s3:GetObjectTagging",
            "s3:GetObjectVersionTagging",
        },
        "/*/*/state/*": {"s3:PutObject", "s3:GetObject", "s3:GetObjectVersion"},
        "/*/*/journal_entries/*": {"s3:PutObject", "s3:GetObject", "s3:GetObjectVersion"},
        "/*/*/data/*": {"s3:PutObject", "s3:GetObject", "s3:GetObjectVersion"},
        "/*/*/reports/*": {"s3:PutObject", "s3:GetObject", "s3:GetObjectVersion"},
        "/*/*/bundle/*": {"s3:PutObject", "s3:GetObject", "s3:GetObjectVersion"},
    }
    # PS-15: the worker never writes an upload. `journal_entries` is the artifacts bucket.
    for statement in s3:
        for resource in _as_list(statement["Resource"]):
            bucket = json.dumps(resource["Fn::Join"][1][0])
            if resource["Fn::Join"][1][-1] == "/*/*/journal_entries/*":
                assert "BucketArtifacts" in bucket
            else:
                assert "BucketPhi" in bucket


def test_every_worker_key_grant_is_through_one_service(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    for statement in _statements(_worker_policy(_template(on, env, "compute"))):
        if not any(a.startswith("kms:") for a in _as_list(statement["Action"])):
            continue
        if statement["Sid"] == "SealQboTokens":  # ADR 0044: its own test below
            continue
        via = json.dumps(statement["Condition"]["StringEquals"]["kms:ViaService"])
        assert ("sqs." in via) != ("s3." in via), statement["Sid"]
        keys = json.dumps(statement["Resource"])
        if "sqs." in via:
            assert "KeyPhi" in keys and "KeyArtifacts" not in keys
        assert "KeyRds" not in keys and "KeyLogs" not in keys


def _token_grants(compute: dict[str, Any]) -> dict[str, dict[str, Any]]:
    grants = {}
    for name, policy in _resources(compute, "AWS::IAM::Policy").items():
        for statement in _statements(policy["Properties"]):
            if "KeyTokens" in json.dumps(statement["Resource"]):
                grants[name.split("DefaultPolicy")[0]] = statement
    return grants


def test_both_task_roles_may_seal_qbo_tokens_on_the_token_key_only(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly], facts: dict[str, Any]
) -> None:
    """ADR 0044: `GenerateDataKey` + `Decrypt` on `meridian-<env>-kms-tokens`, only with
    the `purpose=qbo-token` encryption context — for the worker and the api, nobody else.

    T:186: the api's grant and its `QBO_TOKEN_KMS_KEY_ARN` do NOT depend on the worker
    flag — the api stores tokens on RDS and runs the re-seal script with the worker off.
    """
    env, off, on = pair
    assert facts["qbo_token_env"] == QBO_TOKEN_KMS_KEY_ENV
    assert facts["qbo_token_purpose"] == "qbo-token"
    for assembly, roles in ((on, {"WorkerTaskRole", "ApiTaskRole"}), (off, {"ApiTaskRole"})):
        compute = _template(assembly, env, "compute")
        grants = _token_grants(compute)
        assert set(grants) == roles
        for statement in grants.values():
            assert sorted(_as_list(statement["Action"])) == sorted(QBO_TOKEN_KMS_ACTIONS)
            assert sorted(QBO_TOKEN_KMS_ACTIONS) == ["kms:Decrypt", "kms:GenerateDataKey"]
            (resource,) = _as_list(statement["Resource"])
            assert resource["Fn::ImportValue"].startswith(f"meridian-{env}-data:ExportsOutput")
            assert statement["Condition"] == {
                "StringEquals": {"kms:EncryptionContext:purpose": facts["qbo_token_purpose"]}
            }
        # The api is told the key's ARN under the name the application reads.
        api = _env(_container(compute, "ApiTaskDefinition"))
        assert api[QBO_TOKEN_KMS_KEY_ENV] == grants["ApiTaskRole"]["Resource"]
        # ...and no other stack grants or names it.
        for artifact in assembly.stacks:
            if artifact.stack_name.endswith(("-compute", "-data")):
                continue
            rendered = json.dumps(artifact.template)
            assert "kms-tokens" not in rendered and QBO_TOKEN_KMS_KEY_ENV not in rendered


def test_the_token_key_is_a_rotating_retained_cmk_in_the_data_stack(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    """In both environments, with the flag off as well as on (T:186)."""
    env, off, on = pair
    for assembly in (off, on):
        data = _template(assembly, env, "data")
        key = _one(data, "AWS::KMS::Key", "KeyTokens")
        assert key["EnableKeyRotation"] is True
        tags = {t["Key"]: t["Value"] for t in key["Tags"]}
        assert tags["DataClassification"] == "internal"
        (logical,) = [n for n in _resources(data, "AWS::KMS::Key") if n.startswith("KeyTokens")]
        assert data["Resources"][logical]["DeletionPolicy"] == "Retain"
        aliases = {
            a["Properties"]["AliasName"] for a in _resources(data, "AWS::KMS::Alias").values()
        }
        assert f"alias/meridian-{env}-kms-tokens" in aliases
    # The flag does not touch the data stack at all.
    assert _template(off, env, "data") == _template(on, env, "data")


def test_the_worker_reads_no_secret_and_cannot_exec(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    rendered = json.dumps(_worker_policy(_template(on, env, "compute")))
    for forbidden in ("secretsmanager:", "ssmmessages:", "PhiHmacKey", "DbPhiSecret", "s3:Delete"):
        assert forbidden not in rendered, forbidden


def test_the_api_may_send_to_the_job_queue_only(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, off, on = pair
    before = _one(_template(off, env, "compute"), "AWS::IAM::Policy", "ApiTaskRoleDefaultPolicy")
    compute = _template(on, env, "compute")
    after = _one(compute, "AWS::IAM::Policy", "ApiTaskRoleDefaultPolicy")
    added = {g for g in _grants(after) - _grants(before) if "KeyTokens" not in g[2]}
    queue = json.dumps({"Fn::GetAtt": [_logical(compute, jobs_queue_name(env)), "Arn"]})
    assert {(e, a, r) for e, a, r, _ in added if a.startswith("sqs:")} == {
        ("Allow", "sqs:SendMessage", queue)
    }
    assert {a for _, a, _, _ in added} == {"sqs:SendMessage", "kms:GenerateDataKey", "kms:Decrypt"}
    for _, action, resource, condition in added:
        if action.startswith("kms:"):
            assert "KeyPhi" in resource and "sqs." in condition


def test_the_api_is_told_where_the_queues_are_by_name(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    api = _env(_container(_template(on, env, "compute"), "ApiTaskDefinition"))
    assert api[JOBS_QUEUE_URL_ENV]["Fn::Join"][1][-1] == f"/{jobs_queue_name(env)}"
    assert api[JOBS_DLQ_URL_ENV]["Fn::Join"][1][-1] == f"/{jobs_dlq_name(env)}"
    assert api[JOBS_QUEUE_URL_ENV]["Fn::Join"][1][0] == "https://sqs."


def test_the_worker_log_group_is_one_the_logs_key_admits(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    group = _one(_template(on, env, "compute"), "AWS::Logs::LogGroup", "WorkerLogGroup")
    name = group["LogGroupName"]
    assert name == f"/meridian/{env}/ecs/worker"
    patterns = logs_key_log_group_patterns(env)
    assert any(re.fullmatch(p.replace("*", ".*"), name) for p in patterns)
    assert "KeyLogs" in json.dumps(group["KmsKeyId"])
    assert group["RetentionInDays"] == 400


# ================================================================== on: the alarms
def test_five_worker_alarms_page_on_alarm_only(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    alarms = {
        a["Properties"]["AlarmName"]: a["Properties"]
        for a in _resources(_template(on, env, "observability"), "AWS::CloudWatch::Alarm").values()
    }
    for purpose in WORKER_ALARMS:
        props = alarms[f"meridian-{env}-alarm-{purpose}"]
        assert not props.get("OKActions"), purpose
        assert "AlertsTopic" in json.dumps(props["AlarmActions"]), purpose
        assert "docs/runbooks/alerts.md" in props["AlarmDescription"] or purpose == (
            "worker-task-count"
        )


def test_each_worker_alarm_watches_the_right_thing(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    alarms = {
        a["Properties"]["AlarmName"].removeprefix(f"meridian-{env}-alarm-"): a["Properties"]
        for a in _resources(_template(on, env, "observability"), "AWS::CloudWatch::Alarm").values()
    }
    dlq = alarms["jobs-dlq"]
    assert (dlq["MetricName"], dlq["Threshold"]) == ("ApproximateNumberOfMessagesVisible", 1)
    assert "WorkerJobsDlq" in json.dumps(dlq["Dimensions"])
    age = alarms["jobs-age"]
    assert (age["MetricName"], age["Threshold"]) == ("ApproximateAgeOfOldestMessage", 900)
    assert age["ComparisonOperator"] == "GreaterThanThreshold"
    assert "WorkerJobsQueue" in json.dumps(age["Dimensions"])
    tasks = alarms["worker-task-count"]
    assert (tasks["Namespace"], tasks["MetricName"]) == (
        "ECS/ContainerInsights",
        "RunningTaskCount",
    )
    assert tasks["ComparisonOperator"] == "LessThanThreshold" and tasks["Threshold"] == 1
    assert tasks["TreatMissingData"] == "breaching"
    assert "WorkerService" in json.dumps(tasks["Dimensions"])
    stalled = alarms["sweep-stalled"]
    assert (stalled["Namespace"], stalled["MetricName"]) == ("Meridian/App", SWEEP_DONE_METRIC)
    assert stalled["Dimensions"] == [{"Name": "Environment", "Value": env}]
    assert stalled["TreatMissingData"] == ("missing" if env == "staging" else "breaching")
    dropped = alarms["sweep-dropped"]
    assert (dropped["Namespace"], dropped["MetricName"]) == (
        "AWS/Scheduler",
        "InvocationDroppedCount",
    )
    assert dropped["Dimensions"] == [
        {"Name": "ScheduleGroup", "Value": worker_schedule_group_name(env)}
    ]


def test_the_sweep_filter_matches_the_line_the_worker_writes(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    source = (REPO_ROOT / "workers" / "sweep.py").read_text(encoding="utf-8")
    assert f'"{SWEEP_DONE_MESSAGE}", extra=' in source
    (flt,) = [
        f["Properties"]
        for f in _resources(_template(on, env, "observability"), "AWS::Logs::MetricFilter").values()
        if f["Properties"]["MetricTransformations"][0]["MetricName"] == SWEEP_DONE_METRIC
    ]
    # Equality on one JSON field, never a substring (observability.py's rule).
    assert flt["FilterPattern"] == f'{{ $.message = "{SWEEP_DONE_MESSAGE}" }}'
    assert flt["MetricTransformations"][0]["Dimensions"] == [
        {"Key": "Environment", "Value": "$.env"}
    ]
    assert "WorkerLogGroup" in json.dumps(flt["LogGroupName"])


# ============================================================ on: tags and names
def test_on_synth_has_no_errors_and_every_resource_is_tagged(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    _, _, on = pair
    for artifact in on.stacks:
        errors = [m for m in artifact.messages if m.entry.type == "aws:cdk:error"]
        assert not errors, (artifact.stack_name, [str(m.entry.data) for m in errors])
        for name, resource in artifact.template.get("Resources", {}).items():
            tags = resource.get("Properties", {}).get("Tags")
            if not isinstance(tags, list):
                continue
            keys = {t["Key"]: t["Value"] for t in tags if isinstance(t, dict) and "Key" in t}
            for required in (
                "Project",
                "Environment",
                "Owner",
                "DataClassification",
                "CostCenter",
                "ManagedBy",
            ):
                assert required in keys, (artifact.stack_name, name, required)


def test_every_new_name_follows_the_convention(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    names = [
        *(q["Properties"]["QueueName"] for q in _resources(compute, "AWS::SQS::Queue").values()),
        _one(compute, "AWS::ECS::Service", "WorkerService")["ServiceName"],
        _one(compute, "AWS::ECS::TaskDefinition", "WorkerTaskDefinition")["Family"],
        _one(compute, "AWS::IAM::Role", "WorkerTaskRole")["RoleName"],
        _one(compute, "AWS::IAM::Role", "WorkerSweepSchedulerRole")["RoleName"],
        _one(compute, "AWS::Scheduler::Schedule", "WorkerSweepSchedule")["Name"],
        _one(compute, "AWS::Scheduler::ScheduleGroup", "WorkerScheduleGroup")["Name"],
    ]
    for name in names:
        assert re.fullmatch(rf"meridian-{env}-[a-z0-9]+-[a-z0-9-]+", name), name


@pytest.fixture(scope="module")
def both() -> cx_api.CloudAssembly:
    """Both flags on (and the idle sweep's actor), staging."""
    return synth_with(
        "staging",
        **ON,
        **{
            API_PLATFORM_CONTEXT_FLAG: "true",
            IDLE_SWEEP_ACTOR_CONTEXT: "00000000-0000-0000-0000-0000000000aa",
            "aws:cdk:bundling-stacks": [],
        },
    )


def test_the_worker_and_the_api_platform_compose(both: cx_api.CloudAssembly) -> None:
    """Both flags at once: every queue name distinct, no errors."""
    names = [
        q["Properties"]["QueueName"]
        for artifact in both.stacks
        for q in _resources(artifact.template, "AWS::SQS::Queue").values()
    ]
    assert {jobs_queue_name("staging"), jobs_dlq_name("staging")} <= set(names)
    assert len(names) == len(set(names))  # the rds-stop DLQ (staging) and the webhook pair too
    for artifact in both.stacks:
        assert not [m for m in artifact.messages if m.entry.type == "aws:cdk:error"]


def test_with_the_api_platform_the_worker_publishes_to_the_one_bus(
    both: cx_api.CloudAssembly,
) -> None:
    """T19: the settle's after-commit publish — `WEBHOOK_EVENT_BUS`, PutEvents on it only."""
    compute = _template(both, "staging", "compute")
    worker = _env(_container(compute, "WorkerTaskDefinition"))
    assert worker["WEBHOOK_EVENT_BUS"] == "meridian-staging-events-api"
    statements = _statements(_worker_policy(compute))
    events = [s for s in statements if any(a.startswith("events:") for a in _as_list(s["Action"]))]
    assert len(events) == 1
    (statement,) = events
    assert statement["Action"] == "events:PutEvents"
    resource = statement["Resource"]
    assert not isinstance(resource, list)
    assert resource["Fn::Join"][1][-1] == ":event-bus/meridian-staging-events-api"
    assert resource["Fn::Join"][1][2] == ":events:"
    # The bus the api stack actually creates carries that name.
    bus = next(
        iter(_resources(_template(both, "staging", "api"), "AWS::Events::EventBus").values())
    )
    assert bus["Properties"]["Name"] == "meridian-staging-events-api"
    # The only new action over worker-only is PutEvents: the stalled-delivery sweep adds a
    # SendMessage and the logs key, actions the worker already holds on other resources.
    assert {a for s in statements for a in _as_list(s["Action"])} == EXPECTED_WORKER_ACTIONS | {
        "events:PutEvents"
    }


def test_with_the_api_platform_the_outbox_tick_goes_to_the_job_queue(
    both: cx_api.CloudAssembly, facts: dict[str, Any]
) -> None:
    """Decision D17: every 5 minutes, `OutboxSweepMessage` on the job queue — no RunTask."""
    compute = _template(both, "staging", "compute")
    schedule = _one(compute, "AWS::Scheduler::Schedule", "WorkerOutboxSweepSchedule")
    assert schedule["Name"] == "meridian-staging-schedule-outbox-sweep"
    assert schedule["ScheduleExpression"] == OUTBOX_SWEEP_SCHEDULE == "rate(5 minutes)"
    assert schedule["State"] == "ENABLED"
    (group,) = _resources(compute, "AWS::Scheduler::ScheduleGroup")
    assert schedule["GroupName"] == {"Ref": group}
    target = schedule["Target"]
    assert target["Arn"] == {"Fn::GetAtt": [_logical(compute, jobs_queue_name("staging")), "Arn"]}
    assert "EcsParameters" not in target
    # The TTL sweep's role: no new principal for the tick.
    role = next(
        name
        for name, r in _resources(compute, "AWS::IAM::Role").items()
        if r["Properties"]["RoleName"] == "meridian-staging-iam-sweep-scheduler"
    )
    assert target["RoleArn"] == {"Fn::GetAtt": [role, "Arn"]}
    assert json.loads(target["Input"]) == OUTBOX_SWEEP_MESSAGE
    # `workers/contract.parse_body` accepts it, strictly, as the outbox tick.
    assert (facts["outbox_kind"], facts["outbox_class"]) == ("outbox_sweep", "OutboxSweepMessage")
    retry = target["RetryPolicy"]
    assert retry["MaximumRetryAttempts"] == 2
    assert retry["MaximumEventAgeInSeconds"] < 5 * 60  # a retry never overlaps the next tick
    # The role still sends to the job queue and nothing else.
    policy = _one(compute, "AWS::IAM::Policy", "WorkerSweepSchedulerRoleDefaultPolicy")
    actions = sorted(a for st in _statements(policy) for a in _as_list(st["Action"]))
    assert actions == ["kms:Decrypt", "kms:GenerateDataKey", "sqs:SendMessage"]
    # And nothing anywhere still runs the sweep as an ECS task.
    for artifact in both.stacks:
        rendered = json.dumps(artifact.template)
        assert "workers.outbox_sweep" not in rendered, artifact.stack_name
        assert "iam-outbox-sweep" not in rendered, artifact.stack_name


def test_without_the_api_platform_there_is_no_outbox_tick(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    names = {
        s["Properties"]["Name"] for s in _resources(compute, "AWS::Scheduler::Schedule").values()
    }
    assert names == {f"meridian-{env}-schedule-sweep-runs"}


def test_without_the_api_platform_the_worker_has_no_bus(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    assert "WEBHOOK_EVENT_BUS" not in _env(_container(compute, "WorkerTaskDefinition"))
    assert "events:" not in json.dumps(_worker_policy(compute))


def test_cdk_json_documents_the_flag_and_does_not_set_it() -> None:
    context = json.loads((REPO_ROOT / "infra" / "cdk.json").read_text(encoding="utf-8"))["context"]
    assert f"//{WORKER_CONTEXT_FLAG}" in context
    assert WORKER_CONTEXT_FLAG not in context


def test_every_worker_alarm_has_a_runbook_row() -> None:
    runbook = (REPO_ROOT / "docs" / "runbooks" / "alerts.md").read_text(encoding="utf-8")
    for purpose in WORKER_ALARMS:
        assert f"`meridian-<env>-alarm-{purpose}`" in runbook, purpose
    assert "### Job DLQ triage" in runbook


def test_with_the_api_platform_the_worker_requeues_stalled_deliveries_on_one_queue(
    both: cx_api.CloudAssembly,
) -> None:
    """Critic Stage 1 M-8: the outbox tick re-enqueues lost webhook deliveries.

    `WEBHOOK_QUEUE_URL` and `sqs:SendMessage` on `meridian-<env>-sqs-webhooks` alone —
    never its DLQ, never a receive — plus the queue's `logs` CMK through SQS only.
    """
    compute = _template(both, "staging", "compute")
    worker = _env(_container(compute, "WorkerTaskDefinition"))
    assert "meridian-staging-sqs-webhooks" in json.dumps(worker["WEBHOOK_QUEUE_URL"])
    assert "sqs-webhooks-dlq" not in json.dumps(worker["WEBHOOK_QUEUE_URL"])
    by_sid = {s["Sid"]: s for s in _statements(_worker_policy(compute))}
    send = by_sid["RequeueStalledWebhookDeliveries"]
    assert send["Action"] == "sqs:SendMessage"
    resource = send["Resource"]
    assert not isinstance(resource, list)
    assert resource["Fn::Join"][1][-1] == ":meridian-staging-sqs-webhooks"
    assert resource["Fn::Join"][1][2] == ":sqs:"
    key = by_sid["WebhookMessagesThroughSqs"]
    assert sorted(_as_list(key["Action"])) == ["kms:Decrypt", "kms:GenerateDataKey"]
    assert "KeyLogs" in json.dumps(key["Resource"])
    assert "sqs." in json.dumps(key["Condition"]["StringEquals"]["kms:ViaService"])
    # The queue the api stack creates carries that name.
    names = [
        q["Properties"]["QueueName"]
        for q in _resources(_template(both, "staging", "api"), "AWS::SQS::Queue").values()
    ]
    assert "meridian-staging-sqs-webhooks" in names


def test_with_the_api_platform_the_worker_knows_it_and_has_both_webhook_variables(
    both: cx_api.CloudAssembly,
) -> None:
    """Critic Stage 1 round 2 M1: the worker is told the platform is on (the api's own
    `MERIDIAN_API_V3`, copied) so `ports.check_worker_configuration` can refuse to start
    without the bus or the queue — both of which the same flag gives it."""
    compute = _template(both, "staging", "compute")
    worker = _env(_container(compute, "WorkerTaskDefinition"))
    api = _env(_container(compute, "ApiTaskDefinition"))
    assert worker["MERIDIAN_API_V3"] == api["MERIDIAN_API_V3"] == "1"
    assert worker["WEBHOOK_EVENT_BUS"] and worker["WEBHOOK_QUEUE_URL"]


def test_without_the_api_platform_the_worker_has_no_webhook_queue(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    compute = _template(on, env, "compute")
    worker = _env(_container(compute, "WorkerTaskDefinition"))
    assert "WEBHOOK_QUEUE_URL" not in worker
    assert "MERIDIAN_API_V3" not in worker  # no platform: the worker checks nothing
    assert "sqs-webhooks" not in json.dumps(_worker_policy(compute))


# ============================================================ M-10: QuickBooks on AWS
def test_the_qbo_oauth_client_reaches_the_api_and_the_worker_from_secrets_manager(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    """Critic Stage 1 M-10: without these the D18 "Connect QuickBooks" card answers 503 on
    AWS. Secrets Manager references (JSON fields), never plain environment values; the
    execution role reads that one secret (by name, `-??????`) through the `logs` key."""
    env, _, on = pair
    compute = _template(on, env, "compute")
    for prefix in ("ApiTaskDefinition", "WorkerTaskDefinition"):
        container = _container(compute, prefix)
        secrets = {s["Name"]: json.dumps(s["ValueFrom"]) for s in container["Secrets"]}
        assert QBO_SECRETS <= set(secrets), prefix
        for name, field in (("QBO_CLIENT_ID", "client_id"), ("QBO_CLIENT_SECRET", "client_secret")):
            assert f"meridian-{env}/{QBO_OAUTH_SECRET_NAME}" in secrets[name], prefix
            assert secrets[name].endswith(f':{field}::"]]}}'), (prefix, secrets[name])
        assert not QBO_SECRETS & set(_env(container)), prefix
    reads = [
        statement
        for policy in _resources(compute, "AWS::IAM::Policy").values()
        for statement in _statements(policy["Properties"])
        if statement.get("Sid") == "ReadQboOauthSecret"
    ]
    (read,) = reads
    assert f"meridian-{env}/{QBO_OAUTH_SECRET_NAME}-??????" in json.dumps(read["Resource"])
    assert sorted(_as_list(read["Action"])) == [
        "secretsmanager:DescribeSecret",
        "secretsmanager:GetSecretValue",
    ]


def test_the_qbo_environment_and_redirect_uri_match_the_environment(
    pair: tuple[str, cx_api.CloudAssembly, cx_api.CloudAssembly],
) -> None:
    env, _, on = pair
    api = _env(_container(_template(on, env, "compute"), "ApiTaskDefinition"))
    assert api["QBO_ENVIRONMENT"] == ("production" if env == "production" else "sandbox")
    host = "app.meridiansgrp.com" if env == "production" else "staging-app.meridiansgrp.com"
    assert api["QBO_REDIRECT_URI"] == f"https://{host}{QBO_CALLBACK_PATH}"


def test_the_callback_path_is_the_applications() -> None:
    """infra does not import `src`; the path is read from the file and held equal."""
    source = (REPO_ROOT / "src" / "qbo_client.py").read_text(encoding="utf-8")
    match = re.search(r'^DEFAULT_CALLBACK_PATH = "([^"]+)"', source, re.MULTILINE)
    assert match is not None
    assert match.group(1) == QBO_CALLBACK_PATH
