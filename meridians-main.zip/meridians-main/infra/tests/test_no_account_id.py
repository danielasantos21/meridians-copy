"""No AWS account id may appear in `infra/`.

ADR 0001: the account id is written down in exactly one place
(`docs/aws-migration-plan.md` §1) and nowhere else. In `infra/` it is a
*parameter*: account and region come from the CLI environment at deploy time, so
the same code deploys into a second account later with no edit.

This is the grep from the Phase 1 brief, kept as a test so it runs on every
push rather than once:

    grep -rE '[0-9]{12}' infra --include='*.py'

The raw grep has one false positive: `infra/node_modules/aws-cdk/lib/
init-templates/**` is the CDK CLI's own vendored project template, and it carries
AWS's twelve-digit documentation placeholder. It is gitignored, it is not our
code, and this test skips it along with `cdk.out/`.
"""

from __future__ import annotations

import re
from pathlib import Path

from conftest import INFRA_ROOT

#: Twelve consecutive digits with no digit on either side — the shape of an AWS
#: account id. A longer run of digits is something else (a checksum, a nonce)
#: and is not what this guards against.
ACCOUNT_ID = re.compile(r"(?<!\d)\d{12}(?!\d)")

SKIP_DIRS = {"cdk.out", "node_modules", "__pycache__", ".venv", "venv"}


def _python_files() -> list[Path]:
    return [
        path
        for path in INFRA_ROOT.rglob("*.py")
        if not SKIP_DIRS.intersection(path.relative_to(INFRA_ROOT).parts)
    ]


def test_no_twelve_digit_literal_in_any_infra_python_file() -> None:
    offenders: list[str] = []
    for path in _python_files():
        for lineno, line in enumerate(path.read_text().splitlines(), start=1):
            if ACCOUNT_ID.search(line):
                offenders.append(f"{path.relative_to(INFRA_ROOT)}:{lineno}: {line.strip()}")
    assert not offenders, "possible AWS account id in infra/:\n" + "\n".join(offenders)


def test_the_guard_itself_works() -> None:
    """A guard that cannot fail is not a guard."""
    assert ACCOUNT_ID.search("arn:aws:iam::" + "4" * 12 + ":root")
    assert not ACCOUNT_ID.search("retention 2555 days")


def test_config_files_are_clean_too() -> None:
    """cdk.json and requirements.txt are read at deploy time; check them as well."""
    for name in ("cdk.json", "requirements.txt", "package.json"):
        text = (INFRA_ROOT / name).read_text()
        assert not ACCOUNT_ID.search(text), f"possible account id in infra/{name}"
