"""Phase 12 T21: the `/api/v3` platform's AWS side, behind `-c enableApiPlatform=true`.

Two halves, and the first is the one that protects production today:

* **Off (the default), nothing changes.** The api stack stays empty, the placeholder
  machine client and its two scopes stay, no security group, WAF rule or task
  variable appears. A deploy of this branch before the cost approval is a no-op.
* **On, every control the plan and ADRs 0037/0038 name is present** — the scope
  catalogue equals `src/api_scopes.py`'s machine-grantable set minus `phi:read`; the
  api's Cognito rights are exactly the seven calls the admin adapter makes, on one
  pool, and never `DescribeUserPoolClient`; the sender is its own principal with no
  PHI reach; queues are KMS-encrypted with a DLQ after eight receives.

Synth runs with the CDK's `aws:cdk:bundling-stacks` set to `[]`, which skips the
Lambda asset's Docker build — the tests read the template, not the zip.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

import pytest
from aws_cdk import assertions, cx_api
from conftest import NETWORK_CONTEXT, synth_with

from meridian.api_platform import RUN_EVENT_SOURCE
from meridian.config import API_PLATFORM_CONTEXT_FLAG
from meridian.stacks.api import (
    COGNITO_CLIENT_ADMIN_ACTIONS,
    IDLE_SWEEP_ACTOR_CONTEXT,
    WEBHOOK_MAX_RECEIVES,
    WEBHOOK_RESERVED_CONCURRENCY,
)
from meridian.stacks.auth import API_PLATFORM_MACHINE_SCOPES, MACHINE_SCOPES
from meridian.stacks.edge import API_V3_PATH_PREFIX, RATE_LIMIT_API_V3

REPO_ROOT = Path(__file__).resolve().parents[2]
ENVIRONMENTS = ("staging", "production")

#: A placeholder, not a person: the shape of an application user id.
ACTOR = "00000000-0000-0000-0000-0000000000aa"

ON = {API_PLATFORM_CONTEXT_FLAG: "true", "aws:cdk:bundling-stacks": [], **NETWORK_CONTEXT}


def _load(relative: str, name: str) -> Any:
    """A `src/` module by path — `infra/` does not put the repo root on sys.path."""
    spec = importlib.util.spec_from_file_location(name, REPO_ROOT / relative)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    # Registered first: a dataclass resolves its annotations through sys.modules.
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def off() -> cx_api.CloudAssembly:
    return synth_with("staging", **NETWORK_CONTEXT)


@pytest.fixture(scope="module", params=ENVIRONMENTS)
def on(request: pytest.FixtureRequest) -> tuple[str, cx_api.CloudAssembly]:
    env = str(request.param)
    return env, synth_with(env, **ON, **{IDLE_SWEEP_ACTOR_CONTEXT: ACTOR})


@pytest.fixture(scope="module")
def on_without_actor() -> cx_api.CloudAssembly:
    return synth_with("staging", **ON)


def _template(assembly: cx_api.CloudAssembly, env: str, component: str) -> dict[str, Any]:
    return assembly.get_stack_by_name(f"meridian-{env}-{component}").template


def _resources(template: dict[str, Any], type_name: str) -> dict[str, Any]:
    return {
        name: resource
        for name, resource in template.get("Resources", {}).items()
        if resource["Type"] == type_name
    }


def _statements(template: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for resource in template.get("Resources", {}).values():
        if resource["Type"] == "AWS::IAM::Policy":
            out.extend(resource["Properties"]["PolicyDocument"]["Statement"])
        if resource["Type"] == "AWS::IAM::Role":
            for policy in resource["Properties"].get("Policies", []) or []:
                out.extend(policy["PolicyDocument"]["Statement"])
    return out


def _actions(statement: dict[str, Any]) -> list[str]:
    actions = statement.get("Action", [])
    return [actions] if isinstance(actions, str) else list(actions)


# ============================================================ off: nothing moves
def test_off_the_api_stack_is_empty(off: cx_api.CloudAssembly) -> None:
    resources = {
        name: r
        for name, r in _template(off, "staging", "api").get("Resources", {}).items()
        if r["Type"] != "AWS::CDK::Metadata"
    }
    assert resources == {}


def test_off_the_placeholder_machine_client_and_its_scopes_stay(
    off: cx_api.CloudAssembly,
) -> None:
    auth = _template(off, "staging", "auth")
    names = [
        c["Properties"]["ClientName"]
        for c in _resources(auth, "AWS::Cognito::UserPoolClient").values()
    ]
    assert "meridian-staging-auth-machine" in names
    server = next(iter(_resources(auth, "AWS::Cognito::UserPoolResourceServer").values()))
    assert [s["ScopeName"] for s in server["Properties"]["Scopes"]] == [
        name for name, _ in MACHINE_SCOPES
    ]


def test_off_no_security_group_waf_rule_or_task_variable_appears(
    off: cx_api.CloudAssembly,
) -> None:
    vpc = _template(off, "staging", "vpc")
    group_names = [
        g["Properties"].get("GroupName")
        for g in _resources(vpc, "AWS::EC2::SecurityGroup").values()
    ]
    assert "meridian-staging-sg-webhook-sender" not in group_names

    edge = _template(off, "staging", "edge")
    acl = next(iter(_resources(edge, "AWS::WAFv2::WebACL").values()))
    assert "RateLimitApiV3PerIp" not in [r["Name"] for r in acl["Properties"]["Rules"]]

    compute = json.dumps(_template(off, "staging", "compute"))
    assert "WEBHOOK_QUEUE_URL" not in compute


# ======================================================== on: Cognito and IAM
def test_the_scope_catalogue_is_src_minus_phi_read(on: tuple[str, Any]) -> None:
    env, assembly = on
    scopes = _load("src/api_scopes.py", "api_scopes_for_infra_test")
    expected = sorted(scopes.MACHINE_GRANTABLE_SCOPES - {scopes.PHI_READ})
    server = next(
        iter(
            _resources(
                _template(assembly, env, "auth"), "AWS::Cognito::UserPoolResourceServer"
            ).values()
        )
    )
    names = [s["ScopeName"] for s in server["Properties"]["Scopes"]]
    assert names == expected
    assert names == [name for name, _ in API_PLATFORM_MACHINE_SCOPES]
    assert "runs:write" not in names
    assert not any("phi" in name for name in names)


def test_the_placeholder_machine_client_is_gone(on: tuple[str, Any]) -> None:
    env, assembly = on
    auth = _template(assembly, env, "auth")
    names = [
        c["Properties"]["ClientName"]
        for c in _resources(auth, "AWS::Cognito::UserPoolClient").values()
    ]
    assert names == [f"meridian-{env}-auth-web"]
    assert "MachineClientId" not in auth.get("Outputs", {})


def test_the_api_may_manage_app_clients_on_its_own_pool_only(on: tuple[str, Any]) -> None:
    env, assembly = on
    statements = [
        s
        for s in _statements(_template(assembly, env, "api"))
        if any(a.startswith("cognito-idp:") for a in _actions(s))
    ]
    assert len(statements) == 1
    statement = statements[0]
    assert sorted(_actions(statement)) == sorted(COGNITO_CLIENT_ADMIN_ACTIONS)
    # One resource: the pool ARN, imported from the auth stack — never "*".
    resource = statement["Resource"]
    assert isinstance(resource, dict) and "Fn::ImportValue" in resource
    assert f"meridian-{env}-auth" in json.dumps(resource)


def test_the_admin_actions_are_every_call_the_adapter_makes() -> None:
    """Each boto3 operation `BotoCognitoClientAdmin` calls has its IAM action here."""
    source = (REPO_ROOT / "src" / "cognito_client_admin.py").read_text(encoding="utf-8")
    called = {
        "".join(part.capitalize() for part in op.split("_"))
        for op in (
            "create_user_pool_client",
            "update_user_pool_client",
            "delete_user_pool_client",
            "add_user_pool_client_secret",
            "delete_user_pool_client_secret",
            "list_user_pool_client_secrets",
            "list_user_pool_clients",
        )
        if f'"{op}"' in source
    }
    assert len(called) == 7
    assert {a.split(":", 1)[1] for a in COGNITO_CLIENT_ADMIN_ACTIONS} == called


def test_nothing_anywhere_may_describe_a_client(on: tuple[str, Any]) -> None:
    """`DescribeUserPoolClient` returns the secret (ADR 0037)."""
    env, assembly = on
    for artifact in assembly.stacks:
        assert "DescribeUserPoolClient" not in json.dumps(artifact.template), artifact.stack_name


def test_webhook_secret_rights_are_prefix_scoped(on: tuple[str, Any]) -> None:
    env, assembly = on
    for statement in _statements(_template(assembly, env, "api")):
        if not any(a.startswith("secretsmanager:") for a in _actions(statement)):
            continue
        resources = statement["Resource"]
        rendered = json.dumps(resources)
        assert rendered != '"*"'
        if any(
            a in ("secretsmanager:CreateSecret", "secretsmanager:DeleteSecret")
            for a in _actions(statement)
        ):
            assert f"secret:meridian-{env}-webhook-*" in rendered


# ============================================================ on: the webhook path
def test_the_rule_matches_the_source_the_publisher_uses(on: tuple[str, Any]) -> None:
    env, assembly = on
    ports = (REPO_ROOT / "src" / "webhooks" / "ports.py").read_text(encoding="utf-8")
    assert f'EVENT_SOURCE = "{RUN_EVENT_SOURCE}"' in ports
    api = _template(assembly, env, "api")
    rule = next(iter(_resources(api, "AWS::Events::Rule").values()))["Properties"]
    assert rule["EventPattern"] == {"source": [RUN_EVENT_SOURCE]}
    bus = next(iter(_resources(api, "AWS::Events::EventBus").values()))["Properties"]
    assert bus["Name"] == f"meridian-{env}-events-api"


def test_queues_are_kms_encrypted_with_a_dlq_after_eight_receives(
    on: tuple[str, Any],
) -> None:
    env, assembly = on
    queues = {
        q["Properties"]["QueueName"]: q["Properties"]
        for q in _resources(_template(assembly, env, "api"), "AWS::SQS::Queue").values()
    }
    assert set(queues) == {f"meridian-{env}-sqs-webhooks", f"meridian-{env}-sqs-webhooks-dlq"}
    for props in queues.values():
        assert "KmsMasterKeyId" in props
        assert "KeyLogs" in json.dumps(props["KmsMasterKeyId"])
    redrive = queues[f"meridian-{env}-sqs-webhooks"]["RedrivePolicy"]
    assert redrive["maxReceiveCount"] == WEBHOOK_MAX_RECEIVES == 8


def test_only_this_rule_may_send_to_the_queue(on: tuple[str, Any]) -> None:
    env, assembly = on
    events_statements = [
        (policy["Properties"]["Queues"], s)
        for policy in _resources(_template(assembly, env, "api"), "AWS::SQS::QueuePolicy").values()
        for s in policy["Properties"]["PolicyDocument"]["Statement"]
        if s.get("Principal") == {"Service": "events.amazonaws.com"}
    ]
    assert len(events_statements) == 1
    queues, statement = events_statements[0]
    assert "WebhookQueue" in json.dumps(queues)
    assert statement["Action"] == "sqs:SendMessage"
    assert "aws:SourceArn" in json.dumps(statement["Condition"])


def test_the_sender_is_arm64_in_the_vpc_with_two_concurrent_executions(
    on: tuple[str, Any],
) -> None:
    env, assembly = on
    fn = next(iter(_resources(_template(assembly, env, "api"), "AWS::Lambda::Function").values()))[
        "Properties"
    ]
    assert fn["FunctionName"] == f"meridian-{env}-lambda-webhook-sender"
    assert fn["Architectures"] == ["arm64"]
    assert fn["ReservedConcurrentExecutions"] == WEBHOOK_RESERVED_CONCURRENCY == 2
    assert fn["VpcConfig"]["SecurityGroupIds"]
    variables = fn["Environment"]["Variables"]
    assert "PGPASSWORD" not in variables
    assert variables["PGSSLMODE"] == "verify-full"
    assert "WEBHOOK_DB_SECRET_ARN" in variables
    mapping = next(
        iter(
            _resources(_template(assembly, env, "api"), "AWS::Lambda::EventSourceMapping").values()
        )
    )["Properties"]
    assert mapping["FunctionResponseTypes"] == ["ReportBatchItemFailures"]


def test_the_sender_role_reaches_no_phi(on: tuple[str, Any]) -> None:
    """Separate principal (plan R7): no bucket, no PHI key, no phi_access credential."""
    env, assembly = on
    api = _template(assembly, env, "api")
    role_policies = [
        s
        for name, r in _resources(api, "AWS::IAM::Policy").items()
        if "WebhookSenderRole" in name
        for s in r["Properties"]["PolicyDocument"]["Statement"]
    ]
    assert role_policies
    rendered = json.dumps(role_policies)
    for forbidden in ("s3:", "KeyPhi", "DbPhiSecret", "PhiHmac", "events:PutEvents"):
        assert forbidden not in rendered, forbidden
    for statement in role_policies:
        assert statement["Resource"] != "*"


def test_the_sender_security_group_is_443_out_and_postgres_only(
    on: tuple[str, Any],
) -> None:
    env, assembly = on
    vpc = _template(assembly, env, "vpc")
    sg_id, sg = next(
        (name, g)
        for name, g in _resources(vpc, "AWS::EC2::SecurityGroup").items()
        if g["Properties"].get("GroupName") == f"meridian-{env}-sg-webhook-sender"
    )
    assert not sg["Properties"].get("SecurityGroupIngress")
    egress = sg["Properties"]["SecurityGroupEgress"]
    assert egress == [
        {
            "CidrIp": "0.0.0.0/0",
            "Description": "Partner webhook endpoints and the AWS APIs, through the NAT",
            "FromPort": 443,
            "IpProtocol": "tcp",
            "ToPort": 443,
        }
    ]
    separate = [
        r["Properties"]
        for r in _resources(vpc, "AWS::EC2::SecurityGroupEgress").values()
        if r["Properties"]["GroupId"] == {"Fn::GetAtt": [sg_id, "GroupId"]}
    ]
    assert [(e["FromPort"], e["ToPort"]) for e in separate] == [(5432, 5432)]
    ingress_to_data = [
        r["Properties"]
        for r in _resources(vpc, "AWS::EC2::SecurityGroupIngress").values()
        if r["Properties"].get("SourceSecurityGroupId") == {"Fn::GetAtt": [sg_id, "GroupId"]}
    ]
    assert [(i["FromPort"], i["ToPort"]) for i in ingress_to_data] == [(5432, 5432)]


def test_the_api_task_is_told_where_the_webhook_machinery_is(on: tuple[str, Any]) -> None:
    env, assembly = on
    compute = _template(assembly, env, "compute")
    task = next(
        t
        for t in _resources(compute, "AWS::ECS::TaskDefinition").values()
        if t["Properties"]["Family"] == f"meridian-{env}-ecs-api"
    )
    variables = {
        v["Name"]: v["Value"] for v in task["Properties"]["ContainerDefinitions"][0]["Environment"]
    }
    for name in (
        "WEBHOOK_QUEUE_URL",
        "WEBHOOK_DLQ_URL",
        "WEBHOOK_EVENT_BUS",
        "WEBHOOK_SECRETS_KMS_KEY_ID",
        "WEBHOOK_BLOCKED_CIDRS",
    ):
        assert name in variables, name
    assert variables["WEBHOOK_EVENT_BUS"] == f"meridian-{env}-events-api"
    assert f"meridian-{env}-sqs-webhooks" in json.dumps(variables["WEBHOOK_QUEUE_URL"])


# ============================================================== on: the edge
def test_the_waf_carries_the_api_v3_rate_rule(on: tuple[str, Any]) -> None:
    env, assembly = on
    acl = next(iter(_resources(_template(assembly, env, "edge"), "AWS::WAFv2::WebACL").values()))
    rule = next(r for r in acl["Properties"]["Rules"] if r["Name"] == "RateLimitApiV3PerIp")
    statement = rule["Statement"]["RateBasedStatement"]
    assert statement["Limit"] == RATE_LIMIT_API_V3
    assert statement["AggregateKeyType"] == "IP"
    # ADR 0050: the `api` host as a whole, or `/api/v3/` on any host (the React
    # admin screens call the same routes on `app`).
    host, path = (
        s["ByteMatchStatement"]
        for s in statement["ScopeDownStatement"]["OrStatement"]["Statements"]
    )
    assert host["FieldToMatch"] == {"SingleHeader": {"Name": "host"}}
    assert host["PositionalConstraint"] == "EXACTLY"
    assert host["SearchString"] == ("api" if env == "production" else f"{env}-api") + (
        ".meridiansgrp.com"
    )
    assert path["SearchString"] == API_V3_PATH_PREFIX
    assert "Block" in rule["Action"]
    priorities = [r["Priority"] for r in acl["Properties"]["Rules"]]
    assert len(priorities) == len(set(priorities))


# ============================================================ on: alarms, sweep
def test_both_alarms_notify_on_both_transitions(on: tuple[str, Any]) -> None:
    env, assembly = on
    alarms = {
        a["Properties"]["AlarmName"]: a["Properties"]
        for a in _resources(_template(assembly, env, "api"), "AWS::CloudWatch::Alarm").values()
    }
    assert set(alarms) == {
        f"meridian-{env}-alarm-webhook-dlq",
        f"meridian-{env}-alarm-machine-auth-failures",
    }
    for props in alarms.values():
        assert props["AlarmActions"] and not props.get("OKActions")


def test_the_auth_failure_filter_matches_the_line_the_api_writes(on: tuple[str, Any]) -> None:
    env, assembly = on
    deps = (REPO_ROOT / "api" / "v3" / "deps.py").read_text(encoding="utf-8")
    assert "v3 machine token refused" in deps
    metric_filter = next(
        iter(_resources(_template(assembly, env, "api"), "AWS::Logs::MetricFilter").values())
    )
    assert "v3 machine token refused" in metric_filter["Properties"]["FilterPattern"]


def test_the_auth_failure_metric_is_per_environment(on: tuple[str, Any]) -> None:
    """A text filter has no `$.env` to take a dimension from; without the environment
    in the name, staging's and production's refusals would sum on one metric."""
    env, assembly = on
    api = _template(assembly, env, "api")
    metric_filter = next(iter(_resources(api, "AWS::Logs::MetricFilter").values()))
    transform = metric_filter["Properties"]["MetricTransformations"][0]
    assert transform["MetricName"] == f"MachineTokenRefused-{env}"
    alarm = next(
        a["Properties"]
        for a in _resources(api, "AWS::CloudWatch::Alarm").values()
        if a["Properties"]["AlarmName"].endswith("machine-auth-failures")
    )
    assert alarm["MetricName"] == f"MachineTokenRefused-{env}"


def _schedules(api: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        s["Properties"]["Name"]: s["Properties"]
        for s in _resources(api, "AWS::Scheduler::Schedule").values()
    }


def test_the_idle_sweep_runs_the_script_as_the_named_actor(on: tuple[str, Any]) -> None:
    env, assembly = on
    api = _template(assembly, env, "api")
    schedule = _schedules(api)[f"meridian-{env}-schedule-idle-api-clients"]
    overrides = json.loads(schedule["Target"]["Input"])
    command = overrides["containerOverrides"][0]["command"]
    assert command == ["python3", "scripts/disable_idle_api_clients.py", "--actor", ACTOR]
    assert (REPO_ROOT / "scripts" / "disable_idle_api_clients.py").is_file()
    assert schedule["Target"]["EcsParameters"]["LaunchType"] == "FARGATE"
    # One RunTask statement, the idle sweep's (the outbox sweep is a worker tick, D17).
    run_task = [s for s in _statements(api) if "ecs:RunTask" in _actions(s)]
    assert len(run_task) == 1
    for statement in run_task:
        assert statement["Resource"] != "*"
        assert "ecs:cluster" in json.dumps(statement["Condition"])


def test_without_an_actor_the_sweep_is_not_scheduled_and_synth_warns(
    on_without_actor: cx_api.CloudAssembly,
) -> None:
    api = _template(on_without_actor, "staging", "api")
    # The idle sweep was the only schedule here (the outbox sweep is a worker tick, D17).
    assert set(_schedules(api)) == set()
    messages = [
        str(m.entry.data)
        for m in on_without_actor.get_stack_by_name("meridian-staging-api").messages
        if m.entry.type == "aws:cdk:warning"
    ]
    assert any(IDLE_SWEEP_ACTOR_CONTEXT in m for m in messages)


def test_the_actor_never_lands_in_the_repository() -> None:
    """A user id names a person: it is passed with -c and never committed."""
    cdk_json = (REPO_ROOT / "infra" / "cdk.json").read_text(encoding="utf-8")
    assert f'"{IDLE_SWEEP_ACTOR_CONTEXT}":' not in cdk_json


def test_on_synth_has_no_errors_and_every_resource_is_tagged(on: tuple[str, Any]) -> None:
    env, assembly = on
    for artifact in assembly.stacks:
        errors = [m for m in artifact.messages if m.entry.type == "aws:cdk:error"]
        assert not errors, (artifact.stack_name, [str(m.entry.data) for m in errors])
    api = assertions.Template.from_json(_template(assembly, env, "api"))
    api.all_resources_properties(
        "AWS::SQS::Queue",
        {"Tags": assertions.Match.array_with([{"Key": "Environment", "Value": env}])},
    )


# ============================================================ on: the outbox sweep (T19, D17)
def test_the_api_stack_no_longer_runs_the_outbox_sweep_as_a_task(on: tuple[str, Any]) -> None:
    """Decision D17: the 5-minute sweep is a job-queue tick the worker handles, ≈ $0."""
    env, assembly = on
    api = _template(assembly, env, "api")
    assert f"meridian-{env}-schedule-outbox-sweep" not in _schedules(api)
    roles = {r["Properties"]["RoleName"] for r in _resources(api, "AWS::IAM::Role").values()}
    assert f"meridian-{env}-iam-outbox-sweep" not in roles
    assert "workers.outbox_sweep" not in json.dumps(api)


def test_without_the_worker_synth_says_the_outbox_sweep_is_not_scheduled(
    on: tuple[str, Any],
) -> None:
    env, assembly = on
    messages = [
        str(m.entry.data)
        for m in assembly.get_stack_by_name(f"meridian-{env}-api").messages
        if m.entry.type == "aws:cdk:warning"
    ]
    assert any("outbox sweep is NOT scheduled" in m for m in messages)


def test_the_sweeps_name_the_api_task_family_never_its_revision(on: tuple[str, Any]) -> None:
    """An imported revision ARN would block every `compute` deploy (export in use)."""
    env, assembly = on
    api = _template(assembly, env, "api")
    compute = _template(assembly, env, "compute")
    assert "ApiTaskDefinition" not in json.dumps(api), "the api stack imports the revision ARN"
    family = next(
        t["Properties"]["Family"]
        for t in _resources(compute, "AWS::ECS::TaskDefinition").values()
        if t["Properties"]["Family"].endswith("-ecs-api")
    )
    for schedule in _schedules(api).values():
        arn = json.dumps(schedule["Target"]["EcsParameters"]["TaskDefinitionArn"])
        assert arn.endswith(f':task-definition/{family}"]]}}'), arn
    for statement in (s for s in _statements(api) if "ecs:RunTask" in _actions(s)):
        rendered = [json.dumps(r) for r in statement["Resource"]]
        assert len(rendered) == 2
        assert rendered[0].endswith(f':task-definition/{family}"]]}}')
        assert rendered[1].endswith(f':task-definition/{family}:*"]]}}')


def test_the_api_task_can_reach_the_bus(on: tuple[str, Any]) -> None:
    """What the api's publish and a manual `python -m workers.outbox_sweep` (ECS Exec on the
    api task) read: `WEBHOOK_EVENT_BUS`; what they call: PutEvents."""
    env, assembly = on
    compute = _template(assembly, env, "compute")
    api_task = next(
        t["Properties"]
        for t in _resources(compute, "AWS::ECS::TaskDefinition").values()
        if t["Properties"]["Family"] == f"meridian-{env}-ecs-api"
    )
    environment = {
        e["Name"]: e["Value"] for e in api_task["ContainerDefinitions"][0]["Environment"]
    }
    assert environment["WEBHOOK_EVENT_BUS"] == f"meridian-{env}-events-api"
    put_events = [
        s for s in _statements(_template(assembly, env, "api")) if "events:PutEvents" in _actions(s)
    ]
    assert len(put_events) == 1 and "EventBus" in json.dumps(put_events[0]["Resource"])


# ============================== critic Stage 1 H-2: v3 and the platform are one switch
#: `src/webhooks/ports.AWS_ENV` — what the api refuses to start without outside
#: development. Retyped here because `infra/` does not import `src/`; the test below
#: holds the two lists together.
WEBHOOK_REQUIRED_ENV = (
    "WEBHOOK_QUEUE_URL",
    "WEBHOOK_DLQ_URL",
    "WEBHOOK_EVENT_BUS",
    "WEBHOOK_SECRETS_KMS_KEY_ID",
)


def test_the_required_list_is_the_one_the_api_enforces() -> None:
    source = (REPO_ROOT / "src" / "webhooks" / "ports.py").read_text(encoding="utf-8")
    assert "AWS_ENV = (QUEUE_URL_ENV, DLQ_URL_ENV, EVENT_BUS_ENV, SECRETS_KMS_KEY_ENV)" in source
    for name in WEBHOOK_REQUIRED_ENV:
        assert f'"{name}"' in source, name


def test_with_the_platform_v3_is_on_and_everything_it_needs_is_set(on: tuple[str, Any]) -> None:
    env, assembly = on
    compute = _template(assembly, env, "compute")
    task = next(
        t
        for t in _resources(compute, "AWS::ECS::TaskDefinition").values()
        if t["Properties"]["Family"] == f"meridian-{env}-ecs-api"
    )
    variables = {
        v["Name"]: v["Value"] for v in task["Properties"]["ContainerDefinitions"][0]["Environment"]
    }
    assert variables["MERIDIAN_API_V3"] == "1"
    for name in WEBHOOK_REQUIRED_ENV:
        assert variables.get(name), name
    # The sender Lambda runs the same engine and the same check.
    fn = next(iter(_resources(_template(assembly, env, "api"), "AWS::Lambda::Function").values()))
    lambda_variables = fn["Properties"]["Environment"]["Variables"]
    for name in WEBHOOK_REQUIRED_ENV:
        assert lambda_variables.get(name), name


def test_without_the_platform_v3_is_switched_on_nowhere(off: cx_api.CloudAssembly) -> None:
    """`MERIDIAN_API_V3` is set by `_api_platform_environment` alone: v3 on with the
    platform off cannot be configured through CDK."""
    for artifact in off.stacks:
        assert "MERIDIAN_API_V3" not in json.dumps(artifact.template), artifact.stack_name
    setters = sorted(
        path.name
        for path in (REPO_ROOT / "infra" / "meridian").rglob("*.py")
        if '"MERIDIAN_API_V3"' in path.read_text(encoding="utf-8")
    )
    # `worker.py` names it only to COPY the api's value (`WORKER_ENV_FROM_API`, critic
    # Stage 1 round 2 M1); `compute.py` is still the one place that sets it.
    assert setters == ["compute.py", "worker.py"]
    from meridian.stacks.worker import WORKER_ENV_FROM_API

    assert "MERIDIAN_API_V3" in WORKER_ENV_FROM_API
    worker_source = (REPO_ROOT / "infra" / "meridian" / "stacks" / "worker.py").read_text(
        encoding="utf-8"
    )
    assert '"MERIDIAN_API_V3":' not in worker_source, "copied, never assigned"
