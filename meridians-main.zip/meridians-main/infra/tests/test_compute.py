"""`meridian-<env>-compute` — the synthesized template.

Assertions on the **template**, not on the code that wrote it, so a refactor
that quietly changes what CloudFormation receives fails here.

What these are really about: the constraints in `compute.py`'s docstring that
are correctness, not tuning. One api task. ARM64. A circuit breaker that rolls
back. Immutable, scanned images. And roles whose only `Resource: "*"` statements
are the three AWS defines that way —
`test_the_roles_have_no_undocumented_wildcard` is what fails when a fourth
appears, and `ALLOWED_WILDCARD_ACTIONS` is where its reason has to be written.

No AWS calls, no credentials — `conftest.synth` builds the app in-process.
"""

from __future__ import annotations

import json
import pathlib
import re
from collections.abc import Mapping
from typing import Any

import pytest
from aws_cdk import assertions
from conftest import NETWORK_CONTEXT, stack_template, synth_with

from meridian.config import (
    ECW_DB_CONTEXT_FLAG,
    QBO_ENVIRONMENT_CONTEXT_KEY,
    QBO_OAUTH_CONTEXT_FLAG,
    WORKER_CONTEXT_FLAG,
)
from meridian.stacks.compute import (
    ASK_PROFILE_IDS,
    DEFAULT_IMAGE_TAG,
    ECW_DB_SECRET_NAME,
    QBO_CALLBACK_PATH,
    QBO_OAUTH_SECRET_NAME,
)

API_HEALTH_PATH = "/api/v1/health"


@pytest.fixture(scope="module")
def staging_compute() -> assertions.Template:
    return stack_template("staging", "compute")


@pytest.fixture(scope="module")
def production_compute() -> assertions.Template:
    return stack_template("production", "compute")


def _resources(template: assertions.Template, kind: str) -> Mapping[str, Mapping[str, Any]]:
    return template.find_resources(kind)


def _one(template: assertions.Template, kind: str, **match) -> Mapping[str, Any]:
    found = [
        body
        for body in _resources(template, kind).values()
        if all(body["Properties"].get(k) == v for k, v in match.items())
    ]
    assert len(found) == 1, f"expected exactly one {kind} matching {match}, found {len(found)}"
    return found[0]["Properties"]


# ---------------------------------------------------------------------------
# ECR
# ---------------------------------------------------------------------------
def test_compute_creates_no_repository(staging_compute: assertions.Template):
    """The repositories live in the persistent `data` stack (test_data.py): a
    `RETAIN`ed repository in this destroyed-every-session stack collided on the
    next `up`, and left the first deploy nowhere to push an image."""
    assert _resources(staging_compute, "AWS::ECR::Repository") == {}


# ---------------------------------------------------------------------------
# the cluster
# ---------------------------------------------------------------------------
def test_container_insights_is_enabled(staging_compute: assertions.Template):
    """Without it, "the task restarted" is not a number anyone can alarm on."""
    cluster = _one(staging_compute, "AWS::ECS::Cluster")
    settings = {s["Name"]: s["Value"] for s in cluster["ClusterSettings"]}
    assert settings["containerInsights"] == "enabled"


def test_every_ecs_exec_session_is_logged(staging_compute: assertions.Template):
    """An interactive shell in a task that can reach PHI is an access event."""
    cluster = _one(staging_compute, "AWS::ECS::Cluster")
    config = cluster["Configuration"]["ExecuteCommandConfiguration"]
    assert config["Logging"] == "OVERRIDE"
    assert config["LogConfiguration"]["CloudWatchEncryptionEnabled"] is True
    assert "CloudWatchLogGroupName" in config["LogConfiguration"]
    assert "KmsKeyId" in config


# ---------------------------------------------------------------------------
# log groups
# ---------------------------------------------------------------------------
def test_log_groups_are_encrypted_and_kept_for_400_days(staging_compute: assertions.Template):
    """400 days is why `scripts/lint_no_phi_logging.py` is a build-breaking lint."""
    groups = _resources(staging_compute, "AWS::Logs::LogGroup")
    assert len(groups) == 3
    for body in groups.values():
        assert body["Properties"]["RetentionInDays"] == 400
        assert "KmsKeyId" in body["Properties"]


# ---------------------------------------------------------------------------
# task definitions
# ---------------------------------------------------------------------------
def test_both_task_definitions_are_arm64(staging_compute: assertions.Template):
    """Graviton. A mismatched image fails at task start with `exec format error`."""
    definitions = _resources(staging_compute, "AWS::ECS::TaskDefinition")
    assert len(definitions) == 2
    for body in definitions.values():
        assert body["Properties"]["RuntimePlatform"] == {
            "CpuArchitecture": "ARM64",
            "OperatingSystemFamily": "LINUX",
        }
        assert body["Properties"]["RequiresCompatibilities"] == ["FARGATE"]
        assert body["Properties"]["NetworkMode"] == "awsvpc"


def test_the_api_task_is_one_vcpu_two_gigabytes_and_forty_gibibytes(
    staging_compute: assertions.Template,
):
    api = _one(staging_compute, "AWS::ECS::TaskDefinition", Family="meridian-staging-ecs-api")
    assert api["Cpu"] == "1024"
    assert api["Memory"] == "2048"
    assert api["EphemeralStorage"] == {"SizeInGiB": 40}


def test_the_web_task_is_the_smallest_fargate_size(staging_compute: assertions.Template):
    web = _one(staging_compute, "AWS::ECS::TaskDefinition", Family="meridian-staging-ecs-web")
    assert web["Cpu"] == "256"
    assert web["Memory"] == "512"


def test_a_stopping_task_gets_two_minutes(staging_compute: assertions.Template):
    """A revenue run writing journal entries needs longer than the 30s default."""
    for body in _resources(staging_compute, "AWS::ECS::TaskDefinition").values():
        for container in body["Properties"]["ContainerDefinitions"]:
            assert container["StopTimeout"] == 120


def test_the_api_container_health_check_is_the_alb_path(staging_compute: assertions.Template):
    """The same route the target group checks (D-25), so the two cannot disagree."""
    api = _one(staging_compute, "AWS::ECS::TaskDefinition", Family="meridian-staging-ecs-api")
    (container,) = api["ContainerDefinitions"]
    command = " ".join(container["HealthCheck"]["Command"])
    assert API_HEALTH_PATH in command


def test_flask_env_is_production_in_the_task_definition(staging_compute: assertions.Template):
    """`src/auth.py:224` keys the Secure cookie flag off this name."""
    api = _one(staging_compute, "AWS::ECS::TaskDefinition", Family="meridian-staging-ecs-api")
    (container,) = api["ContainerDefinitions"]
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    assert environment["FLASK_ENV"] == "production"
    assert environment["APP_ENV"] == "staging"


def test_the_backend_switches_are_explicit(staging_compute: assertions.Template):
    """An unset switch used to mean "silently use SQLite on an ephemeral disk"."""
    api = _one(staging_compute, "AWS::ECS::TaskDefinition", Family="meridian-staging-ecs-api")
    (container,) = api["ContainerDefinitions"]
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    assert environment["DATABASE_BACKEND"] == "postgres"
    assert environment["STORAGE_BACKEND"] == "s3"
    assert environment["AUTH_BACKEND"] == "cognito"


def test_tls_to_the_database_is_verify_full_with_a_bundle(staging_compute: assertions.Template):
    """`require` encrypts but does not authenticate the server."""
    api = _one(staging_compute, "AWS::ECS::TaskDefinition", Family="meridian-staging-ecs-api")
    (container,) = api["ContainerDefinitions"]
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    assert environment["PGSSLMODE"] == "verify-full"
    assert environment["PG_SSLROOTCERT"] == "/etc/ssl/rds/global-bundle.pem"


def test_no_environment_variable_holds_a_credential(staging_compute: assertions.Template):
    """The password is a `Secrets` reference; nothing in `Environment` is one.

    `Environment` values are plain strings or CloudFormation references in a
    template anyone who can read the stack can see. A password there is a
    password published.
    """
    api = _one(staging_compute, "AWS::ECS::TaskDefinition", Family="meridian-staging-ecs-api")
    (container,) = api["ContainerDefinitions"]
    names = {e["Name"] for e in container["Environment"]}
    assert (
        not {
            "PGPASSWORD",
            "POSTGRES_URL",
            "DATABASE_URL",
            "COGNITO_CLIENT_SECRET",
            "RESEND_API_KEY",
            "MERIDIAN_PHI_HMAC_KEY",
        }
        & names
    )
    secrets = {s["Name"] for s in container["Secrets"]}
    assert secrets == {"PGPASSWORD", "COGNITO_CLIENT_SECRET", "FLASK_SECRET_KEY"}


# ---------------------------------------------------------------------------
# services
# ---------------------------------------------------------------------------
def _service(template: assertions.Template, name: str) -> Mapping[str, Any]:
    return _one(template, "AWS::ECS::Service", ServiceName=name)


def test_the_api_service_runs_exactly_one_task_in_both_environments(
    staging_compute: assertions.Template, production_compute: assertions.Template
):
    """Two api tasks mis-book journal entries silently. See `compute.py`.

    The deployment configuration matters as much as the count: the default
    (100/200) would briefly run two DURING a deploy, which is the same failure
    arriving at a different moment.
    """
    for template in (staging_compute, production_compute):
        env = "staging" if template is staging_compute else "production"
        api = _service(template, f"meridian-{env}-ecs-svc-api")
        assert api["DesiredCount"] == 1
        configuration = api["DeploymentConfiguration"]
        assert configuration["MinimumHealthyPercent"] == 0
        assert configuration["MaximumPercent"] == 100


def test_the_web_service_scales_with_the_environment(
    staging_compute: assertions.Template, production_compute: assertions.Template
):
    assert _service(staging_compute, "meridian-staging-ecs-svc-web")["DesiredCount"] == 1
    assert _service(production_compute, "meridian-production-ecs-svc-web")["DesiredCount"] == 2


def test_every_deployment_can_roll_itself_back(staging_compute: assertions.Template):
    """The difference between a bad deploy and an outage nobody noticed."""
    for body in _resources(staging_compute, "AWS::ECS::Service").values():
        breaker = body["Properties"]["DeploymentConfiguration"]["DeploymentCircuitBreaker"]
        assert breaker == {"Enable": True, "Rollback": True}


def test_tasks_are_private_and_behind_the_app_security_group(
    staging_compute: assertions.Template,
):
    for body in _resources(staging_compute, "AWS::ECS::Service").values():
        configuration = body["Properties"]["NetworkConfiguration"]["AwsvpcConfiguration"]
        assert configuration["AssignPublicIp"] == "DISABLED"
        assert len(configuration["SecurityGroups"]) == 1


def test_both_services_register_with_a_target_group(staging_compute: assertions.Template):
    """The `edge` stack's two groups are empty until this happens."""
    for body in _resources(staging_compute, "AWS::ECS::Service").values():
        (target,) = body["Properties"]["LoadBalancers"]
        assert target["ContainerPort"] in (8000, 3000)
        assert "TargetGroupArn" in target


def test_ecs_exec_is_on_for_the_api_task_only(staging_compute: assertions.Template):
    """The web container has nothing to investigate that its logs do not show."""
    api = _service(staging_compute, "meridian-staging-ecs-svc-api")
    web = _service(staging_compute, "meridian-staging-ecs-svc-web")
    assert api["EnableExecuteCommand"] is True
    assert web.get("EnableExecuteCommand") is not True


# ---------------------------------------------------------------------------
# IAM — the part that has to be read statement by statement
# ---------------------------------------------------------------------------
#: Every `Resource: "*"` this stack is allowed to contain, keyed on the exact
#: set of actions, with the reason. A wildcard statement whose actions are not
#: one of these fails `test_the_roles_have_no_undocumented_wildcard`.
#:
#: **Keyed on actions and not on a Sid on purpose.** CDK writes all three of
#: these itself — from `ContainerImage.from_ecr_repository` and from
#: `enable_execute_command=True` — and what it writes has no Sid. A test that
#: matched on Sids would pass by ignoring exactly the statements it exists for.
#:
#: None of the three has an ARN to name:
#:
#: * `ecr:GetAuthorizationToken` mints a registry-wide token, and IAM defines it
#:   as account-level. Every other ECR action in this stack names the two
#:   repositories.
#: * the four `ssmmessages:*` actions are ECS Exec's session channels, and AWS's
#:   documented policy for `enableExecuteCommand` uses `"*"`. Every session they
#:   permit is written to the cluster's exec log group and appears in CloudTrail
#:   against a named identity.
#: * `logs:DescribeLogGroups` is a list operation across the account; ECS Exec's
#:   log configuration calls it to find the group it was told to write to.
ALLOWED_WILDCARD_ACTIONS: dict[tuple[str, ...], str] = {
    ("ecr:GetAuthorizationToken",): "account-level by IAM's own definition",
    (
        "ssmmessages:CreateControlChannel",
        "ssmmessages:CreateDataChannel",
        "ssmmessages:OpenControlChannel",
        "ssmmessages:OpenDataChannel",
    ): "ECS Exec session channels have no ARN",
    ("logs:DescribeLogGroups",): "a list operation, called by ECS Exec logging",
}


def _actions(statement: Mapping[str, Any]) -> list[str]:
    """An IAM statement's actions, whether it wrote one or several."""
    raw = statement.get("Action")
    return [raw] if isinstance(raw, str) else list(raw or [])


def _statements(template: assertions.Template) -> list[Mapping[str, Any]]:
    statements: list[Mapping[str, Any]] = []
    for body in _resources(template, "AWS::IAM::Policy").values():
        statements.extend(body["Properties"]["PolicyDocument"]["Statement"])
    return statements


def test_the_roles_have_no_undocumented_wildcard(staging_compute: assertions.Template):
    offenders = []
    for statement in _statements(staging_compute):
        if statement.get("Resource") not in ("*", ["*"]):
            continue
        actions = statement.get("Action")
        actions = (actions,) if isinstance(actions, str) else tuple(actions or ())
        if actions not in ALLOWED_WILDCARD_ACTIONS:
            offenders.append(actions)
    assert not offenders, (
        'a new `Resource: "*"` statement appeared. If AWS genuinely defines the '
        "action that way, add it to ALLOWED_WILDCARD_ACTIONS above with the "
        f"reason; otherwise scope it: {offenders}"
    )


def test_no_statement_allows_a_wildcard_action(staging_compute: assertions.Template):
    for statement in _statements(staging_compute):
        actions = statement.get("Action")
        actions = [actions] if isinstance(actions, str) else (actions or [])
        assert "*" not in actions, statement.get("Sid")


def test_three_roles_and_no_more(staging_compute: assertions.Template):
    names = sorted(
        body["Properties"]["RoleName"]
        for body in _resources(staging_compute, "AWS::IAM::Role").values()
    )
    assert names == [
        "meridian-staging-iam-ecs-api-task",
        "meridian-staging-iam-ecs-execution",
        "meridian-staging-iam-ecs-web-task",
    ]


def test_secret_access_names_one_arn_at_a_time(staging_compute: assertions.Template):
    """`GetSecretValue` is never `Resource: "*"` and never a prefix."""
    reads = [
        statement
        for statement in _statements(staging_compute)
        if "secretsmanager:GetSecretValue" in (statement.get("Action") or [])
    ]
    assert reads, "nothing can read the database credential"
    for statement in reads:
        resources = statement["Resource"]
        resources = [resources] if isinstance(resources, (str, dict)) else resources
        assert len(resources) == 1
        assert resources[0] != "*"


def test_the_web_task_role_holds_nothing(staging_compute: assertions.Template):
    """It exists to be empty, so that an added statement is visible in a diff."""
    web_role = [
        name
        for name, body in _resources(staging_compute, "AWS::IAM::Role").items()
        if body["Properties"]["RoleName"] == "meridian-staging-iam-ecs-web-task"
    ]
    assert len(web_role) == 1
    attached = [
        body
        for body in _resources(staging_compute, "AWS::IAM::Policy").values()
        if any(
            isinstance(ref, dict) and ref.get("Ref") == web_role[0]
            for ref in body["Properties"].get("Roles", [])
        )
    ]
    assert attached == []


# ---------------------------------------------------------------------------
# where the web task proxies to (P5A-02)
# ---------------------------------------------------------------------------
def _web_environment(template: assertions.Template, env_name: str) -> Mapping[str, str]:
    web = _one(template, "AWS::ECS::TaskDefinition", Family=f"meridian-{env_name}-ecs-web")
    container = web["ContainerDefinitions"][0]
    return {e["Name"]: e["Value"] for e in container["Environment"]}


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_both_tasks_are_told_the_web_addresses(
    staging_compute: assertions.Template,
    production_compute: assertions.Template,
    env_name: str,
):
    """ADR 0050. The api builds every e-mail link and the Cognito callback from
    `PUBLIC_APP_URL`; the web task splits www from app only when it is given both
    origins, which only production has — staging serves marketing on its app host."""
    template = staging_compute if env_name == "staging" else production_compute
    app = (
        "https://app.meridiansgrp.com"
        if env_name == "production"
        else "https://staging-app.meridiansgrp.com"
    )
    api = _one(template, "AWS::ECS::TaskDefinition", Family=f"meridian-{env_name}-ecs-api")
    api_env = {e["Name"]: e["Value"] for e in api["ContainerDefinitions"][0]["Environment"]}
    assert api_env["PUBLIC_APP_URL"] == app

    web_env = _web_environment(template, env_name)
    assert web_env["PUBLIC_APP_URL"] == app
    if env_name == "production":
        assert web_env["PUBLIC_WWW_URL"] == "https://www.meridiansgrp.com"
    else:
        assert "PUBLIC_WWW_URL" not in web_env


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_the_web_task_names_its_environment_for_its_json_log_lines(
    staging_compute: assertions.Template,
    production_compute: assertions.Template,
    env_name: str,
):
    """`APP_ENV` is the `env` field of every web log line (`web/src/instrumentation.ts`).

    Unset, the Next.js logger wrote `env: "development"`, and the web 5xx filter in
    `observability` — `Environment=$.env`, read with THIS environment's name — could never
    count a line on ECS. Same value the api task carries.
    """
    template = staging_compute if env_name == "staging" else production_compute

    assert _web_environment(template, env_name)["APP_ENV"] == env_name
    api = _one(template, "AWS::ECS::TaskDefinition", Family=f"meridian-{env_name}-ecs-api")
    api_env = {e["Name"]: e["Value"] for e in api["ContainerDefinitions"][0]["Environment"]}
    assert api_env["APP_ENV"] == env_name


@pytest.mark.parametrize(
    ("env_name", "expected"),
    [
        ("staging", "https://staging-app.meridiansgrp.com"),
        ("production", "https://app.meridiansgrp.com"),
    ],
)
def test_the_web_task_is_told_the_public_hostname(
    staging_compute: assertions.Template,
    production_compute: assertions.Template,
    env_name: str,
    expected: str,
):
    """The environment's public name — and on ECS nothing reads it (P5AR5-01).

    The ALB forwards `/api/*`, `/auth/*` and `/static/*` to the `api` target
    group before the `/*` rule that reaches this container, so the Next.js route
    handlers that would consume this variable never run here
    (`test_the_alb_claims_every_proxy_handler_prefix` in `test_edge.py`). It is
    set to the honest answer anyway, because an unset value falls back to
    `http://localhost:5050` — a port nothing in this container listens on.

    It was `origin-<env>`, the ALB dialled directly, for one critic round; that
    hop is what the listener rules make unreachable, and it is gone along with
    the container's origin-verify secret and the NAT `/32` ingress rule.
    """
    template = staging_compute if env_name == "staging" else production_compute

    assert _web_environment(template, env_name)["MERIDIAN_API_ORIGIN"] == expected


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_the_web_origin_is_a_literal_and_never_the_alb_token(
    staging_compute: assertions.Template,
    production_compute: assertions.Template,
    env_name: str,
):
    """The regression, stated as a shape rather than a string.

    `f"https://{alb.load_balancer_dns_name}"` synthesizes as an `Fn::Join` over
    an `Fn::GetAtt` on the load balancer's `DNSName` — a name no certificate
    here covers. A plain string is the only thing that is not that, and it is
    what a hostname from `edge.public_origin` produces.
    """
    template = staging_compute if env_name == "staging" else production_compute
    value = _web_environment(template, env_name)["MERIDIAN_API_ORIGIN"]

    assert isinstance(value, str), value
    assert "DNSName" not in json.dumps(value)
    assert ".elb.amazonaws.com" not in value
    assert value.startswith("https://")
    assert value.endswith(".meridiansgrp.com")


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_the_web_container_holds_no_secret_at_all(
    staging_compute: assertions.Template,
    production_compute: assertions.Template,
    env_name: str,
):
    """The third origin-verify consumer is gone (P5AR5-01).

    `MERIDIAN_ORIGIN_VERIFY` was a `secrets:` entry here so the proxy hop could
    satisfy the ALB's listener rules — rules that send those paths to the `api`
    target group before this container is reached, so the hop never happened.
    No `secrets:` at all now, in either spelling, which is also what takes the
    compute stack back out of the rotation runbook.
    """
    template = staging_compute if env_name == "staging" else production_compute
    web = _one(template, "AWS::ECS::TaskDefinition", Family=f"meridian-{env_name}-ecs-web")
    container = web["ContainerDefinitions"][0]

    assert container.get("Secrets", []) == []
    assert "MERIDIAN_ORIGIN_VERIFY" not in _web_environment(template, env_name)
    assert "OriginVerify" not in json.dumps(web)


def test_nothing_in_the_compute_stack_reads_the_origin_verify_secret(
    staging_compute: assertions.Template,
):
    """One secret read on the execution role, and it is the database credential.

    The origin-verify grant lived here because the `web` task definition named
    the secret. Nothing does now, so the statement is gone — and its absence is
    asserted rather than assumed, because a re-added `secrets:` entry would
    bring back both the grant and the rotation step that goes with it.
    """
    sids = {
        statement.get("Sid")
        for statement in _statements(staging_compute)
        if "secretsmanager:GetSecretValue" in (statement.get("Action") or [])
    }
    assert "ReadDbAppSecret" in sids
    assert "ReadOriginVerify" not in sids
    assert "OriginVerifySecret" not in json.dumps(staging_compute.to_json())


# ---------------------------------------------------------------------------
# who uvicorn believes about X-Forwarded-For (P5A-03)
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("env_name", "cidr"),
    [("staging", "10.20.0.0/16"), ("production", "10.30.0.0/16")],
)
def test_the_api_task_trusts_only_the_vpc_for_forwarded_headers(
    staging_compute: assertions.Template,
    production_compute: assertions.Template,
    env_name: str,
    cidr: str,
):
    """uvicorn ignores `X-Forwarded-For` unless told which peers to believe.

    Untold, `request.client.host` is the ALB for every caller and
    `api.deps.rate_limit_key` puts the whole firm in one bucket on the
    credential endpoints. Told `*`, anything that can open a socket to the task
    picks its own bucket. The VPC's own CIDR is the only range the ALB can reach
    this container from, and it is this environment's — the two must not be the
    same value, or a copied line would go unnoticed.
    """
    template = staging_compute if env_name == "staging" else production_compute
    api = _one(template, "AWS::ECS::TaskDefinition", Family=f"meridian-{env_name}-ecs-api")
    environment = {e["Name"]: e["Value"] for e in api["ContainerDefinitions"][0]["Environment"]}

    assert environment["FORWARDED_ALLOW_IPS"] == cidr
    assert environment["FORWARDED_ALLOW_IPS"] != "*"


# ---------------------------------------------------------------------------
# the PHI bucket grant (P5A-14)
# ---------------------------------------------------------------------------
def test_the_task_role_cannot_delete_from_the_phi_bucket(staging_compute: assertions.Template):
    """`grant_read` + `grant_put`, not `grant_read_write`.

    CDK's `grantReadWrite` includes `s3:DeleteObject*`, and nothing in
    `src/storage.py` deletes a PHI object — raw uploads and identifier-bearing
    exports are aged out by the bucket's own lifecycle rules, which is a
    property of the bucket, not a call the application makes. Versioning would
    make a delete recoverable; a delete the task can issue is still one an
    attacker holding the task role can issue, in the one bucket whose contents
    are the patients.
    """
    # The bucket ARN arrives as a cross-stack `Fn::ImportValue` whose export
    # name carries the construct id — `BucketPhi...` — so that is what names the
    # bucket in a synthesized policy. There is no literal bucket name to match.
    phi_deletes = [
        statement
        for statement in _statements(staging_compute)
        if any(str(action).startswith("s3:DeleteObject") for action in _actions(statement))
        and "BucketPhi" in json.dumps(statement.get("Resource"))
    ]
    assert phi_deletes == [], (
        f"the api task role may delete objects in the PHI bucket: {phi_deletes}"
    )

    # ...and the check is not vacuous: the artifacts bucket DOES carry a delete
    # grant, so a test that found no delete statements at all would be testing
    # its own matcher rather than the policy.
    artifact_deletes = [
        statement
        for statement in _statements(staging_compute)
        if any(str(action).startswith("s3:DeleteObject") for action in _actions(statement))
    ]
    assert artifact_deletes, "no s3:DeleteObject* statement anywhere — matcher is wrong"


def test_the_task_role_can_still_read_and_write_phi_objects(staging_compute: assertions.Template):
    """The other half — removing delete must not have removed the grant."""
    actions: set[str] = set()
    for statement in _statements(staging_compute):
        if "BucketPhi" not in json.dumps(statement.get("Resource")):
            continue
        actions.update(_actions(statement))

    assert "s3:GetObject*" in actions
    assert "s3:PutObject" in actions


def _ses_statements(template: assertions.Template) -> list[Mapping[str, Any]]:
    return [
        statement
        for statement in _statements(template)
        if any(str(action).startswith("ses:") for action in _actions(statement))
    ]


def test_the_task_role_may_send_email_only_as_the_one_verified_mailbox(
    staging_compute: assertions.Template,
):
    """One statement, two resources, one `From` (Phase 7, ADR 0025).

    Without the `ses:FromAddress` condition the api task could send as any
    address on `meridiansgrp.com` — `billing@`, a person's own mailbox — and a
    phishing mail from the real domain with a real DKIM signature is the most
    convincing mail anybody in the company will ever receive.
    """
    statements = _ses_statements(staging_compute)
    assert len(statements) == 1, f"expected exactly one SES statement, got {statements}"
    statement = statements[0]
    assert sorted(_actions(statement)) == ["ses:SendEmail", "ses:SendRawEmail"]
    assert statement["Condition"]["StringEquals"]["ses:FromAddress"] == "no-reply@meridiansgrp.com"

    resources = json.dumps(statement["Resource"])
    assert "identity/meridiansgrp.com" in resources
    assert "configuration-set/meridian-shared-ses-default" in resources
    assert "*" not in statement["Resource"], "SES must never be granted on a wildcard resource"


def test_the_api_task_is_told_which_backend_mailbox_and_configuration_set(
    staging_compute: assertions.Template,
):
    """The switch and its two plain-configuration values; no credential."""
    api = _one(staging_compute, "AWS::ECS::TaskDefinition", Family="meridian-staging-ecs-api")
    container = api["ContainerDefinitions"][0]
    environment = {entry["Name"]: entry["Value"] for entry in container["Environment"]}
    assert environment["EMAIL_BACKEND"] == "ses"
    assert environment["MERIDIAN_SES_FROM_EMAIL"] == "no-reply@meridiansgrp.com"
    assert environment["MERIDIAN_SES_CONFIGURATION_SET"] == "meridian-shared-ses-default"


def test_the_web_task_may_not_send_email(staging_compute: assertions.Template):
    """It serves pages. Nothing in it has a reason to reach SES."""
    web_role_statements = json.dumps(
        [
            body
            for logical_id, body in _resources(staging_compute, "AWS::IAM::Policy").items()
            if "WebTaskRole" in logical_id
        ]
    )
    assert "ses:" not in web_role_statements


def test_production_is_the_same_shape(production_compute: assertions.Template):
    """One environment's template must not be the only one that was looked at."""
    assert len(_resources(production_compute, "AWS::ECS::Service")) == 2
    api = _one(production_compute, "AWS::ECS::TaskDefinition", Family="meridian-production-ecs-api")
    assert api["RuntimePlatform"]["CpuArchitecture"] == "ARM64"
    assert api["EphemeralStorage"] == {"SizeInGiB": 40}


# ---------------------------------------------------------------------------
# Image tags. `.github/workflows/deploy.yml` passes both keys as the commit sha;
# the fallback chain is per-image key -> `imageTag` -> `DEFAULT_IMAGE_TAG`, and a
# task definition that silently fell back would be indistinguishable in the
# console from one deployed on purpose.
# ---------------------------------------------------------------------------
def _container_images(template: assertions.Template) -> dict[str, str]:
    images: dict[str, str] = {}
    for body in _resources(template, "AWS::ECS::TaskDefinition").values():
        for container in body["Properties"]["ContainerDefinitions"]:
            images[container["Name"]] = json.dumps(container["Image"])
    return images


def test_with_no_context_both_images_are_the_bootstrap_placeholder(
    staging_compute: assertions.Template,
):
    """`bootstrap` is a tag no build ever pushes — deliberately not `latest`.

    Under `IMMUTABLE` tag mutability `latest` could be pushed exactly once and
    would be a lie from the second deploy on.
    """
    images = _container_images(staging_compute)
    assert set(images) == {"api", "web"}
    for image in images.values():
        assert f":{DEFAULT_IMAGE_TAG}" in image


def test_the_two_image_tag_keys_are_independent():
    """A rollback is frequently one image, not both."""
    template = stack_template("staging", "compute", apiImageTag="aaa111", webImageTag="bbb222")
    images = _container_images(template)
    assert ":aaa111" in images["api"]
    assert ":bbb222" in images["web"]


def test_the_older_single_key_still_sets_both():
    """`-c imageTag=<sha>` predates the split and must keep working."""
    template = stack_template("staging", "compute", imageTag="ccc333")
    images = _container_images(template)
    assert ":ccc333" in images["api"]
    assert ":ccc333" in images["web"]


def test_a_per_image_key_beats_the_shared_one():
    template = stack_template("staging", "compute", imageTag="ccc333", webImageTag="ddd444")
    images = _container_images(template)
    assert ":ccc333" in images["api"]
    assert ":ddd444" in images["web"]


def test_the_tag_goes_into_the_repository_uri_not_a_separate_property():
    """ECS names an image as `<repo>:<tag>`; the tag has nowhere else to go.

    Asserted because a refactor that dropped the tag would still synthesize, and
    the services would then pull whatever `latest` happened to be.
    """
    template = stack_template("staging", "compute", apiImageTag="eee555")
    rendered = _container_images(template)["api"]
    # The repository is imported by name from `data`; the registry hostname is
    # composed from AWS::AccountId so that no account id is written down (ADR 0001).
    # What matters here is that the tag is the last segment of the composed URI.
    assert '"AWS::AccountId"' in rendered
    assert "/meridian-staging-ecr-api:eee555" in rendered


# --------------------------------------------------------------- SES region
def test_the_ses_arns_refuse_a_region_the_dns_stack_does_not_use():
    """P7-11. Two spellings of one region is a grant that denies every send.

    `EDGE_REGION` was written into both SES ARNs as a constant while the stack
    that creates the identity and the configuration set took its region from
    somewhere else. The failure mode is not a synth error - it is a deploy that
    reports success and an `AccessDenied` on every invite afterwards.
    """
    from meridian.stacks.base import EDGE_REGION
    from meridian.stacks.compute import ses_region

    assert ses_region(EDGE_REGION) == EDGE_REGION
    with pytest.raises(ValueError, match="dns stack"):
        ses_region("us-west-2")


def test_an_unresolved_region_falls_back_to_the_constant():
    """Offline synth leaves `Stack.region` a token, and a token is not a region.

    Same reasoning as `assert_edge_region`: the check can only compare a
    concrete value, so CI and the tests get the constant and a byte-identical
    template.
    """
    from aws_cdk import Aws

    from meridian.stacks.base import EDGE_REGION
    from meridian.stacks.compute import ses_region

    assert ses_region(Aws.REGION) == EDGE_REGION


def test_the_ses_arns_name_the_edge_region(staging_compute: assertions.Template):
    statement = _ses_statements(staging_compute)[0]
    resources = json.dumps(statement["Resource"])
    assert "us-east-1" in resources


# ---------------------------------------------------------------------------
# Dual acceptance (ADR 0021) — Phase 10 step 1's off switch
# ---------------------------------------------------------------------------
def test_dual_acceptance_is_on_by_default_in_the_task_definition(
    staging_compute: assertions.Template,
):
    """`AUTH_ACCEPT_SUPABASE_TOKENS` is a task-definition variable, not folklore.

    It was named in `docs/runbooks/decommission-supabase-render.md` step 1 before
    it existed anywhere in the infrastructure, so "set it false and deploy" had no
    file to edit. `true` is the pre-cut-off value: a Supabase-issued token is still
    accepted, which is what keeps Flip 1 reversible.
    """
    api = _one(staging_compute, "AWS::ECS::TaskDefinition", Family="meridian-staging-ecs-api")
    (container,) = api["ContainerDefinitions"]
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    assert environment["AUTH_ACCEPT_SUPABASE_TOKENS"] == "true"


def test_accept_supabase_tokens_false_closes_dual_acceptance():
    """Phase 10 step 1: `-c acceptSupabaseTokens=false`, deployed like any change."""
    template = stack_template("production", "compute", acceptSupabaseTokens="false")
    api = _one(template, "AWS::ECS::TaskDefinition", Family="meridian-production-ecs-api")
    (container,) = api["ContainerDefinitions"]
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    assert environment["AUTH_ACCEPT_SUPABASE_TOKENS"] == "false"


# ---------------------------------------------------------------------------
# Cognito configuration in the task definition (tracker T:102)
# ---------------------------------------------------------------------------
def _api_container(template: assertions.Template, env_name: str) -> Mapping[str, Any]:
    api = _one(template, "AWS::ECS::TaskDefinition", Family=f"meridian-{env_name}-ecs-api")
    (container,) = api["ContainerDefinitions"]
    return container


def _cognito_required_env() -> set[str]:
    """`src/settings.COGNITO_REQUIRED_ENV`, read as text.

    Not imported: the infra job in CI installs the CDK requirements only, not the
    application's, and `src/settings.py` is the application's.
    """
    text = (pathlib.Path(__file__).resolve().parents[2] / "src" / "settings.py").read_text()
    block = re.search(r"COGNITO_REQUIRED_ENV = \((.*?)\)", text, re.S)
    assert block, "COGNITO_REQUIRED_ENV moved; update this reader"
    return set(re.findall(r'"([A-Z_]+)"', block.group(1)))


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_the_api_task_carries_every_required_cognito_variable(env_name: str):
    """`AUTH_BACKEND=cognito` refuses to start without all four (`src/settings.py`).

    Before T:102 a staging task only started with `AUTH_BACKEND=disabled` overridden
    by hand. The ids come off the `auth` stack's constructs (an import, never a
    literal), the region is this stack's own, and the secret is a `secrets:` entry.
    """
    container = _api_container(stack_template(env_name, "compute"), env_name)
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    secrets = {s["Name"]: s["ValueFrom"] for s in container["Secrets"]}
    required = _cognito_required_env()
    assert len(required) == 4
    assert required <= set(environment) | set(secrets)
    assert "COGNITO_CLIENT_SECRET" in secrets

    auth_export = f"meridian-{env_name}-auth:"
    assert auth_export in json.dumps(environment["COGNITO_USER_POOL_ID"])
    assert auth_export in json.dumps(environment["COGNITO_CLIENT_ID"])
    assert environment["COGNITO_REGION"] == {"Ref": "AWS::Region"}
    assert auth_export in json.dumps(secrets["COGNITO_CLIENT_SECRET"])
    domain = json.dumps(environment["COGNITO_DOMAIN"])
    assert "https://" in domain and ".amazoncognito.com" in domain


def test_the_execution_role_reads_the_client_secret_through_secrets_manager_only(
    staging_compute: assertions.Template,
):
    """One ARN for `GetSecretValue`; `kms:Decrypt` on the `logs` key via Secrets Manager."""
    reads = [
        s for s in _statements(staging_compute) if s.get("Sid") == "ReadCognitoWebClientSecret"
    ]
    assert len(reads) == 1
    assert "meridian-staging-auth:" in json.dumps(reads[0]["Resource"])
    (decrypt,) = [
        s
        for s in _statements(staging_compute)
        if s.get("Sid") == "DecryptCognitoWebClientSecretThroughSecretsManager"
    ]
    assert _actions(decrypt) == ["kms:Decrypt"]
    assert "KeyLogs" in json.dumps(decrypt["Resource"])
    assert "secretsmanager." in json.dumps(decrypt["Condition"])
    # The task role (the application's own identity) cannot read it again.
    task_policies = json.dumps(
        [
            body
            for logical_id, body in _resources(staging_compute, "AWS::IAM::Policy").items()
            if "ApiTaskRole" in logical_id
        ]
    )
    assert "WebClientSecret" not in task_policies


# ---------------------------------------------------------------------------
# The PHI HMAC key (tracker T:95): fetched by the app, by ARN, never injected
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_the_api_task_is_told_where_the_phi_hmac_key_is_and_not_what_it_is(env_name: str):
    """`src/phi.hmac_key()` fetches the secret named by `MERIDIAN_PHI_HMAC_KEY_SECRET_ARN`.

    Without it the first transaction insert on ECS raises `PhiError`. The value itself is
    never a `secrets:` entry: injected, it would sit in `/proc/<pid>/environ` for the life
    of the task (`compute._api_task_role`).
    """
    container = _api_container(stack_template(env_name, "compute"), env_name)
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    secrets = {s["Name"] for s in container["Secrets"]}
    pointer = json.dumps(environment["MERIDIAN_PHI_HMAC_KEY_SECRET_ARN"])
    assert f"meridian-{env_name}-data:" in pointer and "PhiHmacKey" in pointer
    assert "MERIDIAN_PHI_HMAC_KEY" not in environment
    assert "MERIDIAN_PHI_HMAC_KEY" not in secrets


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_only_the_api_task_role_reads_the_phi_hmac_key_and_only_that_arn(env_name: str):
    """The grant `phi.hmac_key()` uses: one ARN — the one in the environment — and
    `kms:Decrypt` on the `phi` key through Secrets Manager. The execution role has none:
    nothing injects this secret."""
    template = stack_template(env_name, "compute")
    container = _api_container(template, env_name)
    pointer = {e["Name"]: e["Value"] for e in container["Environment"]}[
        "MERIDIAN_PHI_HMAC_KEY_SECRET_ARN"
    ]
    policies = _resources(template, "AWS::IAM::Policy")
    holders = {
        logical_id
        for logical_id, body in policies.items()
        if "PhiHmacKey" in json.dumps(body["Properties"]["PolicyDocument"])
    }
    assert len(holders) == 1 and "ApiTaskRole" in next(iter(holders))
    statements = policies[next(iter(holders))]["Properties"]["PolicyDocument"]["Statement"]
    (read,) = [s for s in statements if s.get("Sid") == "ReadPhiHmacKey"]
    assert read["Resource"] == pointer
    assert set(_actions(read)) == {"secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"}
    (decrypt,) = [s for s in statements if s.get("Sid") == "DecryptPhiHmacKeyThroughSecretsManager"]
    assert _actions(decrypt) == ["kms:Decrypt"]
    assert "KeyPhi" in json.dumps(decrypt["Resource"])
    assert "secretsmanager." in json.dumps(decrypt["Condition"])


def test_the_web_client_secret_is_a_getatt_copy_and_never_a_value():
    """`meridian-<env>/cognito-web-client` holds `Fn::GetAtt ClientSecret`, on the logs CMK.

    CloudFormation's own attribute, not CDK's `user_pool_client_secret` custom
    resource (an extra Lambda with an unnamed role and an implicit log group).
    """
    auth = stack_template("staging", "auth")
    (secret,) = [
        body["Properties"]
        for body in _resources(auth, "AWS::SecretsManager::Secret").values()
        if body["Properties"]["Name"] == "meridian-staging/cognito-web-client"
    ]
    getatt = secret["SecretString"]["Fn::GetAtt"]
    assert getatt[0].startswith("WebClient") and getatt[1] == "ClientSecret"
    assert "KeyLogs" in json.dumps(secret["KmsKeyId"])
    assert not _resources(auth, "Custom::DescribeCognitoUserPoolClient")


# ---------------------------------------------------------------------------
# The SES -> Resend rollback flag (tracker T:143, email-cutover.md §2)
# ---------------------------------------------------------------------------
def test_ses_is_the_default_and_no_resend_key_is_mapped(staging_compute: assertions.Template):
    container = _api_container(staging_compute, "staging")
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    assert environment["EMAIL_BACKEND"] == "ses"
    assert "RESEND_FROM_EMAIL" not in environment
    assert "RESEND_API_KEY" not in {s["Name"] for s in container["Secrets"]}
    assert "resend-api-key" not in json.dumps(staging_compute.to_json())


def test_email_backend_resend_is_the_rollback_in_one_deploy():
    """`-c emailBackend=resend`: the switch, the From, and the key from a NAMED secret."""
    template = stack_template("production", "compute", emailBackend="resend")
    container = _api_container(template, "production")
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    secrets = {s["Name"]: json.dumps(s["ValueFrom"]) for s in container["Secrets"]}
    assert environment["EMAIL_BACKEND"] == "resend"
    assert environment["RESEND_FROM_EMAIL"] == "no-reply@meridiansgrp.com"
    assert "secret:meridian-production/resend-api-key" in secrets["RESEND_API_KEY"]
    assert "RESEND_API_KEY" not in environment

    (read,) = [s for s in _statements(template) if s.get("Sid") == "ReadResendApiKey"]
    # Referenced by name, so the ARN has no suffix and IAM needs the `-??????` form.
    assert "secret:meridian-production/resend-api-key-??????" in json.dumps(read["Resource"])
    (decrypt,) = [
        s
        for s in _statements(template)
        if s.get("Sid") == "DecryptResendApiKeyThroughSecretsManager"
    ]
    assert "KeyLogs" in json.dumps(decrypt["Resource"])
    # SES stays granted: flipping back is the same flag, not an IAM change.
    assert len(_ses_statements(template)) == 1


def test_an_unknown_email_backend_is_refused_at_synth():
    with pytest.raises(ValueError, match="emailBackend"):
        stack_template("staging", "compute", emailBackend="disabled")


# ---------------------------------------------------------------------------
# `-c qboOAuth=true`: the QuickBooks OAuth client on the api WITHOUT the worker
# (ADR 0044 amendment, T:186). Render production connects QuickBooks today, so
# production `compute` passes it once `meridian-production/qbo-oauth` exists.
# ---------------------------------------------------------------------------
def _role_policy(template: assertions.Template, role_prefix: str) -> str:
    return json.dumps(
        [
            body
            for name, body in _resources(template, "AWS::IAM::Policy").items()
            if name.startswith(role_prefix)
        ]
    )


def test_qbo_environment_override_lets_staging_use_intuit_production():
    template = stack_template(
        "staging", "compute", **{QBO_OAUTH_CONTEXT_FLAG: "true", QBO_ENVIRONMENT_CONTEXT_KEY: "production"}
    )
    environment = {e["Name"]: e["Value"] for e in _api_container(template, "staging")["Environment"]}
    assert environment["QBO_ENVIRONMENT"] == "production"
    assert environment["MERIDIAN_QBO_POSTING"] == "off"  # reads real companies, never posts
    with pytest.raises(ValueError, match="production or sandbox"):
        stack_template("staging", "compute", **{QBO_OAUTH_CONTEXT_FLAG: "true", QBO_ENVIRONMENT_CONTEXT_KEY: "prod"})


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_qbo_oauth_maps_the_named_secret_into_the_api_without_the_worker(env_name: str):
    template = stack_template(env_name, "compute", **{QBO_OAUTH_CONTEXT_FLAG: "true"})
    container = _api_container(template, env_name)
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    secrets = {s["Name"]: json.dumps(s["ValueFrom"]) for s in container["Secrets"]}
    for name, field in (("QBO_CLIENT_ID", "client_id"), ("QBO_CLIENT_SECRET", "client_secret")):
        assert f"secret:meridian-{env_name}/{QBO_OAUTH_SECRET_NAME}" in secrets[name]
        assert f":{field}::" in secrets[name]
        assert name not in environment  # a secret, never a plain variable
    assert environment["QBO_ENVIRONMENT"] == (
        "production" if env_name == "production" else "sandbox"
    )
    assert json.dumps(environment["QBO_REDIRECT_URI"]).startswith('"https://')
    assert QBO_CALLBACK_PATH in json.dumps(environment["QBO_REDIRECT_URI"])

    # The execution role reads that ONE secret (by name: the `-??????` form) and its key
    # through Secrets Manager; the task role never reads it.
    (read,) = [s for s in _statements(template) if s.get("Sid") == "ReadQboOauthSecret"]
    (resource,) = read["Resource"] if isinstance(read["Resource"], list) else [read["Resource"]]
    assert f"secret:meridian-{env_name}/{QBO_OAUTH_SECRET_NAME}-??????" in json.dumps(resource)
    (decrypt,) = [
        s
        for s in _statements(template)
        if s.get("Sid") == "DecryptQboOauthSecretThroughSecretsManager"
    ]
    assert "KeyLogs" in json.dumps(decrypt["Resource"])
    assert "ReadQboOauthSecret" in _role_policy(template, "ExecutionRole")
    assert QBO_OAUTH_SECRET_NAME not in _role_policy(template, "ApiTaskRole")

    # No worker comes with it.
    rendered = json.dumps(template.to_json())
    for marker in ("svc-worker", "sqs-jobs", "ecs-worker", "WorkerTaskRole"):
        assert marker not in rendered, marker


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_qbo_oauth_is_off_by_default_and_false_is_the_same(env_name: str):
    """Off, no deploy names the hand-created secret, so none fails before it exists."""
    default = stack_template(env_name, "compute").to_json()
    assert QBO_OAUTH_SECRET_NAME not in json.dumps(default)
    assert "QBO_CLIENT_ID" not in json.dumps(default)
    false = stack_template(env_name, "compute", **{QBO_OAUTH_CONTEXT_FLAG: "false"}).to_json()
    assert json.dumps(default) == json.dumps(false)


# ---------------------------------------------------------------------------
# `-c ecwDb=true`: the P&L run's eCW data mart login on the api, from the
# hand-created `meridian-<env>/ecw-db` secret.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_ecw_db_maps_the_named_secret_into_the_api(env_name: str):
    template = stack_template(env_name, "compute", **{ECW_DB_CONTEXT_FLAG: "true"})
    container = _api_container(template, env_name)
    environment = {e["Name"]: e["Value"] for e in container["Environment"]}
    secrets = {s["Name"]: json.dumps(s["ValueFrom"]) for s in container["Secrets"]}
    for name, field in (
        ("ECW_DB_HOST", "host"),
        ("ECW_DB_NAME", "dbname"),
        ("ECW_DB_USER", "user"),
        ("ECW_DB_PASSWORD", "password"),
    ):
        assert f"secret:meridian-{env_name}/{ECW_DB_SECRET_NAME}" in secrets[name]
        assert f":{field}::" in secrets[name]
        assert name not in environment
    (read,) = [s for s in _statements(template) if s.get("Sid") == "ReadEcwDbSecret"]
    assert f"secret:meridian-{env_name}/{ECW_DB_SECRET_NAME}-??????" in json.dumps(read["Resource"])
    assert "ReadEcwDbSecret" in _role_policy(template, "ExecutionRole")
    assert ECW_DB_SECRET_NAME not in _role_policy(template, "ApiTaskRole")


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_ecw_db_is_off_by_default_and_false_is_the_same(env_name: str):
    default = stack_template(env_name, "compute").to_json()
    assert ECW_DB_SECRET_NAME not in json.dumps(default)
    assert "ECW_DB_HOST" not in json.dumps(default)
    false = stack_template(env_name, "compute", **{ECW_DB_CONTEXT_FLAG: "false"}).to_json()
    assert json.dumps(default) == json.dumps(false)


def test_qbo_oauth_changes_only_the_api_task_and_the_execution_role():
    off = synth_with("staging", **NETWORK_CONTEXT)
    on = synth_with("staging", **NETWORK_CONTEXT, **{QBO_OAUTH_CONTEXT_FLAG: "true"})
    for artifact in off.stacks:
        after = on.get_stack_by_name(artifact.stack_name).template
        if not artifact.stack_name.endswith("-compute"):
            assert json.dumps(artifact.template) == json.dumps(after), artifact.stack_name
            continue
        before = artifact.template
        assert set(before["Resources"]) == set(after["Resources"])
        assert before.get("Outputs") == after.get("Outputs")
        changed = {
            n for n in before["Resources"] if before["Resources"][n] != after["Resources"][n]
        }
        assert {n.rstrip("0123456789ABCDEF") for n in changed} == {
            "ApiTaskDefinition",
            "ExecutionRoleDefaultPolicy",
        }, changed


def test_the_worker_flag_implies_qbo_oauth():
    """`worker_enabled` alone already maps the client (its `qbo_push` refresh needs it), so
    adding `qboOAuth` to a worker deploy changes nothing."""
    worker = stack_template("staging", "compute", **{WORKER_CONTEXT_FLAG: "true"}).to_json()
    both = stack_template(
        "staging", "compute", **{WORKER_CONTEXT_FLAG: "true", QBO_OAUTH_CONTEXT_FLAG: "true"}
    ).to_json()
    assert json.dumps(worker) == json.dumps(both)


# ---------------------------------------------------------------------------
# Sign-in permissions on the api task role (orchestrator item, auth port)
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_the_api_task_may_sign_people_in_against_its_own_pool_only(env_name: str):
    """Exactly eight Cognito admin actions, on this environment's pool ARN, always.

    Without them an invite creating the invitee's account (`AdminCreateUser`, `AdminGetUser`),
    password sign-in (`AdminInitiateAuth`), the MFA challenge
    (`AdminRespondToAuthChallenge`), turning TOTP on (`AdminSetUserMFAPreference`),
    the members' addresses (`ListUsers`) and the remembered browser's age check
    (`AdminGetDevice`, `AdminForgetDevice`) answer AccessDenied on ECS. They are
    NOT behind `-c enableApiPlatform` — sign-in is not an API-platform feature.
    """
    template = stack_template(env_name, "compute")
    (statement,) = [s for s in _statements(template) if s.get("Sid") == "SignInAgainstThisPoolOnly"]
    assert sorted(_actions(statement)) == [
        "cognito-idp:AdminCreateUser",
        "cognito-idp:AdminForgetDevice",
        "cognito-idp:AdminGetDevice",
        "cognito-idp:AdminGetUser",
        "cognito-idp:AdminInitiateAuth",
        "cognito-idp:AdminRespondToAuthChallenge",
        "cognito-idp:AdminSetUserMFAPreference",
        "cognito-idp:ListUsers",
    ]
    resource = statement["Resource"]
    assert isinstance(resource, dict), "one pool ARN, never a list and never '*'"
    assert resource == {"Fn::ImportValue": resource["Fn::ImportValue"]}
    assert f"meridian-{env_name}-auth:" in resource["Fn::ImportValue"]
    assert "UserPool" in resource["Fn::ImportValue"]
    # On the api TASK role — the application's identity — and nowhere else.
    task_policies = [
        body
        for logical_id, body in _resources(template, "AWS::IAM::Policy").items()
        if "SignInAgainstThisPoolOnly" in json.dumps(body)
    ]
    assert len(task_policies) == 1
    assert "ApiTaskRole" in json.dumps(task_policies[0]["Properties"]["Roles"])
    # No other statement in the stack mentions cognito-idp.
    others = [
        s
        for s in _statements(template)
        if s.get("Sid") != "SignInAgainstThisPoolOnly" and "cognito-idp" in json.dumps(s)
    ]
    assert others == []


# ---------------------------------------------------------------------------
# Ask Meridian on Bedrock (tracker T:254, owner decision 2026-10-18)
# ---------------------------------------------------------------------------
def _bi_ask_chain() -> set[str]:
    """`FAST + SMART` model ids in `src/bi_ask.py`, read as text (the infra job has no app deps)."""
    text = (pathlib.Path(__file__).resolve().parents[2] / "src" / "bi_ask.py").read_text()
    return set(re.findall(r'"(global\.anthropic\.[^"]+)"', re.search(
        r"^FAST = .*?^MODEL_LABELS", text, re.S | re.M).group(0)))


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_the_api_task_may_invoke_only_the_ask_models_through_their_profiles(env_name: str):
    template = stack_template(env_name, "compute")
    policies = _resources(template, "AWS::IAM::Policy")
    statements = [
        s
        for body in policies.values()
        if "ApiTaskRole" in json.dumps(body["Properties"]["Roles"])
        for s in body["Properties"]["PolicyDocument"]["Statement"]
    ]
    bedrock = [s for s in statements if any(a.startswith("bedrock:") for a in _actions(s))]
    assert {s["Sid"] for s in bedrock} == {
        "AskMeridianInvokeInferenceProfiles",
        "AskMeridianInvokeFoundationModelsViaProfiles",
    }
    chain = _bi_ask_chain()
    assert chain and chain == set(ASK_PROFILE_IDS), "bi_ask.py chain changed; update ASK_PROFILE_IDS"
    for s in bedrock:
        assert _actions(s) == ["bedrock:InvokeModel"]  # no streaming, no list/get
        assert s["Effect"] == "Allow"
        resources = s["Resource"] if isinstance(s["Resource"], list) else [s["Resource"]]
        per_model = 2 if s["Sid"].endswith("ViaProfiles") else 1  # region-less + home region
        assert len(resources) == per_model * len(chain)
        assert all("*" not in json.dumps(r) for r in resources)
    profiles = next(s for s in bedrock if s["Sid"] == "AskMeridianInvokeInferenceProfiles")
    for pid in chain:
        assert any(
            f":bedrock:us-east-1:" in json.dumps(r) or "arn:aws:bedrock:us-east-1:" in json.dumps(r)
            for r in profiles["Resource"]
        )
        assert any(f"inference-profile/{pid}" in json.dumps(r) for r in profiles["Resource"])
    models = next(s for s in bedrock if s["Sid"] == "AskMeridianInvokeFoundationModelsViaProfiles")
    for pid in chain:
        model = pid.removeprefix("global.")
        assert f"arn:aws:bedrock:::foundation-model/{model}" in models["Resource"]
        assert f"arn:aws:bedrock:us-east-1::foundation-model/{model}" in models["Resource"]
    # Usable only through one of our profiles.
    assert "bedrock:InferenceProfileArn" in models["Condition"]["ArnEquals"]
    assert len(models["Condition"]["ArnEquals"]["bedrock:InferenceProfileArn"]) == len(chain)
    # Nobody else gets Bedrock: not the web task, not the execution role.
    for body in policies.values():
        if "ApiTaskRole" in json.dumps(body["Properties"]["Roles"]):
            continue
        assert "bedrock:" not in json.dumps(body["Properties"]["PolicyDocument"])


@pytest.mark.parametrize("env_name", ["staging", "production"])
def test_the_api_task_turns_ask_on_with_a_ten_dollar_cap(env_name: str):
    environment = {
        e["Name"]: e["Value"]
        for e in _api_container(stack_template(env_name, "compute"), env_name)["Environment"]
    }
    assert environment["BEDROCK_REGION"] == "us-east-1"
    assert environment["BI_ASK_MONTHLY_CAP_USD"] == "10"
