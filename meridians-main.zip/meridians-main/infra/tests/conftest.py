"""Shared fixtures for the CDK tests.

These tests synthesize the app in-process with `aws_cdk.assertions`. They need
no AWS credentials and make no AWS calls — the same property that lets `cdk
synth` run in CI (see `infra/app.py`).
"""

from __future__ import annotations

import sys
from pathlib import Path

INFRA_ROOT = Path(__file__).resolve().parents[1]
if str(INFRA_ROOT) not in sys.path:
    sys.path.insert(0, str(INFRA_ROOT))

import app as cdk_app  # noqa: E402
import aws_cdk as cdk  # noqa: E402
import pytest  # noqa: E402
from aws_cdk import assertions, cx_api  # noqa: E402

#: Every stack the app is expected to produce, by environment.
EXPECTED_STACKS = {
    "staging": [
        "meridian-shared-foundation",
        "meridian-shared-dns",
        "meridian-shared-identity",
        "meridian-staging-vpc",
        "meridian-staging-edge",
        "meridian-staging-data",
        "meridian-staging-auth",
        "meridian-staging-compute",
        "meridian-staging-api",
        "meridian-staging-observability",
        # Always present (M-5): pinned to `drRegion`, account still unresolved.
        "meridian-staging-dr",
    ],
    "production": [
        "meridian-shared-foundation",
        "meridian-shared-dns",
        "meridian-shared-identity",
        "meridian-production-vpc",
        "meridian-production-edge",
        "meridian-production-data",
        "meridian-production-auth",
        "meridian-production-compute",
        "meridian-production-api",
        "meridian-production-observability",
        "meridian-production-dr",
    ],
}


#: `meridian-shared-identity` refuses to synthesize without `ssoInstanceArn`,
#: because deploying it without one deletes any permission sets already created.
#: Tests are in exactly the position that waiver is for — no identifiers, and no
#: deploy — so they say so explicitly, the same way CI does.
NO_IDENTITY_CENTER = {"allowNoIdentityCenter": True}


def synth(env: str) -> cx_api.CloudAssembly:
    """Synthesize the whole app for one environment.

    No `env` is passed to `cdk.App` beyond context, and no account id is set
    anywhere, so this exercises exactly the unresolved-environment path CI uses.
    """
    application = cdk.App(context={"env": env, **NO_IDENTITY_CENTER})
    cdk_app.build(application)
    return application.synth()


@pytest.fixture(scope="session")
def staging() -> cx_api.CloudAssembly:
    return synth("staging")


@pytest.fixture(scope="session")
def production() -> cx_api.CloudAssembly:
    return synth("production")


@pytest.fixture(scope="session")
def foundation(staging: cx_api.CloudAssembly) -> assertions.Template:
    return assertions.Template.from_json(
        staging.get_stack_by_name("meridian-shared-foundation").template
    )


@pytest.fixture(scope="session")
def dns(staging: cx_api.CloudAssembly) -> assertions.Template:
    return assertions.Template.from_json(staging.get_stack_by_name("meridian-shared-dns").template)


@pytest.fixture(scope="session")
def identity(staging: cx_api.CloudAssembly) -> assertions.Template:
    """The identity stack **without** the Identity Center context values.

    This is the first-pass shape: before anyone has run `create-instance`, the
    stack still deploys and still installs the MFA guardrail.
    """
    return assertions.Template.from_json(
        staging.get_stack_by_name("meridian-shared-identity").template
    )


#: Placeholder values for the two identifiers the `vpc` and `edge` stacks take from
#: context. Neither is real (ADR 0001 — no identifier is committed): the prefix
#: list id is a syntactically valid but non-existent one, so a deploy with it
#: fails closed rather than opening the load balancer, and the zone id is the
#: shape Route 53 issues. They exist so the tests can exercise the branches that
#: only run once a real value is supplied.
NETWORK_CONTEXT = {
    "cloudfrontPrefixListId": "pl-0aaaaaaaaaaaaaaaa",
    "hostedZoneId": "Z0AAAAAABBBBBBCCCCCC",
}


def synth_with(env: str, **context: object) -> cx_api.CloudAssembly:
    """Synthesize the app for one environment with extra context values."""
    application = cdk.App(context={"env": env, **NO_IDENTITY_CENTER, **context})
    cdk_app.build(application)
    return application.synth()


def stack_template(env: str, component: str, **context: object) -> assertions.Template:
    """Any `meridian-<env>-<component>` template, with the placeholder context applied."""
    assembly = synth_with(env, **{**NETWORK_CONTEXT, **context})
    return assertions.Template.from_json(
        assembly.get_stack_by_name(f"meridian-{env}-{component}").template
    )


def vpc_template(env: str, **context: object) -> assertions.Template:
    """The persistent `meridian-<env>-vpc` template (ADR 0020)."""
    return stack_template(env, "vpc", **context)


def edge_template(env: str, **context: object) -> assertions.Template:
    """The transient `meridian-<env>-edge` template (ADR 0020)."""
    return stack_template(env, "edge", **context)


def edge_stack(env: str, **context: object) -> cdk.Stack:
    """The `Edge` **construct**, not its template.

    `assertions.Annotations` reads the construct tree, so a test about a synth-time
    warning — the H-F "you are still using a staging label" one, for instance — needs
    the stack object rather than the JSON it produces.
    """
    application = cdk.App(context={"env": env, **NO_IDENTITY_CENTER, **NETWORK_CONTEXT, **context})
    cdk_app.build(application)
    # The construct id **is** the stack name (see `infra/app.py`), which is what
    # makes the runbooks' `cdk deploy meridian-<env>-edge` selectors resolve.
    stack = application.node.try_find_child(f"meridian-{env}-edge")
    assert isinstance(stack, cdk.Stack)
    return stack


def data_template(env: str, **context: object) -> assertions.Template:
    """The `meridian-<env>-data` template.

    It is a separate helper rather than a fixture because two tests want it for both
    environments, and because the data stack is where the origin-verify secret lives
    since L-6 — a fact several edge tests have to assert from the outside.
    """
    assembly = synth_with(env, **context)
    return assertions.Template.from_json(
        assembly.get_stack_by_name(f"meridian-{env}-data").template
    )


#: Placeholder Identity Center identifiers, used only to prove the conditional
#: branch. The real ones are passed with `-c` at deploy time and are never
#: written into this repository (ADR 0001).
SSO_CONTEXT = {
    "ssoInstanceArn": "arn:aws:sso:::instance/ssoins-testplaceholder",
    "ssoAdminPrincipalId": "00000000-0000-0000-0000-00000000aaaa",
    "ssoReadOnlyPrincipalId": "00000000-0000-0000-0000-00000000bbbb",
    "ssoWritePrincipalId": "00000000-0000-0000-0000-00000000cccc",
}


@pytest.fixture(scope="session")
def identity_with_sso() -> assertions.Template:
    """The identity stack once Identity Center exists and its ids are supplied."""
    application = cdk.App(context={"env": "staging", **SSO_CONTEXT})
    cdk_app.build(application)
    return assertions.Template.from_json(
        application.synth().get_stack_by_name("meridian-shared-identity").template
    )
