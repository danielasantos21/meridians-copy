"""`meridian-shared-identity`: permission sets, assignments, and the MFA deny.

Two behaviours matter here and neither is obvious from reading the stack:

1. **The stack is useful before Identity Center exists.** CloudFormation cannot
   create an Identity Center instance, so the ARN and the principal ids arrive
   as context on a later deploy. Until they do, the stack must still deploy and
   must still install the MFA guardrail — otherwise the bootstrap has a
   chicken-and-egg step and somebody does it in the console instead.
2. **The MFA policy must not lock its own users out.** A `NotAction` deny is
   easy to get subtly wrong; the two ways it bites are omitting
   `sts:GetSessionToken` (nobody can ever obtain an MFA session) and using
   `Bool` instead of `BoolIfExists` (role and service calls, which never carry
   the key, are denied too).
"""

from __future__ import annotations

import json

import app as cdk_app
import aws_cdk as cdk
import pytest
from aws_cdk import assertions, cx_api
from conftest import NO_IDENTITY_CENTER, SSO_CONTEXT

from meridian.stacks.identity import BREAK_GLASS_ROLE_NAME

ADMIN_POLICY = "arn:aws:iam::aws:policy/AdministratorAccess"
READONLY_POLICIES = [
    "arn:aws:iam::aws:policy/ReadOnlyAccess",
    "arn:aws:iam::aws:policy/SecurityAudit",
]
WRITE_POLICIES = ["arn:aws:iam::aws:policy/PowerUserAccess"]


def _statements(identity: assertions.Template) -> dict[str, dict]:
    policy = next(iter(identity.find_resources("AWS::IAM::ManagedPolicy").values()))
    return {
        statement["Sid"]: statement
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
    }


# ------------------------------------------------------- without the context


def test_the_stack_deploys_before_identity_center_exists(
    identity: assertions.Template,
) -> None:
    identity.resource_count_is("AWS::SSO::PermissionSet", 0)
    identity.resource_count_is("AWS::SSO::Assignment", 0)
    # Not empty, though: CloudFormation rejects a stack with no resources, and
    # the guardrail is the part that does not wait for anything.
    identity.resource_count_is("AWS::IAM::ManagedPolicy", 1)
    identity.resource_count_is("AWS::IAM::Group", 1)


def test_no_identity_center_identifier_is_baked_into_the_default_template(
    identity: assertions.Template,
) -> None:
    """Identifiers are passed with `-c` at deploy time, never committed (ADR 0001)."""
    assert "ssoins-" not in json.dumps(identity.to_json())


# ---------------------------------------------------------- with the context


def test_permission_sets_exist_once_the_instance_arn_is_supplied(
    identity_with_sso: assertions.Template,
) -> None:
    identity_with_sso.resource_count_is("AWS::SSO::PermissionSet", 3)
    identity_with_sso.has_resource_properties(
        "AWS::SSO::PermissionSet",
        {
            "Name": "meridian-shared-sso-admin",
            "ManagedPolicies": [ADMIN_POLICY],
            "SessionDuration": "PT4H",
            "InstanceArn": SSO_CONTEXT["ssoInstanceArn"],
        },
    )
    identity_with_sso.has_resource_properties(
        "AWS::SSO::PermissionSet",
        {
            "Name": "meridian-shared-sso-readonly",
            "ManagedPolicies": READONLY_POLICIES,
            "SessionDuration": "PT4H",
        },
    )
    identity_with_sso.has_resource_properties(
        "AWS::SSO::PermissionSet",
        {
            "Name": "meridian-shared-sso-write",
            "ManagedPolicies": WRITE_POLICIES,
            "SessionDuration": "PT4H",
        },
    )


def test_assignments_target_this_account_by_pseudo_parameter(
    identity_with_sso: assertions.Template,
) -> None:
    identity_with_sso.resource_count_is("AWS::SSO::Assignment", 3)
    for body in identity_with_sso.find_resources("AWS::SSO::Assignment").values():
        props = body["Properties"]
        assert props["PrincipalType"] == "USER"
        assert props["TargetType"] == "AWS_ACCOUNT"
        # `{"Ref": "AWS::AccountId"}` — resolved at deploy time, so no account
        # id appears in this repository.
        assert props["TargetId"] == {"Ref": "AWS::AccountId"}
    principals = {
        body["Properties"]["PrincipalId"]
        for body in identity_with_sso.find_resources("AWS::SSO::Assignment").values()
    }
    assert principals == {
        SSO_CONTEXT["ssoAdminPrincipalId"],
        SSO_CONTEXT["ssoReadOnlyPrincipalId"],
        SSO_CONTEXT["ssoWritePrincipalId"],
    }


def test_one_missing_principal_id_drops_only_its_own_assignment() -> None:
    """The two users are enrolled independently; neither blocks the other."""
    application = cdk.App(
        context={
            "env": "staging",
            "ssoInstanceArn": SSO_CONTEXT["ssoInstanceArn"],
            "ssoAdminPrincipalId": SSO_CONTEXT["ssoAdminPrincipalId"],
            # ssoReadOnlyPrincipalId deliberately absent
        }
    )
    cdk_app.build(application)
    template = assertions.Template.from_json(
        application.synth().get_stack_by_name("meridian-shared-identity").template
    )
    template.resource_count_is("AWS::SSO::PermissionSet", 3)
    template.resource_count_is("AWS::SSO::Assignment", 1)


def test_a_blank_context_value_counts_as_absent() -> None:
    """`-c ssoInstanceArn=` is a typo, not an instruction to deploy a broken ARN."""
    application = cdk.App(context={"env": "staging", "ssoInstanceArn": "   ", **NO_IDENTITY_CENTER})
    cdk_app.build(application)
    template = assertions.Template.from_json(
        application.synth().get_stack_by_name("meridian-shared-identity").template
    )
    template.resource_count_is("AWS::SSO::PermissionSet", 0)


# -------------------------------------------------- the missing-context guard


def test_synth_fails_without_the_instance_arn_and_without_the_waiver() -> None:
    """The second deploy is the dangerous one, so the guard is at synth time.

    CDK renders the whole template every time. A `cdk deploy` of this stack with
    the `-c` values missing therefore does not leave the permission sets alone —
    it removes them, and both assignments with them, signing everybody out. There
    is no CloudFormation error to notice: from CloudFormation's point of view the
    template simply no longer contains those resources.
    """
    application = cdk.App(context={"env": "staging"})
    with pytest.raises(ValueError) as excinfo:
        cdk_app.build(application)

    message = str(excinfo.value)
    assert "ssoInstanceArn" in message
    # The message has to say what to do, not just what is wrong.
    assert "allowNoIdentityCenter" in message
    assert "cdk.context.json" in message


def test_the_waiver_is_explicit_and_then_the_stack_still_synthesizes(
    identity: assertions.Template,
) -> None:
    """`-c allowNoIdentityCenter=true` is the first-pass and the CI path.

    The `identity` fixture is built with it. That it produces a template at all
    is the assertion; that the template still carries the MFA guardrail is the
    reason the waiver exists rather than the stack simply being removed.
    """
    identity.resource_count_is("AWS::IAM::ManagedPolicy", 1)
    identity.resource_count_is("AWS::SSO::PermissionSet", 0)


def test_the_waiver_is_unnecessary_once_the_arn_is_supplied(
    identity_with_sso: assertions.Template,
) -> None:
    """`identity_with_sso` passes the ARN and no waiver, and synthesizes."""
    identity_with_sso.resource_count_is("AWS::SSO::PermissionSet", 3)


# ----------------------------------------------------------- the break glass


def test_the_humans_group_may_assume_the_break_glass_role(
    identity: assertions.Template,
) -> None:
    """A trust policy grants nothing on its own.

    The break-glass role trusts `AccountRootPrincipal` with MFA, which in IAM
    means "any principal in this account **that an IAM policy also allows**".
    Without this grant the emergency access procedure required by
    45 CFR 164.312(a)(2)(ii) returns `AccessDenied` at the exact moment it is
    needed, and root is the only path left.
    """
    statements = [
        statement
        for policy in identity.find_resources("AWS::IAM::Policy").values()
        for statement in policy["Properties"]["PolicyDocument"]["Statement"]
    ]
    assume = [s for s in statements if s.get("Sid") == "AssumeBreakGlassRole"]
    assert len(assume) == 1, "exactly one break-glass grant"

    statement = assume[0]
    assert statement["Effect"] == "Allow"
    assert statement["Action"] == "sts:AssumeRole"

    resource = json.dumps(statement["Resource"])
    assert BREAK_GLASS_ROLE_NAME in resource
    # Built with `Stack.format_arn`, so the account segment is a pseudo-parameter.
    assert "AWS::AccountId" in resource
    assert "AWS::Partition" in resource


def test_the_break_glass_grant_is_attached_to_the_humans_group_and_nothing_else(
    identity: assertions.Template,
) -> None:
    """Scoped to the group, so membership is the whole of who may break glass."""
    policies = [
        policy
        for policy in identity.find_resources("AWS::IAM::Policy").values()
        if any(
            statement.get("Sid") == "AssumeBreakGlassRole"
            for statement in policy["Properties"]["PolicyDocument"]["Statement"]
        )
    ]
    assert len(policies) == 1
    props = policies[0]["Properties"]
    assert props.get("Groups"), "the grant must hang off the humans group"
    assert not props.get("Users"), "no user is named in this repository"
    assert not props.get("Roles")


def test_the_break_glass_role_name_matches_the_foundation_stack(
    foundation: assertions.Template,
) -> None:
    """Two stacks, one name, spelled once in each. This is the test that they agree.

    They are deliberately not wired together — a failed update to the identity
    stack must not be able to roll back CloudTrail — so the only thing keeping
    the grant pointed at the real role is this assertion.
    """
    role_names = {
        body["Properties"]["RoleName"]
        for body in foundation.find_resources("AWS::IAM::Role").values()
        if "RoleName" in body["Properties"]
    }
    assert BREAK_GLASS_ROLE_NAME in role_names


def test_the_break_glass_role_arn_is_an_output(identity: assertions.Template) -> None:
    """So the runbook's `aws sts assume-role` is copy-and-paste from the deploy."""
    assert "BreakGlassRoleArn" in identity.find_outputs("*")


# ------------------------------------------------------------------- the mfa


def test_the_require_mfa_policy_denies_everything_else_without_mfa(
    identity: assertions.Template,
) -> None:
    identity.has_resource_properties(
        "AWS::IAM::ManagedPolicy", {"ManagedPolicyName": "meridian-shared-iam-require-mfa"}
    )
    deny = _statements(identity)["DenyEverythingElseWithoutMfa"]
    assert deny["Effect"] == "Deny"
    assert deny["Resource"] == "*"
    assert "Action" not in deny, "the deny is a NotAction deny, or it denies nothing"
    assert deny["Condition"] == {"BoolIfExists": {"aws:MultiFactorAuthPresent": "false"}}


def test_the_deny_leaves_a_way_to_enrol_and_to_start_an_mfa_session(
    identity: assertions.Template,
) -> None:
    exempt = set(_statements(identity)["DenyEverythingElseWithoutMfa"]["NotAction"])
    # Without this one, enrolling a device does not help: there is no call left
    # that produces a session carrying `MultiFactorAuthPresent=true`.
    assert "sts:GetSessionToken" in exempt
    for action in (
        "iam:CreateVirtualMFADevice",
        "iam:EnableMFADevice",
        "iam:ResyncMFADevice",
        "iam:ChangePassword",
    ):
        assert action in exempt


def test_self_management_is_scoped_to_the_calling_user(identity: assertions.Template) -> None:
    """`${aws:username}`, so one workforce member cannot re-enrol the other's MFA."""
    statements = _statements(identity)
    for sid in ("AllowManageOwnPasswordAndUser", "AllowManageOwnUserMfa"):
        assert "${aws:username}" in json.dumps(statements[sid]["Resource"])


def test_the_humans_group_exists_and_carries_the_policy(identity: assertions.Template) -> None:
    group = next(iter(identity.find_resources("AWS::IAM::Group").values()))
    assert group["Properties"]["GroupName"] == "meridian-shared-iam-humans"
    assert group["Properties"]["ManagedPolicyArns"]


def test_no_user_is_named_in_the_stack(identity: assertions.Template) -> None:
    """Membership is an operational fact for the runbook, not a tracked identifier."""
    identity.resource_count_is("AWS::IAM::User", 0)
    rendered = json.dumps(identity.to_json())
    assert "andres-cli" not in rendered
    assert "meridian-app" not in rendered


# ---------------------------------------------------------------- both envs


def test_the_identity_stack_is_identical_in_both_environments(
    staging: cx_api.CloudAssembly,
    production: cx_api.CloudAssembly,
) -> None:
    """Account-level, like the foundation stack — and synthesized without credentials."""
    assert (
        production.get_stack_by_name("meridian-shared-identity").template
        == staging.get_stack_by_name("meridian-shared-identity").template
    )
