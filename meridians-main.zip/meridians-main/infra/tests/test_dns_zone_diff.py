"""`scripts/dns_zone_diff.py` — the GoDaddy-export half of the pre-switch check.

It lives here rather than in the repository's top-level `tests/` because everything it
guards is in `infra/`: the checked-in zone export it reads, the stack that must match
it, and `test_dns.py`, which asserts the same file against the synthesized template.
`docs/runbooks/dns-nameserver-switch.md` §3a is the procedure these back.

Both cases below are finding **M-J**, and both are the same failure in different
clothes: a live GoDaddy record that the one check meant to catch it cannot see.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = REPO_ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import dns_zone_diff  # noqa: E402

DOMAIN = "example-zone.test"

#: A GoDaddy-shaped BIND export. Three things in it are the test:
#:
#: * the **apex** `NS` set, which must be ignored (Route 53 serves its own);
#: * a **subdomain** `NS` delegation, which must NOT be ignored — it is a real record
#:   and goes dark at the switch like any other;
#: * a line typed in mixed case, which must compare equal to the lower-case export.
ZONE_FILE = f"""\
$ORIGIN {DOMAIN}.
$TTL 3600

@	3600	IN	SOA	ns25.domaincontrol.com. dns.jomax.net. (
				2026091501
				28800
				7200
				604800
				600 )

@	3600	IN	NS	ns25.domaincontrol.com.
@	3600	IN	NS	ns26.domaincontrol.com.

status	3600	IN	NS	ns1.statuspage.io.
status	3600	IN	NS	ns2.statuspage.io.

AutoDiscover	3600	IN	CNAME	AutoDiscover.Outlook.COM.
@	600	IN	A	203.0.113.10
_dmarc	3600	IN	TXT	"v=DMARC1; p=quarantine"
"""


def _write_export(tmp_path: Path, records: list[dict[str, Any]]) -> Path:
    path = tmp_path / f"{DOMAIN}.zone.json"
    path.write_text(json.dumps({"domain": f"{DOMAIN}.", "records": records}), encoding="utf-8")
    return path


#: What the checked-in export would say if somebody had taken it *before* the
#: delegation was added — lower-cased, trailing dots, the way the real one is written.
BASE_RECORDS: list[dict[str, Any]] = [
    {
        "name": f"autodiscover.{DOMAIN}.",
        "type": "CNAME",
        "ttl": 3600,
        "values": ["autodiscover.outlook.com"],
    },
    {"name": f"{DOMAIN}.", "type": "A", "ttl": 600, "values": ["203.0.113.10"]},
    {
        "name": f"_dmarc.{DOMAIN}.",
        "type": "TXT",
        "ttl": 3600,
        "values": ['"v=DMARC1; p=quarantine"'],
    },
]

DELEGATION = {
    "name": f"status.{DOMAIN}.",
    "type": "NS",
    "ttl": 3600,
    "values": ["ns1.statuspage.io", "ns2.statuspage.io"],
}


@pytest.fixture
def zone() -> dict[tuple[str, str], dict[str, object]]:
    return dns_zone_diff.parse_zone_file(ZONE_FILE, domain=DOMAIN)


def test_the_apex_ns_set_is_ignored(zone: dict[tuple[str, str], dict[str, object]]) -> None:
    """GoDaddy's export lists GoDaddy's nameservers and Route 53 serves its own. That
    they differ is the *point* of the switch, so comparing them would fail every run
    and teach the reader to ignore the output."""
    assert (DOMAIN, "NS") not in zone
    assert (DOMAIN, "SOA") not in zone


def test_a_subdomain_delegation_is_compared(
    zone: dict[tuple[str, str], dict[str, object]],
) -> None:
    """**The M-J bug.** The old code dropped `NS` for every owner name, so
    `status.<domain> NS ns1.statuspage.io.` — a live delegation of a subdomain to
    somebody else's nameservers — was invisible to the script. It would have gone dark
    at the switch with nothing reporting it.
    """
    assert (f"status.{DOMAIN}", "NS") in zone
    assert zone[(f"status.{DOMAIN}", "NS")]["values"] == [
        "ns1.statuspage.io",
        "ns2.statuspage.io",
    ]


def test_a_missing_delegation_is_reported(tmp_path: Path) -> None:
    """End to end: the export does not have it, so the diff says it would go dark."""
    export = dns_zone_diff.parse_json_export(_write_export(tmp_path, BASE_RECORDS))
    problems = dns_zone_diff.diff(dns_zone_diff.parse_zone_file(ZONE_FILE, domain=DOMAIN), export)
    assert len(problems) == 1
    assert "MISSING FROM THE CHECKED-IN EXPORT" in problems[0]
    assert "NS" in problems[0]
    assert f"status.{DOMAIN}" in problems[0]


def test_mixed_case_hostnames_are_not_a_difference(tmp_path: Path) -> None:
    """`AutoDiscover.Outlook.COM.` at GoDaddy and `autodiscover.outlook.com` in the
    export are the same record: DNS names are case-insensitive, and GoDaddy's form
    preserves whatever case was typed. Reporting it as a difference is a false
    positive, and a check with false positives stops being read.

    With the delegation added, the two agree completely — which is also the assertion
    that the case fix did not quietly hide a real difference.
    """
    export = dns_zone_diff.parse_json_export(_write_export(tmp_path, [*BASE_RECORDS, DELEGATION]))
    zone = dns_zone_diff.parse_zone_file(ZONE_FILE, domain=DOMAIN)

    assert (f"autodiscover.{DOMAIN}", "CNAME") in zone
    assert dns_zone_diff.diff(zone, export) == []


def test_txt_values_keep_their_case(tmp_path: Path) -> None:
    """Hostnames are lower-cased; `TXT` is not. A DKIM public key is base64 and its
    case is load-bearing, so a `TXT` difference must still be reported."""
    records = [*BASE_RECORDS, DELEGATION]
    records[2] = {**records[2], "values": ['"V=DMARC1; P=QUARANTINE"']}
    export = dns_zone_diff.parse_json_export(_write_export(tmp_path, records))
    problems = dns_zone_diff.diff(dns_zone_diff.parse_zone_file(ZONE_FILE, domain=DOMAIN), export)
    assert len(problems) == 1
    assert "VALUE DIFFERS" in problems[0]


def test_the_dead_compared_types_constant_is_gone() -> None:
    """It listed a type (`NS_SUB`) that does not exist and was read by nothing. A
    constant that looks like configuration and is not is worse than no constant."""
    assert not hasattr(dns_zone_diff, "COMPARED_TYPES")


# ---------------------------------------------------------------------------
# The 2026-10-12 export: GoDaddy's `<label>.@` owner names and the staging
# self-delegations (docs/runbooks/dns-move-audit-2026-10-12.md §4 step 5).
# ---------------------------------------------------------------------------

#: The four nameservers of the Route 53 zone for this same domain.
SELF_NS = (
    "ns-1.awsdns-01.com",
    "ns-2.awsdns-02.net",
    "ns-3.awsdns-03.org",
    "ns-4.awsdns-04.co.uk",
)

GODADDY_QUIRKS = (
    f"$ORIGIN {DOMAIN}.\n"
    "@\t3600\tIN\tNS\tns25.domaincontrol.com.\n"
    "_sip._tls.@\t3600\tIN\tSRV\t100\t1\t443\tsipdir.online.lync.com.\n"
    + "".join(f"staging-app\t3600\tIN\tNS\t{ns}.\n" for ns in SELF_NS)
    # Two of the four only: not "this same zone", so a real delegation.
    + "".join(f"partner\t3600\tIN\tNS\t{ns}.\n" for ns in SELF_NS[:2])
)

SRV = {
    "name": f"_sip._tls.{DOMAIN}.",
    "type": "SRV",
    "ttl": 3600,
    "values": ["100 1 443 sipdir.online.lync.com"],
}
SELF_DELEGATION = {
    "name": f"staging-app.{DOMAIN}.",
    "type": "NS",
    "ttl": 3600,
    "values": list(SELF_NS),
    "self_delegation": True,
}
PARTIAL = {
    "name": f"partner.{DOMAIN}.",
    "type": "NS",
    "ttl": 3600,
    "values": list(SELF_NS[:2]),
}


def test_a_trailing_at_label_is_the_origin() -> None:
    """GoDaddy writes `_sip._tls.@`. Read literally it became `_sip._tls.@.<domain>`,
    and each SRV record showed up as missing AND extra: four false differences."""
    zone = dns_zone_diff.parse_zone_file(GODADDY_QUIRKS, domain=DOMAIN)
    assert (f"_sip._tls.{DOMAIN}", "SRV") in zone
    assert not [name for name, _ in zone if "@" in name]


def test_self_delegations_are_skipped_on_both_sides(tmp_path: Path) -> None:
    """An NS to exactly this zone's own nameservers is skipped, the flagged export entry
    is skipped too, and nothing is reported. The partial delegation is still compared."""
    path = _write_export(tmp_path, [SRV, SELF_DELEGATION, PARTIAL])
    zone, skipped = dns_zone_diff.drop_self_delegations(
        dns_zone_diff.parse_zone_file(GODADDY_QUIRKS, domain=DOMAIN),
        dns_zone_diff.json_self_nameservers(path),
        domain=DOMAIN,
    )
    export = dns_zone_diff.parse_json_export(path)
    assert skipped == [f"staging-app.{DOMAIN}"]
    assert (f"staging-app.{DOMAIN}", "NS") not in export
    assert (f"partner.{DOMAIN}", "NS") in zone
    assert dns_zone_diff.diff(zone, export) == []


def test_a_delegation_to_only_some_of_the_zones_nameservers_is_still_reported(
    tmp_path: Path,
) -> None:
    """Only an exact match is a self-delegation. Leave `partner` out of the export and
    it must come back as missing; skipping on a partial match would hide it."""
    path = _write_export(tmp_path, [SRV, SELF_DELEGATION])
    zone, _ = dns_zone_diff.drop_self_delegations(
        dns_zone_diff.parse_zone_file(GODADDY_QUIRKS, domain=DOMAIN),
        dns_zone_diff.json_self_nameservers(path),
        domain=DOMAIN,
    )
    problems = dns_zone_diff.diff(zone, dns_zone_diff.parse_json_export(path))
    assert len(problems) == 1
    assert f"partner.{DOMAIN}" in problems[0]


def _route53_listing(tmp_path: Path, extra: list[dict[str, Any]]) -> Path:
    """A saved `aws route53 list-resource-record-sets`, Route 53's own shape."""
    sets: list[dict[str, Any]] = [
        {
            "Name": f"{DOMAIN}.",
            "Type": "NS",
            "TTL": 172800,
            "ResourceRecords": [{"Value": f"{ns}."} for ns in SELF_NS],
        },
        {"Name": f"{DOMAIN}.", "Type": "SOA", "TTL": 900, "ResourceRecords": [{"Value": "x"}]},
        {
            "Name": f"_sip._tls.{DOMAIN}.",
            "Type": "SRV",
            "TTL": 3600,
            "ResourceRecords": [{"Value": "100 1 443 sipdir.online.lync.com"}],
        },
        # Route 53 answers staging-app itself, and holds its ACM validation record.
        {
            "Name": f"staging-app.{DOMAIN}.",
            "Type": "A",
            "AliasTarget": {
                "DNSName": "d111.cloudfront.net.",
                "HostedZoneId": "Z2FDTNDATAQYW2",
                "EvaluateTargetHealth": False,
            },
        },
        {
            "Name": f"_abc.staging-app.{DOMAIN}.",
            "Type": "CNAME",
            "TTL": 300,
            "ResourceRecords": [{"Value": "_def.acm-validations.aws."}],
        },
        *extra,
    ]
    path = tmp_path / "route53.json"
    path.write_text(json.dumps({"ResourceRecordSets": sets}), encoding="utf-8")
    return path


PARTNER_IN_ROUTE53 = {
    "Name": f"partner.{DOMAIN}.",
    "Type": "NS",
    "TTL": 3600,
    "ResourceRecords": [{"Value": f"{ns}."} for ns in SELF_NS[:2]],
}


def test_route53_mode_skips_the_self_delegation_and_what_route53_holds_under_it(
    tmp_path: Path,
) -> None:
    """With `--route53`, "this zone's nameservers" is the listing's apex NS set, and
    Route 53's own records at or below a self-delegated name are not differences."""
    path = _route53_listing(tmp_path, [PARTNER_IN_ROUTE53])
    route53, nameservers = dns_zone_diff.parse_route53(path, domain=DOMAIN)
    assert nameservers == frozenset(SELF_NS)
    zone, skipped = dns_zone_diff.drop_self_delegations(
        dns_zone_diff.parse_zone_file(GODADDY_QUIRKS, domain=DOMAIN), nameservers, domain=DOMAIN
    )
    route53 = dns_zone_diff.drop_at_or_below(route53, skipped)
    assert dns_zone_diff.diff(zone, route53, route53=True) == []

    zone_file = tmp_path / "zone.txt"
    zone_file.write_text(GODADDY_QUIRKS, encoding="utf-8")
    assert dns_zone_diff.main([str(zone_file), "--domain", DOMAIN, "--route53", str(path)]) == 0


def test_route53_mode_reports_a_missing_record_as_missing_from_route53(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """End to end through `main`: the delegation to `partner` is not in Route 53."""
    zone_file = tmp_path / "zone.txt"
    zone_file.write_text(GODADDY_QUIRKS, encoding="utf-8")
    path = _route53_listing(tmp_path, [])
    assert dns_zone_diff.main([str(zone_file), "--domain", DOMAIN, "--route53", str(path)]) == 1
    out = capsys.readouterr().out
    assert "MISSING FROM ROUTE 53" in out
    assert f"partner.{DOMAIN}" in out
    assert "1 difference(s)" in out


def test_the_checked_in_export_flags_exactly_its_self_delegations() -> None:
    """The real export: its self-delegations name the four `awsdns` hosts, and no NS
    record reaches the comparison from it."""
    export_path = REPO_ROOT / "infra" / "dns" / "meridiansgrp.com.zone.json"
    nameservers = dns_zone_diff.json_self_nameservers(export_path)
    assert len(nameservers) == 4
    assert all("awsdns" in ns for ns in nameservers)
    assert not [key for key in dns_zone_diff.parse_json_export(export_path) if key[1] == "NS"]
