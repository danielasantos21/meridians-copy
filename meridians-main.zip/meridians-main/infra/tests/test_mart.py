"""`-c ecwMart=true -c ecwOrgId=<uuid>`: the nightly eCW mart copy (ADR 0053), off by default."""

from __future__ import annotations

import json

import pytest
from conftest import stack_template

ORG = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
ON = {"ecwMart": "true", "ecwOrgId": ORG}
ENVS = ["staging", "production"]


def _res(template, type_):
    """`template` is the JSON dict (`Template.to_json()`)."""
    return {k: v for k, v in template["Resources"].items() if v["Type"] == type_}


def _dump(x) -> str:
    return json.dumps(x, sort_keys=True)


def _api_container(template):
    (td,) = [
        v
        for v in _res(template, "AWS::ECS::TaskDefinition").values()
        if v["Properties"]["Family"].endswith("-ecs-api")
    ]
    return td["Properties"]["ContainerDefinitions"][0]


def _mart_td(template):
    (td,) = [
        v
        for v in _res(template, "AWS::ECS::TaskDefinition").values()
        if v["Properties"]["Family"].endswith("-ecs-mart-sync")
    ]
    return td["Properties"]


@pytest.mark.parametrize("env", ENVS)
def test_off_has_no_mart_resources_or_api_settings(env):
    t = stack_template(env, "compute").to_json()
    text = _dump(t)
    for needle in ("MART_DB_", "mart-sync", "ECW_ORG_ID", "MartSync"):
        assert needle not in text


@pytest.mark.parametrize("env", ENVS)
def test_false_is_the_same_as_absent(env):
    assert (
        stack_template(env, "compute", ecwMart="false").to_json()
        == stack_template(env, "compute").to_json()
    )


@pytest.mark.parametrize("bad", [None, "not-a-uuid"])
def test_flag_without_a_valid_org_id_fails_naming_the_flag(bad):
    ctx = {"ecwMart": "true"}
    if bad:
        ctx["ecwOrgId"] = bad
    with pytest.raises(Exception, match="ecwOrgId"):
        stack_template("staging", "compute", **ctx)


def test_bad_source_sslmode_is_refused():
    with pytest.raises(Exception, match="ecwMartSourceSslMode"):
        stack_template("staging", "compute", **ON, ecwMartSourceSslMode="disable")


@pytest.mark.parametrize("env", ENVS)
def test_api_gets_the_reader_settings(env):
    t = stack_template(env, "compute", **ON)
    c = _api_container(t.to_json())
    environment = {e["Name"]: e["Value"] for e in c["Environment"]}
    assert environment["MART_DB_NAME"] == "meridian"
    assert environment["MART_DB_USER"] == "meridian_mart_reader"
    assert environment["ECW_ORG_ID"] == ORG
    assert "MART_DB_HOST" in environment and "MART_DB_PORT" in environment
    secrets = {s["Name"]: _dump(s["ValueFrom"]) for s in c["Secrets"]}
    assert "MART_DB_PASSWORD" in secrets and ":password" in secrets["MART_DB_PASSWORD"]
    # the api reads the reader's secret and nothing of the owner's
    assert "mart-owner" not in _dump(c) and "MART_TARGET" not in _dump(c)


@pytest.mark.parametrize("env", ENVS)
def test_shared_execution_role_gets_only_the_reader_secret(env):
    off = stack_template(env, "compute").to_json()["Resources"]
    on = stack_template(env, "compute", **ON).to_json()["Resources"]
    key = next(k for k in on if k.startswith("ExecutionRoleDefaultPolicy"))
    sids_off = {s.get("Sid") for s in off[key]["Properties"]["PolicyDocument"]["Statement"]}
    sids_on = {s.get("Sid") for s in on[key]["Properties"]["PolicyDocument"]["Statement"]}
    assert sids_on - sids_off == {"ReadDbMartReaderSecret", "DecryptDbMartReaderSecretThroughSecretsManager"}


@pytest.mark.parametrize("env", ENVS)
def test_mart_sync_task_definition(env):
    t = stack_template(env, "compute", **ON)
    td = _mart_td(t.to_json())
    assert td["Cpu"] == "512" and td["Memory"] == "1024"
    assert td["RuntimePlatform"]["CpuArchitecture"] == "ARM64"
    (c,) = td["ContainerDefinitions"]
    assert c["Command"] == ["python3", "scripts/sync_data_mart.py", "--target", "rds"]
    environment = {e["Name"]: e["Value"] for e in c["Environment"]}
    assert environment["MART_TARGET_NAME"] == "meridian"
    assert environment["MART_TARGET_USER"] == "meridian_mart_owner"
    assert environment["ECW_ORG_ID"] == ORG
    assert environment["PG_SSLROOTCERT"].endswith(".pem")
    assert environment["MART_SOURCE_PORT"] == "5432"
    assert environment["MART_SOURCE_SSLMODE"] == "verify-full"
    assert environment["MART_SOURCE_EXPECTED_DB"] == "ecw_mart"
    assert _dump(environment["MART_TARGET_HOST"]) == _dump(environment["MART_TARGET_ALLOWED_HOSTS"])
    secrets = {s["Name"]: _dump(s["ValueFrom"]) for s in c["Secrets"]}
    assert set(secrets) == {
        "MART_TARGET_PASSWORD",
        "MART_SOURCE_HOST",
        "MART_SOURCE_NAME",
        "MART_SOURCE_USER",
        "MART_SOURCE_PASSWORD",
    }
    assert f"secret:meridian-{env}/ecw-db" in secrets["MART_SOURCE_HOST"]
    assert ":host::" in secrets["MART_SOURCE_HOST"] and ":dbname::" in secrets["MART_SOURCE_NAME"]
    assert "ECW_DB_" not in _dump(c)
    # same image as the api
    api = _api_container(t.to_json())
    assert _dump(api["Image"]) == _dump(c["Image"])


def test_source_sslmode_can_be_require():
    t = stack_template("staging", "compute", **ON, ecwMartSourceSslMode="require")
    (c,) = _mart_td(t.to_json())["ContainerDefinitions"]
    assert {e["Name"]: e["Value"] for e in c["Environment"]}["MART_SOURCE_SSLMODE"] == "require"


@pytest.mark.parametrize("env", ENVS)
def test_mart_roles_log_group_and_schedule(env):
    t = stack_template(env, "compute", **ON)
    j = t.to_json()["Resources"]
    roles = {
        v["Properties"]["RoleName"]: k
        for k, v in j.items()
        if v["Type"] == "AWS::IAM::Role" and "mart-sync" in v["Properties"].get("RoleName", "")
    }
    task_key = roles[f"meridian-{env}-iam-ecs-mart-sync-task"]
    # the task role has no policy of its own
    assert not [
        v for v in j.values()
        if v["Type"] == "AWS::IAM::Policy"
        and any(r.get("Ref") == task_key for r in v["Properties"]["Roles"])
    ]
    exec_key = roles[f"meridian-{env}-iam-ecs-mart-sync-execution"]
    (pol,) = [
        v for v in j.values()
        if v["Type"] == "AWS::IAM::Policy"
        and any(r.get("Ref") == exec_key for r in v["Properties"]["Roles"])
    ]
    text = _dump(pol["Properties"]["PolicyDocument"])
    secret_actions = [
        s for s in pol["Properties"]["PolicyDocument"]["Statement"]
        if "secretsmanager:GetSecretValue" in _dump(s["Action"])
    ]
    assert secret_actions
    assert f"meridian-{env}/ecw-db" in text
    assert "meridian-" + env + "-secret-db-app" not in text
    (lg,) = [v for v in j.values() if v["Type"] == "AWS::Logs::LogGroup"
             and v["Properties"].get("LogGroupName") == f"/meridian/{env}/ecs/mart-sync"]
    assert "KmsKeyId" in lg["Properties"] and lg["Properties"]["RetentionInDays"] == 400

    (sched,) = [v["Properties"] for v in j.values() if v["Type"] == "AWS::Scheduler::Schedule"
                and v["Properties"]["Name"] == f"meridian-{env}-schedule-mart-sync"]
    assert sched["ScheduleExpression"] == "cron(0 5 * * ? *)"
    assert sched["ScheduleExpressionTimezone"] == "America/Chicago"
    assert sched["State"] == "ENABLED"
    ecs_p = sched["Target"]["EcsParameters"]
    assert ecs_p["LaunchType"] == "FARGATE"
    assert ecs_p["NetworkConfiguration"]["AwsvpcConfiguration"]["AssignPublicIp"] == "DISABLED"
    assert sched["Target"]["RetryPolicy"]["MaximumRetryAttempts"] == 1
    assert ":task-definition/" in _dump(ecs_p["TaskDefinitionArn"])
    assert not _dump(ecs_p["TaskDefinitionArn"]).rstrip('"}').split(":")[-1].isdigit()


@pytest.mark.parametrize("env", ENVS)
def test_scheduler_role_may_pass_only_the_two_mart_roles(env):
    j = stack_template(env, "compute", **ON).to_json()["Resources"]
    (role_key,) = [k for k, v in j.items() if v["Type"] == "AWS::IAM::Role"
                   and v["Properties"].get("RoleName") == f"meridian-{env}-iam-mart-sync-scheduler"]
    (pol,) = [v for v in j.values() if v["Type"] == "AWS::IAM::Policy"
              and any(r.get("Ref") == role_key for r in v["Properties"]["Roles"])]
    stmts = {s["Sid"]: s for s in pol["Properties"]["PolicyDocument"]["Statement"]}
    assert set(stmts) == {"RunTheMartSyncTaskOnThisCluster", "PassTheMartSyncRoles"}
    passed = _dump(stmts["PassTheMartSyncRoles"]["Resource"])
    assert stmts["PassTheMartSyncRoles"]["Action"] == "iam:PassRole"
    assert len(stmts["PassTheMartSyncRoles"]["Resource"]) == 2
    assert "MartSyncExecutionRole" in passed and "MartSyncTaskRole" in passed
    assert "ExecutionRole" not in passed.replace("MartSyncExecutionRole", "")
    run = _dump(stmts["RunTheMartSyncTaskOnThisCluster"])
    assert "ecs-mart-sync" in run and "ecs:cluster" in run


@pytest.mark.parametrize("env", ENVS)
def test_on_only_adds_to_the_compute_template(env):
    off = stack_template(env, "compute").to_json()["Resources"]
    on = stack_template(env, "compute", **ON).to_json()["Resources"]
    assert set(off) <= set(on)
    added = {k for k in on if k not in off}
    assert all(k.startswith("MartSync") for k in added)
    changed = {k for k in off if off[k] != on[k] and k != "CDKMetadata"}
    assert changed == {"ApiTaskDefinition51EA709E", next(k for k in on if k.startswith("ExecutionRoleDefaultPolicy"))}


# ---- the data stack is the same with the flag on or off (no CDK auto-exports) ----------------
@pytest.mark.parametrize("env", ENVS)
def test_data_template_is_identical_with_the_flag_on_or_off(env):
    off = stack_template(env, "data").to_json()
    on = stack_template(env, "data", **ON).to_json()
    assert _dump(off) == _dump(on)
    assert not [k for k in _dump(off).split('"') if k.startswith("ExportsOutputRef") and "Mart" in k]
    names = {o["Export"]["Name"] for o in off["Outputs"].values() if "Export" in o}
    assert f"meridian-{env}-data-DatabaseMartOwnerSecretArn" in names
    assert f"meridian-{env}-data-DatabaseMartReaderSecretArn" in names


@pytest.mark.parametrize("env", ENVS)
def test_compute_imports_the_mart_secrets_by_export_name(env):
    text = _dump(stack_template(env, "compute", **ON).to_json())
    assert f"meridian-{env}-data-DatabaseMartOwnerSecretArn" in text
    assert f"meridian-{env}-data-DatabaseMartReaderSecretArn" in text
    assert "Fn::ImportValue" in text
    assert not [k for k in text.split('"') if "ExportsOutputRef" in k and "Mart" in k]
