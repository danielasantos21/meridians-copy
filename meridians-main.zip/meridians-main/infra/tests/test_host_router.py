"""The edge host router (ADR 0050), tested by running its JavaScript.

`meridian/host_router.py` generates a CloudFront Function. Asserting on the source
text would only prove the text says what it says, so these tests run it in Node —
the same `handler(event)` CloudFront calls, fed the event shape CloudFront builds —
and assert on what comes back. Node is on every CI runner that synthesizes (the CDK
CLI needs it); without it the behavioural tests skip and the pure-Python ones run.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

import pytest

from meridian.config import site_hosts
from meridian.host_router import (
    MAX_FUNCTION_BYTES,
    PUBLIC_ROUTES_PATH,
    host_router_code,
    marketing_paths,
)

NODE = shutil.which("node")
needs_node = pytest.mark.skipif(NODE is None, reason="node is not installed")

PROD = site_hosts("production")
STAGING = site_hosts("staging")


def run(code: str, host: str, uri: str, query: dict[str, Any] | None = None) -> dict[str, Any]:
    """Call `handler` once with a CloudFront viewer-request event."""
    event = {
        "request": {
            "method": "GET",
            "uri": uri,
            "querystring": query or {},
            "headers": {"host": {"value": host}},
        }
    }
    script = f"{code}\nprocess.stdout.write(JSON.stringify(handler({json.dumps(event)})));"
    assert NODE is not None
    out = subprocess.run(  # noqa: S603 a fixed local binary, test input only
        [NODE, "-e", script], check=True, capture_output=True, text=True, timeout=30
    )
    return json.loads(out.stdout)


def location(response: dict[str, Any]) -> str:
    return response["headers"]["location"]["value"]


# ------------------------------------------------------------------ pure Python
def test_the_marketing_list_is_read_from_the_web_app() -> None:
    assert PUBLIC_ROUTES_PATH.name == "public-routes.ts"
    assert marketing_paths() == ["/", "/features", "/pricing", "/privacy", "/terms", "/security"]


def test_a_missing_list_fails_loudly(tmp_path: Path) -> None:
    empty = tmp_path / "public-routes.ts"
    empty.write_text("export const NOTHING = 1;\n", encoding="utf-8")
    with pytest.raises(ValueError, match="MARKETING_ROUTES"):
        marketing_paths(empty)


@pytest.mark.parametrize("hosts", [PROD, STAGING])
def test_the_code_fits_a_cloudfront_function_and_is_fully_filled(hosts: Any) -> None:
    code = host_router_code(hosts)
    assert len(code.encode("utf-8")) < MAX_FUNCTION_BYTES
    assert re.search(r"@[A-Z_]+@", code) is None
    assert "function handler(event)" in code
    assert json.dumps(hosts.app) in code and json.dumps(hosts.api) in code


# ------------------------------------------------------------------- behaviour
@needs_node
def test_the_apex_redirects_permanently_to_www_keeping_path_and_query() -> None:
    code = host_router_code(PROD)
    response = run(code, "meridiansgrp.com", "/pricing", {"ref": {"value": "x"}})
    assert response["statusCode"] == 301
    assert response["statusDescription"] == "Moved Permanently"
    assert location(response) == "https://www.meridiansgrp.com/pricing?ref=x"


@needs_node
@pytest.mark.parametrize(
    ("host", "path"),
    [
        ("meridiansgrp.com", "/"),
        ("www.meridiansgrp.com", "/login"),
        ("app.meridiansgrp.com", "/"),
        ("app.meridiansgrp.com", "/pricing"),
    ],
)
def test_every_redirect_expires_from_the_browser_cache_within_an_hour(host: str, path: str) -> None:
    """A rollback puts the app back on `www`; a redirect cached for ever would not."""
    response = run(host_router_code(PROD), host, path)
    assert response["headers"]["cache-control"] == {"value": "max-age=3600"}


@needs_node
@pytest.mark.parametrize("path", ["/", "/features", "/pricing", "/security", "/privacy", "/terms"])
def test_www_serves_the_marketing_pages(path: str) -> None:
    response = run(host_router_code(PROD), "www.meridiansgrp.com", path)
    assert response["uri"] == path
    assert "statusCode" not in response


@needs_node
@pytest.mark.parametrize("path", ["/_next/static/chunks/app.js", "/brand/favicon.svg"])
def test_www_serves_the_assets_its_pages_need(path: str) -> None:
    response = run(host_router_code(PROD), "www.meridiansgrp.com", path)
    assert response["uri"] == path


@needs_node
@pytest.mark.parametrize(
    "path", ["/login", "/dashboard", "/settings", "/api/v2/me", "/auth/callback", "/static/x.svg"]
)
def test_every_app_path_on_www_goes_to_app_with_the_method_kept(path: str) -> None:
    response = run(
        host_router_code(PROD), "www.meridiansgrp.com", path, {"next": {"value": "/runs"}}
    )
    assert response["statusCode"] == 308
    assert location(response) == f"https://app.meridiansgrp.com{path}?next=/runs"


@needs_node
def test_the_app_root_goes_to_the_dashboard() -> None:
    response = run(host_router_code(PROD), "app.meridiansgrp.com", "/")
    assert response["statusCode"] == 302
    assert location(response) == "/dashboard"


@needs_node
def test_marketing_pages_on_app_go_to_www() -> None:
    response = run(host_router_code(PROD), "app.meridiansgrp.com", "/pricing")
    assert response["statusCode"] == 308
    assert location(response) == "https://www.meridiansgrp.com/pricing"


@needs_node
@pytest.mark.parametrize("path", ["/login", "/dashboard", "/api/v2/runs", "/api/v3/runs"])
def test_app_paths_on_app_pass_through(path: str) -> None:
    response = run(host_router_code(PROD), "app.meridiansgrp.com", path)
    assert response["uri"] == path


@needs_node
@pytest.mark.parametrize("hosts", [PROD, STAGING])
@pytest.mark.parametrize(
    ("public", "backend"),
    [("/v3", "/api/v3"), ("/v3/runs", "/api/v3/runs"), ("/v3/runs/abc", "/api/v3/runs/abc")],
)
def test_the_api_host_maps_v3_onto_the_backend(hosts: Any, public: str, backend: str) -> None:
    response = run(host_router_code(hosts), hosts.api, public, {"limit": {"value": "5"}})
    assert response["uri"] == backend
    # The query string is left on the request untouched.
    assert response["querystring"] == {"limit": {"value": "5"}}


@needs_node
def test_the_api_host_also_takes_the_backend_paths_the_generated_clients_call() -> None:
    response = run(host_router_code(PROD), "api.meridiansgrp.com", "/api/v3/runs")
    assert response["uri"] == "/api/v3/runs"


@needs_node
@pytest.mark.parametrize(
    "path", ["/", "/login", "/api/v2/me", "/auth/callback", "/v30", "/v3x/runs", "/_next/x.js"]
)
def test_everything_else_on_the_api_host_is_a_404(path: str) -> None:
    response = run(host_router_code(PROD), "api.meridiansgrp.com", path)
    assert response["statusCode"] == 404
    assert json.loads(response["body"]["data"])["error"]["code"] == "not_found"


@needs_node
@pytest.mark.parametrize("path", ["/", "/pricing", "/login", "/dashboard"])
def test_staging_app_serves_marketing_and_app_unsplit(path: str) -> None:
    """Staging has no www of its own (ADR 0050): nothing redirects on staging-app."""
    response = run(host_router_code(STAGING), STAGING.app, path)
    assert response["uri"] == path


@needs_node
def test_an_unknown_host_is_passed_through() -> None:
    """`origin-<env>` and anything else CloudFront might be asked for: not our call."""
    response = run(host_router_code(PROD), "origin-production.meridiansgrp.com", "/login")
    assert response["uri"] == "/login"


@needs_node
def test_the_host_header_is_compared_case_insensitively() -> None:
    response = run(host_router_code(PROD), "WWW.MeridiansGrp.com", "/login")
    assert response["statusCode"] == 308
