"""`meridian/pins.py`: the webhook sender's CA bundle is checked like the api image's.

Codex CX-INF-03. The Lambda bundling step downloads the same RDS CA bundle
`Dockerfile.api` does, and used to accept anything non-empty. Both now verify it
against `infra/pins/rds-global-bundle.sha256`, and both refuse to build at all while
the pin says `UNPINNED`.
"""

from __future__ import annotations

import inspect
from pathlib import Path

import pytest

from meridian import pins
from meridian.stacks import api


def test_unpinned_bundling_refuses_instead_of_trusting_the_download(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    pin = tmp_path / "pin.sha256"
    pin.write_text("# comment\nUNPINNED\n")
    monkeypatch.setattr(pins, "RDS_CA_PIN_FILE", pin)
    assert pins.rds_ca_bundle_sha256() is None
    commands = pins.rds_ca_bundle_commands("/asset-output/b.pem")
    assert commands[-1] == "exit 1"
    assert not any("curl" in command for command in commands)


def test_a_pinned_bundle_is_downloaded_and_then_verified(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    digest = "a" * 64
    pin = tmp_path / "pin.sha256"
    pin.write_text(f"# comment\n{digest}\n")
    monkeypatch.setattr(pins, "RDS_CA_PIN_FILE", pin)
    commands = pins.rds_ca_bundle_commands("/asset-output/b.pem")
    assert commands[0].startswith("curl -fsSL -o /asset-output/b.pem https://truststore.")
    assert commands[1] == f"echo '{digest}  /asset-output/b.pem' | sha256sum -c -"


def test_a_malformed_pin_counts_as_unpinned(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    pin = tmp_path / "pin.sha256"
    pin.write_text("DEADBEEF\n")
    monkeypatch.setattr(pins, "RDS_CA_PIN_FILE", pin)
    assert pins.rds_ca_bundle_sha256() is None


def test_the_sender_bundling_uses_the_pinned_steps() -> None:
    source = inspect.getsource(api.ApiStack._sender_code)
    assert "rds_ca_bundle_commands(" in source
    assert "test -s" not in source, "non-empty is not verification"
