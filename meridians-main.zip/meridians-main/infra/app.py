#!/usr/bin/env python3
"""The Meridian CDK app.

Synthesize one environment:

    npx cdk synth -c env=staging
    npx cdk synth -c env=production

**No account id appears anywhere in `infra/`** (ADR 0001) — `grep -rE
'[0-9]{12}' infra --include=*.py` is empty, and a test asserts it stays empty.
Account and region come from the CLI environment at deploy time via
`CDK_DEFAULT_ACCOUNT` / `CDK_DEFAULT_REGION`, which the CDK CLI sets from
whatever credentials are in use. When those variables are unset — as in CI, and
as in any local `cdk synth` — the environment is **unresolved**: CDK emits
region-agnostic templates with pseudo-parameters, which is exactly why synth
needs no AWS credentials.

That is not a trick to make CI pass. It is the property ADR 0001 asks for: the
same code deploys into a second account later by pointing different credentials
at it, with no edit.

**Every stack's construct id is its stack name**, e.g. `meridian-production-edge`
for both. The CDK CLI selects stacks by construct id, not by `stack_name`, so a
runbook that says `npx cdk deploy meridian-production-edge` only works if the two
agree; when they did not, every such command failed with "No stacks match".
Keeping them equal is what makes every selector in `docs/runbooks/`,
`.github/workflows/` and `scripts/staging_session.sh` correct as written, and
`infra/tests/test_stack_selectors.py` asserts it for each one.

**Renaming those construct ids changed nothing for CloudFormation.** A top-level
stack's own construct id is not part of the logical-id path of the constructs
inside it — those paths start below the stack — so no resource's logical id
moved, and nothing was replaced. Cross-stack exports key on `stack_name`, which
never changed either, so every import kept resolving to the same name. The rename
is visible to the CDK CLI and to the cloud assembly's stack ids, and nowhere else.
"""

from __future__ import annotations

import os

import aws_cdk as cdk

from meridian.config import (
    DEFAULT_COST_CENTER,
    DEFAULT_OWNER,
    ENV_CONFIG,
    assert_known_env,
)
from meridian.naming import SHARED, stack_name
from meridian.stacks import (
    ApiStack,
    AuthStack,
    BackupDrStack,
    ComputeStack,
    DataStack,
    DnsStack,
    EdgeStack,
    FoundationStack,
    IdentityStack,
    ObservabilityStack,
    VpcStack,
)
from meridian.stacks.compute import ses_region
from meridian.stacks.data import DEFAULT_DR_REGION
from meridian.tags import RequiredTagsAspect, common_tags


def deployment_env() -> cdk.Environment:
    """Account and region from the CLI environment — never from a literal.

    `CDK_DEFAULT_ACCOUNT` and `CDK_DEFAULT_REGION` are set by the CDK CLI from
    the credentials in use. Unset (CI, offline synth) means an unresolved
    environment, and `cdk synth` still works.
    """
    return cdk.Environment(
        account=os.environ.get("CDK_DEFAULT_ACCOUNT"),
        region=os.environ.get("CDK_DEFAULT_REGION"),
    )


def build(app: cdk.App) -> None:
    """Add every stack this app should contain for the requested environment."""
    env = deployment_env()

    # ---------------------------------------------------------------- shared
    # Account-level, deployed once, belongs to neither environment. It is
    # synthesized for every `-c env=...` value so that `cdk diff` on it is
    # always available, but `cdk deploy` names it explicitly.
    # DNS has no dependency on the foundation stack and can go first: the
    # sooner the zone exists, the sooner its records can be verified against
    # the Route 53 nameservers ahead of the switch (ADR 0017). It is bound to a
    # name because the per-environment `auth` stack sends Cognito's mail through
    # its SES identity (Phase 4, ADR 0014).
    dns = DnsStack(
        app,
        f"meridian-{SHARED}-dns",
        stack_name=f"meridian-{SHARED}-dns",
        description="Meridian public hosted zone and the SES sending identity.",
        env=env,
    )
    shared_stacks: list[cdk.Stack] = [
        FoundationStack(
            app,
            f"meridian-{SHARED}-foundation",
            stack_name=f"meridian-{SHARED}-foundation",
            description="Meridian account-level audit, detection, guardrails and CI trust.",
            env=env,
        ),
        dns,
        IdentityStack(
            app,
            f"meridian-{SHARED}-identity",
            stack_name=f"meridian-{SHARED}-identity",
            description="Meridian Identity Center permission sets and the MFA guardrail.",
            env=env,
        ),
    ]
    for shared_stack in shared_stacks:
        for key, value in common_tags(
            SHARED, owner=DEFAULT_OWNER, cost_center=DEFAULT_COST_CENTER
        ).items():
            cdk.Tags.of(shared_stack).add(key, value)

    # ----------------------------------------------------------- environment
    env_name = assert_known_env(str(app.node.try_get_context("env") or "staging"))
    cfg = ENV_CONFIG[env_name]

    # **Construction order is the dependency order, and it is the whole of ADR 0020.**
    #
    #     vpc  ←  data  (keys, secrets, RDS, buckets, backup vault)
    #      ↑        ↑
    #      └──── edge  (NAT, ALB, CloudFront, WAF, flow logs, ops)
    #
    # `vpc` is free and persists. `data` persists. `edge` holds every hourly charge and
    # is destroyed at the end of every staging session (ADR 0008 / D-15) — and because
    # nothing imports from `edge`, destroying it can never reach the VPC or the database.
    # CloudFormation refuses to delete a stack whose exports are in use, which turns that
    # from a convention into a guarantee.
    #
    # Everything is handed over as a **construct, not an ARN**, so that CDK writes the
    # exports and works out the deploy order itself. The exception is the origin-verify
    # secret, passed by ARN: `edge` only READS it into two resource properties and needs
    # no policy grant, so an ARN suffices.
    vpc = VpcStack(
        app,
        stack_name(env_name, "vpc"),
        stack_name=stack_name(env_name, "vpc"),
        description=(
            f"Meridian {env_name}: VPC, subnets, gateway endpoints, security groups. "
            "Persistent and free - never destroyed by a staging teardown (ADR 0020)."
        ),
        env=env,
        env_config=cfg,
    )
    data = DataStack(
        app,
        stack_name(env_name, "data"),
        stack_name=stack_name(env_name, "data"),
        description=f"Meridian {env_name}: KMS keys, RDS, S3, secrets, AWS Backup.",
        env=env,
        env_config=cfg,
        vpc_stack=vpc,
    )

    # `edge` is bound to a name because `compute` registers its ECS services into
    # this stack's two ALB target groups (Phase 5a). That is the one new import
    # ADR 0020 did not have, and it means `edge` is destroyed AFTER
    # `compute`/`api`/`observability`, not before — see `stacks/compute.py`.
    edge = EdgeStack(
        app,
        stack_name(env_name, "edge"),
        stack_name=stack_name(env_name, "edge"),
        description=f"Meridian {env_name}: NAT, ALB, CloudFront, WAF, flow logs, ops.",
        env=env,
        env_config=cfg,
        vpc_stack=vpc,
        logs_key=data.keys["logs"],
        ops_volume_key=data.keys["artifacts"],
        origin_verify_secret_arn=data.origin_verify.secret_arn,
    )

    # `compute` is bound to a name for the same reason `edge` is: `observability` takes
    # the two ECS services, the cluster and the api/web log groups off it, so that an
    # alarm names the service CDK actually created rather than a string that has to be
    # kept in step by hand. That import also fixes the teardown order — `compute` is
    # destroyed after `observability`, which is correct: the alarms should outlive the
    # thing they watch, not the other way round.
    # `auth` imports two things, and neither is a literal: the SES identity
    # that Cognito sends password resets through (shared `dns`, Phase 1) and
    # the environment's `internal` CMK for the migration Lambda's log group
    # and the web client's secret (`data`, the same handover `edge` uses for its
    # flow logs). Both are passed as values off the owning stack so CDK writes
    # the exports and works out the deploy order itself. Bound to a name because
    # `compute` wires the api task's `COGNITO_*` from it (T:102) and `api` scopes
    # the api task's app-client permissions to its pool ARN (Phase 12). It is
    # built before `compute` for that reason; `auth` is persistent, so the import
    # never constrains a staging teardown.
    auth = AuthStack(
        app,
        stack_name(env_name, "auth"),
        stack_name=stack_name(env_name, "auth"),
        description=f"Meridian {env_name}: Cognito user pool and clients.",
        env=env,
        env_config=cfg,
        ses_identity_name=dns.email_identity.email_identity_name,
        ses_configuration_set_name=dns.configuration_set.configuration_set_name,
        logs_key=data.keys["logs"],
        # T:163: the nightly identity export writes to `archive` under the `phi` CMK.
        export_key=data.keys["phi"],
    )

    compute = ComputeStack(
        app,
        stack_name(env_name, "compute"),
        stack_name=stack_name(env_name, "compute"),
        description=(f"Meridian {env_name}: ECR, ECS cluster, task definitions and services."),
        env=env,
        env_config=cfg,
        vpc_stack=vpc,
        data_stack=data,
        edge_stack=edge,
        auth_stack=auth,
        # SES (Phase 7). Three **plain strings** off the shared `dns` stack —
        # the domain it verified, the configuration-set name it chose, and the
        # one mailbox it publishes as. Not constructs and not tokens, unlike
        # every other handover above, for two reasons: an IAM condition value
        # and a container environment variable have to be readable text, and a
        # token would make `compute` import from the shared stack, which
        # CloudFormation then refuses to let a staging teardown destroy
        # independently. They still come off `dns` rather than being retyped
        # here, so there is exactly one definition of each.
        ses_identity_name=dns.domain,
        ses_configuration_set_name=dns.configuration_set_name,
        ses_from_address=dns.no_reply_address,
        # …and the region those two ARNs are composed in, taken off the same
        # stack rather than spelled a second time as a constant. `ses_region()`
        # refuses a concrete mismatch at synth (P7-11).
        ses_region=ses_region(dns.region),
    )

    stacks: list[cdk.Stack] = [
        vpc,
        data,
        edge,
        auth,
        compute,
        # Phase 12 T21. Empty unless `-c enableApiPlatform=true` (default off): the
        # webhook bus, queues and sender Lambda, the api task's app-client and webhook
        # permissions (on `compute`'s role, scoped to `auth`'s pool), two alarms and the
        # daily idle-client sweep. Imports from `vpc`, `data`, `compute` and `auth`;
        # exports nothing, so a staging teardown destroys it first.
        ApiStack(
            app,
            stack_name(env_name, "api"),
            stack_name=stack_name(env_name, "api"),
            description=f"Meridian {env_name}: the /api/v3 platform - webhooks, queues, API IAM.",
            env=env,
            env_config=cfg,
            vpc_stack=vpc,
            data_stack=data,
            compute_stack=compute,
            auth_stack=auth,
        ),
        # Phase 6. It imports from `data` (the alerts topic, the RDS instance, the `logs`
        # CMK, the stop-schedule DLQ), `edge` (the ALB, both target groups, the WAF, the
        # distribution, the public hostname) and `compute` (both services, the cluster,
        # the api/web log groups) — constructs, not ARNs, so CDK writes the exports and
        # works out the order. It exports nothing itself, which is what lets a staging
        # teardown destroy it first (ADR 0008 / D-15).
        ObservabilityStack(
            app,
            stack_name(env_name, "observability"),
            stack_name=stack_name(env_name, "observability"),
            description=(
                f"Meridian {env_name}: alarms, log metric filters, dashboard, the "
                "stop-DLQ pipe and the health canary."
            ),
            env=env,
            env_config=cfg,
            data_stack=data,
            edge_stack=edge,
            compute_stack=compute,
        ),
    ]

    # ------------------------------------------------- the one out-of-region stack
    # `meridian-<env>-dr` holds the cross-region backup vault the `data` stack copies
    # into. A CloudFormation stack lives in one region, so this one is pinned with
    # `-c drRegion` (default `us-west-2`).
    #
    # **It is always in the app (M-5).** It used to be added only when
    # `CDK_DEFAULT_REGION` was set, on the theory that a pinned stack needs a concrete
    # account as well as a concrete region. It does not: only the region has to be
    # concrete, and the CDK CLI sets `CDK_DEFAULT_REGION` from whatever credentials are in
    # use anyway — so under the CLI the stack was always present and the conditional only
    # ever hid it from the in-process tests, which is precisely where a missing stack goes
    # unnoticed. Pinning the region while leaving the account unresolved keeps the
    # property that actually matters: `cdk synth` still needs no credentials.
    #
    # The `data` stack does NOT import from it — it composes the vault ARN from
    # pseudo-parameters — so the two synthesize independently and the deploy order is a
    # written rule rather than a CloudFormation dependency:
    # deploy `meridian-<env>-dr` first (docs/runbooks/restore-drill.md §1).
    dr_region = str(app.node.try_get_context("drRegion") or DEFAULT_DR_REGION)
    stacks.append(
        BackupDrStack(
            app,
            stack_name(env_name, "dr"),
            stack_name=stack_name(env_name, "dr"),
            description=(
                f"Meridian {env_name}: the {dr_region} backup vault the daily plan "
                "copies into. Deploy this BEFORE meridian-<env>-data."
            ),
            env=cdk.Environment(account=os.environ.get("CDK_DEFAULT_ACCOUNT"), region=dr_region),
            env_config=cfg,
        )
    )

    for stack in stacks:
        for key, value in common_tags(
            env_name, owner=DEFAULT_OWNER, cost_center=DEFAULT_COST_CENTER
        ).items():
            cdk.Tags.of(stack).add(key, value)

    # The tag checker runs at READONLY priority, after every mutating tag Aspect
    # has written its tags. See meridian/tags.py.
    cdk.Aspects.of(app).add(RequiredTagsAspect(), priority=cdk.AspectPriority.READONLY)


def main() -> cdk.App:
    app = cdk.App()
    build(app)
    app.synth()
    return app


if __name__ == "__main__":
    main()
