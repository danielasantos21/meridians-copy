"""Hand-written helpers that ship beside the generated `meridian_client` (ADR 0043).

Kept OUTSIDE `meridian_client/`, which `scripts/generate_python_client.py`
replaces whole on every regeneration.

Two things a partner needs that an OpenAPI document cannot describe:

* `verify_webhook` — check that a webhook really came from Meridian, was not
  changed on the way, and is not a replay. Standard library only (`hmac`).
  The contract is `src/webhooks/signing.py` on the server:

      Meridian-Event-Id:  <uuid, unique per subscription; the same on every retry>
      Meridian-Signature: t=<unix seconds>,v1=<hex HMAC-SHA256(secret, "<t>.<event_id>.<body>")>

  During a secret rotation the header carries two `v1=` values for 24 hours,
  so a receiver holding either secret verifies.

* `TokenCache` — the machine access token (15 minutes) is reused until 60
  seconds before it expires, instead of asking Cognito on every call. That is
  both politeness and the cost control: Cognito bills per token request.

Nothing here logs a secret, a token or a body.
"""

from __future__ import annotations

import hashlib
import hmac
import threading
import time
import uuid
from collections.abc import Callable, Iterable, Mapping
from typing import Any

SIGNATURE_HEADER = "Meridian-Signature"
EVENT_ID_HEADER = "Meridian-Event-Id"
#: Reject a delivery signed more than this many seconds from now.
TOLERANCE_SECONDS = 300
#: Refuse absurd headers before doing any HMAC work.
MAX_SIGNATURES = 4
MAX_HEADER_LENGTH = 1024
#: Refresh the machine token this many seconds before it expires.
TOKEN_EARLY_REFRESH_SECONDS = 60


class WebhookVerificationError(ValueError):
    """The delivery must be rejected. `reason` is a short stable code."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(reason)


class ReplayCache:
    """Event ids already accepted, remembered for twice the tolerance.

    In-process. A receiver running several processes needs a shared store
    with the same "first claim wins" behaviour (an INSERT on a unique key).
    """

    def __init__(self, ttl_seconds: int = 2 * TOLERANCE_SECONDS) -> None:
        self._ttl = ttl_seconds
        self._seen: dict[str, int] = {}
        self._lock = threading.Lock()

    def claim(self, event_id: str, now: int) -> bool:
        """True the first time `event_id` is seen within the TTL, then False."""
        with self._lock:
            for key in [k for k, until in self._seen.items() if until <= now]:
                del self._seen[key]
            if event_id in self._seen:
                return False
            self._seen[event_id] = now + self._ttl
            return True


def _event_id(raw: str) -> str:
    try:
        canonical = str(uuid.UUID(raw))
    except (ValueError, TypeError, AttributeError):
        raise WebhookVerificationError("invalid_event_id") from None
    # The signed string joins its parts with "."; only a canonical UUID is safe.
    if canonical != raw:
        raise WebhookVerificationError("invalid_event_id")
    return canonical


def _parse(header: str) -> tuple[int, tuple[str, ...]]:
    if not isinstance(header, str) or not header or len(header) > MAX_HEADER_LENGTH:
        raise WebhookVerificationError("malformed_header")
    timestamp: int | None = None
    signatures: list[str] = []
    for item in header.split(","):
        name, sep, value = item.strip().partition("=")
        if not sep:
            raise WebhookVerificationError("malformed_header")
        if name == "t":
            if timestamp is not None or not value.isascii() or not value.isdigit():
                raise WebhookVerificationError("malformed_header")
            timestamp = int(value)
        elif name == "v1":
            if len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
                raise WebhookVerificationError("malformed_header")
            signatures.append(value)
    if timestamp is None or not signatures or len(signatures) > MAX_SIGNATURES:
        raise WebhookVerificationError("malformed_header")
    return timestamp, tuple(signatures)


def _expected(secret: str | bytes, timestamp: int, event_id: str, body: bytes) -> str:
    key = secret.encode("utf-8") if isinstance(secret, str) else bytes(secret)
    message = f"{timestamp}.{event_id}.".encode("ascii") + body
    return hmac.new(key, message, hashlib.sha256).hexdigest()


def verify_webhook(
    *,
    body: bytes,
    headers: Mapping[str, str],
    secrets: Iterable[str | bytes],
    replay_cache: ReplayCache,
    now: int | None = None,
    tolerance: int = TOLERANCE_SECONDS,
) -> str:
    """Return the event id of a genuine, fresh, first-seen delivery; else raise.

    `body` must be the raw request bytes exactly as received — parse the JSON
    only after this returns. `secrets` is every secret you currently hold for
    the subscription (two during a rotation). The signature is checked before
    the event id is remembered, so a forgery cannot burn a real event id.
    """
    if not isinstance(body, (bytes, bytearray)):
        raise TypeError("body must be the raw bytes received")
    lowered = {k.lower(): v for k, v in headers.items()}
    event_id = _event_id(lowered.get(EVENT_ID_HEADER.lower(), ""))
    timestamp, signatures = _parse(lowered.get(SIGNATURE_HEADER.lower(), ""))
    current = int(time.time()) if now is None else now
    if abs(current - timestamp) > tolerance:
        raise WebhookVerificationError("timestamp_out_of_tolerance")
    keys = [s for s in secrets if s]
    if not keys:
        raise WebhookVerificationError("no_secret")
    matched = False
    for secret in keys:
        expected = _expected(secret, timestamp, event_id, bytes(body))
        for signature in signatures:
            # Compare every pair: no early exit that leaks which one matched.
            matched |= hmac.compare_digest(expected, signature)
    if not matched:
        raise WebhookVerificationError("signature_mismatch")
    if not replay_cache.claim(event_id, current):
        raise WebhookVerificationError("replayed_event")
    return event_id


class TokenCache:
    """A client-credentials access token, reused until 60 s before it expires.

    `fetch` does the actual token request and returns the token endpoint's
    JSON (`access_token`, `expires_in`). `client_credentials_fetcher` builds one
    for a Cognito token URL with `httpx` (a dependency of the generated client).
    Thread-safe: concurrent callers share one refresh.
    """

    def __init__(
        self,
        fetch: Callable[[], Mapping[str, Any]],
        clock: Callable[[], float] = time.time,
        early_refresh: int = TOKEN_EARLY_REFRESH_SECONDS,
    ) -> None:
        self._fetch = fetch
        self._clock = clock
        self._early = early_refresh
        self._token: str | None = None
        self._refresh_at = 0.0
        self._lock = threading.Lock()

    def token(self) -> str:
        with self._lock:
            now = self._clock()
            if self._token is None or now >= self._refresh_at:
                answer = self._fetch()
                token = answer.get("access_token")
                expires_in = answer.get("expires_in")
                if not isinstance(token, str) or not token:
                    raise RuntimeError("the token endpoint returned no access_token")
                if isinstance(expires_in, bool) or not isinstance(expires_in, (int, float)):
                    raise RuntimeError("the token endpoint returned no expires_in")
                self._token = token
                self._refresh_at = now + max(0.0, float(expires_in) - self._early)
            return self._token

    def clear(self) -> None:
        """Forget the token (after a 401, say); the next call fetches a new one."""
        with self._lock:
            self._token = None
            self._refresh_at = 0.0


def client_credentials_fetcher(
    token_url: str, client_id: str, client_secret: str, scopes: Iterable[str] = ()
) -> Callable[[], Mapping[str, Any]]:
    """A `TokenCache` fetch for an OAuth2 client-credentials token endpoint."""

    def fetch() -> Mapping[str, Any]:
        import httpx

        data = {"grant_type": "client_credentials"}
        scope = " ".join(scopes)
        if scope:
            data["scope"] = scope
        response = httpx.post(token_url, data=data, auth=(client_id, client_secret), timeout=10)
        response.raise_for_status()
        return response.json()

    return fetch


def authenticated_client(base_url: str, tokens: TokenCache, **kwargs: Any) -> Any:
    """A `meridian_client.AuthenticatedClient` whose token comes from `tokens`.

    The generated client takes a fixed token; call this again (it is cheap)
    for each unit of work, and the cache decides whether Cognito is asked.
    """
    from meridian_client import AuthenticatedClient

    return AuthenticatedClient(base_url=base_url, token=tokens.token(), **kwargs)
