from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="PageInfo")


@_attrs_define
class PageInfo:
    """
    Attributes:
        has_more (bool):  Default: False.
        limit (int):
        next_cursor (None | str):
    """

    limit: int
    next_cursor: None | str
    has_more: bool = False

    def to_dict(self) -> dict[str, Any]:
        has_more = self.has_more

        limit = self.limit

        next_cursor: None | str
        next_cursor = self.next_cursor

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "has_more": has_more,
                "limit": limit,
                "next_cursor": next_cursor,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        has_more = d.pop("has_more")

        limit = d.pop("limit")

        def _parse_next_cursor(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        next_cursor = _parse_next_cursor(d.pop("next_cursor"))

        page_info = cls(
            has_more=has_more,
            limit=limit,
            next_cursor=next_cursor,
        )

        return page_info
