from enum import StrEnum


class QbAccountCreateDomain(StrEnum):
    PAYROLL = "payroll"
    REVENUE = "revenue"

    def __str__(self) -> str:
        return str(self.value)
