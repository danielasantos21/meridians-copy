from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="MxPayrollCreateParams")


@_attrs_define
class MxPayrollCreateParams:
    """3.3. Only the exchange rate.

    Period, year, the NRF day split and the provision date are all derived
    from the workbook — the sheet name or the title row. A run whose period
    cannot be read fails as `PERIOD_UNDETECTABLE` rather than being booked
    into a guessed month (12.5).

    A raw provider export is in pesos and carries no rate, so the user gives
    one (MXN per 1 USD); a raw file without it is refused.

        Attributes:
            exchange_rate (float | None | Unset):
    """

    exchange_rate: float | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        exchange_rate: float | None | Unset
        if isinstance(self.exchange_rate, Unset):
            exchange_rate = UNSET
        else:
            exchange_rate = self.exchange_rate

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if exchange_rate is not UNSET:
            field_dict["exchange_rate"] = exchange_rate

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_exchange_rate(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        exchange_rate = _parse_exchange_rate(d.pop("exchange_rate", UNSET))

        mx_payroll_create_params = cls(
            exchange_rate=exchange_rate,
        )

        return mx_payroll_create_params
