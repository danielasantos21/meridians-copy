from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from typing_extensions import Self

from ..models.api_client_request_v3_kind import ApiClientRequestV3Kind
from ..types import UNSET, Unset

T = TypeVar("T", bound="ApiClientRequestV3")


@_attrs_define
class ApiClientRequestV3:
    """`POST /admin/api-clients`: ask for a client (status `pending_approval`).

    Attributes:
        kind (ApiClientRequestV3Kind):
        name (str):
        ip_allowlist (list[str] | None | Unset):
        mtls_subject (None | str | Unset):
        partner_baa_id (None | Unset | UUID):
        processes (list[str] | Unset):
        scopes (list[str] | Unset):
    """

    kind: ApiClientRequestV3Kind
    name: str
    ip_allowlist: list[str] | None | Unset = UNSET
    mtls_subject: None | str | Unset = UNSET
    partner_baa_id: None | Unset | UUID = UNSET
    processes: list[str] | Unset = UNSET
    scopes: list[str] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        kind = self.kind.value

        name = self.name

        ip_allowlist: list[str] | None | Unset
        if isinstance(self.ip_allowlist, Unset):
            ip_allowlist = UNSET
        elif isinstance(self.ip_allowlist, list):
            ip_allowlist = self.ip_allowlist

        else:
            ip_allowlist = self.ip_allowlist

        mtls_subject: None | str | Unset
        if isinstance(self.mtls_subject, Unset):
            mtls_subject = UNSET
        else:
            mtls_subject = self.mtls_subject

        partner_baa_id: None | str | Unset
        if isinstance(self.partner_baa_id, Unset):
            partner_baa_id = UNSET
        elif isinstance(self.partner_baa_id, UUID):
            partner_baa_id = str(self.partner_baa_id)
        else:
            partner_baa_id = self.partner_baa_id

        processes: list[str] | Unset = UNSET
        if not isinstance(self.processes, Unset):
            processes = self.processes

        scopes: list[str] | Unset = UNSET
        if not isinstance(self.scopes, Unset):
            scopes = self.scopes

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "kind": kind,
                "name": name,
            }
        )
        if ip_allowlist is not UNSET:
            field_dict["ip_allowlist"] = ip_allowlist
        if mtls_subject is not UNSET:
            field_dict["mtls_subject"] = mtls_subject
        if partner_baa_id is not UNSET:
            field_dict["partner_baa_id"] = partner_baa_id
        if processes is not UNSET:
            field_dict["processes"] = processes
        if scopes is not UNSET:
            field_dict["scopes"] = scopes

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        kind = ApiClientRequestV3Kind(d.pop("kind"))

        name = d.pop("name")

        def _parse_ip_allowlist(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                ip_allowlist_type_0 = cast(list[str], data)

                return ip_allowlist_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        ip_allowlist = _parse_ip_allowlist(d.pop("ip_allowlist", UNSET))

        def _parse_mtls_subject(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mtls_subject = _parse_mtls_subject(d.pop("mtls_subject", UNSET))

        def _parse_partner_baa_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                partner_baa_id_type_0 = UUID(data)

                return partner_baa_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        partner_baa_id = _parse_partner_baa_id(d.pop("partner_baa_id", UNSET))

        processes = cast(list[str], d.pop("processes", UNSET))

        scopes = cast(list[str], d.pop("scopes", UNSET))

        api_client_request_v3 = cls(
            kind=kind,
            name=name,
            ip_allowlist=ip_allowlist,
            mtls_subject=mtls_subject,
            partner_baa_id=partner_baa_id,
            processes=processes,
            scopes=scopes,
        )

        return api_client_request_v3
