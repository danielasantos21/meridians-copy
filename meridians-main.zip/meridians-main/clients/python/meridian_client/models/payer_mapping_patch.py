from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="PayerMappingPatch")


@_attrs_define
class PayerMappingPatch:
    """
    Attributes:
        active (bool | None | Unset):
        notes (None | str | Unset):
        override_type (None | str | Unset):
        payer_name (None | str | Unset):
        payer_type (None | str | Unset):
    """

    active: bool | None | Unset = UNSET
    notes: None | str | Unset = UNSET
    override_type: None | str | Unset = UNSET
    payer_name: None | str | Unset = UNSET
    payer_type: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        active: bool | None | Unset
        if isinstance(self.active, Unset):
            active = UNSET
        else:
            active = self.active

        notes: None | str | Unset
        if isinstance(self.notes, Unset):
            notes = UNSET
        else:
            notes = self.notes

        override_type: None | str | Unset
        if isinstance(self.override_type, Unset):
            override_type = UNSET
        else:
            override_type = self.override_type

        payer_name: None | str | Unset
        if isinstance(self.payer_name, Unset):
            payer_name = UNSET
        else:
            payer_name = self.payer_name

        payer_type: None | str | Unset
        if isinstance(self.payer_type, Unset):
            payer_type = UNSET
        else:
            payer_type = self.payer_type

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if active is not UNSET:
            field_dict["active"] = active
        if notes is not UNSET:
            field_dict["notes"] = notes
        if override_type is not UNSET:
            field_dict["override_type"] = override_type
        if payer_name is not UNSET:
            field_dict["payer_name"] = payer_name
        if payer_type is not UNSET:
            field_dict["payer_type"] = payer_type

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        active = _parse_active(d.pop("active", UNSET))

        def _parse_notes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        notes = _parse_notes(d.pop("notes", UNSET))

        def _parse_override_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        override_type = _parse_override_type(d.pop("override_type", UNSET))

        def _parse_payer_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        payer_name = _parse_payer_name(d.pop("payer_name", UNSET))

        def _parse_payer_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        payer_type = _parse_payer_type(d.pop("payer_type", UNSET))

        payer_mapping_patch = cls(
            active=active,
            notes=notes,
            override_type=override_type,
            payer_name=payer_name,
            payer_type=payer_type,
        )

        return payer_mapping_patch
