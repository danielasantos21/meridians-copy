from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="QbLocationPatch")


@_attrs_define
class QbLocationPatch:
    """
    Attributes:
        active (bool | None | Unset):
        ns_location (None | str | Unset):
        qb_location (None | str | Unset):
    """

    active: bool | None | Unset = UNSET
    ns_location: None | str | Unset = UNSET
    qb_location: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        active: bool | None | Unset
        if isinstance(self.active, Unset):
            active = UNSET
        else:
            active = self.active

        ns_location: None | str | Unset
        if isinstance(self.ns_location, Unset):
            ns_location = UNSET
        else:
            ns_location = self.ns_location

        qb_location: None | str | Unset
        if isinstance(self.qb_location, Unset):
            qb_location = UNSET
        else:
            qb_location = self.qb_location

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if active is not UNSET:
            field_dict["active"] = active
        if ns_location is not UNSET:
            field_dict["ns_location"] = ns_location
        if qb_location is not UNSET:
            field_dict["qb_location"] = qb_location

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        active = _parse_active(d.pop("active", UNSET))

        def _parse_ns_location(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ns_location = _parse_ns_location(d.pop("ns_location", UNSET))

        def _parse_qb_location(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        qb_location = _parse_qb_location(d.pop("qb_location", UNSET))

        qb_location_patch = cls(
            active=active,
            ns_location=ns_location,
            qb_location=qb_location,
        )

        return qb_location_patch
