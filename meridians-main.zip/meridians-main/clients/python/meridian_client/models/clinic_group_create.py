from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="ClinicGroupCreate")


@_attrs_define
class ClinicGroupCreate:
    """
    Attributes:
        group_name (str):
        locations (str):
        bank_account_key (None | str | Unset):
        hospital_location (None | str | Unset):
        primary_location_code (None | str | Unset):
    """

    group_name: str
    locations: str
    bank_account_key: None | str | Unset = UNSET
    hospital_location: None | str | Unset = UNSET
    primary_location_code: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        group_name = self.group_name

        locations = self.locations

        bank_account_key: None | str | Unset
        if isinstance(self.bank_account_key, Unset):
            bank_account_key = UNSET
        else:
            bank_account_key = self.bank_account_key

        hospital_location: None | str | Unset
        if isinstance(self.hospital_location, Unset):
            hospital_location = UNSET
        else:
            hospital_location = self.hospital_location

        primary_location_code: None | str | Unset
        if isinstance(self.primary_location_code, Unset):
            primary_location_code = UNSET
        else:
            primary_location_code = self.primary_location_code

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "group_name": group_name,
                "locations": locations,
            }
        )
        if bank_account_key is not UNSET:
            field_dict["bank_account_key"] = bank_account_key
        if hospital_location is not UNSET:
            field_dict["hospital_location"] = hospital_location
        if primary_location_code is not UNSET:
            field_dict["primary_location_code"] = primary_location_code

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        group_name = d.pop("group_name")

        locations = d.pop("locations")

        def _parse_bank_account_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        bank_account_key = _parse_bank_account_key(d.pop("bank_account_key", UNSET))

        def _parse_hospital_location(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        hospital_location = _parse_hospital_location(d.pop("hospital_location", UNSET))

        def _parse_primary_location_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        primary_location_code = _parse_primary_location_code(
            d.pop("primary_location_code", UNSET)
        )

        clinic_group_create = cls(
            group_name=group_name,
            locations=locations,
            bank_account_key=bank_account_key,
            hospital_location=hospital_location,
            primary_location_code=primary_location_code,
        )

        return clinic_group_create
