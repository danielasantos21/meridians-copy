from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

T = TypeVar("T", bound="PayerMappingV3")


@_attrs_define
class PayerMappingV3:
    """
    Attributes:
        account_code (None | str):
        active (bool):  Default: True.
        category (None | str):
        id (int | None | str):
        name (str):
        notes (None | str):
        override_type (None | str):
        payer_type (None | str):
        updated_at (datetime.datetime | None):
    """

    account_code: None | str
    category: None | str
    id: int | None | str
    name: str
    notes: None | str
    override_type: None | str
    payer_type: None | str
    updated_at: datetime.datetime | None
    active: bool = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        account_code: None | str
        account_code = self.account_code

        active = self.active

        category: None | str
        category = self.category

        id: int | None | str
        id = self.id

        name = self.name

        notes: None | str
        notes = self.notes

        override_type: None | str
        override_type = self.override_type

        payer_type: None | str
        payer_type = self.payer_type

        updated_at: None | str
        if isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "account_code": account_code,
                "active": active,
                "category": category,
                "id": id,
                "name": name,
                "notes": notes,
                "override_type": override_type,
                "payer_type": payer_type,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_account_code(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        account_code = _parse_account_code(d.pop("account_code"))

        active = d.pop("active")

        def _parse_category(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        category = _parse_category(d.pop("category"))

        def _parse_id(data: object) -> int | None | str:
            if data is None:
                return data
            return cast(int | None | str, data)

        id = _parse_id(d.pop("id"))

        name = d.pop("name")

        def _parse_notes(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        notes = _parse_notes(d.pop("notes"))

        def _parse_override_type(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        override_type = _parse_override_type(d.pop("override_type"))

        def _parse_payer_type(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        payer_type = _parse_payer_type(d.pop("payer_type"))

        def _parse_updated_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = datetime.datetime.fromisoformat(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        updated_at = _parse_updated_at(d.pop("updated_at"))

        payer_mapping_v3 = cls(
            account_code=account_code,
            active=active,
            category=category,
            id=id,
            name=name,
            notes=notes,
            override_type=override_type,
            payer_type=payer_type,
            updated_at=updated_at,
        )

        payer_mapping_v3.additional_properties = d
        return payer_mapping_v3

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
