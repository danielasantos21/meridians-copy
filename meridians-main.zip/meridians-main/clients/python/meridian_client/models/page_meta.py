from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="PageMeta")


@_attrs_define
class PageMeta:
    """
    Attributes:
        total_estimate (int | None):
    """

    total_estimate: int | None

    def to_dict(self) -> dict[str, Any]:
        total_estimate: int | None
        total_estimate = self.total_estimate

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "total_estimate": total_estimate,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_total_estimate(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        total_estimate = _parse_total_estimate(d.pop("total_estimate"))

        page_meta = cls(
            total_estimate=total_estimate,
        )

        return page_meta
