from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

T = TypeVar("T", bound="QbAccountV3")


@_attrs_define
class QbAccountV3:
    """
    Attributes:
        active (bool):  Default: True.
        domain (str):
        id (int | None | str):
        is_standard (bool):  Default: False.
        ns_account (str):
        qb_account (str):
        sort_order (int):  Default: 0.
        updated_at (datetime.datetime | None):
    """

    domain: str
    id: int | None | str
    ns_account: str
    qb_account: str
    updated_at: datetime.datetime | None
    active: bool = True
    is_standard: bool = False
    sort_order: int = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        active = self.active

        domain = self.domain

        id: int | None | str
        id = self.id

        is_standard = self.is_standard

        ns_account = self.ns_account

        qb_account = self.qb_account

        sort_order = self.sort_order

        updated_at: None | str
        if isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "active": active,
                "domain": domain,
                "id": id,
                "is_standard": is_standard,
                "ns_account": ns_account,
                "qb_account": qb_account,
                "sort_order": sort_order,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        active = d.pop("active")

        domain = d.pop("domain")

        def _parse_id(data: object) -> int | None | str:
            if data is None:
                return data
            return cast(int | None | str, data)

        id = _parse_id(d.pop("id"))

        is_standard = d.pop("is_standard")

        ns_account = d.pop("ns_account")

        qb_account = d.pop("qb_account")

        sort_order = d.pop("sort_order")

        def _parse_updated_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = datetime.datetime.fromisoformat(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        updated_at = _parse_updated_at(d.pop("updated_at"))

        qb_account_v3 = cls(
            active=active,
            domain=domain,
            id=id,
            is_standard=is_standard,
            ns_account=ns_account,
            qb_account=qb_account,
            sort_order=sort_order,
            updated_at=updated_at,
        )

        qb_account_v3.additional_properties = d
        return qb_account_v3

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
