from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.run_warning_v3_details_type_0 import RunWarningV3DetailsType0


T = TypeVar("T", bound="RunWarningV3")


@_attrs_define
class RunWarningV3:
    """A non-blocking fact about the run (`DUPLICATE_INPUT`, contract §12.9).

    Attributes:
        code (str):
        details (None | RunWarningV3DetailsType0):
        message (str):
    """

    code: str
    details: None | RunWarningV3DetailsType0
    message: str

    def to_dict(self) -> dict[str, Any]:
        from ..models.run_warning_v3_details_type_0 import (
            RunWarningV3DetailsType0,
        )

        code = self.code

        details: dict[str, Any] | None
        if isinstance(self.details, RunWarningV3DetailsType0):
            details = self.details.to_dict()
        else:
            details = self.details

        message = self.message

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "code": code,
                "details": details,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.run_warning_v3_details_type_0 import (
            RunWarningV3DetailsType0,
        )

        d = dict(src_dict)
        code = d.pop("code")

        def _parse_details(data: object) -> None | RunWarningV3DetailsType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_0 = RunWarningV3DetailsType0.from_dict(data)

                return details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RunWarningV3DetailsType0, data)

        details = _parse_details(d.pop("details"))

        message = d.pop("message")

        run_warning_v3 = cls(
            code=code,
            details=details,
            message=message,
        )

        return run_warning_v3
