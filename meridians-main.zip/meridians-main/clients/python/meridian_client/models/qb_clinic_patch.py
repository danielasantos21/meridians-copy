from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="QbClinicPatch")


@_attrs_define
class QbClinicPatch:
    """
    Attributes:
        active (bool | None | Unset):
        location_name (None | str | Unset):
        qb_clinic (None | str | Unset):
        service_line (None | str | Unset):
    """

    active: bool | None | Unset = UNSET
    location_name: None | str | Unset = UNSET
    qb_clinic: None | str | Unset = UNSET
    service_line: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        active: bool | None | Unset
        if isinstance(self.active, Unset):
            active = UNSET
        else:
            active = self.active

        location_name: None | str | Unset
        if isinstance(self.location_name, Unset):
            location_name = UNSET
        else:
            location_name = self.location_name

        qb_clinic: None | str | Unset
        if isinstance(self.qb_clinic, Unset):
            qb_clinic = UNSET
        else:
            qb_clinic = self.qb_clinic

        service_line: None | str | Unset
        if isinstance(self.service_line, Unset):
            service_line = UNSET
        else:
            service_line = self.service_line

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if active is not UNSET:
            field_dict["active"] = active
        if location_name is not UNSET:
            field_dict["location_name"] = location_name
        if qb_clinic is not UNSET:
            field_dict["qb_clinic"] = qb_clinic
        if service_line is not UNSET:
            field_dict["service_line"] = service_line

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        active = _parse_active(d.pop("active", UNSET))

        def _parse_location_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        location_name = _parse_location_name(d.pop("location_name", UNSET))

        def _parse_qb_clinic(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        qb_clinic = _parse_qb_clinic(d.pop("qb_clinic", UNSET))

        def _parse_service_line(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        service_line = _parse_service_line(d.pop("service_line", UNSET))

        qb_clinic_patch = cls(
            active=active,
            location_name=location_name,
            qb_clinic=qb_clinic,
            service_line=service_line,
        )

        return qb_clinic_patch
