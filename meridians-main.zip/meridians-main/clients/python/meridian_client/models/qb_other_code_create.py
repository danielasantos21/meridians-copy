from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="QbOtherCodeCreate")


@_attrs_define
class QbOtherCodeCreate:
    """
    Attributes:
        other_code (str):
        service_line (str):
    """

    other_code: str
    service_line: str

    def to_dict(self) -> dict[str, Any]:
        other_code = self.other_code

        service_line = self.service_line

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "other_code": other_code,
                "service_line": service_line,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        other_code = d.pop("other_code")

        service_line = d.pop("service_line")

        qb_other_code_create = cls(
            other_code=other_code,
            service_line=service_line,
        )

        return qb_other_code_create
