from enum import StrEnum


class ListDeliveriesStatusType0(StrEnum):
    DEAD = "dead"
    DELIVERED = "delivered"
    DROPPED = "dropped"
    FAILED = "failed"
    PENDING = "pending"

    def __str__(self) -> str:
        return str(self.value)
