from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="UploadV3")


@_attrs_define
class UploadV3:
    """One file granted to a run (`POST /runs/{run_id}/uploads`).

    Attributes:
        content_type (None | str):
        filename (None | str):
        role (str):
        upload_id (str):
    """

    content_type: None | str
    filename: None | str
    role: str
    upload_id: str

    def to_dict(self) -> dict[str, Any]:
        content_type: None | str
        content_type = self.content_type

        filename: None | str
        filename = self.filename

        role = self.role

        upload_id = self.upload_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "content_type": content_type,
                "filename": filename,
                "role": role,
                "upload_id": upload_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_content_type(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        content_type = _parse_content_type(d.pop("content_type"))

        def _parse_filename(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        filename = _parse_filename(d.pop("filename"))

        role = d.pop("role")

        upload_id = d.pop("upload_id")

        upload_v3 = cls(
            content_type=content_type,
            filename=filename,
            role=role,
            upload_id=upload_id,
        )

        return upload_v3
