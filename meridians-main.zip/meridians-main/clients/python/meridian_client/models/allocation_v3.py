from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.allocation_share_v3 import AllocationShareV3


T = TypeVar("T", bound="AllocationV3")


@_attrs_define
class AllocationV3:
    """One employee's clinic split, as `employee_clinic_allocations` holds it.

    Attributes:
        allocations (list[AllocationShareV3]):
        employee (str):
        entity (None | str):
        file_number (None | str):
        job_category (None | str):
        pay_type (None | str):
        subsidiary (None | str):
    """

    allocations: list[AllocationShareV3]
    employee: str
    entity: None | str
    file_number: None | str
    job_category: None | str
    pay_type: None | str
    subsidiary: None | str

    def to_dict(self) -> dict[str, Any]:
        allocations = []
        for allocations_item_data in self.allocations:
            allocations_item = allocations_item_data.to_dict()
            allocations.append(allocations_item)

        employee = self.employee

        entity: None | str
        entity = self.entity

        file_number: None | str
        file_number = self.file_number

        job_category: None | str
        job_category = self.job_category

        pay_type: None | str
        pay_type = self.pay_type

        subsidiary: None | str
        subsidiary = self.subsidiary

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "allocations": allocations,
                "employee": employee,
                "entity": entity,
                "file_number": file_number,
                "job_category": job_category,
                "pay_type": pay_type,
                "subsidiary": subsidiary,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.allocation_share_v3 import AllocationShareV3

        d = dict(src_dict)
        allocations = []
        _allocations = d.pop("allocations")
        for allocations_item_data in _allocations:
            allocations_item = AllocationShareV3.from_dict(allocations_item_data)

            allocations.append(allocations_item)

        employee = d.pop("employee")

        def _parse_entity(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        entity = _parse_entity(d.pop("entity"))

        def _parse_file_number(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        file_number = _parse_file_number(d.pop("file_number"))

        def _parse_job_category(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        job_category = _parse_job_category(d.pop("job_category"))

        def _parse_pay_type(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        pay_type = _parse_pay_type(d.pop("pay_type"))

        def _parse_subsidiary(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        subsidiary = _parse_subsidiary(d.pop("subsidiary"))

        allocation_v3 = cls(
            allocations=allocations,
            employee=employee,
            entity=entity,
            file_number=file_number,
            job_category=job_category,
            pay_type=pay_type,
            subsidiary=subsidiary,
        )

        return allocation_v3
