from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.clinic_group_v3 import ClinicGroupV3
    from ..models.department_v3 import DepartmentV3
    from ..models.location_mapping_v3 import LocationMappingV3
    from ..models.page_info import PageInfo
    from ..models.page_meta import PageMeta
    from ..models.payer_mapping_v3 import PayerMappingV3
    from ..models.provider_mapping_v3 import ProviderMappingV3
    from ..models.qb_account_v3 import QbAccountV3
    from ..models.qb_clinic_v3 import QbClinicV3
    from ..models.qb_department_v3 import QbDepartmentV3
    from ..models.qb_location_v3 import QbLocationV3
    from ..models.qb_other_code_v3 import QbOtherCodeV3
    from ..models.qb_payer_label_v3 import QbPayerLabelV3
    from ..models.qb_provider_code_v3 import QbProviderCodeV3


T = TypeVar("T", bound="PagedMappingV3")


@_attrs_define
class PagedMappingV3:
    """
    Attributes:
        data (list[ClinicGroupV3 | DepartmentV3 | LocationMappingV3 | PayerMappingV3 | ProviderMappingV3 | QbAccountV3 |
            QbClinicV3 | QbDepartmentV3 | QbLocationV3 | QbOtherCodeV3 | QbPayerLabelV3 | QbProviderCodeV3]):
        meta (PageMeta):
        page (PageInfo):
    """

    data: list[
        ClinicGroupV3
        | DepartmentV3
        | LocationMappingV3
        | PayerMappingV3
        | ProviderMappingV3
        | QbAccountV3
        | QbClinicV3
        | QbDepartmentV3
        | QbLocationV3
        | QbOtherCodeV3
        | QbPayerLabelV3
        | QbProviderCodeV3
    ]
    meta: PageMeta
    page: PageInfo

    def to_dict(self) -> dict[str, Any]:
        from ..models.clinic_group_v3 import ClinicGroupV3
        from ..models.department_v3 import DepartmentV3
        from ..models.location_mapping_v3 import LocationMappingV3
        from ..models.payer_mapping_v3 import PayerMappingV3
        from ..models.provider_mapping_v3 import ProviderMappingV3
        from ..models.qb_account_v3 import QbAccountV3
        from ..models.qb_clinic_v3 import QbClinicV3
        from ..models.qb_department_v3 import QbDepartmentV3
        from ..models.qb_other_code_v3 import QbOtherCodeV3
        from ..models.qb_payer_label_v3 import QbPayerLabelV3
        from ..models.qb_provider_code_v3 import QbProviderCodeV3

        data = []
        for data_item_data in self.data:
            data_item: dict[str, Any]
            if (
                isinstance(data_item_data, ProviderMappingV3)
                or isinstance(data_item_data, LocationMappingV3)
                or isinstance(data_item_data, PayerMappingV3)
                or isinstance(data_item_data, DepartmentV3)
                or isinstance(data_item_data, QbProviderCodeV3)
                or isinstance(data_item_data, ClinicGroupV3)
                or isinstance(data_item_data, QbAccountV3)
                or isinstance(data_item_data, QbDepartmentV3)
                or isinstance(data_item_data, QbClinicV3)
                or isinstance(data_item_data, QbOtherCodeV3)
                or isinstance(data_item_data, QbPayerLabelV3)
            ):
                data_item = data_item_data.to_dict()
            else:
                data_item = data_item_data.to_dict()

            data.append(data_item)

        meta = self.meta.to_dict()

        page = self.page.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "data": data,
                "meta": meta,
                "page": page,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.clinic_group_v3 import ClinicGroupV3
        from ..models.department_v3 import DepartmentV3
        from ..models.location_mapping_v3 import LocationMappingV3
        from ..models.page_info import PageInfo
        from ..models.page_meta import PageMeta
        from ..models.payer_mapping_v3 import PayerMappingV3
        from ..models.provider_mapping_v3 import ProviderMappingV3
        from ..models.qb_account_v3 import QbAccountV3
        from ..models.qb_clinic_v3 import QbClinicV3
        from ..models.qb_department_v3 import QbDepartmentV3
        from ..models.qb_location_v3 import QbLocationV3
        from ..models.qb_other_code_v3 import QbOtherCodeV3
        from ..models.qb_payer_label_v3 import QbPayerLabelV3
        from ..models.qb_provider_code_v3 import QbProviderCodeV3

        d = dict(src_dict)
        data = []
        _data = d.pop("data")
        for data_item_data in _data:

            def _parse_data_item(
                data: object,
            ) -> (
                ClinicGroupV3
                | DepartmentV3
                | LocationMappingV3
                | PayerMappingV3
                | ProviderMappingV3
                | QbAccountV3
                | QbClinicV3
                | QbDepartmentV3
                | QbLocationV3
                | QbOtherCodeV3
                | QbPayerLabelV3
                | QbProviderCodeV3
            ):
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_0 = ProviderMappingV3.from_dict(data)

                    return data_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_1 = LocationMappingV3.from_dict(data)

                    return data_item_type_1
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_2 = PayerMappingV3.from_dict(data)

                    return data_item_type_2
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_3 = DepartmentV3.from_dict(data)

                    return data_item_type_3
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_4 = QbProviderCodeV3.from_dict(data)

                    return data_item_type_4
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_5 = ClinicGroupV3.from_dict(data)

                    return data_item_type_5
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_6 = QbAccountV3.from_dict(data)

                    return data_item_type_6
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_7 = QbDepartmentV3.from_dict(data)

                    return data_item_type_7
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_8 = QbClinicV3.from_dict(data)

                    return data_item_type_8
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_9 = QbOtherCodeV3.from_dict(data)

                    return data_item_type_9
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    data_item_type_10 = QbPayerLabelV3.from_dict(data)

                    return data_item_type_10
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                data_item_type_11 = QbLocationV3.from_dict(data)

                return data_item_type_11

            data_item = _parse_data_item(data_item_data)

            data.append(data_item)

        meta = PageMeta.from_dict(d.pop("meta"))

        page = PageInfo.from_dict(d.pop("page"))

        paged_mapping_v3 = cls(
            data=data,
            meta=meta,
            page=page,
        )

        return paged_mapping_v3
