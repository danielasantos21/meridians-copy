from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="MxEmployeeIn")


@_attrs_define
class MxEmployeeIn:
    """`PUT /api/v2/config/mx-employees/{employee_id}` — create or replace one row.

    PUT and not PATCH: the Jinja form was one form doing both, posting every
    field every time, and a partial update would let a half-filled inline edit
    blank a department nobody was editing.

    `employee_id` is in the path, not the body. The two required fields are the
    ones the Flask route refused without — the code and the NetSuite department
    — and they are required here for the same reason: a roster row with no
    department books payroll to nothing.

        Attributes:
            department_netsuite (str):
            department (str | Unset):  Default: ''.
            name (str | Unset):  Default: ''.
            position (str | Unset):  Default: ''.
            report (str | Unset):  Default: ''.
    """

    department_netsuite: str
    department: str | Unset = ""
    name: str | Unset = ""
    position: str | Unset = ""
    report: str | Unset = ""

    def to_dict(self) -> dict[str, Any]:
        department_netsuite = self.department_netsuite

        department = self.department

        name = self.name

        position = self.position

        report = self.report

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "department_netsuite": department_netsuite,
            }
        )
        if department is not UNSET:
            field_dict["department"] = department
        if name is not UNSET:
            field_dict["name"] = name
        if position is not UNSET:
            field_dict["position"] = position
        if report is not UNSET:
            field_dict["report"] = report

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        department_netsuite = d.pop("department_netsuite")

        department = d.pop("department", UNSET)

        name = d.pop("name", UNSET)

        position = d.pop("position", UNSET)

        report = d.pop("report", UNSET)

        mx_employee_in = cls(
            department_netsuite=department_netsuite,
            department=department,
            name=name,
            position=position,
            report=report,
        )

        return mx_employee_in
