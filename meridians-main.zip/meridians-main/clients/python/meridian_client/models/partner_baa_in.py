from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="PartnerBaaIn")


@_attrs_define
class PartnerBaaIn:
    """`POST /admin/partner-baas`: record a signed agreement.

    Attributes:
        document_ref (str):
        partner_name (str):
        signed_on (datetime.date):
        expires_on (datetime.date | None | Unset):
    """

    document_ref: str
    partner_name: str
    signed_on: datetime.date
    expires_on: datetime.date | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        document_ref = self.document_ref

        partner_name = self.partner_name

        signed_on = self.signed_on.isoformat()

        expires_on: None | str | Unset
        if isinstance(self.expires_on, Unset):
            expires_on = UNSET
        elif isinstance(self.expires_on, datetime.date):
            expires_on = self.expires_on.isoformat()
        else:
            expires_on = self.expires_on

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "document_ref": document_ref,
                "partner_name": partner_name,
                "signed_on": signed_on,
            }
        )
        if expires_on is not UNSET:
            field_dict["expires_on"] = expires_on

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        document_ref = d.pop("document_ref")

        partner_name = d.pop("partner_name")

        signed_on = datetime.date.fromisoformat(d.pop("signed_on"))

        def _parse_expires_on(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_on_type_0 = datetime.date.fromisoformat(data)

                return expires_on_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        expires_on = _parse_expires_on(d.pop("expires_on", UNSET))

        partner_baa_in = cls(
            document_ref=document_ref,
            partner_name=partner_name,
            signed_on=signed_on,
            expires_on=expires_on,
        )

        return partner_baa_in
