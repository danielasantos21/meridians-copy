from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="RevenueSliceV3")


@_attrs_define
class RevenueSliceV3:
    """
    Attributes:
        amount (float):
        clinic_group (None | str):
        name (str):
        pct (float):
        records (int):
    """

    amount: float
    clinic_group: None | str
    name: str
    pct: float
    records: int

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        clinic_group: None | str
        clinic_group = self.clinic_group

        name = self.name

        pct = self.pct

        records = self.records

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "amount": amount,
                "clinic_group": clinic_group,
                "name": name,
                "pct": pct,
                "records": records,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        amount = d.pop("amount")

        def _parse_clinic_group(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        clinic_group = _parse_clinic_group(d.pop("clinic_group"))

        name = d.pop("name")

        pct = d.pop("pct")

        records = d.pop("records")

        revenue_slice_v3 = cls(
            amount=amount,
            clinic_group=clinic_group,
            name=name,
            pct=pct,
            records=records,
        )

        return revenue_slice_v3
