from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="PartnerBaaV3")


@_attrs_define
class PartnerBaaV3:
    """One BAA as a superadmin sees it.

    Attributes:
        approved_at (datetime.datetime | None):
        approved_by (None | str):
        client_count (int):  Default: 0.
        document_ref (str):
        expires_on (datetime.date | None):
        id (str):
        in_force (bool):
        partner_name (str):
        revoked_at (datetime.datetime | None):
        revoked_by (None | str):
        revoked_reason (None | str):
        signed_on (datetime.date):
    """

    approved_at: datetime.datetime | None
    approved_by: None | str
    document_ref: str
    expires_on: datetime.date | None
    id: str
    in_force: bool
    partner_name: str
    revoked_at: datetime.datetime | None
    revoked_by: None | str
    revoked_reason: None | str
    signed_on: datetime.date
    client_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        approved_at: None | str
        if isinstance(self.approved_at, datetime.datetime):
            approved_at = self.approved_at.isoformat()
        else:
            approved_at = self.approved_at

        approved_by: None | str
        approved_by = self.approved_by

        client_count = self.client_count

        document_ref = self.document_ref

        expires_on: None | str
        if isinstance(self.expires_on, datetime.date):
            expires_on = self.expires_on.isoformat()
        else:
            expires_on = self.expires_on

        id = self.id

        in_force = self.in_force

        partner_name = self.partner_name

        revoked_at: None | str
        if isinstance(self.revoked_at, datetime.datetime):
            revoked_at = self.revoked_at.isoformat()
        else:
            revoked_at = self.revoked_at

        revoked_by: None | str
        revoked_by = self.revoked_by

        revoked_reason: None | str
        revoked_reason = self.revoked_reason

        signed_on = self.signed_on.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "approved_at": approved_at,
                "approved_by": approved_by,
                "client_count": client_count,
                "document_ref": document_ref,
                "expires_on": expires_on,
                "id": id,
                "in_force": in_force,
                "partner_name": partner_name,
                "revoked_at": revoked_at,
                "revoked_by": revoked_by,
                "revoked_reason": revoked_reason,
                "signed_on": signed_on,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_approved_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                approved_at_type_0 = datetime.datetime.fromisoformat(data)

                return approved_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        approved_at = _parse_approved_at(d.pop("approved_at"))

        def _parse_approved_by(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        approved_by = _parse_approved_by(d.pop("approved_by"))

        client_count = d.pop("client_count")

        document_ref = d.pop("document_ref")

        def _parse_expires_on(data: object) -> datetime.date | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_on_type_0 = datetime.date.fromisoformat(data)

                return expires_on_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None, data)

        expires_on = _parse_expires_on(d.pop("expires_on"))

        id = d.pop("id")

        in_force = d.pop("in_force")

        partner_name = d.pop("partner_name")

        def _parse_revoked_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                revoked_at_type_0 = datetime.datetime.fromisoformat(data)

                return revoked_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        revoked_at = _parse_revoked_at(d.pop("revoked_at"))

        def _parse_revoked_by(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        revoked_by = _parse_revoked_by(d.pop("revoked_by"))

        def _parse_revoked_reason(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        revoked_reason = _parse_revoked_reason(d.pop("revoked_reason"))

        signed_on = datetime.date.fromisoformat(d.pop("signed_on"))

        partner_baa_v3 = cls(
            approved_at=approved_at,
            approved_by=approved_by,
            client_count=client_count,
            document_ref=document_ref,
            expires_on=expires_on,
            id=id,
            in_force=in_force,
            partner_name=partner_name,
            revoked_at=revoked_at,
            revoked_by=revoked_by,
            revoked_reason=revoked_reason,
            signed_on=signed_on,
        )

        return partner_baa_v3
