from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="ApiClientV3")


@_attrs_define
class ApiClientV3:
    """One machine client as an admin sees it. Never a secret.

    Attributes:
        approved_at (datetime.datetime | None):
        approved_by (None | str):
        cognito_client_id (None | str):
        created_at (datetime.datetime | None):
        disabled_at (datetime.datetime | None):
        disabled_reason (None | str):
        id (str):
        ip_allowlist (list[str] | None):
        kind (str):
        last_used_at (datetime.datetime | None):
        mtls_subject (None | str):
        name (str):
        partner_baa_id (None | str):
        processes (list[str]):
        requested_by (None | str):
        rotation_in_progress (bool):  Default: False.
        rotation_started_at (datetime.datetime | None):
        scopes (list[str]):
        secret_fingerprint (None | str):
        self_approved (bool):  Default: False.
        status (str):
    """

    approved_at: datetime.datetime | None
    approved_by: None | str
    cognito_client_id: None | str
    created_at: datetime.datetime | None
    disabled_at: datetime.datetime | None
    disabled_reason: None | str
    id: str
    ip_allowlist: list[str] | None
    kind: str
    last_used_at: datetime.datetime | None
    mtls_subject: None | str
    name: str
    partner_baa_id: None | str
    processes: list[str]
    requested_by: None | str
    rotation_started_at: datetime.datetime | None
    scopes: list[str]
    secret_fingerprint: None | str
    status: str
    rotation_in_progress: bool = False
    self_approved: bool = False

    def to_dict(self) -> dict[str, Any]:
        approved_at: None | str
        if isinstance(self.approved_at, datetime.datetime):
            approved_at = self.approved_at.isoformat()
        else:
            approved_at = self.approved_at

        approved_by: None | str
        approved_by = self.approved_by

        cognito_client_id: None | str
        cognito_client_id = self.cognito_client_id

        created_at: None | str
        if isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        disabled_at: None | str
        if isinstance(self.disabled_at, datetime.datetime):
            disabled_at = self.disabled_at.isoformat()
        else:
            disabled_at = self.disabled_at

        disabled_reason: None | str
        disabled_reason = self.disabled_reason

        id = self.id

        ip_allowlist: list[str] | None
        if isinstance(self.ip_allowlist, list):
            ip_allowlist = self.ip_allowlist

        else:
            ip_allowlist = self.ip_allowlist

        kind = self.kind

        last_used_at: None | str
        if isinstance(self.last_used_at, datetime.datetime):
            last_used_at = self.last_used_at.isoformat()
        else:
            last_used_at = self.last_used_at

        mtls_subject: None | str
        mtls_subject = self.mtls_subject

        name = self.name

        partner_baa_id: None | str
        partner_baa_id = self.partner_baa_id

        processes = self.processes

        requested_by: None | str
        requested_by = self.requested_by

        rotation_in_progress = self.rotation_in_progress

        rotation_started_at: None | str
        if isinstance(self.rotation_started_at, datetime.datetime):
            rotation_started_at = self.rotation_started_at.isoformat()
        else:
            rotation_started_at = self.rotation_started_at

        scopes = self.scopes

        secret_fingerprint: None | str
        secret_fingerprint = self.secret_fingerprint

        self_approved = self.self_approved

        status = self.status

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "approved_at": approved_at,
                "approved_by": approved_by,
                "cognito_client_id": cognito_client_id,
                "created_at": created_at,
                "disabled_at": disabled_at,
                "disabled_reason": disabled_reason,
                "id": id,
                "ip_allowlist": ip_allowlist,
                "kind": kind,
                "last_used_at": last_used_at,
                "mtls_subject": mtls_subject,
                "name": name,
                "partner_baa_id": partner_baa_id,
                "processes": processes,
                "requested_by": requested_by,
                "rotation_in_progress": rotation_in_progress,
                "rotation_started_at": rotation_started_at,
                "scopes": scopes,
                "secret_fingerprint": secret_fingerprint,
                "self_approved": self_approved,
                "status": status,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_approved_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                approved_at_type_0 = datetime.datetime.fromisoformat(data)

                return approved_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        approved_at = _parse_approved_at(d.pop("approved_at"))

        def _parse_approved_by(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        approved_by = _parse_approved_by(d.pop("approved_by"))

        def _parse_cognito_client_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        cognito_client_id = _parse_cognito_client_id(d.pop("cognito_client_id"))

        def _parse_created_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = datetime.datetime.fromisoformat(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        created_at = _parse_created_at(d.pop("created_at"))

        def _parse_disabled_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                disabled_at_type_0 = datetime.datetime.fromisoformat(data)

                return disabled_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        disabled_at = _parse_disabled_at(d.pop("disabled_at"))

        def _parse_disabled_reason(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        disabled_reason = _parse_disabled_reason(d.pop("disabled_reason"))

        id = d.pop("id")

        def _parse_ip_allowlist(data: object) -> list[str] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                ip_allowlist_type_0 = cast(list[str], data)

                return ip_allowlist_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None, data)

        ip_allowlist = _parse_ip_allowlist(d.pop("ip_allowlist"))

        kind = d.pop("kind")

        def _parse_last_used_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_used_at_type_0 = datetime.datetime.fromisoformat(data)

                return last_used_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_used_at = _parse_last_used_at(d.pop("last_used_at"))

        def _parse_mtls_subject(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        mtls_subject = _parse_mtls_subject(d.pop("mtls_subject"))

        name = d.pop("name")

        def _parse_partner_baa_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        partner_baa_id = _parse_partner_baa_id(d.pop("partner_baa_id"))

        processes = cast(list[str], d.pop("processes"))

        def _parse_requested_by(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        requested_by = _parse_requested_by(d.pop("requested_by"))

        rotation_in_progress = d.pop("rotation_in_progress")

        def _parse_rotation_started_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                rotation_started_at_type_0 = datetime.datetime.fromisoformat(data)

                return rotation_started_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        rotation_started_at = _parse_rotation_started_at(d.pop("rotation_started_at"))

        scopes = cast(list[str], d.pop("scopes"))

        def _parse_secret_fingerprint(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        secret_fingerprint = _parse_secret_fingerprint(d.pop("secret_fingerprint"))

        self_approved = d.pop("self_approved")

        status = d.pop("status")

        api_client_v3 = cls(
            approved_at=approved_at,
            approved_by=approved_by,
            cognito_client_id=cognito_client_id,
            created_at=created_at,
            disabled_at=disabled_at,
            disabled_reason=disabled_reason,
            id=id,
            ip_allowlist=ip_allowlist,
            kind=kind,
            last_used_at=last_used_at,
            mtls_subject=mtls_subject,
            name=name,
            partner_baa_id=partner_baa_id,
            processes=processes,
            requested_by=requested_by,
            rotation_in_progress=rotation_in_progress,
            rotation_started_at=rotation_started_at,
            scopes=scopes,
            secret_fingerprint=secret_fingerprint,
            self_approved=self_approved,
            status=status,
        )

        return api_client_v3
