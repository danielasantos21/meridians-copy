from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="ProcessV3")


@_attrs_define
class ProcessV3:
    """
    Attributes:
        can_run (bool):
        can_view_results (bool):
        enabled (bool):
        key (str):
        name (str):
        steps (list[str]):
    """

    can_run: bool
    can_view_results: bool
    enabled: bool
    key: str
    name: str
    steps: list[str]

    def to_dict(self) -> dict[str, Any]:
        can_run = self.can_run

        can_view_results = self.can_view_results

        enabled = self.enabled

        key = self.key

        name = self.name

        steps = self.steps

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "can_run": can_run,
                "can_view_results": can_view_results,
                "enabled": enabled,
                "key": key,
                "name": name,
                "steps": steps,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        can_run = d.pop("can_run")

        can_view_results = d.pop("can_view_results")

        enabled = d.pop("enabled")

        key = d.pop("key")

        name = d.pop("name")

        steps = cast(list[str], d.pop("steps"))

        process_v3 = cls(
            can_run=can_run,
            can_view_results=can_view_results,
            enabled=enabled,
            key=key,
            name=name,
            steps=steps,
        )

        return process_v3
