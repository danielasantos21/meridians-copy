from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.error_body_details_type_0 import ErrorBodyDetailsType0
    from ..models.error_body_field_errors_type_0 import ErrorBodyFieldErrorsType0


T = TypeVar("T", bound="ErrorBody")


@_attrs_define
class ErrorBody:
    """
    Attributes:
        code (str):
        details (ErrorBodyDetailsType0 | None):
        field_errors (ErrorBodyFieldErrorsType0 | None):
        message (str):
        request_id (str):
        retryable (bool):  Default: False.
    """

    code: str
    details: ErrorBodyDetailsType0 | None
    field_errors: ErrorBodyFieldErrorsType0 | None
    message: str
    request_id: str
    retryable: bool = False

    def to_dict(self) -> dict[str, Any]:
        from ..models.error_body_details_type_0 import (
            ErrorBodyDetailsType0,
        )
        from ..models.error_body_field_errors_type_0 import (
            ErrorBodyFieldErrorsType0,
        )

        code = self.code

        details: dict[str, Any] | None
        if isinstance(self.details, ErrorBodyDetailsType0):
            details = self.details.to_dict()
        else:
            details = self.details

        field_errors: dict[str, Any] | None
        if isinstance(self.field_errors, ErrorBodyFieldErrorsType0):
            field_errors = self.field_errors.to_dict()
        else:
            field_errors = self.field_errors

        message = self.message

        request_id = self.request_id

        retryable = self.retryable

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "code": code,
                "details": details,
                "field_errors": field_errors,
                "message": message,
                "request_id": request_id,
                "retryable": retryable,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.error_body_details_type_0 import (
            ErrorBodyDetailsType0,
        )
        from ..models.error_body_field_errors_type_0 import (
            ErrorBodyFieldErrorsType0,
        )

        d = dict(src_dict)
        code = d.pop("code")

        def _parse_details(data: object) -> ErrorBodyDetailsType0 | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_0 = ErrorBodyDetailsType0.from_dict(data)

                return details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ErrorBodyDetailsType0 | None, data)

        details = _parse_details(d.pop("details"))

        def _parse_field_errors(data: object) -> ErrorBodyFieldErrorsType0 | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                field_errors_type_0 = ErrorBodyFieldErrorsType0.from_dict(data)

                return field_errors_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ErrorBodyFieldErrorsType0 | None, data)

        field_errors = _parse_field_errors(d.pop("field_errors"))

        message = d.pop("message")

        request_id = d.pop("request_id")

        retryable = d.pop("retryable")

        error_body = cls(
            code=code,
            details=details,
            field_errors=field_errors,
            message=message,
            request_id=request_id,
            retryable=retryable,
        )

        return error_body
