from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="DepartmentCreate")


@_attrs_define
class DepartmentCreate:
    """
    Attributes:
        department_name (str):
    """

    department_name: str

    def to_dict(self) -> dict[str, Any]:
        department_name = self.department_name

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "department_name": department_name,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        department_name = d.pop("department_name")

        department_create = cls(
            department_name=department_name,
        )

        return department_create
