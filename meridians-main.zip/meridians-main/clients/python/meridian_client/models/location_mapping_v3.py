from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

T = TypeVar("T", bound="LocationMappingV3")


@_attrs_define
class LocationMappingV3:
    """
    Attributes:
        active (bool):  Default: True.
        clinic_group (None | str):
        code (None | str):
        facility_raw (None | str):
        has_hospital (bool):  Default: False.
        id (int | None | str):
        name (str):
        netsuite_entity (None | str):
        updated_at (datetime.datetime | None):
    """

    clinic_group: None | str
    code: None | str
    facility_raw: None | str
    id: int | None | str
    name: str
    netsuite_entity: None | str
    updated_at: datetime.datetime | None
    active: bool = True
    has_hospital: bool = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        active = self.active

        clinic_group: None | str
        clinic_group = self.clinic_group

        code: None | str
        code = self.code

        facility_raw: None | str
        facility_raw = self.facility_raw

        has_hospital = self.has_hospital

        id: int | None | str
        id = self.id

        name = self.name

        netsuite_entity: None | str
        netsuite_entity = self.netsuite_entity

        updated_at: None | str
        if isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "active": active,
                "clinic_group": clinic_group,
                "code": code,
                "facility_raw": facility_raw,
                "has_hospital": has_hospital,
                "id": id,
                "name": name,
                "netsuite_entity": netsuite_entity,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        active = d.pop("active")

        def _parse_clinic_group(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        clinic_group = _parse_clinic_group(d.pop("clinic_group"))

        def _parse_code(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        code = _parse_code(d.pop("code"))

        def _parse_facility_raw(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        facility_raw = _parse_facility_raw(d.pop("facility_raw"))

        has_hospital = d.pop("has_hospital")

        def _parse_id(data: object) -> int | None | str:
            if data is None:
                return data
            return cast(int | None | str, data)

        id = _parse_id(d.pop("id"))

        name = d.pop("name")

        def _parse_netsuite_entity(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        netsuite_entity = _parse_netsuite_entity(d.pop("netsuite_entity"))

        def _parse_updated_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = datetime.datetime.fromisoformat(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        updated_at = _parse_updated_at(d.pop("updated_at"))

        location_mapping_v3 = cls(
            active=active,
            clinic_group=clinic_group,
            code=code,
            facility_raw=facility_raw,
            has_hospital=has_hospital,
            id=id,
            name=name,
            netsuite_entity=netsuite_entity,
            updated_at=updated_at,
        )

        location_mapping_v3.additional_properties = d
        return location_mapping_v3

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
