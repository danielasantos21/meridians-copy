from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="UsageIpV3")


@_attrs_define
class UsageIpV3:
    """An address the client called from inside the window.

    Attributes:
        ip (str):
        last_seen (datetime.datetime):
        requests (int):
    """

    ip: str
    last_seen: datetime.datetime
    requests: int

    def to_dict(self) -> dict[str, Any]:
        ip = self.ip

        last_seen = self.last_seen.isoformat()

        requests = self.requests

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ip": ip,
                "last_seen": last_seen,
                "requests": requests,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        ip = d.pop("ip")

        last_seen = datetime.datetime.fromisoformat(d.pop("last_seen"))

        requests = d.pop("requests")

        usage_ip_v3 = cls(
            ip=ip,
            last_seen=last_seen,
            requests=requests,
        )

        return usage_ip_v3
