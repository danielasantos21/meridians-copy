from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.artifact_v3 import ArtifactV3


T = TypeVar("T", bound="ArtifactsV3")


@_attrs_define
class ArtifactsV3:
    """
    Attributes:
        data (list[ArtifactV3]):
    """

    data: list[ArtifactV3]

    def to_dict(self) -> dict[str, Any]:
        data = []
        for data_item_data in self.data:
            data_item = data_item_data.to_dict()
            data.append(data_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "data": data,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.artifact_v3 import ArtifactV3

        d = dict(src_dict)
        data = []
        _data = d.pop("data")
        for data_item_data in _data:
            data_item = ArtifactV3.from_dict(data_item_data)

            data.append(data_item)

        artifacts_v3 = cls(
            data=data,
        )

        return artifacts_v3
