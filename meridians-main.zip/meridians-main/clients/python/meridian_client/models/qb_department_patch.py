from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="QbDepartmentPatch")


@_attrs_define
class QbDepartmentPatch:
    """
    Attributes:
        active (bool | None | Unset):
        ns_department (None | str | Unset):
        qb_class (None | str | Unset):
    """

    active: bool | None | Unset = UNSET
    ns_department: None | str | Unset = UNSET
    qb_class: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        active: bool | None | Unset
        if isinstance(self.active, Unset):
            active = UNSET
        else:
            active = self.active

        ns_department: None | str | Unset
        if isinstance(self.ns_department, Unset):
            ns_department = UNSET
        else:
            ns_department = self.ns_department

        qb_class: None | str | Unset
        if isinstance(self.qb_class, Unset):
            qb_class = UNSET
        else:
            qb_class = self.qb_class

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if active is not UNSET:
            field_dict["active"] = active
        if ns_department is not UNSET:
            field_dict["ns_department"] = ns_department
        if qb_class is not UNSET:
            field_dict["qb_class"] = qb_class

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        active = _parse_active(d.pop("active", UNSET))

        def _parse_ns_department(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ns_department = _parse_ns_department(d.pop("ns_department", UNSET))

        def _parse_qb_class(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        qb_class = _parse_qb_class(d.pop("qb_class", UNSET))

        qb_department_patch = cls(
            active=active,
            ns_department=ns_department,
            qb_class=qb_class,
        )

        return qb_department_patch
