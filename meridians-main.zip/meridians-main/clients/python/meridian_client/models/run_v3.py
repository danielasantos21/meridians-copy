from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="RunV3")


@_attrs_define
class RunV3:
    """A plain `process_runs` read. Nothing a Phase 11 run store would change
    (params, run_state, artifacts, actions) is here: those are AFTER-P11.

        Attributes:
            batch_id (int | None):
            completed_at (datetime.datetime | None):
            created_at (datetime.datetime | None):
            created_by (None | str):
            fiscal_year (int | None):
            input_file (None | str):
            is_test (bool):  Default: False.
            period (int | None):
            process (str):
            run_id (str):
            state (str):
            step (None | str):
            superseded_by_run_id (None | str):
            updated_at (datetime.datetime | None):
    """

    batch_id: int | None
    completed_at: datetime.datetime | None
    created_at: datetime.datetime | None
    created_by: None | str
    fiscal_year: int | None
    input_file: None | str
    period: int | None
    process: str
    run_id: str
    state: str
    step: None | str
    superseded_by_run_id: None | str
    updated_at: datetime.datetime | None
    is_test: bool = False

    def to_dict(self) -> dict[str, Any]:
        batch_id: int | None
        batch_id = self.batch_id

        completed_at: None | str
        if isinstance(self.completed_at, datetime.datetime):
            completed_at = self.completed_at.isoformat()
        else:
            completed_at = self.completed_at

        created_at: None | str
        if isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        created_by: None | str
        created_by = self.created_by

        fiscal_year: int | None
        fiscal_year = self.fiscal_year

        input_file: None | str
        input_file = self.input_file

        is_test = self.is_test

        period: int | None
        period = self.period

        process = self.process

        run_id = self.run_id

        state = self.state

        step: None | str
        step = self.step

        superseded_by_run_id: None | str
        superseded_by_run_id = self.superseded_by_run_id

        updated_at: None | str
        if isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "batch_id": batch_id,
                "completed_at": completed_at,
                "created_at": created_at,
                "created_by": created_by,
                "fiscal_year": fiscal_year,
                "input_file": input_file,
                "is_test": is_test,
                "period": period,
                "process": process,
                "run_id": run_id,
                "state": state,
                "step": step,
                "superseded_by_run_id": superseded_by_run_id,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_batch_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        batch_id = _parse_batch_id(d.pop("batch_id"))

        def _parse_completed_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                completed_at_type_0 = datetime.datetime.fromisoformat(data)

                return completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        completed_at = _parse_completed_at(d.pop("completed_at"))

        def _parse_created_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = datetime.datetime.fromisoformat(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        created_at = _parse_created_at(d.pop("created_at"))

        def _parse_created_by(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        created_by = _parse_created_by(d.pop("created_by"))

        def _parse_fiscal_year(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year"))

        def _parse_input_file(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        input_file = _parse_input_file(d.pop("input_file"))

        is_test = d.pop("is_test")

        def _parse_period(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        period = _parse_period(d.pop("period"))

        process = d.pop("process")

        run_id = d.pop("run_id")

        state = d.pop("state")

        def _parse_step(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        step = _parse_step(d.pop("step"))

        def _parse_superseded_by_run_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        superseded_by_run_id = _parse_superseded_by_run_id(
            d.pop("superseded_by_run_id")
        )

        def _parse_updated_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = datetime.datetime.fromisoformat(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        updated_at = _parse_updated_at(d.pop("updated_at"))

        run_v3 = cls(
            batch_id=batch_id,
            completed_at=completed_at,
            created_at=created_at,
            created_by=created_by,
            fiscal_year=fiscal_year,
            input_file=input_file,
            is_test=is_test,
            period=period,
            process=process,
            run_id=run_id,
            state=state,
            step=step,
            superseded_by_run_id=superseded_by_run_id,
            updated_at=updated_at,
        )

        return run_v3
