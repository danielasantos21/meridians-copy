from enum import StrEnum


class ArtifactV3Kind(StrEnum):
    BUNDLE = "bundle"
    DATA = "data"
    JOURNAL_ENTRY = "journal_entry"
    REPORT = "report"
    WORKBOOK = "workbook"

    def __str__(self) -> str:
        return str(self.value)
