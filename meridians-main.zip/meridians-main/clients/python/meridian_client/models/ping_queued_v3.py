from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="PingQueuedV3")


@_attrs_define
class PingQueuedV3:
    """
    Attributes:
        delivery_id (str):
        event_id (str):
    """

    delivery_id: str
    event_id: str

    def to_dict(self) -> dict[str, Any]:
        delivery_id = self.delivery_id

        event_id = self.event_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "delivery_id": delivery_id,
                "event_id": event_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        delivery_id = d.pop("delivery_id")

        event_id = d.pop("event_id")

        ping_queued_v3 = cls(
            delivery_id=delivery_id,
            event_id=event_id,
        )

        return ping_queued_v3
