from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="LocationMappingPatch")


@_attrs_define
class LocationMappingPatch:
    """
    Attributes:
        active (bool | None | Unset):
        clinic_group (None | str | Unset):
        facility_raw (None | str | Unset):
        location_code (None | str | Unset):
        location_name (None | str | Unset):
    """

    active: bool | None | Unset = UNSET
    clinic_group: None | str | Unset = UNSET
    facility_raw: None | str | Unset = UNSET
    location_code: None | str | Unset = UNSET
    location_name: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        active: bool | None | Unset
        if isinstance(self.active, Unset):
            active = UNSET
        else:
            active = self.active

        clinic_group: None | str | Unset
        if isinstance(self.clinic_group, Unset):
            clinic_group = UNSET
        else:
            clinic_group = self.clinic_group

        facility_raw: None | str | Unset
        if isinstance(self.facility_raw, Unset):
            facility_raw = UNSET
        else:
            facility_raw = self.facility_raw

        location_code: None | str | Unset
        if isinstance(self.location_code, Unset):
            location_code = UNSET
        else:
            location_code = self.location_code

        location_name: None | str | Unset
        if isinstance(self.location_name, Unset):
            location_name = UNSET
        else:
            location_name = self.location_name

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if active is not UNSET:
            field_dict["active"] = active
        if clinic_group is not UNSET:
            field_dict["clinic_group"] = clinic_group
        if facility_raw is not UNSET:
            field_dict["facility_raw"] = facility_raw
        if location_code is not UNSET:
            field_dict["location_code"] = location_code
        if location_name is not UNSET:
            field_dict["location_name"] = location_name

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        active = _parse_active(d.pop("active", UNSET))

        def _parse_clinic_group(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        clinic_group = _parse_clinic_group(d.pop("clinic_group", UNSET))

        def _parse_facility_raw(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        facility_raw = _parse_facility_raw(d.pop("facility_raw", UNSET))

        def _parse_location_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        location_code = _parse_location_code(d.pop("location_code", UNSET))

        def _parse_location_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        location_name = _parse_location_name(d.pop("location_name", UNSET))

        location_mapping_patch = cls(
            active=active,
            clinic_group=clinic_group,
            facility_raw=facility_raw,
            location_code=location_code,
            location_name=location_name,
        )

        return location_mapping_patch
