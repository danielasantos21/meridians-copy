from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

from ..models.qb_account_create_domain import QbAccountCreateDomain
from ..types import UNSET, Unset

T = TypeVar("T", bound="QbAccountCreate")


@_attrs_define
class QbAccountCreate:
    """
    Attributes:
        domain (QbAccountCreateDomain):
        ns_account (str):
        qb_account (str):
        is_standard (bool | Unset):  Default: False.
        sort_order (int | Unset):  Default: 0.
    """

    domain: QbAccountCreateDomain
    ns_account: str
    qb_account: str
    is_standard: bool | Unset = False
    sort_order: int | Unset = 0

    def to_dict(self) -> dict[str, Any]:
        domain = self.domain.value

        ns_account = self.ns_account

        qb_account = self.qb_account

        is_standard = self.is_standard

        sort_order = self.sort_order

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "domain": domain,
                "ns_account": ns_account,
                "qb_account": qb_account,
            }
        )
        if is_standard is not UNSET:
            field_dict["is_standard"] = is_standard
        if sort_order is not UNSET:
            field_dict["sort_order"] = sort_order

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        domain = QbAccountCreateDomain(d.pop("domain"))

        ns_account = d.pop("ns_account")

        qb_account = d.pop("qb_account")

        is_standard = d.pop("is_standard", UNSET)

        sort_order = d.pop("sort_order", UNSET)

        qb_account_create = cls(
            domain=domain,
            ns_account=ns_account,
            qb_account=qb_account,
            is_standard=is_standard,
            sort_order=sort_order,
        )

        return qb_account_create
