from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="ProviderMappingCreate")


@_attrs_define
class ProviderMappingCreate:
    """
    Attributes:
        department (str):
        provider_name (str):
        location_code (None | str | Unset):
    """

    department: str
    provider_name: str
    location_code: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        department = self.department

        provider_name = self.provider_name

        location_code: None | str | Unset
        if isinstance(self.location_code, Unset):
            location_code = UNSET
        else:
            location_code = self.location_code

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "department": department,
                "provider_name": provider_name,
            }
        )
        if location_code is not UNSET:
            field_dict["location_code"] = location_code

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        department = d.pop("department")

        provider_name = d.pop("provider_name")

        def _parse_location_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        location_code = _parse_location_code(d.pop("location_code", UNSET))

        provider_mapping_create = cls(
            department=department,
            provider_name=provider_name,
            location_code=location_code,
        )

        return provider_mapping_create
