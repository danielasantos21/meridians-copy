from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.mx_payroll_create_params import MxPayrollCreateParams


T = TypeVar("T", bound="MxPayrollCreateRunV3")


@_attrs_define
class MxPayrollCreateRunV3:
    """`POST /api/v3/processes/mx-payroll/runs` — the create params.

    Attributes:
        params (MxPayrollCreateParams | Unset): 3.3. Only the exchange rate.

            Period, year, the NRF day split and the provision date are all derived
            from the workbook — the sheet name or the title row. A run whose period
            cannot be read fails as `PERIOD_UNDETECTABLE` rather than being booked
            into a guessed month (12.5).

            A raw provider export is in pesos and carries no rate, so the user gives
            one (MXN per 1 USD); a raw file without it is refused.
    """

    params: MxPayrollCreateParams | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        params: dict[str, Any] | Unset = UNSET
        if not isinstance(self.params, Unset):
            params = self.params.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if params is not UNSET:
            field_dict["params"] = params

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.mx_payroll_create_params import (
            MxPayrollCreateParams,
        )

        d = dict(src_dict)
        _params = d.pop("params", UNSET)
        params: MxPayrollCreateParams | Unset
        if isinstance(_params, Unset):
            params = UNSET
        else:
            params = MxPayrollCreateParams.from_dict(_params)

        mx_payroll_create_run_v3 = cls(
            params=params,
        )

        return mx_payroll_create_run_v3
