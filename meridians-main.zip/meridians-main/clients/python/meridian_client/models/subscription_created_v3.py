from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="SubscriptionCreatedV3")


@_attrs_define
class SubscriptionCreatedV3:
    """
    Attributes:
        api_client_id (None | str):
        created_at (datetime.datetime | None):
        created_by (None | str):
        event_types (list[str]):
        failure_streak (int):
        id (str):
        secret (str):
        status (str):
        url (str):
    """

    api_client_id: None | str
    created_at: datetime.datetime | None
    created_by: None | str
    event_types: list[str]
    failure_streak: int
    id: str
    secret: str
    status: str
    url: str

    def to_dict(self) -> dict[str, Any]:
        api_client_id: None | str
        api_client_id = self.api_client_id

        created_at: None | str
        if isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        created_by: None | str
        created_by = self.created_by

        event_types = self.event_types

        failure_streak = self.failure_streak

        id = self.id

        secret = self.secret

        status = self.status

        url = self.url

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "api_client_id": api_client_id,
                "created_at": created_at,
                "created_by": created_by,
                "event_types": event_types,
                "failure_streak": failure_streak,
                "id": id,
                "secret": secret,
                "status": status,
                "url": url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_api_client_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        api_client_id = _parse_api_client_id(d.pop("api_client_id"))

        def _parse_created_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = datetime.datetime.fromisoformat(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        created_at = _parse_created_at(d.pop("created_at"))

        def _parse_created_by(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        created_by = _parse_created_by(d.pop("created_by"))

        event_types = cast(list[str], d.pop("event_types"))

        failure_streak = d.pop("failure_streak")

        id = d.pop("id")

        secret = d.pop("secret")

        status = d.pop("status")

        url = d.pop("url")

        subscription_created_v3 = cls(
            api_client_id=api_client_id,
            created_at=created_at,
            created_by=created_by,
            event_types=event_types,
            failure_streak=failure_streak,
            id=id,
            secret=secret,
            status=status,
            url=url,
        )

        return subscription_created_v3
