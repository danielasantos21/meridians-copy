from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="QbProviderCodeCreate")


@_attrs_define
class QbProviderCodeCreate:
    """
    Attributes:
        provider_code (str):
        provider_name (str):
    """

    provider_code: str
    provider_name: str

    def to_dict(self) -> dict[str, Any]:
        provider_code = self.provider_code

        provider_name = self.provider_name

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "provider_code": provider_code,
                "provider_name": provider_name,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        provider_code = d.pop("provider_code")

        provider_name = d.pop("provider_name")

        qb_provider_code_create = cls(
            provider_code=provider_code,
            provider_name=provider_name,
        )

        return qb_provider_code_create
