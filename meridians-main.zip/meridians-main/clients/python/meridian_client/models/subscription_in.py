from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

from ..models.subscription_in_event_types_item import SubscriptionInEventTypesItem

T = TypeVar("T", bound="SubscriptionIn")


@_attrs_define
class SubscriptionIn:
    """
    Attributes:
        event_types (list[SubscriptionInEventTypesItem]):
        url (str):
    """

    event_types: list[SubscriptionInEventTypesItem]
    url: str

    def to_dict(self) -> dict[str, Any]:
        event_types = []
        for event_types_item_data in self.event_types:
            event_types_item = event_types_item_data.value
            event_types.append(event_types_item)

        url = self.url

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "event_types": event_types,
                "url": url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        event_types = []
        _event_types = d.pop("event_types")
        for event_types_item_data in _event_types:
            event_types_item = SubscriptionInEventTypesItem(event_types_item_data)

            event_types.append(event_types_item)

        url = d.pop("url")

        subscription_in = cls(
            event_types=event_types,
            url=url,
        )

        return subscription_in
