from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

T = TypeVar("T", bound="QbProviderCodeV3")


@_attrs_define
class QbProviderCodeV3:
    """
    Attributes:
        active (bool):  Default: True.
        end_date (None | str):
        id (int | None | str):
        provider_code (str):
        provider_name (str):
        start_date (None | str):
        updated_at (datetime.datetime | None):
    """

    end_date: None | str
    id: int | None | str
    provider_code: str
    provider_name: str
    start_date: None | str
    updated_at: datetime.datetime | None
    active: bool = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        active = self.active

        end_date: None | str
        end_date = self.end_date

        id: int | None | str
        id = self.id

        provider_code = self.provider_code

        provider_name = self.provider_name

        start_date: None | str
        start_date = self.start_date

        updated_at: None | str
        if isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "active": active,
                "end_date": end_date,
                "id": id,
                "provider_code": provider_code,
                "provider_name": provider_name,
                "start_date": start_date,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        active = d.pop("active")

        def _parse_end_date(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        end_date = _parse_end_date(d.pop("end_date"))

        def _parse_id(data: object) -> int | None | str:
            if data is None:
                return data
            return cast(int | None | str, data)

        id = _parse_id(d.pop("id"))

        provider_code = d.pop("provider_code")

        provider_name = d.pop("provider_name")

        def _parse_start_date(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        start_date = _parse_start_date(d.pop("start_date"))

        def _parse_updated_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = datetime.datetime.fromisoformat(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        updated_at = _parse_updated_at(d.pop("updated_at"))

        qb_provider_code_v3 = cls(
            active=active,
            end_date=end_date,
            id=id,
            provider_code=provider_code,
            provider_name=provider_name,
            start_date=start_date,
            updated_at=updated_at,
        )

        qb_provider_code_v3.additional_properties = d
        return qb_provider_code_v3

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
