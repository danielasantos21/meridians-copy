from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="DeliveryV3")


@_attrs_define
class DeliveryV3:
    """
    Attributes:
        attempt (int):
        created_at (datetime.datetime | None):
        delivered_at (datetime.datetime | None):
        event_id (str):
        event_type (str):
        id (str):
        last_attempt_at (datetime.datetime | None):
        last_error_code (None | str):
        last_status_code (int | None):
        next_attempt_at (datetime.datetime | None):
        status (str):
        subscription_id (str):
    """

    attempt: int
    created_at: datetime.datetime | None
    delivered_at: datetime.datetime | None
    event_id: str
    event_type: str
    id: str
    last_attempt_at: datetime.datetime | None
    last_error_code: None | str
    last_status_code: int | None
    next_attempt_at: datetime.datetime | None
    status: str
    subscription_id: str

    def to_dict(self) -> dict[str, Any]:
        attempt = self.attempt

        created_at: None | str
        if isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        delivered_at: None | str
        if isinstance(self.delivered_at, datetime.datetime):
            delivered_at = self.delivered_at.isoformat()
        else:
            delivered_at = self.delivered_at

        event_id = self.event_id

        event_type = self.event_type

        id = self.id

        last_attempt_at: None | str
        if isinstance(self.last_attempt_at, datetime.datetime):
            last_attempt_at = self.last_attempt_at.isoformat()
        else:
            last_attempt_at = self.last_attempt_at

        last_error_code: None | str
        last_error_code = self.last_error_code

        last_status_code: int | None
        last_status_code = self.last_status_code

        next_attempt_at: None | str
        if isinstance(self.next_attempt_at, datetime.datetime):
            next_attempt_at = self.next_attempt_at.isoformat()
        else:
            next_attempt_at = self.next_attempt_at

        status = self.status

        subscription_id = self.subscription_id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "attempt": attempt,
                "created_at": created_at,
                "delivered_at": delivered_at,
                "event_id": event_id,
                "event_type": event_type,
                "id": id,
                "last_attempt_at": last_attempt_at,
                "last_error_code": last_error_code,
                "last_status_code": last_status_code,
                "next_attempt_at": next_attempt_at,
                "status": status,
                "subscription_id": subscription_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        attempt = d.pop("attempt")

        def _parse_created_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = datetime.datetime.fromisoformat(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        created_at = _parse_created_at(d.pop("created_at"))

        def _parse_delivered_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                delivered_at_type_0 = datetime.datetime.fromisoformat(data)

                return delivered_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        delivered_at = _parse_delivered_at(d.pop("delivered_at"))

        event_id = d.pop("event_id")

        event_type = d.pop("event_type")

        id = d.pop("id")

        def _parse_last_attempt_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_attempt_at_type_0 = datetime.datetime.fromisoformat(data)

                return last_attempt_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_attempt_at = _parse_last_attempt_at(d.pop("last_attempt_at"))

        def _parse_last_error_code(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        last_error_code = _parse_last_error_code(d.pop("last_error_code"))

        def _parse_last_status_code(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        last_status_code = _parse_last_status_code(d.pop("last_status_code"))

        def _parse_next_attempt_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                next_attempt_at_type_0 = datetime.datetime.fromisoformat(data)

                return next_attempt_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        next_attempt_at = _parse_next_attempt_at(d.pop("next_attempt_at"))

        status = d.pop("status")

        subscription_id = d.pop("subscription_id")

        delivery_v3 = cls(
            attempt=attempt,
            created_at=created_at,
            delivered_at=delivered_at,
            event_id=event_id,
            event_type=event_type,
            id=id,
            last_attempt_at=last_attempt_at,
            last_error_code=last_error_code,
            last_status_code=last_status_code,
            next_attempt_at=next_attempt_at,
            status=status,
            subscription_id=subscription_id,
        )

        return delivery_v3
