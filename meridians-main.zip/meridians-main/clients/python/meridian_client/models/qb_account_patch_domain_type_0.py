from enum import StrEnum


class QbAccountPatchDomainType0(StrEnum):
    PAYROLL = "payroll"
    REVENUE = "revenue"

    def __str__(self) -> str:
        return str(self.value)
