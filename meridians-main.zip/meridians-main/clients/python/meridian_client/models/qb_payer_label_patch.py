from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="QbPayerLabelPatch")


@_attrs_define
class QbPayerLabelPatch:
    """
    Attributes:
        active (bool | None | Unset):
        label (None | str | Unset):
        payer_type (None | str | Unset):
    """

    active: bool | None | Unset = UNSET
    label: None | str | Unset = UNSET
    payer_type: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        active: bool | None | Unset
        if isinstance(self.active, Unset):
            active = UNSET
        else:
            active = self.active

        label: None | str | Unset
        if isinstance(self.label, Unset):
            label = UNSET
        else:
            label = self.label

        payer_type: None | str | Unset
        if isinstance(self.payer_type, Unset):
            payer_type = UNSET
        else:
            payer_type = self.payer_type

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if active is not UNSET:
            field_dict["active"] = active
        if label is not UNSET:
            field_dict["label"] = label
        if payer_type is not UNSET:
            field_dict["payer_type"] = payer_type

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        active = _parse_active(d.pop("active", UNSET))

        def _parse_label(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        label = _parse_label(d.pop("label", UNSET))

        def _parse_payer_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        payer_type = _parse_payer_type(d.pop("payer_type", UNSET))

        qb_payer_label_patch = cls(
            active=active,
            label=label,
            payer_type=payer_type,
        )

        return qb_payer_label_patch
