from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.qb_revenue_create_params_bank_deposits import (
        QbRevenueCreateParamsBankDeposits,
    )


T = TypeVar("T", bound="QbRevenueCreateParams")


@_attrs_define
class QbRevenueCreateParams:
    """3.3. The JSON `params` part of the create multipart.

    `period` and `fiscal_year` are nullable because null IS today's `'auto'`
    (12.5): the processor derives both from the transaction dates when they
    are not given, and forcing a period into the request for a process that
    legitimately does not know one yet would make the SPA guess.

    They are whole numbers here and `P07` / `FY26` inside the processor. The
    conversion happens once, at the HTTP edge (`src/utils.format_period`), so
    the typed API never leaks the string form and the processor never sees a
    pydantic model (10.1).

        Attributes:
            bank_deposits (QbRevenueCreateParamsBankDeposits | Unset):
            fiscal_year (int | None | Unset):
            generate_unposted (bool | Unset):  Default: False.
            je_date (None | str | Unset):
            period (int | None | Unset):
    """

    bank_deposits: QbRevenueCreateParamsBankDeposits | Unset = UNSET
    fiscal_year: int | None | Unset = UNSET
    generate_unposted: bool | Unset = False
    je_date: None | str | Unset = UNSET
    period: int | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        bank_deposits: dict[str, Any] | Unset = UNSET
        if not isinstance(self.bank_deposits, Unset):
            bank_deposits = self.bank_deposits.to_dict()

        fiscal_year: int | None | Unset
        if isinstance(self.fiscal_year, Unset):
            fiscal_year = UNSET
        else:
            fiscal_year = self.fiscal_year

        generate_unposted = self.generate_unposted

        je_date: None | str | Unset
        if isinstance(self.je_date, Unset):
            je_date = UNSET
        else:
            je_date = self.je_date

        period: int | None | Unset
        if isinstance(self.period, Unset):
            period = UNSET
        else:
            period = self.period

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if bank_deposits is not UNSET:
            field_dict["bank_deposits"] = bank_deposits
        if fiscal_year is not UNSET:
            field_dict["fiscal_year"] = fiscal_year
        if generate_unposted is not UNSET:
            field_dict["generate_unposted"] = generate_unposted
        if je_date is not UNSET:
            field_dict["je_date"] = je_date
        if period is not UNSET:
            field_dict["period"] = period

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.qb_revenue_create_params_bank_deposits import (
            QbRevenueCreateParamsBankDeposits,
        )

        d = dict(src_dict)
        _bank_deposits = d.pop("bank_deposits", UNSET)
        bank_deposits: QbRevenueCreateParamsBankDeposits | Unset
        if isinstance(_bank_deposits, Unset):
            bank_deposits = UNSET
        else:
            bank_deposits = QbRevenueCreateParamsBankDeposits.from_dict(_bank_deposits)

        def _parse_fiscal_year(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year", UNSET))

        generate_unposted = d.pop("generate_unposted", UNSET)

        def _parse_je_date(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        je_date = _parse_je_date(d.pop("je_date", UNSET))

        def _parse_period(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        period = _parse_period(d.pop("period", UNSET))

        qb_revenue_create_params = cls(
            bank_deposits=bank_deposits,
            fiscal_year=fiscal_year,
            generate_unposted=generate_unposted,
            je_date=je_date,
            period=period,
        )

        return qb_revenue_create_params
