from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.upload_grant_v3_fields import UploadGrantV3Fields


T = TypeVar("T", bound="UploadGrantV3")


@_attrs_define
class UploadGrantV3:
    """A pre-signed S3 POST: send `fields` plus the file (as `file`, last) to `url`.

    Expires at `expires_at`. The object is scanned for malware on arrival;
    the run's `execute` answers `FILE_SCAN_PENDING` (409) until it is clean.

        Attributes:
            content_type (str):
            expires_at (datetime.datetime):
            fields (UploadGrantV3Fields):
            max_bytes (int):
            method (str):  Default: 'POST'.
            role (str):
            run_id (str):
            upload_id (str):
            url (str):
    """

    content_type: str
    expires_at: datetime.datetime
    fields: UploadGrantV3Fields
    max_bytes: int
    role: str
    run_id: str
    upload_id: str
    url: str
    method: str = "POST"

    def to_dict(self) -> dict[str, Any]:
        content_type = self.content_type

        expires_at = self.expires_at.isoformat()

        fields = self.fields.to_dict()

        max_bytes = self.max_bytes

        method = self.method

        role = self.role

        run_id = self.run_id

        upload_id = self.upload_id

        url = self.url

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "content_type": content_type,
                "expires_at": expires_at,
                "fields": fields,
                "max_bytes": max_bytes,
                "method": method,
                "role": role,
                "run_id": run_id,
                "upload_id": upload_id,
                "url": url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.upload_grant_v3_fields import UploadGrantV3Fields

        d = dict(src_dict)
        content_type = d.pop("content_type")

        expires_at = datetime.datetime.fromisoformat(d.pop("expires_at"))

        fields = UploadGrantV3Fields.from_dict(d.pop("fields"))

        max_bytes = d.pop("max_bytes")

        method = d.pop("method")

        role = d.pop("role")

        run_id = d.pop("run_id")

        upload_id = d.pop("upload_id")

        url = d.pop("url")

        upload_grant_v3 = cls(
            content_type=content_type,
            expires_at=expires_at,
            fields=fields,
            max_bytes=max_bytes,
            method=method,
            role=role,
            run_id=run_id,
            upload_id=upload_id,
            url=url,
        )

        return upload_grant_v3
