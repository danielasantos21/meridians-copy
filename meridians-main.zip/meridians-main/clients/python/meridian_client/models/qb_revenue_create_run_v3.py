from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.qb_revenue_create_params import QbRevenueCreateParams


T = TypeVar("T", bound="QbRevenueCreateRunV3")


@_attrs_define
class QbRevenueCreateRunV3:
    """`POST /api/v3/processes/qb-revenue/runs` — the create params.

    Attributes:
        params (QbRevenueCreateParams | Unset): 3.3. The JSON `params` part of the create multipart.

            `period` and `fiscal_year` are nullable because null IS today's `'auto'`
            (12.5): the processor derives both from the transaction dates when they
            are not given, and forcing a period into the request for a process that
            legitimately does not know one yet would make the SPA guess.

            They are whole numbers here and `P07` / `FY26` inside the processor. The
            conversion happens once, at the HTTP edge (`src/utils.format_period`), so
            the typed API never leaks the string form and the processor never sees a
            pydantic model (10.1).
    """

    params: QbRevenueCreateParams | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        params: dict[str, Any] | Unset = UNSET
        if not isinstance(self.params, Unset):
            params = self.params.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if params is not UNSET:
            field_dict["params"] = params

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.qb_revenue_create_params import (
            QbRevenueCreateParams,
        )

        d = dict(src_dict)
        _params = d.pop("params", UNSET)
        params: QbRevenueCreateParams | Unset
        if isinstance(_params, Unset):
            params = UNSET
        else:
            params = QbRevenueCreateParams.from_dict(_params)

        qb_revenue_create_run_v3 = cls(
            params=params,
        )

        return qb_revenue_create_run_v3
