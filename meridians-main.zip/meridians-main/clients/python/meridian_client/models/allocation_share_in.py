from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="AllocationShareIn")


@_attrs_define
class AllocationShareIn:
    """
    Attributes:
        location_code (str):
        percentage (float):
    """

    location_code: str
    percentage: float

    def to_dict(self) -> dict[str, Any]:
        location_code = self.location_code

        percentage = self.percentage

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "location_code": location_code,
                "percentage": percentage,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        location_code = d.pop("location_code")

        percentage = d.pop("percentage")

        allocation_share_in = cls(
            location_code=location_code,
            percentage=percentage,
        )

        return allocation_share_in
