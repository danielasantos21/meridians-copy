from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.allocation_share_in import AllocationShareIn


T = TypeVar("T", bound="AllocationIn")


@_attrs_define
class AllocationIn:
    """`PUT /api/v3/allocations` — replace one employee's whole split.

    The employee is named in the BODY, never the URL: a name is PII and the
    URL is logged by every proxy on the way (§3.1 rule 5).

        Attributes:
            allocations (list[AllocationShareIn]):
            employee_name (str):
            entity (None | str | Unset):
            file_number (None | str | Unset):
            job_category (None | str | Unset):
            pay_type (None | str | Unset):
            subsidiary (None | str | Unset):
    """

    allocations: list[AllocationShareIn]
    employee_name: str
    entity: None | str | Unset = UNSET
    file_number: None | str | Unset = UNSET
    job_category: None | str | Unset = UNSET
    pay_type: None | str | Unset = UNSET
    subsidiary: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        allocations = []
        for allocations_item_data in self.allocations:
            allocations_item = allocations_item_data.to_dict()
            allocations.append(allocations_item)

        employee_name = self.employee_name

        entity: None | str | Unset
        if isinstance(self.entity, Unset):
            entity = UNSET
        else:
            entity = self.entity

        file_number: None | str | Unset
        if isinstance(self.file_number, Unset):
            file_number = UNSET
        else:
            file_number = self.file_number

        job_category: None | str | Unset
        if isinstance(self.job_category, Unset):
            job_category = UNSET
        else:
            job_category = self.job_category

        pay_type: None | str | Unset
        if isinstance(self.pay_type, Unset):
            pay_type = UNSET
        else:
            pay_type = self.pay_type

        subsidiary: None | str | Unset
        if isinstance(self.subsidiary, Unset):
            subsidiary = UNSET
        else:
            subsidiary = self.subsidiary

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "allocations": allocations,
                "employee_name": employee_name,
            }
        )
        if entity is not UNSET:
            field_dict["entity"] = entity
        if file_number is not UNSET:
            field_dict["file_number"] = file_number
        if job_category is not UNSET:
            field_dict["job_category"] = job_category
        if pay_type is not UNSET:
            field_dict["pay_type"] = pay_type
        if subsidiary is not UNSET:
            field_dict["subsidiary"] = subsidiary

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.allocation_share_in import AllocationShareIn

        d = dict(src_dict)
        allocations = []
        _allocations = d.pop("allocations")
        for allocations_item_data in _allocations:
            allocations_item = AllocationShareIn.from_dict(allocations_item_data)

            allocations.append(allocations_item)

        employee_name = d.pop("employee_name")

        def _parse_entity(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        entity = _parse_entity(d.pop("entity", UNSET))

        def _parse_file_number(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_number = _parse_file_number(d.pop("file_number", UNSET))

        def _parse_job_category(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        job_category = _parse_job_category(d.pop("job_category", UNSET))

        def _parse_pay_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        pay_type = _parse_pay_type(d.pop("pay_type", UNSET))

        def _parse_subsidiary(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        subsidiary = _parse_subsidiary(d.pop("subsidiary", UNSET))

        allocation_in = cls(
            allocations=allocations,
            employee_name=employee_name,
            entity=entity,
            file_number=file_number,
            job_category=job_category,
            pay_type=pay_type,
            subsidiary=subsidiary,
        )

        return allocation_in
