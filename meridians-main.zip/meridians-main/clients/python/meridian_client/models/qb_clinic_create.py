from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="QbClinicCreate")


@_attrs_define
class QbClinicCreate:
    """
    Attributes:
        location_name (str):
        qb_clinic (str):
        service_line (str | Unset):  Default: ''.
    """

    location_name: str
    qb_clinic: str
    service_line: str | Unset = ""

    def to_dict(self) -> dict[str, Any]:
        location_name = self.location_name

        qb_clinic = self.qb_clinic

        service_line = self.service_line

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "location_name": location_name,
                "qb_clinic": qb_clinic,
            }
        )
        if service_line is not UNSET:
            field_dict["service_line"] = service_line

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        location_name = d.pop("location_name")

        qb_clinic = d.pop("qb_clinic")

        service_line = d.pop("service_line", UNSET)

        qb_clinic_create = cls(
            location_name=location_name,
            qb_clinic=qb_clinic,
            service_line=service_line,
        )

        return qb_clinic_create
