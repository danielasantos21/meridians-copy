from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..models.artifact_v3_kind import ArtifactV3Kind

T = TypeVar("T", bound="ArtifactV3")


@_attrs_define
class ArtifactV3:
    """One file a run produced. `phi` ones are listed only to `phi:read`.

    Attributes:
        artifact_id (str):
        balanced (bool | None):
        content_type (None | str):
        journal_no (None | str):
        kind (ArtifactV3Kind):
        label (None | str):
        line_count (int | None):
        name (str):
        phi (bool):  Default: False.
        size_bytes (int | None):
        subfolder (str):
        total (None | str):
    """

    artifact_id: str
    balanced: bool | None
    content_type: None | str
    journal_no: None | str
    kind: ArtifactV3Kind
    label: None | str
    line_count: int | None
    name: str
    size_bytes: int | None
    subfolder: str
    total: None | str
    phi: bool = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        artifact_id = self.artifact_id

        balanced: bool | None
        balanced = self.balanced

        content_type: None | str
        content_type = self.content_type

        journal_no: None | str
        journal_no = self.journal_no

        kind = self.kind.value

        label: None | str
        label = self.label

        line_count: int | None
        line_count = self.line_count

        name = self.name

        phi = self.phi

        size_bytes: int | None
        size_bytes = self.size_bytes

        subfolder = self.subfolder

        total: None | str
        total = self.total

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "artifact_id": artifact_id,
                "balanced": balanced,
                "content_type": content_type,
                "journal_no": journal_no,
                "kind": kind,
                "label": label,
                "line_count": line_count,
                "name": name,
                "phi": phi,
                "size_bytes": size_bytes,
                "subfolder": subfolder,
                "total": total,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        artifact_id = d.pop("artifact_id")

        def _parse_balanced(data: object) -> bool | None:
            if data is None:
                return data
            return cast(bool | None, data)

        balanced = _parse_balanced(d.pop("balanced"))

        def _parse_content_type(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        content_type = _parse_content_type(d.pop("content_type"))

        def _parse_journal_no(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        journal_no = _parse_journal_no(d.pop("journal_no"))

        kind = ArtifactV3Kind(d.pop("kind"))

        def _parse_label(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        label = _parse_label(d.pop("label"))

        def _parse_line_count(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        line_count = _parse_line_count(d.pop("line_count"))

        name = d.pop("name")

        phi = d.pop("phi")

        def _parse_size_bytes(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        size_bytes = _parse_size_bytes(d.pop("size_bytes"))

        subfolder = d.pop("subfolder")

        def _parse_total(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        total = _parse_total(d.pop("total"))

        artifact_v3 = cls(
            artifact_id=artifact_id,
            balanced=balanced,
            content_type=content_type,
            journal_no=journal_no,
            kind=kind,
            label=label,
            line_count=line_count,
            name=name,
            phi=phi,
            size_bytes=size_bytes,
            subfolder=subfolder,
            total=total,
        )

        artifact_v3.additional_properties = d
        return artifact_v3

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
