from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..models.qb_account_patch_domain_type_0 import QbAccountPatchDomainType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="QbAccountPatch")


@_attrs_define
class QbAccountPatch:
    """
    Attributes:
        active (bool | None | Unset):
        domain (None | QbAccountPatchDomainType0 | Unset):
        is_standard (bool | None | Unset):
        ns_account (None | str | Unset):
        qb_account (None | str | Unset):
        sort_order (int | None | Unset):
    """

    active: bool | None | Unset = UNSET
    domain: None | QbAccountPatchDomainType0 | Unset = UNSET
    is_standard: bool | None | Unset = UNSET
    ns_account: None | str | Unset = UNSET
    qb_account: None | str | Unset = UNSET
    sort_order: int | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        active: bool | None | Unset
        if isinstance(self.active, Unset):
            active = UNSET
        else:
            active = self.active

        domain: None | str | Unset
        if isinstance(self.domain, Unset):
            domain = UNSET
        elif isinstance(self.domain, QbAccountPatchDomainType0):
            domain = self.domain.value
        else:
            domain = self.domain

        is_standard: bool | None | Unset
        if isinstance(self.is_standard, Unset):
            is_standard = UNSET
        else:
            is_standard = self.is_standard

        ns_account: None | str | Unset
        if isinstance(self.ns_account, Unset):
            ns_account = UNSET
        else:
            ns_account = self.ns_account

        qb_account: None | str | Unset
        if isinstance(self.qb_account, Unset):
            qb_account = UNSET
        else:
            qb_account = self.qb_account

        sort_order: int | None | Unset
        if isinstance(self.sort_order, Unset):
            sort_order = UNSET
        else:
            sort_order = self.sort_order

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if active is not UNSET:
            field_dict["active"] = active
        if domain is not UNSET:
            field_dict["domain"] = domain
        if is_standard is not UNSET:
            field_dict["is_standard"] = is_standard
        if ns_account is not UNSET:
            field_dict["ns_account"] = ns_account
        if qb_account is not UNSET:
            field_dict["qb_account"] = qb_account
        if sort_order is not UNSET:
            field_dict["sort_order"] = sort_order

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        active = _parse_active(d.pop("active", UNSET))

        def _parse_domain(data: object) -> None | QbAccountPatchDomainType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                domain_type_0 = QbAccountPatchDomainType0(data)

                return domain_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | QbAccountPatchDomainType0 | Unset, data)

        domain = _parse_domain(d.pop("domain", UNSET))

        def _parse_is_standard(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_standard = _parse_is_standard(d.pop("is_standard", UNSET))

        def _parse_ns_account(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ns_account = _parse_ns_account(d.pop("ns_account", UNSET))

        def _parse_qb_account(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        qb_account = _parse_qb_account(d.pop("qb_account", UNSET))

        def _parse_sort_order(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        sort_order = _parse_sort_order(d.pop("sort_order", UNSET))

        qb_account_patch = cls(
            active=active,
            domain=domain,
            is_standard=is_standard,
            ns_account=ns_account,
            qb_account=qb_account,
            sort_order=sort_order,
        )

        return qb_account_patch
