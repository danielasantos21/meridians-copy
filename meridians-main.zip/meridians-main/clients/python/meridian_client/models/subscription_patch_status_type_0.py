from enum import StrEnum


class SubscriptionPatchStatusType0(StrEnum):
    ACTIVE = "active"
    PAUSED = "paused"

    def __str__(self) -> str:
        return str(self.value)
