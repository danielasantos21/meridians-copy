from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="QbPayerLabelCreate")


@_attrs_define
class QbPayerLabelCreate:
    """
    Attributes:
        label (str):
        payer_type (str):
    """

    label: str
    payer_type: str

    def to_dict(self) -> dict[str, Any]:
        label = self.label

        payer_type = self.payer_type

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "label": label,
                "payer_type": payer_type,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        label = d.pop("label")

        payer_type = d.pop("payer_type")

        qb_payer_label_create = cls(
            label=label,
            payer_type=payer_type,
        )

        return qb_payer_label_create
