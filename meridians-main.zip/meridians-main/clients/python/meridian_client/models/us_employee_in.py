from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="UsEmployeeIn")


@_attrs_define
class UsEmployeeIn:
    """`PUT /api/v3/employees/{employee_id}?entity=us` — create or replace one row.

    Attributes:
        name (str):
        primary_location (str):
        active (bool | Unset):  Default: True.
        department (None | str | Unset):
    """

    name: str
    primary_location: str
    active: bool | Unset = True
    department: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        primary_location = self.primary_location

        active = self.active

        department: None | str | Unset
        if isinstance(self.department, Unset):
            department = UNSET
        else:
            department = self.department

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "name": name,
                "primary_location": primary_location,
            }
        )
        if active is not UNSET:
            field_dict["active"] = active
        if department is not UNSET:
            field_dict["department"] = department

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        name = d.pop("name")

        primary_location = d.pop("primary_location")

        active = d.pop("active", UNSET)

        def _parse_department(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        department = _parse_department(d.pop("department", UNSET))

        us_employee_in = cls(
            name=name,
            primary_location=primary_location,
            active=active,
            department=department,
        )

        return us_employee_in
