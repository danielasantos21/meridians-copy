from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.page_info import PageInfo
    from ..models.page_meta import PageMeta
    from ..models.subscription_v3 import SubscriptionV3


T = TypeVar("T", bound="PagedSubscriptionV3")


@_attrs_define
class PagedSubscriptionV3:
    """
    Attributes:
        data (list[SubscriptionV3]):
        meta (PageMeta):
        page (PageInfo):
    """

    data: list[SubscriptionV3]
    meta: PageMeta
    page: PageInfo

    def to_dict(self) -> dict[str, Any]:
        data = []
        for data_item_data in self.data:
            data_item = data_item_data.to_dict()
            data.append(data_item)

        meta = self.meta.to_dict()

        page = self.page.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "data": data,
                "meta": meta,
                "page": page,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.page_info import PageInfo
        from ..models.page_meta import PageMeta
        from ..models.subscription_v3 import SubscriptionV3

        d = dict(src_dict)
        data = []
        _data = d.pop("data")
        for data_item_data in _data:
            data_item = SubscriptionV3.from_dict(data_item_data)

            data.append(data_item)

        meta = PageMeta.from_dict(d.pop("meta"))

        page = PageInfo.from_dict(d.pop("page"))

        paged_subscription_v3 = cls(
            data=data,
            meta=meta,
            page=page,
        )

        return paged_subscription_v3
