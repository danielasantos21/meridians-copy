from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="UsageDayV3")


@_attrs_define
class UsageDayV3:
    """One UTC day of a client's calls (from `audit.api_request`).

    Attributes:
        day (datetime.date):
        errors (int):
        requests (int):
    """

    day: datetime.date
    errors: int
    requests: int

    def to_dict(self) -> dict[str, Any]:
        day = self.day.isoformat()

        errors = self.errors

        requests = self.requests

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "day": day,
                "errors": errors,
                "requests": requests,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        day = datetime.date.fromisoformat(d.pop("day"))

        errors = d.pop("errors")

        requests = d.pop("requests")

        usage_day_v3 = cls(
            day=day,
            errors=errors,
            requests=requests,
        )

        return usage_day_v3
