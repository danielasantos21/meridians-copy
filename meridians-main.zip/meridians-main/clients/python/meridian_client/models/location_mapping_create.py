from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="LocationMappingCreate")


@_attrs_define
class LocationMappingCreate:
    """
    Attributes:
        clinic_group (str):
        facility_raw (str):
        location_code (str):
        location_name (str):
    """

    clinic_group: str
    facility_raw: str
    location_code: str
    location_name: str

    def to_dict(self) -> dict[str, Any]:
        clinic_group = self.clinic_group

        facility_raw = self.facility_raw

        location_code = self.location_code

        location_name = self.location_name

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "clinic_group": clinic_group,
                "facility_raw": facility_raw,
                "location_code": location_code,
                "location_name": location_name,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        clinic_group = d.pop("clinic_group")

        facility_raw = d.pop("facility_raw")

        location_code = d.pop("location_code")

        location_name = d.pop("location_name")

        location_mapping_create = cls(
            clinic_group=clinic_group,
            facility_raw=facility_raw,
            location_code=location_code,
            location_name=location_name,
        )

        return location_mapping_create
