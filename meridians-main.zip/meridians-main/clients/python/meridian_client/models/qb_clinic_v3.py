from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

T = TypeVar("T", bound="QbClinicV3")


@_attrs_define
class QbClinicV3:
    """
    Attributes:
        active (bool):  Default: True.
        id (int | None | str):
        location_name (str):
        qb_clinic (str):
        service_line (str):  Default: ''.
        updated_at (datetime.datetime | None):
    """

    id: int | None | str
    location_name: str
    qb_clinic: str
    updated_at: datetime.datetime | None
    active: bool = True
    service_line: str = ""
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        active = self.active

        id: int | None | str
        id = self.id

        location_name = self.location_name

        qb_clinic = self.qb_clinic

        service_line = self.service_line

        updated_at: None | str
        if isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "active": active,
                "id": id,
                "location_name": location_name,
                "qb_clinic": qb_clinic,
                "service_line": service_line,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        active = d.pop("active")

        def _parse_id(data: object) -> int | None | str:
            if data is None:
                return data
            return cast(int | None | str, data)

        id = _parse_id(d.pop("id"))

        location_name = d.pop("location_name")

        qb_clinic = d.pop("qb_clinic")

        service_line = d.pop("service_line")

        def _parse_updated_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = datetime.datetime.fromisoformat(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        updated_at = _parse_updated_at(d.pop("updated_at"))

        qb_clinic_v3 = cls(
            active=active,
            id=id,
            location_name=location_name,
            qb_clinic=qb_clinic,
            service_line=service_line,
            updated_at=updated_at,
        )

        qb_clinic_v3.additional_properties = d
        return qb_clinic_v3

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
