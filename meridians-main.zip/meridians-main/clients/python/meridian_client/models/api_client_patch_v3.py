from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="ApiClientPatchV3")


@_attrs_define
class ApiClientPatchV3:
    """`PATCH /admin/api-clients/{id}`: only the fields given change.

    Attributes:
        ip_allowlist (list[str] | None | Unset):
        mtls_subject (None | str | Unset):
        name (None | str | Unset):
        partner_baa_id (None | Unset | UUID):
        processes (list[str] | None | Unset):
        reason (None | str | Unset):
        scopes (list[str] | None | Unset):
    """

    ip_allowlist: list[str] | None | Unset = UNSET
    mtls_subject: None | str | Unset = UNSET
    name: None | str | Unset = UNSET
    partner_baa_id: None | Unset | UUID = UNSET
    processes: list[str] | None | Unset = UNSET
    reason: None | str | Unset = UNSET
    scopes: list[str] | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        ip_allowlist: list[str] | None | Unset
        if isinstance(self.ip_allowlist, Unset):
            ip_allowlist = UNSET
        elif isinstance(self.ip_allowlist, list):
            ip_allowlist = self.ip_allowlist

        else:
            ip_allowlist = self.ip_allowlist

        mtls_subject: None | str | Unset
        if isinstance(self.mtls_subject, Unset):
            mtls_subject = UNSET
        else:
            mtls_subject = self.mtls_subject

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        partner_baa_id: None | str | Unset
        if isinstance(self.partner_baa_id, Unset):
            partner_baa_id = UNSET
        elif isinstance(self.partner_baa_id, UUID):
            partner_baa_id = str(self.partner_baa_id)
        else:
            partner_baa_id = self.partner_baa_id

        processes: list[str] | None | Unset
        if isinstance(self.processes, Unset):
            processes = UNSET
        elif isinstance(self.processes, list):
            processes = self.processes

        else:
            processes = self.processes

        reason: None | str | Unset
        if isinstance(self.reason, Unset):
            reason = UNSET
        else:
            reason = self.reason

        scopes: list[str] | None | Unset
        if isinstance(self.scopes, Unset):
            scopes = UNSET
        elif isinstance(self.scopes, list):
            scopes = self.scopes

        else:
            scopes = self.scopes

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if ip_allowlist is not UNSET:
            field_dict["ip_allowlist"] = ip_allowlist
        if mtls_subject is not UNSET:
            field_dict["mtls_subject"] = mtls_subject
        if name is not UNSET:
            field_dict["name"] = name
        if partner_baa_id is not UNSET:
            field_dict["partner_baa_id"] = partner_baa_id
        if processes is not UNSET:
            field_dict["processes"] = processes
        if reason is not UNSET:
            field_dict["reason"] = reason
        if scopes is not UNSET:
            field_dict["scopes"] = scopes

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_ip_allowlist(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                ip_allowlist_type_0 = cast(list[str], data)

                return ip_allowlist_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        ip_allowlist = _parse_ip_allowlist(d.pop("ip_allowlist", UNSET))

        def _parse_mtls_subject(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mtls_subject = _parse_mtls_subject(d.pop("mtls_subject", UNSET))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_partner_baa_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                partner_baa_id_type_0 = UUID(data)

                return partner_baa_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        partner_baa_id = _parse_partner_baa_id(d.pop("partner_baa_id", UNSET))

        def _parse_processes(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                processes_type_0 = cast(list[str], data)

                return processes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        processes = _parse_processes(d.pop("processes", UNSET))

        def _parse_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reason = _parse_reason(d.pop("reason", UNSET))

        def _parse_scopes(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                scopes_type_0 = cast(list[str], data)

                return scopes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        scopes = _parse_scopes(d.pop("scopes", UNSET))

        api_client_patch_v3 = cls(
            ip_allowlist=ip_allowlist,
            mtls_subject=mtls_subject,
            name=name,
            partner_baa_id=partner_baa_id,
            processes=processes,
            reason=reason,
            scopes=scopes,
        )

        return api_client_patch_v3
