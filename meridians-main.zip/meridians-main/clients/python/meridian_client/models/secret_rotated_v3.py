from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="SecretRotatedV3")


@_attrs_define
class SecretRotatedV3:
    """
    Attributes:
        id (str):
        previous_valid_until (datetime.datetime):
        secret (str):
    """

    id: str
    previous_valid_until: datetime.datetime
    secret: str

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        previous_valid_until = self.previous_valid_until.isoformat()

        secret = self.secret

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "previous_valid_until": previous_valid_until,
                "secret": secret,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        id = d.pop("id")

        previous_valid_until = datetime.datetime.fromisoformat(
            d.pop("previous_valid_until")
        )

        secret = d.pop("secret")

        secret_rotated_v3 = cls(
            id=id,
            previous_valid_until=previous_valid_until,
            secret=secret,
        )

        return secret_rotated_v3
