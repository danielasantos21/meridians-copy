from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="HealthV3")


@_attrs_define
class HealthV3:
    """
    Attributes:
        database (str):
        status (str):
        version (str):
    """

    database: str
    status: str
    version: str

    def to_dict(self) -> dict[str, Any]:
        database = self.database

        status = self.status

        version = self.version

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "database": database,
                "status": status,
                "version": version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        database = d.pop("database")

        status = d.pop("status")

        version = d.pop("version")

        health_v3 = cls(
            database=database,
            status=status,
            version=version,
        )

        return health_v3
