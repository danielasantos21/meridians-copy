from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.usage_day_v3 import UsageDayV3
    from ..models.usage_ip_v3 import UsageIpV3


T = TypeVar("T", bound="ApiClientUsageV3")


@_attrs_define
class ApiClientUsageV3:
    """
    Attributes:
        daily (list[UsageDayV3]):
        error_rate (float | None):
        errors (int):  Default: 0.
        id (str):
        idle_disable_after (datetime.datetime | None):
        last_used_at (datetime.datetime | None):
        last_used_ip (None | str):
        recent_ips (list[UsageIpV3]):
        requests (int):  Default: 0.
        status (str):
        window_days (int):  Default: 30.
    """

    daily: list[UsageDayV3]
    error_rate: float | None
    id: str
    idle_disable_after: datetime.datetime | None
    last_used_at: datetime.datetime | None
    last_used_ip: None | str
    recent_ips: list[UsageIpV3]
    status: str
    errors: int = 0
    requests: int = 0
    window_days: int = 30

    def to_dict(self) -> dict[str, Any]:
        daily = []
        for daily_item_data in self.daily:
            daily_item = daily_item_data.to_dict()
            daily.append(daily_item)

        error_rate: float | None
        error_rate = self.error_rate

        errors = self.errors

        id = self.id

        idle_disable_after: None | str
        if isinstance(self.idle_disable_after, datetime.datetime):
            idle_disable_after = self.idle_disable_after.isoformat()
        else:
            idle_disable_after = self.idle_disable_after

        last_used_at: None | str
        if isinstance(self.last_used_at, datetime.datetime):
            last_used_at = self.last_used_at.isoformat()
        else:
            last_used_at = self.last_used_at

        last_used_ip: None | str
        last_used_ip = self.last_used_ip

        recent_ips = []
        for recent_ips_item_data in self.recent_ips:
            recent_ips_item = recent_ips_item_data.to_dict()
            recent_ips.append(recent_ips_item)

        requests = self.requests

        status = self.status

        window_days = self.window_days

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "daily": daily,
                "error_rate": error_rate,
                "errors": errors,
                "id": id,
                "idle_disable_after": idle_disable_after,
                "last_used_at": last_used_at,
                "last_used_ip": last_used_ip,
                "recent_ips": recent_ips,
                "requests": requests,
                "status": status,
                "window_days": window_days,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.usage_day_v3 import UsageDayV3
        from ..models.usage_ip_v3 import UsageIpV3

        d = dict(src_dict)
        daily = []
        _daily = d.pop("daily")
        for daily_item_data in _daily:
            daily_item = UsageDayV3.from_dict(daily_item_data)

            daily.append(daily_item)

        def _parse_error_rate(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        error_rate = _parse_error_rate(d.pop("error_rate"))

        errors = d.pop("errors")

        id = d.pop("id")

        def _parse_idle_disable_after(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                idle_disable_after_type_0 = datetime.datetime.fromisoformat(data)

                return idle_disable_after_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        idle_disable_after = _parse_idle_disable_after(d.pop("idle_disable_after"))

        def _parse_last_used_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_used_at_type_0 = datetime.datetime.fromisoformat(data)

                return last_used_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_used_at = _parse_last_used_at(d.pop("last_used_at"))

        def _parse_last_used_ip(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        last_used_ip = _parse_last_used_ip(d.pop("last_used_ip"))

        recent_ips = []
        _recent_ips = d.pop("recent_ips")
        for recent_ips_item_data in _recent_ips:
            recent_ips_item = UsageIpV3.from_dict(recent_ips_item_data)

            recent_ips.append(recent_ips_item)

        requests = d.pop("requests")

        status = d.pop("status")

        window_days = d.pop("window_days")

        api_client_usage_v3 = cls(
            daily=daily,
            error_rate=error_rate,
            errors=errors,
            id=id,
            idle_disable_after=idle_disable_after,
            last_used_at=last_used_at,
            last_used_ip=last_used_ip,
            recent_ips=recent_ips,
            requests=requests,
            status=status,
            window_days=window_days,
        )

        return api_client_usage_v3
