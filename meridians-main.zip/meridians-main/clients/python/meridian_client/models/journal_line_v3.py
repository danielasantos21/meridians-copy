from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="JournalLineV3")


@_attrs_define
class JournalLineV3:
    """One aggregated JE line. Department x payer type x location: no person.

    Attributes:
        account (None | str):
        clinic_group (None | str):
        credit (str):  Default: '0'.
        debit (str):  Default: '0'.
        department (None | str):
        description (None | str):
        fiscal_year (int | None):
        je_date (None | str):
        je_type (None | str):
        line_number (int | None):
        location (None | str):
        period (int | None):
        subsidiary (None | str):
    """

    account: None | str
    clinic_group: None | str
    department: None | str
    description: None | str
    fiscal_year: int | None
    je_date: None | str
    je_type: None | str
    line_number: int | None
    location: None | str
    period: int | None
    subsidiary: None | str
    credit: str = "0"
    debit: str = "0"

    def to_dict(self) -> dict[str, Any]:
        account: None | str
        account = self.account

        clinic_group: None | str
        clinic_group = self.clinic_group

        credit = self.credit

        debit = self.debit

        department: None | str
        department = self.department

        description: None | str
        description = self.description

        fiscal_year: int | None
        fiscal_year = self.fiscal_year

        je_date: None | str
        je_date = self.je_date

        je_type: None | str
        je_type = self.je_type

        line_number: int | None
        line_number = self.line_number

        location: None | str
        location = self.location

        period: int | None
        period = self.period

        subsidiary: None | str
        subsidiary = self.subsidiary

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "account": account,
                "clinic_group": clinic_group,
                "credit": credit,
                "debit": debit,
                "department": department,
                "description": description,
                "fiscal_year": fiscal_year,
                "je_date": je_date,
                "je_type": je_type,
                "line_number": line_number,
                "location": location,
                "period": period,
                "subsidiary": subsidiary,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_account(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        account = _parse_account(d.pop("account"))

        def _parse_clinic_group(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        clinic_group = _parse_clinic_group(d.pop("clinic_group"))

        credit = d.pop("credit")

        debit = d.pop("debit")

        def _parse_department(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        department = _parse_department(d.pop("department"))

        def _parse_description(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        description = _parse_description(d.pop("description"))

        def _parse_fiscal_year(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year"))

        def _parse_je_date(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        je_date = _parse_je_date(d.pop("je_date"))

        def _parse_je_type(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        je_type = _parse_je_type(d.pop("je_type"))

        def _parse_line_number(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        line_number = _parse_line_number(d.pop("line_number"))

        def _parse_location(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        location = _parse_location(d.pop("location"))

        def _parse_period(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        period = _parse_period(d.pop("period"))

        def _parse_subsidiary(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        subsidiary = _parse_subsidiary(d.pop("subsidiary"))

        journal_line_v3 = cls(
            account=account,
            clinic_group=clinic_group,
            credit=credit,
            debit=debit,
            department=department,
            description=description,
            fiscal_year=fiscal_year,
            je_date=je_date,
            je_type=je_type,
            line_number=line_number,
            location=location,
            period=period,
            subsidiary=subsidiary,
        )

        return journal_line_v3
