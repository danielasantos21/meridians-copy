from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.revenue_slice_v3 import RevenueSliceV3


T = TypeVar("T", bound="RevenueSummaryV3")


@_attrs_define
class RevenueSummaryV3:
    """One current revenue batch of a period, as aggregates only.

    Never a transaction row: service dates are identifiers (§3.2 table).

        Attributes:
            batch_id (int | None):
            by_clinic_group (list[RevenueSliceV3]):
            by_location (list[RevenueSliceV3]):
            by_payer_type (list[RevenueSliceV3]):
            fiscal_year (int):
            mapped_records (int):
            mapping_rate (float):
            period (int):
            total_amount (float):
            total_records (int):
            unmapped_records (int):
    """

    batch_id: int | None
    by_clinic_group: list[RevenueSliceV3]
    by_location: list[RevenueSliceV3]
    by_payer_type: list[RevenueSliceV3]
    fiscal_year: int
    mapped_records: int
    mapping_rate: float
    period: int
    total_amount: float
    total_records: int
    unmapped_records: int

    def to_dict(self) -> dict[str, Any]:
        batch_id: int | None
        batch_id = self.batch_id

        by_clinic_group = []
        for by_clinic_group_item_data in self.by_clinic_group:
            by_clinic_group_item = by_clinic_group_item_data.to_dict()
            by_clinic_group.append(by_clinic_group_item)

        by_location = []
        for by_location_item_data in self.by_location:
            by_location_item = by_location_item_data.to_dict()
            by_location.append(by_location_item)

        by_payer_type = []
        for by_payer_type_item_data in self.by_payer_type:
            by_payer_type_item = by_payer_type_item_data.to_dict()
            by_payer_type.append(by_payer_type_item)

        fiscal_year = self.fiscal_year

        mapped_records = self.mapped_records

        mapping_rate = self.mapping_rate

        period = self.period

        total_amount = self.total_amount

        total_records = self.total_records

        unmapped_records = self.unmapped_records

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "batch_id": batch_id,
                "by_clinic_group": by_clinic_group,
                "by_location": by_location,
                "by_payer_type": by_payer_type,
                "fiscal_year": fiscal_year,
                "mapped_records": mapped_records,
                "mapping_rate": mapping_rate,
                "period": period,
                "total_amount": total_amount,
                "total_records": total_records,
                "unmapped_records": unmapped_records,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.revenue_slice_v3 import RevenueSliceV3

        d = dict(src_dict)

        def _parse_batch_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        batch_id = _parse_batch_id(d.pop("batch_id"))

        by_clinic_group = []
        _by_clinic_group = d.pop("by_clinic_group")
        for by_clinic_group_item_data in _by_clinic_group:
            by_clinic_group_item = RevenueSliceV3.from_dict(by_clinic_group_item_data)

            by_clinic_group.append(by_clinic_group_item)

        by_location = []
        _by_location = d.pop("by_location")
        for by_location_item_data in _by_location:
            by_location_item = RevenueSliceV3.from_dict(by_location_item_data)

            by_location.append(by_location_item)

        by_payer_type = []
        _by_payer_type = d.pop("by_payer_type")
        for by_payer_type_item_data in _by_payer_type:
            by_payer_type_item = RevenueSliceV3.from_dict(by_payer_type_item_data)

            by_payer_type.append(by_payer_type_item)

        fiscal_year = d.pop("fiscal_year")

        mapped_records = d.pop("mapped_records")

        mapping_rate = d.pop("mapping_rate")

        period = d.pop("period")

        total_amount = d.pop("total_amount")

        total_records = d.pop("total_records")

        unmapped_records = d.pop("unmapped_records")

        revenue_summary_v3 = cls(
            batch_id=batch_id,
            by_clinic_group=by_clinic_group,
            by_location=by_location,
            by_payer_type=by_payer_type,
            fiscal_year=fiscal_year,
            mapped_records=mapped_records,
            mapping_rate=mapping_rate,
            period=period,
            total_amount=total_amount,
            total_records=total_records,
            unmapped_records=unmapped_records,
        )

        return revenue_summary_v3
