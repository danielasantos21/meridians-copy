from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="QbDepartmentCreate")


@_attrs_define
class QbDepartmentCreate:
    """
    Attributes:
        ns_department (str):
        qb_class (str):
    """

    ns_department: str
    qb_class: str

    def to_dict(self) -> dict[str, Any]:
        ns_department = self.ns_department

        qb_class = self.qb_class

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ns_department": ns_department,
                "qb_class": qb_class,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        ns_department = d.pop("ns_department")

        qb_class = d.pop("qb_class")

        qb_department_create = cls(
            ns_department=ns_department,
            qb_class=qb_class,
        )

        return qb_department_create
