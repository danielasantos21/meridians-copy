from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..models.subscription_patch_event_types_type_0_item import (
    SubscriptionPatchEventTypesType0Item,
)
from ..models.subscription_patch_status_type_0 import SubscriptionPatchStatusType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="SubscriptionPatch")


@_attrs_define
class SubscriptionPatch:
    """
    Attributes:
        event_types (list[SubscriptionPatchEventTypesType0Item] | None | Unset):
        status (None | SubscriptionPatchStatusType0 | Unset):
        url (None | str | Unset):
    """

    event_types: list[SubscriptionPatchEventTypesType0Item] | None | Unset = UNSET
    status: None | SubscriptionPatchStatusType0 | Unset = UNSET
    url: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        event_types: list[str] | None | Unset
        if isinstance(self.event_types, Unset):
            event_types = UNSET
        elif isinstance(self.event_types, list):
            event_types = []
            for event_types_type_0_item_data in self.event_types:
                event_types_type_0_item = event_types_type_0_item_data.value
                event_types.append(event_types_type_0_item)

        else:
            event_types = self.event_types

        status: None | str | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        elif isinstance(self.status, SubscriptionPatchStatusType0):
            status = self.status.value
        else:
            status = self.status

        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if event_types is not UNSET:
            field_dict["event_types"] = event_types
        if status is not UNSET:
            field_dict["status"] = status
        if url is not UNSET:
            field_dict["url"] = url

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_event_types(
            data: object,
        ) -> list[SubscriptionPatchEventTypesType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                event_types_type_0 = []
                _event_types_type_0 = data
                for event_types_type_0_item_data in _event_types_type_0:
                    event_types_type_0_item = SubscriptionPatchEventTypesType0Item(
                        event_types_type_0_item_data
                    )

                    event_types_type_0.append(event_types_type_0_item)

                return event_types_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SubscriptionPatchEventTypesType0Item] | None | Unset, data)

        event_types = _parse_event_types(d.pop("event_types", UNSET))

        def _parse_status(data: object) -> None | SubscriptionPatchStatusType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                status_type_0 = SubscriptionPatchStatusType0(data)

                return status_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SubscriptionPatchStatusType0 | Unset, data)

        status = _parse_status(d.pop("status", UNSET))

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))

        subscription_patch = cls(
            event_types=event_types,
            status=status,
            url=url,
        )

        return subscription_patch
