from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="QbLocationCreate")


@_attrs_define
class QbLocationCreate:
    """
    Attributes:
        ns_location (str):
        qb_location (str):
    """

    ns_location: str
    qb_location: str

    def to_dict(self) -> dict[str, Any]:
        ns_location = self.ns_location

        qb_location = self.qb_location

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ns_location": ns_location,
                "qb_location": qb_location,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        ns_location = d.pop("ns_location")

        qb_location = d.pop("qb_location")

        qb_location_create = cls(
            ns_location=ns_location,
            qb_location=qb_location,
        )

        return qb_location_create
