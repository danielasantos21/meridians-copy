from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="ImportedV3")


@_attrs_define
class ImportedV3:
    """
    Attributes:
        imported (int):  Default: 0.
    """

    imported: int = 0

    def to_dict(self) -> dict[str, Any]:
        imported = self.imported

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "imported": imported,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        imported = d.pop("imported")

        imported_v3 = cls(
            imported=imported,
        )

        return imported_v3
