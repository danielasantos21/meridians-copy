from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="QbOtherCodePatch")


@_attrs_define
class QbOtherCodePatch:
    """
    Attributes:
        active (bool | None | Unset):
        other_code (None | str | Unset):
        service_line (None | str | Unset):
    """

    active: bool | None | Unset = UNSET
    other_code: None | str | Unset = UNSET
    service_line: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        active: bool | None | Unset
        if isinstance(self.active, Unset):
            active = UNSET
        else:
            active = self.active

        other_code: None | str | Unset
        if isinstance(self.other_code, Unset):
            other_code = UNSET
        else:
            other_code = self.other_code

        service_line: None | str | Unset
        if isinstance(self.service_line, Unset):
            service_line = UNSET
        else:
            service_line = self.service_line

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if active is not UNSET:
            field_dict["active"] = active
        if other_code is not UNSET:
            field_dict["other_code"] = other_code
        if service_line is not UNSET:
            field_dict["service_line"] = service_line

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        active = _parse_active(d.pop("active", UNSET))

        def _parse_other_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        other_code = _parse_other_code(d.pop("other_code", UNSET))

        def _parse_service_line(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        service_line = _parse_service_line(d.pop("service_line", UNSET))

        qb_other_code_patch = cls(
            active=active,
            other_code=other_code,
            service_line=service_line,
        )

        return qb_other_code_patch
