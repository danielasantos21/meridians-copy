from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

T = TypeVar("T", bound="DownloadUrlV3")


@_attrs_define
class DownloadUrlV3:
    """A short-lived signed URL for one artifact; the mint is audited.

    Attributes:
        audit_id (None | str):
        content_type (None | str):
        expires_at (datetime.datetime):
        expires_in (int):
        filename (str):
        size_bytes (int | None):
        url (str):
    """

    audit_id: None | str
    content_type: None | str
    expires_at: datetime.datetime
    expires_in: int
    filename: str
    size_bytes: int | None
    url: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        audit_id: None | str
        audit_id = self.audit_id

        content_type: None | str
        content_type = self.content_type

        expires_at = self.expires_at.isoformat()

        expires_in = self.expires_in

        filename = self.filename

        size_bytes: int | None
        size_bytes = self.size_bytes

        url = self.url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "audit_id": audit_id,
                "content_type": content_type,
                "expires_at": expires_at,
                "expires_in": expires_in,
                "filename": filename,
                "size_bytes": size_bytes,
                "url": url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_audit_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        audit_id = _parse_audit_id(d.pop("audit_id"))

        def _parse_content_type(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        content_type = _parse_content_type(d.pop("content_type"))

        expires_at = datetime.datetime.fromisoformat(d.pop("expires_at"))

        expires_in = d.pop("expires_in")

        filename = d.pop("filename")

        def _parse_size_bytes(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        size_bytes = _parse_size_bytes(d.pop("size_bytes"))

        url = d.pop("url")

        download_url_v3 = cls(
            audit_id=audit_id,
            content_type=content_type,
            expires_at=expires_at,
            expires_in=expires_in,
            filename=filename,
            size_bytes=size_bytes,
            url=url,
        )

        download_url_v3.additional_properties = d
        return download_url_v3

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
