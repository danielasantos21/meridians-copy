from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="UploadRequestV3")


@_attrs_define
class UploadRequestV3:
    """`POST /api/v3/runs/{run_id}/uploads` — ask for one pre-signed upload.

    `role` may be left out when the process takes one input. The pre-signed
    POST then holds S3 to this `content_type` and to at most the input's
    `max_bytes`.

        Attributes:
            content_type (str):
            filename (str):
            size_bytes (int):
            role (None | str | Unset):
    """

    content_type: str
    filename: str
    size_bytes: int
    role: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        content_type = self.content_type

        filename = self.filename

        size_bytes = self.size_bytes

        role: None | str | Unset
        if isinstance(self.role, Unset):
            role = UNSET
        else:
            role = self.role

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "content_type": content_type,
                "filename": filename,
                "size_bytes": size_bytes,
            }
        )
        if role is not UNSET:
            field_dict["role"] = role

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        content_type = d.pop("content_type")

        filename = d.pop("filename")

        size_bytes = d.pop("size_bytes")

        def _parse_role(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        role = _parse_role(d.pop("role", UNSET))

        upload_request_v3 = cls(
            content_type=content_type,
            filename=filename,
            size_bytes=size_bytes,
            role=role,
        )

        return upload_request_v3
