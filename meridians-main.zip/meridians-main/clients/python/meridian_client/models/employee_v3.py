from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="EmployeeV3")


@_attrs_define
class EmployeeV3:
    """One roster row, MX or US. No compensation field exists to expose (§3.2).

    Attributes:
        active (bool):  Default: True.
        department (None | str):
        department_netsuite (None | str):
        employee_id (str):
        entity (str):
        name (None | str):
        position (None | str):
        primary_location (None | str):
        report (None | str):
    """

    department: None | str
    department_netsuite: None | str
    employee_id: str
    entity: str
    name: None | str
    position: None | str
    primary_location: None | str
    report: None | str
    active: bool = True

    def to_dict(self) -> dict[str, Any]:
        active = self.active

        department: None | str
        department = self.department

        department_netsuite: None | str
        department_netsuite = self.department_netsuite

        employee_id = self.employee_id

        entity = self.entity

        name: None | str
        name = self.name

        position: None | str
        position = self.position

        primary_location: None | str
        primary_location = self.primary_location

        report: None | str
        report = self.report

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "active": active,
                "department": department,
                "department_netsuite": department_netsuite,
                "employee_id": employee_id,
                "entity": entity,
                "name": name,
                "position": position,
                "primary_location": primary_location,
                "report": report,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        active = d.pop("active")

        def _parse_department(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        department = _parse_department(d.pop("department"))

        def _parse_department_netsuite(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        department_netsuite = _parse_department_netsuite(d.pop("department_netsuite"))

        employee_id = d.pop("employee_id")

        entity = d.pop("entity")

        def _parse_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        name = _parse_name(d.pop("name"))

        def _parse_position(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        position = _parse_position(d.pop("position"))

        def _parse_primary_location(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        primary_location = _parse_primary_location(d.pop("primary_location"))

        def _parse_report(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        report = _parse_report(d.pop("report"))

        employee_v3 = cls(
            active=active,
            department=department,
            department_netsuite=department_netsuite,
            employee_id=employee_id,
            entity=entity,
            name=name,
            position=position,
            primary_location=primary_location,
            report=report,
        )

        return employee_v3
