from enum import StrEnum


class SubscriptionPatchEventTypesType0Item(StrEnum):
    RUN_BLOCKED = "run.blocked"
    RUN_COMPLETED = "run.completed"
    RUN_EXPIRED = "run.expired"
    RUN_FAILED = "run.failed"
    RUN_NEEDS_INPUT = "run.needs_input"

    def __str__(self) -> str:
        return str(self.value)
