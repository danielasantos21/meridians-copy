from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

T = TypeVar("T", bound="ClinicGroupV3")


@_attrs_define
class ClinicGroupV3:
    """
    Attributes:
        bank_account_key (None | str):
        created_at (datetime.datetime | None):
        group_name (str):
        hospital_location (None | str):
        id (int | None | str):
        locations (str):  Default: ''.
        primary_location_code (None | str):
    """

    bank_account_key: None | str
    created_at: datetime.datetime | None
    group_name: str
    hospital_location: None | str
    id: int | None | str
    primary_location_code: None | str
    locations: str = ""
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        bank_account_key: None | str
        bank_account_key = self.bank_account_key

        created_at: None | str
        if isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        group_name = self.group_name

        hospital_location: None | str
        hospital_location = self.hospital_location

        id: int | None | str
        id = self.id

        locations = self.locations

        primary_location_code: None | str
        primary_location_code = self.primary_location_code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "bank_account_key": bank_account_key,
                "created_at": created_at,
                "group_name": group_name,
                "hospital_location": hospital_location,
                "id": id,
                "locations": locations,
                "primary_location_code": primary_location_code,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_bank_account_key(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        bank_account_key = _parse_bank_account_key(d.pop("bank_account_key"))

        def _parse_created_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = datetime.datetime.fromisoformat(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        created_at = _parse_created_at(d.pop("created_at"))

        group_name = d.pop("group_name")

        def _parse_hospital_location(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        hospital_location = _parse_hospital_location(d.pop("hospital_location"))

        def _parse_id(data: object) -> int | None | str:
            if data is None:
                return data
            return cast(int | None | str, data)

        id = _parse_id(d.pop("id"))

        locations = d.pop("locations")

        def _parse_primary_location_code(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        primary_location_code = _parse_primary_location_code(
            d.pop("primary_location_code")
        )

        clinic_group_v3 = cls(
            bank_account_key=bank_account_key,
            created_at=created_at,
            group_name=group_name,
            hospital_location=hospital_location,
            id=id,
            locations=locations,
            primary_location_code=primary_location_code,
        )

        clinic_group_v3.additional_properties = d
        return clinic_group_v3

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
