from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from typing_extensions import Self

T = TypeVar("T", bound="PayerMappingCreate")


@_attrs_define
class PayerMappingCreate:
    """
    Attributes:
        payer_name (str):
        payer_type (str):
    """

    payer_name: str
    payer_type: str

    def to_dict(self) -> dict[str, Any]:
        payer_name = self.payer_name

        payer_type = self.payer_type

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "payer_name": payer_name,
                "payer_type": payer_type,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        payer_name = d.pop("payer_name")

        payer_type = d.pop("payer_type")

        payer_mapping_create = cls(
            payer_name=payer_name,
            payer_type=payer_type,
        )

        return payer_mapping_create
