from enum import StrEnum


class ApiClientRequestV3Kind(StrEnum):
    INTERNAL = "internal"
    PARTNER = "partner"
    SANDBOX = "sandbox"

    def __str__(self) -> str:
        return str(self.value)
