from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from typing_extensions import Self

if TYPE_CHECKING:
    from ..models.api_client_v3 import ApiClientV3


T = TypeVar("T", bound="ApiClientSecretV3")


@_attrs_define
class ApiClientSecretV3:
    """The answer to approve / rotate-secret: the client and its secret, ONCE.

    Attributes:
        client (ApiClientV3): One machine client as an admin sees it. Never a secret.
        secret (None | str):
    """

    client: ApiClientV3
    secret: None | str

    def to_dict(self) -> dict[str, Any]:
        client = self.client.to_dict()

        secret: None | str
        secret = self.secret

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "client": client,
                "secret": secret,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.api_client_v3 import ApiClientV3

        d = dict(src_dict)
        client = ApiClientV3.from_dict(d.pop("client"))

        def _parse_secret(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        secret = _parse_secret(d.pop("secret"))

        api_client_secret_v3 = cls(
            client=client,
            secret=secret,
        )

        return api_client_secret_v3
