from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.paged_revenue_summary_v3 import PagedRevenueSummaryV3
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    fiscal_year: int,
    period: int,
    location: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["fiscal_year"] = fiscal_year

    params["period"] = period

    json_location: None | str | Unset
    if isinstance(location, Unset):
        json_location = UNSET
    else:
        json_location = location
    params["location"] = json_location

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v3/revenue/summaries",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | PagedRevenueSummaryV3 | None:
    if response.status_code == 200:
        response_200 = PagedRevenueSummaryV3.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | PagedRevenueSummaryV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    fiscal_year: int,
    period: int,
    location: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedRevenueSummaryV3]:
    """Revenue Summaries

     One summary per current revenue batch of the period (usually one).

    Args:
        fiscal_year (int):
        period (int):
        location (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedRevenueSummaryV3]
    """

    kwargs = _get_kwargs(
        fiscal_year=fiscal_year,
        period=period,
        location=location,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    fiscal_year: int,
    period: int,
    location: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedRevenueSummaryV3 | None:
    """Revenue Summaries

     One summary per current revenue batch of the period (usually one).

    Args:
        fiscal_year (int):
        period (int):
        location (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedRevenueSummaryV3
    """

    return sync_detailed(
        client=client,
        fiscal_year=fiscal_year,
        period=period,
        location=location,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    fiscal_year: int,
    period: int,
    location: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedRevenueSummaryV3]:
    """Revenue Summaries

     One summary per current revenue batch of the period (usually one).

    Args:
        fiscal_year (int):
        period (int):
        location (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedRevenueSummaryV3]
    """

    kwargs = _get_kwargs(
        fiscal_year=fiscal_year,
        period=period,
        location=location,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    fiscal_year: int,
    period: int,
    location: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedRevenueSummaryV3 | None:
    """Revenue Summaries

     One summary per current revenue batch of the period (usually one).

    Args:
        fiscal_year (int):
        period (int):
        location (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedRevenueSummaryV3
    """

    return (
        await asyncio_detailed(
            client=client,
            fiscal_year=fiscal_year,
            period=period,
            location=location,
        )
    ).parsed
