from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.paged_journal_line_v3 import PagedJournalLineV3
from ...types import UNSET, Response, Unset


def _get_kwargs(
    run_id: UUID,
    *,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_location: None | str | Unset
    if isinstance(location, Unset):
        json_location = UNSET
    else:
        json_location = location
    params["location"] = json_location

    params["limit"] = limit

    json_cursor: None | str | Unset
    if isinstance(cursor, Unset):
        json_cursor = UNSET
    else:
        json_cursor = cursor
    params["cursor"] = json_cursor

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v3/runs/{run_id}/journal-entries".format(
            run_id=quote(str(run_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | PagedJournalLineV3 | None:
    if response.status_code == 200:
        response_200 = PagedJournalLineV3.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | PagedJournalLineV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedJournalLineV3]:
    """Run Journal Entries

     One run's journal lines, if the run is this org's and readable.

    Args:
        run_id (UUID):
        location (None | str | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedJournalLineV3]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        location=location,
        limit=limit,
        cursor=cursor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedJournalLineV3 | None:
    """Run Journal Entries

     One run's journal lines, if the run is this org's and readable.

    Args:
        run_id (UUID):
        location (None | str | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedJournalLineV3
    """

    return sync_detailed(
        run_id=run_id,
        client=client,
        location=location,
        limit=limit,
        cursor=cursor,
    ).parsed


async def asyncio_detailed(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedJournalLineV3]:
    """Run Journal Entries

     One run's journal lines, if the run is this org's and readable.

    Args:
        run_id (UUID):
        location (None | str | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedJournalLineV3]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        location=location,
        limit=limit,
        cursor=cursor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedJournalLineV3 | None:
    """Run Journal Entries

     One run's journal lines, if the run is this org's and readable.

    Args:
        run_id (UUID):
        location (None | str | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedJournalLineV3
    """

    return (
        await asyncio_detailed(
            run_id=run_id,
            client=client,
            location=location,
            limit=limit,
            cursor=cursor,
        )
    ).parsed
