from http import HTTPStatus
from typing import Any
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.paged_journal_line_v3 import PagedJournalLineV3
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    run_id: None | Unset | UUID = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_run_id: None | str | Unset
    if isinstance(run_id, Unset):
        json_run_id = UNSET
    elif isinstance(run_id, UUID):
        json_run_id = str(run_id)
    else:
        json_run_id = run_id
    params["run_id"] = json_run_id

    json_fiscal_year: int | None | Unset
    if isinstance(fiscal_year, Unset):
        json_fiscal_year = UNSET
    else:
        json_fiscal_year = fiscal_year
    params["fiscal_year"] = json_fiscal_year

    json_period: int | None | Unset
    if isinstance(period, Unset):
        json_period = UNSET
    else:
        json_period = period
    params["period"] = json_period

    json_location: None | str | Unset
    if isinstance(location, Unset):
        json_location = UNSET
    else:
        json_location = location
    params["location"] = json_location

    params["limit"] = limit

    json_cursor: None | str | Unset
    if isinstance(cursor, Unset):
        json_cursor = UNSET
    else:
        json_cursor = cursor
    params["cursor"] = json_cursor

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v3/journal-entries",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | PagedJournalLineV3 | None:
    if response.status_code == 200:
        response_200 = PagedJournalLineV3.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | PagedJournalLineV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    run_id: None | Unset | UUID = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedJournalLineV3]:
    """List Journal Entries

     Booked journal lines of the processes this caller may read, by line.

    Args:
        run_id (None | Unset | UUID):
        fiscal_year (int | None | Unset):
        period (int | None | Unset):
        location (None | str | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedJournalLineV3]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        fiscal_year=fiscal_year,
        period=period,
        location=location,
        limit=limit,
        cursor=cursor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    run_id: None | Unset | UUID = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedJournalLineV3 | None:
    """List Journal Entries

     Booked journal lines of the processes this caller may read, by line.

    Args:
        run_id (None | Unset | UUID):
        fiscal_year (int | None | Unset):
        period (int | None | Unset):
        location (None | str | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedJournalLineV3
    """

    return sync_detailed(
        client=client,
        run_id=run_id,
        fiscal_year=fiscal_year,
        period=period,
        location=location,
        limit=limit,
        cursor=cursor,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    run_id: None | Unset | UUID = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedJournalLineV3]:
    """List Journal Entries

     Booked journal lines of the processes this caller may read, by line.

    Args:
        run_id (None | Unset | UUID):
        fiscal_year (int | None | Unset):
        period (int | None | Unset):
        location (None | str | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedJournalLineV3]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        fiscal_year=fiscal_year,
        period=period,
        location=location,
        limit=limit,
        cursor=cursor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    run_id: None | Unset | UUID = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    location: None | str | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedJournalLineV3 | None:
    """List Journal Entries

     Booked journal lines of the processes this caller may read, by line.

    Args:
        run_id (None | Unset | UUID):
        fiscal_year (int | None | Unset):
        period (int | None | Unset):
        location (None | str | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedJournalLineV3
    """

    return (
        await asyncio_detailed(
            client=client,
            run_id=run_id,
            fiscal_year=fiscal_year,
            period=period,
            location=location,
            limit=limit,
            cursor=cursor,
        )
    ).parsed
