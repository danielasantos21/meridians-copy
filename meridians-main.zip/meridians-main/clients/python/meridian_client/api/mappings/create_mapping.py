from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.clinic_group_create import ClinicGroupCreate
from ...models.clinic_group_v3 import ClinicGroupV3
from ...models.department_create import DepartmentCreate
from ...models.department_v3 import DepartmentV3
from ...models.error_envelope import ErrorEnvelope
from ...models.location_mapping_create import LocationMappingCreate
from ...models.location_mapping_v3 import LocationMappingV3
from ...models.payer_mapping_create import PayerMappingCreate
from ...models.payer_mapping_v3 import PayerMappingV3
from ...models.provider_mapping_create import ProviderMappingCreate
from ...models.provider_mapping_v3 import ProviderMappingV3
from ...models.qb_account_create import QbAccountCreate
from ...models.qb_account_v3 import QbAccountV3
from ...models.qb_clinic_create import QbClinicCreate
from ...models.qb_clinic_v3 import QbClinicV3
from ...models.qb_department_create import QbDepartmentCreate
from ...models.qb_department_v3 import QbDepartmentV3
from ...models.qb_location_create import QbLocationCreate
from ...models.qb_location_v3 import QbLocationV3
from ...models.qb_other_code_create import QbOtherCodeCreate
from ...models.qb_other_code_v3 import QbOtherCodeV3
from ...models.qb_payer_label_create import QbPayerLabelCreate
from ...models.qb_payer_label_v3 import QbPayerLabelV3
from ...models.qb_provider_code_create import QbProviderCodeCreate
from ...models.qb_provider_code_v3 import QbProviderCodeV3
from ...types import Response


def _get_kwargs(
    kind: str,
    *,
    body: ClinicGroupCreate
    | DepartmentCreate
    | LocationMappingCreate
    | PayerMappingCreate
    | ProviderMappingCreate
    | QbAccountCreate
    | QbClinicCreate
    | QbDepartmentCreate
    | QbLocationCreate
    | QbOtherCodeCreate
    | QbPayerLabelCreate
    | QbProviderCodeCreate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v3/mappings/{kind}".format(
            kind=quote(str(kind), safe=""),
        ),
    }

    if (
        isinstance(body, ProviderMappingCreate)
        or isinstance(body, LocationMappingCreate)
        or isinstance(body, PayerMappingCreate)
        or isinstance(body, DepartmentCreate)
        or isinstance(body, QbProviderCodeCreate)
        or isinstance(body, ClinicGroupCreate)
        or isinstance(body, QbAccountCreate)
        or isinstance(body, QbDepartmentCreate)
        or isinstance(body, QbClinicCreate)
        or isinstance(body, QbOtherCodeCreate)
        or isinstance(body, QbPayerLabelCreate)
    ):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
    | None
):
    if response.status_code == 201:

        def _parse_response_201(
            data: object,
        ) -> (
            ClinicGroupV3
            | DepartmentV3
            | LocationMappingV3
            | PayerMappingV3
            | ProviderMappingV3
            | QbAccountV3
            | QbClinicV3
            | QbDepartmentV3
            | QbLocationV3
            | QbOtherCodeV3
            | QbPayerLabelV3
            | QbProviderCodeV3
        ):
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_0 = ProviderMappingV3.from_dict(data)

                return response_201_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_1 = LocationMappingV3.from_dict(data)

                return response_201_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_2 = PayerMappingV3.from_dict(data)

                return response_201_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_3 = DepartmentV3.from_dict(data)

                return response_201_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_4 = QbProviderCodeV3.from_dict(data)

                return response_201_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_5 = ClinicGroupV3.from_dict(data)

                return response_201_type_5
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_6 = QbAccountV3.from_dict(data)

                return response_201_type_6
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_7 = QbDepartmentV3.from_dict(data)

                return response_201_type_7
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_8 = QbClinicV3.from_dict(data)

                return response_201_type_8
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_9 = QbOtherCodeV3.from_dict(data)

                return response_201_type_9
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_10 = QbPayerLabelV3.from_dict(data)

                return response_201_type_10
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_201_type_11 = QbLocationV3.from_dict(data)

            return response_201_type_11

        response_201 = _parse_response_201(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    kind: str,
    *,
    client: AuthenticatedClient,
    body: ClinicGroupCreate
    | DepartmentCreate
    | LocationMappingCreate
    | PayerMappingCreate
    | ProviderMappingCreate
    | QbAccountCreate
    | QbClinicCreate
    | QbDepartmentCreate
    | QbLocationCreate
    | QbOtherCodeCreate
    | QbPayerLabelCreate
    | QbProviderCodeCreate,
) -> Response[
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
]:
    """Create Mapping

     Add one mapping to this org's collection. 201 with the row.

    Args:
        kind (str):
        body (ClinicGroupCreate | DepartmentCreate | LocationMappingCreate | PayerMappingCreate |
            ProviderMappingCreate | QbAccountCreate | QbClinicCreate | QbDepartmentCreate |
            QbLocationCreate | QbOtherCodeCreate | QbPayerLabelCreate | QbProviderCodeCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ClinicGroupV3 | DepartmentV3 | LocationMappingV3 | PayerMappingV3 | ProviderMappingV3 | QbAccountV3 | QbClinicV3 | QbDepartmentV3 | QbLocationV3 | QbOtherCodeV3 | QbPayerLabelV3 | QbProviderCodeV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        kind=kind,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    kind: str,
    *,
    client: AuthenticatedClient,
    body: ClinicGroupCreate
    | DepartmentCreate
    | LocationMappingCreate
    | PayerMappingCreate
    | ProviderMappingCreate
    | QbAccountCreate
    | QbClinicCreate
    | QbDepartmentCreate
    | QbLocationCreate
    | QbOtherCodeCreate
    | QbPayerLabelCreate
    | QbProviderCodeCreate,
) -> (
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
    | None
):
    """Create Mapping

     Add one mapping to this org's collection. 201 with the row.

    Args:
        kind (str):
        body (ClinicGroupCreate | DepartmentCreate | LocationMappingCreate | PayerMappingCreate |
            ProviderMappingCreate | QbAccountCreate | QbClinicCreate | QbDepartmentCreate |
            QbLocationCreate | QbOtherCodeCreate | QbPayerLabelCreate | QbProviderCodeCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ClinicGroupV3 | DepartmentV3 | LocationMappingV3 | PayerMappingV3 | ProviderMappingV3 | QbAccountV3 | QbClinicV3 | QbDepartmentV3 | QbLocationV3 | QbOtherCodeV3 | QbPayerLabelV3 | QbProviderCodeV3 | ErrorEnvelope
    """

    return sync_detailed(
        kind=kind,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    kind: str,
    *,
    client: AuthenticatedClient,
    body: ClinicGroupCreate
    | DepartmentCreate
    | LocationMappingCreate
    | PayerMappingCreate
    | ProviderMappingCreate
    | QbAccountCreate
    | QbClinicCreate
    | QbDepartmentCreate
    | QbLocationCreate
    | QbOtherCodeCreate
    | QbPayerLabelCreate
    | QbProviderCodeCreate,
) -> Response[
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
]:
    """Create Mapping

     Add one mapping to this org's collection. 201 with the row.

    Args:
        kind (str):
        body (ClinicGroupCreate | DepartmentCreate | LocationMappingCreate | PayerMappingCreate |
            ProviderMappingCreate | QbAccountCreate | QbClinicCreate | QbDepartmentCreate |
            QbLocationCreate | QbOtherCodeCreate | QbPayerLabelCreate | QbProviderCodeCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ClinicGroupV3 | DepartmentV3 | LocationMappingV3 | PayerMappingV3 | ProviderMappingV3 | QbAccountV3 | QbClinicV3 | QbDepartmentV3 | QbLocationV3 | QbOtherCodeV3 | QbPayerLabelV3 | QbProviderCodeV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        kind=kind,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    kind: str,
    *,
    client: AuthenticatedClient,
    body: ClinicGroupCreate
    | DepartmentCreate
    | LocationMappingCreate
    | PayerMappingCreate
    | ProviderMappingCreate
    | QbAccountCreate
    | QbClinicCreate
    | QbDepartmentCreate
    | QbLocationCreate
    | QbOtherCodeCreate
    | QbPayerLabelCreate
    | QbProviderCodeCreate,
) -> (
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
    | None
):
    """Create Mapping

     Add one mapping to this org's collection. 201 with the row.

    Args:
        kind (str):
        body (ClinicGroupCreate | DepartmentCreate | LocationMappingCreate | PayerMappingCreate |
            ProviderMappingCreate | QbAccountCreate | QbClinicCreate | QbDepartmentCreate |
            QbLocationCreate | QbOtherCodeCreate | QbPayerLabelCreate | QbProviderCodeCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ClinicGroupV3 | DepartmentV3 | LocationMappingV3 | PayerMappingV3 | ProviderMappingV3 | QbAccountV3 | QbClinicV3 | QbDepartmentV3 | QbLocationV3 | QbOtherCodeV3 | QbPayerLabelV3 | QbProviderCodeV3 | ErrorEnvelope
    """

    return (
        await asyncio_detailed(
            kind=kind,
            client=client,
            body=body,
        )
    ).parsed
