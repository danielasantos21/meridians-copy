from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.clinic_group_v3 import ClinicGroupV3
from ...models.department_patch import DepartmentPatch
from ...models.department_v3 import DepartmentV3
from ...models.error_envelope import ErrorEnvelope
from ...models.location_mapping_patch import LocationMappingPatch
from ...models.location_mapping_v3 import LocationMappingV3
from ...models.payer_mapping_patch import PayerMappingPatch
from ...models.payer_mapping_v3 import PayerMappingV3
from ...models.provider_mapping_patch import ProviderMappingPatch
from ...models.provider_mapping_v3 import ProviderMappingV3
from ...models.qb_account_patch import QbAccountPatch
from ...models.qb_account_v3 import QbAccountV3
from ...models.qb_clinic_patch import QbClinicPatch
from ...models.qb_clinic_v3 import QbClinicV3
from ...models.qb_department_patch import QbDepartmentPatch
from ...models.qb_department_v3 import QbDepartmentV3
from ...models.qb_location_patch import QbLocationPatch
from ...models.qb_location_v3 import QbLocationV3
from ...models.qb_other_code_patch import QbOtherCodePatch
from ...models.qb_other_code_v3 import QbOtherCodeV3
from ...models.qb_payer_label_patch import QbPayerLabelPatch
from ...models.qb_payer_label_v3 import QbPayerLabelV3
from ...models.qb_provider_code_patch import QbProviderCodePatch
from ...models.qb_provider_code_v3 import QbProviderCodeV3
from ...types import Response


def _get_kwargs(
    kind: str,
    row_id: int,
    *,
    body: DepartmentPatch
    | LocationMappingPatch
    | PayerMappingPatch
    | ProviderMappingPatch
    | QbAccountPatch
    | QbClinicPatch
    | QbDepartmentPatch
    | QbLocationPatch
    | QbOtherCodePatch
    | QbPayerLabelPatch
    | QbProviderCodePatch,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/v3/mappings/{kind}/{row_id}".format(
            kind=quote(str(kind), safe=""),
            row_id=quote(str(row_id), safe=""),
        ),
    }

    if (
        isinstance(body, DepartmentPatch)
        or isinstance(body, LocationMappingPatch)
        or isinstance(body, PayerMappingPatch)
        or isinstance(body, ProviderMappingPatch)
        or isinstance(body, QbAccountPatch)
        or isinstance(body, QbClinicPatch)
        or isinstance(body, QbDepartmentPatch)
        or isinstance(body, QbLocationPatch)
        or isinstance(body, QbOtherCodePatch)
        or isinstance(body, QbPayerLabelPatch)
    ):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
    | None
):
    if response.status_code == 200:

        def _parse_response_200(
            data: object,
        ) -> (
            ClinicGroupV3
            | DepartmentV3
            | LocationMappingV3
            | PayerMappingV3
            | ProviderMappingV3
            | QbAccountV3
            | QbClinicV3
            | QbDepartmentV3
            | QbLocationV3
            | QbOtherCodeV3
            | QbPayerLabelV3
            | QbProviderCodeV3
        ):
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_0 = ProviderMappingV3.from_dict(data)

                return response_200_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_1 = LocationMappingV3.from_dict(data)

                return response_200_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_2 = PayerMappingV3.from_dict(data)

                return response_200_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_3 = DepartmentV3.from_dict(data)

                return response_200_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_4 = QbProviderCodeV3.from_dict(data)

                return response_200_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_5 = ClinicGroupV3.from_dict(data)

                return response_200_type_5
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_6 = QbAccountV3.from_dict(data)

                return response_200_type_6
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_7 = QbDepartmentV3.from_dict(data)

                return response_200_type_7
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_8 = QbClinicV3.from_dict(data)

                return response_200_type_8
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_9 = QbOtherCodeV3.from_dict(data)

                return response_200_type_9
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_10 = QbPayerLabelV3.from_dict(data)

                return response_200_type_10
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_200_type_11 = QbLocationV3.from_dict(data)

            return response_200_type_11

        response_200 = _parse_response_200(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    kind: str,
    row_id: int,
    *,
    client: AuthenticatedClient,
    body: DepartmentPatch
    | LocationMappingPatch
    | PayerMappingPatch
    | ProviderMappingPatch
    | QbAccountPatch
    | QbClinicPatch
    | QbDepartmentPatch
    | QbLocationPatch
    | QbOtherCodePatch
    | QbPayerLabelPatch
    | QbProviderCodePatch,
) -> Response[
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
]:
    """Update Mapping

     Edit one of this org's mappings. Another org's id, or none, is 404.

    Args:
        kind (str):
        row_id (int):
        body (DepartmentPatch | LocationMappingPatch | PayerMappingPatch | ProviderMappingPatch |
            QbAccountPatch | QbClinicPatch | QbDepartmentPatch | QbLocationPatch | QbOtherCodePatch |
            QbPayerLabelPatch | QbProviderCodePatch):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ClinicGroupV3 | DepartmentV3 | LocationMappingV3 | PayerMappingV3 | ProviderMappingV3 | QbAccountV3 | QbClinicV3 | QbDepartmentV3 | QbLocationV3 | QbOtherCodeV3 | QbPayerLabelV3 | QbProviderCodeV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        kind=kind,
        row_id=row_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    kind: str,
    row_id: int,
    *,
    client: AuthenticatedClient,
    body: DepartmentPatch
    | LocationMappingPatch
    | PayerMappingPatch
    | ProviderMappingPatch
    | QbAccountPatch
    | QbClinicPatch
    | QbDepartmentPatch
    | QbLocationPatch
    | QbOtherCodePatch
    | QbPayerLabelPatch
    | QbProviderCodePatch,
) -> (
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
    | None
):
    """Update Mapping

     Edit one of this org's mappings. Another org's id, or none, is 404.

    Args:
        kind (str):
        row_id (int):
        body (DepartmentPatch | LocationMappingPatch | PayerMappingPatch | ProviderMappingPatch |
            QbAccountPatch | QbClinicPatch | QbDepartmentPatch | QbLocationPatch | QbOtherCodePatch |
            QbPayerLabelPatch | QbProviderCodePatch):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ClinicGroupV3 | DepartmentV3 | LocationMappingV3 | PayerMappingV3 | ProviderMappingV3 | QbAccountV3 | QbClinicV3 | QbDepartmentV3 | QbLocationV3 | QbOtherCodeV3 | QbPayerLabelV3 | QbProviderCodeV3 | ErrorEnvelope
    """

    return sync_detailed(
        kind=kind,
        row_id=row_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    kind: str,
    row_id: int,
    *,
    client: AuthenticatedClient,
    body: DepartmentPatch
    | LocationMappingPatch
    | PayerMappingPatch
    | ProviderMappingPatch
    | QbAccountPatch
    | QbClinicPatch
    | QbDepartmentPatch
    | QbLocationPatch
    | QbOtherCodePatch
    | QbPayerLabelPatch
    | QbProviderCodePatch,
) -> Response[
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
]:
    """Update Mapping

     Edit one of this org's mappings. Another org's id, or none, is 404.

    Args:
        kind (str):
        row_id (int):
        body (DepartmentPatch | LocationMappingPatch | PayerMappingPatch | ProviderMappingPatch |
            QbAccountPatch | QbClinicPatch | QbDepartmentPatch | QbLocationPatch | QbOtherCodePatch |
            QbPayerLabelPatch | QbProviderCodePatch):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ClinicGroupV3 | DepartmentV3 | LocationMappingV3 | PayerMappingV3 | ProviderMappingV3 | QbAccountV3 | QbClinicV3 | QbDepartmentV3 | QbLocationV3 | QbOtherCodeV3 | QbPayerLabelV3 | QbProviderCodeV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        kind=kind,
        row_id=row_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    kind: str,
    row_id: int,
    *,
    client: AuthenticatedClient,
    body: DepartmentPatch
    | LocationMappingPatch
    | PayerMappingPatch
    | ProviderMappingPatch
    | QbAccountPatch
    | QbClinicPatch
    | QbDepartmentPatch
    | QbLocationPatch
    | QbOtherCodePatch
    | QbPayerLabelPatch
    | QbProviderCodePatch,
) -> (
    ClinicGroupV3
    | DepartmentV3
    | LocationMappingV3
    | PayerMappingV3
    | ProviderMappingV3
    | QbAccountV3
    | QbClinicV3
    | QbDepartmentV3
    | QbLocationV3
    | QbOtherCodeV3
    | QbPayerLabelV3
    | QbProviderCodeV3
    | ErrorEnvelope
    | None
):
    """Update Mapping

     Edit one of this org's mappings. Another org's id, or none, is 404.

    Args:
        kind (str):
        row_id (int):
        body (DepartmentPatch | LocationMappingPatch | PayerMappingPatch | ProviderMappingPatch |
            QbAccountPatch | QbClinicPatch | QbDepartmentPatch | QbLocationPatch | QbOtherCodePatch |
            QbPayerLabelPatch | QbProviderCodePatch):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ClinicGroupV3 | DepartmentV3 | LocationMappingV3 | PayerMappingV3 | ProviderMappingV3 | QbAccountV3 | QbClinicV3 | QbDepartmentV3 | QbLocationV3 | QbOtherCodeV3 | QbPayerLabelV3 | QbProviderCodeV3 | ErrorEnvelope
    """

    return (
        await asyncio_detailed(
            kind=kind,
            row_id=row_id,
            client=client,
            body=body,
        )
    ).parsed
