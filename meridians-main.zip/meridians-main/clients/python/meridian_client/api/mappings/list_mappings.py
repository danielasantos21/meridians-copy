from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.paged_mapping_v3 import PagedMappingV3
from ...types import UNSET, Response, Unset


def _get_kwargs(
    kind: str,
    *,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    json_cursor: None | str | Unset
    if isinstance(cursor, Unset):
        json_cursor = UNSET
    else:
        json_cursor = cursor
    params["cursor"] = json_cursor

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v3/mappings/{kind}".format(
            kind=quote(str(kind), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | PagedMappingV3 | None:
    if response.status_code == 200:
        response_200 = PagedMappingV3.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | PagedMappingV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    kind: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedMappingV3]:
    """List Mappings

     One mapping collection of this org, by id.

    Args:
        kind (str):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedMappingV3]
    """

    kwargs = _get_kwargs(
        kind=kind,
        limit=limit,
        cursor=cursor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    kind: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedMappingV3 | None:
    """List Mappings

     One mapping collection of this org, by id.

    Args:
        kind (str):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedMappingV3
    """

    return sync_detailed(
        kind=kind,
        client=client,
        limit=limit,
        cursor=cursor,
    ).parsed


async def asyncio_detailed(
    kind: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedMappingV3]:
    """List Mappings

     One mapping collection of this org, by id.

    Args:
        kind (str):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedMappingV3]
    """

    kwargs = _get_kwargs(
        kind=kind,
        limit=limit,
        cursor=cursor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    kind: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedMappingV3 | None:
    """List Mappings

     One mapping collection of this org, by id.

    Args:
        kind (str):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedMappingV3
    """

    return (
        await asyncio_detailed(
            kind=kind,
            client=client,
            limit=limit,
            cursor=cursor,
        )
    ).parsed
