import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.paged_run_v3 import PagedRunV3
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    process: None | str | Unset = UNSET,
    state: None | str | Unset = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    created_by: None | str | Unset = UNSET,
    from_: datetime.date | None | Unset = UNSET,
    to: datetime.date | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_process: None | str | Unset
    if isinstance(process, Unset):
        json_process = UNSET
    else:
        json_process = process
    params["process"] = json_process

    json_state: None | str | Unset
    if isinstance(state, Unset):
        json_state = UNSET
    else:
        json_state = state
    params["state"] = json_state

    json_fiscal_year: int | None | Unset
    if isinstance(fiscal_year, Unset):
        json_fiscal_year = UNSET
    else:
        json_fiscal_year = fiscal_year
    params["fiscal_year"] = json_fiscal_year

    json_period: int | None | Unset
    if isinstance(period, Unset):
        json_period = UNSET
    else:
        json_period = period
    params["period"] = json_period

    json_created_by: None | str | Unset
    if isinstance(created_by, Unset):
        json_created_by = UNSET
    else:
        json_created_by = created_by
    params["created_by"] = json_created_by

    json_from_: None | str | Unset
    if isinstance(from_, Unset):
        json_from_ = UNSET
    elif isinstance(from_, datetime.date):
        json_from_ = from_.isoformat()
    else:
        json_from_ = from_
    params["from"] = json_from_

    json_to: None | str | Unset
    if isinstance(to, Unset):
        json_to = UNSET
    elif isinstance(to, datetime.date):
        json_to = to.isoformat()
    else:
        json_to = to
    params["to"] = json_to

    params["limit"] = limit

    json_cursor: None | str | Unset
    if isinstance(cursor, Unset):
        json_cursor = UNSET
    else:
        json_cursor = cursor
    params["cursor"] = json_cursor

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v3/runs",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | PagedRunV3 | None:
    if response.status_code == 200:
        response_200 = PagedRunV3.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | PagedRunV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    process: None | str | Unset = UNSET,
    state: None | str | Unset = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    created_by: None | str | Unset = UNSET,
    from_: datetime.date | None | Unset = UNSET,
    to: datetime.date | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedRunV3]:
    """List Runs

     This org's runs of the processes this caller may read, newest first.

    Args:
        process (None | str | Unset):
        state (None | str | Unset):
        fiscal_year (int | None | Unset):
        period (int | None | Unset):
        created_by (None | str | Unset):
        from_ (datetime.date | None | Unset):
        to (datetime.date | None | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedRunV3]
    """

    kwargs = _get_kwargs(
        process=process,
        state=state,
        fiscal_year=fiscal_year,
        period=period,
        created_by=created_by,
        from_=from_,
        to=to,
        limit=limit,
        cursor=cursor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    process: None | str | Unset = UNSET,
    state: None | str | Unset = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    created_by: None | str | Unset = UNSET,
    from_: datetime.date | None | Unset = UNSET,
    to: datetime.date | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedRunV3 | None:
    """List Runs

     This org's runs of the processes this caller may read, newest first.

    Args:
        process (None | str | Unset):
        state (None | str | Unset):
        fiscal_year (int | None | Unset):
        period (int | None | Unset):
        created_by (None | str | Unset):
        from_ (datetime.date | None | Unset):
        to (datetime.date | None | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedRunV3
    """

    return sync_detailed(
        client=client,
        process=process,
        state=state,
        fiscal_year=fiscal_year,
        period=period,
        created_by=created_by,
        from_=from_,
        to=to,
        limit=limit,
        cursor=cursor,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    process: None | str | Unset = UNSET,
    state: None | str | Unset = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    created_by: None | str | Unset = UNSET,
    from_: datetime.date | None | Unset = UNSET,
    to: datetime.date | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedRunV3]:
    """List Runs

     This org's runs of the processes this caller may read, newest first.

    Args:
        process (None | str | Unset):
        state (None | str | Unset):
        fiscal_year (int | None | Unset):
        period (int | None | Unset):
        created_by (None | str | Unset):
        from_ (datetime.date | None | Unset):
        to (datetime.date | None | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedRunV3]
    """

    kwargs = _get_kwargs(
        process=process,
        state=state,
        fiscal_year=fiscal_year,
        period=period,
        created_by=created_by,
        from_=from_,
        to=to,
        limit=limit,
        cursor=cursor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    process: None | str | Unset = UNSET,
    state: None | str | Unset = UNSET,
    fiscal_year: int | None | Unset = UNSET,
    period: int | None | Unset = UNSET,
    created_by: None | str | Unset = UNSET,
    from_: datetime.date | None | Unset = UNSET,
    to: datetime.date | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedRunV3 | None:
    """List Runs

     This org's runs of the processes this caller may read, newest first.

    Args:
        process (None | str | Unset):
        state (None | str | Unset):
        fiscal_year (int | None | Unset):
        period (int | None | Unset):
        created_by (None | str | Unset):
        from_ (datetime.date | None | Unset):
        to (datetime.date | None | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedRunV3
    """

    return (
        await asyncio_detailed(
            client=client,
            process=process,
            state=state,
            fiscal_year=fiscal_year,
            period=period,
            created_by=created_by,
            from_=from_,
            to=to,
            limit=limit,
            cursor=cursor,
        )
    ).parsed
