from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delivery_v3 import DeliveryV3
from ...models.error_envelope import ErrorEnvelope
from ...types import Response


def _get_kwargs(
    delivery_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v3/webhooks/deliveries/{delivery_id}/redrive".format(
            delivery_id=quote(str(delivery_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeliveryV3 | ErrorEnvelope | None:
    if response.status_code == 202:
        response_202 = DeliveryV3.from_dict(response.json())

        return response_202

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeliveryV3 | ErrorEnvelope]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    delivery_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[DeliveryV3 | ErrorEnvelope]:
    """Redrive Delivery

     Re-queue a dead or dropped delivery. The tenant re-check runs again. 202.

    Bounded: at most 3 redrives of one delivery, none of an event older than 7
    days (`409 WEBHOOK_STATE_INVALID`, `details.reason`), and 1 per
    subscription per 30-second window (`429 QUOTA_EXCEEDED` with `Retry-After`).

    Args:
        delivery_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeliveryV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        delivery_id=delivery_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    delivery_id: UUID,
    *,
    client: AuthenticatedClient,
) -> DeliveryV3 | ErrorEnvelope | None:
    """Redrive Delivery

     Re-queue a dead or dropped delivery. The tenant re-check runs again. 202.

    Bounded: at most 3 redrives of one delivery, none of an event older than 7
    days (`409 WEBHOOK_STATE_INVALID`, `details.reason`), and 1 per
    subscription per 30-second window (`429 QUOTA_EXCEEDED` with `Retry-After`).

    Args:
        delivery_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeliveryV3 | ErrorEnvelope
    """

    return sync_detailed(
        delivery_id=delivery_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    delivery_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[DeliveryV3 | ErrorEnvelope]:
    """Redrive Delivery

     Re-queue a dead or dropped delivery. The tenant re-check runs again. 202.

    Bounded: at most 3 redrives of one delivery, none of an event older than 7
    days (`409 WEBHOOK_STATE_INVALID`, `details.reason`), and 1 per
    subscription per 30-second window (`429 QUOTA_EXCEEDED` with `Retry-After`).

    Args:
        delivery_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeliveryV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        delivery_id=delivery_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    delivery_id: UUID,
    *,
    client: AuthenticatedClient,
) -> DeliveryV3 | ErrorEnvelope | None:
    """Redrive Delivery

     Re-queue a dead or dropped delivery. The tenant re-check runs again. 202.

    Bounded: at most 3 redrives of one delivery, none of an event older than 7
    days (`409 WEBHOOK_STATE_INVALID`, `details.reason`), and 1 per
    subscription per 30-second window (`429 QUOTA_EXCEEDED` with `Retry-After`).

    Args:
        delivery_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeliveryV3 | ErrorEnvelope
    """

    return (
        await asyncio_detailed(
            delivery_id=delivery_id,
            client=client,
        )
    ).parsed
