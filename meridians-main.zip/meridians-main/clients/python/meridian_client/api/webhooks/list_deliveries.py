from http import HTTPStatus
from typing import Any
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.list_deliveries_status_type_0 import ListDeliveriesStatusType0
from ...models.paged_delivery_v3 import PagedDeliveryV3
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    subscription_id: None | Unset | UUID = UNSET,
    status: ListDeliveriesStatusType0 | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_subscription_id: None | str | Unset
    if isinstance(subscription_id, Unset):
        json_subscription_id = UNSET
    elif isinstance(subscription_id, UUID):
        json_subscription_id = str(subscription_id)
    else:
        json_subscription_id = subscription_id
    params["subscription_id"] = json_subscription_id

    json_status: None | str | Unset
    if isinstance(status, Unset):
        json_status = UNSET
    elif isinstance(status, ListDeliveriesStatusType0):
        json_status = status.value
    else:
        json_status = status
    params["status"] = json_status

    params["limit"] = limit

    json_cursor: None | str | Unset
    if isinstance(cursor, Unset):
        json_cursor = UNSET
    else:
        json_cursor = cursor
    params["cursor"] = json_cursor

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v3/webhooks/deliveries",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | PagedDeliveryV3 | None:
    if response.status_code == 200:
        response_200 = PagedDeliveryV3.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | PagedDeliveryV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    subscription_id: None | Unset | UUID = UNSET,
    status: ListDeliveriesStatusType0 | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedDeliveryV3]:
    """List Deliveries

     The delivery log, newest first; filter by subscription and status.

    Args:
        subscription_id (None | Unset | UUID):
        status (ListDeliveriesStatusType0 | None | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedDeliveryV3]
    """

    kwargs = _get_kwargs(
        subscription_id=subscription_id,
        status=status,
        limit=limit,
        cursor=cursor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    subscription_id: None | Unset | UUID = UNSET,
    status: ListDeliveriesStatusType0 | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedDeliveryV3 | None:
    """List Deliveries

     The delivery log, newest first; filter by subscription and status.

    Args:
        subscription_id (None | Unset | UUID):
        status (ListDeliveriesStatusType0 | None | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedDeliveryV3
    """

    return sync_detailed(
        client=client,
        subscription_id=subscription_id,
        status=status,
        limit=limit,
        cursor=cursor,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    subscription_id: None | Unset | UUID = UNSET,
    status: ListDeliveriesStatusType0 | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | PagedDeliveryV3]:
    """List Deliveries

     The delivery log, newest first; filter by subscription and status.

    Args:
        subscription_id (None | Unset | UUID):
        status (ListDeliveriesStatusType0 | None | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | PagedDeliveryV3]
    """

    kwargs = _get_kwargs(
        subscription_id=subscription_id,
        status=status,
        limit=limit,
        cursor=cursor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    subscription_id: None | Unset | UUID = UNSET,
    status: ListDeliveriesStatusType0 | None | Unset = UNSET,
    limit: int | Unset = 25,
    cursor: None | str | Unset = UNSET,
) -> ErrorEnvelope | PagedDeliveryV3 | None:
    """List Deliveries

     The delivery log, newest first; filter by subscription and status.

    Args:
        subscription_id (None | Unset | UUID):
        status (ListDeliveriesStatusType0 | None | Unset):
        limit (int | Unset):  Default: 25.
        cursor (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | PagedDeliveryV3
    """

    return (
        await asyncio_detailed(
            client=client,
            subscription_id=subscription_id,
            status=status,
            limit=limit,
            cursor=cursor,
        )
    ).parsed
