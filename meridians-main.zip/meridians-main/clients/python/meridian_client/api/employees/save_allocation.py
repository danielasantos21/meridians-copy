from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.allocation_in import AllocationIn
from ...models.allocation_v3 import AllocationV3
from ...models.error_envelope import ErrorEnvelope
from ...types import Response


def _get_kwargs(
    *,
    body: AllocationIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v3/allocations",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AllocationV3 | ErrorEnvelope | None:
    if response.status_code == 200:
        response_200 = AllocationV3.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AllocationV3 | ErrorEnvelope]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: AllocationIn,
) -> Response[AllocationV3 | ErrorEnvelope]:
    """Save Allocation

     Replace one employee's whole clinic split, in one transaction. 200.

    The employee is in the body, not the URL (a name is PII). The shares must
    total 100% (`allocation_rules`); the delete-and-insert is
    `Database.save_employee_allocations`, which scopes both by this org.

    Args:
        body (AllocationIn): `PUT /api/v3/allocations` — replace one employee's whole split.

            The employee is named in the BODY, never the URL: a name is PII and the
            URL is logged by every proxy on the way (§3.1 rule 5).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AllocationV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: AllocationIn,
) -> AllocationV3 | ErrorEnvelope | None:
    """Save Allocation

     Replace one employee's whole clinic split, in one transaction. 200.

    The employee is in the body, not the URL (a name is PII). The shares must
    total 100% (`allocation_rules`); the delete-and-insert is
    `Database.save_employee_allocations`, which scopes both by this org.

    Args:
        body (AllocationIn): `PUT /api/v3/allocations` — replace one employee's whole split.

            The employee is named in the BODY, never the URL: a name is PII and the
            URL is logged by every proxy on the way (§3.1 rule 5).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AllocationV3 | ErrorEnvelope
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: AllocationIn,
) -> Response[AllocationV3 | ErrorEnvelope]:
    """Save Allocation

     Replace one employee's whole clinic split, in one transaction. 200.

    The employee is in the body, not the URL (a name is PII). The shares must
    total 100% (`allocation_rules`); the delete-and-insert is
    `Database.save_employee_allocations`, which scopes both by this org.

    Args:
        body (AllocationIn): `PUT /api/v3/allocations` — replace one employee's whole split.

            The employee is named in the BODY, never the URL: a name is PII and the
            URL is logged by every proxy on the way (§3.1 rule 5).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AllocationV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: AllocationIn,
) -> AllocationV3 | ErrorEnvelope | None:
    """Save Allocation

     Replace one employee's whole clinic split, in one transaction. 200.

    The employee is in the body, not the URL (a name is PII). The shares must
    total 100% (`allocation_rules`); the delete-and-insert is
    `Database.save_employee_allocations`, which scopes both by this org.

    Args:
        body (AllocationIn): `PUT /api/v3/allocations` — replace one employee's whole split.

            The employee is named in the BODY, never the URL: a name is PII and the
            URL is logged by every proxy on the way (§3.1 rule 5).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AllocationV3 | ErrorEnvelope
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
