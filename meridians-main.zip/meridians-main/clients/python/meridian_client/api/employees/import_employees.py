from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.imported_v3 import ImportedV3
from ...types import UNSET, Response


def _get_kwargs(
    *,
    entity: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["entity"] = entity

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v3/employees/import",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | ImportedV3 | None:
    if response.status_code == 200:
        response_200 = ImportedV3.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | ImportedV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    entity: str,
) -> Response[ErrorEnvelope | ImportedV3]:
    """Import Employees

     One-time import of the MX roster file (`mx_employees.seed`).

    Args:
        entity (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | ImportedV3]
    """

    kwargs = _get_kwargs(
        entity=entity,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    entity: str,
) -> ErrorEnvelope | ImportedV3 | None:
    """Import Employees

     One-time import of the MX roster file (`mx_employees.seed`).

    Args:
        entity (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | ImportedV3
    """

    return sync_detailed(
        client=client,
        entity=entity,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    entity: str,
) -> Response[ErrorEnvelope | ImportedV3]:
    """Import Employees

     One-time import of the MX roster file (`mx_employees.seed`).

    Args:
        entity (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | ImportedV3]
    """

    kwargs = _get_kwargs(
        entity=entity,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    entity: str,
) -> ErrorEnvelope | ImportedV3 | None:
    """Import Employees

     One-time import of the MX roster file (`mx_employees.seed`).

    Args:
        entity (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | ImportedV3
    """

    return (
        await asyncio_detailed(
            client=client,
            entity=entity,
        )
    ).parsed
