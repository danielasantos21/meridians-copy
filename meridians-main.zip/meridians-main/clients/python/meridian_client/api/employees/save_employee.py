from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.employee_v3 import EmployeeV3
from ...models.error_envelope import ErrorEnvelope
from ...models.mx_employee_in import MxEmployeeIn
from ...models.us_employee_in import UsEmployeeIn
from ...types import UNSET, Response


def _get_kwargs(
    employee_id: str,
    *,
    body: MxEmployeeIn | UsEmployeeIn,
    entity: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["entity"] = entity

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v3/employees/{employee_id}".format(
            employee_id=quote(str(employee_id), safe=""),
        ),
        "params": params,
    }

    if isinstance(body, MxEmployeeIn):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EmployeeV3 | ErrorEnvelope | None:
    if response.status_code == 200:
        response_200 = EmployeeV3.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EmployeeV3 | ErrorEnvelope]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    employee_id: str,
    *,
    client: AuthenticatedClient,
    body: MxEmployeeIn | UsEmployeeIn,
    entity: str,
) -> Response[EmployeeV3 | ErrorEnvelope]:
    """Save Employee

     Create or replace one row of this org's roster. 200 with the row as stored.

    Keyed on (this org, the code): a code another org also uses is a
    different row, so a PUT can only ever write the caller's own.

    Args:
        employee_id (str):
        entity (str):
        body (MxEmployeeIn | UsEmployeeIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EmployeeV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        employee_id=employee_id,
        body=body,
        entity=entity,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    employee_id: str,
    *,
    client: AuthenticatedClient,
    body: MxEmployeeIn | UsEmployeeIn,
    entity: str,
) -> EmployeeV3 | ErrorEnvelope | None:
    """Save Employee

     Create or replace one row of this org's roster. 200 with the row as stored.

    Keyed on (this org, the code): a code another org also uses is a
    different row, so a PUT can only ever write the caller's own.

    Args:
        employee_id (str):
        entity (str):
        body (MxEmployeeIn | UsEmployeeIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EmployeeV3 | ErrorEnvelope
    """

    return sync_detailed(
        employee_id=employee_id,
        client=client,
        body=body,
        entity=entity,
    ).parsed


async def asyncio_detailed(
    employee_id: str,
    *,
    client: AuthenticatedClient,
    body: MxEmployeeIn | UsEmployeeIn,
    entity: str,
) -> Response[EmployeeV3 | ErrorEnvelope]:
    """Save Employee

     Create or replace one row of this org's roster. 200 with the row as stored.

    Keyed on (this org, the code): a code another org also uses is a
    different row, so a PUT can only ever write the caller's own.

    Args:
        employee_id (str):
        entity (str):
        body (MxEmployeeIn | UsEmployeeIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EmployeeV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        employee_id=employee_id,
        body=body,
        entity=entity,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    employee_id: str,
    *,
    client: AuthenticatedClient,
    body: MxEmployeeIn | UsEmployeeIn,
    entity: str,
) -> EmployeeV3 | ErrorEnvelope | None:
    """Save Employee

     Create or replace one row of this org's roster. 200 with the row as stored.

    Keyed on (this org, the code): a code another org also uses is a
    different row, so a PUT can only ever write the caller's own.

    Args:
        employee_id (str):
        entity (str):
        body (MxEmployeeIn | UsEmployeeIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EmployeeV3 | ErrorEnvelope
    """

    return (
        await asyncio_detailed(
            employee_id=employee_id,
            client=client,
            body=body,
            entity=entity,
        )
    ).parsed
