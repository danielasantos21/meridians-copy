from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_client_usage_v3 import ApiClientUsageV3
from ...models.error_envelope import ErrorEnvelope
from ...types import UNSET, Response, Unset


def _get_kwargs(
    client_id: str,
    *,
    days: int | Unset = 30,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["days"] = days

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v3/admin/api-clients/{client_id}/usage".format(
            client_id=quote(str(client_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApiClientUsageV3 | ErrorEnvelope | None:
    if response.status_code == 200:
        response_200 = ApiClientUsageV3.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApiClientUsageV3 | ErrorEnvelope]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    client_id: str,
    *,
    client: AuthenticatedClient,
    days: int | Unset = 30,
) -> Response[ApiClientUsageV3 | ErrorEnvelope]:
    """Api Client Usage

     Last use, requests and errors per day, and recent addresses, over `days`.

    Counted from `audit.api_request` (T06) through revision 0016's aggregate
    functions: one client, this org, at most 90 days, never a raw audit row.

    Args:
        client_id (str):
        days (int | Unset):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiClientUsageV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        client_id=client_id,
        days=days,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    client_id: str,
    *,
    client: AuthenticatedClient,
    days: int | Unset = 30,
) -> ApiClientUsageV3 | ErrorEnvelope | None:
    """Api Client Usage

     Last use, requests and errors per day, and recent addresses, over `days`.

    Counted from `audit.api_request` (T06) through revision 0016's aggregate
    functions: one client, this org, at most 90 days, never a raw audit row.

    Args:
        client_id (str):
        days (int | Unset):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiClientUsageV3 | ErrorEnvelope
    """

    return sync_detailed(
        client_id=client_id,
        client=client,
        days=days,
    ).parsed


async def asyncio_detailed(
    client_id: str,
    *,
    client: AuthenticatedClient,
    days: int | Unset = 30,
) -> Response[ApiClientUsageV3 | ErrorEnvelope]:
    """Api Client Usage

     Last use, requests and errors per day, and recent addresses, over `days`.

    Counted from `audit.api_request` (T06) through revision 0016's aggregate
    functions: one client, this org, at most 90 days, never a raw audit row.

    Args:
        client_id (str):
        days (int | Unset):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiClientUsageV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        client_id=client_id,
        days=days,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    client_id: str,
    *,
    client: AuthenticatedClient,
    days: int | Unset = 30,
) -> ApiClientUsageV3 | ErrorEnvelope | None:
    """Api Client Usage

     Last use, requests and errors per day, and recent addresses, over `days`.

    Counted from `audit.api_request` (T06) through revision 0016's aggregate
    functions: one client, this org, at most 90 days, never a raw audit row.

    Args:
        client_id (str):
        days (int | Unset):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiClientUsageV3 | ErrorEnvelope
    """

    return (
        await asyncio_detailed(
            client_id=client_id,
            client=client,
            days=days,
        )
    ).parsed
