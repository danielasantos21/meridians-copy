from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_client_secret_v3 import ApiClientSecretV3
from ...models.error_envelope import ErrorEnvelope
from ...models.reason_v3 import ReasonV3
from ...types import Response


def _get_kwargs(
    client_id: str,
    *,
    body: ReasonV3,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v3/admin/api-clients/{client_id}/approve".format(
            client_id=quote(str(client_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApiClientSecretV3 | ErrorEnvelope | None:
    if response.status_code == 200:
        response_200 = ApiClientSecretV3.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = ErrorEnvelope.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApiClientSecretV3 | ErrorEnvelope]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    client_id: str,
    *,
    client: AuthenticatedClient,
    body: ReasonV3,
) -> Response[ApiClientSecretV3 | ErrorEnvelope]:
    """Approve Api Client

     Superadmin only. Creates the Cognito app client; the secret is in this answer ONCE.

    Args:
        client_id (str):
        body (ReasonV3): A state change that must say why (approve, revoke, disable, enable).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiClientSecretV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        client_id=client_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    client_id: str,
    *,
    client: AuthenticatedClient,
    body: ReasonV3,
) -> ApiClientSecretV3 | ErrorEnvelope | None:
    """Approve Api Client

     Superadmin only. Creates the Cognito app client; the secret is in this answer ONCE.

    Args:
        client_id (str):
        body (ReasonV3): A state change that must say why (approve, revoke, disable, enable).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiClientSecretV3 | ErrorEnvelope
    """

    return sync_detailed(
        client_id=client_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    client_id: str,
    *,
    client: AuthenticatedClient,
    body: ReasonV3,
) -> Response[ApiClientSecretV3 | ErrorEnvelope]:
    """Approve Api Client

     Superadmin only. Creates the Cognito app client; the secret is in this answer ONCE.

    Args:
        client_id (str):
        body (ReasonV3): A state change that must say why (approve, revoke, disable, enable).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiClientSecretV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        client_id=client_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    client_id: str,
    *,
    client: AuthenticatedClient,
    body: ReasonV3,
) -> ApiClientSecretV3 | ErrorEnvelope | None:
    """Approve Api Client

     Superadmin only. Creates the Cognito app client; the secret is in this answer ONCE.

    Args:
        client_id (str):
        body (ReasonV3): A state change that must say why (approve, revoke, disable, enable).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiClientSecretV3 | ErrorEnvelope
    """

    return (
        await asyncio_detailed(
            client_id=client_id,
            client=client,
            body=body,
        )
    ).parsed
