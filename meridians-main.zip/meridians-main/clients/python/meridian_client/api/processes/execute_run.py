from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.process_run_v3 import ProcessRunV3
from ...types import UNSET, Response, Unset


def _get_kwargs(
    run_id: UUID,
    *,
    idempotency_key: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(idempotency_key, Unset):
        headers["Idempotency-Key"] = idempotency_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v3/runs/{run_id}/actions/execute".format(
            run_id=quote(str(run_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | ProcessRunV3 | None:
    if response.status_code == 202:
        response_202 = ProcessRunV3.from_dict(response.json())

        return response_202

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 428:
        response_428 = ErrorEnvelope.from_dict(response.json())

        return response_428

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = ErrorEnvelope.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | ProcessRunV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    idempotency_key: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | ProcessRunV3]:
    """Start the run's execute job

     Start the run's `execute` job (the manifest's). Requires `Idempotency-Key`: a repeat with the same
    key replays, never books twice. Answers 202 with the run; poll `GET /runs/{run_id}`. An organization
    starts at most one job of a process per 30-second window and 30 an hour (`429 QUOTA_EXCEEDED` with
    `Retry-After`).

    Args:
        run_id (UUID):
        idempotency_key (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | ProcessRunV3]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        idempotency_key=idempotency_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    idempotency_key: None | str | Unset = UNSET,
) -> ErrorEnvelope | ProcessRunV3 | None:
    """Start the run's execute job

     Start the run's `execute` job (the manifest's). Requires `Idempotency-Key`: a repeat with the same
    key replays, never books twice. Answers 202 with the run; poll `GET /runs/{run_id}`. An organization
    starts at most one job of a process per 30-second window and 30 an hour (`429 QUOTA_EXCEEDED` with
    `Retry-After`).

    Args:
        run_id (UUID):
        idempotency_key (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | ProcessRunV3
    """

    return sync_detailed(
        run_id=run_id,
        client=client,
        idempotency_key=idempotency_key,
    ).parsed


async def asyncio_detailed(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    idempotency_key: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | ProcessRunV3]:
    """Start the run's execute job

     Start the run's `execute` job (the manifest's). Requires `Idempotency-Key`: a repeat with the same
    key replays, never books twice. Answers 202 with the run; poll `GET /runs/{run_id}`. An organization
    starts at most one job of a process per 30-second window and 30 an hour (`429 QUOTA_EXCEEDED` with
    `Retry-After`).

    Args:
        run_id (UUID):
        idempotency_key (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | ProcessRunV3]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        idempotency_key=idempotency_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    idempotency_key: None | str | Unset = UNSET,
) -> ErrorEnvelope | ProcessRunV3 | None:
    """Start the run's execute job

     Start the run's `execute` job (the manifest's). Requires `Idempotency-Key`: a repeat with the same
    key replays, never books twice. Answers 202 with the run; poll `GET /runs/{run_id}`. An organization
    starts at most one job of a process per 30-second window and 30 an hour (`429 QUOTA_EXCEEDED` with
    `Retry-After`).

    Args:
        run_id (UUID):
        idempotency_key (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | ProcessRunV3
    """

    return (
        await asyncio_detailed(
            run_id=run_id,
            client=client,
            idempotency_key=idempotency_key,
        )
    ).parsed
