from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.download_url_v3 import DownloadUrlV3
from ...models.error_envelope import ErrorEnvelope
from ...types import Response


def _get_kwargs(
    run_id: UUID,
    artifact_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v3/runs/{run_id}/artifacts/{artifact_id}/download-url".format(
            run_id=quote(str(run_id), safe=""),
            artifact_id=quote(str(artifact_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DownloadUrlV3 | ErrorEnvelope | None:
    if response.status_code == 200:
        response_200 = DownloadUrlV3.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DownloadUrlV3 | ErrorEnvelope]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    run_id: UUID,
    artifact_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DownloadUrlV3 | ErrorEnvelope]:
    """Mint a signed download URL

     A short-lived signed URL for one artifact. The mint is audited
    (`artifact_downloads`; for a `phi` file also `audit.phi_access`).

    Args:
        run_id (UUID):
        artifact_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DownloadUrlV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        artifact_id=artifact_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    run_id: UUID,
    artifact_id: str,
    *,
    client: AuthenticatedClient,
) -> DownloadUrlV3 | ErrorEnvelope | None:
    """Mint a signed download URL

     A short-lived signed URL for one artifact. The mint is audited
    (`artifact_downloads`; for a `phi` file also `audit.phi_access`).

    Args:
        run_id (UUID):
        artifact_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DownloadUrlV3 | ErrorEnvelope
    """

    return sync_detailed(
        run_id=run_id,
        artifact_id=artifact_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    run_id: UUID,
    artifact_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DownloadUrlV3 | ErrorEnvelope]:
    """Mint a signed download URL

     A short-lived signed URL for one artifact. The mint is audited
    (`artifact_downloads`; for a `phi` file also `audit.phi_access`).

    Args:
        run_id (UUID):
        artifact_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DownloadUrlV3 | ErrorEnvelope]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        artifact_id=artifact_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    run_id: UUID,
    artifact_id: str,
    *,
    client: AuthenticatedClient,
) -> DownloadUrlV3 | ErrorEnvelope | None:
    """Mint a signed download URL

     A short-lived signed URL for one artifact. The mint is audited
    (`artifact_downloads`; for a `phi` file also `audit.phi_access`).

    Args:
        run_id (UUID):
        artifact_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DownloadUrlV3 | ErrorEnvelope
    """

    return (
        await asyncio_detailed(
            run_id=run_id,
            artifact_id=artifact_id,
            client=client,
        )
    ).parsed
