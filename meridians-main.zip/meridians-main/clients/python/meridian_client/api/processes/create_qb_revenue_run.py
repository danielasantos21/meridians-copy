from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.process_run_v3 import ProcessRunV3
from ...models.qb_revenue_create_run_v3 import QbRevenueCreateRunV3
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: QbRevenueCreateRunV3,
    idempotency_key: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(idempotency_key, Unset):
        headers["Idempotency-Key"] = idempotency_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v3/processes/qb-revenue/runs",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | ProcessRunV3 | None:
    if response.status_code == 201:
        response_201 = ProcessRunV3.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 428:
        response_428 = ErrorEnvelope.from_dict(response.json())

        return response_428

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = ErrorEnvelope.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | ProcessRunV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: QbRevenueCreateRunV3,
    idempotency_key: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | ProcessRunV3]:
    """Create a QB Revenue run

     Start a QB Revenue run: a draft that takes its files next (`POST /runs/{run_id}/uploads`), then
    `execute`. A repeated `Idempotency-Key` returns the same run (200).

    Args:
        idempotency_key (None | str | Unset):
        body (QbRevenueCreateRunV3): `POST /api/v3/processes/qb-revenue/runs` — the create params.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | ProcessRunV3]
    """

    kwargs = _get_kwargs(
        body=body,
        idempotency_key=idempotency_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: QbRevenueCreateRunV3,
    idempotency_key: None | str | Unset = UNSET,
) -> ErrorEnvelope | ProcessRunV3 | None:
    """Create a QB Revenue run

     Start a QB Revenue run: a draft that takes its files next (`POST /runs/{run_id}/uploads`), then
    `execute`. A repeated `Idempotency-Key` returns the same run (200).

    Args:
        idempotency_key (None | str | Unset):
        body (QbRevenueCreateRunV3): `POST /api/v3/processes/qb-revenue/runs` — the create params.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | ProcessRunV3
    """

    return sync_detailed(
        client=client,
        body=body,
        idempotency_key=idempotency_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: QbRevenueCreateRunV3,
    idempotency_key: None | str | Unset = UNSET,
) -> Response[ErrorEnvelope | ProcessRunV3]:
    """Create a QB Revenue run

     Start a QB Revenue run: a draft that takes its files next (`POST /runs/{run_id}/uploads`), then
    `execute`. A repeated `Idempotency-Key` returns the same run (200).

    Args:
        idempotency_key (None | str | Unset):
        body (QbRevenueCreateRunV3): `POST /api/v3/processes/qb-revenue/runs` — the create params.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | ProcessRunV3]
    """

    kwargs = _get_kwargs(
        body=body,
        idempotency_key=idempotency_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: QbRevenueCreateRunV3,
    idempotency_key: None | str | Unset = UNSET,
) -> ErrorEnvelope | ProcessRunV3 | None:
    """Create a QB Revenue run

     Start a QB Revenue run: a draft that takes its files next (`POST /runs/{run_id}/uploads`), then
    `execute`. A repeated `Idempotency-Key` returns the same run (200).

    Args:
        idempotency_key (None | str | Unset):
        body (QbRevenueCreateRunV3): `POST /api/v3/processes/qb-revenue/runs` — the create params.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | ProcessRunV3
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            idempotency_key=idempotency_key,
        )
    ).parsed
