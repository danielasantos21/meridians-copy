from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_envelope import ErrorEnvelope
from ...models.upload_grant_v3 import UploadGrantV3
from ...models.upload_request_v3 import UploadRequestV3
from ...types import Response


def _get_kwargs(
    run_id: UUID,
    *,
    body: UploadRequestV3,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v3/runs/{run_id}/uploads".format(
            run_id=quote(str(run_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorEnvelope | UploadGrantV3 | None:
    if response.status_code == 201:
        response_201 = UploadGrantV3.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ErrorEnvelope.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorEnvelope.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ErrorEnvelope.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ErrorEnvelope.from_dict(response.json())

        return response_409

    if response.status_code == 413:
        response_413 = ErrorEnvelope.from_dict(response.json())

        return response_413

    if response.status_code == 415:
        response_415 = ErrorEnvelope.from_dict(response.json())

        return response_415

    if response.status_code == 422:
        response_422 = ErrorEnvelope.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ErrorEnvelope.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorEnvelope.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = ErrorEnvelope.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorEnvelope | UploadGrantV3]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    body: UploadRequestV3,
) -> Response[ErrorEnvelope | UploadGrantV3]:
    """Get a pre-signed upload for a run

     A pre-signed POST for one input file of a draft run (5 minutes).

    Send the returned `fields` and then the file to `url`. The policy pins
    the key, this `content_type` and the input's size limit; the object is
    scanned for malware on arrival and nothing reads it until it is clean.

    Args:
        run_id (UUID):
        body (UploadRequestV3): `POST /api/v3/runs/{run_id}/uploads` — ask for one pre-signed
            upload.

            `role` may be left out when the process takes one input. The pre-signed
            POST then holds S3 to this `content_type` and to at most the input's
            `max_bytes`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | UploadGrantV3]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    body: UploadRequestV3,
) -> ErrorEnvelope | UploadGrantV3 | None:
    """Get a pre-signed upload for a run

     A pre-signed POST for one input file of a draft run (5 minutes).

    Send the returned `fields` and then the file to `url`. The policy pins
    the key, this `content_type` and the input's size limit; the object is
    scanned for malware on arrival and nothing reads it until it is clean.

    Args:
        run_id (UUID):
        body (UploadRequestV3): `POST /api/v3/runs/{run_id}/uploads` — ask for one pre-signed
            upload.

            `role` may be left out when the process takes one input. The pre-signed
            POST then holds S3 to this `content_type` and to at most the input's
            `max_bytes`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | UploadGrantV3
    """

    return sync_detailed(
        run_id=run_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    body: UploadRequestV3,
) -> Response[ErrorEnvelope | UploadGrantV3]:
    """Get a pre-signed upload for a run

     A pre-signed POST for one input file of a draft run (5 minutes).

    Send the returned `fields` and then the file to `url`. The policy pins
    the key, this `content_type` and the input's size limit; the object is
    scanned for malware on arrival and nothing reads it until it is clean.

    Args:
        run_id (UUID):
        body (UploadRequestV3): `POST /api/v3/runs/{run_id}/uploads` — ask for one pre-signed
            upload.

            `role` may be left out when the process takes one input. The pre-signed
            POST then holds S3 to this `content_type` and to at most the input's
            `max_bytes`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorEnvelope | UploadGrantV3]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    run_id: UUID,
    *,
    client: AuthenticatedClient,
    body: UploadRequestV3,
) -> ErrorEnvelope | UploadGrantV3 | None:
    """Get a pre-signed upload for a run

     A pre-signed POST for one input file of a draft run (5 minutes).

    Send the returned `fields` and then the file to `url`. The policy pins
    the key, this `content_type` and the input's size limit; the object is
    scanned for malware on arrival and nothing reads it until it is clean.

    Args:
        run_id (UUID):
        body (UploadRequestV3): `POST /api/v3/runs/{run_id}/uploads` — ask for one pre-signed
            upload.

            `role` may be left out when the process takes one input. The pre-signed
            POST then holds S3 to this `content_type` and to at most the input's
            `max_bytes`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorEnvelope | UploadGrantV3
    """

    return (
        await asyncio_detailed(
            run_id=run_id,
            client=client,
            body=body,
        )
    ).parsed
