#!/usr/bin/env python3
"""
Unposted JE Generation CLI

Generates "Unposted" journal entries by comparing revenue JEs with bank deposits.

Usage:
    python process_unposted.py --period P01 --year FY26
"""

import logging
import sys
from datetime import datetime
from pathlib import Path

import click

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from src.config import Config
from src.unposted_generator import UnpostedGenerator

# Configure logging
logging.basicConfig(
    level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@click.command()
@click.option('--period', '-p', required=True, help='Fiscal period (e.g., P01, P12)')
@click.option('--year', '-y', required=True, help='Fiscal year (e.g., FY26)')
@click.option(
    '--date',
    '-d',
    'je_date',
    default=None,
    help='Journal entry date (YYYY-MM-DD, defaults to fiscal calendar date)',
)
@click.option(
    '--je-dir', default='output/journal_entries', help='Directory containing revenue JE files'
)
@click.option(
    '--bank-file', default='Resources/Bankaccount.xlsx', help='Path to bank account Excel file'
)
@click.option(
    '--output-dir', default='output/journal_entries', help='Directory for output unposted JE files'
)
@click.option(
    '--config',
    '-c',
    'config_path',
    default='config/mappings.xlsx',
    help='Path to config/mappings file',
)
def main(period, year, je_date, je_dir, bank_file, output_dir, config_path):
    """
    Generate unposted journal entries.

    Compares total revenue (clinic + hospital JEs) with bank deposits
    and generates allocation-based unposted JEs for each clinic group.

    Example:
        python process_unposted.py --period P01 --year FY26
    """
    try:
        click.echo("=" * 60)
        click.echo("Unposted JE Generation")
        click.echo("=" * 60)
        click.echo(f"Period: {period}")
        click.echo(f"Fiscal Year: {year}")
        click.echo(f"JE Directory: {je_dir}")
        click.echo(f"Bank File: {bank_file}")

        # Load config to get subsidiary and clearing account
        config = Config(config_path)
        config.load()

        # Get JE date from fiscal calendar if not provided
        if je_date is None:
            je_date = config.get_je_date(year, period)
            if je_date:
                click.echo(f"JE Date: {je_date} (from fiscal calendar)")
            else:
                je_date = datetime.now().strftime("%Y-%m-%d")
                click.echo(f"JE Date: {je_date} (today - no fiscal calendar entry)")
        else:
            click.echo(f"JE Date: {je_date}")

        click.echo("")

        # Create generator
        generator = UnpostedGenerator(
            je_dir=je_dir,
            bank_file=bank_file,
            output_dir=output_dir,
            subsidiary=config.settings.subsidiary,
            clearing_account=config.settings.clearing_account,
        )

        # Generate and export
        results, output_files = generator.generate_and_export(
            je_date=je_date, period=period, fiscal_year=year
        )

        # Display summary
        click.echo("\n" + "=" * 60)
        click.echo("SUMMARY")
        click.echo("=" * 60)

        total_positive = 0
        total_negative = 0
        negative_groups = []

        for clinic_group, result in sorted(results.items()):
            status = ""
            if result.is_negative:
                status = "[NEGATIVE]"
                total_negative += result.unposted_amount
                negative_groups.append(clinic_group)
            else:
                total_positive += result.unposted_amount

            click.echo(
                f"{clinic_group:12} | Revenue: ${result.total_revenue:>12,.2f} | "
                f"Bank: ${result.bank_deposit:>12,.2f} | "
                f"Unposted: ${result.unposted_amount:>12,.2f} {status}"
            )

        click.echo("-" * 60)
        click.echo(f"Total Positive Unposted: ${total_positive:,.2f}")
        click.echo(f"Total Negative Unposted: ${total_negative:,.2f}")
        click.echo(f"Net Unposted: ${total_positive + total_negative:,.2f}")

        if negative_groups:
            click.echo(
                f"\nWARNING: {len(negative_groups)} groups have negative unposted (bank > revenue):"
            )
            for group in negative_groups:
                click.echo(f"  - {group}")

        click.echo("\nOutput Files:")
        for clinic_group, filepath in sorted(output_files.items()):
            click.echo(f"  {filepath}")

        click.echo("\n" + "=" * 60)
        click.echo("Unposted JE generation completed successfully")
        click.echo("=" * 60)

        sys.exit(0)

    except FileNotFoundError as e:
        click.echo(f"\nERROR: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"\nERROR: {e}", err=True)
        logger.exception("Unposted generation failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
