#!/usr/bin/env python3
"""
Revenue Automation CLI

Processes billing system exports and generates NetSuite journal entries.

Usage:
    python process_revenue.py --input "path/to/file.xlsx" --period P12 --year FY25
"""

import logging
import sys
from datetime import datetime
from pathlib import Path

import click
import pandas as pd

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from src.aggregation import TransactionAggregator
from src.config import Config
from src.database import Database
from src.enrichment import TransactionEnricher
from src.exporters import (
    ArchiveManager,
    EnrichedDataExporter,
    JournalEntryExporter,
    RevenueWorkbookExporter,
    ValidationReportExporter,
)
from src.fiscal_calendar import FiscalCalendar
from src.hospital_enrichment import HospitalEnricher
from src.hospital_reader import HospitalReader
from src.je_generator import JournalEntryGenerator
from src.unposted_generator import UnpostedGenerator
from src.utils import (
    calculate_file_hash,
    format_fiscal_year,
    format_period,
    parse_fiscal_year,
    parse_period,
)


def parse_overview_sheet(input_file: str) -> dict:
    """Parse the Overview sheet to get the full summary table.

    Returns a dict with:
    - rows: list of dicts with group data
    - payments_total: total payments from the Overview sheet
    """
    try:
        df = pd.read_excel(input_file, sheet_name='Overview', header=None)
    except Exception:
        # Overview sheet doesn't exist
        return None

    overview_rows = []
    payments_total = 0

    # Row 0 is header, rows 1-9 are data (groups + Total)
    for idx in range(1, min(len(df), 10)):  # Rows 1-9
        row = df.iloc[idx]
        group_name = row.iloc[0]
        if pd.isna(group_name):
            continue

        group_name = str(group_name).strip()

        # Extract values, handling NaN
        bank_total = float(row.iloc[1]) if pd.notna(row.iloc[1]) else None
        bank_net = float(row.iloc[2]) if pd.notna(row.iloc[2]) else None
        payments = float(row.iloc[3]) if pd.notna(row.iloc[3]) else None
        unpost_total = float(row.iloc[4]) if pd.notna(row.iloc[4]) else None
        unpost_net = float(row.iloc[5]) if pd.notna(row.iloc[5]) else None
        pct_unpost_total = float(row.iloc[6]) if pd.notna(row.iloc[6]) else None
        pct_unpost_net = float(row.iloc[7]) if pd.notna(row.iloc[7]) else None

        row_data = {
            "group": group_name,
            "bank_total": bank_total,
            "bank_net": bank_net,
            "payments": payments,
            "unpost_total": unpost_total,
            "unpost_net": unpost_net,
            "pct_unpost_total": pct_unpost_total,
            "pct_unpost_net": pct_unpost_net,
        }
        overview_rows.append(row_data)

        # Track total payments
        if group_name == 'Total' and payments is not None:
            payments_total = payments

    return {"rows": overview_rows, "payments_total": payments_total}


# Configure logging
logging.basicConfig(
    level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class RevenueProcessor:
    """Main processor for revenue automation."""

    def __init__(
        self,
        config_path: str = "config/mappings.xlsx",
        db_path: str | None = None,  # None: $MERIDIAN_SQLITE_PATH, else data/revenue.db
        calendar_path: str = "data/Calendar/Calendar.xlsx",
    ):
        self.config = Config(config_path)
        self.db = Database(db_path)
        self.fiscal_calendar = FiscalCalendar(calendar_path)
        self.enricher = None
        self.aggregator = TransactionAggregator()
        self.je_generator = None

        # Exporters
        self.je_exporter = JournalEntryExporter()
        self.data_exporter = EnrichedDataExporter()
        self.report_exporter = ValidationReportExporter()
        self.workbook_exporter = RevenueWorkbookExporter()
        self.archive_manager = ArchiveManager()

    def process(
        self,
        input_file: str,
        period: str,
        fiscal_year: str,
        je_date: str = None,
        force: bool = False,
        unposted_entries: dict = None,
    ) -> dict:
        """
        Process revenue file and generate outputs.

        Args:
            input_file: Path to input Excel file
            period: Period string (e.g., "P12")
            fiscal_year: Fiscal year string (e.g., "FY25")
            je_date: Optional journal entry date (defaults to today)
            force: Force reprocessing even if file was already processed

        Returns:
            Dict with processing results
        """
        logger.info(f"Starting revenue processing for {period} {fiscal_year}")
        logger.info(f"Input file: {input_file}")

        # Validate input file
        input_path = Path(input_file)
        if not input_path.exists():
            raise FileNotFoundError(f"Input file not found: {input_file}")

        # Parse period and year
        period_int = parse_period(period)
        year_int = parse_fiscal_year(fiscal_year)
        period_str = format_period(period_int)
        year_str = format_fiscal_year(year_int)

        # Calculate file hash for duplicate detection
        file_hash = calculate_file_hash(input_file)

        # Check for duplicate processing
        existing_batch = self.db.check_duplicate_batch(file_hash, year_int, period_int)
        if existing_batch:
            if not force:
                logger.warning(f"File already processed in batch {existing_batch['id']}")
                logger.warning("Use --force to reprocess")
                return {
                    "status": "skipped",
                    "reason": "duplicate",
                    "existing_batch_id": existing_batch["id"],
                }
            else:
                # Delete existing batch to allow reprocessing
                logger.info(f"Force flag set - deleting existing batch {existing_batch['id']}")
                self.db.delete_batch(existing_batch['id'])

        # Load configuration
        logger.info("Loading configuration...")
        self.config.load()
        self.fiscal_calendar.load()
        self.enricher = TransactionEnricher(self.config)
        self.je_generator = JournalEntryGenerator(self.config.settings)

        # Create batch
        batch_id = self.db.create_batch(
            fiscal_year=year_int, period=period_int, input_file=input_file, file_hash=file_hash
        )

        # Parse and store Overview sheet data
        overview_data = parse_overview_sheet(input_file)
        if overview_data:
            self.db.update_batch_overview(batch_id, overview_data)
            logger.info(
                f"Stored Overview data: payments total ${overview_data['payments_total']:,.2f}"
            )

        try:
            # Read input data
            logger.info("Reading input file...")
            df = self._read_input_file(input_file)
            logger.info(f"Read {len(df)} transactions from input file")

            # Enrich transactions
            logger.info("Enriching transactions with mappings...")
            enrichment_result = self.enricher.enrich_dataframe(df)

            # Store transactions in database
            logger.info("Storing transactions in database...")
            self.db.insert_transactions(batch_id, enrichment_result.transactions)

            # Store unmapped items
            unmapped_items = self._collect_unmapped_items(enrichment_result)
            if unmapped_items:
                self.db.insert_unmapped_items(batch_id, unmapped_items)

            # Validate transaction periods against fiscal calendar
            logger.info("Validating transaction periods...")
            enrichment_result = self.enricher.validate_periods(
                enrichment_result, self.fiscal_calendar, year_str, period_int
            )

            # Aggregate by location (creates 15 location-level groups instead of 11 clinic groups)
            logger.info("Aggregating transactions by location...")
            aggregated = self.aggregator.aggregate_by_location(enrichment_result.transactions)

            # Generate journal entries
            # Use fiscal calendar date if not explicitly provided
            if je_date is None:
                je_date = self.config.get_je_date(year_str, period_str)
                if je_date:
                    logger.info(f"Using fiscal calendar date: {je_date}")
                else:
                    logger.warning(
                        f"No fiscal calendar entry for {year_str} {period_str}, using today's date"
                    )
                    je_date = datetime.now().strftime("%Y-%m-%d")

            logger.info("Generating journal entries...")
            journal_entries = self.je_generator.generate_journal_entries(
                aggregated, je_date, period_str, year_str, by_location=True
            )

            # Store journal entries in database
            je_dict_list = self.je_generator.convert_to_dict_list(journal_entries)
            self.db.insert_journal_entries(batch_id, je_dict_list)

            # Export journal entry CSVs
            logger.info("Exporting journal entry files...")
            je_files = self.je_exporter.export_to_csv(
                journal_entries, period_str, year_str, by_location=True
            )

            # Process hospital sheets
            hospital_reader = HospitalReader()
            hospital_sheets = hospital_reader.detect_hospital_sheets(input_file)
            hospital_je_files = {}
            hospital_enrichment_result = None

            if hospital_sheets:
                logger.info(f"Processing {len(hospital_sheets)} hospital sheets...")

                # Read all hospital data
                hospital_data = hospital_reader.read_all_hospitals(input_file)

                if hospital_data:
                    # Enrich hospital transactions with provider mappings
                    hospital_enricher = HospitalEnricher(self.config)
                    hospital_enrichment_result = hospital_enricher.enrich_transactions(
                        hospital_data
                    )

                    # Generate hospital JEs
                    hospital_entries = self.je_generator.generate_hospital_entries(
                        hospital_enrichment_result.transactions, je_date, period_str, year_str
                    )

                    # Export hospital JE files
                    hospital_je_files = self.je_exporter.export_to_csv(
                        hospital_entries, period_str, year_str, by_location=True
                    )

                    # Merge hospital JE files into main je_files dict
                    je_files.update(hospital_je_files)

                    logger.info(f"Generated {len(hospital_je_files)} hospital JE files")

                    # Log hospital totals
                    hospital_totals = hospital_reader.get_hospital_totals(hospital_data)
                    for hospital_name, total in hospital_totals.items():
                        logger.info(f"  {hospital_name}: ${total:,.2f}")

            # Also emit QuickBooks Online revenue JE files alongside the NetSuite CSVs
            # (dual output for the NetSuite->QB migration; failure can't break NetSuite).
            from src.revenue_qb_exporter import export_revenue_qb

            hospital_txns = (
                hospital_enrichment_result.transactions if hospital_enrichment_result else None
            )
            export_revenue_qb(
                output_dir=str(self.je_exporter.output_dir),
                clinic_transactions=enrichment_result.transactions,
                hospital_transactions=hospital_txns,
                unposted_entries=unposted_entries,
                je_date=je_date,
                period_str=period_str,
                fiscal_year=year_str,
            )

            # Export enriched data
            logger.info("Exporting enriched data...")
            enriched_df = self.enricher.create_enriched_dataframe(df, enrichment_result)
            enriched_file = self.data_exporter.export_to_excel(enriched_df, period_str, year_str)

            # Export validation report (with enhanced validations)
            logger.info("Exporting validation report...")
            report_file = self.report_exporter.export_report(
                enrichment_result,
                enrichment_result.transactions,
                period_str,
                year_str,
                input_path.name,
                journal_entries=journal_entries,
                original_df=df,
            )

            # Export comprehensive revenue workbook
            logger.info("Exporting revenue workbook...")
            workbook_file = self.workbook_exporter.export_workbook(
                enriched_df=enriched_df,
                je_entries=journal_entries,
                config=self.config,
                period=period_str,
                fiscal_year=year_str,
                unposted_entries=unposted_entries,
            )

            # Save data for potential re-export with unposted entries
            self._workbook_data = {
                'enriched_df': enriched_df,
                'je_entries': journal_entries,
                'period': period_str,
                'fiscal_year': year_str,
            }

            # Archive output files
            logger.info("Archiving output files...")
            all_output_files = {
                **je_files,
                "enriched_data": enriched_file,
                "validation_report": report_file,
                "revenue_workbook": workbook_file,
            }
            archive_path = self.archive_manager.archive_output(
                all_output_files, year_str, period_str
            )

            # Update batch status
            self.db.update_batch_status(
                batch_id,
                status="completed",
                record_count=enrichment_result.total_records,
                total_amount=enrichment_result.total_amount,
            )

            # Calculate combined totals including hospital data
            total_records = enrichment_result.total_records
            total_amount = enrichment_result.total_amount
            unmapped_hospital_providers = 0

            if hospital_enrichment_result:
                total_records += hospital_enrichment_result.total_records
                total_amount += hospital_enrichment_result.total_amount
                unmapped_hospital_providers = len(hospital_enrichment_result.unmapped_providers)

            # Prepare result summary
            result = {
                "status": "completed",
                "batch_id": batch_id,
                "period": period_str,
                "fiscal_year": year_str,
                "statistics": {
                    "total_records": total_records,
                    "mapped_records": enrichment_result.mapped_records,
                    "partial_records": enrichment_result.partial_records,
                    "unmapped_records": enrichment_result.unmapped_records,
                    "total_amount": total_amount,
                    "locations": len(aggregated),  # Clinic locations
                    "clinic_records": enrichment_result.total_records,
                    "clinic_amount": enrichment_result.total_amount,
                },
                "output_files": {
                    "journal_entries": je_files,
                    "enriched_data": enriched_file,
                    "validation_report": report_file,
                    "revenue_workbook": workbook_file,
                    "archive": archive_path,
                },
                "unmapped_summary": {
                    "payers": len(enrichment_result.unmapped_payers),
                    "facilities": len(enrichment_result.unmapped_facilities),
                    "providers": len(enrichment_result.unmapped_providers),
                },
                "period_validation": {
                    "validated": enrichment_result.period_validated,
                    "errors": len(enrichment_result.period_validation_errors),
                },
            }

            # Add hospital statistics if processed
            if hospital_enrichment_result:
                result["statistics"]["hospital_records"] = hospital_enrichment_result.total_records
                result["statistics"]["hospital_amount"] = hospital_enrichment_result.total_amount
                result["statistics"]["hospitals"] = len(hospital_je_files)
                result["unmapped_summary"]["hospital_providers"] = unmapped_hospital_providers

            logger.info("=" * 60)
            logger.info("PROCESSING COMPLETE")
            logger.info("=" * 60)
            logger.info(f"Batch ID: {batch_id}")
            logger.info(f"Clinic Records: {enrichment_result.total_records}")
            logger.info(f"Clinic Amount: ${enrichment_result.total_amount:,.2f}")
            if hospital_enrichment_result:
                logger.info(f"Hospital Records: {hospital_enrichment_result.total_records}")
                logger.info(f"Hospital Amount: ${hospital_enrichment_result.total_amount:,.2f}")
            logger.info(f"Total Amount: ${total_amount:,.2f}")
            logger.info(
                f"Mapping Rate: {(enrichment_result.mapped_records / enrichment_result.total_records * 100):.1f}%"
            )
            logger.info(f"Journal Entry Files: {len(je_files)}")

            if enrichment_result.unmapped_payers or enrichment_result.unmapped_facilities:
                logger.warning(
                    f"Unmapped Items: {len(enrichment_result.unmapped_payers)} payers, "
                    f"{len(enrichment_result.unmapped_facilities)} facilities, "
                    f"{len(enrichment_result.unmapped_providers)} clinic providers"
                )
                logger.warning(f"Review validation report: {report_file}")

            if hospital_enrichment_result and hospital_enrichment_result.unmapped_providers:
                logger.warning(f"Unmapped Hospital Providers: {unmapped_hospital_providers}")
                for provider, data in list(hospital_enrichment_result.unmapped_providers.items())[
                    :5
                ]:
                    logger.warning(
                        f"  {provider}: {data['count']} transactions, ${data['amount']:,.2f}"
                    )

            return result

        except Exception as e:
            logger.error(f"Processing failed: {e}")
            self.db.update_batch_status(batch_id, status="failed")
            raise

    def re_export_workbook(self, unposted_entries: dict) -> str:
        """Re-export the revenue workbook with unposted entries included."""
        if not hasattr(self, '_workbook_data'):
            raise RuntimeError("No workbook data available - run process() first")
        data = self._workbook_data
        return self.workbook_exporter.export_workbook(
            enriched_df=data['enriched_df'],
            je_entries=data['je_entries'],
            config=self.config,
            period=data['period'],
            fiscal_year=data['fiscal_year'],
            unposted_entries=unposted_entries,
        )

    def _read_input_file(self, input_file: str) -> pd.DataFrame:
        """Read the input Excel file."""
        # Try to read "All clinics" sheet first
        try:
            df = pd.read_excel(input_file, sheet_name="All clinics")
            logger.info(f"Read 'All clinics' sheet with {len(df)} rows")
            return df
        except ValueError:
            pass

        # Fall back to first sheet
        df = pd.read_excel(input_file, sheet_name=0)
        logger.info(f"Read first sheet with {len(df)} rows")
        return df

    def _collect_unmapped_items(self, result) -> list:
        """Collect unmapped items for database storage."""
        items = []

        for payer, data in result.unmapped_payers.items():
            items.append(
                {
                    "item_type": "payer",
                    "original_value": payer,
                    "occurrence_count": data["count"],
                    "total_amount": data["amount"],
                }
            )

        for facility, data in result.unmapped_facilities.items():
            items.append(
                {
                    "item_type": "facility",
                    "original_value": facility,
                    "occurrence_count": data["count"],
                    "total_amount": data["amount"],
                }
            )

        for provider, data in result.unmapped_providers.items():
            items.append(
                {
                    "item_type": "provider",
                    "original_value": provider,
                    "occurrence_count": data["count"],
                    "total_amount": data["amount"],
                }
            )

        return items


@click.command()
@click.option('--input', '-i', 'input_file', required=True, help='Path to input Excel file')
@click.option(
    '--period',
    '-p',
    required=False,
    default=None,
    help='Fiscal period (e.g., P12, P01). Auto-detected from transaction dates if not specified.',
)
@click.option(
    '--year',
    '-y',
    required=False,
    default=None,
    help='Fiscal year (e.g., FY25, 2025). Auto-detected from transaction dates if not specified.',
)
@click.option(
    '--date',
    '-d',
    'je_date',
    default=None,
    help='Journal entry date (YYYY-MM-DD, defaults to today)',
)
@click.option(
    '--config',
    '-c',
    'config_path',
    default='config/mappings.xlsx',
    help='Path to config/mappings file',
)
@click.option(
    '--db',
    'db_path',
    default=None,
    help='Path to SQLite database (default: $MERIDIAN_SQLITE_PATH, else data/revenue.db)',
)
@click.option(
    '--calendar',
    'calendar_path',
    default='data/Calendar/Calendar.xlsx',
    help='Path to fiscal calendar Excel file',
)
@click.option(
    '--force', '-f', is_flag=True, help='Force reprocessing even if file was already processed'
)
@click.option(
    '--unposted', '-u', is_flag=True, help='Generate unposted JEs after processing revenue JEs'
)
def main(input_file, period, year, je_date, config_path, db_path, calendar_path, force, unposted):
    """
    Process revenue data and generate NetSuite journal entries.

    Takes billing system export Excel file and produces:
    - Journal entry CSV files for each clinic group
    - Enriched transaction data with mappings applied
    - Validation report with unmapped items

    Example:
        python process_revenue.py --input data/input/revenue.xlsx --period P12 --year FY25

    Period and year are auto-detected from transaction dates if not specified.
    """
    try:
        processor = RevenueProcessor(
            config_path=config_path, db_path=db_path, calendar_path=calendar_path
        )

        # Auto-detect period and year if not provided
        auto_detected = False
        if period is None or year is None:
            click.echo("\nAuto-detecting period and fiscal year from transaction dates...")

            # Load fiscal calendar first
            processor.fiscal_calendar.load()

            # Read transaction dates from input file
            df = pd.read_excel(input_file, sheet_name="All clinics")
            if "Transaction Date" not in df.columns:
                click.echo(
                    "ERROR: Cannot auto-detect - 'Transaction Date' column not found", err=True
                )
                sys.exit(1)

            transaction_dates = df["Transaction Date"].dropna().tolist()
            if not transaction_dates:
                click.echo("ERROR: Cannot auto-detect - no transaction dates found", err=True)
                sys.exit(1)

            detected_year, detected_period, stats = (
                processor.fiscal_calendar.detect_period_from_dates(transaction_dates)
            )

            if detected_year is None or detected_period is None:
                click.echo("ERROR: Could not detect period from transaction dates", err=True)
                click.echo("Please specify --period and --year manually", err=True)
                sys.exit(1)

            # Use detected values if not manually specified
            if year is None:
                year = detected_year
            if period is None:
                period = f"P{detected_period:02d}"

            auto_detected = True

            # Show detection results
            click.echo(f"\n{'=' * 60}")
            click.echo(f"AUTO-DETECTED: {period} {year}")
            click.echo(f"{'=' * 60}")
            if len(stats) > 1:
                click.echo("Period distribution in transaction dates:")
                for period_key, count in stats.items():
                    pct = count / sum(stats.values()) * 100
                    marker = " <-- SELECTED" if period_key == f"{year} - {detected_period}" else ""
                    click.echo(f"  {period_key}: {count:,} dates ({pct:.1f}%){marker}")
            else:
                click.echo(f"All {sum(stats.values()):,} transaction dates are in {period} {year}")
            click.echo("")

        result = processor.process(
            input_file=input_file, period=period, fiscal_year=year, je_date=je_date, force=force
        )

        # Add auto-detection info to result for display
        if auto_detected:
            result["auto_detected"] = True

        if result["status"] == "completed":
            click.echo("\n" + "=" * 60)
            click.echo("SUCCESS - Revenue processing completed")
            click.echo("=" * 60)
            click.echo("\nOutput Files:")
            for name, path in result["output_files"].items():
                if isinstance(path, dict):
                    for clinic, file_path in path.items():
                        click.echo(f"  - {clinic}: {file_path}")
                else:
                    click.echo(f"  - {name}: {path}")

            if (
                result["unmapped_summary"]["payers"] > 0
                or result["unmapped_summary"]["facilities"] > 0
            ):
                click.echo("\nWARNING: Some items could not be mapped")
                click.echo(f"  Review: {result['output_files']['validation_report']}")

            # Generate unposted JEs if requested
            if unposted:
                click.echo("\n" + "=" * 60)
                click.echo("Generating Unposted Journal Entries...")
                click.echo("=" * 60)

                # Get the JE date that was used for revenue JEs
                used_je_date = je_date
                if used_je_date is None:
                    # Use the same date logic as revenue processing
                    processor.config.load()
                    used_je_date = processor.config.get_je_date(year, period)
                    if used_je_date is None:
                        used_je_date = datetime.now().strftime("%Y-%m-%d")

                unposted_gen = UnpostedGenerator(
                    je_dir="output/journal_entries",
                    bank_file="Resources/Bankaccount.xlsx",
                    output_dir="output/journal_entries",
                    subsidiary=processor.config.settings.subsidiary,
                    clearing_account=processor.config.settings.clearing_account,
                )

                try:
                    # Use normalized period/year from processing result
                    norm_period = result['period']
                    norm_year = result['fiscal_year']

                    # Step-by-step so we can capture entries for workbook
                    unposted_results = unposted_gen.calculate_unposted(norm_period, norm_year)
                    unposted_entries = unposted_gen.generate_unposted_entries(
                        unposted_results, used_je_date, norm_period, norm_year
                    )
                    unposted_files = unposted_gen.export_unposted_jes(
                        unposted_entries, norm_period, norm_year
                    )

                    click.echo("\nUnposted JE Summary:")
                    for clinic_group, res in unposted_results.items():
                        status = "NEGATIVE (bank > revenue)" if res.is_negative else ""
                        click.echo(
                            f"  {clinic_group}: Revenue=${res.total_revenue:,.2f}, "
                            f"Bank=${res.bank_deposit:,.2f}, "
                            f"Unposted=${res.unposted_amount:,.2f} {status}"
                        )

                    click.echo("\nUnposted JE Files:")
                    for clinic_group, filepath in unposted_files.items():
                        click.echo(f"  - {clinic_group}: {filepath}")

                    # Re-export workbook with unposted entries included
                    click.echo("\nRe-exporting workbook with unposted entries...")
                    processor.re_export_workbook(unposted_entries)
                    click.echo("Workbook updated with unposted entries.")

                except Exception as e:
                    click.echo(f"\nERROR generating unposted JEs: {e}", err=True)
                    logger.exception("Unposted generation failed")

            sys.exit(0)

        elif result["status"] == "skipped":
            click.echo(f"\nSKIPPED - File already processed (batch {result['existing_batch_id']})")
            click.echo("Use --force to reprocess")
            sys.exit(0)

    except FileNotFoundError as e:
        click.echo(f"\nERROR: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"\nERROR: {e}", err=True)
        logger.exception("Processing failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
