"""The backup-freshness checker — alarm on backups that silently STOPPED, not only failed.

Tracker T:160 (Codex G-M1). The Phase 6 backup alarms are EventBridge rules on
`Backup Job State Change` / `Copy Job State Change` failures, so they see a job that ran
and failed. They cannot see a job that never ran: a disabled plan, a selection tag that
changed, an S3 opt-in switched off — each simply produces no event. This function asks
the vaults what they actually hold, once every few hours, and publishes the ages:

* `RecoveryPointAgeHours`, `Resource=<label>` — the newest COMPLETED recovery point in
  the local vault for each protected resource (the RDS instance and the buckets named in
  `PROTECTED_RESOURCES`).
* `RecoveryPointAgeHours`, `Resource=dr` — the newest COMPLETED copy in the DR vault, in
  the DR region.
* `RestorableLagHours`, `Resource=rds` — how far RDS's `LatestRestorableTime` (the
  point-in-time-recovery edge) is behind now.
* `MissingRecoveryPoints` — how many of the above have no recovery point at all.
* `CheckerRuns` — 1, published LAST, so a run that raised publishes no heartbeat and the
  heartbeat alarm (`observability.py`) fires on the silence.

Everything is in `Meridian/Backup` with an `Environment` dimension. ARNs, vault names and
ages only; no recovery-point content is read, and nothing here can restore or delete —
the role is list/describe plus one metric namespace.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Callable

logger = logging.getLogger()
logger.setLevel(logging.INFO)

NAMESPACE = "Meridian/Backup"


def _hours(since: datetime, now: datetime) -> float:
    return round((now - since).total_seconds() / 3600.0, 2)


def newest_completed(client: Any, vault: str, resource_arn: str | None = None) -> datetime | None:
    """The CreationDate of the newest COMPLETED recovery point, or None."""
    kwargs: dict[str, Any] = {"BackupVaultName": vault}
    if resource_arn:
        kwargs["ByResourceArn"] = resource_arn
    newest: datetime | None = None
    for page in client.get_paginator("list_recovery_points_by_backup_vault").paginate(**kwargs):
        for point in page.get("RecoveryPoints", []):
            if point.get("Status") != "COMPLETED":
                continue
            created = point["CreationDate"]
            if newest is None or created > newest:
                newest = created
    return newest


def check(
    *,
    backup: Any,
    backup_dr: Any,
    rds: Any,
    vault: str,
    dr_vault: str,
    resources: dict[str, str],
    db_instance: str,
    now: datetime,
) -> tuple[dict[str, float], list[str], float | None]:
    """(ages by label, labels with no recovery point, PITR lag in hours or None)."""
    ages: dict[str, float] = {}
    missing: list[str] = []
    for label, arn in resources.items():
        created = newest_completed(backup, vault, arn)
        if created is None:
            missing.append(label)
        else:
            ages[label] = _hours(created, now)
    dr_created = newest_completed(backup_dr, dr_vault)
    if dr_created is None:
        missing.append("dr")
    else:
        ages["dr"] = _hours(dr_created, now)

    instances = rds.describe_db_instances(DBInstanceIdentifier=db_instance)["DBInstances"]
    restorable = instances[0].get("LatestRestorableTime") if instances else None
    lag = _hours(restorable, now) if restorable else None
    if lag is None:
        missing.append("rds-pitr")
    return ages, missing, lag


def metric_data(
    environment: str, ages: dict[str, float], missing: list[str], lag: float | None
) -> list[dict]:
    """Everything but the heartbeat, which `publish` sends last and separately."""

    def dims(resource: str | None = None) -> list[dict[str, str]]:
        out = [{"Name": "Environment", "Value": environment}]
        if resource:
            out.append({"Name": "Resource", "Value": resource})
        return out

    data = [
        {
            "MetricName": "RecoveryPointAgeHours",
            "Dimensions": dims(label),
            "Value": age,
            "Unit": "None",
        }
        for label, age in sorted(ages.items())
    ]
    if lag is not None:
        data.append(
            {
                "MetricName": "RestorableLagHours",
                "Dimensions": dims("rds"),
                "Value": lag,
                "Unit": "None",
            }
        )
    data.append(
        {
            "MetricName": "MissingRecoveryPoints",
            "Dimensions": dims(),
            "Value": float(len(missing)),
            "Unit": "Count",
        }
    )
    return data


def publish(cloudwatch: Any, environment: str, data: list[dict]) -> None:
    cloudwatch.put_metric_data(Namespace=NAMESPACE, MetricData=data)
    cloudwatch.put_metric_data(
        Namespace=NAMESPACE,
        MetricData=[
            {
                "MetricName": "CheckerRuns",
                "Dimensions": [{"Name": "Environment", "Value": environment}],
                "Value": 1.0,
                "Unit": "Count",
            }
        ],
    )


def handler(
    event: dict,
    context: Any,
    clients: Callable[[str, str | None], Any] | None = None,
    now: datetime | None = None,
) -> dict:
    """Scheduled. `clients(service, region)` is injectable so the tests use Stubbers."""
    if clients is None:  # pragma: no cover - the real clients, in AWS only
        import boto3

        def clients(service: str, region: str | None) -> Any:
            return boto3.client(service, region_name=region) if region else boto3.client(service)

    environment = os.environ["ENVIRONMENT"]
    resources = json.loads(os.environ["PROTECTED_RESOURCES"])
    ages, missing, lag = check(
        backup=clients("backup", None),
        backup_dr=clients("backup", os.environ["DR_REGION"]),
        rds=clients("rds", None),
        vault=os.environ["BACKUP_VAULT_NAME"],
        dr_vault=os.environ["DR_BACKUP_VAULT_NAME"],
        resources=resources,
        db_instance=os.environ["DB_INSTANCE_IDENTIFIER"],
        now=now or datetime.now(timezone.utc),
    )
    publish(clients("cloudwatch", None), environment, metric_data(environment, ages, missing, lag))
    logger.info("backup freshness: ages %s, missing %s, pitr lag %s h", ages, missing, lag)
    return {"ages": ages, "missing": missing, "restorable_lag_hours": lag}
