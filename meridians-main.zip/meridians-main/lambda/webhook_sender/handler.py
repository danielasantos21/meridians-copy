"""The webhook sender Lambda — a thin SQS adapter over `src.webhooks.engine`.

Phase 12 T11 (`docs/reports/phase-12-plan.md` §3.7, ADR 0038). Deployed as
`meridian-<env>-lambda-webhook-sender` (T21): in the VPC, its own security
group (443 out, 5432 to RDS) and role, reserved concurrency 2, triggered by
`meridian-<env>-sqs-webhooks` with `ReportBatchItemFailures` on.

Everything that decides anything — the fan-out, the tenant re-check, the SSRF
guard, signing, the retry schedule, dead-lettering — is the engine's, the same
code the api and the in-process fake queue run. This file only translates:

    SQS record body      → `Message.from_json` (our message, or an EventBridge
                           envelope → fan-out). An unparseable body is logged
                           and acknowledged: retrying it cannot fix it.
    Decision `ack`       → nothing (the record succeeds and SQS deletes it).
    Decision `retry`     → `ChangeMessageVisibility` to the delay, and the
                           record reported as a batch item failure, so the SAME
                           message comes back after the backoff.
    Decision `dead`      → the message copied to the DLQ (the DLQ-depth alarm
                           watches it), then acknowledged.
    an exception         → a batch item failure with no visibility change; the
                           queue's own redrive policy (8 receives → DLQ) is the
                           backstop.

Configuration comes from the environment (`src.webhooks.ports.adapters_from_env`):
`WEBHOOK_QUEUE_URL`, `WEBHOOK_DLQ_URL`, `WEBHOOK_EVENT_BUS`,
`WEBHOOK_SECRETS_KMS_KEY_ID`, `WEBHOOK_BLOCKED_CIDRS` (the VPC range), plus the
database settings `src.pg` reads. Nothing about a message, a URL or a response
body is logged — ids and reason codes only.

THE DATABASE PASSWORD (T21)
---------------------------
ECS injects `PGPASSWORD` into the api task from Secrets Manager; Lambda has no
such mechanism, and a Lambda environment variable holding the password would be
readable by anyone with `lambda:GetFunctionConfiguration`. So the stack passes
the credential secret's **ARN** (`WEBHOOK_DB_SECRET_ARN`) and the first
invocation reads the `password` field into this process's environment, where
`src.settings.postgres_url()` finds it — the same pattern as the User Migration
Lambda. Never logged; one `GetSecretValue` per cold start.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from src.log_safe import register_secret
from src.webhooks import engine
from src.webhooks.ports import Message

logger = logging.getLogger(__name__)


#: The ARN of the `meridian_app` credential secret (`infra/meridian/stacks/api.py`).
DB_SECRET_ARN_ENV = "WEBHOOK_DB_SECRET_ARN"  # noqa: S105 a name, not a secret


def load_db_password(client: Any = None) -> bool:
    """Put the database password into `PGPASSWORD` once. True if it was fetched.

    Does nothing when `PGPASSWORD` is already set (a later invocation, or a local
    run) or when no secret ARN is configured (tests, a laptop).
    """
    arn = os.environ.get(DB_SECRET_ARN_ENV, "").strip()
    if os.environ.get("PGPASSWORD") or not arn:
        return False
    if client is None:
        import boto3  # the Lambda runtime's own copy

        client = boto3.client("secretsmanager")
    raw = client.get_secret_value(SecretId=arn)["SecretString"]
    password = json.loads(raw)["password"]
    # Set after the log filter snapshotted the environment: register it too.
    register_secret(password)
    os.environ["PGPASSWORD"] = password
    return True


def handle_record(record: dict[str, Any], ports: engine.Ports) -> bool:
    """Handle one SQS record. True = done (delete it); False = leave it on the queue."""
    try:
        message = Message.from_json(record.get("body", ""))
    except ValueError as exc:
        logger.warning("webhook sender: unparseable message acknowledged: %s", exc)
        return True
    try:
        decision = engine.handle(message, ports)
    except Exception:
        logger.exception("webhook sender: handling failed; SQS will redeliver")
        return False
    if decision.action == "retry":
        ports.queue.retry_later(record["receiptHandle"], decision.delay_seconds)
        return False
    if decision.action == "dead":
        ports.queue.dead_letter(message)
    return True


def handler(event: dict[str, Any], context: Any = None) -> dict[str, Any]:
    """The Lambda entry point: an SQS batch in, the partial-batch response out."""
    load_db_password()
    ports = engine.get_ports()
    failures = [
        {"itemIdentifier": record["messageId"]}
        for record in event.get("Records", [])
        if not handle_record(record, ports)
    ]
    return {"batchItemFailures": failures}
