"""Cognito User Migration trigger — the real implementation (Phase 4 step 6).

Phase 4 step 6 of `docs/aws-migration-plan.md`; the decision is ADR 0003
("a User Migration Lambda, with no forced reset"), refined by ADR 0021.

WHAT IT IS FOR
--------------
Supabase will not export password hashes. Without this function, moving identity
to Cognito forces every user to reset a password on the morning of the flip. With
it, the first sign-in after the flip goes: Cognito has no such user → Cognito
calls this function with the email and the plaintext password → this function
asks Supabase Auth whether that pair is good → on yes, Cognito creates the user
silently, with `custom:app_uid` carrying the legacy Supabase UUID so that not one
application row is rewritten.

It handles both triggers:

  `UserMigration_Authentication`   someone signed in. A password is present and
                                   is checked against Supabase Auth.
  `UserMigration_ForgotPassword`   someone asked to reset. There is NO password
                                   in the event, so nothing can be verified: the
                                   user is created in `RESET_REQUIRED` and
                                   Cognito sends its own code to the address it
                                   has just been told is verified. That address
                                   comes from the bundled snapshot, never from
                                   the request — otherwise anyone could type any
                                   address and be handed an account.

FAIL CLOSED, AND SAY SO IN THE SAME WORDS EVERY TIME
----------------------------------------------------
Every failure raises `RuntimeError(UNAVAILABLE)` — *sign-in is temporarily
unavailable* — and that is the whole vocabulary:

  * a failure to **check** a credential is not a failure **of** the credential.
    Supabase down, a timeout, a 500: the user has done nothing wrong, and
    "invalid credentials" sends them to a password reset that cannot help;
  * a wrong password (Supabase 400 `invalid_grant`) gets the **same** text. Not
    because it is accurate, but because any other text is an oracle: a message
    that differs for "user exists, wrong password" and "no such user" tells an
    attacker which addresses are real. Cognito shows its own generic message to
    the user anyway (`PreventUserExistenceErrors=ENABLED`), so the only audience
    for a more specific message here is CloudWatch — and the status code class
    is logged for that.

WHAT IS LOGGED, EXACTLY
-----------------------
The email **domain**, the trigger source, the HTTP status **class** (`2xx`,
`4xx`, `5xx`, `timeout`, `none`) and the elapsed milliseconds. Never the local
part of an address, never the password, never the event, never the Supabase
response body. These lines land in CloudWatch on a 400-day retention, so
anything logged is a 400-day problem. `tests/test_user_migration_lambda.py`
greps every log call made during a run for the local part.

THE FIVE-SECOND BUDGET
----------------------
Cognito abandons a `UserMigration_*` trigger at about 5 seconds and the user sees
a failed sign-in. The function therefore:

  * runs **outside the VPC** (an ENI attachment on a cold start does not fit);
  * gives the Supabase call an overall **3-second deadline**, not a 3-second
    socket timeout. `socket.settimeout` bounds each individual socket operation,
    so a server that dribbles a byte every two seconds keeps a "3-second"
    request alive indefinitely and Cognito abandons the trigger while the
    function is still waiting. The connect phase is capped at 1 second and the
    read is bounded by whatever is left of the budget; when `context` offers
    `get_remaining_time_in_millis()` the budget is clipped to that too, minus a
    reserve for the response. An exhausted budget fails **closed**;
  * caches the snapshot and the Supabase credentials in module globals, so only
    the first invocation on a container pays for them.

NO CHEAP ANSWERS
----------------
"This address is not in the snapshot" and "this address is federated-only" are
decided by a dictionary lookup, in well under a millisecond, while a wrong
password costs a round-trip to Supabase. That difference is measurable from
outside and answers "is this address real?" without any message saying so. Both
branches therefore make the **same** Supabase request with a fixed decoy
password before refusing, so the latency profile of a refusal does not depend on
whether the address exists. Supabase's password grant applies no account lockout
by default, so a decoy attempt cannot lock anybody out; the residual (rate
limiting, and the wall-clock cost of the extra call) is recorded in ADR 0021.

CONFIGURATION
-------------
`SUPABASE_URL` and `SUPABASE_ANON_KEY` are read from the environment when they
are set. Otherwise they are fetched **once per container** from the Secrets
Manager secret named by `LEGACY_SUPABASE_SECRET_ARN`, using the boto3 that the
Lambda runtime provides (`infra/meridian/stacks/auth.py` grants
`secretsmanager:GetSecretValue` on that one ARN and nothing else). The anon key
is used, not the service key: this call is an ordinary sign-in, and a service
key in a function reachable from the public internet would be a far larger
blast radius than the thing it is checking.

`legacy_users.json` sits beside this file, bundled into the deployment asset. It
holds email addresses, so it is **not committed**: `legacy_users.example.json` is
the committed shape and `scripts/snapshot_legacy_users.py` generates the real one
(fresh on the day of the deploy — plan step 10). A missing snapshot is not an
error condition to work around: it fails every sign-in closed, which is the
correct behaviour for a function whose entire job is deciding who is real.

Runtime: Python 3.12, stdlib only (`http.client`, `json`, `logging`, `os`,
`pathlib`, `time`, `urllib.parse`). No `requests`, no third-party HTTP client,
nothing to vendor.
"""

from __future__ import annotations

import contextlib
import http.client
import json
import logging
import os
import time
import urllib.parse
from pathlib import Path
from typing import Any, NoReturn

#: A named logger rather than the root one. Lambda installs its handler on the
#: root logger and this propagates to it, so the CloudWatch output is the same —
#: but nothing else in the process has its level changed underneath it.
logger = logging.getLogger("user_migration")
logger.setLevel(logging.INFO)

#: What the user is told, whatever went wrong. See the module docstring.
UNAVAILABLE = "Sign-in is temporarily unavailable. Please try again shortly."

#: The two trigger sources this function answers. Anything else is a pool
#: misconfiguration, and a trigger we do not understand is not one we improvise
#: a response to.
AUTHENTICATION_TRIGGER = "UserMigration_Authentication"
FORGOT_PASSWORD_TRIGGER = "UserMigration_ForgotPassword"  # noqa: S105 a name, not a secret

#: The OVERALL budget for the Supabase call — connect, send and read together —
#: not a per-socket-operation timeout. Three seconds inside Cognito's five.
TOTAL_BUDGET_SECONDS = 3.0

#: The connect phase's share of it. A TLS handshake to a healthy in-region host
#: is tens of milliseconds; a second is generous, and capping it here means a
#: black-holed host leaves two seconds of the budget for a retry-free read.
CONNECT_TIMEOUT_SECONDS = 1.0

#: Held back from `context.get_remaining_time_in_millis()` when clipping the
#: budget: the answer still has to be turned into a Cognito response after the
#: socket closes.
RESERVE_SECONDS = 0.5

#: The password sent for an address the function is going to refuse anyway, so
#: that refusing costs a round-trip whether or not the address exists. It is not
#: a credential and it is not secret — it is deliberately not a valid password
#: under the pool policy, and Supabase applies no lockout to the password grant.
DECOY_PASSWORD = "not-a-credential"  # noqa: S105 a name, not a secret

#: The bundled snapshot, beside this file. `LEGACY_USERS_PATH` overrides it,
#: which is how the tests point at a fixture without writing into the asset.
SNAPSHOT_FILENAME = "legacy_users.json"

#: Cognito's own name for "this user is done, do not email them".
SUPPRESS = "SUPPRESS"

#: The password grant on Supabase's GoTrue.
TOKEN_PATH = "/auth/v1/token?grant_type=password"  # noqa: S105 a name, not a secret

_snapshot_cache: dict[str, dict[str, Any]] | None = None
_credentials_cache: tuple[str, str] | None = None


# ----------------------------------------------------------------- logging
def _domain(address: str) -> str:
    """`a.person@example.com` -> `example.com`. The only part that may be logged.

    A domain says which tenant or which provider is having trouble, which is the
    whole diagnostic value of the address; the local part identifies a person.
    """
    _local, at, domain = address.rpartition("@")
    # No `@` means `rpartition` hands back the WHOLE string as the "domain" —
    # which would log a username verbatim. A value that is not an address has no
    # domain, and that is all this may say about it.
    if not at or not domain:
        return "(none)"
    return domain


def _status_class(status: int | None) -> str:
    """`401 -> '4xx'`. A class, not a code: a code is one bit closer to an oracle."""
    if status is None:
        return "none"
    return f"{status // 100}xx"


# ------------------------------------------------------------- the snapshot
def _snapshot_path() -> Path:
    override = (os.environ.get("LEGACY_USERS_PATH") or "").strip()
    return Path(override) if override else Path(__file__).resolve().parent / SNAPSHOT_FILENAME


def load_snapshot() -> dict[str, dict[str, Any]]:
    """The bundled `{email_lower: {supabase_uuid, has_password, providers}}` map.

    Cached in a module global, so a warm container reads the file once. A missing
    or unreadable file raises, and every caller of this function turns a raise
    into a closed sign-in: a snapshot that is not there cannot say anybody is
    real.
    """
    global _snapshot_cache
    if _snapshot_cache is None:
        path = _snapshot_path()
        with path.open(encoding="utf-8") as handle:
            loaded = json.load(handle)
        if not isinstance(loaded, dict):
            raise ValueError("legacy user snapshot is not a JSON object")
        _snapshot_cache = {str(key).strip().lower(): value for key, value in loaded.items()}
    return _snapshot_cache


# ---------------------------------------------------------- the credentials
def load_credentials() -> tuple[str, str]:
    """`(supabase_url, anon_key)`, from the environment or from Secrets Manager.

    Cached per container. The Secrets Manager path costs one API call on a cold
    start — roughly 100-250 ms in-region for the call itself, which is why it is
    paid once and why the socket timeout below it is 3 seconds and not 4. Importing
    boto3 and building the client is CPU-bound and took 3-5 s at 128 MB
    (2026-10-08), which is why the function has 1024 MB; the client's own
    timeouts are 1 s so a slow call cannot hang past Cognito's 5 s.

    boto3 is imported **inside** this function: it is provided by the Lambda
    runtime, it is not a dependency of this repository, and the tests exercise
    the environment path without it.
    """
    global _credentials_cache
    if _credentials_cache is not None:
        return _credentials_cache

    url = (os.environ.get("SUPABASE_URL") or "").strip()
    key = (os.environ.get("SUPABASE_ANON_KEY") or "").strip()

    if not (url and key):
        arn = (os.environ.get("LEGACY_SUPABASE_SECRET_ARN") or "").strip()
        if not arn:
            raise RuntimeError(
                "neither SUPABASE_URL/SUPABASE_ANON_KEY nor LEGACY_SUPABASE_SECRET_ARN is set"
            )
        import boto3  # noqa: PLC0415 — runtime-provided; see the docstring
        from botocore.config import Config  # noqa: PLC0415 — likewise

        client = boto3.client(
            "secretsmanager",
            config=Config(connect_timeout=1, read_timeout=1, retries={"max_attempts": 2}),
        )
        secret = json.loads(client.get_secret_value(SecretId=arn)["SecretString"])
        url = str(secret.get("SUPABASE_URL") or "").strip()
        key = str(secret.get("SUPABASE_ANON_KEY") or "").strip()

    if not (url and key):
        raise RuntimeError("the legacy Supabase credentials are empty")

    _credentials_cache = (url.rstrip("/"), key)
    return _credentials_cache


# -------------------------------------------------------------- the request
def _budget(context: Any) -> float:
    """Seconds this invocation may spend on Supabase, clipped to Lambda's own clock.

    `TOTAL_BUDGET_SECONDS` is the ceiling. When the runtime supplies a context
    with `get_remaining_time_in_millis()` — it always does in Lambda, and never
    in a unit test — the budget is also clipped to what is actually left, minus
    a reserve for building the response. A negative result means there is no
    time to ask, and the caller fails closed.
    """
    budget = TOTAL_BUDGET_SECONDS
    remaining = getattr(context, "get_remaining_time_in_millis", None)
    if callable(remaining):
        try:
            budget = min(budget, float(remaining()) / 1000.0 - RESERVE_SECONDS)
        except Exception:
            return TOTAL_BUDGET_SECONDS
    return budget


def _check_password(
    email: str, password: str, credentials: tuple[str, str], deadline: float
) -> int | None:
    """Ask Supabase Auth whether this pair is good. Returns the HTTP status.

    `None` means the call did not complete — a timeout, DNS, a reset connection,
    or a budget that ran out before or during it. Nothing is returned from the
    response body: a GoTrue error quotes what upset it, and this function's
    callers must not be able to log or re-raise that.

    `http.client` rather than `urllib.request` for one reason: the deadline. A
    `timeout=` on `urlopen` is handed to `socket.settimeout`, which bounds each
    individual recv — so a slow trickle of bytes never trips it and the trigger
    dies of Cognito's five seconds instead. Here the connect is capped, and the
    read timeout is recomputed from what is left of the deadline.
    """
    url, key = credentials
    parts = urllib.parse.urlsplit(url)
    host = parts.hostname
    if not host:
        return None

    remaining = deadline - time.monotonic()
    if remaining <= 0:
        return None

    body = json.dumps({"email": email, "password": password}).encode("utf-8")
    connection = http.client.HTTPSConnection(
        host,
        parts.port,
        timeout=min(CONNECT_TIMEOUT_SECONDS, remaining),
    )
    try:
        connection.request(
            "POST",
            parts.path + TOKEN_PATH,
            body=body,
            headers={
                "Content-Type": "application/json",
                "apikey": key,
                "Authorization": f"Bearer {key}",
                "Content-Length": str(len(body)),
            },
        )
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return None
        socket_ = getattr(connection, "sock", None)
        if socket_ is not None:
            socket_.settimeout(remaining)
        return int(connection.getresponse().status)
    except Exception:
        # Timeout, DNS, TLS, a reset connection. Deliberately not logged with
        # its text: an exception's message quotes the request that produced it.
        return None
    finally:
        # Best effort: the answer is already decided, and a failed close must
        # not replace it.
        with contextlib.suppress(Exception):
            connection.close()


# --------------------------------------------------------------- the answer
def _migrated_attributes(email: str, entry: dict[str, Any]) -> dict[str, str]:
    """The three attributes Cognito writes onto the new user.

    `custom:app_uid` is the whole point: it carries the legacy Supabase UUID, so
    the ~30 application tables keyed on that UUID are never rewritten (ADR 0003).
    A snapshot row without one is not migratable — creating the user anyway would
    give them a Cognito `sub` and orphan every row they own.
    """
    app_uid = str(entry.get("supabase_uuid") or "").strip()
    if not app_uid:
        raise RuntimeError(UNAVAILABLE)
    return {
        "email": email,
        "email_verified": "true",
        "custom:app_uid": app_uid,
    }


def _respond(
    event: dict[str, Any], email: str, entry: dict[str, Any], final_status: str
) -> dict[str, Any]:
    """Fill in `event['response']` and hand the whole event back.

    Cognito expects the event it sent, mutated — not a bare response object.
    `messageAction: SUPPRESS` because this user already exists as far as they are
    concerned; a "welcome, here is your temporary password" email arriving in the
    middle of a successful sign-in is a support call and a phishing lesson.
    """
    response = event.setdefault("response", {})
    response["userAttributes"] = _migrated_attributes(email, entry)
    response["finalUserStatus"] = final_status
    response["messageAction"] = SUPPRESS
    return event


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Both `UserMigration_*` triggers. Raises `RuntimeError(UNAVAILABLE)` to refuse."""
    started = time.monotonic()
    trigger = str(event.get("triggerSource") or "")
    email = str(event.get("userName") or "").strip().lower()
    domain = _domain(email)
    status: int | None = None

    def done(outcome: str) -> None:
        logger.info(
            "user-migration trigger=%s domain=%s outcome=%s status=%s duration_ms=%d",
            trigger or "(none)",
            domain,
            outcome,
            _status_class(status),
            int((time.monotonic() - started) * 1000),
        )

    if trigger not in (AUTHENTICATION_TRIGGER, FORGOT_PASSWORD_TRIGGER):
        done("unsupported-trigger")
        raise RuntimeError(UNAVAILABLE)

    try:
        snapshot = load_snapshot()
    except Exception:
        # No snapshot, no migration. Not logged with its text: the message would
        # quote a path, and the outcome is what matters.
        done("no-snapshot")
        raise RuntimeError(UNAVAILABLE) from None

    def credentials() -> tuple[str, str]:
        """The Supabase URL and anon key, or a refusal that names no ARN.

        `load_credentials()` raises with the text Secrets Manager gave it, and
        that text carries the secret's ARN — which carries the account id. An
        uncaught raise here puts both in CloudWatch on a 400-day retention, and
        an unhandled Lambda error also hands the stack trace to Cognito.
        """
        try:
            return load_credentials()
        except Exception:
            done("no-credentials")
            raise RuntimeError(UNAVAILABLE) from None

    def decoy(outcome: str) -> NoReturn:
        """Refuse, but pay for the round-trip first. See "NO CHEAP ANSWERS".

        The status is recorded so the log line has the same shape as any other
        refusal; what it says about this address is nothing, because the
        password sent was never anybody's.
        """
        nonlocal status
        status = _check_password(email, DECOY_PASSWORD, credentials(), deadline)
        done(outcome)
        raise RuntimeError(UNAVAILABLE)

    deadline = time.monotonic() + _budget(context)

    entry = snapshot.get(email)
    if not isinstance(entry, dict):
        # Fail closed. An address that is not in the snapshot did not exist in
        # Supabase, and a user created here would be an account minted by typing
        # an address into a login box.
        decoy("not-in-snapshot")

    if not entry.get("has_password") and trigger != FORGOT_PASSWORD_TRIGGER:
        # Federated-only (Google or Microsoft): the password flow can never succeed
        # for them. The RESET flow may (Andres, 2026-10-05): "Forgot password" mails
        # a code to the snapshot's address and they choose a password, so nobody is
        # stranded while the IdPs are off. Pre-provisioning and linking
        # (`scripts/preprovision_cognito_users.py`) still applies once they are on.
        decoy("federated-only")

    if trigger == FORGOT_PASSWORD_TRIGGER:
        # Nothing to verify: the event carries no password. The user is created
        # in RESET_REQUIRED and Cognito emails its own code to the verified
        # address FROM THE SNAPSHOT.
        #
        # The decoy call is made anyway, and its result thrown away. Without it
        # this branch was the ONLY one that answered without a round trip,
        # which inverted the oracle the decoy exists to close: a stranger paid
        # for Supabase, a known user did not, and the difference said "this
        # address is real" to anyone holding a stopwatch. All three branches
        # now cost one request (ADR 0021 residual §2 and §3).
        status = _check_password(email, DECOY_PASSWORD, credentials(), deadline)
        answer = _respond(event, email, entry, "RESET_REQUIRED")
        done("reset-required")
        return answer

    password = str((event.get("request") or {}).get("password") or "")
    if not password:
        done("no-password")
        raise RuntimeError(UNAVAILABLE)

    status = _check_password(email, password, credentials(), deadline)
    if status != 200:
        # Every non-200 lands here, including a 400 `invalid_grant` from a wrong
        # password. One message, deliberately (see the module docstring).
        done("refused")
        raise RuntimeError(UNAVAILABLE)

    answer = _respond(event, email, entry, "CONFIRMED")
    done("migrated")
    return answer
