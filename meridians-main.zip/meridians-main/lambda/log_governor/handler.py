"""The log-group governor — retention and a CMK for log groups nothing else can reach.

Tracker rows T:60 and T:65. Two kinds of CloudWatch log group in this estate are created
**implicitly**, by AWS, the first time something runs, and so appear in no CloudFormation
template: the CDK helper Lambdas' groups (`Custom::VpcRestrictDefaultSG`,
`Custom::S3AutoDeleteObjects` — `/aws/lambda/meridian-<env>-<stack>-Custom…`) and the
Synthetics canary's (`/aws/lambda/cwsyn-<canary>-<uuid>`). AWS creates them with
never-expire retention and no customer-managed key, and no construct property can say
otherwise.

The rows asked for "a CloudWatch account-level default retention and encryption
policy". **No such policy exists**: `AWS::Logs::AccountPolicy` (PutAccountPolicy) covers
data protection, subscription filters, field indexes, transformers and metric
extraction — not retention and not encryption. So this function is the control
instead: deployed per environment by `meridian-<env>-observability`, run on a schedule
and on every `CreateLogGroup` CloudTrail event, it walks the name prefixes it is given
and, for each group found,

* sets the estate's retention (`RETENTION_DAYS`) when the group has none, and
* associates the environment's `logs` CMK (`KMS_KEY_ARN`) when the group has no key.

It never shortens a retention that is already set and never replaces a key that is
already there: a group some construct configured on purpose is left exactly as it is.
Its IAM role may touch only the prefixes it is given, so it cannot reach the other
environment's groups or anyone else's in the shared account.

`AssociateKmsKey` affects data written **after** the call; what was logged before stays
under the AWS-owned key until it expires under the new retention. Neither group holds
PHI (CDK-internal output; a status code and a timing), which is why that residue is
acceptable.

Logs group NAMES and counts only — a log-group name is an identifier of our own, never a
person.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def _config() -> tuple[list[str], int, str]:
    prefixes = json.loads(os.environ["LOG_GROUP_PREFIXES"])
    if not isinstance(prefixes, list) or not all(isinstance(p, str) and p for p in prefixes):
        raise ValueError("LOG_GROUP_PREFIXES must be a JSON list of non-empty strings")
    return prefixes, int(os.environ["RETENTION_DAYS"]), os.environ["KMS_KEY_ARN"]


def govern(client: Any, prefixes: list[str], retention_days: int, kms_key_arn: str) -> dict:
    """Walk every group under `prefixes`; fix what is missing. Returns what it did."""
    result: dict[str, list[str]] = {"retention_set": [], "key_associated": [], "seen": []}
    paginator = client.get_paginator("describe_log_groups")
    for prefix in prefixes:
        for page in paginator.paginate(logGroupNamePrefix=prefix):
            for group in page.get("logGroups", []):
                name = group["logGroupName"]
                result["seen"].append(name)
                if group.get("retentionInDays") is None:
                    client.put_retention_policy(logGroupName=name, retentionInDays=retention_days)
                    result["retention_set"].append(name)
                if not group.get("kmsKeyId"):
                    client.associate_kms_key(logGroupName=name, kmsKeyId=kms_key_arn)
                    result["key_associated"].append(name)
    return result


def handler(event: dict, context: Any, client: Any = None) -> dict:
    """Scheduled sweep or a `CreateLogGroup` event: either way, a full sweep.

    The event is not trusted for the group name: a sweep of the configured prefixes is
    cheap, and it is the only path that can never be pointed at a group outside them.
    """
    prefixes, retention_days, kms_key_arn = _config()
    if client is None:  # pragma: no cover - the real client, in AWS only
        import boto3

        client = boto3.client("logs")
    result = govern(client, prefixes, retention_days, kms_key_arn)
    logger.info(
        "log governor: %d groups seen, retention set on %s, key associated on %s",
        len(result["seen"]),
        result["retention_set"] or "none",
        result["key_associated"] or "none",
    )
    return {k: len(v) if k == "seen" else v for k, v in result.items()}
