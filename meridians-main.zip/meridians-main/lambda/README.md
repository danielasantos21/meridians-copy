# lambda/

One folder per AWS Lambda handler. Each is bundled as a CDK asset by the stack that deploys
it — the application never imports these, and they are never deployed by hand.

| Folder | Deployed by | What it does |
|---|---|---|
| `user_migration/` | `infra/meridian/stacks/auth.py` | Cognito's User Migration trigger: moves a Supabase password user into the pool on their first sign-in after Flip 1. Reads a bundled snapshot (`legacy_users.json`, gitignored; `legacy_users.example.json` shows the shape). Deleted at the Phase 10 cut-off (tracker T:91). |
| `webhook_sender/` | `infra/meridian/stacks/api.py` (behind `-c enableApiPlatform=true`) | Delivers `/api/v3` webhook events from the SQS queue; a thin adapter over `src/webhooks/engine.py`, so its asset bundles `src/` and psycopg2 (ADR 0038). |
| `backup_freshness/` | `infra/meridian/stacks/observability.py` (production) | Publishes the age of every recovery point so an alarm fires on backups that stopped, not only ones that failed (tracker T:217). |
| `log_governor/` | `infra/meridian/stacks/observability.py` | Gives implicit log groups (CDK helpers, the canary) the estate's retention and KMS key (tracker T:218/T:219). |
| *(none — `scripts/cognito_export.py`)* | `infra/meridian/stacks/auth.py` | The nightly Cognito identity export into the Object-Locked `archive` bucket (tracker T:163, D15). Its asset is `scripts/` filtered to that one file, so the CLI and the Lambda are one module. |

Tests: `tests/test_user_migration_lambda.py`, `tests/test_backup_freshness_lambda.py`,
`tests/test_log_governor_lambda.py` (botocore `Stubber`, no AWS), and the webhook engine tests
under `tests/security/`.

## What does not live here

- **Business logic the application shares.** That is `src/`.
- **Real identities.** `legacy_users.json` holds real email addresses: it is gitignored,
  excluded by `.dockerignore`, and generated on the day of a deploy
  (`scripts/snapshot_legacy_users.py`).
- **Dependencies the Lambda runtime does not have**, unless the stack's bundling adds them
  (only `webhook_sender/` does).
