# 261019-all: every eCW mart table on AWS (no patient identifiers)

Decision (Andres, 2026-10-19): "all tables, no IDs". Identifiers go into the `phi` schema later,
only when a feature needs them (AWS BAA active since 2026-07-13). Plan only; no code written.
Worktree `merge-main-into-aws-2026-10-16` (written at eb2664cd; revised after the independent check
`261019-all-CHECK.md`, commit fc50f74d, at HEAD 9aab965b). Any Alembic revision this needs would be
0050 or later (0049 is the Executive Report work); none is expected. T:260 is untouched: native SQL stays
refused on AWS, so the new tables are reachable only through the question builder, which can
name only catalog columns.

## Revision 2 (after the check): what changed

B1 indexes + timing gate (1D, 2, 6); B2 per-swap grant (2); B3 explicit hide list and ids not copied
(1A, 3); B4 `fact_ob_*` not copied (3); W1 joins (1C); W2 time 70-90 min (2); W3 storage and WAL math (4);
W4 first-load scripts (2, 8); W5 DROP+CREATE views (1A); W6 `_copy_log` correctness (2); W7 Ask index
and tests (5, 6); W8 test paths (6). Owner defaults that stand: record keys hidden in the builder,
free-text reasons not copied, `ecw_` tables auto-shown when they pass the tripwire, staff names shown.
Pending owner (recommended, applied unless he says no): do not copy `preg_id`, `contact_id`,
`master_contact_id`; do not copy `fact_ob_preg`, `fact_ob_flowsheet`, `fact_ob_req_buckets`
(and `report_ob_dash_telos`, same shape) row-level.

## 0. What I measured (read-only, local `meridians_ecw`, names/counts/sizes only)

* Mac mart: 122 tables = 121 data tables + `_sync_log`; 22.1 M rows; 3.9 GB, no indexes;
  1,455 columns (about 12 per table). The 15 tables on AWS today are 1.8 GB of that.
* Identifier sweep over the 121 tables with the loader's own rules (`keep_columns` +
  `check_columns` from `scripts/sync_data_mart.py`): 0 columns to drop, 0 failures. None of the
  five `SKIP_TABLES` is present. The Mac copy was already scrubbed, so this proves the Mac copy
  is clean, not that the source cannot change; the loader keeps scrubbing on AWS (section 3).
* Same columns against BI's own `TRIPWIRE` (`src/bi_catalog.py`): 12 hits, all false alarms or
  clinic data: `dim_facility.facility_address_line_1`, `_line_2`, `facility_phone_no`,
  `facility_zip`; `fact_outgoingreferrals` and `report_incoming_referrals`: `addressed`,
  `addressed_dt`, `addressed_by_id`, `days_creation_to_address` /
  `days_from_creation_to_addressed`.
* Free text (the real risk), found by column width plus distinct counts:
  `dim_reason.reason` (142,101 distinct values, up to 500 chars, 1.59 M rows) and
  `fact_follow_up_compliance.follow_up_requested_reason` (42,602 distinct, up to 279). Staff-typed
  visit reasons; they can carry names or dates of birth. Everything else wide is codes, labels,
  insurance/provider/staff names, or short enumerations (`report_documents.assigned_to` 413
  distinct, max 36; `fact_ob_preg.ins_name` 149 distinct).
* Record keys (not patient ids under the owner's rule, but eCW visit-level keys):
  `encounter_id` (14 tables), `claim_no` (12), `visit_id` (6), `referral_id` (2),
  `*_enc_id` (4 columns), `document_id`, `check_no`. No `patient_*` id column exists anywhere.
* `visit_pat_age` (`fact_well_compliance`, smallint): fine unless ages above 89 exist; the check
  script (task 1) reports max age and fails above 89.
* `fact_ob_preg` is patient-level (11,431 rows, 94 columns, pregnancy status and dates, no id).
  It is allowed (no identifier) but is the table most open to re-identification by someone who
  knows a person; it gets the small-cell note in section 3.
* No mart table has an `org_id` column (0 found): tenant comes from `analytics.tenant`.
* RDS `statement_timeout` is a parameter-group default of 300 s (`infra/meridian/stacks/data.py`
  `STATEMENT_TIMEOUT_MS`). `open_source` sets 900 s on the read side; `open_rds_target` sets
  nothing, so the loader's target COPY of a 480 MB table is under the 5 min cap today.
* Alembic 0048 already runs `ALTER DEFAULT PRIVILEGES FOR ROLE meridian_mart_owner IN SCHEMA
  analytics` (SELECT to the reader), so owner-created views are readable by the api login with no
  new grant (task 5 adds a test that proves it for the new views).

## 1. How BI exposes a table today, and the smallest way to expose all 121

Today (one table = four things):
1. a table or view in schema `analytics`, with `org_id` (hand-written SQL, `sql/analytics/*.sql`;
   views created by the owner, `security_invoker = false`, `CROSS JOIN analytics.tenant t`);
2. an entry in `bi_catalog.SEMANTIC` (the **true allowlist**: a column nobody listed stays hidden;
   `test_every_allowlisted_column_has_explicit_metadata` enforces it), plus `TABLE_DISPLAY`,
   `DESCRIPTIONS`, `COLUMN_DISPLAY`, `FOREIGN_KEYS`;
3. `build_catalog` reads `information_schema.columns` for schema `analytics`, skips relations
   without `org_id`, applies `DENIED_*`, and runs the PHI `TRIPWIRE` on EVERY non-denied column,
   listed or not. A hit raises `CatalogUnsafe` and BI answers 503 for everybody. So one bad
   generated column would switch BI off, not just hide itself;
4. reads go through `mart_source` (audited door, `phi.MART_READ_OBJECTS`: `bi.query` etc.). No
   new object word is needed for new tables: the audit row names the action, not the table.

Decision: generated pass-through views, not 121 hand-written ones, for one reason of size
(hand-writing means about 1,450 `SEMANTIC` rows).

**A. View generator** in `scripts/apply_analytics_views.py` (new step after file 090, same
SAVEPOINT-per-step pattern and same `check_statement`/`guard_sql` guard). For every base table in
schema `mart` (minus `_`-prefixed) it creates `analytics.ecw_<table>`:
`SELECT <safe columns>, t.org_id FROM mart.<table> CROSS JOIN analytics.tenant t`,
`WITH (security_invoker = false)`; each regenerated view is `DROP VIEW IF EXISTS` then `CREATE` (not
`CREATE OR REPLACE`, which cannot drop or reorder columns; `check_statement` allows drop inside analytics;
the reader's grant returns through the 0048 default privileges). Prefix `ecw_` so nothing collides with Cobalt's
`analytics.dim_visit_type` or the hand-written `mart_*` views (those stay; they carry the
fiscal-calendar and small-cell logic that raw tables do not). Safe columns are decided in ONE
shared function (new `src/mart_columns.py`, no DB, imported by the generator, the catalog, the
loader and the check script) so the three layers cannot drift:
  * drop `DROP_COLUMNS` and `patient_`-prefixed columns not in `PATIENT_OK` (loader rules);
  * drop `FREE_TEXT_DROP` and `NEVER_COPY_COLUMNS` (below);
  * drop record keys by the explicit HIDE LIST below, plus the default-hide rule for ids (pinned by a
    test; there is no free-form regex);
  * drop any column that matches the catalog `TRIPWIRE` and is not allowed. The 12 false alarms
    are handled by adding the five referral "addressed" names to `TRIPWIRE_ALLOWED`
    (counts/flags/dates, same list the loader calls `ADDRESS_OK`); the four facility address /
    phone / zip columns are simply left out of the view (no BI use);
  * drop types BI cannot query (`_PG_TO_BASE` has no entry);
  * a table with no safe column gets no view; a table that vanished gets its stale `ecw_` view
    dropped (`DROP VIEW IF EXISTS`, owner-owned only).
Date columns arrive as `date`; the `real`/`smallint`/`bigint` columns are cast to `numeric`
where the existing views do (`real` to `numeric(.,2)`) so sums do not show float dust.

**Hide list (written out; lives in `src/mart_columns.py`, pinned by `tests/fixtures/mart_columns.txt`
which classifies all 134 real `*_id/_no/_key` column names as KEEP or HIDE, test fails on any unclassified
name).** Record keys, hidden from every generated view, copied to `mart` only where noted:
`claim_no`, `encounter_id`, `visit_id`, `referral_id`, `document_id`, `check_no`, `batch_id`,
`payment_id`, `payment_detail_id`, `payment_subdetail_id`, `submission_payment_detail_id`,
`first_submission_id`, `last_submission_id`, `tosubmitted_id`, `toreadytosubmit_id`, `well_id`,
`telenc_id`, `ref_from_id`, `ref_to_id`, and every `*_enc_id` (`ref_enc_id`, `next_appt_enc_id`,
`next_prov_appt_enc_id`, `appt_created_post_visit_enc_id`). Default-hide rule for anything else:
a `*_id` or `*_no` column is shown only if it is on the reviewed KEEP list: facility
(`facility_id`, `facility_group_id`, `facility_norm_id`, `from_facility_id`, `from_facility_grp_id`,
`first_ob_appt_facility_grp_id`), provider (`resource_provider_id`, `appointment_provider_id`,
`rendering_provider_id`, `cpt_rendering_provider_id`, `cpt_provider_allocated_id`,
`first_ob_appt_res_prv_id`, `last_appt_apptprov_id`, `last_appt_resprov_id`, `next_*_apptprov_id`,
`next_*_resprov_id`), visit type (`visit_type_id`, `first_ob_appt_visit_type_id`, `*_vt_id`),
`cpt_id`, `inv_cpt_id`, `icd1_id`-`icd4_id`, `payor_id`, `primary_insurance_id`,
`secondary_insurance_id`, `claim_status_id`, `claim_type_id`, `general_visit_status_id`,
`visit_status_id`, `encounter_type_id`, `encounter_eligibility_status_id`, `reason_id`,
`disposition_id`, `campaign_id`, `skill_id`, `team_id`, `cascodes_id`, `remarkcodes_id`,
`start_time_id`, `end_time_id`, `*_gralvs_id`, every `*_calendar_week_id` / `*_cal_wk_id` /
`*_calendar_period_id`, and staff ids (`agent_id`, `nic_agent_id`, `ecw_user_id`, `biller_*_id`,
`*_by_id`, `assigned_to_id`, `posted_by_id`, `*_submitted_by_id`, `telenc_assigned_to_id`,
`telenc_created_by_id`, `tosubmitted_user_id`, `toreadytosubmit_user_id`, `addressed_by_id`,
`adressed_by_id`). `bigint` ids not on either list are hidden and listed by the check script, so a
new upstream id column is hidden until reviewed.
**Not copied at all** (`NEVER_COPY_COLUMNS` in `mart_target.py`, applied by the loader like
`DROP_COLUMNS`, and refused by `check_mart_columns.py` if present in a source): `preg_id` (one id per
pregnancy, 5 tables), `contact_id` and `master_contact_id` (`fact_inbound_detail`, `fact_outbound`,
with call date and time). Pending owner, recommended. If a later phi-schema feature needs them they
go there, not into `mart`.

**B. Catalog policy change (BI's fail-closed rule, made explicit).** New `GENERATED_PREFIX =
"ecw_"` in `bi_catalog.py`: for those relations only, the allowlist is "every column that survives
deny + tripwire + `_PG_TO_BASE`", with type-derived semantics (date to Temporal, `*_id` bigint to
FK-less ID, text `dim_*` low-cardinality to Category, everything else none). Curated tables keep
the hand-listed allowlist untouched. The tripwire still runs on generated relations as the second
lock. `test_every_allowlisted_column_has_explicit_metadata` and `test_kept_columns_exact` are
scoped to curated tables; a new test pins the generated policy (Open question 3).
Category columns on the 40-odd `ecw_dim_*` tables feed Ask's KNOWN VALUES lookups, which cost one
5 s-capped query per column per hour; limit Category to dims under 50,000 rows (the check script
records row counts) so facts never get a values lookup.
Display names: `table_display_name` already title-cases names; add `ecw_` to read as
"eCW: fact cpts" and group them under one "eCW tables" heading in the data picker (the picker
reads `TABLE_DISPLAY`; no front-end change beyond sorting the heading, check
`web/` data-picker code during task 4).

**C. Joins (decision: mechanical foreign keys).** The builder joins through catalog `FOREIGN_KEYS`
(8 hand entries today), so without a rule a fact would show provider and facility as bare numbers.
`bi_catalog` derives FKs for `ecw_` tables: a kept `<x>_id` column in a fact points to the `ecw_dim_<x>`
view when that dim has a column of the same name (e.g. `fact_visits_detail.facility_id` to
`ecw_dim_facility.facility_id`, `resource_provider_id` to `ecw_dim_resource_provider`, `visit_type_id` to
`ecw_dim_visit_type`, `cpt_id` to `ecw_dim_cpt`, `payor_id`, `primary_insurance_id`). Prefixed columns
(`next_appt_vt_id`) resolve to their own dim view by name stripping (`dim_next_appt_vt`). A test pins
the derived FKs for the five biggest facts; ambiguous or missing matches get no FK (never a guess).
Fact-to-fact joins are not offered (record keys are hidden; Open question 1).

**D. Indexes (B1; decided now, created by the loader).** The BI timeout is 10 s per card
(`TIMEOUT_MS = 10000`, `src/bi_run.py`), preview 3 s, lock 1 s, not the 300 s of the loader. With no
indexes a group-by on a 1.5 M-row, 480 MB table is a disk scan on a db.t3.micro (1 GB RAM). Indexes are
chosen from how BI filters (date window, clinic/facility, provider, visit type):
`fact_cpts_payments_detail` (cpt_service_date, facility_id, resource_provider_id),
`fact_cpts` (cpt_service_date, facility_id, resource_provider_id),
`fact_encounters_detail` and `fact_visits_detail` (appointment_date, facility_id,
resource_provider_id), `fact_msg_codes` / `fact_last_msg_codes` / `fact_first_msg_codes`
(payment_date), `fact_inbound_detail`, `fact_follow_up_compliance`, `fact_claims_performance`,
`fact_claims`, `fact_scrubbing`, `report_*` large tables: the first `date` column plus
`facility_id` / `resource_provider_id` when present. Rule, not a hand list: for every table over
200,000 rows the loader creates a btree on each of {first date column, `facility_id`,
`resource_provider_id`, `visit_type_id`} that exists, named `ix_<table>_<col>`, right after the
load and before ANALYZE (`CREATE INDEX IF NOT EXISTS`; a table that is TRUNCATEd keeps its indexes,
a recreated one gets them again). About 25 tables x 3 indexes; a btree on a bigint or date of 1.5 M rows is
about 32-45 MB, so about 2.5 GB across both copies; counted in section 4. Indexes help the
date/clinic/provider filters BI builds; an unfiltered group-by over a whole fact still scans and may
need the question to add a date filter. The separate Daily Report fix will precompute heavy views and
cache card results; this plan does not wait for it and does not duplicate it.
**Timing gate (staging, before production):** top 5 largest generated views
(`ecw_fact_cpts_payments_detail`, `ecw_fact_cpts`, `ecw_fact_encounters_detail`, `ecw_fact_msg_codes`,
`ecw_fact_visits_detail`): one count and one group-by with a date filter and one group-by by
clinic with no filter, through the real builder path as the reader; each must finish under 10 s on
t3.micro. A table that fails is hidden from the catalog (`HIDE_TABLES` in `bi_catalog.py`) or gets another
index; the result and numbers go into the runbook. Production repeats the same five queries.

## 2. Loader and copy changes

**Table list = all source tables minus `SKIP_TABLES`, minus `_`-prefixed, minus the reviewed
exclusions.** Not "whatever the source holds": a new table appearing upstream later must not flow
in unreviewed. So:
* `scripts/mart_target.py`: `RDS_TABLES` (11 names) becomes the reviewed list of 116 names
  (121 minus `dim_reason`, whose only content is the free text; minus `fact_ob_preg`, `fact_ob_flowsheet`,
  `fact_ob_req_buckets`, `report_ob_dash_telos`, pending owner, section 3). Same name, new
  content, generated once from the local catalog and committed. A table in the source that is not
  on the list is skipped and logged `new table, not reviewed: <name>`; adding it is a one-line
  commit. Existing refusal of `--tables` outside the list stays.
* `FREE_TEXT_DROP = {("fact_follow_up_compliance", "follow_up_requested_reason")}` in
  `mart_target.py`, applied by the loader next to `DROP_COLUMNS` (table-scoped; the generic name
  `reason` must not be dropped globally). `dim_reason` is excluded as a whole table.
* `sync_data_mart.run`: in rds mode with no `--tables`, discover the source and intersect with the
  reviewed list instead of `sorted(RDS_TABLES)`. `check_columns` stays on for every table.
* Target session: `SET statement_timeout = '30min'` right after `open_rds_target` (the 300 s
  parameter-group cap would cut a 480 MB COPY on a slow night); lock timeout unchanged.
* Right after each table's load, before ANALYZE: create the indexes of section 1D (tables over
  200,000 rows), then `ANALYZE mart.<table>` (a fresh TRUNCATE+COPY has no statistics until
  autovacuum catches up).
* Schema change on a recreated table: runbook section 4 says the DROP fails because views depend
  on the table, and 116 generated views make that far likelier. Decision: before `DROP TABLE` the
  loader first runs `DROP VIEW IF EXISTS analytics.ecw_<table>` (owner owns it) and logs
  `schema changed, rerun apply_analytics_views`; the next apply (task below) recreates it. No CDK
  change. Hand-written `mart_*` views still fail loudly as today (they need judgement).
* Full vs incremental: the source has no update stamp, so true incremental is not possible. What
  is possible and cheap: `ecw_mart` is only as fresh as the last Mac push, so the nightly copy of
  unchanged data is wasted work. The copy script writes, in each table's swap transaction, one row
  per table to `ecw_mart.public._copy_log (table_name, loaded_at)`. The loader (rds mode) decides
  PER TABLE: copy table `t` unless `mart._sync_log` has an ok row for `t` with `finished_at >=
  _copy_log.loaded_at` AND the same `rules_version`. `rules_version` is a constant in
  `mart_target.py` (hash of the reviewed list, `DROP_COLUMNS`, `FREE_TEXT_DROP`,
  `NEVER_COPY_COLUMNS`, the hide list and the index rule); the loader adds the column to
  `mart._sync_log` (`ALTER TABLE ... ADD COLUMN IF NOT EXISTS`, owner DDL, no Alembic). So a partly
  failed run re-copies only the failed tables, and a rules or list change re-copies everything. A table
  absent from `_copy_log` (the day the outside mart opens to AWS) is copied every night. Snapshots
  always run. The loader reads `_copy_log` as `ecw_reader`, so the copy script grants it (next
  section) and the loader checks readability at start (a clear exit 1 otherwise).

**Time of the loader (planning number: 70-90 min for a full run, plus about 10 min of index builds;
replaced by the measurement).** `ecw_mart` to `mart` is on the SAME RDS instance, so the bound is
instance I/O and burst credits, not the 1 MB/s tunnel. Today 0.8 GB takes about 15 min on the 0.5 vCPU
task (runbook section 7); linear scaling to 3.7 GB gives about 70 min, which is the figure to plan
with (the 30-60 min I first wrote had no basis). A full run starting at 05:00 would end near 06:40
Central, and each table is locked (ACCESS EXCLUSIVE, BI waits only 1 s) while it reloads, so a
table is unavailable to BI for its own load time (about 1-2 min for the biggest). Therefore the
rule: after every Mac push Andres starts one one-off loader task the same evening (same command as
5a), so the 05:00 schedule finds nothing newer and ends in about 1 minute. The staging database is
stopped at 02:00 UTC, so staging cannot measure the nightly run; the one-off staging load measures the
load, and the first production night after a push is the only nightly proof (check the log;
confirm it is finished before users). The task (0.5 vCPU / 1 GB / default 20 GB ephemeral) is enough:
the temp file is per table, at most 481 MB. No infra change.

**Copy script `scripts/copy_ecw_mart_to_aws.sh` (the Mac to ecw_mart hop, one-off per refresh).**
* `TABLES` becomes computed: all base tables in local `mart` minus `_`-prefixed minus
  `SKIP_TABLES` minus `dim_reason` and the four pending-owner `ob` tables (read through the shared list in `mart_target.py` via the
  venv python, so there is one list). The P&L's 7 tables are inside it.
* Replace `drop schema mart cascade ... rename to public` (empty `ecw_mart` for the whole upload,
  and the 05:00 loader would copy the emptiness) with a per-table swap: load `public.<t>__new`,
  then in ONE transaction `DROP TABLE public.<t>; ALTER TABLE <t>__new RENAME TO <t>;
  GRANT SELECT ON public.<t> TO ecw_reader; INSERT INTO _copy_log ...` (a swapped-in table is a new
  table with no grant; without the grant the P&L and the loader would get "permission denied" the
  moment one table swaps). After the last table the script checks
  `has_table_privilege('ecw_reader', table, 'SELECT')` for every table in `public` (including
  `_copy_log`) and fails loudly if any is false. The P&L keeps working during the upload and an
  aborted run leaves a mix of new and old tables, never a missing or ungranted one. `--only-missing`
  resumes after an abort without re-uploading finished tables.
* Preflight, before any prompt: `scripts/check_mart_columns.py` (new) on the local copy, and the
  same check on `ecw_mart` after the load (section 4). Free-space check from CloudWatch
  `FreeStorageSpace` (read-only): refuse if less than twice the bytes still to upload plus 3 GB.
* Upload time: about 1 MB/s means 3.8 GB is about 60 min from scratch; 2.0 GB of it (the 101
  tables not on AWS yet) is about 33 min with `--only-missing`. Compression is not possible
  through the SSM port tunnel; gzip to S3 and a load from the ops instance would cut it to about
  10 minutes but adds an S3 write and a new door, so it is a later option, not this plan.

## 3. PHI and identifier checks (layers, all names-only)

1. Mac copy: `scripts/check_mart_columns.py <dsn> <schema>` applies the shared rules
   (`keep_columns` + `check_columns`) to every table and fails on any dropped-but-present column,
   any `patient_*` not in `PATIENT_OK`, any suspect name, any `FREE_TEXT_DROP` column still
   present, `visit_pat_age` over 89, and prints table and column NAMES only (never values).
   The copy script calls it before uploading and again on `ecw_mart` after.
2. Loader on AWS: the existing `DROP_COLUMNS` + `check_columns` on every discovered table
   (deny by surprise: an unexpected identifying column fails that table, others still copy).
3. Generator: the shared safe-column function (section 1A).
4. Catalog: the `TRIPWIRE` on every column of every `analytics` relation, fail closed.
5. Audit: unchanged `ecw_mart_read` rows for every read.
Column handling summary (all derived from the sweep in section 0):
* `dim_reason` (whole table) and `follow_up_requested_reason`: not copied (free text).
* record keys (explicit hide list, section 1A): copied to `mart` (kept for later phi-schema
  features), hidden from every generated view; `preg_id`, `contact_id`, `master_contact_id` are NOT
  copied at all (pending owner, recommended).
* `fact_ob_preg`, `fact_ob_flowsheet`, `fact_ob_req_buckets`, `report_ob_dash_telos`: NOT copied
  row-level (pending owner, recommended). They hold pregnancy, delivery and postpartum dates per patient
  (`fact_ob_preg`: 94 columns, 11,431 rows); with provider, facility and insurance, a delivery date
  identifies a person to anyone who knows her, and the builder returns and exports raw rows. They come
  later as aggregate-only views (counts by week, clinic, bucket) built by hand, or with the date columns
  dropped. `report_active_ob_patients_snapshot` (31,768 rows, one date) is copied without `preg_id`.
* the 4 facility address/phone/zip columns: copied, left out of the views.
* staff names (`created_by_name`, `agent_name`, `biller_name`, `assigned_to_name`,
  `scrubbing` names, about 22 columns): workforce data, not patient data; shown as for
  `provider_name` today. Default decision, not a question; say if you want them hidden or masked.
* Other patient-level fact tables without an id (visits, encounters, claims): allowed, because the
  dates are service dates, not birth, delivery or pregnancy dates, and the keys are hidden. The
  engine's small-cell masking (k = 11, keyed on `provider_name`) does not apply to raw views;
  the runbook says so.

## 4. Storage and cost (both environments)

* Sizes (116 tables, about 3.7 GB data): `ecw_mart` 1.8 GB to 3.7 GB; schema `mart` 1.8 GB to 3.7 GB
  plus the indexes of section 1D (about 1.2 GB; none in `ecw_mart`): about 8.6 GB for both copies, so
  about 2x as expected plus indexes. "14-16 GB free" on each 20 GB instance is the coordinator's figure
  and is NOT verified; the independent checker reads CloudWatch `FreeStorageSpace` (read-only) before
  step 2, and the scripts refuse to start under 8 GB free.
* Peak, not just total: a swap or a TRUNCATE+COPY keeps the old file until commit, so the biggest
  table needs about 2 x 481 MB at once, in `ecw_mart` and again in `mart` (not at the same time).
  WAL: each bulk load writes about the size of the data again (about 3.7 GB for the upload, about
  4.9 GB for the nightly reload including index builds); RDS archives it within minutes, so the
  transient on the disk is about 2-3 GB. Worst case moment: existing data about 2 GB + 8.6 GB + 1 GB
  peak + 3 GB WAL = about 14.6 GB of 20 GB, about 5 GB free (25%). If the real free figure is lower
  than 8 GB, raise allocated storage to 40 GB in `infra/meridian/stacks/data.py` first (a data
  deploy, about $2.3 per month per environment); autoscale to 100 GB is only the backstop.
* Keep `ecw_mart.public` after the load. Not droppable: (a) the P&L run reads 7 of its tables
  straight from it (T:261, the `ecw-db` secret, `ECW_MART_SOURCE_DB`); (b) it is the only source
  the 05:00 task can reach (the outside mart is closed to the NAT addresses); (c) dropping it
  means a 65 min re-upload to rebuild `mart`. The 2x is the price of the P&L door and of nightly
  rebuilds.
* Cost: gp3 is about $0.115 per GB-month, so about +4 GB in `ecw_mart` and +2 GB in `mart` is
  about $0.7 per month per environment, plus about $0.15 for the indexes (about $1.7 for both). The nightly task at worst 1 hour on
  0.5 vCPU / 1 GB Fargate is about $0.03 a night. Task-to-RDS traffic stays inside the VPC, so it
  adds no NAT charge; the Mac upload costs nothing. Backup storage up to the database size is free.
  Total: about $2 per month.

## 5. Ask (Bedrock) with 121 tables

1,455 columns as catalog JSON is about 60-90 KB, about 20-30 k tokens in the cached system
prompt (`bi_ask._system`, 1 h cache). Cache write on Haiku is $2 per M tokens, so a cold prompt
costs about $0.05, and the cache is per hour per process; with the $10 monthly cap this eats the
cap faster than the questions do. Accuracy also drops when Haiku has to choose between
`dim_next_appt_vt` and `dim_next_comp_appt_vt`.
Decision (default, Open question 3): Ask sees the curated tables in full, exactly as today, plus a
COMPLETE compact index of every generated table built from the same catalog: one line per table,
`ecw_<table>(col:t,col:n,col:d,...)` with a one-letter type (text, number, date) and every kept column
name, no display names. Because the index lists every column the catalog allows (hidden record
keys are not in it), the model cannot name a column that is not in the catalog. About 1,100 kept
columns at about 5 tokens each is about 6 k tokens, against 20-30 k for the full JSON. Ask may
build a query on any `ecw_` table with the index (the compiler checks against the full catalog; a
type slip gets the existing one-retry on the stronger model). `_category_columns` stays limited to
curated tables and small `ecw_dim_*` tables, so KNOWN VALUES does not grow. The question
builder (human) sees all tables with full metadata. If real questions show the index is not enough,
the follow-up is a two-step ask (pick tables, then send full columns of those), not this plan.
Tests: (a) the system prompt text before the index block is byte-identical to today's (golden
compare, catches accidental change to the curated prompt); (b) index block under 8 k tokens
(chars / 3.5) and total under the recorded baseline + 8 k; (c) every column in the index exists in the
catalog and no hidden record key appears; (d) a measured cold-prompt cost line in the test output
(Haiku $2 per M cache write, about $0.07 cold).

## 6. Tests

* `tests/test_sync_data_mart.py`: the "refuses `--tables` outside RDS_TABLES" test uses the new
  list; add: an unlisted source table is skipped and logged; `FREE_TEXT_DROP` and `NEVER_COPY_COLUMNS` columns are not in
  the target; indexes are created after load for tables over 200,000 rows; per-table `_copy_log`
  skip (newer, older, rules_version changed, partly failed run); `DROP VIEW` + `CREATE` for
  regenerated views; `dim_reason` is not copied; target session sets `statement_timeout`; `_copy_log`
  newer/older/missing branches; a recreated table drops its `ecw_` view first.
* `tests/test_apply_analytics_views.py`: generated SQL for a fixture with the real column names
  (new `tests/fixtures/mart_columns.txt`, names and types only, from this session's sweep) passes
  `guard_sql`; every generated view selects `t.org_id` and is `security_invoker = false`; no
  generated column matches `TRIPWIRE` unless allowed; the 4 facility columns and the two free-text
  columns are absent; mart absent leads to SKIP, not failure.
* `tests/bi/test_catalog.py`: `ecw_` policy (every surviving column present, types mapped, every
  name in the hide list absent, the 134-name fixture fully classified, derived FKs for the five biggest
  facts (section 1C), index rule picks the expected columns, Category only for small dims); curated tests scoped away from `ecw_`; tripwire
  still raises on an injected `ecw_x.patient_name`; the five "addressed" names allowed.
* `tests/bi/test_ask.py`: the four checks of section 5; `_category_columns` does not query
  generated facts.
* `tests/test_mart_views_sql_pg.py` (pg fixture): create 3 small fake mart tables, run the
  generator, reader login can `SELECT` from the `ecw_` views (proves the default privileges),
  cannot `SELECT` from `mart.*`.
* `tests/test_check_mart_columns.py`: names only in the output, fails on each rule above.
* Staging timing gate (section 1D): five biggest views, three queries each, each under 10 s,
  numbers written into the runbook; `ecw_reader` can SELECT every `ecw_mart.public` table.
* Live (staging after load; adjacent to T:257, not absorbed): row counts per `analytics.ecw_*` view
  equal the `mart` tables; one `/verify` run asks "claims by payer last month" via the builder and
  one Ask question about a generated table.
* Gate before every commit: `pytest tests/bi tests/test_sync_data_mart.py
  tests/test_apply_analytics_views.py tests/test_mart_views_sql_pg.py tests/test_check_mart_columns.py -x`
  (`tests/bi/test_catalog.py` is inside `tests/bi`; the earlier `tests/test_catalog*` did not exist), ruff, `scripts/lint_org_scope.py`.

## 7. Tasks (execution order; each task ends with the tests above passing)

1. Shared rules and checker: `src/mart_columns.py`, `scripts/check_mart_columns.py`,
   `tests/test_check_mart_columns.py`, `tests/fixtures/mart_columns.txt`. No behaviour change yet.
2. Loader: `scripts/mart_target.py` (reviewed list of 116, `FREE_TEXT_DROP`, `NEVER_COPY_COLUMNS`, `rules_version`),
   `scripts/sync_data_mart.py` (list intersection, timeout, indexes + ANALYZE, view drop, per-table `_copy_log` skip, `--no-snapshots` flag),
   tests in `tests/test_sync_data_mart.py`.
3. Copy script: computed table list, per-table swap, `--only-missing`, preflights, `_copy_log`, per-swap grant,
   dry run (`--dry-run` lists tables and bytes, writes nothing); the two wrappers
   `scripts/ecw_mart_staging` (has no copy wrapper today: add `6b-copy-ecw.sh`, because `7-first-load.sh`
   already holds number 7 there) and `scripts/ecw_mart_production/7-copy-ecw.sh` echo the new time estimate.
4. Views and catalog: generator in `apply_analytics_views.py`, `bi_catalog.py` policy,
   `TRIPWIRE_ALLOWED` additions, hide list, derived FKs, `HIDE_TABLES`, data-picker heading, tests. Ask scope in `bi_ask.py` with its tests.
5. Runbook and tracker: `docs/runbooks/ecw-mart.md` (all tables, timings, section 4 failure modes,
   rollback), `docs/migration-tracker.md` (T:256/T:253 text; add the new row), ADR 0053 addendum
   (`docs/adr/`), vault note. Then the independent checker (no shared context): infra tests (no
   infra change expected, run anyway), `cdk synth`, read-only AWS checks (RDS available, free
   storage, secret points at `ecw_mart`), and `/verify` for the app change.

## 8. Scripts Andres runs (after the checker passes; staging first, production second)

Per environment, same steps, one at a time, report to me between steps:

| # | Command | What it does | Time |
|---|---------|--------------|------|
| 0 | refresh the Mac copy with main's `scripts/sync_data_mart.py` (main checkout) | refresh and scrub the Mac copy (skip if it is fresh) | per today's run |
| 1 | `python scripts/check_mart_columns.py "dbname=meridians_ecw" mart` | names-only identifier check of all tables | under 1 min |
| 2 | staging `bash scripts/ecw_mart_staging/6b-copy-ecw.sh` (production `bash scripts/ecw_mart_production/7-copy-ecw.sh`) | uploads the 116 tables to `ecw_mart` with per-swap grants (y/N prompts; `--only-missing` resumes) | about 60 min full, about 33 min for the 101 missing |
| 3 | staging `7-first-load.sh` (production `8-first-load.sh`), edited as below | 5a loader for all reviewed tables, 5b views incl. the generated ones, 5c snapshots | planning 80-100 min (loader 70-90 + indexes); measured on staging, then production |
| 4 | timing gate queries (section 1D), `/verify`, one Ask question | proves speed and the app | 15 min |

First-load script edit (both environments): step a drops its `--tables "$TABLES"` list and runs
`sync_data_mart.py --target rds --no-snapshots` (full reviewed list; the snapshot step stays after
5b, so snapshots never run against the old views). Failure handling: the loader copies every table
it can, exits 1 if any failed, and prints the failed names; the script stops before 5b, and Andres
re-runs step a once with `--tables <failed names>` (allowed because they are on the reviewed list),
then continues. Step b is `apply_analytics_views.py --target rds`, step c `--snapshot-only`, unchanged.

Staging stops its database at 02:00 UTC, so run step 3 the same day and leave 05:00 alone that
night (expected failure, runbook section 4). Production: only after staging passes the timing gate
and /verify; run step 3 in the evening, not at 05:00. The first production night after load is the only
nightly timing proof: check
`aws logs tail /meridian/production/ecs/mart-sync --since 24h`.

## 9. Rollback

* No data is lost by any step: `ecw_mart` per-table swap, so a failed upload leaves old tables in
  place. If the new `mart` copy misbehaves, redeploy the old commit: the loader goes back to the
  11-table list and the old views; the extra 105 `mart` tables and `analytics.ecw_*` views are
  harmless leftovers (`DROP VIEW` of every `ecw_` view then `DROP TABLE` of the extra tables as
  `meridian_mart_owner`, which I hand you as one reviewed script `scripts/ecw_mart_*/rollback-all-tables.sh`
  with a `--dry-run`).
* Fastest off switch for exposure (no deploy): `DROP VIEW analytics.ecw_*` (generated names only),
  the catalog cache drops the tables within 5 minutes (`CACHE_SECONDS = 300`). BI itself and the
  15 curated tables stay up.
* Full off: redeploy compute without `-c ecwMart=true` (runbook section 3; keep every other flag).
* Storage cannot be reduced on RDS; the extra GB stay allocated (about $1 per month); acceptable.

## 10. Decision coverage

* D "all tables, no IDs": 116 of 121 copied (all 121 minus `dim_reason` (free text) and four `ob`
  tables with patient-level pregnancy dates, pending owner, section 3; `preg_id`, `contact_id`,
  `master_contact_id` not copied), no patient identifier columns anywhere (three scrub layers plus tripwire), record
  keys held back from BI by default.
* Deferred: identifiers in `phi` schema (explicitly later); true incremental from the source;
  gzip-via-S3 upload; the Daily Report precompute and card-result cache (separate fix); aggregate-only
  views of the `ob` tables; opening native SQL (T:260).

## Open questions (default in bold; I proceed with the default if you do not answer)

1. **Record keys in BI** (`encounter_id`, `claim_no`, `visit_id`, `referral_id`, `*_enc_id`):
   **hide from the question builder (kept in the AWS copy for later)** vs show. Showing allows
   fact-to-fact joins; hiding matches how the hand-written views already treat `visit_id`. Easy to
   flip later (edit the hide list, rerun apply).
2. **Free-text reasons** (`dim_reason.reason`, `follow_up_requested_reason`): **do not copy** vs
   copy. They are staff-typed and can contain names; the owner rule "no IDs" does not cover text
   that can embed them. Loses the visit-reason table (about 70 MB, no numbers in it).
3. **BI allowlist for the generated tables:** **fail closed by rule (every column that passes the
   identifier tripwire, type check and the shared deny list is shown, no hand-written metadata
   per column) and Ask limited to the curated tables plus an index of the rest** vs hand-list
   every column (about 1,450 entries, weeks of work) or give Ask all 116 tables (about 25 k
   tokens, higher cost and worse accuracy).
4. **Pending owner, recommended defaults already applied in this plan:** do not copy `preg_id`,
   `contact_id`, `master_contact_id`, and do not copy `fact_ob_preg`, `fact_ob_flowsheet`,
   `fact_ob_req_buckets`, `report_ob_dash_telos` row-level until aggregate-only views exist. Say
   "copy them" to reverse; the `ob` tables would then need their date columns dropped or masked first.
