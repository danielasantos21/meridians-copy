# 261018-cob — Cobalt eCW snapshot on AWS so Operations works (tracker T:251)

Status: PLAN only, nothing built. Branch `merge/main-into-aws-2026-10-16`. Date 2026-10-18.
Follows ADR 0053 ("mart first, Cobalt next"). Every AWS command below is "Andres runs; independent
checker reviews first" (CLAUDE.md), staging first, production second.

**Revision 2 (after independent check `261018-cob-CHECK.md`, commit c8948d6d).** Owner decisions are final:
manual copy now; schema `mart` behind the audited door (ADR 0054); every Operations read audited; payment check
and ERA ids dropped at copy time.
**B2 - PENDING OWNER CONFIRMATION:** clinician (provider) NPIs. Default in this plan = KEEP them (public NPPES
registry data, not patient data; BI shows `dim_provider.npi` on purpose, `src/bi_rows.py:27`,
`src/bi_query.py:79-80`, `src/bi_catalog.py:87`, `sql/analytics/020_dimensions.sql:76`). The choice is ONE
constant, `KEEP_CLINICIAN_NPI = True` in `scripts/cobalt_slim.py`; flipping it to `False` drops `providers.npi`,
appointments `provider_npi` and the three line-item NPIs, and `dim_provider.npi` then reads NULL (the test and the
BI catalog note switch with it). Payment check numbers and ERA ids are dropped either way.

## 0. BLUF

* Operations reads **five Cobalt endpoints** (`appointments`, `claims`, `locations`, `providers`,
  `visit-types`) through the owner-run `analytics.*` views `020`..`060`, which read
  `public.cobalt_latest`. On RDS those six files are skipped (`scripts/apply_analytics_views.py`
  `REQUIRES_COBALT`) and `operations_routes._gate` refuses on Postgres. That is the whole gap.
* Recommendation: **extend the ADR 0053 pattern.** Copy the *scrubbed* Cobalt copy from the Mac
  (already free of names/DOB/MRN/phone/insurance ids/notes), **slimmed to the keys the views read**
  (about 67k rows, well under 100 MB, versus 4.3 GB / 1.47 GB elsewhere), into `mart.cobalt_rows`
  in RDS `meridian`; point the six views at `mart.cobalt_latest`; make Operations read through the
  existing audited door `src/mart_source.py` (`meridian_mart_reader`, `ecw_mart_read` audit pair).
* **No new Alembic revision, no new infra, no new env var** are needed for the first working version
  (schemas, roles, default privileges, `MART_DB_*` and `ECW_ORG_ID` all come from 0048 and
  `-c ecwMart=true`). Freshness = the last time Andres runs the copy script (see section 3 for the
  nightly follow-up that removes the Mac).
* Depends on ADR 0053 being live first (the `ecwMart` flag deployed, runbook `docs/runbooks/ecw-mart.md`
  steps 1-5 done on that environment).

## 1. What Operations needs (read from the code)

Path: `web/src/app/operations/page.tsx` + tabs -> `/api/v2/operations/{kpis,claims,portfolio}`
(`api/routers/operations.py`, permission `operations:access`) -> `src/api/v2/operations_routes.py`
(`_gate`, `_check_tenant`, one `ecw_cursor()` per request) -> `src/operations_kpis.py` and
`src/operations_claims.py` (SQL strings + counting). The "eCW data isn't connected on this server yet"
message is `ECW_NOT_CONNECTED` from `_gate` when `ECW_DB_*`/`ECW_ORG_ID` are unset **or the backend is
Postgres** (`_on_postgres()`); the screen only displays it.

| Needs (analytics object) | Built by | Reads Cobalt endpoint / JSON keys |
|---|---|---|
| `fct_appointment`, `dim_location`, `dim_provider`, `dim_visit_type`, `sync_status` | `020`,`030`,`060` | appointments: `id`, `datetime`, `created_at`, `status`, `appointment_type`, `location`, `provider_ehr_id`, `provider_name`, `duration`, `emr_appointment_id`; locations: `ehr_id`,`name`; providers: `ehr_id`,`name`,`npi`,`specialty`,`credentials`; visit-types: `code`,`description` |
| `fct_claim`, `fct_claim_line`, `fct_claim_dx`, `fct_payment`, `icd_descriptions()` | `040`,`045`,`050`,`060` | claims: `service_date`, `claim_date`, `void_flag`, `total_charge`, `total_payment`, `net_payment`, `net_adjustment`, `patient_responsibility`, `balance`, `claim_status`, `claim_status_description`, `emr_provider_id`, `emr_appointment_id`, `provider_name`, `line_items[]` (`cpt_code`,`description`,`billed_amount`,`allowed_amount`,`units`,`place_of_service`,`icd_pointers`), `icd_codes[]` (`code`,`primary`,`description`), `payments[]` (`payment_date`,`amount`,`payer_type`,`payment_type`) |
| `analytics.tenant` (1 row, org) | `010`, seeded by `apply_analytics_views.py` from `ECW_ORG_ID` | none |

Already on RDS (0048 + `--target rds`): `000`, `010`, `085`, `090`. Operations does not read the 11 `mart.*` tables.

## 2. Where the Cobalt data comes from, and how fresh

* **Producer:** `~/Desktop/Meridian/scripts/cobalt_nightly.py` (old repo path; not in this repo), run by
  launchd `~/Library/LaunchAgents/com.meridian.cobalt-nightly.plist` at **04:00 daily on the Mac**
  (log `~/MeridianReports/logs/cobalt_nightly.log`). It pulls the Cobalt API read-only and writes
  versioned rows (a row is stored again only when it changed) to **two** Postgres copies:
  * **SCRUBBED** -> always-on Homebrew Postgres, port 5432, database `meridians_ecw`, table
    `public.cobalt_rows(endpoint, id, pulled_at, data jsonb)` + view `public.cobalt_latest` +
    `public.cobalt_runs`. Drops every key `daily_brief_run.banned_key()` flags, recursively
    (names, DOB, MRN, phone, insurance ids, medications, notes, patient id). Dates, CPT/ICD, money and
    CARC codes stay: a HIPAA *limited data set*, not de-identified.
  * **RAW** -> second Postgres on port 5433 (`meridians_ecw_raw`, socket only) whose data folder is in the
    encrypted vault `/Volumes/MeridianECW/cobalt-pg`. Contains the full `patients` endpoint (258,747
    patients) and free text. **Never a source for AWS.** The long-running `psql ... -p 5433 ... \copy s from
    pstdin` (pid 87990, 5 days 10 h old, near-zero CPU) is a stale orphan of that raw loader holding an open
    transaction; the 18 Oct 04:07 run finished fine (384,919 raw rows). Flagged for Andres, not touched.
* **Sizes (read-only `pg_database_size`/`pg_total_relation_size`, no row data):** raw DB 1,470 MB (1,462 MB
  `cobalt_rows`); scrubbed `cobalt_rows` 429 MB total, whole `meridians_ecw` database 4,345 MB (the
  mart copy is most of it). Latest-version rows Operations needs: appointments 39,238 (22 MB), claims
  27,804 (73 MB compressed / 255 MB as text), locations 76, providers 75, visit-types 74. In the claims,
  `billing_activity_log` + `submission_history` are ~146 MB and `payments[].era_*` more; Operations reads none.
* **Freshness:** data through the last 04:00 run (appointments window: 14 days back, 7 ahead; claims window
  per `--days`). `fct_appointment` and `analytics.sync_status` already compute "last synced" from
  `max(pulled_at)`, so the screen shows honest staleness. On AWS it is as old as the last copy.
* **Identifier columns.** The table has only `endpoint,id,pulled_at,data`; identifiers live inside `data`.
  In the scrubbed copy what is left that can link to a patient in eCW: appointment keys (`id`,
  `ehr_appointment_id`, `emr_appointment_id`), claim keys (`id`, `emr_claim_id`), `payments[].check_number`,
  `era_payer_claim_id`, `era_reference_id`, `member_balance`, `provider_npi`/`ordering|referring|rendering_provider_npi`
  (clinician, not patient), free-text `description` on `icd_codes[]`, and every date (service, payment,
  appointment time). Names/DOB/MRN are already gone.

## 3. Options

| | A. Copy from the Mac, like `copy_ecw_mart_to_aws.sh` (**recommended now**) | B. ECS task pulls Cobalt API nightly | C. Copy the whole scrubbed table |
|---|---|---|---|
| How | New `scripts/cobalt_slim.py` (+ `scripts/copy_cobalt_to_aws.sh`) streams slimmed latest rows from `meridians_ecw` over the SSM tunnel into `mart.cobalt_rows` as `meridian_mart_owner` | Port `backend/cobalt.py` + scrub rules into this repo; scheduled ECS task writes `mart.cobalt_rows`; Cobalt creds in Secrets Manager | `pg_dump` of `cobalt_rows` |
| Fresh | When Andres runs it (e.g. after 04:00); can be a daily manual habit | Nightly, no Mac | same as A |
| Effort | Small: 1 script + 1 shell + SQL/route tweaks | Large: port credentials, paging, scrub rules (PHI rules must be re-proved), IP allowlist at Cobalt for the NAT, new task/schedule/IAM | trivial but ships 429 MB incl. 6 unused endpoints (eligibility, orders, referring providers, pharmacies...) and hidden free text |
| PHI | Minimum necessary (whitelist) | Same, plus credentials in AWS | Worst |

Recommendation: **A now; B as a separate follow-up (new tracker row)** once Andres confirms Cobalt allows the
NAT address. A's loader contract (`mart.cobalt_rows` latest-only, fixed DDL) is what B would also write, so
nothing is thrown away. C rejected.

## 4. PHI handling

* **Where it lives:** schema `mart` of RDS `meridian`, per ADR 0053 (not the `phi` schema). Same reasoning
  as the ADR: a single-tenant rebuildable staging copy that **no application role can read** (zero grants;
  `meridian_app`/`phi_access` have nothing on `mart`), reached only through owner-run views
  (`security_invoker = false`) by `meridian_mart_reader`. T:251 originally sketched a `phi` table with
  `org_id` + RLS; that is superseded for the same reasons (nightly rewrite, no reader). Record it in
  **ADR 0054** (short, "Cobalt in mart", reopens only with a second tenant).
* **Stripped at copy time (in `scripts/cobalt_slim.py`, whitelist not blacklist):**
  keep only the keys in the section 1 table. Drop: all of `billing_activity_log`, `submission_history`,
  `object_metadata`, `schedule_block_color`, `local_datetime`, `ehr_appointment_id`, `secondary_provider_ehr_id`,
  on appointments; on claims drop `emr_claim_id`, `claim_type`, `synced_at`, `updated_at`,
  `balances`, `void_claim`; in `payments[]` drop `check_number`, `era_*`, `member_balance`, `withheld`, `payer_id`,
  `payer_name`, ids. **Clinician NPIs** (`providers.npi`, appointments `provider_npi`, line-item
  ordering/referring/rendering NPIs) follow the single flag `KEEP_CLINICIAN_NPI` (default True = kept, pending
  owner confirmation, see top). Endpoints not in the five are never read. The patient list and the RAW copy
  are never touched.
* **Source guard (W6):** the slimmer refuses any host that is not loopback, port 5433, any database name other
  than exactly `meridians_ecw` (the raw one is `meridians_ecw_raw`), and any `cobalt_rows` that has a `patients`
  endpoint (the scrubbed copy has none today, so the guard is satisfiable).
* **ICD description release rule at copy time (W3):** `icd_codes[].description` is typed free text (the scrubber
  is key-based; values are not scanned). The slimmer applies the same rule as `analytics.icd_pick`
  (`060_sync_status_icd.sql`): a description is kept for a code only if it is that code's most frequent description
  (ties alphabetical), appears on >=10 distinct claims, is <=80 chars and has no digit that is not in the code;
  every other description is set to null before it leaves the Mac. The view-side rule stays as the second layer.
* **Kept on purpose (cannot be removed without breaking the views):** `id` and `emr_appointment_id`
  (claim -> appointment join, `040`), dates, CPT/ICD codes, money, `icd_codes[].description` (only released
  through `analytics.icd_descriptions()` with the existing >=10-claims / <=80-chars / no-stray-digits rule in
  `060`). These stay inside `mart`, never selected as columns by any view (comments in `040`/`045`).
* **Audit:** Operations switches from the unaudited `ecw_cursor()` to `mart_source` so each uncached request
  writes one opened + one closed `audit.phi_access` row (`action = ecw_mart_read`, `object_name` =
  `mart:operations.kpis|claims|portfolio` (`src/phi.py:755` prefixes `mart:`), closed row = row count, no values). No use of the `phi` role or
  `src/phi.py` DDL changes beyond adding the three names to `phi.MART_READ_OBJECTS`. Support sessions without
  PHI access are refused by `read_scope` exactly as for BI. Native SQL stays refused (T:260).
* **Dumps/restores:** `mart` is already excluded from dumps (runbook section 5); no change.
* Local DB `meridians_ecw` keeps its existing protections; nothing PHI is written to the repo, the vault, or
  logs (script prints counts only, errors through `scrub()`).

## 5. Alembic changes

None required. 0048 already created `mart`/`analytics`, `meridian_mart_owner` (owns both), and
`meridian_mart_reader` (USAGE + default SELECT/EXECUTE on `analytics`, 60 s statement timeout, zero on
`mart`). The loader creates `mart.cobalt_rows` / `mart.cobalt_latest` as the owner (so it owns them; the
reader gets nothing). `tenant_tables.txt` and `lint_org_scope` are unchanged (`mart` is not in
`gen_tenant_tables.SCHEMAS`).
Conditional: if staging shows `fct_claim` queries exceeding the reader's 60 s timeout (jsonb parse of ~70 MB),
add **0049_mart_reader_timeout** (`ALTER ROLE meridian_mart_reader SET statement_timeout = ...`) rather than
changing the views; renumber check against the 0038-0044 note in CLAUDE.md. Measure first (step S6 below).

## 6. Code changes (all under this repo; no .env reads)

1. `scripts/cobalt_slim.py` (new): pure `slim(endpoint, data) -> dict` + `ENDPOINTS`, header comment, `--help`,
   `--dry-run` (counts and byte sizes only), streams `SELECT endpoint,id,pulled_at,data FROM public.cobalt_latest
   WHERE endpoint = ANY(%s)` with a server-side cursor, writes COPY text to stdout. Reads the local DSN from
   `COBALT_PG_DSN` (default `dbname=meridians_ecw`, as `cobalt_nightly.py`), refuses non-loopback.
2. `scripts/copy_cobalt_to_aws.sh staging|production` (new, modelled line by line on
   `scripts/copy_ecw_mart_to_aws.sh`): AWS SSO account check, RDS available (staging may be stopped), SSM
   tunnel via `meridian-$ENV-ec2-ops` on local port **55481 (staging) / 55482 (production)** as the existing script,
   `sslmode=verify-full`, `hostaddr=127.0.0.1`, `sslrootcert=$HOME/.postgresql/rds-ca.pem`, and
   `export PGOPTIONS="-c statement_timeout=0"` (RDS stops any statement after 5 min, `infra/meridian/stacks/data.py`
   `STATEMENT_TIMEOUT_MS`; W1), then logs in as **`meridian_mart_owner`** with the password from
   `meridian-$ENV-secret-db-mart-owner` (env var only, never printed; no RDS master login needed).
   Creates once (as owner, in `mart`): `cobalt_rows(endpoint text, id text, pulled_at timestamptz, data jsonb)`,
   index `(endpoint,id)`, and `cobalt_latest` view (same definition as the local one). Then, in ONE transaction
   per run: `TRUNCATE mart.cobalt_rows` + `\copy` from `cobalt_slim.py`; prints before/after row counts per
   endpoint and `max(pulled_at)`; y/N prompts like the existing script. Never drops the table (the views depend
   on it). Lock window is seconds (tens of MB).
3. `scripts/apply_analytics_views.py`: for `--target rds`, move `REQUIRES_COBALT` from "always skip" to the
   **new** skip-while-empty code (`mart_missing()` at line ~438 only tests `report_measures_table`): skip unless
   `to_regclass('mart.cobalt_latest')` exists and `mart.cobalt_rows` is non-empty; the same change in `check()`
   (~line 530, same `REQUIRES_COBALT` skip) and new `EXPECTED` entries so `--check` verifies the Cobalt views; and rewrite `public.cobalt_latest` / `public.cobalt_rows` to `mart.cobalt_latest` /
   `mart.cobalt_rows` (including `SET search_path = pg_catalog, analytics, public` in `icd_descriptions`)
   before executing; the SQL files stay unchanged so the local path is identical. `--check` must still pass.
   `grep -n "public\." sql/analytics/*.sql` after rewrite must show no leftover app-table reference
   (new test).
4. `src/api/v2/operations_routes.py`: **(B1, no recursion)** rename the old `_gate` body to `_gate_local` (unchanged except the
   `_on_postgres()` clause is removed) and point the non-Postgres branch of `mart_source.gate` at
   `operations_routes._gate_local`; the routes then call `mart_source.gate(org_id)` directly (a new `_gate` that
   delegates to `mart_source.gate` may remain only if `_gate_local` is what `mart_source` calls). Test: both
   backends return, no RecursionError; in `kpis/claims/portfolio` use `with mart_source.read_scope(org_id, user_id, "operations.<x>"):
   with mart_source.mart_cursor() as cur:`; map `MartReadNotAudited`/`MartNotConfigured`/`SupportPhiRefused` to
   503 `ECW_NOT_CONNECTED` for the first two exactly as `bi_routes.py` ~99 does; `SupportPhiRefused` is NOT mapped: `api/errors.py:225-233` already turns it into 403 PERMISSION_DENIED, leave it; fix the "NOT ON RDS YET (T:251)" docstring.
   `api/routers/operations.py`: pass `identity.user_id` to the three calls.
5. `src/phi.py`: add `operations.kpis`, `operations.claims`, `operations.portfolio` to `MART_READ_OBJECTS`.
6. Env / infra: **none.** The api already gets `MART_DB_HOST/PORT/NAME/USER/PASSWORD` and `ECW_ORG_ID` from
   `-c ecwMart=true -c ecwOrgId=<uuid>` (`infra/meridian/stacks/compute.py` ~1173). Operations on AWS works
   iff that flag is on. `web/` needs no change (it only renders the 503 message).
7. Docs: ADR 0054 (must also say that BI gets the `fct_appointment`, `fct_claim`, `fct_claim_line`, `fct_claim_dx`,
   `dim_provider` views once S5 applies them, `src/bi_catalog.py:98-182`, audited as `bi.*`, and that BI permission is
   intended; W7); runbook `docs/runbooks/ecw-mart.md` new step "5d Cobalt for Operations"; tracker T:251
   rewritten (and a new row for option B); CHANGELOG + PATCH bump per CLAUDE.md.

## 7. Tests

* `tests/test_cobalt_slim.py`: synthetic fixtures only (no real row, no real names): whitelist keeps exactly the
  listed keys, drops every listed key recursively, unknown extra keys dropped, refuses endpoints outside the five,
  refuses a DSN pointing at the raw copy / one containing `patients`.
* `tests/test_apply_analytics_views.py`: on rds the Cobalt files are skipped when `mart.cobalt_rows` is missing
  and applied (with `mart.` rewrite) when present; no leftover `public.` table reference.
* `tests/test_api_v2_operations.py`: about 35 tests patch `ops.ecw_cursor` (lines ~174, 271, 418); after the change
  the routes use `mart_source.mart_cursor`, whose non-Postgres branch calls `mart_source.ecw_cursor`, so the fixtures
  are re-pointed to patch that (keep the `ops` names the tests import). Then replace `test_postgres_backend_is_503_before_any_ecw_connection` with
  (a) Postgres + unconfigured -> 503, no connection; (b) Postgres + configured -> 200 via a fake `mart_cursor`,
  one `read_scope` with `operations.kpis`; (c) other org -> 404; (d) no scope -> `MartReadNotAudited` -> 503.
* `tests/test_phi_mart_read_pg.py`: the three new `what` values write the opened/closed pair.
* Live PG test beside `tests/test_mart_views_sql_pg.py`: seed synthetic `mart.cobalt_rows`, apply 020-060 as
  owner, assert `meridian_mart_reader` can `SELECT` `analytics.fct_appointment` but gets permission denied on
  `mart.cobalt_rows` and `mart.cobalt_latest`, and `meridian_app` can read neither schema.
* `tests/test_migration_0048_ecw_mart_pg.py`: extend the "reader has nothing on mart" assertion to a
  loader-created `mart.cobalt_rows`.
* Parity: compare `/api/v2/operations/kpis` for one closed past window on the Mac (5051/3005 per memory) vs the
  AWS app after the copy (same snapshot, so counts must match); `scripts/check_operations_parity.py` for the
  local side. Then `/verify` on the running app. Infra tests/`cdk synth`: no template change expected; run them
  anyway (`infra/tests/test_mart.py`) and let the independent checker confirm the synth is byte-identical.

## 8. Runbook steps (Andres runs; checker reviews first; staging, then production)

Precondition: ADR 0053 steps 1-6 done for the environment (mart flag deployed, BI shows numbers).

S1. Merge/deploy the code above (images + compute with the **same flags as today**, including
    `-c ecwMart=true -c ecwOrgId=<uuid>`; a dropped flag removes the feature). Checker reads the synth diff
    (expect none) and the live account read-only (`describe-services`, secrets exist).
S2. On the Mac, make sure the scrubbed copy is current: `launchctl list | grep cobalt-nightly`, last line of
    `~/MeridianReports/logs/cobalt_nightly.log` shows today's "scrubbed: N rows".
S3. `python3 scripts/cobalt_slim.py --dry-run` (counts and sizes; expect ~39k appointments, ~28k claims, 76/75/74).
S4. `aws sso login --profile meridians-admin`, then
    `bash scripts/copy_cobalt_to_aws.sh staging` (answer the y/N prompts; read the row counts it prints).
S5. Apply the Cobalt analytics views on RDS (run_mart helper from runbook step 5):
    `run_mart python3 scripts/apply_analytics_views.py --target rds`; wait for exit code 0, read
    `aws logs tail /meridian/$ENV/ecs/mart-sync --since 30m` (expect no `SKIP 020..060`).
S6. Time the heaviest request (`/api/v2/operations/claims?tab=billing` with a 366-day range) in the app; if
    over ~45 s add 0049 (timeout) before production.
S7. `/verify`: open Operations as a user with `operations:access`: no "isn't connected", counts equal the
    Mac for the same window; `select action, object_name, count(*) from audit.phi_access where action =
    'ecw_mart_read' and object_name like 'mart:operations.%' group by 1,2` shows rows; a user without the right
    still gets 403; a support session without PHI is refused.
S8. Repeat S2-S7 with `production`. Update the runbook "Executed:" line and close T:251.
Rollback: compute deploy without `-c ecwMart=true` (Operations returns to "not connected"); `mart.cobalt_*`
are a rebuildable copy: `TRUNCATE mart.cobalt_rows` as owner removes the data.
Refresh: rerun S2 + S4 (+ S5 only if the loader reports changed columns). Staging RDS may be stopped by schedule;
start it first (runbook step 3).

## 9. Cost

~$0: +<100 MB RDS storage and backups (cents), no new compute, no new secrets, tunnel via the existing ops
instance. Option B later: ~$0.3-1/month Fargate + NAT, one secret ($0.40).

## 10. Risks

* **Stale data on AWS** between manual copies (mitigated: the screen shows last sync; option B removes it).
* **Mac availability / vault:** only the always-on scrubbed DB is needed; if the 04:00 job missed a night, rerun
  `cobalt_nightly.py` first (it backfills 14 days).
* **Wrong source:** pointing the slimmer at the RAW copy would ship patient lists; guarded by the DSN/`patients`
  refusal and by never reading port 5433.
* **Heavy views on a small RDS** (claims JSON parse): measured in S6; fallback is a timeout revision or slimmer
  JSON, not a different design.
* **Whitelist drift:** a future view reading a new JSON key silently gets NULL on AWS. Test: derive the key list
  by grepping `sql/analytics/*.sql` and assert it is a subset of the whitelist.
* **Limited data set on AWS** (dates, claim/appointment keys). Same exposure class as the existing mart copy
  (which holds encounter-level rows), but it must be named in the privacy notes when ADR 0054 is written.
* **Lock window** during `TRUNCATE`+`COPY` (seconds); an Operations request in that window may time out once.
* Alembic number collision (CLAUDE.md note) only if 0049 is needed.
* Side finding: orphan `psql` pid 87990 on the vault DB (open transaction for 5 days).

## 11. Open questions for Andres (max 3)

1. **Freshness:** is "as fresh as the last time you run the copy script (after the 04:00 Mac pull)" acceptable
   for Operations on AWS now, with the nightly ECS pull from the Cobalt API (option B, needs your OK that Cobalt
   allows our NAT address and that its credentials may live in Secrets Manager) tracked as the follow-up?
   *Recommended default: yes to A now, B later.*
2. **Where the PHI lives:** keep the slimmed snapshot in `mart` (no `org_id`/RLS, no app-role access, audited
   door, as ADR 0053) instead of a `phi`-schema table with RLS as T:251 first suggested?
   *Recommended default: `mart`.*
3. **Audit volume and scope:** accept two `audit.phi_access` rows per uncached Operations request (like BI) and
   a whitelist that also drops provider NPIs and payment check/ERA ids?
   *Recommended default: yes.*
