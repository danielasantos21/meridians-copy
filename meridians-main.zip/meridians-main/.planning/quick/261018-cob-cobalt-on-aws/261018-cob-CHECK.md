# 261018-cob plan check (independent, read-only)

Plan: `.planning/quick/261018-cob-cobalt-on-aws/261018-cob-PLAN.md` (cited as P:line). Code: this worktree,
branch merge/main-into-aws-2026-10-16. Local `meridians_ecw:5432 public.cobalt_latest` queried for key NAMES and counts only.

Goal-backward verdict: if the plan is built as written, Operations on staging would NOT yet show numbers: B1 breaks
non-Postgres tests/behaviour (infinite recursion) and B2/B3 contradict the owner decisions / make the verify step
unpassable. Everything else needed (no Alembic, no infra, no env var, owner can create tables in `mart`) holds.

## BLOCKERS

B1. `_gate` -> `mart_source.gate` recurses forever (P:148-149).
 `src/mart_source.py` gate(): the non-Postgres branch calls `operations_routes._gate(org_id)`. The plan makes
 `operations_routes._gate` a thin call to `mart_source.gate`, so off Postgres each calls the other (RecursionError).
 "Existing circular-safe branch" does not exist. Fix: keep the old body under a new name (e.g. `_gate_local`) and point
 `mart_source.gate`'s non-PG branch at that, or give `mart_source.gate` its own copy of the env check.

B2. Provider NPIs are not all dropped (owner decision 3; P:36, P:98-99).
 `providers.npi` is kept (P:36 lists it; `sql/analytics/020_dimensions.sql:76` selects it). The plan drops only
 appointments `provider_npi` and the three line-item NPIs. Local keys confirm `npi` on 75/75 providers, `provider_npi`
 on all appointments, `ordering|referring|rendering_provider_npi` on every line item. Dropping `providers.npi` makes
 `analytics.dim_provider.npi` NULL; BI exposes it on purpose (`src/bi_rows.py:27`, `src/bi_query.py:79-80`,
 `src/bi_catalog.py:87`), so the plan must say what BI shows (NULL, or hide the column) and test it. Or ask the owner
 to confirm "clinician registry NPI stays".

B3. The audit check in S7 returns nothing (P:107-108, P:199-201).
 `src/phi.py:755` writes `object_name = f"mart:{read.what}"`, so rows are `mart:operations.kpis`. The plan's
 `object_name like 'operations.%'` finds zero rows and the /verify step cannot pass. Fix the query to
 `like 'mart:operations.%'` and the wording in section 4 and the new test.

## WARNINGS

W1. 5-minute statement timeout on the copy (P:136-139). The RDS parameter group sets `statement_timeout` 300 000 ms
 (`infra/meridian/stacks/data.py:229,912`). `copy_ecw_mart_to_aws.sh` sets `PGOPTIONS="-c statement_timeout=0"` for
 this reason; the plan's script does not say so. Add it (a session GUC; the owner may set it).

W2. Test fixture rewiring understated (P:168-171). `tests/test_api_v2_operations.py:174,271,418` patch `ops.ecw_cursor`;
 after the change the routes use `mart_source.mart_cursor`, whose non-PG branch calls `mart_source.ecw_cursor`. About 35
 tests need the fixture re-pointed, not one test replaced. Say so, and keep `ops` importable names the tests use.

W3. ICD free text goes to AWS unfiltered (P:102-105, P:225). `icd_codes[].description` is typed text: 93,189 entries,
 5,832 distinct, 4,348 longer than 80 chars, 15,028 with digits. The scrubber is key-based; values are not scanned. The
 views only ever release descriptions that pass `icd_pick` (>=10 claims, <=80 chars, no stray digits;
 `060_sync_status_icd.sql`). Apply that rule in the slimmer (or truncate/null the rest) to meet "minimum necessary".
 Other kept free-ish fields are low cardinality and safe: claim_status_description 21, appointment status 18,
 appointment_type 42, payment_type 14, payer_type 2, line-item description 492 distinct, none over 100 chars.

W4. `SupportPhiRefused` is not a 503 (P:150-152). `api/errors.py:225-233` already maps it globally to PERMISSION_DENIED
 (403); `bi_routes.py:99` handles only `MartReadNotAudited` and `MartNotConfigured`. Do the same; do not map support
 refusal to ECW_NOT_CONNECTED.

W5. Skip logic for Cobalt views on RDS (P:141-147). `mart_missing()` (`scripts/apply_analytics_views.py:438`) only tests
 emptiness for `report_measures_table`; "skip while missing/empty" for `cobalt_rows` needs new code (check
 `mart.cobalt_rows` non-empty and `mart.cobalt_latest` exists via `to_regclass`). Also `check()` (line ~530) has the
 same `REQUIRES_COBALT` skip to update. `EXPECTED` covers only 000/010, so `--check` will not verify the Cobalt views;
 add expectations or a live test (the plan's PG test partly covers it).

W6. Slimmer source guard is name-only (P:100-101). Also refuse port 5433 and any host not loopback, and match the
 database name exactly (`meridians_ecw`, raw is `meridians_ecw_raw`). Verified now: the scrubbed `cobalt_latest` has
 no `patients` endpoint (14 endpoints, none patients), so the runtime guard is satisfiable.

W7. BI widens too (not in plan). `src/bi_catalog.py:98-182` already lists `fct_appointment`, `fct_claim`,
 `fct_claim_line`, `fct_claim_dx`, `dim_provider`; once S5 applies the Cobalt views on RDS, BI users get them (audited
 as `bi.*`). Name this in ADR 0054 and the privacy notes; confirm BI permission is intended.

W8. Tunnel port and prompts unspecified (P:132-135). State the local port (use 55481/55482 like the existing script,
 not 55439 or 5432/5433/55432) and `PGOPTIONS`, `sslmode=verify-full` with `~/.postgresql/rds-ca.pem`, `hostaddr`.

## OK (verified)

* Whitelist vs actual keys. Every key the views read exists locally and is in the plan's list:
  appointments (id column + datetime, created_at, status, appointment_type, location, provider_ehr_id, provider_name,
  duration, emr_appointment_id; `030_fct_appointment.sql:93-137`, `040:23-29`), claims top-level (17 keys incl.
  line_items, icd_codes, payments; `040:44-50`), line_items (cpt_code, description, billed_amount, allowed_amount,
  units, place_of_service, icd_pointers; `050:60-80`), icd_codes (code, primary, description), payments (payment_date,
  amount, payer_type, payment_type; `045:25-40`), locations (ehr_id, name), providers (ehr_id, name, npi, specialty,
  credentials), visit-types (code, description). Keys the plan drops that exist locally and are read by no view:
  billing_activity_log, submission_history, balances, claim_type, emr_claim_id, synced_at, updated_at, void_claim,
  check_number, era_*, member_balance, withheld, payer_id/payer_name, ids, local_datetime, object_metadata,
  schedule_block_color, ehr_appointment_id, secondary_provider_ehr_id, fax, hours, practice_locations, timezone.
  Whitelist-by-rebuild (new dict) is the right shape; keep it that way.
* Paths and names exist: `scripts/apply_analytics_views.py` (`REQUIRES_COBALT` line 54, `REQUIRES_MART` 149),
  `scripts/copy_ecw_mart_to_aws.sh`, `scripts/check_operations_parity.py`, `sql/analytics/020..060`,
  `src/mart_source.py` (`gate`, `read_scope`, `mart_cursor`, `MartReadNotAudited`, `MartNotConfigured`),
  `src/phi.py:716` `MART_READ_OBJECTS` and `open_mart_read`, `api/routers/operations.py` (`identity.user_id` exists,
  `api/deps.py:101`), `docs/runbooks/ecw-mart.md`, `docs/adr/0053..` (0054 is free), tracker T:251, the tests named
  (`test_cobalt_slim` is new; `test_apply_analytics_views`, `test_api_v2_operations`, `test_phi_mart_read_pg`,
  `test_mart_views_sql_pg`, `test_migration_0048_ecw_mart_pg`, `infra/tests/test_mart.py` exist).
  `compute.py` ~1173 wires `ecwOrgId`/MART_DB_* behind `ecwMart`.
* No Alembic/infra needed: schema `mart` is owned by `meridian_mart_owner` (0048:185), reader gets nothing on mart and
  default SELECT on analytics (0048:195-202), so owner-created `mart.cobalt_*` are unreadable by app roles and the new
  owner-run analytics views are readable by the reader. The plan correctly avoids `CREATE SCHEMA`. The nightly
  `sync_data_mart.py` only drops/truncates its 11 named tables (lines 323-327), so it will not wipe `mart.cobalt_*`.
  `scripts/gen_tenant_tables.py` SCHEMAS is `public, phi`, so tenant_tables.txt/lint unchanged.
* No new Python package, so `requirements.lock.txt` is not touched (`tests/test_requirements_lock.py`).
* Reader 60 s timeout: data is ~67k rows; Operations tolerates it; 0049 conditional is reasonable (current top
  migration 0048, no collision).
* Local ports respected: plan never uses raw DB 5433 as a source; staging tunnel/Mac ports only need W8.
* Order of steps S1-S8 is right (code/images first, copy, then views via the mart-sync task, then verify); S5 needs the
  new image from S1 because the ECS task runs the repo's `apply_analytics_views.py`.

## INFO

* Linkable keys left (appointment `id`/`emr_appointment_id`, claim `id`) are needed for the claim-to-appointment join
  (`040:21-29`). If the owner wants them opaque, an HMAC with a salt kept on the Mac, applied to both fields at copy
  time, preserves the join. Not required by the decisions.
* `060` keeps `SET search_path = pg_catalog, analytics, public` for the SECURITY DEFINER function; use `mart` in the
  rewrite as the plan says and keep the "no `public.` reference left" test.
