---
phase: 261018-cob-cobalt-on-aws
reviewed: 2026-10-19T00:00:00Z
depth: standard
files_reviewed: 14
files_reviewed_list:
  - scripts/cobalt_slim.py
  - scripts/copy_cobalt_to_aws.sh
  - scripts/cobalt_mart_ddl.sql
  - scripts/apply_analytics_views.py
  - scripts/ecw_mart_staging/9-copy-cobalt.sh
  - scripts/ecw_mart_production/10-copy-cobalt.sh
  - src/api/v2/operations_routes.py
  - api/routers/operations.py
  - src/mart_source.py
  - src/phi.py
  - tests/test_cobalt_slim.py
  - tests/test_api_v2_operations.py
  - tests/test_apply_analytics_views.py
  - tests/bi/test_s4a_routes_pg.py
findings:
  critical: 2
  warning: 4
  info: 5
  total: 11
status: issues_found
---

# 261018-cob: Code Review Report

**Diff:** merge/main-into-aws-2026-10-16...feat/cobalt-on-aws. **Tests run:** 528 passed (cobalt_slim, operations, apply_analytics_views, mart_source, phi_mart_read_pg, migration_0048_pg, bi s4a/s4b/s5a).

Overall: the whitelist rebuild, ICD rule, operations routing and RDS rewrite are sound. Two real problems: a partial or empty copy can be committed to RDS, and the source guard can be bypassed through libpq environment variables or `hostaddr`.

## Blockers

### BL-01: a failed or refused slimmer run can commit TRUNCATE + a partial (or empty) COPY

**File:** `scripts/cobalt_slim.py:282-290`, `scripts/copy_cobalt_to_aws.sh:56`
**Issue:** With `--as-sql`, `TRUNCATE mart.cobalt_rows; COPY ... FROM STDIN;` is written BEFORE `stream()` connects (it is a lazy generator). If the source is refused, the connection drops, or any exception happens mid-stream, Python exits non-zero with no `\.`. psql, reading a script from stdin, treats EOF as end of COPY data and, under `-1`, still issues COMMIT. Result: the previous good copy is replaced by an empty or truncated one, and Operations silently shows partial numbers. `pipefail` makes the script exit non-zero afterwards, but the commit has already happened. The earlier `--dry-run` only narrows the window (it is a separate run, and it re-reads the data).
**Fix:** Do not stream straight into psql. Build the SQL into a private temp file first (mode 600, deleted by the trap, in a scratch dir), and only run psql if the slimmer exited 0. Also assert inside the same transaction that the loaded count equals the expected count, for example:
```bash
tmp="$(mktemp)"; chmod 600 "$tmp"; trap '... ; rm -f "$tmp"' EXIT
"$PY" "$ROOT/scripts/cobalt_slim.py" --as-sql > "$tmp" || die "slimmer failed"
psql "$R" -Xq -v ON_ERROR_STOP=1 -1 -f "$tmp"
```
Alternatively have `main()` buffer rows (or write to a spool file) and emit TRUNCATE/COPY only after the stream finished. Add a test that forces `stream` to raise and asserts the output has no `TRUNCATE`.

### BL-02: source guard can be bypassed (hostaddr, libpq env vars, no post-connect check)

**File:** `scripts/cobalt_slim.py:104-114`
**Issue:** `check_dsn` only parses `host`, `port`, `dbname` out of the DSN string.
1. `host=localhost hostaddr=10.0.0.5 dbname=meridians_ecw` passes, but libpq connects to `hostaddr`.
2. The default DSN `dbname=meridians_ecw` has no host or port, so libpq takes `PGHOST`, `PGHOSTADDR`, `PGPORT`, `PGSERVICE`, `PGSERVICEFILE`, `PASSFILE` from the environment. `PGPORT=5433` (the raw vault copy, which exists on this Mac) or a remote `PGHOST` defeats "loopback, not 5433". The missing-port default `"5432"` is assumed, not verified.
3. URI-form DSNs fail closed only by accident (no `dbname` match).
The `patients` check is the only post-connect defence, and it only works if the raw copy really differs in that way.
**Fix:** After connecting, verify what was actually reached and refuse otherwise:
```python
cur.execute("SELECT current_database(), inet_server_port(), inet_server_addr()::text")
db, port, addr = cur.fetchone()
if db != ALLOWED_DB or port == 5433 or (addr and addr not in ("127.0.0.1", "::1")):
    raise SourceRefused(...)
```
(`inet_server_addr()` is NULL on a unix socket, which is fine.) Also reject `hostaddr`, `service`, `passfile` keys in `check_dsn`, and clear `PGHOST/PGHOSTADDR/PGPORT/PGSERVICE` from the environment (or pass explicit `host=localhost`). Add tests for `hostaddr=` and for `PGPORT=5433` in the environment.

## Warnings

### WR-01: a failing COPY prints row content to the terminal

**File:** `scripts/copy_cobalt_to_aws.sh:56`
**Issue:** psql with `ON_ERROR_STOP` prints `CONTEXT: COPY cobalt_rows, line N, column data: "<row>"` on a data error (for example a JSON string containing `\u0000`, which jsonb rejects). The row is slimmed but still carries service dates and appointment/claim keys, which the task rules say never to print. The same applies to scrollback and logs.
**Fix:** `psql ... -v VERBOSITY=terse` (drops CONTEXT/DETAIL) on the COPY call, and strip `\u0000` in `slim`/`_esc` (or in `json.dumps` output) so that failure is not triggered by data.

### WR-02: free-text CPT line `description` and other string fields are not gated

**File:** `scripts/cobalt_slim.py:82-89, 146-150`
**Issue:** ICD descriptions go through the release rule, but `line_items[].description`, `appointment_type`, `claim_status_description`, `provider_name`, `visit-types.description` and `locations.name` pass as-is for any string value. They are probably controlled vocabularies, but the claim line `description` is the same kind of field as the ICD description (eCW text), with no length or frequency rule. Nothing verifies they hold no patient-entered text.
**Fix:** Apply the same count/length/digit release rule to line `description` keyed by `cpt_code` (or at least a length cap plus the no-stray-digit rule), or document in ADR 0054 that these were checked against the real data distribution.

### WR-03: operations audit pair can silently carry `user_id=None`

**File:** `src/api/v2/operations_routes.py:178, 235, 272`
**Issue:** `user_id=None` defaults on `kpis/claims/portfolio`. The only caller found (`api/routers/operations.py`) passes `identity.user_id`, but any other or future caller that omits it writes an audit row with no user, and `support_access.refuses_phi(org, None)` may not refuse a support session. Fail-open default for an audit field.
**Fix:** Make `user_id` a required positional argument (no default) and update the tests that call without it.

### WR-04: test for the audited scope never checks which `what` each route uses

**File:** `tests/test_api_v2_operations.py` (`WHAT` dict, `test_postgres_configured_reads_through_one_audited_scope`)
**Issue:** `WHAT` is defined and never used; the assertion is `scopes[0][1] in (all three)`, so kpis could write `mart:operations.portfolio` and still pass. `user_id` is also not asserted, although the plan says "user_id passed".
**Fix:** Map `url -> expected what` (note `CLAIMS` has `?tab=` in the parametrised URL, so the `WHAT` keys would not match as written: key on the path) and assert `scopes[0] == (ORG_A, expected)` plus the user id.

## Info

### IN-01: rewrite_cobalt is exact-string based (safe, but brittle)

**File:** `scripts/apply_analytics_views.py:471-476`
`re.sub(r"\bpublic\.cobalt_(latest|rows)\b")` can only touch those two table names (also inside SQL comments, harmless). The search_path replace is an exact-string match, so a reformatted `SET search_path` in 060 would silently stay on `public`, leaving the SECURITY DEFINER function with `public` in its path. `test_rds_cobalt_rewrite_leaves_no_public_table_reference` does catch that (it asserts no `search_path ... public`), so this is covered; just note that 060's other objects are all schema-qualified (checked: only `public.cobalt_latest` appears at lines 15 and 64). Replacing `public` with `mart` in a SECURITY DEFINER path is acceptable because `mart` is owner-controlled and only the reader's grants matter (shown by `test_cobalt_copy_is_readable_only_through_the_analytics_views`).

### IN-02: `--check` for cobalt runs the normal compare once data exists, and applies skip while empty

**File:** `scripts/apply_analytics_views.py:556-566`
Behaviour correct (SKIP with a reason while `mart.cobalt_*` is missing or empty, the `cobalt_missing` queries use `to_regclass`, so no transaction-aborting error). The tests monkeypatch `cobalt_missing` and test it separately with a fake cursor, so the real SQL of `cobalt_missing` only runs in prod; the pg test does not cover it. Consider one pg-backed assertion.

### IN-03: copy script behaviour is untested

**File:** `scripts/copy_cobalt_to_aws.sh`
No test (even a `bash -n` / `shellcheck` / `--dry-run` smoke test). Reviewed by reading: it never echoes the password (kept in `PGPASSWORD`, unset in the trap), uses `sslmode=verify-full` with `hostaddr=127.0.0.1` through the tunnel and the RDS CA, `statement_timeout=0` via `PGOPTIONS`, no `CREATE SCHEMA` (DDL file and script confirm), single transaction (`-1`) for TRUNCATE+COPY, and refuses account other than 486243787301. One nit: `ok` reads the answer from stdin, fine here, but the staging/production wrappers do not forward `--dry-run` to the copy script.

### IN-04: recursion and gate flow are fine

**File:** `src/api/v2/operations_routes.py:131-156`, `src/mart_source.py:98-106`
`_gate -> mart_source.gate -> (off Postgres) _gate_local`; no cycle (`_gate_local` does not call back). `_mart` maps `MartReadNotAudited/MartNotConfigured` to 503 non-retryable, `psycopg2.Error` (including a connect failure) to the existing retryable `_db_down`, and leaves `SupportPhiRefused` alone (handled in `api/errors.py:225`). The audit opens once per request (`read_scope` is re-entrant and `mart_cursor` is lazy), and the three `what` words were added to `MART_READ_OBJECTS` and covered by `test_operations_reads_write_the_opened_closed_pair`. Minor: a `PhiError` from a failed audit write (the "refuse the read" path) is not mapped to ECW_NOT_CONNECTED, so it surfaces as a 500 rather than a 503; refusing is correct, the status code is just less friendly. Local (non-Postgres) path: `read_scope` is a no-op and `mart_cursor` yields `ecw_cursor()`, covered by the existing tests (now patching `mart_source.ecw_cursor`).

### IN-05: removed `_on_postgres` patches did not weaken the BI tests

**File:** `tests/bi/test_s4a_routes_pg.py:610`, `test_s4b_routes_pg.py:337`, `test_s5a_routes_pg.py:1359`
The same fixtures still patch `mart_source.on_postgres -> False`, and `operations_routes._gate` now goes through `mart_source.gate`, which reads that same flag, so the effective setup is unchanged. The old comment above the removed lines ("the eCW gate refuses that backend (T:251)") is now stale and should be reworded.

## Confirmed good (PHI)

- Whitelist rebuild: arrays rebuilt element by element, non-dict elements become null, nested objects in scalar slots become null, unknown keys never pass. Payment `check_number` and `era_reference_id` are not in `PAYMENT_KEYS`; `KEEP_CLINICIAN_NPI` governs all four NPI slots (tested both ways).
- ICD rule matches `analytics.icd_pick` (distinct claims, >=10, <=80 chars, digit-subset check, tie-break by byte order). It runs over all claims rather than the view's non-void/in-window subset, which can only keep a superset of what the views may later release, and every non-kept description is nulled before leaving the Mac.
- `--dry-run` prints counts and sizes only. COPY text escaping covers backslash, tab, newline and carriage return.
- `patients` endpoint guard exists, but see BL-02 for the connection-target gaps.

---

_Reviewed: 2026-10-19_
_Reviewer: Claude (gsd-code-reviewer)_
_Depth: standard_
