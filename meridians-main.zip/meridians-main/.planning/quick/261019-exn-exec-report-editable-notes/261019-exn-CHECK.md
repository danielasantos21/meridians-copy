# 261019-exn plan check (independent, goal-backward)

Plan: `.planning/quick/261019-exn-exec-report-editable-notes/261019-exn-PLAN.md` (commit 47dbe00f), checked against worktree HEAD 0a4448c8.
Result: **ISSUES FOUND: 5 blockers, 9 warnings.** The design is sound (JSONB doc per org+period+kind, compare-and-set on `version`, admin-only via `require_admin_in("bi")`), but the plan as written would fail CI and has two real defects (privileges, unique-violation mapping) plus a text-loss path in the import.

## BLOCKERS

**B1. Privileges: the plan's "no DELETE / INSERT+SELECT only" is not achievable with GRANT alone.**
- `migrations/versions/0003_rds_adaptations.py:291-294` sets `ALTER DEFAULT PRIVILEGES ... GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO meridian_app`, so every new table starts with full DML for the app role. `0043_bi_drill_audit.py` knows this and does `REVOKE ALL ON audit FROM meridian_app` before `GRANT INSERT`. The plan (Task 1 action) only lists GRANTs, so `bi_exec_tables` would keep DELETE and `bi_exec_table_revisions` would keep UPDATE and DELETE.
- The plan also contradicts itself: revisions get `GRANT ... DELETE` for the 50-row prune, yet the pg test and T-exn-07 say "app role cannot UPDATE/DELETE revisions".
- Fix: `REVOKE ALL ... FROM meridian_app` first on both tables, then exact grants. Decide on the prune: either drop pruning (rows are small; cap by count in a CHECK-free way is not needed) or accept DELETE on revisions and reword T-exn-07 and the test to "cannot UPDATE; DELETE only the prune statement". Cheapest: keep all revisions, no DELETE grant, so the log really is append-only.

**B2. Optimistic-concurrency path is broken in three places (the 409 merge cannot work as planned).**
- `src/bi_store.py:176-190` (`connect`) catches EVERY `UniqueViolation` and re-raises it as `Conflict` code `NAME_TAKEN` ("A collection with that name already exists here.") or `STALE_REVISION` if the constraint name contains "revisions". The plan's "base_version=0 inserts (unique violation -> Conflict STALE_VERSION)" never sees the raw error. Use `INSERT ... ON CONFLICT (org_id, fiscal_year, edition, which, kind) DO NOTHING RETURNING id` and treat zero rows as stale; same for the revisions insert.
- `bi_store.StoreError` has no `details`, and `src/api/v2/bi_common.py:81-92` (`store_error`) maps a Conflict to `ApiError(code, message, status=409, field_errors=...)` with no `details`. The plan's `details.current` (the current doc the client merges against) would be dropped. Needs a Conflict subclass carrying the doc and a custom mapping (ApiError itself accepts `details`, `src/api/v2/errors.py:320`).
- The plan says to reuse "the `_call`/`_out` helpers in `bi_dashboard_routes.py`". They do not exist there. The real helpers are `bi_common.call` / `bi_common.store_error` (`bi_common.py:81,106`).
- Also read the current doc inside the same cursor before raising (the raise rolls back, which is fine since nothing was written).

**B3. Repo registrations the plan omits; CI goes red without them (Task 1/2 files lists are incomplete).**
- `tests/test_migrations.py:28` `HEAD_REVISION = "0048_ecw_mart"` (asserted at :88). The plan says "only if it lists heads": it does. Must become `0049_bi_exec_tables`.
- `scripts/tenant_tables.txt` and `scripts/gen_tenant_tables.py` (the `CREATED_LATER`-style dict that ends near line 270, entries like `public.bi_segment_revisions`). `tests/test_migrations.py:267` (`test_the_list_accounts_for_every_org_scoped_table_at_head`) fails if a table with `org_id` is not on the list. Also `scripts/lint_org_scope.py` reads that list, so until the tables are added, the plan's "org-scope lint stays green" is vacuous: the lint would not check `bi_exec_store.py` at all. Add both tables, regenerate, and keep the baseline untouched.
- `scripts/pull_live_data.py:262-290` classifies every tenant table (pulled vs "built on the laptop, not pulled"). Add both new tables there (verify with `tests/test_pull_live_data.py`).
- `scripts/generate_openapi.py` has a hand-maintained `ROUTES` registry (e.g. the executive export at ~line 2109). `scripts/check_api_drift.sh` exits 2 when a served route is not declared. The plan only says "regenerate openapi"; it must add two `Route(...)` entries first.
- `tests/test_access_item_gates.py:120-139` `ADMIN_BI` list: the new GET and PUT must be added (they are the 403-when-`bi`-off and member-403 proofs the owner asked for). The plan never names this file.
- `docs/runbooks/migrations.md` (revision table, ~line 43) should get a 0049 row.

**B4. The import-from-this-browser flow can lose text (contradicts truth 6, "nothing is lost").**
- Task 4: after "Import selected" the plan deletes "those imported-or-dismissed `<scope>|sum-*|next-*` keys". Rows the user left unchecked (default unchecked when someone already edited the shared row) count as "dismissed" and are deleted, but their text now lives nowhere (revisions hold server rows only).
- Second path: if the post-import save hits a 409 and the merge resolves a same-field conflict as "Use theirs", the imported text is dropped, yet the key has been deleted.
- Fix: delete only keys whose text is now equal to the saved server text (verify against the final server doc after the last successful save); leave every other key, and keep the banner. The separate confirmed "Discard this browser's copy" stays the only deletion of un-imported text. Add tests for both paths.

**B5. Version and changelog placement are wrong (owner flagged it).**
- `web/package.json` is 1.3.54 and `CHANGELOG.md:11` already has `### v1.3.54 (2026-10-19)` (Operations precompute), below a 1.3.53 entry. The plan says 1.3.53 -> 1.3.54 in Task 4, in the commit message, the changelog heading, and success criteria. All four must say 1.3.55. (Per CLAUDE.md the entry goes at the top of the file, above the 1.3.53 one; the file's order is already irregular, so put it first.)

## WARNINGS

**W1. "Same member lookup the dashboards use" does not exist.** `bi_dashboard_store.py` resolves no names. The real helper is `src/auth.fetch_profiles(user_ids, viewer_id, org_id)` (`src/auth.py:256`; org admins can read member profiles under revision 0017). Call it in the route layer after the transaction (not inside `bi_exec_store`), batch both docs' `updated_by` ids in one call, and fall back to the email local part, then to "another admin" for removed members.

**W2. Rate-limit claim is unsupported.** `LIMIT_WRITE` is 30/minute per user (`src/api/v2/limits.py:25`) and is shared with every other BI write. Debounce 1.5 s plus blur flush plus `visibilitychange` plus two tables plus 409 re-saves can pass 30 in a minute while editing steadily. Treat 429 as "retry after Retry-After, keep text in memory" (not as a failed save), or give these two routes their own limit (e.g. 60/minute).

**W3. Deck path is two-step and the plan wires only one step.** `openPreview(final)` builds the spec synchronously (`executive-report.tsx` ~line 125-165); the POST happens later from `deck-preview.tsx:57-68` (`downloadDeck`, called at ~:535) and `executive-report.tsx:131` (`downloadVersion`). `deck-preview.tsx` is not in `files_modified`, yet the STALE_TABLES toast and reload belong there; the preview's spec cannot refresh itself, so the user must be told to close and reopen. `flush()` must be awaited and then `specFor` must read the latest rows from a ref, not a stale closure. Also `exec_pptx.validate_spec` DROPS unknown keys (`src/exec_pptx.py:78`), so `which` must be added to its `out` dict (1-12, 1-4 for quarter) and `table_versions` must be read from the raw `data` in `bi_download_routes.bi_executive_pptx` (it only holds the validated `spec`). `executive-lock.test.tsx` mocks `exportExecutivePptx`; its expectations need updating.

**W4. Final (lock) and shared rows disagree.** The lock store is per-browser localStorage (`lock-store.ts:LOCKS_KEY`). Admin A marks Final, admin B on another computer still sees Draft and can edit the shared rows; a locked deck skips the freshness check and uses A's local snapshot. The plan accepts this under Open Question 1, but the Final banner should say it is "frozen on this device" so nobody trusts it as shared.

**W5. Seed rows are under-specified.** The server validation "a seed row may not be missing" needs the fixed seed keys (`sum-ops`, `sum-mna`, `sum-team`, `next-0..4`) hard-coded in Python; the plan never lists them. Seed topic names are translated (`t("bi.exec.sum.operations")`) but a typed row requires a stored non-blank `topic`: the first saver's language would be frozen into the shared row for every admin. Store seeds without a topic (or with a key) and render the localised name client-side; same for the five initiative names.

**W6. "Never reusing a retired number" cannot be met with the stored shape.** Nothing records retired topic numbers once a row is removed. Either drop the rule (max+1 is fine) or store `next_topic_no` in the doc.

**W7. Row-cap interplay with the deck.** Highlights stores up to 40 rows, but the deck adds 3 computed rows and `exec_pptx.py:144` caps summary rows at 40, so an admin could save a table that later fails export with 422. Cap typed rows at 37 (API and CHECK), or count the calc rows.

**W8. Test wiring instructions are wrong.** `test_ci_migrations_job_membership.py:22` lists only three modules; nothing needs adding for a new pg file. `backend.yml` (~line 154) already runs every `tests/**/*_pg.py` with `MERIDIAN_PG_REQUIRED=1`. `tests/test_api_v2_bi_exec.py` (HTTP + Postgres) is not named `_pg.py`, so it will SKIP in the default job and trip `tests/allowed-skips.txt` unless it is renamed `test_api_v2_bi_exec_pg.py` (or uses fixtures that need no Postgres). Remove the "add to the CI job list" step.

**W9. Scope.** Task 3 touches ~9 source files plus 5 test files; Task 2 ~10 files; `files_modified` has 34 entries. Task count (4) is fine, but Task 3 is the risk; consider splitting hook+model from UI (Task 3a/3b) so executor context does not degrade.

## OK (verified)

- Alembic: head is `0048_ecw_mart` (`migrations/versions/0048_ecw_mart.py:72`); no branch, local or remote, carries a 0049 file or a `down_revision` of 0048 other than the same file. `0049_bi_exec_tables` is free.
- Goal coverage: all 7 truths map to tasks; admin-only on GET and PUT via `require_admin_in("bi")` (`api/deps.py:288`) is the same gate the export uses (`api/routers/bi_downloads.py:25`); `_actor` refuses org/user in the query string (`bi_downloads.py:35`).
- Cited files exist: `bi_dashboard_store.py`, `bi_dashboards.py`, `bi_downloads.py`, `bi_download_routes.py`, `exec_pptx.py`, `0042_bi_dashboards.py`, `statements.tsx`, `forecast.tsx`, `report-ui.tsx`, `executive-report.tsx`, `deck-spec.ts`, `lock-store.ts`, `messages/bi-exec.ts`, `isStaleRevision` (via `lib/api/bi-content`). New files `lib/api/bi-exec.ts` etc. do not yet exist (to be created, no clash; `exportExecutivePptx` lives in `lib/api/bi-export.ts:40`).
- RLS template is right: 0042 pattern (ENABLE+FORCE, `meridian_org_isolation`, `REVOKE ... FROM phi_access`, `app.current_org_id()`); composite FK `(org_id, table_id)` and `UNIQUE (org_id, id)` follow 0042.
- exec_pptx limits match the plan (rows <=40, note 4000, topic 120, `_XML_BAD` keeps \t \n \r); seed text with newlines survives. Paging 7 and 5 rows per slide matches `_page_count`.
- No new dependency, so `requirements.lock.txt` is untouched. No-PHI logging: counts-only log with `# phi-lint: ok <reason>` is the sanctioned pattern (reason is required).
- Migration safety on production: two new empty tables, no ALTER of existing tables, no backfill; the only lock is the brief FK validation lock on `organizations` (same as 0042). Downgrade drops both tables and the plan says to back up first. No data to copy, so no long locks.
- Concurrency design: whole-table `UPDATE ... WHERE version = base` with rowcount check is correct once B2 is fixed; the client three-way merge by row key is sound for the matrix listed.
