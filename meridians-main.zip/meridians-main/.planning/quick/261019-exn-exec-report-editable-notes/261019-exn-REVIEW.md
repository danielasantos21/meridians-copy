---
phase: 261019-exn
reviewed: 2026-10-19
depth: standard
files_reviewed: 20
findings:
  critical: 0
  warning: 3
  info: 6
  total: 9
status: issues_found
---

# 261019-exn: Code Review (feat/exec-tables vs merge/main-into-aws-2026-10-16)

Tests run: tests/test_exec_pptx.py, test_bi_exec_store_pg.py, test_api_v2_bi_exec_pg.py, test_access_item_gates.py: 155 pass, 1 fail (pre-existing, see IN-01). Vitest on web/src/app/bi/executive and lib/api/bi-exec: 190 pass.

No BLOCKERs. Migration, store, routes and the autosave hook are sound. Real Postgres tests (ephemeral PG, threads with Barrier for the first-insert race, RLS, grants, DB CHECKs) are not over-mocked.

## Verified OK (no finding)

1. Migration 0049: REVOKE ALL (app and phi roles) then exact GRANT (tables SELECT/INSERT/UPDATE, revisions SELECT/INSERT); ENABLE + FORCE RLS; policy USING and WITH CHECK on `app.current_org_id()`; revisions policy adds an EXISTS on the parent; composite FK (org_id, table_id) so a revision cannot cross orgs; CHECKs on year, edition, which, kind, rows type, size, array length, via. New tables only, no locks on existing ones, so safe live. Downgrade drops both (docstring warns of data loss). Identity columns need no sequence grant.
2. Store: first save uses INSERT ON CONFLICT DO NOTHING (loser gets zero rows, so StaleVersion with the current doc); later saves use UPDATE ... WHERE version = base; revision insert is in the same transaction (stale raises, whole transaction rolls back); every statement has an explicit `org_id = %(org)s` or the `app.current_org_id()` guard. Row validation is strict (unknown keys, seeds required, reserved keys, control chars stripped).
3. Routes: `require_admin_in("bi")`, CSRF on PUT, own 90/min bucket, query-string org/user spoofing refused, body capped at 300 KB, NaN constants rejected, the log line has counts only.

## Warnings

### WR-01: Name lookup can hit Cognito ListUsers on every autosave and every GET

**File:** `src/api/v2/bi_exec_routes.py:65-84` (calls `src/auth.py:1329`, `src/cognito.py:1047`)
**Issue:** `_names` calls `_auth.identity_directory()` (a full, uncached ListUsers walk, up to 10 pages) whenever any `updated_by` has no profile `full_name`. Users who never set a name are common. Autosave (debounce 1.5 s, blur, hide, 409 re-saves, up to 90/min per user) turns each save into a Cognito walk, in a sync threadpool call, adding latency and risking Cognito ListUsers throttling for everyone (login also uses Cognito).
**Fix:** Cache the directory for 60-300 s inside `_names` (or `identity_directory`), or skip the directory on the PUT path and fall back to the email-less "another admin"; or return names only on GET.

### WR-02: Draft-deck freshness check trusts the client's rows, and 503 now blocks draft export

**File:** `src/api/v2/bi_download_routes.py:397-418, 437-438`
**Issue:** Only the version numbers are compared; the rows in the spec are whatever the browser sent, so the 409 protects against concurrent edits but is not an integrity check (the module TODO acknowledges the spec is browser-built, so this is acceptable for a preview deck, but the 409 text suggests a guarantee it does not give). Behaviour change: a draft export now needs Postgres (`get_versions` raises StoreNotConfigured, which `_call` maps to 503). Locked decks skip the check, so only drafts break when `DATABASE_BACKEND` is not postgres (the Supabase main path). Existing callers: the only caller is the web deck dialog (updated) and tests (updated with the autouse monkeypatch). Nothing else calls `export.pptx`.
**Fix:** Accept as is on AWS (document in the CHANGELOG/ADR that draft export needs Postgres), or have the server load the saved rows and ignore client rows (the TODO already planned this). Add one test that a StoreNotConfigured on a draft returns 503 with a clear message, since the autouse monkeypatch hides that path.

### WR-03: `which` is now required on every draft spec, a breaking change for any API client

**File:** `src/exec_pptx.py:93-99`
**Issue:** A draft spec without `which` is 422 (and without `table_versions` is 422). Fine for the only web client, but it is a contract change on a public route. Confirm `openapi/meridian-v2.json` documents `which` and `table_versions` as required for drafts (the generator change adds 34 lines; the 871-line spec diff is large and was not line-reviewed).
**Fix:** Spot-check the generated spec; mention in CHANGELOG.

## Info

### IN-01: Pre-existing failing test

**File:** `tests/test_access_item_gates.py:157-171`
`test_remaining_doors_need_their_scope[post-/api/v2/bi/executive/export.pptx-bi]` fails on the base branch too (export.pptx is admin-only since 716ddd95 but is still in this member-scope list; the comment on ADMIN_BI says it was "moved", yet the parametrize list still holds it). Not caused by this branch. Fix: delete that tuple from the list.

### IN-02: Dead field `again`

**File:** `web/src/app/bi/executive/use-exec-tables.ts:73,174,184`
`t.again` is set but never read; the loop condition uses `t.dirty`. Behaviour is correct (edits during flight keep `dirty` true because `t.rows !== snapshot`). Remove the field.

### IN-03: Rate-limited retry loop is unbounded

**File:** `use-exec-tables.ts:134-138, 186`
A persistent 429 keeps the save loop sleeping and retrying forever (status stays "saving"). Acceptable (text is kept) but consider showing the error status after N waits.

### IN-04: "Discard this browser's copy" also deletes over-limit and unticked text

**File:** `import-local.tsx:72-77`
Gated by an explicit confirm, so lossless rule holds as designed; make sure `bi.exec.import.discardBody` (Spanish too) says over-length texts are removed as well.

### IN-05: Deck preview can go stale from the user's own edits

**File:** `executive-report.tsx:146-150`
The spec is built after `flush()`, but the dialog stays open; an autosave bump (own edit) before Download gives 409 STALE_TABLES. Handled via `onStaleTables` reload, and the dialog is modal, so low risk.

### IN-06: Row text limit counts characters, DB limit counts bytes

**File:** `src/bi_exec_store.py:44,203` vs migration CHECK `octet_length(rows::text) <= 262144`
Python checks `json.dumps(...)` size (matches jsonb text size closely, since both use ", " and ": "), so a CheckViolation is unlikely; if it ever differs, `bi_store.connect` maps CheckViolation to Invalid, so the user sees a 422, not a 500. No action needed beyond a test at the boundary (37 rows x 2000 multi-byte chars).

## Area notes

- (5) Autosave hook: debounce 1.5 s, single in-flight per table with follow-up loop, flush on blur/hide/export/lock, period switch saves old scope then detaches (late answers dropped, conflicts on detached scopes leave the server copy alone), 429 honours Retry-After, 409 merges up to 5 times with `base` = server-confirmed copy. Merge function is a correct per-field three-way merge (both-changed-differently and edit-vs-remove are conflicts, default theirs, seeds restored). Import never deletes unless local text equals saved text or the user confirms discard. Status buttons use `aria-pressed` plus a per-row accessible name and a non-colour glyph; status line is `role="status"`. i18n tests pass (en/es key parity).
- (6) Tests: PG-backed with real roles and threads; the mocks are limited to `get_versions` in pptx route tests and the fake API in the hook tests, which is appropriate.

_Reviewer: Claude (gsd-code-reviewer), depth standard_
