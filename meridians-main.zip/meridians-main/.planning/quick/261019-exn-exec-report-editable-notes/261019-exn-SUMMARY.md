# 261019-exn Summary: shared, editable Executive Report tables (v1.3.55)

Branch `feat/exec-tables` (worktree `.claude/worktrees/feat-exec-tables`, from `merge/main-into-aws-2026-10-16`).

Highlights and Initiatives are now stored in AWS RDS per organization and period (Alembic 0049), with compare-and-set saves, append-only revisions, add/remove rows, click-to-set Hit/Miss/Challenge, last-edited-by, a row-level merge when two admins collide, a one-time lossless import from the browser, and a deck built from the saved rows.

## Commits

| Task | Commit | What |
|---|---|---|
| 1 | 2bc3eb0a | Alembic 0049, `bi_exec_store`, repo registrations (HEAD_REVISION, tenant list, pull_live_data, runbook) |
| 2 | 08596d42 | GET/PUT `/api/v2/bi/executive/tables`, STALE_VERSION 409 with current rows, deck freshness check, OpenAPI + types |
| 3a | 5f3a46c8 | `tables-model`, `use-exec-tables`, `bi-exec` client, initiative-name i18n keys |
| 3b | 0357f793 | `tables-ui`, slides wired, deck-spec and finals use saved rows, deck preview handles STALE_TABLES |
| 4 | 2782a284 | import from this browser, version 1.3.55, CHANGELOG |

## Decisions and notes

- Revisions are append-only and never pruned (app role has SELECT and INSERT only). A retention job, if ever wanted, is a later owner-run task.
- Proposed CLAUDE.md line (not applied): "Executive Report Highlights and Initiatives live in `bi_exec_tables` (per org, period, table, compare-and-set); the three slide Notes boxes and the Mark-final lock store are still localStorage and are the next follow-up."
- Behavior change: a draft deck export now reads `bi_exec_store.get_versions`, so without `DATABASE_BACKEND=postgres` it answers 503 instead of rendering sample data.
- Known limitation: a same-field 409 that arrives after a period switch (the old period's scope is detached) keeps the server copy and drops the pending local edit.

## Deviations from plan

1. `import-local.tsx` is split into `import-rules.ts` (pure rules, tested) and `import-local.tsx` (UI); a `.ts` and `.tsx` with the same stem collide in module resolution.
2. `which` is optional on locked decks (a final uses its frozen snapshot); required on drafts as planned.
3. Task 4's deck/lock wiring landed in the Task 3b commit because `deck-spec.ts` imported the constants that moved.
4. Added `test-fake-api.ts` (shared in-memory server for web tests) and timeouts (`configure`, `vi.setConfig`) in four test files, after two executive-lock flakes under full-suite load.
5. `bi.exec.next.name.4` ("M&A") added to the i18n same-in-both allowlist.
6. INSERTs use the `WITH scope AS (...)` pattern so the org-scope lint sees an org predicate (baseline untouched).

## Deferred / not done

- `tests/test_access_item_gates.py::test_remaining_doors_need_their_scope[post-/api/v2/bi/executive/export.pptx-bi]` fails identically on the base branch (stale case: the export is admin-only). Not touched.
- `web/` has no `eslint.config.*`, so the plan's `npx eslint` step cannot run.
- Not run (Andres's steps per CLAUDE.md): independent-agent review of 0049 against the live account, `alembic upgrade head`, `/verify` on the running app.
- STATE.md and ROADMAP.md not touched (quick task).

## Self-Check: PASSED

Files exist: migrations/versions/0049_bi_exec_tables.py, src/bi_exec_store.py, src/api/v2/bi_exec_routes.py, api/routers/bi_exec.py, web/src/app/bi/executive/{tables-model.ts,use-exec-tables.ts,tables-ui.tsx,import-rules.ts,import-local.tsx}. Commits 2bc3eb0a, 08596d42, 5f3a46c8, 0357f793, 2782a284 are in `git log`.
