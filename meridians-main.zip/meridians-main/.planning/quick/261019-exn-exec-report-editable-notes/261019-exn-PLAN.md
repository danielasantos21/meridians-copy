---
phase: quick-261019-exn
plan: 01
type: execute
wave: 1
depends_on: []
files_modified:
  - migrations/versions/0049_bi_exec_tables.py
  - src/bi_exec_store.py
  - src/api/v2/bi_exec_routes.py
  - api/routers/bi_exec.py
  - api/main.py
  - src/api/v2/schemas.py
  - src/api/v2/bi_download_routes.py
  - src/exec_pptx.py
  - openapi/meridian-v2.json
  - web/src/lib/api/schema.d.ts
  - web/src/lib/api/bi-exec.ts
  - web/src/app/bi/executive/tables-model.ts
  - web/src/app/bi/executive/use-exec-tables.ts
  - web/src/app/bi/executive/tables-ui.tsx
  - web/src/app/bi/executive/import-local.tsx
  - web/src/app/bi/executive/statements.tsx
  - web/src/app/bi/executive/forecast.tsx
  - web/src/app/bi/executive/executive-report.tsx
  - web/src/app/bi/executive/deck-spec.ts
  - web/src/app/bi/executive/lock-store.ts
  - web/src/lib/i18n/messages/bi-exec.ts
  - tests/test_bi_exec_store_pg.py
  - tests/test_api_v2_bi_exec_pg.py
  - tests/test_exec_pptx.py
  - web/src/app/bi/executive/deck-preview.tsx
  - tests/test_migrations.py
  - tests/test_access_item_gates.py
  - tests/test_pull_live_data.py
  - scripts/tenant_tables.txt
  - scripts/gen_tenant_tables.py
  - scripts/pull_live_data.py
  - scripts/generate_openapi.py
  - docs/runbooks/migrations.md
  - src/api/v2/limits.py
  - web/src/app/bi/executive/tables-model.ts
  - web/src/app/bi/executive/*.test.ts(x)
  - web/package.json
  - CHANGELOG.md
autonomous: true
requirements: [EXN-01 server-stored shared tables, EXN-02 add/remove/edit rows + click-to-set status, EXN-03 optimistic concurrency + last-edited-by, EXN-04 one-time localStorage import, EXN-05 deck uses saved rows, EXN-06 admin-only + bi access item + audit]
must_haves:
  truths:
    - "An org admin adds a row (topic + note, or initiative + actions) on the Highlights or Initiatives table, reloads, and another admin on another computer sees it."
    - "Clicking the Hit, Miss or Challenge cell of a typed row sets that one status; clicking it again clears it; the three are mutually exclusive."
    - "Computed rows (Clinic Contribution/EBITDA, Visits, Visits vs AOP) cannot be edited or have their status changed, but can carry an optional note."
    - "Two admins saving the same table at once never silently overwrite each other: the second gets a clear 'changed by X at HH:MM' message and a merge/choose path."
    - "A non-admin, or an admin whose org has the bi access item off, gets 403 on every one of these endpoints."
    - "The browser's old localStorage text is offered for import once and nothing is lost."
    - "The downloaded .pptx contains exactly the saved rows (added rows, edited notes, statuses)."
  artifacts:
    - { path: "migrations/versions/0049_bi_exec_tables.py", provides: "bi_exec_tables + bi_exec_table_revisions, RLS" }
    - { path: "src/bi_exec_store.py", provides: "get/save with compare-and-set, revision history, validation" }
    - { path: "src/api/v2/bi_exec_routes.py", provides: "service functions behind the router" }
    - { path: "api/routers/bi_exec.py", provides: "GET/PUT /api/v2/bi/executive/tables" }
    - { path: "web/src/app/bi/executive/use-exec-tables.ts", provides: "load, autosave, conflict merge hook" }
  key_links:
    - { from: "tables-ui.tsx", to: "/api/v2/bi/executive/tables", via: "use-exec-tables.ts -> bi-exec.ts", pattern: "executive/tables" }
    - { from: "bi_exec_store.save_table", to: "bi_exec_tables", via: "UPDATE ... WHERE version = base_version (rowcount 0 -> 409)", pattern: "version = %\\(base" }
    - { from: "deck-spec.ts summarySlide/next", to: "saved rows", via: "rows passed in DeckSelection (no textMap for these two)", pattern: "highlights" }
---

<objective>
Make the Executive Report's two typed tables (Highlights; Initiatives) editable, row-addable and SHARED: stored in AWS RDS per org and per period (quarter or period edition), visible to all admins, with last-edited-by/at and optimistic concurrency, and used by the deck export.

Purpose: today they live in browser localStorage ("saved on this device"), which breaks the project rule (CLAUDE.md: everything new goes to RDS via Alembic + pg.with_org + org predicate + RLS; no local-only stores), loses text on another computer, and cannot be shared.
Output: Alembic 0049, store + API, React UI, import from browser, deck wiring, tests, v1.3.55.
Scope boundary (do only what was asked): the three slide "Notes" boxes (notes-pl / notes-cost / notes-exp), the Mark-final lock store (localStorage `meridian.bi.exec.locks.v1`), and the sample-data numbers stay as they are; see Open Question 1. Owner defaults applied (no answer yet): only the two tables now; a new period starts from the seed rows (no copy-forward); computed rows cannot be overridden (optional note only). This plan owns Alembic revision 0049; other work uses 0050+.
</objective>

<context>
@CLAUDE.md
@src/bi_dashboard_store.py            (pattern: compare-and-set save, revisions, Conflict/STALE_REVISION)
@api/routers/bi_dashboards.py          (pattern: router + CSRF/WRITE/READ deps, `_actor`, `_json`)
@api/routers/bi_downloads.py           (the existing admin-only `/executive/export.pptx`)
@src/api/v2/bi_download_routes.py      (`bi_executive_pptx`: spec validated, PREVIEW ONLY)
@src/exec_pptx.py                      (summary rows <=40, note <=4000, topic <=120; paginates 7 rows/slide summary, 5 next)
@migrations/versions/0042_bi_dashboards.py  (RLS template: ENABLE+FORCE, policy meridian_org_isolation, grants to meridian_app, revoke phi_access)
@web/src/app/bi/executive/statements.tsx    (SummarySlide, TYPED_DEFAULTS, mark(), topic())
@web/src/app/bi/executive/forecast.tsx      (INITIATIVES, NextStepsSlide)
@web/src/app/bi/executive/report-ui.tsx     (useLocalState, TEXT_KEY, StoredTextarea, TextStoreProvider)
@web/src/app/bi/executive/executive-report.tsx (scope, specFor, lock())
@web/src/app/bi/executive/deck-spec.ts      (summarySlide, `next` slide)

<findings>
What the code does today (verified in this worktree at 83e95288):
- Page `/bi/executive` is a PREVIEW on made-up data (`getExecData()`); only server touch is `POST /api/v2/bi/executive/export.pptx` (admin-only, `require_admin_in("bi")`, CSRF, LIMIT_XLSX 10/min, size cap 1.5 MB). The browser builds the whole deck spec; the server only validates and draws it.
- Typed text lives in ONE localStorage key `meridian.bi.exec.text.v1`, a flat map `"<scope>|<id>" -> text`, scope = `"{fy}|{edition}|{which}"` (e.g. `2026|quarter|3`). Typed ids: `sum-ops`, `sum-mna`, `sum-team` (Highlights) and `next-0..next-4` (Initiatives); also `notes-pl/cost/exp` (out of scope). Missing key -> the hard-coded default (`TYPED_DEFAULTS`, `INITIATIVES`).
- Highlights table rows today: computed Financials (topic 1, two lines: Clinic Contribution, EBITDA; status computed from sign of clinic contribution), computed Patient Engagement (2: Visits, status from sign), computed "Visits vs AOP: needs a budget" (2, no status), typed Operations (3, status fixed `hit`), typed M&A (4, fixed `hit`), typed Team (6, fixed `chal`). Statuses of typed rows are hard-coded in both `statements.tsx` and `deck-spec.ts` (nothing can change them).
- Initiatives: 5 rows from the `INITIATIVES` constant, text id `next-{i}`; row number = index+1.
- Period choice: fy (FY26/FY25) + edition (period|quarter) + which (1-12 or 1-4); default FY26 / quarter / Q3. Window text `Q3 – FY26` from `windowText`.
- Mark-final lock (`lock-store.ts`) freezes `textsOfScope(textMap, scope)` into the version's `texts`; locked windows show those frozen texts read-only. That snapshot is also localStorage today (its header says the real table will be `exec_report_final`).
- Latest Alembic revision is `0048_ecw_mart`. Access items live in 0047 (`bi` is an access item; `require_admin_in("bi")` = org admin AND bi module on).
- Dashboards' "audit" is a revisions table (`bi_dashboard_revisions`, keeps newest 50, `changed_by`); `bi_drill_audit` is only for raw-row reads. There is no generic admin-edit audit table, so this plan follows the dashboards pattern (revisions = who/when/what, restorable).
- Conflict pattern to copy: `bi_store.Conflict` (HTTP 409, code `STALE_REVISION`) and web `isStaleRevision`.
</findings>
</context>

<design_decisions>
D1 Storage shape: one JSONB document per (org, period, table kind), not one SQL row per table row. Reason: whole-table compare-and-set with one `version` is the simplest correct concurrency, add/remove/reorder are one write, and the deck needs the whole table anyway. Max 37 typed/added/calc-note rows for Highlights because the deck adds the 3 computed rows and exec_pptx caps a summary at 40; 30 for Initiatives.
D2 Autosave (recommended) rather than a Save button. Reason: today's behaviour is instant save; a Save button would silently regress to "typed text lost on navigation". Autosave is safe because writes are compare-and-set and a 409 triggers a row-level merge (D5) instead of an overwrite. Rules: save 1.5 s after the last keystroke, on field blur, on `visibilitychange: hidden`, and before the deck export; never two saves in flight (queue the newest). A visible status line (aria-live polite): "Saving…" / "Saved · Ana R. · 10:42" / "Not saved: retry" with a Retry button. No beforeunload prompt except while a save is pending or failed.
D3 Computed rows are NOT stored. Only an optional `note` per computed row is stored (key `calc-financials`, `calc-visits`, `calc-visits-budget`), shown under the computed text. Their Hit/Miss stay computed from the numbers.
D4 Seeds: the 3 typed Highlights rows (keys sum-ops, sum-mna, sum-team) and 5 Initiatives (next-0..4) are "seed" rows (`origin: "seed"`) stored WITHOUT a name (names are translated client-side so one admin's language is never frozen for another): editable, NOT removable (owner: "remove rows they added"). Added rows have `origin: "added"` and a Remove button (with confirm). Until the first save of a period the UI shows the seeds with today's default text; the first edit/save writes the whole table (seeds + whatever changed). No row is written to the DB just by opening the page (GET is read-only).
D5 Conflict handling: a 409 carries the CURRENT server document. The client three-way merges by row key using `base` (last synced copy), `mine`, `theirs` (pure function `mergeTables`, unit-tested): a row changed only by me or only by them merges silently; a row added/removed by one side merges; a row whose same field was changed on both sides goes to a small dialog (Use theirs / Keep mine) per row. After the merge it saves again with `base_version = theirs.version`. Status line shows "Merged with changes by X".
D6 Access: Executive Report is admin-only. Every new route uses `Depends(require_admin_in("bi"))`; the page already hides itself from non-admins (`executive-access.test.tsx`), keep that. The bi module/access-item rule is inherited from `require_admin_in("bi")`.
D7 Deck: the browser builds the spec from the SAVED rows (same hook state, after flushing pending saves). Server adds a freshness check for non-locked decks: the spec carries `table_versions: {highlights, initiatives}` (0 = never saved); if either differs from the DB the server answers 409 `STALE_TABLES` ("Someone changed the highlights while you were exporting; reload") so a deck can never be built from out-of-date rows. Locked (final) decks keep using the frozen snapshot, which now includes the rows (D8).
D8 Locks (W4: the lock store is per browser, so the Final banner says "frozen on this device"): `FinalVersion` gets optional `highlights` and `initiatives` row snapshots (the saved rows at lock time); window text snapshot `texts` stays for the three notes boxes. Older locks without them fall back to the old text ids. When `exec_report_final` is built later, the same fields move there. (No change to who can lock.)
</design_decisions>

<tasks>

<task type="auto" tdd="true">
  <name>Task 1 (Wave 1): Alembic 0049 + store with compare-and-set, RLS, append-only revisions, repo registrations</name>
  <files>migrations/versions/0049_bi_exec_tables.py, src/bi_exec_store.py, tests/test_bi_exec_store_pg.py, tests/test_migrations.py, scripts/tenant_tables.txt, scripts/gen_tenant_tables.py, scripts/pull_live_data.py, tests/test_pull_live_data.py, docs/runbooks/migrations.md</files>
  <behavior>
    - get_tables(actor, fy, edition, which) -> {highlights: Doc, initiatives: Doc}; Doc = {exists, version (0 if none), rows, updated_by (uuid), updated_at}; a missing doc returns exists=false, rows=[] (client shows seeds). Names are NOT resolved here (see W1 in Task 2).
    - save_table(actor, kind, fy, edition, which, base_version, rows, via): base_version=0 runs `INSERT ... ON CONFLICT (org_id, fiscal_year, edition, which, kind) DO NOTHING RETURNING id` and zero rows returned means someone created it first -> StaleVersion. base_version=n runs `UPDATE ... SET rows, version = version + 1, updated_by, updated_at = now() WHERE org_id = %(org)s AND <period + kind> AND version = %(base)s RETURNING id, version`; zero rows -> StaleVersion. The revision row is inserted in the same transaction with `ON CONFLICT (org_id, table_id, version) DO NOTHING` (zero rows -> StaleVersion, defensive). NEVER rely on catching a raw UniqueViolation: `bi_store.connect` rewrites every UniqueViolation into Conflict NAME_TAKEN / STALE_REVISION (bi_store.py ~176-190), which would give the client the wrong code.
    - StaleVersion is a small subclass of `bi_store.Conflict` (code "STALE_VERSION", status 409) that carries `current` (the current Doc). It is built by reading the current doc with the same cursor BEFORE raising (the raise rolls back; nothing was written).
    - Revisions are APPEND-ONLY and never pruned or coalesced (one small row per save, <=256 KB; the client debounce keeps volume low). The app role has INSERT and SELECT on revisions and nothing else. A retention job, if ever wanted, is a later owner-run task (note it in the SUMMARY).
    - Validation (raise bi_store.Invalid, 422): kind in highlights|initiatives; fy 2000-2100; edition period|quarter; which 1-12 (1-4 for quarter); rows list; Highlights: at most 37 rows in total (typed + calc notes + added), because the deck adds the computed rows and exec_pptx caps a summary slide at 40 rows (W7); Initiatives at most 30; each row key matches /^[a-z0-9-]{1,64}$/ and is unique; `origin` in seed|added; Highlights typed row: `topic_no` int 1-99, `note` <=2000, `status` in hit|miss|chal|"", and a `topic` of 1-120 chars REQUIRED when origin=added and ABSENT/ignored when origin=seed (seed names are translated client-side, W5); Highlights calc row: key in {calc-financials, calc-visits, calc-visits-budget}, only `note` (<=2000); Initiative row: `name` 1-120 required when added, absent for seed; `actions` <=2000; strip XML-illegal control characters (same regex as exec_pptx `_XML_BAD`); reject unknown keys; total JSON <=256 KB. Fixed seed keys hard-coded in the store: Highlights `sum-ops`, `sum-mna`, `sum-team` (topic_no 3, 4, 6); Initiatives `next-0`..`next-4`. When a doc already exists a save that omits any seed key is refused (seeds are not removable). On the first save (base_version 0) all seed keys must also be present.
    - No `next_topic_no` and no "never reuse a retired number" rule (W6): a new topic number is max(existing topic_no)+1, or the existing number when the typed name matches an existing added topic case-insensitively.
    - Tests (pg, run as `meridian_app` through `bi_store.connect`): org B never sees org A's doc even with a SELECT naming no org; insert with another org_id refused by WITH CHECK; two admins: A saves v1->v2, B saves with base 1 -> StaleVersion carrying the current doc; two concurrent first inserts (base 0): exactly one wins and the loser gets STALE_VERSION (not NAME_TAKEN); a revision row exists per save with the right user and the full rows; grants: `meridian_app` has NO DELETE on bi_exec_tables and ONLY INSERT+SELECT on bi_exec_table_revisions (assert via has_table_privilege), phi_access has none; DB CHECKs reject 41 rows and an unknown edition even if the Python layer is bypassed; seeds-required rules.
  </behavior>
  <action>
    Create `migrations/versions/0049_bi_exec_tables.py` (revision `0049_bi_exec_tables`, down_revision `0048_ecw_mart`; this plan owns 0049, other work uses 0050+; docstring with WHY / WHAT / DOWNGRADE like 0042; the downgrade drops both tables and says it destroys saved Executive Report text, back up first).
    Table `public.bi_exec_tables`: id bigint identity PK; org_id uuid NOT NULL REFERENCES organizations ON DELETE CASCADE; fiscal_year int CHECK 2000..2100; edition text CHECK IN ('period','quarter'); which int CHECK 1..12 and (edition <> 'quarter' OR which <= 4); kind text CHECK IN ('highlights','initiatives'); rows jsonb NOT NULL DEFAULT '[]' CHECK (jsonb_typeof = 'array' AND jsonb_array_length <= 37 AND octet_length(rows::text) <= 262144) (37 is the larger-table cap and also fits Initiatives' 30; the Python layer enforces the per-kind number); version int NOT NULL DEFAULT 1 CHECK >= 1; created_by uuid NOT NULL; created_at timestamptz DEFAULT now(); updated_by uuid NOT NULL; updated_at timestamptz DEFAULT now(); UNIQUE (org_id, fiscal_year, edition, which, kind); UNIQUE (org_id, id).
    Table `public.bi_exec_table_revisions`: id identity; org_id; table_id bigint; version int; rows jsonb (same size CHECK); via text CHECK IN ('save','import','merge'); changed_by uuid NOT NULL; changed_at timestamptz DEFAULT now(); UNIQUE (org_id, table_id, version); FOREIGN KEY (org_id, table_id) REFERENCES bi_exec_tables (org_id, id) ON DELETE CASCADE.
    PRIVILEGES (B1): migration 0003 sets ALTER DEFAULT PRIVILEGES so every new table starts with full DML for meridian_app. Follow 0043_bi_drill_audit: on BOTH tables first `REVOKE ALL ON <table> FROM meridian_app` and `REVOKE ALL ON <table> FROM phi_access`, then exact grants: bi_exec_tables `GRANT SELECT, INSERT, UPDATE` (no DELETE: rows are cleared by saving); bi_exec_table_revisions `GRANT SELECT, INSERT` only (append-only). RLS on both: ENABLE + FORCE, policy `meridian_org_isolation` USING/WITH CHECK `org_id = app.current_org_id()` (revisions: plus the EXISTS on the parent, as `_child_rule` in 0042). COMMENT both tables: "typed report text only; no PHI, no patient identifiers".
    Create `src/bi_exec_store.py` following `bi_dashboard_store.py`: every statement carries `org_id = %(org)s`, uses `bi_store.connect(actor)` (= `pg.with_org`), `_p(actor, ...)`, `Actor`, `Invalid`. Never log row text (counts only).
    REGISTRATIONS that CI requires (B3; do these in this task so the suite is green at the end of Wave 1): (a) `tests/test_migrations.py` `HEAD_REVISION` "0048_ecw_mart" -> "0049_bi_exec_tables"; (b) add both tables to `scripts/gen_tenant_tables.py` (the later-created-tables dict, entries like `public.bi_segment_revisions`) and regenerate `scripts/tenant_tables.txt` with the script (`test_the_list_accounts_for_every_org_scoped_table_at_head` fails otherwise, and `scripts/lint_org_scope.py` only checks tables on that list, so without this the org-scope lint would silently not cover `bi_exec_store.py`); keep the lint baseline/ratchet untouched; (c) classify both tables in `scripts/pull_live_data.py` (read the existing classification at ~262-290: these two are typed report text, treat like the other BI content tables) and run `tests/test_pull_live_data.py`; (d) add a 0049 row to the revision table in `docs/runbooks/migrations.md` (~line 43). Do NOT touch `tests/test_ci_migrations_job_membership.py`: `backend.yml` already runs every `tests/**/*_pg.py` with MERIDIAN_PG_REQUIRED=1 (W8).
  </action>
  <verify>
    <automated>MERIDIAN_PG_REQUIRED=1 pytest tests/test_bi_exec_store_pg.py tests/test_migrations.py tests/test_pull_live_data.py tests/test_lint_org_scope.py tests/test_lint_org_scope_ratchet.py -x -q</automated>
  </verify>
  <done>Upgrade, downgrade, upgrade clean on the ephemeral Postgres; grants proven by has_table_privilege; stale first insert returns STALE_VERSION; all registrations done and the org-scope lint now covers the new store with the baseline unchanged.</done>
</task>

<task type="auto" tdd="true">
  <name>Task 2 (Wave 2): API routes, schemas, error mapping with details, names, rate limits, deck freshness check, OpenAPI registry</name>
  <files>src/api/v2/bi_exec_routes.py, api/routers/bi_exec.py, api/main.py, src/api/v2/schemas.py, src/api/v2/bi_download_routes.py, src/exec_pptx.py, scripts/generate_openapi.py, openapi/meridian-v2.json, web/src/lib/api/schema.d.ts, tests/test_access_item_gates.py, tests/test_api_v2_bi_exec_pg.py, tests/test_exec_pptx.py</files>
  <behavior>
    - GET /api/v2/bi/executive/tables?fy=2026&edition=quarter&which=3 -> 200 BiExecTablesOut {highlights, initiatives}, each {exists, version, rows, updated_by_name, updated_at}. Missing doc -> exists=false, version=0, rows=[].
    - PUT /api/v2/bi/executive/tables/{kind}?fy&edition&which body {base_version:int>=0, rows:[...], via?: "save"|"import"|"merge"} -> 200 new Doc; 409 code STALE_VERSION with `details.current` = current Doc (with names resolved); 422 on bad rows/params; 403 non-admin or bi access off; 401 unauthenticated; 403 on missing/bad CSRF; 429 over limit; 422 when body > 300 KB. A query string naming org_id/user_id is refused 422 (`_actor` rule).
    - Deck: see action.
    - Tests: 401/403 matrix (anonymous, member, admin with bi off, admin); CSRF; stale 409 body has details.current; first-save race returns STALE_VERSION; two orgs isolated over HTTP; revision row has the right user; 429 handling; caplog proves no note text in logs; names fall back (email local part, then "another admin"); pptx contains an added row and its status after saving (extend tests/test_exec_pptx.py with 8 summary rows -> 2 pages).
  </behavior>
  <action>
    Router `api/routers/bi_exec.py` (prefix `/api/v2/bi`, tag `bi`), same shape as `bi_downloads.py`: `CSRF`, `BI_ADMIN = Depends(require_admin_in("bi"))`, `READ = Depends(limit(LIMIT_READ))`. Rate limit (W2): `LIMIT_WRITE` is 30/min per user and shared with every other BI write, and steady autosave (two tables, blur + hide flushes, 409 re-saves) can pass it; add `LIMIT_EXEC_TABLES = "90/minute"` in `src/api/v2/limits.py` for these two routes only, and ALSO make the client treat 429 as "wait Retry-After (default 5 s), keep the text in memory, retry" and never as a failed/lost save. Handlers: `async def` + `run_in_threadpool` for PUT, plain `def` for GET. Register the router in `api/main.py` beside `bi_downloads_router`.
    Service layer `src/api/v2/bi_exec_routes.py`: call the store through `bi_common.call` and map errors with `bi_common.store_error` (the real helpers, bi_common.py ~81 and ~106; there is no `_call/_out` in bi_dashboard_routes). `store_error` drops any `details`, so add a branch for `StaleVersion`: build `ApiError(code="STALE_VERSION", message="Someone else changed this table.", status=409, details={"current": doc})` directly (ApiError accepts `details`, src/api/v2/errors.py ~320). Names (W1): after the store transaction, in this layer, call `src.auth.fetch_profiles(user_ids, viewer_id, org_id)` (src/auth.py ~256) ONCE for the `updated_by` ids of both docs; fall back to the email local part, then the literal "another admin" for removed members; never expose a raw uuid. Pydantic schemas in schemas.py: `BiExecRowIn` discriminated on `kind` (typed | calc), `extra="forbid"`; `BiExecTablePutIn`; `BiExecTableOut`; `BiExecTablesOut`; a `BiExecStaleOut` for the 409 details.
    OpenAPI (B3): `scripts/generate_openapi.py` has a hand-maintained `ROUTES` registry (the executive export is near line 2109): add two `Route(...)` entries (GET and PUT) FIRST, then regenerate `openapi/meridian-v2.json` and run `npm run generate:types` (never hand-edit schema.d.ts); `scripts/check_api_drift.sh` must exit 0. Add the new GET and PUT to the `ADMIN_BI` list in `tests/test_access_item_gates.py` (~120-139) so the member-403 and bi-off-403 proofs cover them. Also keep `scripts/lint_route_ownership.py` green.
    Audit: each successful write inserts the revision row in the same transaction (who, when, version, via, full rows) and emits one INFO log line `bi exec tables verb=save org=%s user=%s kind=%s version=%s rows=%s` with the `# phi-lint: ok` marker and reason like the neighbouring pptx log (counts only). Reads are not audited. No new audit table.
    Deck freshness (W3): `exec_pptx.validate_spec` DROPS unknown keys, so (1) add `which` to its `out` dict (int; 1-12, 1-4 when edition is quarter; required for non-locked decks); (2) in `bi_download_routes.bi_executive_pptx` read `table_versions` ({highlights:int>=0, initiatives:int>=0}) from the RAW `data` returned by `read_deck_body` (the validated `spec` will not hold it). For non-locked decks compare to `bi_exec_store.get_versions(actor, fy, edition, which)` (cheap SELECT of two versions); mismatch -> ApiError 409 `STALE_TABLES`; missing `table_versions` on a draft deck -> 422. Locked decks skip the check. Keep the existing TODO(AWS) comment and add one line that typed rows are now server-checked.
  </action>
  <verify>
    <automated>MERIDIAN_PG_REQUIRED=1 pytest tests/test_api_v2_bi_exec_pg.py tests/test_access_item_gates.py tests/test_exec_pptx.py tests/test_bi_exec_store_pg.py tests/test_lint_org_scope.py -x -q && python scripts/lint_route_ownership.py && python scripts/lint_no_phi_logging.py && bash scripts/check_api_drift.sh</automated>
  </verify>
  <done>Endpoints behave per the matrix; the 409 body carries the current doc; generated TS types include the new schemas; drift check and lints green.</done>
</task>

<task type="auto" tdd="true">
  <name>Task 3a (Wave 3): pure model and sync hook (no UI)</name>
  <files>web/src/lib/api/bi-exec.ts, web/src/app/bi/executive/tables-model.ts, web/src/app/bi/executive/use-exec-tables.ts, tests: tables-model.test.ts, use-exec-tables.test.tsx, web/src/lib/api/bi-exec.test.ts</files>
  <behavior>
    tables-model.ts (pure): seed definitions by key (Highlights `sum-ops` topic_no 3 default text TYPED_DEFAULTS.ops status hit; `sum-mna` 4 hit; `sum-team` 6 chal; Initiatives `next-0..4` with INITIATIVES default actions). Seed rows carry NO stored name: the display name comes from the i18n key client-side (W5), so the first saver's language is never frozen for other admins. `orderHighlights` (topic_no, calc rows before typed rows of the same topic, then position), `addHighlight(rows, {topic, note})` (topic_no = existing number when the name matches an existing added topic case-insensitively, else max+1; key `a-<random8>`; refuses beyond 37 rows), `removeAdded` (seeds refused), `setStatus(row, s)` (same status again -> ""), `mergeTables(base, mine, theirs)` three-way by row key: a row changed on one side only merges; add/remove by one side merges; same field changed on both sides -> a conflict entry. `toPutPayload`. Tests: add/remove/ordering, status toggle, merge matrix (mine-only, theirs-only, both-different-field, both-same-field, add+add, remove vs edit), seeds not removable, 37-row cap.
    use-exec-tables.ts: loads GET for the scope (reload on fy/edition/which change; ignore a stale response by request id); exposes {highlights, initiatives, status: loading|saved|saving|error|conflict, lastEdited, setHighlights, setInitiatives, flush(), latest() (reads a ref so callers never get a stale closure), retry()}. Autosave per D2 (1.5 s debounce, blur, visibilitychange, before export; one save in flight). The first save is blocked until the first load finished (base_version comes from it). 409 -> mergeTables then resave with base_version = theirs.version; 403 -> read-only; 429 -> wait Retry-After, keep text, retry; 5xx/network -> status error with Retry, text kept in memory. Add `isStaleVersion(e)` in bi-exec.ts beside the other stale helpers. Tests with fake timers: debounce, single in-flight, blur flush, 409 merge then resave, 429 backoff, error then retry, scope switch flushes pending first.
  </behavior>
  <action>Interface-first: write the types and tests, then implement. Use `apiFetch`/`ApiError` as in `lib/api/bi-dashboards.ts`.</action>
  <verify>
    <automated>cd web && npx vitest run src/app/bi/executive/tables-model.test.ts src/app/bi/executive/use-exec-tables.test.tsx src/lib/api/bi-exec.test.ts && npx tsc --noEmit</automated>
  </verify>
  <done>Model and hook pass their tests against a mocked API; no UI changed yet.</done>
</task>

<task type="auto" tdd="true">
  <name>Task 3b (Wave 4): editable table UI, wiring, Spanish strings</name>
  <files>web/src/app/bi/executive/tables-ui.tsx, statements.tsx, forecast.tsx, executive-report.tsx, web/src/lib/i18n/messages/bi-exec.ts, tests: tables-ui.test.tsx, executive-report.test.tsx, executive-access.test.tsx</files>
  <behavior>
    - Highlights keeps columns Topic | Note | Hit | Miss | Challenge. Typed rows: Note is a Textarea (aria-label "Nota de {topic}"); Hit/Miss/Challenge cells are real `<button aria-pressed>` (label "{Topic}: marcar Logrado"), exactly one or none active; Tab order per row: note -> Hit -> Miss -> Challenge; Space/Enter toggle. Computed rows stay read-only (dot from the number) with a small optional-note textarea under the computed text (keys calc-*). Added typed rows have a trash button (`aria-label` "Quitar fila {topic}") with a confirm dialog; seed rows have none. Seed names are shown from the existing i18n keys (`bi.exec.sum.operations` etc.).
    - Initiatives: Initiative (name; editable input for added rows; i18n name for seeds) | Actions (Textarea); number = position.
    - "Add row" button under each table opens an inline form (not a modal): name input (required, 120), note/actions textarea (optional, 2000), Add + Cancel; Enter in the name moves to the note; Escape cancels; after adding, focus moves to the new row's note and a polite live region says "Fila agregada". New rows start with no status. Disabled with a tooltip when the window is Final.
    - Status line per table (aria-live polite): Guardando... / Guardado · {name} · {date time} / Error al guardar [Reintentar] / Combinado con cambios de {name}. Dialog (Radix, like the existing ones) only for same-field conflicts: per row "Usar la de {name}" / "Mantener la mía".
    - Hints (EN + ES) replacing "saved on this device": "Typed rows are editable here. Everyone who can open this report sees the same rows; saved automatically with {w}." / "Las filas escritas se editan aquí. Quien pueda abrir este informe ve las mismas filas; se guardan solo con {w}." (same for `bi.exec.next.hint`). All new keys in BOTH language blocks of messages/bi-exec.ts (i18n completeness test must pass). The three slide Notes boxes keep their "saved on this device only" hint (out of scope).
    - Final banner text now says the final is "frozen on this device" (W4): the lock store is per-browser, so admin B on another computer still sees Draft and can edit the shared rows; the banner must not suggest it is shared.
    DESIGN.md rules: P1 table style (rules not boxes), no new colours, targets >= 24px, existing focus-ring pattern.
    Wiring: `executive-report.tsx` owns `useExecTables(scopeParts)` and passes rows into SummarySlide/NextStepsSlide as props. `TEXT_KEY` stays ONLY for notes-pl/cost/exp; `sum-*`/`next-*` are no longer read/written from it except by the import (Task 4). Typed-row statuses in `statements.tsx` read `row.status` (hard-coded `mark("hit"/"chal")` removed).
  </behavior>
  <action>Implement as described on top of Task 3a. Keep the first-load state: seeds greyed with "Cargando..." until GET returns so a slow request cannot overwrite server rows.</action>
  <verify>
    <automated>cd web && npx vitest run src/app/bi/executive src/lib/i18n && npx tsc --noEmit && npx eslint src/app/bi/executive</automated>
  </verify>
  <done>The two tables behave per the must-have truths in the browser against a mocked API; i18n, tsc, eslint green; no localStorage use for sum-*/next-* outside the import.</done>
</task>

<task type="auto" tdd="true">
  <name>Task 4 (Wave 5): import from this browser, deck + lock wiring, version bump</name>
  <files>web/src/app/bi/executive/import-local.tsx, deck-spec.ts, deck-spec.test.ts, deck-preview.tsx, lock-store.ts, lock-store.test.ts, executive-report.tsx, executive-lock.test.tsx, web/package.json, CHANGELOG.md</files>
  <behavior>
    Import (B4, lossless): on load of a period, if localStorage `meridian.bi.exec.text.v1` has any `"<scope>|sum-ops|sum-mna|sum-team|next-0..4"` key for the current scope, show a Banner: "This browser has text saved for {w} that is not in the shared report. [Review and import] [Not now]". Review opens a dialog listing each row whose local text differs from the server (or seed) text: Row | This browser | Shared report, a checkbox per row (default checked when the shared doc does not exist yet or the shared text still equals the seed default; unchecked when someone already edited it), Import selected / Cancel. Import writes the chosen text into table state and saves with `via: "import"`. Deletion rule: after the LAST successful save (including any 409 merge and resave), compare each local key's text with the FINAL saved server doc and delete ONLY the keys whose text now EQUALS the saved server text. Unchecked rows and rows lost to a "Use theirs" merge resolution keep their key, and the banner stays (it reappears while any differing key remains). The only deletion of un-imported text is the separate "Discard this browser's copy" action inside the dialog, behind a confirm. "Not now" hides the banner for this visit only (state, not storage). Never import before the user clicks. localStorage unreadable/blocked -> no banner. Other scopes' keys and notes-* are never touched. Tests: banner only with matching keys; checkbox defaults; save failure leaves all keys; success removes only equal keys; UNCHECKED row keeps its key and the banner; a 409 "Use theirs" resolution keeps the key; other scope's keys survive.
    Deck (W3): the spec is built in two steps: `openPreview(final)` builds it synchronously, and the POST happens later from `deck-preview.tsx` (`downloadDeck`, ~line 57 and ~535) and from `executive-report.tsx` `downloadVersion`. So: (1) before `openPreview` and before `downloadVersion` do `await flush()` then build the spec from `latest()` (ref, not a stale closure); (2) `deck-spec.ts` summary/next take rows from the saved tables: computed rows as today plus their optional note after " · "; typed and added rows with `n` = topic_no, status from the row, topic/name from the stored name or the i18n seed name; initiatives `n` = position; spec gains `which` and `table_versions`; (3) `deck-preview.tsx` handles 409 STALE_TABLES with toast "Alguien cambió las filas mientras exportabas; cierra la vista previa y ábrela de nuevo" (the open preview cannot refresh its own spec) and triggers a tables reload; `deck-preview.tsx` is therefore in files_modified. Update `executive-lock.test.tsx` expectations (it mocks `exportExecutivePptx`). deck-spec tests: added row appears with the right n/status; initiatives order; 8 summary rows count line; locked spec uses its snapshot, not live rows.
    Lock: `lockWindow` also stores optional `highlights`/`initiatives` row snapshots on FinalVersion (older locks without them fall back to the old text ids). lock-store tests cover back-compat.
    Version (B5): web/package.json is 1.3.54 now (and CHANGELOG already has "v1.3.54, Operations precompute"), so this release is 1.3.55 PATCH. Put the entry at the TOP of CHANGELOG.md (above the 1.3.53 entry): "### Executive Report tables shared (2026-10-19, v1.3.55)" with plain-language lines: Highlights and Initiatives save to the shared report (same for every admin, per quarter/period), add/remove rows, click Hit/Miss/Challenge, who edited last, two admins no longer overwrite each other, this browser's old text can be imported once, the deck uses the saved rows. Propose (do not edit) a CLAUDE.md line about it.
  </behavior>
  <action>Implement per behavior. Commit message: `feat(exec): Highlights and Initiatives are shared per period on AWS: add/remove rows, click Hit/Miss/Challenge, last edited by, no silent overwrite, import from this browser (v1.3.55)` with NO Co-Authored-By and no "Generated with" lines.</action>
  <verify>
    <automated>cd web && npx vitest run src/app/bi/executive && npx tsc --noEmit && cd .. && pytest tests/test_exec_pptx.py -q && grep -q '"version": "1.3.55"' web/package.json</automated>
  </verify>
  <done>Import is offered and lossless; deck export reflects saved rows and refuses stale ones; finals snapshot rows; version and changelog say 1.3.55.</done>
</task>

</tasks>

<test_plan>
Python (pytest): tests/test_bi_exec_store_pg.py (RLS, compare-and-set, append-only revisions and has_table_privilege grants, CHECKs, org isolation); tests/test_api_v2_bi_exec_pg.py (auth matrix, CSRF, 409 body, 422 messages, rate limit, no-text-in-logs, org isolation over HTTP); tests/test_exec_pptx.py (added row and status in deck, paging at 7/5, `table_versions` freshness 409). Existing: tests/test_migrations.py, test_ci_migrations_job_membership.py (nothing to add: backend.yml already runs every tests/**/*_pg.py), test_lint_org_scope*.py.
Vitest: tables-model (add/remove/order/status/merge), use-exec-tables (debounce, in-flight, blur flush, 409 merge, retry, scope switch), tables-ui (keyboard: Tab order, Space toggles status, Enter/Escape in add form, aria-pressed/labels, live regions, Final = read-only), import-local, deck-spec, lock-store back-compat, executive-access (non-admin never sees tables or calls the API), i18n completeness. Run `axe` on the two tables if the repo already has a jest-axe helper (grep before adding any dependency; do not add one).
Pg tests must run with Docker (`MERIDIAN_PG_REQUIRED=1`); per CLAUDE.md this is an AWS step, so before Andres runs `alembic upgrade` anywhere: run infra tests, then dispatch an independent subagent (no shared context) to read the migration against the live account read-only (revision chain at 0048, no name collisions with `bi_exec_*`), plus `/verify` on the running app (add row, click status, reload, second browser profile sees it, conflict path). Hand Andres the exact `alembic upgrade head` command; never run it from here.
</test_plan>

<threat_model>
## Trust boundaries
| Boundary | Description |
|----------|-------------|
| browser -> /api/v2/bi/executive/tables | untrusted JSON (rows, base_version, query params) crosses here |
| browser -> export.pptx | spec still built client-side; only freshness is server-checked |
| app role -> Postgres | tenant isolation depends on org predicate AND RLS |

## STRIDE Threat Register
| Threat ID | Category | Component | Disposition | Mitigation Plan |
|-----------|----------|-----------|-------------|-----------------|
| T-exn-01 | E | PUT/GET tables | mitigate | `require_admin_in("bi")` on both; test matrix anonymous/member/admin-bi-off/admin |
| T-exn-02 | I | cross-tenant read/write | mitigate | `org_id = %s` in every statement + RLS FORCE + WITH CHECK; org/user never read from body or query (422); pg test with a naked SELECT |
| T-exn-03 | T | lost update by concurrent admins | mitigate | compare-and-set on `version` (ON CONFLICT DO NOTHING for first insert so bi_store never rewrites it to NAME_TAKEN); StaleVersion 409 returns the current doc in `details`; client row-level merge |
| T-exn-04 | T | CSRF on PUT | mitigate | `check_csrf` dependency; test with missing token |
| T-exn-05 | T | stored XSS via note text | mitigate | React renders as text (no dangerouslySetInnerHTML); server strips control chars; pptx path already XML-sanitised |
| T-exn-06 | D | oversized or floods of writes | mitigate | 37-row (Highlights; 30 Initiatives), 2000-char, 256 KB caps (API and DB CHECK); dedicated 90/min limit for these routes; client treats 429 as retry-after, one save in flight |
| T-exn-07 | R | who changed what | mitigate | `bi_exec_table_revisions` (user, time, version, full rows); REVOKE ALL then INSERT+SELECT only, so the app role cannot UPDATE or DELETE (proved with has_table_privilege) |
| T-exn-08 | I | note text in logs | mitigate | log counts only; caplog test |
| T-exn-09 | I | notes could contain PHI typed by a person | accept | typed executive text, no patient fields collected; table COMMENT states policy; stored in RDS (not in the PHI schema) |
| T-exn-10 | T | stale deck sent as final truth | mitigate | `table_versions` check on draft decks; finals use frozen snapshot |
</threat_model>

<open_questions>
1. Scope of "everything typed on this page": the three slide Notes boxes (P&L, Cost, Expenses; `notes-*`) and the Mark-final lock store are also localStorage-only. Recommended default: NOT in this plan (owner asked for the two tables); open a follow-up plan that reuses the same table (add kind `notes`) and builds `exec_report_final`. Until then the hint on those three boxes keeps saying "saved on this device only".
2. What does a period with no saved rows start with? Recommended default: the seed topics/initiatives with the current sample text for every period (same as today) until someone edits; no copy-forward. Alternative: new period starts from the previous period's saved rows with statuses cleared.
3. Can an admin override Hit/Miss for computed rows (e.g. mark Clinic Contribution a Challenge)? Recommended default: no, computed rows stay computed (as asked); only an optional note. Say yes and it becomes one extra optional `status_override` field per calc row.
</open_questions>

<verification>
- `pytest` Python files above and `scripts/lint_*.py` green; `cdk synth` not needed (no infra change) but the migration review subagent is.
- vitest + tsc + eslint green; no new dependency added.
- grep: no `useLocalState`/`TEXT_KEY` use for `sum-`/`next-` outside import-local.tsx; no `localStorage` write of those ids anywhere.
- /verify on the running app (use aws-migration ports per memory; do not `next build` while dev runs).
</verification>

<success_criteria>
All 7 truths hold; every EXN requirement covered by Tasks 1-4; migration applied only by Andres; v1.3.55 + CHANGELOG entry; commit has no Claude attribution lines.
</success_criteria>

<output>
After completion, create `.planning/quick/261019-exn-exec-report-editable-notes/261019-exn-SUMMARY.md`.
</output>
