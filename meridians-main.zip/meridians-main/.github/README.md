# .github/

GitHub configuration. Today that is two workflows and nothing else.

## Workflows

| Workflow | File | What it does |
|---|---|---|
| **web** | `workflows/web.yml` | The front-end checks: `npm ci`, `tsc --noEmit`, `vitest run` (including the axe accessibility suite and the token-contrast gate), `next build`, plus two design-system greps — no raw hex colour in a `.tsx`, and no `vh` units. |
| **backend** | `workflows/backend.yml` | The Python checks: `ruff check` + `ruff format --check`, the PHI-logging lint (`scripts/lint_no_phi_logging.py`), `mypy` (at its narrow Phase 0 scope), `pytest tests/` with a **skip audit** on the same run (`scripts/check_pytest_skips.py`, `MAX_SKIPPED=10`), `pip-audit` against `requirements.lock.txt`, and `gitleaks` over the full history (`fetch-depth: 0`). **It installs LibreOffice on purpose and fails if it is missing** — without it, `tests/conftest.py` skips the workbook tests silently and a broken journal-entry calculation looks green. It also sets the four backend switches explicitly, because an unset backend is a deployment mistake. |

Both run on pull requests. `web` also runs on pushes to `main` and `feat/**`; `backend` on pushes to `main`, `aws-migration` and `feat/**`.

## What CI does and does not guarantee

CI **reports** a failure. It does not **prevent** a merge or a deploy: branch protection is
not available on this GitHub plan, so a red commit can still reach `main`, and Render's
auto-deploy will still pick it up. Reading the result is a person's job. Turning Render
auto-deploy off is an open row in `docs/migration-tracker.md`.

The scope of the lint and type checks is deliberately narrow in Phase 0 and widens as
modules are ported — see the `ruff rule widening` and `mypy 5-file scope` rows in
`docs/migration-tracker.md`, and `pyproject.toml` for the current lists.

## What does not live here

- **Secrets.** Workflow credentials come from GitHub Actions secrets, never from a file.
- **Agent and assistant configuration.** `.github/agents/`, `.github/skills/` and
  `.github/hooks/` are gitignored on purpose.
- **Deployment definitions.** Hosting is `render.yaml` today and the CDK app in `infra/`
  from Phase 1.
