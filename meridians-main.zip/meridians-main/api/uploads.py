"""`multipart/form-data` for the FastAPI half, parsed by werkzeug.

WHY NOT `UploadFile`. FastAPI's own form support is `python-multipart`, which
is not a dependency of this repository and may not become one in this phase.
werkzeug already is — Flask brings it, and it stays until Phase 11 deletes the
mount — and its parser is the one that has been reading these exact uploads in
production. So the ported endpoints parse with the SAME parser the Flask ones
did, which is the strongest guarantee available that a workbook accepted
yesterday is accepted today: not a re-implementation, the same code.

What comes back is what `flask.request.form` and `flask.request.files` are: a
`MultiDict` of fields and a `MultiDict` of `FileStorage`. That matters beyond
convenience — `src/api/v2`'s upload helpers call `.getlist()`, `.filename` and
`.save(path)` on them, and those helpers are shared with the Flask modules
that have not moved yet. One shape, one set of helpers, no second upload path.

STREAMED, NOT BUFFERED. The body is spooled to a temporary file as it arrives
and werkzeug reads it from there, spilling each part over 500 kB to its own
temp file exactly as it does under Flask. A whole-body `await request.body()`
would have put a hundred-megabyte workbook in the process's heap.

`MAX_CONTENT_LENGTH` keeps its meaning: it is read off the mounted Flask app,
so there is ONE limit for both surfaces, and going over it is the §4.2
`FILE_TOO_LARGE` envelope rather than werkzeug's HTML 413. When the mount is
absent — the OpenAPI build, and any test that does not bring Flask — there is
no `MAX_CONTENT_LENGTH` to read, and "no limit" is the wrong reading of that:
the bound is then `api.main.max_body_bytes()`, the same number
`MaxBodySizeMiddleware` enforces on the whole request (P5AR2-02). werkzeug is
given it too, so a multipart part that lies about its own length is refused by
the parser rather than spooled to a temporary file first.

THE PARTS ARE CLOSED. Each part over werkzeug's threshold gets its own
`tempfile.TemporaryFile`, and a `FileStorage` that is never closed leaks that
descriptor until the object is collected. `close_uploads` is the yield
dependency that closes them once the handler has answered; every route that
calls `form_and_files` declares it.

Never logged, at any level: a filename, a field value or any part of a body.
"""

from __future__ import annotations

import logging
import tempfile
from typing import Any, AsyncIterator, Tuple

from fastapi import Request
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.formparser import parse_form_data

from src.api.v2 import errors as err
from src.api.v2.errors import ApiError

logger = logging.getLogger(__name__)

#: How much of the body is held in memory before it goes to a temporary file.
SPOOL_MAX_BYTES = 1024 * 1024


def max_content_length(request: Request) -> int:
    """The largest form body this request may carry, in bytes.

    The mounted Flask app's `MAX_CONTENT_LENGTH` when it has one — read from
    there rather than declared here for the reason `csrf_enabled` gives: one
    switch for both surfaces, so a deployment cannot end up capping half of its
    own API — bounded by `api.main.max_body_bytes()`, which is what the ASGI
    guard outside every route allows through in the first place.

    Never None: werkzeug reads `max_content_length=None` as unbounded.

    The import of `api.main` is deferred because that module imports the
    routers, which import this one.
    """
    from .main import max_body_bytes

    hard = max_body_bytes()
    flask_app = getattr(request.app.state, "flask_app", None)
    if flask_app is None:
        return hard
    try:
        limit = flask_app.config.get("MAX_CONTENT_LENGTH")
    except Exception:  # pragma: no cover - defensive
        return hard
    return min(int(limit), hard) if limit else hard


async def close_uploads(request: Request) -> AsyncIterator[None]:
    """Yield dependency: close every `FileStorage` this request parsed.

    werkzeug spills a multipart part over 500 kB into its own
    `tempfile.TemporaryFile` and hands it over inside a `FileStorage`. Nothing
    closed those: the handler reads the part, answers, and the descriptor stays
    open until the garbage collector happens to reach it — on a long-lived
    single-worker process under a run that uploads a workbook a minute, that is
    a descriptor leak with a file-handle limit at the end of it (P5AR2-10).

    Declared on the route rather than done inside `form_and_files`, because the
    files have to outlive that function by exactly one handler.
    """
    try:
        yield
    finally:
        for storage in getattr(request.state, "uploaded_files", ()):
            try:
                storage.close()
            except Exception:  # pragma: no cover - a closed file closes again
                logger.debug("an upload part could not be closed", exc_info=True)


async def form_and_files(request: Request) -> Tuple[Any, Any]:
    """`(form, files)` for this request, in werkzeug's own shapes.

    An empty pair when the request carries no form body at all, which is what
    `flask.request.form` / `.files` are in that case — the callers answer
    `FILES_MISSING`, and a caller must not be able to choose which of our
    error handlers runs by sending something unparseable.
    """
    limit = max_content_length(request)
    with tempfile.SpooledTemporaryFile(max_size=SPOOL_MAX_BYTES) as spool:
        size = 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > limit:
                raise ApiError(
                    err.FILE_TOO_LARGE,
                    "That upload is larger than this server accepts. Nothing was saved.",
                )
            spool.write(chunk)
        spool.seek(0)
        environ = {
            "REQUEST_METHOD": request.method.upper(),
            "CONTENT_TYPE": request.headers.get("content-type", ""),
            "CONTENT_LENGTH": str(size),
            "wsgi.input": spool,
        }
        try:
            _stream, form, files = parse_form_data(environ, max_content_length=limit)
        except RequestEntityTooLarge as exc:
            raise ApiError(
                err.FILE_TOO_LARGE,
                "That upload is larger than this server accepts. Nothing was saved.",
            ) from exc
        # The parts are read (and spilled to their own temp files) before the
        # spool closes, so the `FileStorage` objects outlive this block — which
        # is why `close_uploads` has to be the thing that closes them, and why
        # they are recorded here for it to find.
        request.state.uploaded_files = [
            storage for _key, storage in files.items(multi=True) if storage is not None
        ]
        check_workbook_parts(request.state.uploaded_files)
        return form, files


def check_workbook_parts(parts: Any) -> None:
    """Refuse the request if any part is a ZIP container out of bounds (zip bomb),
    or is not the kind of file its name claims (the file signature).

    Every ported upload route parses through `form_and_files`, so this is the
    one place a workbook is checked before a processor opens it, on either
    database backend:

    * `src.storage.check_workbook_container`: entry count, total declared
      uncompressed size, per-entry ratio; nothing decompressed. The answer is
      the §4.2 `FILE_UNREADABLE` 422, naming no file.
    * `src.file_signature.check`: a `.xlsx`/`.xlsm` is an OOXML workbook ZIP, a
      `.xls` an OLE2 document, a `.csv` text with no NUL. The answer is the
      §4.2 `FILE_TYPE_INVALID` 415 with `details.reason` (a fixed code),
      naming no file. Other extensions are not checked here.
    """
    from src import file_signature
    from src.storage import WorkbookContainerRejected, check_workbook_container

    for storage in parts:
        stream = getattr(storage, "stream", None)
        if stream is None:
            continue
        try:
            check_workbook_container(stream)
        except WorkbookContainerRejected as refused:
            reason = refused.reason
            logger.info(
                "upload refused: workbook container %s", reason
            )  # phi-lint: ok fixed reason code
            raise ApiError(
                err.FILE_UNREADABLE,
                "That workbook could not be opened safely. Nothing was saved.",
            ) from None
        try:
            file_signature.check(getattr(storage, "filename", "") or "", stream)
        except file_signature.FileSignatureRejected as refused:
            reason = refused.reason
            logger.info(
                "upload refused: file signature %s", reason
            )  # phi-lint: ok fixed reason code
            raise ApiError(
                err.FILE_TYPE_INVALID,
                "That file is not the kind of file its name says it is. Nothing was saved.",
                details={"reason": reason},
            ) from None
