# `api/` — the FastAPI layer

The process. `uvicorn api.main:app` serves the paths that have been ported to FastAPI and
mounts the Flask application (`web_app.app`) underneath at `/`, so every path that has not
been ported still answers at the same origin, unchanged. The decisions are
**[ADR 0023](../docs/adr/0023-fastapi-beside-flask.md)**.

```
api/
├── main.py        the app: routers, error handlers, security headers, the Flask mount
├── deps.py        auth / CSRF / rate-limit dependencies — what flask.g used to be
├── errors.py      the api-v2-contract.md 4.1 envelope as exception handlers
├── __main__.py    `python -m api`
├── routers/
│   ├── health.py  GET /api/v1/health, GET /health          (D-25)
│   ├── auth.py    POST /api/v2/auth/*                      (contract 3.1)
│   └── oauth.py   GET /auth/{google,microsoft,callback}    (Phase 11 G2)
└── v3/            /api/v3 (Phase 12) — only with MERIDIAN_API_V3=1 and DATABASE_BACKEND=postgres
    ├── deps.py      Caller + require_scope, the one place a scope is checked
    ├── schemas.py   request/response models (unknown fields refused)
    └── routers/     health, and the fallback that answers 405/404 for the prefix
```

Scope rules (who holds which `/api/v3` scope) are business logic and live in
`src/api_scopes.py`; the plan is `docs/reports/phase-12-plan.md` §3.

## What lives here

HTTP, and only HTTP. A router decodes a request, calls a function in `src/`, and turns what
comes back into a response. `api/routers/auth.py` has no authentication logic in it at all —
the whole of that is in `src/api/v2/auth_routes.py`, written without a framework, which is
what makes the port a translation rather than a second copy.

## What does not

Business logic, SQL, and the OpenAPI document. `openapi/meridian-v2.json` is generated from
the pydantic models by `scripts/generate_openapi.py`; FastAPI's own `/openapi.json` is
disabled so there is exactly one contract in the repository.

## The one rule

**A path leaves Flask in the same commit that lands it here.** Never both.
`tests/test_fastapi_app.py` asserts both halves for every path moved so far.

## Running it

```bash
scripts/serve_api.sh            # the whole application on :5050
scripts/serve_api.sh --reload   # ...with autoreload
python -m api                   # the same thing, no shell script
python web_app.py               # Flask ALONE — no ported paths. Jinja work only.
```
