"""Build the FastAPI app, with Flask mounted underneath it (ADR 0023).

    uvicorn api.main:app

ONE PROCESS, ONE ORIGIN, TWO FRAMEWORKS. Every path this app has a router for
is served by FastAPI; everything else falls through to the Flask app at `/`,
which is the whole of today's Jinja surface plus the `/api/v2` blueprint minus
whatever has been ported. The browser, the Next.js rewrites, the ALB and the
health check cannot tell which half answered — that is the point, and it is
what makes "port one module at a time" a series of safe commits rather than a
flag day.

THE ONE-COMMIT RULE. A path leaves the Flask blueprint in the same commit that
lands it here. Never both: two implementations of one URL is a bug that hides
until the two disagree, and the one that answers is decided by routing order
rather than by anyone's intent.

Flask is mounted through `a2wsgi.WSGIMiddleware`, which streams the request
body to Flask as it arrives instead of reading it all into memory first (the
Starlette adapter this replaced did that, and is deprecated). Phase 11 deletes
the mount outright. `MaxBodySizeMiddleware` below still bounds every body —
the declared `Content-Length` when there is one, and the bytes themselves when
there is not, which is every upload that comes through the Next.js proxy — and
answers a 413 envelope, so no single upload can take the task's 2 GB.
"""

from __future__ import annotations

import json
import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Callable, Optional

from a2wsgi import WSGIMiddleware
from fastapi import FastAPI, Request
from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware

from src import log_setup
from src.api.v2 import bi_drill_routes
from src.api.v2 import errors as v2_errors
from src.http_headers import security_headers
from src.settings import api_v3_enabled, forwarded_allow_ips, max_upload_bytes

from . import errors as api_errors
from .deps import RateLimiter, make_rate_limiter
from .request_log import RequestLogMiddleware
from .routers import auth as auth_router
from .routers import bi as bi_router
from .routers import bi_content as bi_content_router
from .routers import bi_dashboards as bi_dashboards_router
from .routers import bi_downloads as bi_downloads_router
from .routers import bi_exec as bi_exec_router
from .routers import bi_models as bi_models_router
from .routers import config as config_router
from .routers import core as core_router
from .routers import dashboard as dashboard_router
from .routers import dev as dev_router
from .routers import health as health_router
from .routers import local_storage as local_storage_router
from .routers import mx_employees as mx_employees_router
from .routers import oauth as oauth_router
from .routers import oneshot_runs as oneshot_router
from .routers import operations as operations_router
from .routers import payroll_db as payroll_db_router
from .routers import pnl as pnl_router
from .routers import qb_usa_runs as qb_usa_router
from .routers import qbo as qbo_router
from .routers import superadmin as superadmin_router
from .routers import users as users_router

logger = logging.getLogger(__name__)

#: Headroom over `MERIDIAN_MAX_UPLOAD_BYTES` for the multipart envelope: the
#: boundaries, the per-part headers and the filename. A 50 MB workbook arrives
#: as a slightly larger request, and rejecting it at exactly the file limit
#: would refuse the very upload the limit is meant to allow. The precise check
#: stays where it has always been, in the storage layer, against the file.
BODY_SIZE_HEADROOM_BYTES = 1024 * 1024


def max_body_bytes() -> int:
    """The largest request body this process will accept, in bytes."""
    return max_upload_bytes() + BODY_SIZE_HEADROOM_BYTES


class MaxBodySizeMiddleware:
    """Refuse an oversized body before anything downstream buffers it.

    Pure ASGI, and outside every route: the request it is protecting against is
    the one a handler reads past the limit — the ported routers' form parser,
    or a Flask view reading the stream through the mount. uvicorn 0.53 has no
    `--limit-max-request-size` flag to do this at the server (checked; there is
    `--limit-concurrency`, `--limit-max-requests` and `--ws-max-size`, and none
    of them bounds an HTTP body), so it is done here.

    **`Content-Length` is the cheap half; the count is the real one**
    (P5AR2-02). The first version checked the declared length and nothing else,
    on the reasoning that every browser upload sends one. It does — and then
    `web/src/lib/proxy.ts` forwards the request as a **stream**, which the
    fetch runtime frames as `Transfer-Encoding: chunked` with no length at all.
    So in the one deployment this app actually has, the header check never
    fired: every upload arrived chunked and the bound was not there. The guard
    now wraps `receive` and adds up the bytes it passes through, so a body is
    bounded by what it IS rather than by what it said it was, chunked or not.

    Aborting mid-body is the awkward case and is handled honestly: until the
    handler has sent its response start we can still send the 413 envelope, and
    after that there is no status left to change, so the only truthful thing to
    do is stop feeding the body and close the connection (`more_body: False`
    with the stream incomplete makes the caller's read fail rather than letting
    a truncated body look complete).
    """

    def __init__(self, app, limit: Callable[[], int] = max_body_bytes) -> None:
        self.app = app
        self.limit = limit

    @staticmethod
    def _declared_length(scope) -> int:
        for name, value in scope["headers"]:
            if name == b"content-length":
                try:
                    return int(value)
                except ValueError:
                    return 0
        return 0

    @staticmethod
    def _too_large_body(limit: int) -> bytes:
        return json.dumps(
            api_errors.envelope(
                v2_errors.FILE_TOO_LARGE,
                f"That request is larger than the {limit} byte limit.",
                api_errors.new_request_id(),
            )
        ).encode()

    @staticmethod
    async def _send_413(send, limit: int) -> None:
        body = MaxBodySizeMiddleware._too_large_body(limit)
        headers = [(b"content-type", b"application/json")]
        headers += [
            (name.lower().encode("latin-1"), value.encode("latin-1"))
            for name, value in security_headers().items()
        ]
        headers.append((b"content-length", str(len(body)).encode()))
        await send({"type": "http.response.start", "status": 413, "headers": headers})
        await send({"type": "http.response.body", "body": body})

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        limit = self.limit()
        if self._declared_length(scope) > limit:
            # The declared length is still checked first, and for a reason
            # beyond speed: it refuses the request without reading a byte of
            # it, so an honest client is told "too large" before it has spent
            # the bandwidth.
            await self._send_413(send, limit)
            return

        state = {"received": 0, "over": False, "started": False}

        async def counting_receive():
            message = await receive()
            if message["type"] == "http.request":
                state["received"] += len(message.get("body", b"") or "")
                if state["received"] > limit:
                    state["over"] = True
                    # Stop the body here. The app sees a body that ended; it
                    # will fail to parse it, and whatever it answers is
                    # replaced below.
                    return {"type": "http.disconnect"}
            return message

        async def guarded_send(message) -> None:
            if state["over"]:
                if message["type"] == "http.response.start" and not state["started"]:
                    # Nothing has gone out yet: the 413 envelope is still
                    # available and is the right answer.
                    state["started"] = True
                    await self._send_413(send, limit)
                    return
                # Either the envelope has been sent already or the handler had
                # begun streaming before the body ran over. Send nothing more;
                # the connection closes with the response incomplete, which is
                # the only signal left that says "do not trust this".
                return
            if message["type"] == "http.response.start":
                state["started"] = True
            await send(message)

        await self.app(scope, counting_receive, guarded_send)
        if state["over"] and not state["started"]:
            # The app returned without answering at all (an ASGI app is allowed
            # to, once it has seen a disconnect). The caller still gets the
            # envelope that says why.
            state["started"] = True
            await self._send_413(send, limit)


#: The app's own version, reported nowhere in a response body — `/api/v1/health`
#: answers with the v1 contract's `1.0.0` and `/api/v2/health` with the v2
#: contract's `2.0.0`. This is what an operator sees in the OpenAPI document.
APP_VERSION = "2.0.0"


def _load_flask_app():
    """`web_app.app`, imported only when it is actually going to be mounted.

    Deferred because importing `web_app` pulls in pandas, openpyxl and
    WeasyPrint: a test that only needs the ported routers, and the OpenAPI
    generator, should not pay for the whole Jinja application.
    """
    from web_app import app as flask_app

    return flask_app


@asynccontextmanager
async def _lifespan(_app: FastAPI) -> AsyncIterator[None]:
    """Start and stop what lives as long as the server (critic Stage 1 round 2 L1/L2).

    On a laptop with `/api/v3` on, the in-process webhook queue gets its consumer
    (`src.webhooks.local.start_if_local`: a drainer thread, and the boot check
    that the development sealing key is set). It runs for EVERY way the app is
    served — `uvicorn api.main:app`, `--factory api.main:create_app`, a
    `with TestClient(app)` — not only through the module attribute. None in AWS
    (the sender Lambda drains SQS). At shutdown the drainer is stopped and
    joined, so a send in progress finishes instead of dying with the daemon
    thread (a lost one was recovered by the 60 s lease and the sweep anyway).
    Also at start: this host's stale per-request input copies are removed
    (`process_inputs.sweep_stale_pin_scratch`).
    """
    from src import process_inputs
    from src.webhooks import local as local_webhooks

    # Round 2 L13: per-request input copies (PHI-bearing) a dead predecessor on
    # this host left behind. A failure to sweep is not a failure to start.
    try:
        process_inputs.sweep_stale_pin_scratch()
    except OSError as exc:
        logger.warning(
            "stale input scratch sweep failed at start", extra={"error_type": type(exc).__name__}
        )
    local_webhooks.start_if_local()
    # Ask Meridian: build the KNOWN VALUES list now and every 6 h, so no ask waits for it.
    from src import bi_ask

    values_stop = bi_ask.start_values_refresher()
    try:
        yield
    finally:
        if values_stop is not None:
            values_stop.set()
        local_webhooks.stop_drainer()


def create_app(
    wsgi_app: Optional[Any] = None,
    mount_flask: bool = True,
    limiter: Optional[RateLimiter] = None,
) -> FastAPI:
    """Assemble the application.

    `wsgi_app` overrides the Flask app to mount — a test passes a small one so
    the suite does not import the whole web app. `mount_flask=False` builds the
    ported surface alone, which is what `scripts/generate_openapi.py` wants.
    `limiter=None` means no rate limiting, the same opt-out
    `create_api_v2_blueprint(limiter=None)` had.

    **`ProxyHeadersMiddleware` is applied here, not left to the `--proxy-headers`
    CLI flag alone.** uvicorn does not honour `X-Forwarded-For` by default, and
    without it `request.client.host` is the ALB's address for every caller —
    which `api.deps.rate_limit_key` then uses as the bucket key, putting the
    whole firm on one allowance for the credential endpoints. Applying the
    middleware in the app means a `TestClient` exercises the same code the
    server runs, and that the trust list comes from one place
    (`FORWARDED_ALLOW_IPS`, which is also what uvicorn's flag reads) rather than
    from a command line nobody tests.
    """
    app = FastAPI(
        title="Meridian API",
        version=APP_VERSION,
        lifespan=_lifespan,
        # ONE OpenAPI artefact, and it is not this one. `openapi/meridian-v2.json`
        # is generated from the pydantic models by `scripts/generate_openapi.py`
        # and is what the TypeScript client is built from; a second, partial
        # document served at /openapi.json would be a contract nobody
        # regenerates and eventually a contract that lies.
        openapi_url=None,
        docs_url=None,
        redoc_url=None,
    )
    app.state.limiter = limiter

    api_errors.install(app)

    # `/api/v3` audit trail (Phase 12 T06) and the Postgres quota counters its
    # dependencies charge (T09). The middleware is added FIRST so it sits innermost of
    # the middleware below: inside the request envelope (the request id and the
    # proxy-corrected client address exist) and outside the exception handlers
    # (an ApiError has already become its status).
    if api_v3_enabled():
        # Critic Stage 1 H-2: v3 answers webhook calls with 201/202, so outside
        # development it refuses to start without the real queue, secret store
        # and bus (`src/webhooks/ports.check_configuration`) — never a silent
        # in-memory fallback. In AWS the compute stack sets them together with
        # `MERIDIAN_API_V3` (`-c enableApiPlatform=true`).
        from src.webhooks import ports as webhook_ports

        webhook_ports.check_configuration()

        from .v3 import audit as v3_audit
        from .v3 import quotas as v3_quotas

        app.state.api_audit_writer = v3_audit.write_row
        app.state.api_quota_store = v3_quotas.PgQuotaStore()
        app.add_middleware(v3_audit.ApiAuditMiddleware)
        # Machine-client admin (T12): the Cognito port, and the throttled
        # last-use write on each successful machine authentication.
        from src import api_clients as _api_clients
        from src.cognito_client_admin import client_admin_for_environment

        app.state.cognito_client_admin = client_admin_for_environment()
        app.state.api_client_usage_recorder = _api_clients.record_use

    @app.middleware("http")
    async def _request_envelope(request: Request, call_next):
        """Mint the request id, then stamp the security headers on the way out.

        `setdefault` semantics: a response that came back through the Flask
        mount already carries these from `web_app.set_security_headers`, and
        setting them twice would send each header twice.
        """
        request.state.request_id = api_errors.new_request_id()
        response = await call_next(request)
        for name, value in security_headers().items():
            if name not in response.headers:
                response.headers[name] = value
        # Session-bound answers must not survive the session (Codex, 2026-09-17):
        # without this a browser's back/forward cache or an intermediary could
        # replay a dashboard or /me payload after logout. Static files are
        # served under /static and keep their own caching.
        path = request.url.path
        if (path.startswith("/api/") or path.startswith("/auth/")) and (
            "cache-control" not in response.headers
        ):
            response.headers["Cache-Control"] = "no-store"
        return response

    # Outside the envelope middleware, and in this order: the body guard has to
    # run before anything reads the body, and the proxy headers have to be
    # applied before ANYTHING — including the rate limiter's key — asks who the
    # caller is.
    app.add_middleware(MaxBodySizeMiddleware)
    app.add_middleware(ProxyHeadersMiddleware, trusted_hosts=forwarded_allow_ips())
    # Outermost of all: one `http_request` line per request, whichever half
    # answered and whatever answered it — a 413 from the body guard included.
    app.add_middleware(RequestLogMiddleware)

    app.include_router(health_router.router)
    app.include_router(local_storage_router.router)
    app.include_router(core_router.router)
    app.include_router(auth_router.router)
    app.include_router(oauth_router.router)
    app.include_router(config_router.router)
    app.include_router(users_router.router)
    app.include_router(mx_employees_router.router)
    app.include_router(superadmin_router.router)
    app.include_router(pnl_router.router)
    app.include_router(payroll_db_router.router)
    app.include_router(operations_router.router)
    app.include_router(bi_router.router)
    app.include_router(bi_content_router.router)
    app.include_router(bi_dashboards_router.router)
    app.include_router(bi_downloads_router.router)
    app.include_router(bi_exec_router.router)
    app.include_router(bi_models_router.router)
    # The raw-row access log: one observer per process, replaced if an app is built again.
    bi_drill_routes.register_observer()
    app.include_router(oneshot_router.router)
    app.include_router(qb_usa_router.router)
    app.include_router(dashboard_router.router)
    # 404 everywhere but a development laptop (`src/local_sign_in_as.py`).
    app.include_router(dev_router.router)
    app.include_router(qbo_router.router)
    app.include_router(qbo_router.callback_router)

    # `/api/v3` (Phase 12): only behind `MERIDIAN_API_V3` on the Postgres
    # backend, and before the Flask mount so its fallback claims the prefix.
    if api_v3_enabled():
        from . import v3

        v3.install(app)

    if mount_flask:
        flask_app = wsgi_app if wsgi_app is not None else _load_flask_app()
        app.state.flask_app = flask_app
        log_setup.install_flask(flask_app)
        # Mounted LAST and at the root, so it catches everything the routers
        # above did not claim. Starlette matches mounts after routes.
        # a2wsgi types its ASGI signature with its own TypedDicts; Starlette wants plain
        # MutableMappings. Same protocol at runtime.
        app.mount("/", WSGIMiddleware(flask_app))  # type: ignore[arg-type]
    else:
        app.state.flask_app = None

    return app


#: The ASGI application uvicorn serves: `uvicorn api.main:app`.
#:
#: Built on first ACCESS rather than on import (PEP 562), because building it
#: imports `web_app` and everything under it. `uvicorn api.main:app` reaches
#: for the attribute and gets the whole application, eagerly, at boot — a
#: misconfiguration still fails there and not on the first request. A test or
#: the OpenAPI generator that imports `create_app` pays for none of it.
_app: Optional[FastAPI] = None


def __getattr__(name: str) -> Any:
    global _app
    if name == "app":
        if _app is None:
            # The server's entry point, so the log format is installed here and
            # not by a `--log-config` flag nobody tests (ADR 0024 §4). uvicorn has
            # configured its own loggers by now; this re-homes them onto the JSON
            # handler. Only the FORMAT is gated (critic Stage 1 L-16): JSON by
            # default on the Postgres backend, plain text on Supabase/Render unless
            # `MERIDIAN_JSON_LOGS=1`. The redacting filter and the `uvicorn.access`
            # suppression are installed on every backend (round 2 M5): the format
            # may be optional, redaction is not.
            log_setup.configure_logging(json_format=log_setup.json_logging_enabled())
            _app = create_app(limiter=make_rate_limiter())
            # Phase 11 D4: on RDS, the in-process job transport starts with the
            # server, so a job a killed predecessor left behind is delivered
            # again (workers/inprocess.Dispatcher.recover).
            from workers import inprocess

            inprocess.start_if_rds()
            # The local webhook drainer (critic Stage 1 H-2) starts in the app's
            # lifespan (`_lifespan`), so every way of serving it gets one.
        return _app
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
