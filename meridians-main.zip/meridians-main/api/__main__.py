"""`python -m api` — run the API the way the container runs it.

Equivalent to `uvicorn api.main:app --host 0.0.0.0 --port $MERIDIAN_PORT`, and
exists so there is one command that works from a checkout, from a venv and
from inside an image without anybody having to remember the module path.

`python web_app.py` still works and still serves Flask alone; it is the
quickest loop for Jinja work. It does NOT serve the ported paths, so the React
app and anything hitting `/api/v1/health` need this one.
"""

import os


def main() -> None:
    import uvicorn

    uvicorn.run(
        "api.main:app",
        host=os.environ.get("MERIDIAN_HOST", "0.0.0.0"),  # noqa: S104 the container listens on all interfaces; the task SG is the boundary
        port=int(os.environ.get("MERIDIAN_PORT", "5050")),
        # One worker, deliberately: the MFA handle store and the in-process
        # run state are per-process (ADR 0010 rules out Redis), so a second
        # worker would strand half of each.
        workers=1,
        reload=os.environ.get("MERIDIAN_RELOAD") == "1",
    )


if __name__ == "__main__":
    main()
