"""Who is calling `/api/v3`, and may they (phase-12-plan §3.4).

`Caller` is the one shape a v3 handler sees, human or machine. `require_scope`
is the one dependency that compares a caller's scopes with what a route needs:
every v3 route declares exactly that, handlers never read scopes themselves,
and `tests/security/test_route_authz_matrix.py` fails if a route forgets.

The scope check runs BEFORE the handler loads anything, so a 403 reveals
nothing about whether a record exists. Object-level checks (a record in
another org answers 404, never 403) are the handlers' job, via the `org_id`
predicate and RLS.

Humans are resolved exactly as `/api/v2` resolves them (`api.deps.require_user`
then the org, role and permissions from Postgres) and their scopes derived from
those rows. Machines present a Cognito client-credentials ACCESS token
(`src.cognito.validate_machine_token`); their org, status and scopes come from
the `api_clients` row (`src.api_clients.authorize`, T05). Every machine refusal
is the same bare `401 AUTH_REQUIRED`, whatever the reason.
"""

from __future__ import annotations

import hmac
import logging
from dataclasses import dataclass, field
from typing import Iterable, List, Literal, Optional

from fastapi import Depends, Request
from fastapi.routing import APIRoute
from starlette.routing import Match

from src import api_clients, api_scopes, cognito
from src import auth as _auth
from src.api.v2 import errors as err
from src.api.v2.errors import ApiError
from src.settings import api_mtls_origin_verify_secret

from .. import deps as base_deps
from . import quotas

#: The URL prefix every v3 route lives under.
PREFIX = "/api/v3"

#: v3's addition to the §4.2 catalogue: the caller is who they say they are
#: but does not hold the scope this route needs. `details.required_scope`
#: names it. Kept out of `src.api.v2.errors` so the v2 contract document does
#: not change for a code v2 never answers.
SCOPE_INSUFFICIENT = "SCOPE_INSUFFICIENT"

#: Set by the partner mTLS ingress (T25) on every request it forwards: the
#: shared origin-verify secret, and the client-certificate subject it verified.
#: The subject is believed only beside the right secret (§3.6 step 4).
ORIGIN_VERIFY_HEADER = "X-Meridian-Origin-Verify"
CERT_SUBJECT_HEADER = "X-Meridian-Client-Cert-Subject"

#: Where `resolve_caller` leaves the caller for the audit middleware (T06).
CALLER_STATE = "v3_caller"

#: `app.state` attribute holding the last-use recorder (T12,
#: `src.api_clients.record_use`), set by `create_app`.
USAGE_RECORDER_STATE = "api_client_usage_recorder"

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Caller:
    """The caller of a v3 request, whoever they are.

    `org_id` is the tenant, always from a database row (the membership for a
    human, the `api_clients` row for a machine) and never from a token.
    Exactly one of `user_id` / `client_id` is set.
    """

    kind: Literal["human", "machine"]
    org_id: str
    grant: api_scopes.ScopeGrant = field(default_factory=api_scopes.ScopeGrant)
    user_id: Optional[str] = None
    client_id: Optional[str] = None
    #: The human's resolved identity, for `apply_cookies` after a silent refresh.
    identity: Optional[base_deps.Identity] = field(default=None, repr=False, compare=False)

    @property
    def is_machine(self) -> bool:
        return self.kind == "machine"

    def allows(self, scope: str, process: Optional[str] = None) -> bool:
        """Does this caller hold `scope`? Human-only scopes never for a machine."""
        if self.is_machine and scope in api_scopes.HUMAN_ONLY_SCOPES:
            return False
        return self.grant.allows(scope, process)


def human_caller(identity: base_deps.Identity) -> Caller:
    """A `Caller` from an identity whose org half `require_org` has filled in."""
    org = identity.org or {}
    return Caller(
        kind="human",
        org_id=identity.required_org_id,
        grant=api_scopes.scopes_for_human(
            identity.permissions,
            org.get("role"),
            can_read_phi=bool(org.get("can_read_phi")),
        ),
        user_id=identity.user_id,
        identity=identity,
    )


def verified_cert_subject(request: Request) -> Optional[str]:
    """The mTLS client-certificate subject, only when the ingress vouched for it.

    No configured secret (every deployment until T25), no header, or the
    wrong secret → None, so machine `phi:read` never counts.
    """
    expected = api_mtls_origin_verify_secret()
    sent = request.headers.get(ORIGIN_VERIFY_HEADER) or ""
    if not expected or not sent:
        return None
    if not hmac.compare_digest(sent.encode("utf-8"), expected.encode("utf-8")):
        return None
    return request.headers.get(CERT_SUBJECT_HEADER) or None


def machine_caller(request: Request, token: str) -> Caller:
    """A `Caller` for a machine access token, or a bare 401 for any refusal."""
    claims = cognito.validate_machine_token(token)
    if claims is None:
        logger.info("v3 machine token refused: invalid_token")
        raise ApiError(err.AUTH_REQUIRED, "Authentication required.")
    # Signature verified: a refusal from here on may count against this client
    # id in the lockout (T09). Before this point it would let anybody lock a
    # partner out by forging tokens that name it.
    setattr(request.state, quotas.VERIFIED_CLIENT_STATE, claims["client_id"])
    try:
        client, grant = api_clients.authorize(
            claims,
            base_deps.client_address(request),
            verified_cert_subject(request),
        )
    except api_clients.MachineAuthRefused as refused:
        reason = refused.reason
        logger.info("v3 machine token refused: %s", reason)  # phi-lint: ok fixed reason code
        raise ApiError(err.AUTH_REQUIRED, "Authentication required.") from None
    # The address already passed `client.ip_allowlist` in `authorize`; an
    # allowlisted client is exempt from the ADDRESS lockout (quotas, L-4).
    setattr(request.state, quotas.ALLOWLISTED_CLIENT_STATE, client.ip_allowlist is not None)
    # `last_used_at` / `last_used_ip` (T12): throttled inside the recorder, and
    # never allowed to fail the request. Bare test apps have no recorder.
    recorder = getattr(request.app.state, USAGE_RECORDER_STATE, None)
    if recorder is not None:
        recorder(client, base_deps.client_address(request))
    return Caller(kind="machine", org_id=client.org_id, grant=grant, client_id=client.id)


def resolve_caller(request: Request, _gate: None = Depends(quotas.auth_gate)) -> Caller:
    """FastAPI dependency: the caller, or 401 / 403 `ORG_REQUIRED` / 429.

    A bearer token whose (unverified, routing-only) `token_use` is `access` is
    a machine's and goes to `machine_caller`; everything else — ID tokens,
    cookies, the local-development bypass — is a human, resolved exactly as
    `/api/v2` resolves one. Each path verifies its own token.

    `quotas.auth_gate` runs first (progressive lockout on past bearer
    failures); a 401 for a bearer request is counted; a resolved caller
    spends one call of its own allowance (T09).
    """
    token = base_deps._bearer_token(request)
    try:
        if (
            token
            and not _auth._auth_disabled()
            and cognito.token_use_of(token) == cognito.MACHINE_TOKEN_USE
        ):
            caller = machine_caller(request, token)
        else:
            caller = human_caller(base_deps.require_org(base_deps.require_user(request)))
    except ApiError as refused:
        if refused.code == err.AUTH_REQUIRED:
            quotas.record_auth_failure(request)
            quotas.refuse_if_address_locked(request)
        raise
    # A locked-out address refuses every caller except a verified machine
    # client whose own IP allowlist admits it (critic Stage 1 L-4).
    quotas.refuse_if_address_locked(
        request,
        allowlisted=caller.is_machine
        and bool(getattr(request.state, quotas.ALLOWLISTED_CLIENT_STATE, False)),
    )
    setattr(request.state, CALLER_STATE, caller)
    if caller.is_machine:
        quotas.charge(request, f"client:{caller.client_id}")
    else:
        quotas.charge(request, f"user:{caller.user_id}")
    return caller


def require_scope(scope: str):
    """FastAPI dependency: a caller holding `scope`, or 403 `SCOPE_INSUFFICIENT`.

    `require_scope(api_scopes.PUBLIC)` declares a route open on purpose (health,
    sign-in): it resolves nobody and returns None. Any other value must be in
    the catalogue, and a typo fails when the route is defined, not later.

    The returned dependency carries `.required_scope`, which is how the route
    matrix test reads a route's declaration without sending a request.
    """
    if scope != api_scopes.PUBLIC and scope not in api_scopes.ALL_SCOPES:
        raise ValueError(f"unknown API scope: {scope!r}")

    if scope == api_scopes.PUBLIC:

        def _public() -> None:
            return None

        _public.required_scope = scope  # type: ignore[attr-defined]
        return _public

    def _dependency(caller: Caller = Depends(resolve_caller)) -> Caller:
        if not caller.allows(scope):
            raise ApiError(
                SCOPE_INSUFFICIENT,
                "You do not have access to this.",
                status=403,
                details={"required_scope": scope},
            )
        return caller

    _dependency.required_scope = scope  # type: ignore[attr-defined]
    return _dependency


def declared_scopes(route: APIRoute) -> List[str]:
    """Every scope `route` declares through `require_scope`, at any depth."""
    found: List[str] = []
    pending = list(route.dependant.dependencies)
    while pending:
        dependant = pending.pop()
        scope = getattr(dependant.call, "required_scope", None)
        if scope is not None:
            found.append(scope)
        pending.extend(dependant.dependencies)
    return found


def routes_without_scope(routes: Iterable[APIRoute]) -> List[str]:
    """`"METHOD /path"` for every route in `routes` that declares no scope."""
    missing = []
    for route in routes:
        if not declared_scopes(route):
            for method in sorted(route.methods or ()):
                missing.append(f"{method} {route.path}")
    return missing


def allowed_methods(routes: Iterable[APIRoute], path: str) -> List[str]:
    """The methods some route in `routes` answers at `path` (a 405's `Allow`)."""
    probe = {"type": "http", "path": path, "root_path": "", "method": "\x00"}
    methods: set = set()
    for route in routes:
        match, _ = route.matches(probe)
        if match != Match.NONE:
            methods |= set(route.methods or ())
    return sorted(methods)
