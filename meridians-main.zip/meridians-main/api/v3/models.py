"""The `/api/v3` resource models (Phase 12 T07/T08).

Response models classify every field (`api.v3.masking`); request models
forbid unknown fields (`V3Model`). Where `/api/v2` already has the request
model — the mapping creates and patches, the MX roster row — it is reused
as-is: those are `extra="forbid"` already, and the v2 service that validates
them is the one v3 calls, so there is one definition of a valid body.

The mapping response models SUBCLASS the v2 ones and add only a model-wide
classification: the fields, and the conversion from a row, stay defined once.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional

from pydantic import Field

from src.api.v2 import schemas as sc

from . import masking
from .masking import GENERAL, INTERNAL, PII, classified
from .schemas import V3Model

_GENERAL = masking.model_config_for(GENERAL)
#: The v2 row models ignore unknown keys (a row has more columns than the wire).
_GENERAL_V2 = masking.model_config_for(GENERAL, extra="ignore")


# ---------------------------------------------------------------- processes
class ProcessV3(V3Model):
    model_config = _GENERAL

    key: str
    name: str
    enabled: bool
    #: This caller may start a run of it (`processes:run`).
    can_run: bool
    #: This caller may read its runs and results (`runs:read`).
    can_view_results: bool
    steps: List[str]


# --------------------------------------------------------------------- runs
class RunV3(V3Model):
    """A plain `process_runs` read. Nothing a Phase 11 run store would change
    (params, run_state, artifacts, actions) is here: those are AFTER-P11."""

    run_id: str = classified(GENERAL)
    process: str = classified(GENERAL)
    state: str = classified(GENERAL)
    step: Optional[str] = classified(GENERAL, None)
    fiscal_year: Optional[int] = classified(GENERAL, None)
    period: Optional[int] = classified(GENERAL, None)
    #: The legacy batch id. Ours, not a partner's: never a machine's (§3.1 rule 5).
    batch_id: Optional[int] = classified(INTERNAL, None)
    #: The uploaded file's name, as uploaded. Internal (§3.2 table).
    input_file: Optional[str] = classified(INTERNAL, None)
    #: The user who started it. A person's id is not a partner's business.
    created_by: Optional[str] = classified(INTERNAL, None)
    created_at: Optional[datetime] = classified(GENERAL, None)
    updated_at: Optional[datetime] = classified(GENERAL, None)
    completed_at: Optional[datetime] = classified(GENERAL, None)
    superseded_by_run_id: Optional[str] = classified(GENERAL, None)
    #: Created while the org's Test mode was on: never posted, emailed or
    #: announced, and left out of totals.
    is_test: bool = classified(GENERAL, False)


# ---------------------------------------------------------- journal entries
class JournalLineV3(V3Model):
    """One aggregated JE line. Department x payer type x location: no person."""

    model_config = _GENERAL

    je_type: Optional[str] = None
    fiscal_year: Optional[int] = None
    period: Optional[int] = None
    clinic_group: Optional[str] = None
    line_number: Optional[int] = None
    je_date: Optional[str] = None
    subsidiary: Optional[str] = None
    location: Optional[str] = None
    department: Optional[str] = None
    account: Optional[str] = None
    debit: Decimal = Decimal("0")
    credit: Decimal = Decimal("0")
    description: Optional[str] = None


# ----------------------------------------------------------------- mappings
class ProviderMappingV3(sc.ProviderMappingOut):
    model_config = _GENERAL_V2


class LocationMappingV3(sc.LocationMappingOut):
    model_config = _GENERAL_V2


class PayerMappingV3(sc.PayerMappingOut):
    model_config = _GENERAL_V2


class DepartmentV3(sc.DepartmentOut):
    model_config = _GENERAL_V2


class QbProviderCodeV3(sc.QbProviderCodeOut):
    model_config = _GENERAL_V2


class ClinicGroupV3(sc.ClinicGroupOut):
    model_config = _GENERAL_V2


# The other QuickBooks mapping tables (critic H-1 follow-up): chart-of-accounts
# vocabulary only — account paths, classes, clinics, catch-all codes, payer
# labels, locations. No person, no patient: GENERAL, like the rest.
class QbAccountV3(sc.QbAccountOut):
    model_config = _GENERAL_V2


class QbDepartmentV3(sc.QbDepartmentOut):
    model_config = _GENERAL_V2


class QbClinicV3(sc.QbClinicOut):
    model_config = _GENERAL_V2


class QbOtherCodeV3(sc.QbOtherCodeOut):
    model_config = _GENERAL_V2


class QbPayerLabelV3(sc.QbPayerLabelOut):
    model_config = _GENERAL_V2


class QbLocationV3(sc.QbLocationOut):
    model_config = _GENERAL_V2


# ---------------------------------------------------------------- employees
class EmployeeV3(V3Model):
    """One roster row, MX or US. No compensation field exists to expose (§3.2)."""

    entity: str = classified(GENERAL)
    #: The payroll code: the natural key, and what the URL carries.
    employee_id: str = classified(GENERAL)
    name: Optional[str] = classified(PII, None)
    position: Optional[str] = classified(PII, None)
    department: Optional[str] = classified(GENERAL, None)
    department_netsuite: Optional[str] = classified(GENERAL, None)
    report: Optional[str] = classified(GENERAL, None)
    primary_location: Optional[str] = classified(GENERAL, None)
    active: bool = classified(GENERAL, True)


class UsEmployeeIn(V3Model):
    """`PUT /api/v3/employees/{employee_id}?entity=us` — create or replace one row."""

    name: str = Field(min_length=1, max_length=200)
    primary_location: str = Field(min_length=1, max_length=100)
    department: Optional[str] = Field(default=None, max_length=100)
    active: bool = True


class ImportedV3(V3Model):
    model_config = _GENERAL

    imported: int = 0


# -------------------------------------------------------------- allocations
class AllocationShareV3(V3Model):
    model_config = _GENERAL

    location_code: str
    percentage: float


class AllocationV3(V3Model):
    """One employee's clinic split, as `employee_clinic_allocations` holds it."""

    #: The name as the roster normalises it (upper-case). The table's key.
    employee: str = classified(PII)
    file_number: Optional[str] = classified(GENERAL, None)
    entity: Optional[str] = classified(GENERAL, None)
    job_category: Optional[str] = classified(GENERAL, None)
    subsidiary: Optional[str] = classified(GENERAL, None)
    pay_type: Optional[str] = classified(GENERAL, None)
    allocations: List[AllocationShareV3] = classified(GENERAL, default_factory=list)


class AllocationShareIn(V3Model):
    location_code: str = Field(min_length=1, max_length=50)
    percentage: float = Field(gt=0, le=100)


class AllocationIn(V3Model):
    """`PUT /api/v3/allocations` — replace one employee's whole split.

    The employee is named in the BODY, never the URL: a name is PII and the
    URL is logged by every proxy on the way (§3.1 rule 5).
    """

    employee_name: str = Field(min_length=1, max_length=200)
    file_number: Optional[str] = Field(default=None, max_length=50)
    entity: Optional[str] = Field(default=None, max_length=100)
    job_category: Optional[str] = Field(default=None, max_length=100)
    subsidiary: Optional[str] = Field(default=None, max_length=200)
    pay_type: Optional[str] = Field(default=None, max_length=50)
    allocations: List[AllocationShareIn] = Field(min_length=1, max_length=100)


# ------------------------------------------------------------------ revenue
class RevenueSliceV3(V3Model):
    model_config = _GENERAL

    name: str
    clinic_group: Optional[str] = None
    records: int
    amount: float
    pct: float


class RevenueSummaryV3(V3Model):
    """One current revenue batch of a period, as aggregates only.

    Never a transaction row: service dates are identifiers (§3.2 table).
    """

    fiscal_year: int = classified(GENERAL)
    period: int = classified(GENERAL)
    batch_id: Optional[int] = classified(INTERNAL, None)
    total_records: int = classified(GENERAL)
    total_amount: float = classified(GENERAL)
    mapped_records: int = classified(GENERAL)
    unmapped_records: int = classified(GENERAL)
    mapping_rate: float = classified(GENERAL)
    by_clinic_group: List[RevenueSliceV3] = classified(GENERAL, default_factory=list)
    by_location: List[RevenueSliceV3] = classified(GENERAL, default_factory=list)
    by_payer_type: List[RevenueSliceV3] = classified(GENERAL, default_factory=list)


# ---------------------------------------------------- process endpoints (T18)
class UploadV3(V3Model):
    """One file granted to a run (`POST /runs/{run_id}/uploads`)."""

    upload_id: str = classified(GENERAL)
    #: The manifest input it fills (`billing_export`, `payroll_export`, ...).
    role: str = classified(GENERAL)
    #: The name the caller gave. A person's choice, so internal (§3.2 table).
    filename: Optional[str] = classified(INTERNAL, None)
    content_type: Optional[str] = classified(GENERAL, None)


class RunWarningV3(V3Model):
    """A non-blocking fact about the run (`DUPLICATE_INPUT`, contract §12.9)."""

    model_config = _GENERAL

    code: str
    message: str
    details: Optional[Dict[str, Any]] = None


class ProcessRunV3(RunV3):
    """A run as the process endpoints answer it: `RunV3` plus what a caller
    driving it needs — what it may do next, and the files granted so far."""

    #: The job actions legal now (`POST /runs/{run_id}/actions/{action}`).
    available_actions: List[str] = classified(GENERAL, default_factory=list)
    uploads: List[UploadV3] = classified(GENERAL, default_factory=list)
    warnings: List[RunWarningV3] = classified(GENERAL, default_factory=list)
    #: Why a failed run failed: a §4.2 code, never a value.
    error_code: Optional[str] = classified(GENERAL, None)


class UploadRequestV3(V3Model):
    """`POST /api/v3/runs/{run_id}/uploads` — ask for one pre-signed upload.

    `role` may be left out when the process takes one input. The pre-signed
    POST then holds S3 to this `content_type` and to at most the input's
    `max_bytes`.
    """

    role: Optional[str] = Field(default=None, min_length=1, max_length=64)
    filename: str = Field(min_length=1, max_length=255)
    content_type: str = Field(min_length=1, max_length=255)
    size_bytes: int = Field(gt=0)


class UploadGrantV3(V3Model):
    """A pre-signed S3 POST: send `fields` plus the file (as `file`, last) to `url`.

    Expires at `expires_at`. The object is scanned for malware on arrival;
    the run's `execute` answers `FILE_SCAN_PENDING` (409) until it is clean.
    """

    model_config = _GENERAL

    run_id: str
    upload_id: str
    role: str
    method: str = "POST"
    url: str
    fields: Dict[str, str]
    content_type: str
    max_bytes: int
    expires_at: datetime


class ArtifactV3(sc.ArtifactOut):
    """One file a run produced. `phi` ones are listed only to `phi:read`."""

    model_config = _GENERAL_V2

    #: In the `phi` bucket (patient data): downloading it is an audited PHI access.
    phi: bool = False


class ArtifactsV3(V3Model):
    model_config = _GENERAL

    data: List[ArtifactV3]


class DownloadUrlV3(sc.DownloadUrlOut):
    """A short-lived signed URL for one artifact; the mint is audited."""

    model_config = _GENERAL_V2
