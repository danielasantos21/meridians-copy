"""`/api/v3/revenue/summaries` — a period's revenue, as aggregates only (phase-12-plan §3.2).

Scope `revenue:read`. The batches are the period's CURRENT ones
(`pnl_facts.current_batches`: no rehearsal, nothing a re-run superseded),
and each batch's figures are `Database.get_dashboard_data` — the same
numbers the batch dashboard shows, from the org-scoped handle. No
transaction row is ever returned: service dates are identifiers (§3.2).

`location` narrows the location breakdown; the batch totals stay the
batch's, because a total that silently changed with a filter is a figure an
accountant would reconcile against the wrong thing.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse

from src import api_scopes
from src.api.v2.routes import org_db_for
from src.pnl_logic.facts import current_batches

from .. import masking
from ..deps import PREFIX, Caller, require_scope
from ..models import RevenueSliceV3, RevenueSummaryV3
from ..pagination import Paged, PageInfo, PageMeta, only_query

router = APIRouter(prefix=PREFIX, tags=["revenue"])

REVENUE_READ = require_scope(api_scopes.REVENUE_READ)


def _slices(rows: List[Dict[str, Any]], name_key: str = "name") -> List[RevenueSliceV3]:
    return [
        RevenueSliceV3(
            name=str(row.get(name_key) or "Unknown"),
            clinic_group=row.get("clinic_group"),
            records=int(row.get("records") or 0),
            amount=float(row.get("amount") or 0),
            pct=float(row.get("pct") or 0),
        )
        for row in rows or []
    ]


def summary_of(
    data: Dict[str, Any], fiscal_year: int, period: int, batch_id: int, location: Optional[str]
) -> RevenueSummaryV3:
    summary = data.get("summary") or {}
    locations = data.get("location_breakdown") or []
    if location is not None:
        locations = [row for row in locations if row.get("name") == location]
    return RevenueSummaryV3(
        fiscal_year=fiscal_year,
        period=period,
        batch_id=batch_id,
        total_records=int(summary.get("total_records") or 0),
        total_amount=float(summary.get("total_amount") or 0),
        mapped_records=int(summary.get("mapped_records") or 0),
        unmapped_records=int(summary.get("unmapped_records") or 0),
        mapping_rate=float(summary.get("mapping_rate") or 0),
        by_clinic_group=_slices(data.get("clinic_breakdown") or []),
        by_location=_slices(locations),
        by_payer_type=_slices(data.get("payer_breakdown") or [], name_key="type"),
    )


@router.get(
    "/revenue/summaries",
    response_model=Paged[RevenueSummaryV3],
    dependencies=[Depends(only_query("fiscal_year", "period", "location", paged=False))],
)
def revenue_summaries(
    fiscal_year: int = Query(..., ge=2000, le=2100),
    period: int = Query(..., ge=1, le=12),
    location: Optional[str] = Query(None, min_length=1, max_length=200),
    caller: Caller = Depends(REVENUE_READ),
) -> JSONResponse:
    """One summary per current revenue batch of the period (usually one)."""
    db = org_db_for(caller.org_id, caller.user_id)
    items = [
        summary_of(db.get_dashboard_data(batch_id), fiscal_year, period, batch_id, location)
        for batch_id in current_batches(db, fiscal_year, period)
    ]
    body = Paged[RevenueSummaryV3](
        data=items,
        page=PageInfo(limit=max(len(items), 1)),
        meta=PageMeta(total_estimate=len(items)),
    )
    return masking.respond(body, caller)
