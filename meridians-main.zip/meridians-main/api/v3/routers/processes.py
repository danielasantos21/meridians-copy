"""`/api/v3` process endpoints, generated from the manifests (phase-12-plan §3.2, §3.9, T18).

NO PER-PROCESS ROUTER. `build_router()` iterates `src.process_api.api_processes()`
— the registry's manifests that declare a `prepare` — and generates:

=========================================================== ==================== ============
Route                                                       Scope                Notes
=========================================================== ==================== ============
POST /api/v3/processes/{process}/runs  (one per manifest)   processes:run        body = the manifest's
                                                                                 `params_model`;
                                                                                 `Idempotency-Key` required
POST /api/v3/runs/{run_id}/uploads                          processes:run        pre-signed S3 POST
POST /api/v3/runs/{run_id}/actions/{kind} (one per job      execute:             `Idempotency-Key`
     kind some manifest declares with a handler)            processes:execute;   required on execute
                                                            others processes:run
GET  /api/v3/runs/{run_id}/artifacts                        runs:read            `phi` ones need phi:read
POST /api/v3/runs/{run_id}/artifacts/{artifact_id}/download-url
                                                            artifacts:download   + phi:read for `phi`;
                                                                                 audited
=========================================================== ==================== ============

Process-bound scopes are checked FOR the run's process (`access.may_see`): a
run the caller cannot see under the route's scope or `runs:read` — another
org's, a process it holds nothing for, or none at all — is the same `404
RUN_NOT_FOUND`; one it can see but may not act on is `403 SCOPE_INSUFFICIENT`.
A `phi` artifact without `phi:read` is left out of the list and answers 404 to
a download, exactly like an artifact that does not exist.

Job starts are capped per org and process (OWASP API6) on top of every
caller's allowance: one per 30-second window (`quotas.JOB_START_SPACING_*`),
and `quotas.JOB_START_LIMIT` per hour; past either, `429 QUOTA_EXCEEDED` with
`Retry-After`. Every call gets its
`audit.api_request` row from the T06 middleware; a download of a `phi`
artifact also writes the `audit.phi_access` pair and the `artifact_downloads`
row (with the machine client's id) through the same mint `/api/v2` uses.

This module deliberately has no `from __future__ import annotations`: the
create routes' body models are built per manifest at import time, and FastAPI
reads a route's annotations as objects.
"""

import uuid
from typing import Any, Dict, List, Mapping, Optional

from fastapi import APIRouter, Body, Depends, Header, Request
from fastapi.responses import JSONResponse
from pydantic import Field, create_model

from src import api_scopes, process_api, process_runs
from src.api.v2 import errors as err
from src.api.v2 import runs_common as rc
from src.api.v2.errors import ApiError
from src.processes import REGISTRY
from src.processes.manifest import ProcessManifest

from ... import errors as api_errors
from ...deps import client_address
from .. import access, masking, quotas
from ..deps import PREFIX, SCOPE_INSUFFICIENT, Caller, require_scope
from ..models import (
    ArtifactsV3,
    ArtifactV3,
    DownloadUrlV3,
    ProcessRunV3,
    RunWarningV3,
    UploadGrantV3,
    UploadRequestV3,
    UploadV3,
)
from ..pagination import only_query
from ..schemas import V3Model
from .runs import _run_out

TAG = "processes"

PROCESSES_RUN = require_scope(api_scopes.PROCESSES_RUN)
RUNS_READ = require_scope(api_scopes.RUNS_READ)
ARTIFACTS_DOWNLOAD = require_scope(api_scopes.ARTIFACTS_DOWNLOAD)

NO_QUERY = [Depends(only_query(paged=False))]


# ------------------------------------------------------------------ helpers
def _actor(caller: Caller) -> process_api.Actor:
    email = None
    if caller.identity is not None:
        email = (caller.identity.user or {}).get("email")
    return process_api.Actor(
        org_id=caller.org_id,
        user_id=None if caller.is_machine else caller.user_id,
        client_id=caller.client_id if caller.is_machine else None,
        email=email,
    )


def _process_out(manifest: ProcessManifest, row: Mapping[str, Any]) -> ProcessRunV3:
    base = _run_out(dict(row)).model_dump()
    run_state = row.get("run_state") or {}
    error = row.get("error") or {}
    return ProcessRunV3(
        **base,
        available_actions=process_api.available_actions(manifest, row),
        uploads=[
            UploadV3(
                upload_id=str(u.get("upload_id")),
                role=str(u.get("role")),
                filename=u.get("filename"),
                content_type=u.get("content_type"),
            )
            for u in process_api.pending_uploads(row)
        ],
        warnings=[
            RunWarningV3(
                code=str(w.get("code")), message=str(w.get("message")), details=w.get("details")
            )
            for w in (run_state.get("warnings") or [])
            if isinstance(w, dict)
        ],
        error_code=error.get("code") if isinstance(error, dict) else None,
    )


def _deny(scope: str, process: str) -> ApiError:
    return ApiError(
        SCOPE_INSUFFICIENT,
        "You do not have access to this.",
        status=403,
        details={"required_scope": scope, "process": process},
    )


def _run_for(caller: Caller, run_id: uuid.UUID, scope: str) -> Dict[str, Any]:
    """This org's run that the caller may act on under `scope` — or 404 / 403.

    Found by `run_id AND org_id` (RLS under it). Invisible (another org's, a
    process the caller holds neither `scope` nor `runs:read` for, or nothing)
    is `404 RUN_NOT_FOUND`, identical in every case; visible but not
    actionable is `403 SCOPE_INSUFFICIENT`.
    """
    row = process_runs.get_run(caller.org_id, str(run_id))
    process = (row or {}).get("process")
    may_act = bool(row) and access.may_see(caller, scope, process)
    if not may_act and not (row and access.may_see(caller, api_scopes.RUNS_READ, process)):
        raise ApiError(err.RUN_NOT_FOUND, "No such run.")
    if not may_act:
        raise _deny(scope, str(process))
    return dict(row or {})


def _api_manifest(row: Mapping[str, Any]) -> ProcessManifest:
    """The run's manifest, when v3 drives that process's runs; else 404."""
    manifest = process_api.api_process(str(row.get("process")))
    if manifest is None:
        raise ApiError(
            err.NOT_FOUND,
            "This process's runs are not started through /api/v3 yet.",
            details={"process": row.get("process")},
        )
    return manifest


def _rc_caller(caller: Caller, request: Request) -> rc.Caller:
    user: Dict[str, Any] = {}
    permissions: Dict[str, Any] = {}
    if caller.identity is not None:
        user = dict(caller.identity.user or {})
        permissions = dict(caller.identity.permissions or {})
    return rc.Caller(
        org_id=caller.org_id,
        user=user,
        permissions=permissions,
        ip=client_address(request),
        user_agent=(request.headers.get("user-agent") or "")[:512] or None,
        request_id=api_errors.request_id(request),
        client_id=caller.client_id if caller.is_machine else None,
    )


def _visible_artifacts(
    manifest: ProcessManifest, caller: Caller, row: Mapping[str, Any]
) -> List[Any]:
    """[(path, ArtifactV3)] this caller may see: `phi` ones only with `phi:read`."""
    out = []
    for path, artifact in process_api.artifacts_of(manifest, caller.org_id, row):
        phi = process_api.is_phi_artifact(artifact)
        if phi and not caller.allows(api_scopes.PHI_READ):
            continue
        out.append((path, ArtifactV3(**artifact.model_dump(), phi=phi)))
    return out


# ------------------------------------------------------------------- create
def _create_body(manifest: ProcessManifest) -> type:
    """`{"params": <the manifest's params_model>}`, strict, one per process."""
    pascal = "".join(part.capitalize() for part in manifest.id.split("-"))
    try:
        manifest.params_model()
        default: Any = Field(default_factory=manifest.params_model)
    except Exception:  # a process whose params have required fields
        default = ...
    return create_model(
        f"{pascal}CreateRunV3",
        __base__=V3Model,
        __doc__=f"`POST /api/v3/processes/{manifest.id}/runs` — the create params.",
        params=(manifest.params_model, default),
    )


def _add_create(router: APIRouter, manifest: ProcessManifest) -> None:
    body_model = _create_body(manifest)
    process = manifest.id

    def create(
        body: body_model = Body(...),  # type: ignore[valid-type]
        idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
        caller: Caller = Depends(PROCESSES_RUN),
    ) -> JSONResponse:
        # Held FOR this process, in a module the org has on. The process
        # catalogue is not a secret (`GET /processes` lists it), so a 403.
        if not access.may_see(caller, api_scopes.PROCESSES_RUN, process):
            raise _deny(api_scopes.PROCESSES_RUN, process)
        key = process_api.require_key(idempotency_key)
        row, created = process_api.create_run(manifest, _actor(caller), body.params, key)  # type: ignore[attr-defined]
        return masking.respond(_process_out(manifest, row), caller, status=201 if created else 200)

    create.__doc__ = (
        f"Start a {manifest.label} run: a draft that takes its files next "
        "(`POST /runs/{run_id}/uploads`), then `execute`. A repeated "
        "`Idempotency-Key` returns the same run (200)."
    )
    router.add_api_route(
        f"/processes/{process}/runs",
        create,
        methods=["POST"],
        status_code=201,
        response_model=ProcessRunV3,
        dependencies=NO_QUERY,
        name=f"create_{process.replace('-', '_')}_run",
        summary=f"Create a {manifest.label} run",
    )


# ------------------------------------------------------------------- upload
def _add_upload(router: APIRouter) -> None:
    def request_upload(
        run_id: uuid.UUID,
        body: UploadRequestV3,
        caller: Caller = Depends(PROCESSES_RUN),
    ) -> JSONResponse:
        """A pre-signed POST for one input file of a draft run (5 minutes).

        Send the returned `fields` and then the file to `url`. The policy pins
        the key, this `content_type` and the input's size limit; the object is
        scanned for malware on arrival and nothing reads it until it is clean.
        """
        row = _run_for(caller, run_id, api_scopes.PROCESSES_RUN)
        manifest = _api_manifest(row)
        _run, grant = process_api.grant_upload(
            manifest,
            row,
            role=body.role,
            filename=body.filename,
            content_type=body.content_type,
            size_bytes=body.size_bytes,
        )
        out = UploadGrantV3(run_id=str(row["run_id"]), **grant)
        response = masking.respond(out, caller, status=201)
        response.headers["Cache-Control"] = "no-store"  # a write credential
        return response

    router.add_api_route(
        "/runs/{run_id}/uploads",
        request_upload,
        methods=["POST"],
        status_code=201,
        response_model=UploadGrantV3,
        dependencies=NO_QUERY,
        summary="Get a pre-signed upload for a run",
    )


# ------------------------------------------------------------------ actions
def _add_action(router: APIRouter, kind: str) -> None:
    scope = process_api.ACTION_SCOPES[kind]
    needs_key = kind in process_api.IDEMPOTENCY_REQUIRED
    scope_dependency = require_scope(scope)

    def action(
        run_id: uuid.UUID,
        request: Request,
        idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
        caller: Caller = Depends(scope_dependency),
    ) -> JSONResponse:
        row = _run_for(caller, run_id, scope)
        manifest = _api_manifest(row)
        job = manifest.jobs.get(kind)
        if job is None or job.handler is None:
            raise ApiError(
                err.NOT_FOUND,
                f"{manifest.label} runs have no {kind!r} action.",
                details={"action": kind},
            )
        key = process_api.require_key(idempotency_key) if needs_key else idempotency_key
        # The 30-second spacing first: a call it refuses does not spend the
        # hour's allowance.
        quotas.cap(
            request,
            f"jobs-30s:{caller.org_id}:{manifest.id}",
            quotas.JOB_START_SPACING_LIMIT,
            quotas.JOB_START_SPACING_WINDOW,
        )
        quotas.cap(
            request,
            f"jobs:{caller.org_id}:{manifest.id}",
            quotas.JOB_START_LIMIT,
            quotas.JOB_START_WINDOW,
        )
        started = process_api.start_action(manifest, row, kind, _actor(caller), key)
        return masking.respond(_process_out(manifest, started), caller, status=202)

    action.__doc__ = (
        f"Start the run's `{kind}` job (the manifest's). "
        + (
            "Requires `Idempotency-Key`: a repeat with the same key replays, never books twice. "
            if needs_key
            else "An `Idempotency-Key` makes a repeat replay. "
        )
        + "Answers 202 with the run; poll `GET /runs/{run_id}`. "
        + "An organization starts at most one job of a process per 30-second window "
        + "and 30 an hour (`429 QUOTA_EXCEEDED` with `Retry-After`)."
    )
    router.add_api_route(
        f"/runs/{{run_id}}/actions/{kind}",
        action,
        methods=["POST"],
        status_code=202,
        response_model=ProcessRunV3,
        dependencies=NO_QUERY,
        name=f"{kind}_run",
        summary=f"Start the run's {kind} job",
    )


# ---------------------------------------------------------------- artifacts
def _add_artifacts(router: APIRouter) -> None:
    def list_run_artifacts(run_id: uuid.UUID, caller: Caller = Depends(RUNS_READ)) -> JSONResponse:
        """What a completed run produced (409 `ARTIFACTS_NOT_READY` before).

        Files in the `phi` bucket (the enriched data, the reports, the bundle)
        are listed only to a caller holding `phi:read`.
        """
        row = _run_for(caller, run_id, api_scopes.RUNS_READ)
        manifest = REGISTRY[str(row["process"])]
        data = [artifact for _path, artifact in _visible_artifacts(manifest, caller, row)]
        return masking.respond(ArtifactsV3(data=data), caller)

    def create_download_url(
        run_id: uuid.UUID,
        artifact_id: str,
        request: Request,
        caller: Caller = Depends(ARTIFACTS_DOWNLOAD),
    ) -> JSONResponse:
        """A short-lived signed URL for one artifact. The mint is audited
        (`artifact_downloads`; for a `phi` file also `audit.phi_access`)."""
        row = _run_for(caller, run_id, api_scopes.ARTIFACTS_DOWNLOAD)
        manifest = REGISTRY[str(row["process"])]
        visible = {a.artifact_id for _path, a in _visible_artifacts(manifest, caller, row)}
        if artifact_id not in visible:
            raise ApiError(err.NOT_FOUND, "No such artifact on this run.")
        minted = process_api.mint_download(
            manifest, _rc_caller(caller, request), str(row["run_id"]), artifact_id
        )
        response = masking.respond(DownloadUrlV3(**minted.model_dump()), caller)
        response.headers["Cache-Control"] = "no-store"  # a bearer URL
        return response

    router.add_api_route(
        "/runs/{run_id}/artifacts",
        list_run_artifacts,
        methods=["GET"],
        response_model=ArtifactsV3,
        dependencies=NO_QUERY,
        summary="List a run's artifacts",
    )
    router.add_api_route(
        "/runs/{run_id}/artifacts/{artifact_id}/download-url",
        create_download_url,
        methods=["POST"],
        response_model=DownloadUrlV3,
        dependencies=NO_QUERY,
        summary="Mint a signed download URL",
    )


def build_router(
    manifests: Optional[List[ProcessManifest]] = None,
    actions: Optional[List[str]] = None,
) -> APIRouter:
    """The process routes for `manifests` (default: every v3 process)."""
    router = APIRouter(prefix=PREFIX, tags=[TAG])
    for manifest in manifests if manifests is not None else process_api.api_processes():
        _add_create(router, manifest)
    _add_upload(router)
    for kind in actions if actions is not None else process_api.api_actions():
        _add_action(router, kind)
    _add_artifacts(router)
    return router


router = build_router()
