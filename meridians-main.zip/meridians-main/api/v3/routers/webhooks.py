"""`/api/v3/webhooks` — subscriptions, the delivery log, test pings and redrive (Phase 12 T11).

phase-12-plan §3.2 (two rows), §3.7; ADR 0038. The work is
`src.webhooks.subscriptions` (Postgres + the secret port) and
`src.webhooks.engine` (the delivery state machine); this router adds the
scope, the strict request models, the page and the classified response.

Every route needs `webhooks:manage`: an org admin (human) or a machine client
granted it. Object-level rules, on every request:

* the org is the caller's, from a database row, never a parameter;
* a machine sees only the subscriptions it created, and their deliveries;
* anything outside that — another org's, another client's, a deleted one, or
  nobody's — is the same `404 NOT_FOUND`.

A URL the SSRF guard refuses (§3.7) is `422 WEBHOOK_URL_REJECTED` with one
generic message whatever the reason, so this endpoint cannot be used to ask
what our DNS thinks of a name.

The plain signing secret is in the create and rotate responses and nowhere
else, ever: Postgres holds only a reference to it.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Tuple

from fastapi import APIRouter, Depends, Query, Request, Response
from fastapi.responses import JSONResponse
from pydantic import Field, field_validator, model_validator

from api.routers.config import _raw_body as json_body
from src import api_scopes
from src.api.v2 import errors as err
from src.api.v2.errors import ApiError
from src.api.v2.routes import body_of
from src.webhooks import engine
from src.webhooks import subscriptions as subs
from src.webhooks.ssrf import MAX_URL_LENGTH, SSRFError

from .. import masking, quotas
from ..deps import PREFIX, Caller, require_scope
from ..masking import GENERAL, INTERNAL, classified
from ..pagination import Paged, PageParams, bad_cursor, only_query, page_of, page_params
from ..schemas import V3Model

router = APIRouter(prefix=PREFIX, tags=["webhooks"])

WEBHOOKS_MANAGE = require_scope(api_scopes.WEBHOOKS_MANAGE)

#: §3.3: one generic message for every refused URL.
WEBHOOK_URL_REJECTED = "WEBHOOK_URL_REJECTED"
#: Redrive of a delivery that is not dead or dropped; a ping to a paused one.
WEBHOOK_STATE_INVALID = "WEBHOOK_STATE_INVALID"

CURSOR_KEYS = ("created_at", "id")

EventType = Literal["run.completed", "run.failed", "run.blocked", "run.needs_input", "run.expired"]
DeliveryStatus = Literal["pending", "delivered", "failed", "dropped", "dead"]


# ------------------------------------------------------------------ models
def _unique(values: List[str]) -> List[str]:
    if len(set(values)) != len(values):
        raise ValueError("each event type may be listed once")
    return values


class SubscriptionIn(V3Model):
    url: str = Field(min_length=9, max_length=MAX_URL_LENGTH)
    event_types: List[EventType] = Field(min_length=1, max_length=len(engine.EVENT_TYPES))

    @field_validator("event_types")
    @classmethod
    def _types_unique(cls, value: List[str]) -> List[str]:
        return _unique(value)


class SubscriptionPatch(V3Model):
    url: Optional[str] = Field(None, min_length=9, max_length=MAX_URL_LENGTH)
    event_types: Optional[List[EventType]] = Field(
        None, min_length=1, max_length=len(engine.EVENT_TYPES)
    )
    status: Optional[Literal["active", "paused"]] = None

    @field_validator("event_types")
    @classmethod
    def _types_unique(cls, value: Optional[List[str]]) -> Optional[List[str]]:
        return _unique(value) if value is not None else value

    @model_validator(mode="after")
    def _something(self) -> "SubscriptionPatch":
        if not self.model_fields_set:
            raise ValueError("send at least one of url, event_types, status")
        for name in self.model_fields_set:
            if getattr(self, name) is None:
                raise ValueError(f"{name} cannot be null")
        return self


class SubscriptionV3(V3Model):
    model_config = masking.model_config_for(GENERAL)

    id: str
    url: str
    event_types: List[str]
    status: str
    #: Consecutive dead deliveries; 5 pauses the subscription.
    failure_streak: int
    #: The machine client that owns it; null when an org admin created it.
    api_client_id: Optional[str] = None
    #: The admin who created it. A person's id is not a partner's business.
    created_by: Optional[str] = classified(INTERNAL, None)
    created_at: Optional[datetime] = None


class SubscriptionCreatedV3(SubscriptionV3):
    #: The signing secret. Shown in this response only, never again.
    secret: str = classified(GENERAL)


class SecretRotatedV3(V3Model):
    model_config = masking.model_config_for(GENERAL)

    id: str
    #: The new signing secret. Shown in this response only.
    secret: str
    #: Until then deliveries are signed with the old secret too.
    previous_valid_until: datetime


class PingQueuedV3(V3Model):
    model_config = masking.model_config_for(GENERAL)

    delivery_id: str
    event_id: str


class DeliveryV3(V3Model):
    model_config = masking.model_config_for(GENERAL)

    id: str
    subscription_id: str
    event_id: str
    event_type: str
    attempt: int
    status: str
    last_status_code: Optional[int] = None
    #: Our reason code (TENANT_MISMATCH, SSRF_BLOCKED, HTTP_ERROR, …), never a body.
    last_error_code: Optional[str] = None
    next_attempt_at: Optional[datetime] = None
    last_attempt_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    created_at: Optional[datetime] = None


# ----------------------------------------------------------------- helpers
def _owner(caller: Caller) -> subs.Owner:
    if caller.is_machine:
        return subs.Owner(org_id=caller.org_id, client_id=caller.client_id)
    return subs.Owner(org_id=caller.org_id, user_id=caller.user_id)


def _not_found() -> ApiError:
    return ApiError(err.NOT_FOUND, "Not found.")


def _url_rejected() -> ApiError:
    return ApiError(
        WEBHOOK_URL_REJECTED,
        "That URL cannot receive webhooks.",
        status=422,
        field_errors={"url": ["not accepted"]},
    )


def _subscription_out(row: Dict[str, Any]) -> SubscriptionV3:
    return SubscriptionV3(
        id=str(row["id"]),
        url=row["url"],
        event_types=list(row["event_types"] or []),
        status=row["status"],
        failure_streak=int(row["failure_streak"]),
        api_client_id=str(row["api_client_id"]) if row.get("api_client_id") else None,
        created_by=str(row["created_by"]) if row.get("created_by") else None,
        created_at=row.get("created_at"),
    )


def _delivery_out(row: Dict[str, Any]) -> DeliveryV3:
    return DeliveryV3(
        id=str(row["id"]),
        subscription_id=str(row["subscription_id"]),
        event_id=str(row["event_id"]),
        event_type=row["event_type"],
        attempt=int(row["attempt"]),
        status=row["status"],
        last_status_code=row.get("last_status_code"),
        last_error_code=row.get("last_error_code"),
        next_attempt_at=row.get("next_attempt_at"),
        last_attempt_at=row.get("last_attempt_at"),
        delivered_at=row.get("delivered_at"),
        created_at=row.get("created_at"),
    )


def _after(params: PageParams) -> Optional[Tuple[str, str]]:
    after = params.after(CURSOR_KEYS)
    if after is None:
        return None
    try:
        datetime.fromisoformat(str(after["created_at"]))
        uuid.UUID(str(after["id"]))
    except ValueError as exc:
        raise bad_cursor() from exc
    return str(after["created_at"]), str(after["id"])


def _cursor_key(item: Any) -> Dict[str, Any]:
    return {"created_at": item.created_at.isoformat() if item.created_at else "", "id": item.id}


# ----------------------------------------------------------- subscriptions
@router.get(
    "/webhooks/subscriptions",
    response_model=Paged[SubscriptionV3],
    dependencies=[Depends(only_query())],
)
def list_subscriptions(
    params: PageParams = Depends(page_params),
    caller: Caller = Depends(WEBHOOKS_MANAGE),
) -> JSONResponse:
    """This org's subscriptions (a machine: its own), newest first."""
    rows = subs.list_page(_owner(caller), params.limit + 1, _after(params))
    body = page_of([_subscription_out(r) for r in rows], params.limit, _cursor_key)
    return masking.respond(body, caller)


@router.post(
    "/webhooks/subscriptions",
    status_code=201,
    response_model=SubscriptionCreatedV3,
    dependencies=[Depends(only_query(paged=False))],
)
async def create_subscription(
    request: Request, caller: Caller = Depends(WEBHOOKS_MANAGE)
) -> JSONResponse:
    """Subscribe an HTTPS URL to run events. 201 with the secret — shown once."""
    body = body_of(SubscriptionIn, await json_body(request))
    try:
        row, secret = subs.create(
            _owner(caller), body.url, list(body.event_types), engine.get_ports()
        )
    except SSRFError:
        raise _url_rejected() from None
    out = SubscriptionCreatedV3(**_subscription_out(row).model_dump(), secret=secret)
    return masking.respond(out, caller, status=201)


@router.get(
    "/webhooks/subscriptions/{subscription_id}",
    response_model=SubscriptionV3,
    dependencies=[Depends(only_query(paged=False))],
)
def get_subscription(
    subscription_id: uuid.UUID, caller: Caller = Depends(WEBHOOKS_MANAGE)
) -> JSONResponse:
    row = subs.get(_owner(caller), str(subscription_id))
    if row is None:
        raise _not_found()
    return masking.respond(_subscription_out(row), caller)


@router.patch(
    "/webhooks/subscriptions/{subscription_id}",
    response_model=SubscriptionV3,
    dependencies=[Depends(only_query(paged=False))],
)
async def update_subscription(
    subscription_id: uuid.UUID, request: Request, caller: Caller = Depends(WEBHOOKS_MANAGE)
) -> JSONResponse:
    """Change the URL (re-checked), the event types, or pause / resume."""
    body = body_of(SubscriptionPatch, await json_body(request))
    changes = {name: getattr(body, name) for name in body.model_fields_set}
    if "event_types" in changes:
        changes["event_types"] = list(changes["event_types"])
    owner = _owner(caller)
    if subs.get(owner, str(subscription_id)) is None:
        raise _not_found()  # before the URL check: a 422 must not confirm the id exists
    try:
        row = subs.update(owner, str(subscription_id), changes, engine.get_ports())
    except SSRFError:
        raise _url_rejected() from None
    if row is None:
        raise _not_found()
    return masking.respond(_subscription_out(row), caller)


@router.delete(
    "/webhooks/subscriptions/{subscription_id}",
    status_code=204,
    response_model=None,
    dependencies=[Depends(only_query(paged=False))],
)
def delete_subscription(
    subscription_id: uuid.UUID, caller: Caller = Depends(WEBHOOKS_MANAGE)
) -> Response:
    """Stop and remove it (its delivery log stays). 204."""
    if not subs.disable(_owner(caller), str(subscription_id), engine.get_ports()):
        raise _not_found()
    return Response(status_code=204)


@router.post(
    "/webhooks/subscriptions/{subscription_id}/rotate-secret",
    response_model=SecretRotatedV3,
    dependencies=[Depends(only_query(paged=False))],
)
def rotate_subscription_secret(
    subscription_id: uuid.UUID, caller: Caller = Depends(WEBHOOKS_MANAGE)
) -> JSONResponse:
    """A new secret, shown once; the old one keeps signing for 24 hours."""
    rotated = subs.rotate_secret(_owner(caller), str(subscription_id), engine.get_ports())
    if rotated is None:
        raise _not_found()
    secret, until = rotated
    out = SecretRotatedV3(id=str(subscription_id), secret=secret, previous_valid_until=until)
    return masking.respond(out, caller)


@router.post(
    "/webhooks/subscriptions/{subscription_id}/test",
    status_code=202,
    response_model=PingQueuedV3,
    dependencies=[Depends(only_query(paged=False))],
)
def test_subscription(
    subscription_id: uuid.UUID, request: Request, caller: Caller = Depends(WEBHOOKS_MANAGE)
) -> JSONResponse:
    """Queue a signed `webhook.test` delivery through the real path. 202.

    Bounded: 1 per subscription per 30-second window and 60 per org per hour
    (`429 QUOTA_EXCEEDED` with `Retry-After`), counted whether or not the ping
    is queued.
    """
    owner = _owner(caller)
    if subs.get(owner, str(subscription_id)) is None:
        raise _not_found()
    quotas.cap(
        request,
        f"webhook-test-30s:{caller.org_id}:{subscription_id}",
        subs.TESTS_PER_SUBSCRIPTION,
        subs.TEST_SUBSCRIPTION_WINDOW_SECONDS,
    )
    quotas.cap(
        request,
        f"webhook-test:{caller.org_id}",
        subs.TESTS_PER_ORG_PER_HOUR,
        subs.TEST_ORG_WINDOW_SECONDS,
    )
    try:
        queued = subs.test_ping(owner, str(subscription_id), engine.get_ports())
    except subs.NotActive:
        raise ApiError(
            WEBHOOK_STATE_INVALID, "Only an active subscription can be tested.", status=409
        ) from None
    if queued is None:
        raise _not_found()
    return masking.respond(PingQueuedV3(**queued), caller, status=202)


# -------------------------------------------------------------- deliveries
@router.get(
    "/webhooks/deliveries",
    response_model=Paged[DeliveryV3],
    dependencies=[Depends(only_query("subscription_id", "status"))],
)
def list_deliveries(
    subscription_id: Optional[uuid.UUID] = Query(None),
    status: Optional[DeliveryStatus] = Query(None),
    params: PageParams = Depends(page_params),
    caller: Caller = Depends(WEBHOOKS_MANAGE),
) -> JSONResponse:
    """The delivery log, newest first; filter by subscription and status."""
    rows = subs.list_deliveries(
        _owner(caller),
        params.limit + 1,
        subscription_id=str(subscription_id) if subscription_id else None,
        status=status,
        after=_after(params),
    )
    body = page_of([_delivery_out(r) for r in rows], params.limit, _cursor_key)
    return masking.respond(body, caller)


@router.post(
    "/webhooks/deliveries/{delivery_id}/redrive",
    status_code=202,
    response_model=DeliveryV3,
    dependencies=[Depends(only_query(paged=False))],
)
def redrive_delivery(
    delivery_id: uuid.UUID, request: Request, caller: Caller = Depends(WEBHOOKS_MANAGE)
) -> JSONResponse:
    """Re-queue a dead or dropped delivery. The tenant re-check runs again. 202.

    Bounded: at most 3 redrives of one delivery, none of an event older than 7
    days (`409 WEBHOOK_STATE_INVALID`, `details.reason`), and 1 per
    subscription per 30-second window (`429 QUOTA_EXCEEDED` with `Retry-After`).
    """
    owner = _owner(caller)
    found = subs.get_delivery(owner, str(delivery_id))
    if found is None:
        raise _not_found()
    quotas.cap(
        request,
        f"webhook-redrive-30s:{caller.org_id}:{found['subscription_id']}",
        subs.REDRIVES_PER_SUBSCRIPTION,
        subs.REDRIVE_WINDOW_SECONDS,
    )
    try:
        row = subs.redrive(owner, str(delivery_id), engine.get_ports())
    except subs.RedriveLimit as refused:
        message = (
            "This delivery has been redriven the most times allowed."
            if refused.reason == subs.REDRIVE_LIMIT
            else "This delivery's event is too old to redrive."
        )
        raise ApiError(
            WEBHOOK_STATE_INVALID, message, status=409, details={"reason": refused.reason}
        ) from None
    except subs.NotRedrivable:
        raise ApiError(
            WEBHOOK_STATE_INVALID, "Only a dead or dropped delivery can be redriven.", status=409
        ) from None
    if row is None:
        raise _not_found()
    return masking.respond(_delivery_out(row), caller, status=202)
