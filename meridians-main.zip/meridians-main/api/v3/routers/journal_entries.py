"""`/api/v3/journal-entries` — the booked JE lines (phase-12-plan §3.2, T07).

Aggregated lines only (department x payer type x location): nothing on a
line names a person, so nothing is masked. Scope `journal-entries:read`,
narrowed to the processes the caller holds it FOR: those processes' batch
types are the only ones in the query (`access.BATCH_TYPE_FOR_PROCESS`).

Two ways in, one read (`pg_store.journal_line_page`):

* `GET /journal-entries?run_id&fiscal_year&period&location` — the current
  (booked, not rehearsed, not superseded) lines, or one run's.
* `GET /runs/{run_id}/journal-entries` — the same, addressed through the run.

A run of another org, of a process the caller may not read journal lines of,
or of nobody is `404 RUN_NOT_FOUND` either way.
"""

from __future__ import annotations

import uuid
from decimal import Decimal
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse

from src import api_scopes, process_runs
from src.api.v2 import errors as err
from src.api.v2 import pg_store
from src.api.v2.errors import ApiError

from .. import access, masking
from ..deps import PREFIX, Caller, require_scope
from ..models import JournalLineV3
from ..pagination import Paged, PageParams, bad_cursor, only_query, page_of, page_params

router = APIRouter(prefix=PREFIX, tags=["journal-entries"])

JE_READ = require_scope(api_scopes.JOURNAL_ENTRIES_READ)

CURSOR_KEYS = ("id",)


def _line_out(row: Dict[str, Any]) -> JournalLineV3:
    return JournalLineV3(
        je_type=row.get("je_type"),
        fiscal_year=row.get("fiscal_year"),
        period=row.get("period"),
        clinic_group=row.get("clinic_group"),
        line_number=row.get("line_number"),
        je_date=row.get("je_date"),
        subsidiary=row.get("subsidiary"),
        location=row.get("location"),
        department=row.get("department"),
        account=row.get("account"),
        debit=Decimal(str(row.get("debit") or 0)),
        credit=Decimal(str(row.get("credit") or 0)),
        description=row.get("description"),
    )


def _visible_run(caller: Caller, run_id: uuid.UUID) -> Dict[str, Any]:
    """The run, if this caller may read its journal lines; else 404."""
    row = process_runs.get_run(caller.org_id, str(run_id))
    if not row or not access.may_see(caller, api_scopes.JOURNAL_ENTRIES_READ, row.get("process")):
        raise ApiError(err.RUN_NOT_FOUND, "No such run.")
    return row


def _page(
    caller: Caller,
    params: PageParams,
    process_keys: List[str],
    batch_id: Optional[int] = None,
    fiscal_year: Optional[int] = None,
    period: Optional[int] = None,
    location: Optional[str] = None,
) -> JSONResponse:
    after = params.after(CURSOR_KEYS)
    if after is not None and not isinstance(after["id"], int):
        raise bad_cursor()
    batch_types = [
        access.BATCH_TYPE_FOR_PROCESS[key]
        for key in process_keys
        if key in access.BATCH_TYPE_FOR_PROCESS
    ]
    fetched: List[Dict[str, Any]] = []
    if batch_types:
        fetched = pg_store.journal_line_page(
            caller.org_id,
            batch_types,
            batch_id=batch_id,
            fiscal_year=fiscal_year,
            period=period,
            location=location,
            after_id=after["id"] if after else None,
            limit=params.limit + 1,
        )
    # The cursor is the line id; the line itself does not carry it.
    lines = [(row["id"], _line_out(row)) for row in fetched]
    body = page_of(lines, params.limit, lambda pair: {"id": pair[0]})
    body = Paged(data=[line for _id, line in body.data], page=body.page, meta=body.meta)
    return masking.respond(body, caller)


def _run_batch(caller: Caller, run_id: uuid.UUID) -> tuple:
    run = _visible_run(caller, run_id)
    return [run["process"]], run.get("batch_id")


@router.get(
    "/journal-entries",
    response_model=Paged[JournalLineV3],
    dependencies=[Depends(only_query("run_id", "fiscal_year", "period", "location"))],
)
def list_journal_entries(
    run_id: Optional[uuid.UUID] = Query(None),
    fiscal_year: Optional[int] = Query(None, ge=2000, le=2100),
    period: Optional[int] = Query(None, ge=1, le=12),
    location: Optional[str] = Query(None, min_length=1, max_length=200),
    params: PageParams = Depends(page_params),
    caller: Caller = Depends(JE_READ),
) -> JSONResponse:
    """Booked journal lines of the processes this caller may read, by line."""
    if run_id is not None:
        keys, batch_id = _run_batch(caller, run_id)
        if batch_id is None:
            keys = []  # a run that booked nothing has no lines
        return _page(caller, params, keys, batch_id, fiscal_year, period, location)
    keys = access.process_keys_for(caller, api_scopes.JOURNAL_ENTRIES_READ)
    return _page(caller, params, keys, None, fiscal_year, period, location)


@router.get(
    "/runs/{run_id}/journal-entries",
    response_model=Paged[JournalLineV3],
    dependencies=[Depends(only_query("location"))],
)
def run_journal_entries(
    run_id: uuid.UUID,
    location: Optional[str] = Query(None, min_length=1, max_length=200),
    params: PageParams = Depends(page_params),
    caller: Caller = Depends(JE_READ),
) -> JSONResponse:
    """One run's journal lines, if the run is this org's and readable."""
    keys, batch_id = _run_batch(caller, run_id)
    if batch_id is None:
        keys = []
    return _page(caller, params, keys, batch_id, location=location)
