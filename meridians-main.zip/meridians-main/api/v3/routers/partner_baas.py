"""`/api/v3/admin/partner-baas` — partner BAAs, record and revoke (phase-12-plan §3.2, §3.8 item 9).

HUMAN-ONLY and SUPERADMIN-ONLY. Every route declares `clients:manage` (human-
only, org `admin`), so a machine gets `403 SCOPE_INSUFFICIENT` before any row
is read; then `src.partner_baas` enters the org through `pg.with_superadmin`,
which refuses a non-superadmin (`403 PERMISSION_DENIED`, nothing read) and
writes an `audit.superadmin_access` row for everybody else. The plan's table
names the scope "superadmin"; no v3 caller is ever granted that scope (§3.4
derives none), so the superadmin check lives where `approve` keeps it — in
`src/`, against `public.superadmins`, on every request.

Revoking is immediate for the clients that name the BAA: `phi:read` is gone on
their next request (`app.api_client_for_token` recomputes `baa_active` each
time). Nothing is ever deleted.
"""

from __future__ import annotations

import datetime as _dt
import uuid
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import Field

from src import api_scopes, partner_baas

from .. import masking
from ..deps import PREFIX, Caller, require_scope
from ..masking import GENERAL
from ..pagination import Paged, PageParams, bad_cursor, only_query, page_of, page_params
from ..schemas import V3Model
from .admin_clients import ReasonV3, _actor, _run

router = APIRouter(prefix=PREFIX + "/admin/partner-baas", tags=["admin: partner baas"])

CLIENTS_MANAGE = require_scope(api_scopes.CLIENTS_MANAGE)

CURSOR_KEYS = ("approved_at", "id")


class PartnerBaaIn(V3Model):
    """`POST /admin/partner-baas`: record a signed agreement."""

    partner_name: str = Field(min_length=1, max_length=200)
    #: The evidence-store key of the signed PDF — never the document, never a URL.
    document_ref: str = Field(min_length=1, max_length=300)
    signed_on: _dt.date
    expires_on: Optional[_dt.date] = None


class PartnerBaaV3(V3Model):
    """One BAA as a superadmin sees it."""

    model_config = masking.model_config_for(GENERAL)

    id: str
    partner_name: str
    document_ref: str
    signed_on: _dt.date
    expires_on: Optional[_dt.date] = None
    approved_by: Optional[str] = None
    approved_at: Optional[_dt.datetime] = None
    revoked_at: Optional[_dt.datetime] = None
    revoked_by: Optional[str] = None
    revoked_reason: Optional[str] = None
    #: Not revoked and not expired: a client naming it may hold `phi:read`.
    in_force: bool
    #: How many clients (not revoked) name this agreement.
    client_count: int = 0


def _out(row: Dict[str, Any]) -> PartnerBaaV3:
    return PartnerBaaV3.model_validate({name: row.get(name) for name in PartnerBaaV3.model_fields})


def _after(params: PageParams) -> Optional[Dict[str, Any]]:
    after = params.after(CURSOR_KEYS)
    if after is not None:
        try:
            _dt.datetime.fromisoformat(str(after["approved_at"]))
            uuid.UUID(str(after["id"]))
        except ValueError as exc:
            raise bad_cursor() from exc
    return after


@router.get("", response_model=Paged[PartnerBaaV3], dependencies=[Depends(only_query())])
def list_partner_baas(
    params: PageParams = Depends(page_params), caller: Caller = Depends(CLIENTS_MANAGE)
) -> JSONResponse:
    """This org's BAAs, newest first. Superadmin only."""
    rows = _run(
        partner_baas.list_baas, _actor(caller), caller.org_id, params.limit + 1, _after(params)
    )
    body = page_of(
        [_out(row) for row in rows],
        params.limit,
        lambda b: {"approved_at": b.approved_at.isoformat() if b.approved_at else "", "id": b.id},
    )
    return masking.respond(body, caller)


@router.post(
    "",
    status_code=201,
    response_model=PartnerBaaV3,
    dependencies=[Depends(only_query(paged=False))],
)
def record_partner_baa(
    body: PartnerBaaIn, caller: Caller = Depends(CLIENTS_MANAGE)
) -> JSONResponse:
    """Record a signed BAA. Superadmin only; the caller is recorded as its approver."""
    row = _run(
        partner_baas.record_baa,
        _actor(caller),
        caller.org_id,
        body.partner_name,
        body.document_ref,
        body.signed_on,
        body.expires_on,
    )
    return masking.respond(_out(row), caller, status=201)


@router.post(
    "/{baa_id}/revoke",
    response_model=PartnerBaaV3,
    dependencies=[Depends(only_query(paged=False))],
)
def revoke_partner_baa(
    baa_id: str, body: ReasonV3, caller: Caller = Depends(CLIENTS_MANAGE)
) -> JSONResponse:
    """Revoke a BAA. Every client naming it loses `phi:read` on its next request."""
    row = _run(partner_baas.revoke_baa, _actor(caller), caller.org_id, baa_id, body.reason)
    return masking.respond(_out(row), caller)
