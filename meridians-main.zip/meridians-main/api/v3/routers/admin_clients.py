"""`/api/v3/admin/api-clients` — machine clients, managed by people (phase-12-plan §3.2, §3.6, T12).

HUMAN-ONLY. Every route declares `clients:manage`, which is in
`HUMAN_ONLY_SCOPES`: a machine caller never holds it (`Caller.allows`, the
`api_clients` CHECK), so a machine gets `403 SCOPE_INSUFFICIENT` before any
row is read. The org `admin` role grants it to a person (§3.4).

APPROVAL (and re-enabling) additionally needs a superadmin, checked inside
`src.api_clients` through `pg.with_superadmin`, which writes the
`audit.superadmin_access` row. The requester may approve their own client
only in development; in staging and production a second superadmin must
(`src.api_clients.self_approval_allowed`, critic Stage 1 M-6 — it names the
trigger to revisit).

SECRETS are returned exactly once, in the body of `approve` and
`rotate-secret`, with `Cache-Control: no-store`. The row keeps a fingerprint.

OBJECT-LEVEL: every id is read with `id = %s AND org_id = %s` under
`with_org` (RLS); another org's client, or a malformed id, is the same
`404 NOT_FOUND`. Every change appends an `audit.api_client_change` row in the
same transaction, and the request itself an `audit.api_request` row (T06).

Endpoints beyond the plan's list: `POST /{id}/rotate-secret/complete` (the
second half of the two-secret rotation ADR 0037 settled on) and
`POST /{id}/enable` (the way back from `disable`, including the idle job's).
"""

from __future__ import annotations

import datetime as _dt
import uuid
from typing import Any, Dict, List, Literal, Optional

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse
from pydantic import Field

from src import api_clients, api_scopes
from src import cognito_client_admin as cca
from src.api.v2 import errors as err
from src.api.v2.errors import ApiError

from .. import masking
from ..deps import PREFIX, Caller, require_scope
from ..masking import GENERAL, INTERNAL, classified
from ..pagination import Paged, PageParams, bad_cursor, only_query, page_of, page_params
from ..schemas import V3Model

router = APIRouter(prefix=PREFIX + "/admin/api-clients", tags=["admin: api clients"])

CLIENTS_MANAGE = require_scope(api_scopes.CLIENTS_MANAGE)

#: `app.state` attribute holding the `CognitoClientAdmin`. `create_app` sets
#: the boto3 adapter; tests set `FakeCognitoClientAdmin`. None → 503.
IDP_STATE = "cognito_client_admin"

#: v3 codes this router adds (kept out of the v2 catalogue, like
#: `SCOPE_INSUFFICIENT`).
API_CLIENT_STATE_INVALID = "API_CLIENT_STATE_INVALID"
IDENTITY_PROVIDER_UNAVAILABLE = "IDENTITY_PROVIDER_UNAVAILABLE"

CURSOR_KEYS = ("created_at", "id")


# ------------------------------------------------------------------ models
class ApiClientRequestV3(V3Model):
    """`POST /admin/api-clients`: ask for a client (status `pending_approval`)."""

    name: str = Field(min_length=3, max_length=80)
    kind: Literal["internal", "partner", "sandbox"]
    scopes: List[str] = Field(default_factory=list, max_length=20)
    processes: List[str] = Field(default_factory=list, max_length=20)
    #: None = any address. `[]` = no address at all.
    ip_allowlist: Optional[List[str]] = Field(default=None, max_length=20)
    mtls_subject: Optional[str] = Field(default=None, min_length=1, max_length=512)
    partner_baa_id: Optional[uuid.UUID] = None


class ApiClientPatchV3(V3Model):
    """`PATCH /admin/api-clients/{id}`: only the fields given change."""

    name: Optional[str] = Field(default=None, min_length=3, max_length=80)
    scopes: Optional[List[str]] = Field(default=None, max_length=20)
    processes: Optional[List[str]] = Field(default=None, max_length=20)
    ip_allowlist: Optional[List[str]] = Field(default=None, max_length=20)
    mtls_subject: Optional[str] = Field(default=None, min_length=1, max_length=512)
    partner_baa_id: Optional[uuid.UUID] = None
    reason: Optional[str] = Field(default=None, max_length=api_clients.REASON_MAX)


class ReasonV3(V3Model):
    """A state change that must say why (approve, revoke, disable, enable)."""

    reason: str = Field(min_length=3, max_length=api_clients.REASON_MAX)


class OptionalReasonV3(V3Model):
    reason: Optional[str] = Field(default=None, max_length=api_clients.REASON_MAX)


class ApiClientV3(V3Model):
    """One machine client as an admin sees it. Never a secret."""

    model_config = masking.model_config_for(GENERAL)

    id: str
    name: str
    kind: str
    status: str
    cognito_client_id: Optional[str] = None
    secret_fingerprint: Optional[str] = None
    scopes: List[str]
    processes: List[str]
    ip_allowlist: Optional[List[str]] = None
    mtls_subject: Optional[str] = None
    partner_baa_id: Optional[str] = None
    requested_by: Optional[str] = None
    approved_by: Optional[str] = None
    approved_at: Optional[_dt.datetime] = None
    self_approved: bool = False
    disabled_at: Optional[_dt.datetime] = None
    disabled_reason: Optional[str] = None
    last_used_at: Optional[_dt.datetime] = None
    #: A second secret was added and the old one is still live: the admin
    #: screen offers "Finish rotation" only while this is true (revision 0016).
    rotation_in_progress: bool = False
    rotation_started_at: Optional[_dt.datetime] = None
    created_at: Optional[_dt.datetime] = None


class ApiClientSecretV3(V3Model):
    """The answer to approve / rotate-secret: the client and its secret, ONCE."""

    client: ApiClientV3 = classified(GENERAL)
    #: Shown once and never again: only its fingerprint is kept. `internal`
    #: so that even a (never-possible) machine caller would get null.
    secret: Optional[str] = classified(INTERNAL, None)


class UsageDayV3(V3Model):
    """One UTC day of a client's calls (from `audit.api_request`)."""

    model_config = masking.model_config_for(GENERAL)

    day: _dt.date
    requests: int
    #: Calls that authenticated as the client and were answered 4xx or 5xx.
    errors: int


class UsageIpV3(V3Model):
    """An address the client called from inside the window."""

    model_config = masking.model_config_for(GENERAL)

    ip: str
    last_seen: _dt.datetime
    requests: int


class ApiClientUsageV3(V3Model):
    model_config = masking.model_config_for(GENERAL)

    id: str
    status: str
    last_used_at: Optional[_dt.datetime] = None
    last_used_ip: Optional[str] = None
    #: When the idle job will disable it if it stays unused (active clients only).
    idle_disable_after: Optional[_dt.datetime] = None
    #: The window below, in days (1-90, default 30), ending today (UTC).
    window_days: int = api_clients.USAGE_DEFAULT_DAYS
    requests: int = 0
    errors: int = 0
    #: errors / requests over the window; null when there were no requests.
    error_rate: Optional[float] = None
    #: One entry per day of the window, oldest first, zeros included.
    daily: List[UsageDayV3] = Field(default_factory=list)
    #: Up to five addresses, most recent first.
    recent_ips: List[UsageIpV3] = Field(default_factory=list)


# ----------------------------------------------------------------- helpers
def _out(row: Dict[str, Any]) -> ApiClientV3:
    allow = row.get("ip_allowlist")
    return ApiClientV3(
        id=str(row["id"]),
        name=row["name"],
        kind=row["kind"],
        status=row["status"],
        cognito_client_id=row.get("cognito_client_id"),
        secret_fingerprint=row.get("secret_fingerprint"),
        scopes=sorted(row.get("granted_scopes") or []),
        processes=sorted(row.get("allowed_processes") or []),
        ip_allowlist=list(allow) if allow is not None else None,
        mtls_subject=row.get("mtls_subject"),
        partner_baa_id=row.get("partner_baa_id"),
        requested_by=row.get("requested_by"),
        approved_by=row.get("approved_by"),
        approved_at=row.get("approved_at"),
        self_approved=bool(row.get("approved_by"))
        and row.get("approved_by") == row.get("requested_by"),
        disabled_at=row.get("disabled_at"),
        disabled_reason=row.get("disabled_reason"),
        last_used_at=row.get("last_used_at"),
        rotation_in_progress=row.get("rotation_started_at") is not None,
        rotation_started_at=row.get("rotation_started_at"),
        created_at=row.get("created_at"),
    )


def _idp(request: Request) -> cca.CognitoClientAdmin:
    found = getattr(request.app.state, IDP_STATE, None)
    if found is None:
        raise ApiError(
            IDENTITY_PROVIDER_UNAVAILABLE,
            "Client management is not available right now.",
            status=503,
            retryable=True,
        )
    return found


def _actor(caller: Caller) -> str:
    # `clients:manage` is human-only, so this is always a person; said again
    # here so a future scope change cannot hand a machine this path.
    if caller.is_machine or not caller.user_id:
        raise ApiError(
            "SCOPE_INSUFFICIENT",
            "You do not have access to this.",
            status=403,
            details={"required_scope": api_scopes.CLIENTS_MANAGE},
        )
    return str(caller.user_id)


def _run(action, *args: Any, **kwargs: Any) -> Any:
    """Call a lifecycle function; turn its refusals into the §4.1 envelope."""
    try:
        return action(*args, **kwargs)
    except api_clients.ClientNotFound:
        raise ApiError(err.NOT_FOUND, "Not found.") from None
    except api_clients.GrantInvalid as refused:
        raise ApiError(
            err.VALIDATION_ERROR,
            "That grant is not allowed for a machine client.",
            field_errors=refused.field_errors,
        ) from None
    except api_clients.StateConflict as refused:
        raise ApiError(API_CLIENT_STATE_INVALID, str(refused), status=409) from None
    except api_clients.ApproverRefused as refused:
        raise ApiError(err.PERMISSION_DENIED, str(refused), status=403) from None
    except api_clients.IdentityProviderFailed:
        raise ApiError(
            IDENTITY_PROVIDER_UNAVAILABLE,
            "The identity provider did not accept the change; nothing was changed.",
            status=503,
            retryable=True,
        ) from None


def _no_store(response: JSONResponse) -> JSONResponse:
    response.headers["Cache-Control"] = "no-store"
    return response


def _with_secret(row: Dict[str, Any], secret: str, caller: Caller) -> JSONResponse:
    body = ApiClientSecretV3(client=_out(row), secret=secret)
    return _no_store(masking.respond(body, caller))


def _after(params: PageParams) -> Optional[Dict[str, Any]]:
    after = params.after(CURSOR_KEYS)
    if after is not None:
        try:
            _dt.datetime.fromisoformat(str(after["created_at"]))
            uuid.UUID(str(after["id"]))
        except ValueError as exc:
            raise bad_cursor() from exc
    return after


# ------------------------------------------------------------------ routes
@router.get("", response_model=Paged[ApiClientV3], dependencies=[Depends(only_query())])
def list_api_clients(
    params: PageParams = Depends(page_params), caller: Caller = Depends(CLIENTS_MANAGE)
) -> JSONResponse:
    """This org's machine clients, newest first."""
    _actor(caller)
    rows = _run(api_clients.list_clients, caller.org_id, params.limit + 1, _after(params))
    body = page_of(
        [_out(row) for row in rows],
        params.limit,
        lambda c: {"created_at": c.created_at.isoformat() if c.created_at else "", "id": c.id},
    )
    return masking.respond(body, caller)


@router.post(
    "",
    status_code=201,
    response_model=ApiClientV3,
    dependencies=[Depends(only_query(paged=False))],
)
def request_api_client(
    body: ApiClientRequestV3, caller: Caller = Depends(CLIENTS_MANAGE)
) -> JSONResponse:
    """Ask for a machine client. It does nothing until a superadmin approves it."""
    grant = api_clients.Grant(
        name=body.name,
        scopes=tuple(body.scopes),
        processes=tuple(body.processes),
        ip_allowlist=tuple(body.ip_allowlist) if body.ip_allowlist is not None else None,
        mtls_subject=body.mtls_subject,
        partner_baa_id=str(body.partner_baa_id) if body.partner_baa_id else None,
    )
    row = _run(api_clients.request_client, caller.org_id, _actor(caller), body.kind, grant)
    return masking.respond(_out(row), caller, status=201)


@router.get(
    "/{client_id}",
    response_model=ApiClientV3,
    dependencies=[Depends(only_query(paged=False))],
)
def get_api_client(client_id: str, caller: Caller = Depends(CLIENTS_MANAGE)) -> JSONResponse:
    _actor(caller)
    return masking.respond(_out(_run(api_clients.get_client, caller.org_id, client_id)), caller)


@router.patch(
    "/{client_id}",
    response_model=ApiClientV3,
    dependencies=[Depends(only_query(paged=False))],
)
def patch_api_client(
    client_id: str,
    body: ApiClientPatchV3,
    request: Request,
    caller: Caller = Depends(CLIENTS_MANAGE),
) -> JSONResponse:
    """Change what a client may do. A narrowing bites on its next request."""
    given = body.model_fields_set - {"reason"}
    changes: Dict[str, Any] = {}
    for name in given:
        value = getattr(body, name)
        if name in ("name", "scopes", "processes") and value is None:
            raise ApiError(
                err.VALIDATION_ERROR,
                f"{name} cannot be null.",
                field_errors={name: ["cannot be null"]},
            )
        if name == "partner_baa_id":
            value = str(value) if value is not None else None
        changes[name] = value
    row = _run(
        api_clients.update_grant,
        caller.org_id,
        client_id,
        _actor(caller),
        changes,
        _idp(request),
        reason=body.reason,
    )
    return masking.respond(_out(row), caller)


@router.post(
    "/{client_id}/approve",
    response_model=ApiClientSecretV3,
    dependencies=[Depends(only_query(paged=False))],
)
def approve_api_client(
    client_id: str, body: ReasonV3, request: Request, caller: Caller = Depends(CLIENTS_MANAGE)
) -> JSONResponse:
    """Superadmin only. Creates the Cognito app client; the secret is in this answer ONCE."""
    row, secret = _run(
        api_clients.approve, caller.org_id, client_id, _actor(caller), body.reason, _idp(request)
    )
    return _with_secret(row, secret, caller)


@router.post(
    "/{client_id}/rotate-secret",
    response_model=ApiClientSecretV3,
    dependencies=[Depends(only_query(paged=False))],
)
def rotate_api_client_secret(
    client_id: str,
    request: Request,
    body: Optional[OptionalReasonV3] = None,
    caller: Caller = Depends(CLIENTS_MANAGE),
) -> JSONResponse:
    """Add a second secret; both work until `rotate-secret/complete`. New secret ONCE."""
    row, secret = _run(
        api_clients.rotate_secret,
        caller.org_id,
        client_id,
        _actor(caller),
        _idp(request),
        reason=body.reason if body else None,
    )
    return _with_secret(row, secret, caller)


@router.post(
    "/{client_id}/rotate-secret/complete",
    response_model=ApiClientV3,
    dependencies=[Depends(only_query(paged=False))],
)
def complete_api_client_rotation(
    client_id: str,
    request: Request,
    body: Optional[OptionalReasonV3] = None,
    caller: Caller = Depends(CLIENTS_MANAGE),
) -> JSONResponse:
    """The partner has switched: delete the old secret."""
    row = _run(
        api_clients.complete_rotation,
        caller.org_id,
        client_id,
        _actor(caller),
        _idp(request),
        reason=body.reason if body else None,
    )
    return masking.respond(_out(row), caller)


@router.post(
    "/{client_id}/revoke",
    response_model=ApiClientV3,
    dependencies=[Depends(only_query(paged=False))],
)
def revoke_api_client(
    client_id: str, body: ReasonV3, request: Request, caller: Caller = Depends(CLIENTS_MANAGE)
) -> JSONResponse:
    """Permanent. Every token of this client fails from its next request."""
    row = _run(
        api_clients.revoke, caller.org_id, client_id, _actor(caller), body.reason, _idp(request)
    )
    return masking.respond(_out(row), caller)


@router.post(
    "/{client_id}/disable",
    response_model=ApiClientV3,
    dependencies=[Depends(only_query(paged=False))],
)
def disable_api_client(
    client_id: str, body: ReasonV3, caller: Caller = Depends(CLIENTS_MANAGE)
) -> JSONResponse:
    """Switch off, reversibly. Tokens fail from the next request."""
    row = _run(api_clients.disable, caller.org_id, client_id, _actor(caller), body.reason)
    return masking.respond(_out(row), caller)


@router.post(
    "/{client_id}/enable",
    response_model=ApiClientV3,
    dependencies=[Depends(only_query(paged=False))],
)
def enable_api_client(
    client_id: str, body: ReasonV3, caller: Caller = Depends(CLIENTS_MANAGE)
) -> JSONResponse:
    """Superadmin only (a re-approval). Tokens minted before the disable stay dead."""
    row = _run(api_clients.enable, caller.org_id, client_id, _actor(caller), body.reason)
    return masking.respond(_out(row), caller)


def usage_window(
    days: int = Query(api_clients.USAGE_DEFAULT_DAYS, ge=1, le=api_clients.USAGE_MAX_DAYS),
) -> int:
    """The usage window in days: 1 to 90 (the audit functions answer nothing wider)."""
    return days


@router.get(
    "/{client_id}/usage",
    response_model=ApiClientUsageV3,
    dependencies=[Depends(only_query("days", paged=False))],
)
def api_client_usage(
    client_id: str,
    days: int = Depends(usage_window),
    caller: Caller = Depends(CLIENTS_MANAGE),
) -> JSONResponse:
    """Last use, requests and errors per day, and recent addresses, over `days`.

    Counted from `audit.api_request` (T06) through revision 0016's aggregate
    functions: one client, this org, at most 90 days, never a raw audit row.
    """
    _actor(caller)
    used = _run(api_clients.usage, caller.org_id, client_id, days)
    row = used["client"]
    daily = [UsageDayV3(**day) for day in used["daily"]]
    total = sum(day.requests for day in daily)
    failed = sum(day.errors for day in daily)
    idle_after = None
    if row["status"] == "active":
        since = row.get("last_used_at") or row.get("approved_at") or row.get("created_at")
        if since is not None:
            idle_after = since + _dt.timedelta(days=api_clients.IDLE_DISABLE_DAYS)
    body = ApiClientUsageV3(
        id=str(row["id"]),
        status=row["status"],
        last_used_at=row.get("last_used_at"),
        last_used_ip=row.get("last_used_ip"),
        idle_disable_after=idle_after,
        window_days=used["days"],
        requests=total,
        errors=failed,
        error_rate=round(failed / total, 4) if total else None,
        daily=daily,
        recent_ips=[UsageIpV3(**ip) for ip in used["recent_ips"]],
    )
    return masking.respond(body, caller)
