"""`/api/v3/employees` and `/api/v3/allocations` — the payroll rosters (phase-12-plan §3.2).

Two rosters, one resource, chosen by the required `entity`:

* `mx` — `config_mx_employees`, through `src/api/v2/mx_employees.py` (the
  service the v2 roster screen uses: active rows, keyed by payroll code).
* `us` — `config_employees`, through the org-scoped `Database` handle
  (`routes.org_db_for`) and its `get_config_employees`.

Names and positions are `pii`: returned to a caller holding
`employees:read`, never logged. No compensation field exists on either
roster, so none can be exposed.

`/allocations` is `employee_clinic_allocations` — how each employee's wages
split across clinics — through `Database.get_all_employee_allocations`.
`employee_id` filters by the ADP file number (the roster's payroll id). The
table has no period, so a `period` filter would be a lie: it is refused as an
unknown parameter.
"""

from __future__ import annotations

import hashlib
import logging
from typing import Any, Dict, List, Optional, Tuple

from fastapi import APIRouter, Depends, Path, Query, Request, Response
from fastapi.responses import JSONResponse

# The v2 routers' one definition of "the decoded body, or None".
from api.routers.config import _raw_body as json_body
from src import allocation_rules, api_scopes
from src.api.v2 import errors as err
from src.api.v2 import mx_employees
from src.api.v2.errors import ApiError
from src.api.v2.routes import body_of, org_db_for

from .. import masking
from ..deps import PREFIX, Caller, require_scope
from ..models import (
    AllocationIn,
    AllocationShareV3,
    AllocationV3,
    EmployeeV3,
    ImportedV3,
    UsEmployeeIn,
)
from ..pagination import Paged, PageParams, only_query, page_in_memory, page_params

#: Never a name, a position or a code in a log line: types and counts only.
logger = logging.getLogger(__name__)

router = APIRouter(prefix=PREFIX, tags=["employees"])

EMPLOYEES_READ = require_scope(api_scopes.EMPLOYEES_READ)
ALLOCATIONS_READ = require_scope(api_scopes.ALLOCATIONS_READ)

ENTITIES = ("mx", "us")
ENTITY_PATTERN = "^(mx|us)$"


# ---------------------------------------------------------------- employees
def mx_out(row: Any) -> EmployeeV3:
    return EmployeeV3(
        entity="mx",
        employee_id=row.employee_id,
        name=row.name,
        position=row.position,
        department=row.department,
        department_netsuite=row.department_netsuite,
        report=row.report,
        active=row.active,
    )


def us_out(row: Dict[str, Any]) -> EmployeeV3:
    return EmployeeV3(
        entity="us",
        employee_id=str(row.get("employee_id") or ""),
        name=row.get("name"),
        department=row.get("department"),
        primary_location=row.get("primary_location"),
        # `config_employees.active` is an integer flag (revision 0002).
        active=bool(row.get("active")),
    )


def roster(caller: Caller, entity: str) -> List[EmployeeV3]:
    """The org's roster for `entity`, as v3 rows."""
    if entity == "mx":
        return [mx_out(row) for row in mx_employees.employees(caller.org_id, caller.user_id).data]
    db = org_db_for(caller.org_id, caller.user_id)
    return [us_out(row) for row in db.get_config_employees(active_only=False)]


@router.get(
    "/employees",
    response_model=Paged[EmployeeV3],
    dependencies=[Depends(only_query("entity"))],
)
def list_employees(
    entity: str = Query(..., pattern=ENTITY_PATTERN),
    params: PageParams = Depends(page_params),
    caller: Caller = Depends(EMPLOYEES_READ),
) -> JSONResponse:
    """One roster of this org, by payroll code."""
    rows = roster(caller, entity)
    page = page_in_memory(rows, lambda row: (row.employee_id,), ("employee_id",), params)
    return masking.respond(page, caller)


# -------------------------------------------------------------- allocations
def allocation_out(key: str, data: Dict[str, Any]) -> AllocationV3:
    return AllocationV3(
        employee=key,
        file_number=data.get("file_number") or None,
        entity=data.get("entity") or None,
        job_category=data.get("job_category") or None,
        subsidiary=data.get("subsidiary") or None,
        pay_type=data.get("pay_type") or None,
        allocations=[
            AllocationShareV3(
                location_code=str(share["location_code"]),
                percentage=float(share["percentage"]),
            )
            for share in data.get("allocations") or []
        ],
    )


def allocations_of(caller: Caller) -> List[AllocationV3]:
    db = org_db_for(caller.org_id, caller.user_id)
    return [allocation_out(key, data) for key, data in db.get_all_employee_allocations().items()]


def _allocation_key(row: AllocationV3) -> Tuple[str]:
    """A digest of the employee key, never the name: the cursor travels in a URL.

    The table's natural key IS the person's name, and a cursor is a query
    parameter every proxy logs (§3.1 rule 5). Ordering by a one-way digest
    keeps the page stable without the name leaving in a URL.
    """
    return (hashlib.sha256(row.employee.encode("utf-8")).hexdigest(),)


@router.get(
    "/allocations",
    response_model=Paged[AllocationV3],
    dependencies=[Depends(only_query("employee_id"))],
)
def list_allocations(
    employee_id: Optional[str] = Query(None, min_length=1, max_length=50),
    params: PageParams = Depends(page_params),
    caller: Caller = Depends(ALLOCATIONS_READ),
) -> JSONResponse:
    """This org's clinic allocations, one row per employee."""
    rows = allocations_of(caller)
    if employee_id is not None:
        rows = [row for row in rows if (row.file_number or "") == employee_id.strip()]
    page = page_in_memory(rows, _allocation_key, ("key",), params)
    return masking.respond(page, caller)


# ================================================================== writing
# T08. The MX roster writes are `src/api/v2/mx_employees.py`, called as-is.
# The US roster and the allocations have no v2 service; they are the
# org-scoped `Database` methods the Jinja screens call, with the allocation
# rules from `src/allocation_rules.py` (shared with `web_app`).

EMPLOYEES_WRITE = require_scope(api_scopes.EMPLOYEES_WRITE)
ALLOCATIONS_WRITE = require_scope(api_scopes.ALLOCATIONS_WRITE)

EMPLOYEE_ID = Path(..., min_length=1, max_length=50)


def _not_found() -> ApiError:
    return ApiError(err.NOT_FOUND, "No such employee in this roster.")


def _us_row(db: Any, code: str) -> Optional[Dict[str, Any]]:
    """This org's US roster row for `code`, active or not, or None."""
    for row in db.get_config_employees(active_only=False):
        if str(row.get("employee_id") or "") == code:
            return row
    return None


def _code(employee_id: str) -> str:
    code = employee_id.strip()
    if not code:
        raise ApiError(
            err.VALIDATION_ERROR,
            "An employee code is required.",
            field_errors={"employee_id": ["required"]},
        )
    return code


def _save_us(caller: Caller, code: str, raw: Any) -> EmployeeV3:
    body = body_of(UsEmployeeIn, raw)
    db = org_db_for(caller.org_id, caller.user_id)
    try:
        db.upsert_config_employee(
            code,
            body.name.strip(),
            body.primary_location.strip(),
            (body.department or "").strip() or None,
            active=body.active,
            updated_by=caller.user_id,
        )
    except Exception as exc:
        # Type only: a database error's text carries the row (names).
        logger.error("us employee upsert failed: %s", type(exc).__name__)
        raise ApiError(
            err.PERSISTENCE_UNAVAILABLE, "The employee could not be saved. Nothing was changed."
        ) from exc
    stored = _us_row(db, code)
    if stored is None:  # pragma: no cover - the upsert just wrote it
        raise _not_found()
    return us_out(stored)


def _deactivate_us(caller: Caller, code: str) -> None:
    db = org_db_for(caller.org_id, caller.user_id)
    row = _us_row(db, code)
    if row is None:
        # Another org's code and no code at all are the same answer (§8).
        raise _not_found()
    try:
        db.upsert_config_employee(
            code,
            row.get("name") or "",
            row.get("primary_location") or "",
            row.get("department"),
            active=False,
            updated_by=caller.user_id,
        )
    except Exception as exc:
        logger.error("us employee deactivate failed: %s", type(exc).__name__)
        raise ApiError(
            err.PERSISTENCE_UNAVAILABLE,
            "The employee could not be deactivated. Nothing was changed.",
        ) from exc


@router.post(
    "/employees/import",
    response_model=ImportedV3,
    dependencies=[Depends(only_query("entity", paged=False))],
)
def import_employees(
    entity: str = Query(..., pattern=ENTITY_PATTERN),
    caller: Caller = Depends(EMPLOYEES_WRITE),
) -> JSONResponse:
    """One-time import of the MX roster file (`mx_employees.seed`)."""
    if entity != "mx":
        raise ApiError(
            err.VALIDATION_ERROR,
            "Only the MX roster has an import.",
            field_errors={"entity": ["no import for this roster"]},
        )
    result = mx_employees.seed(caller.org_id, caller.user_id)
    return masking.respond(ImportedV3(imported=result.imported), caller)


@router.put(
    "/employees/{employee_id}",
    response_model=EmployeeV3,
    dependencies=[Depends(only_query("entity", paged=False))],
)
async def save_employee(
    request: Request,
    employee_id: str = EMPLOYEE_ID,
    entity: str = Query(..., pattern=ENTITY_PATTERN),
    caller: Caller = Depends(EMPLOYEES_WRITE),
) -> JSONResponse:
    """Create or replace one row of this org's roster. 200 with the row as stored.

    Keyed on (this org, the code): a code another org also uses is a
    different row, so a PUT can only ever write the caller's own.
    """
    raw = await json_body(request)
    if entity == "mx":
        saved = mx_out(mx_employees.save(employee_id, raw, caller.org_id, caller.user_id))
    else:
        saved = _save_us(caller, _code(employee_id), raw)
    return masking.respond(saved, caller)


@router.delete(
    "/employees/{employee_id}",
    status_code=204,
    response_model=None,
    dependencies=[Depends(only_query("entity", paged=False))],
)
def deactivate_employee(
    employee_id: str = EMPLOYEE_ID,
    entity: str = Query(..., pattern=ENTITY_PATTERN),
    caller: Caller = Depends(EMPLOYEES_WRITE),
) -> Response:
    """Take one employee off this org's active roster. Nothing is removed. 204."""
    if entity == "mx":
        mx_employees.deactivate(employee_id, caller.org_id, caller.user_id)
    else:
        _deactivate_us(caller, _code(employee_id))
    return Response(status_code=204)


@router.put(
    "/allocations",
    response_model=AllocationV3,
    dependencies=[Depends(only_query(paged=False))],
)
async def save_allocation(
    request: Request, caller: Caller = Depends(ALLOCATIONS_WRITE)
) -> JSONResponse:
    """Replace one employee's whole clinic split, in one transaction. 200.

    The employee is in the body, not the URL (a name is PII). The shares must
    total 100% (`allocation_rules`); the delete-and-insert is
    `Database.save_employee_allocations`, which scopes both by this org.
    """
    body = body_of(AllocationIn, await json_body(request))
    key = allocation_rules.employee_key(body.employee_name)
    if not key:
        raise ApiError(
            err.VALIDATION_ERROR,
            "An employee name is required.",
            field_errors={"employee_name": ["required"]},
        )
    shares = [share.model_dump() for share in body.allocations]
    problem = allocation_rules.allocation_total_error(shares)
    if problem:
        raise ApiError(err.VALIDATION_ERROR, problem, field_errors={"allocations": [problem]})

    db = org_db_for(caller.org_id, caller.user_id)
    try:
        db.save_employee_allocations(
            key,
            {
                "allocations": shares,
                "entity": body.entity or "",
                "job_category": body.job_category or "",
                "subsidiary": body.subsidiary or "",
                "pay_type": body.pay_type or "",
                "file_number": body.file_number or "",
            },
        )
    except Exception as exc:
        logger.error("allocation save failed: %s", type(exc).__name__)
        raise ApiError(
            err.PERSISTENCE_UNAVAILABLE, "The allocation could not be saved. Nothing was changed."
        ) from exc
    stored = db.get_all_employee_allocations().get(key)
    if stored is None:  # pragma: no cover - the save just wrote it
        raise ApiError(err.NOT_FOUND, "No such allocation.")
    return masking.respond(allocation_out(key, stored), caller)
