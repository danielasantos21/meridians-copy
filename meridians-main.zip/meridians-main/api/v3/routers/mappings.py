"""`/api/v3/mappings/{kind}` — the org's mapping collections (phase-12-plan §3.2).

The work is `src/api/v2`'s, called as-is: `routes.config_collection` and the
`config_routes` readers do the org-scoped read (`org_db_for` → the org's
`DatabasePostgres`, `org_id = %s` in every statement, RLS under it). This
router adds only what v3 adds — the scope, the page, the classified model.

Kinds: providers, locations, payers, departments, clinic-groups,
qb-provider-codes, and the other QuickBooks mapping tables — qb-accounts,
qb-departments, qb-clinics, qb-other-codes, qb-payer-labels, qb-locations
(`config_routes.QB_MAP_KINDS`; what a QuickBooks revenue or payroll run is
coded from, which on Postgres a run refuses to do without — critic H-1). Any
other kind is `404 NOT_FOUND`.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Tuple, Type, Union

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# The v2 routers' one definition of "the decoded body, or None": a body that
# is not JSON falls out as the same 422 a missing field gets.
from api.routers.config import _raw_body as json_body
from src import api_scopes
from src.api.v2 import config_routes, routes
from src.api.v2 import errors as err
from src.api.v2.errors import ApiError

from .. import masking
from ..deps import PREFIX, Caller, require_scope
from ..models import (
    ClinicGroupV3,
    DepartmentV3,
    LocationMappingV3,
    PayerMappingV3,
    ProviderMappingV3,
    QbAccountV3,
    QbClinicV3,
    QbDepartmentV3,
    QbLocationV3,
    QbOtherCodeV3,
    QbPayerLabelV3,
    QbProviderCodeV3,
)
from ..pagination import Paged, PageParams, only_query, page_in_memory, page_params

router = APIRouter(prefix=PREFIX, tags=["mappings"])

MAPPINGS_READ = require_scope(api_scopes.MAPPINGS_READ)


def _reader(kind: str) -> Callable[[str, Any], Any]:
    return lambda org_id, user_id: routes.config_collection(kind, org_id, user_id)


#: URL kind -> (v3 model, the v2 read that answers it).
KINDS: Dict[str, Tuple[Type[BaseModel], Callable[[str, Any], Any]]] = {
    "providers": (ProviderMappingV3, _reader("providers")),
    "locations": (LocationMappingV3, _reader("locations")),
    "payers": (PayerMappingV3, _reader("payers")),
    "departments": (DepartmentV3, _reader("departments")),
    "qb-provider-codes": (QbProviderCodeV3, config_routes.qb_provider_codes),
    "clinic-groups": (ClinicGroupV3, config_routes.clinic_groups),
    **{
        kind: (model, config_routes.QB_MAP_READERS[kind])
        for kind, model in (
            ("qb-accounts", QbAccountV3),
            ("qb-departments", QbDepartmentV3),
            ("qb-clinics", QbClinicV3),
            ("qb-other-codes", QbOtherCodeV3),
            ("qb-payer-labels", QbPayerLabelV3),
            ("qb-locations", QbLocationV3),
        )
    },
}

CURSOR_KEYS = ("id",)

#: What one item of any collection may be — the response model's `data`.
MappingV3 = Union[
    ProviderMappingV3,
    LocationMappingV3,
    PayerMappingV3,
    DepartmentV3,
    QbProviderCodeV3,
    ClinicGroupV3,
    QbAccountV3,
    QbDepartmentV3,
    QbClinicV3,
    QbOtherCodeV3,
    QbPayerLabelV3,
    QbLocationV3,
]


def kind_or_404(kind: str) -> Tuple[Type[BaseModel], Callable[[str, Any], Any]]:
    found = KINDS.get(kind)
    if found is None:
        raise ApiError(err.NOT_FOUND, "Not found.")
    return found


def as_v3(model: Type[BaseModel], row: BaseModel) -> BaseModel:
    """A v2 row model as its v3 twin: same fields, plus the classification."""
    return model.model_validate(row.model_dump())


def _sort_key(row: Any) -> Tuple[str]:
    # Integer ids sort as numbers; the zero-pad keeps the cursor a string.
    return (str(getattr(row, "id", "") or "").zfill(20),)


@router.get(
    "/mappings/{kind}",
    response_model=Paged[MappingV3],
    dependencies=[Depends(only_query())],
)
def list_mappings(
    kind: str,
    params: PageParams = Depends(page_params),
    caller: Caller = Depends(MAPPINGS_READ),
) -> JSONResponse:
    """One mapping collection of this org, by id."""
    model, read = kind_or_404(kind)
    collection = read(caller.org_id, caller.user_id)
    rows = [as_v3(model, row) for row in collection.data]
    return masking.respond(page_in_memory(rows, _sort_key, CURSOR_KEYS, params), caller)


# ------------------------------------------------------------------ writing
# T08. Each one is the v2 service that already serves the React settings
# screen: the same strict (`extra="forbid"`) request models, the same
# case-insensitive collision rule (409 `MAPPING_EXISTS`), the same org-scoped
# `_find` that makes another org's id a 404. v3 adds the scope and the model.

MAPPINGS_WRITE = require_scope(api_scopes.MAPPINGS_WRITE)

#: URL kind -> the v2 create that serves it.
CREATORS: Dict[str, Callable[..., Any]] = {
    **routes.CONFIG_CREATORS,
    "qb-provider-codes": config_routes.add_qb_provider_code,
    "clinic-groups": config_routes.add_clinic_group,
    **config_routes.QB_MAP_CREATORS,
}

#: URL kind -> the `config_routes.COLLECTIONS` name its edits and deletes use.
#: Clinic groups have no edit or delete service, so their rows are not
#: addressable one by one: `/mappings/clinic-groups/{id}` is a 404.
EDITABLE: Dict[str, str] = {
    "providers": "providers",
    "locations": "locations",
    "payers": "payers",
    "departments": "departments",
    "qb-provider-codes": "qb_provider_codes",
    **config_routes.QB_MAP_KINDS,
}


def _editable_or_404(kind: str) -> str:
    kind_or_404(kind)
    name = EDITABLE.get(kind)
    if name is None:
        raise ApiError(err.NOT_FOUND, "Not found.")
    return name


@router.post(
    "/mappings/{kind}",
    status_code=201,
    response_model=MappingV3,
    dependencies=[Depends(only_query(paged=False))],
)
async def create_mapping(
    kind: str, request: Request, caller: Caller = Depends(MAPPINGS_WRITE)
) -> JSONResponse:
    """Add one mapping to this org's collection. 201 with the row."""
    model, _read = kind_or_404(kind)
    created = CREATORS[kind](await json_body(request), caller.org_id, caller.user_id)
    return masking.respond(as_v3(model, created), caller, status=201)


@router.patch(
    "/mappings/{kind}/{row_id}",
    response_model=MappingV3,
    dependencies=[Depends(only_query(paged=False))],
)
async def update_mapping(
    kind: str, row_id: int, request: Request, caller: Caller = Depends(MAPPINGS_WRITE)
) -> JSONResponse:
    """Edit one of this org's mappings. Another org's id, or none, is 404."""
    name = _editable_or_404(kind)
    model, _read = KINDS[kind]
    updated = config_routes.update_collection(
        name, str(row_id), await json_body(request), caller.org_id, caller.user_id
    )
    return masking.respond(as_v3(model, updated), caller)


@router.delete(
    "/mappings/{kind}/{row_id}",
    status_code=204,
    response_model=None,
    dependencies=[Depends(only_query(paged=False))],
)
def delete_mapping(kind: str, row_id: int, caller: Caller = Depends(MAPPINGS_WRITE)) -> Response:
    """Remove one of this org's mappings. 204. Another org's id, or none, is 404."""
    name = _editable_or_404(kind)
    config_routes.delete_collection(name, str(row_id), caller.org_id, caller.user_id)
    return Response(status_code=204)
