"""`/api/v3/processes` and `/api/v3/runs` — reads of `process_runs` (phase-12-plan §3.2, T07).

A PLAIN READ, deliberately. The run store, the state machine, artifacts and
the actions all change in Phase 11, so everything past "list the rows and
show one" is AFTER-P11 and absent here: no params, no run_state, no
artifacts, no actions.

Object-level authorization on every request:

* the org is the caller's, from a database row (`Caller.org_id`), never a
  parameter;
* the processes are the ones the caller holds `runs:read` FOR
  (`access.process_keys_for`) — a process it may not see is not in the query
  at all;
* `GET /runs/{run_id}` reads `run_id AND org_id` (`process_runs.get_run`,
  RLS under it), and a run of another org, of a process the caller may not
  see, or of nobody, is the same `404 RUN_NOT_FOUND`.
"""

from __future__ import annotations

import uuid
from datetime import date, datetime, time, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse

from src import api_scopes, process_runs
from src.api.v2 import errors as err
from src.api.v2 import pg_store
from src.api.v2.errors import ApiError
from src.api.v2.routes import PROCESS_CATALOGUE, module_enabled_for

from .. import access, masking
from ..deps import PREFIX, Caller, require_scope
from ..models import ProcessV3, RunV3
from ..pagination import (
    Paged,
    PageInfo,
    PageMeta,
    PageParams,
    bad_cursor,
    only_query,
    page_of,
    page_params,
)

router = APIRouter(prefix=PREFIX, tags=["runs"])

RUNS_READ = require_scope(api_scopes.RUNS_READ)

#: The run list's filters (contract §11), minus the ones that are not a plain
#: column read (`has_declared_gates`, `q`, `sort`): those are 422, by omission.
RUN_FILTERS = ("process", "state", "fiscal_year", "period", "created_by", "from", "to")

#: The keyset: newest first, `run_id` breaking a `created_at` tie.
CURSOR_KEYS = ("created_at", "run_id")


# ---------------------------------------------------------------- processes
@router.get(
    "/processes",
    response_model=Paged[ProcessV3],
    dependencies=[Depends(only_query(paged=False))],
)
def list_processes(caller: Caller = Depends(RUNS_READ)) -> JSONResponse:
    """The processes this org has, and what this caller may do with each."""
    modules = access.org_modules_of(caller)
    items = [
        ProcessV3(
            key=spec["key"],
            name=spec["name"],
            enabled=module_enabled_for(modules, spec["permission"]),
            can_run=caller.allows(api_scopes.PROCESSES_RUN, spec["permission"]),
            can_view_results=caller.allows(api_scopes.RUNS_READ, spec["permission"]),
            steps=list(spec["steps"]),
        )
        for spec in PROCESS_CATALOGUE
    ]
    body = Paged[ProcessV3](
        data=items,
        page=PageInfo(limit=len(items)),
        meta=PageMeta(total_estimate=len(items)),
    )
    return masking.respond(body, caller)


# --------------------------------------------------------------------- runs
def _run_out(row: Dict[str, Any]) -> RunV3:
    inputs = row.get("inputs") or {}
    uploaded = ((inputs.get("file") or {}) if isinstance(inputs, dict) else {}).get("uploaded_as")
    return RunV3(
        run_id=str(row.get("run_id")),
        process=str(row.get("process")),
        state=row.get("state") or "draft",
        step=row.get("step"),
        fiscal_year=row.get("fiscal_year"),
        period=row.get("period"),
        batch_id=row.get("batch_id"),
        input_file=uploaded,
        created_by=str(row["created_by"]) if row.get("created_by") else None,
        created_at=row.get("created_at"),
        updated_at=row.get("updated_at"),
        completed_at=row.get("updated_at") if row.get("state") == "completed" else None,
        superseded_by_run_id=(
            str(row["superseded_by_run_id"]) if row.get("superseded_by_run_id") else None
        ),
        is_test=bool(row.get("is_test")),
    )


def _day_bound(value: Optional[date], end: bool) -> Optional[str]:
    if value is None:
        return None
    moment = datetime.combine(value, time.max if end else time.min, tzinfo=timezone.utc)
    return moment.isoformat()


def _after(params: PageParams) -> Optional[Dict[str, Any]]:
    """The cursor's position, its two halves checked as a timestamp and a UUID."""
    after = params.after(CURSOR_KEYS)
    if after is not None:
        try:
            datetime.fromisoformat(str(after["created_at"]))
            uuid.UUID(str(after["run_id"]))
        except ValueError as exc:
            raise bad_cursor() from exc
    return after


def _states(raw: Optional[str]) -> List[str]:
    states = [s for s in (raw or "").split(",") if s]
    bad = [s for s in states if s not in process_runs.VALID_STATES]
    if bad:
        raise ApiError(
            err.VALIDATION_ERROR,
            "Unknown run state: " + ", ".join(bad),
            field_errors={"state": bad},
        )
    return states


@router.get(
    "/runs",
    response_model=Paged[RunV3],
    dependencies=[Depends(only_query(*RUN_FILTERS))],
)
def list_runs(
    process: Optional[str] = Query(None, max_length=64),
    state: Optional[str] = Query(None, max_length=512),
    fiscal_year: Optional[int] = Query(None, ge=2000, le=2100),
    period: Optional[int] = Query(None, ge=1, le=12),
    created_by: Optional[str] = Query(None, max_length=64),
    from_: Optional[date] = Query(None, alias="from"),
    to: Optional[date] = Query(None),
    params: PageParams = Depends(page_params),
    caller: Caller = Depends(RUNS_READ),
) -> JSONResponse:
    """This org's runs of the processes this caller may read, newest first."""
    allowed = access.process_keys_for(caller, api_scopes.RUNS_READ)
    if process is not None:
        # A process the caller may not see is an empty list, not a 403: the
        # answer to "which runs of X may I see" is "none".
        allowed = [key for key in allowed if key == process]
    after = _after(params)

    filters: Dict[str, Any] = {}
    if fiscal_year is not None:
        filters["fiscal_year"] = fiscal_year
    if period is not None:
        filters["period"] = period
    if created_by is not None:
        who = caller.user_id if created_by == "me" else created_by
        try:
            filters["created_by"] = str(uuid.UUID(str(who)))
        except (TypeError, ValueError):
            raise ApiError(
                err.VALIDATION_ERROR,
                "created_by must be a user id or `me`.",
                field_errors={"created_by": ["must be a user id or me"]},
            )

    rows: List[Dict[str, Any]] = []
    if allowed:
        rows = pg_store.run_history(
            caller.org_id,
            allowed,
            states=_states(state),
            eq=filters,
            created_from=_day_bound(from_, end=False),
            created_to=_day_bound(to, end=True),
            before=str(after["created_at"]) if after else None,
            before_run_id=str(after["run_id"]) if after else None,
            limit=params.limit + 1,
        )
    body = page_of(
        [_run_out(row) for row in rows],
        params.limit,
        lambda run: {
            "created_at": run.created_at.isoformat() if run.created_at else "",
            "run_id": run.run_id,
        },
    )
    return masking.respond(body, caller)


@router.get(
    "/runs/{run_id}",
    response_model=RunV3,
    dependencies=[Depends(only_query(paged=False))],
)
def get_run(run_id: uuid.UUID, caller: Caller = Depends(RUNS_READ)) -> JSONResponse:
    """One run — this org's, of a process this caller may read — or 404."""
    row = process_runs.get_run(caller.org_id, str(run_id))
    if not row or not access.may_see(caller, api_scopes.RUNS_READ, row.get("process")):
        raise ApiError(err.RUN_NOT_FOUND, "No such run.")
    return masking.respond(_run_out(row), caller)
