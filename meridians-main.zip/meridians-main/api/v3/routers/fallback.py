"""Every `/api/v3` path no v3 route answers: 405 or 404, never Flask.

Without this, a v3 path with the wrong method, or no v3 route at all, would
fall through to the Flask mount at `/` and answer with whatever Flask says —
an HTML 404, or a 405 without the envelope (tracker line 99). Registered LAST
among the v3 routes and before the mount, it claims the whole prefix:

* the path exists under another method → `405 METHOD_NOT_ALLOWED` + `Allow`;
* otherwise → `404 NOT_FOUND`.

A CORS preflight (`OPTIONS`) lands here too and gets a 405 with no
`Access-Control-Allow-*` header: v3 is same-origin by proxy and its CORS
allowlist is empty (§3.1 rule 8).
"""

from fastapi import APIRouter, Depends, Request
from starlette.exceptions import HTTPException as StarletteHTTPException

from src import api_scopes
from src.api.v2 import errors as err
from src.api.v2.errors import ApiError

from ..deps import PREFIX, allowed_methods, require_scope

#: Every method a client could send. The fallback must match all of them, or a
#: method missing here would slip past it to Flask.
ALL_METHODS = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "TRACE"]

router = APIRouter()


@router.api_route(
    PREFIX,
    methods=ALL_METHODS,
    include_in_schema=False,
    dependencies=[Depends(require_scope(api_scopes.PUBLIC))],
)
@router.api_route(
    PREFIX + "/{rest:path}",
    methods=ALL_METHODS,
    include_in_schema=False,
    dependencies=[Depends(require_scope(api_scopes.PUBLIC))],
)
async def fallback(request: Request) -> None:
    # Imported here: `api.v3` imports this module to build its route list.
    from .. import feature_routes

    allow = allowed_methods(feature_routes(), request.url.path)
    if allow:
        raise StarletteHTTPException(status_code=405, headers={"Allow": ", ".join(allow)})
    raise ApiError(err.NOT_FOUND, "Not found.")
