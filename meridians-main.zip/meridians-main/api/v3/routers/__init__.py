"""The `/api/v3` routers. `fallback` is always included last (see `api.v3.install`).

health    GET /api/v3/health                        (§3.13 step 1)
runs      GET /processes, /runs, /runs/{run_id}          (§3.2, T07)
processes POST /processes/{process}/runs (one per manifest with `prepare`),
          POST /runs/{run_id}/uploads, POST /runs/{run_id}/actions/{kind}
          (one per job kind), GET /runs/{run_id}/artifacts,
          POST /runs/{run_id}/artifacts/{artifact_id}/download-url   (T18)
journal_entries  GET /journal-entries, /runs/{run_id}/journal-entries (T07)
mappings  GET/POST /mappings/{kind}, PATCH/DELETE /mappings/{kind}/{row_id} (T07/T08)
employees GET /employees, /allocations; PUT/DELETE /employees/{employee_id},
          POST /employees/import, PUT /allocations      (T07/T08)
revenue   GET /revenue/summaries                        (T07)
admin_clients  /admin/api-clients[/{id}[/…]], GET /{id}/usage   (T12)
partner_baas   GET/POST /admin/partner-baas, POST /{id}/revoke (T12 gaps, superadmin)
fallback  every other /api/v3 path: 405 or 404      (§3.1 rule 7)
"""
