"""`GET /api/v3/health` — the v3 liveness probe (phase-12-plan §3.13 step 1).

Same body shape as `/api/v1/health`, with the v3 version string, so the
health-check move (T27) is a path change and nothing else. Public on purpose.
"""

from fastapi import APIRouter, Depends

from src import api_scopes

from ..deps import PREFIX, require_scope
from ..schemas import HealthV3

#: The v3 contract's version string.
HEALTH_VERSION = "3.0.0"

router = APIRouter(prefix=PREFIX, tags=["system"])


@router.get(
    "/health",
    response_model=HealthV3,
    dependencies=[Depends(require_scope(api_scopes.PUBLIC))],
)
async def health() -> HealthV3:
    """Liveness. Reads nothing, authenticates nothing."""
    from src.settings import get_settings

    return HealthV3(status="ok", version=HEALTH_VERSION, database=get_settings().database_backend)
