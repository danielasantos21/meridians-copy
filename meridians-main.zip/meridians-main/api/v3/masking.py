"""Field classification and the one serializer that honours it (phase-12-plan §3.1 rule 4).

Every field of every `/api/v3` response model says what kind of data it is,
in its JSON schema as `x-classification` — per field, or once for the whole
model in `model_config["json_schema_extra"]` when every field is the same
kind. The classes:

========== ==================================================================
`general`  Business data the route's scope already covers (a mapping, a JE
           line, an aggregate). Returned to whoever passed `require_scope`.
`pii`      About a person but not health information (an employee's name).
           Returned to whoever holds the route's scope; never logged.
`phi`      Health information. `null` unless the caller holds `phi:read`.
`internal` Ours, not a partner's business (an uploaded file's name). `null`
           for a machine caller; a human in the org sees it.
========== ==================================================================

`serialize` is the ONLY way a v3 handler turns a model into a body, so a field
classified `phi` cannot reach a caller without `phi:read` by a handler
forgetting to check: handlers never check. `tests/security/
test_response_field_classification.py` walks every v3 response model and
fails on a field with no class, and `test_phi_masked_without_scope.py` proves
the masking both ways.

A masked field becomes `null`, never absent: the shape a client parses does
not change with who is asking, only the values. That is why every `phi` or
`internal` field must be `Optional` (the classification test checks it).
"""

from __future__ import annotations

from typing import Any, Dict, Iterator, Optional, Type

from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from src import api_scopes

#: The JSON-schema key a classification lives under.
KEY = "x-classification"

GENERAL = "general"
PII = "pii"
PHI = "phi"
INTERNAL = "internal"

CLASSES = frozenset({GENERAL, PII, PHI, INTERNAL})

#: The classes that can be nulled, and so must be Optional on the model.
MASKABLE = frozenset({PHI, INTERNAL})


def classified(kind: str, default: Any = ..., **kwargs: Any) -> Any:
    """`Field(...)` carrying `x-classification: kind`. Required unless given a default."""
    if kind not in CLASSES:
        raise ValueError(f"unknown field classification: {kind!r}")
    extra = dict(kwargs.pop("json_schema_extra", None) or {})
    extra[KEY] = kind
    if "default_factory" in kwargs:
        return Field(json_schema_extra=extra, **kwargs)
    return Field(default, json_schema_extra=extra, **kwargs)


def model_config_for(kind: str, extra: str = "forbid") -> ConfigDict:
    """A `model_config`: every field of the model is `kind` unless it says otherwise."""
    if kind not in CLASSES:
        raise ValueError(f"unknown field classification: {kind!r}")
    return ConfigDict(extra=extra, json_schema_extra={KEY: kind})  # type: ignore[typeddict-item]


def field_class(model: Type[BaseModel], name: str) -> Optional[str]:
    """The classification of `model.name`: the field's own, else the model's, else None."""
    info = model.model_fields[name]
    extra = info.json_schema_extra
    if isinstance(extra, dict) and extra.get(KEY):
        return str(extra[KEY])
    model_extra = model.model_config.get("json_schema_extra")
    if isinstance(model_extra, dict) and model_extra.get(KEY):
        return str(model_extra[KEY])
    return None


def nested_models(annotation: Any) -> Iterator[Type[BaseModel]]:
    """Every pydantic model reachable from a type annotation (List[X], Optional[X], ...)."""
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        yield annotation
        return
    for arg in getattr(annotation, "__args__", ()) or ():
        yield from nested_models(arg)


def _masked(kind: Optional[str], caller: Any) -> bool:
    if kind == PHI:
        return not caller.allows(api_scopes.PHI_READ)
    if kind == INTERNAL:
        return bool(caller.is_machine)
    return False


def _plain(value: Any, caller: Any) -> Any:
    if isinstance(value, BaseModel):
        return serialize(value, caller)
    if isinstance(value, (list, tuple)):
        return [_plain(item, caller) for item in value]
    if isinstance(value, dict):
        return {key: _plain(item, caller) for key, item in value.items()}
    return value


def serialize(model: BaseModel, caller: Any) -> Dict[str, Any]:
    """`model` as a JSON-ready dict, with the fields this caller may not see nulled.

    Field by field over the model's own declared fields (never `__dict__`), so
    nothing the model does not declare can ride along, and recursively into
    nested models and lists of them.
    """
    cls = type(model)
    dumped = model.model_dump(mode="json")
    out: Dict[str, Any] = {}
    for name in cls.model_fields:
        if _masked(field_class(cls, name), caller):
            out[name] = None
            continue
        value = getattr(model, name)
        if isinstance(value, BaseModel) or (
            isinstance(value, (list, tuple)) and any(isinstance(v, BaseModel) for v in value)
        ):
            out[name] = _plain(value, caller)
        else:
            out[name] = dumped[name]
    return out


def respond(model: BaseModel, caller: Any, status: int = 200) -> JSONResponse:
    """The response for `model`, masked for `caller`. Every v3 handler ends here."""
    return JSONResponse(status_code=status, content=serialize(model, caller))
