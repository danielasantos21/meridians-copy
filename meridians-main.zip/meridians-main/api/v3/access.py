"""Which processes a v3 caller may see, for a process-bound scope (phase-12-plan §3.2, §3.4).

`require_scope` answers "does this caller hold `runs:read` for ANY process".
A list or a record then has to be narrowed to the processes the caller holds
it FOR — a human's per-process `results` permission, a machine's
`allowed_processes` — and to the modules the org has switched on. That
narrowing is here, once, so no router writes its own.

The process vocabulary is `src.api.v2.routes.PROCESS_CATALOGUE`: `key` is
what `process_runs.process` stores (`qb-revenue`), `permission` is what a
grant is held for (`revenue`). `import_batches.batch_type` is a third
spelling, mapped below for the journal lines.

A process the caller may not see is left OUT of the query, never filtered out
of the answer afterwards; a record of such a process answers 404, exactly
like a record of another org (contract §8).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from src.api.v2.routes import PROCESS_CATALOGUE, module_enabled_for

from .deps import Caller

#: `process_runs.process` -> the `import_batches.batch_type` its journal lines
#: are stored under. qb-usa-payroll books through its own tables and has no
#: `journal_entries` rows; it is here so the map is total.
BATCH_TYPE_FOR_PROCESS: Dict[str, str] = {
    "qb-revenue": "revenue",
    "mx-payroll": "payroll",
    "qb-usa-payroll": "qb_usa_payroll",
}


def org_modules_of(caller: Caller) -> Optional[set]:
    """The org's enabled modules: the ones `require_org` read, or a fresh read.

    A human's were read on this request. A machine has no `Identity`, so they
    are read now, by org id from the caller's row, and a read that fails
    DENIES (no modules), whatever the backend — critic Stage 1 M-4. (A
    human's read went through `get_org_modules`, which on the Postgres backend
    v3 runs on fails closed the same way.)
    """
    if caller.identity is not None:
        return caller.identity.org_modules
    from src.auth import get_org_modules_fail_closed

    return get_org_modules_fail_closed(caller.org_id)


def processes_for(caller: Caller, scope: str) -> List[Dict[str, Any]]:
    """The catalogue entries this caller holds `scope` for, in enabled modules."""
    modules = org_modules_of(caller)
    return [
        spec
        for spec in PROCESS_CATALOGUE
        if caller.allows(scope, spec["permission"])
        and module_enabled_for(modules, spec["permission"])
    ]


def process_keys_for(caller: Caller, scope: str) -> List[str]:
    return [spec["key"] for spec in processes_for(caller, scope)]


def may_see(caller: Caller, scope: str, process_key: Optional[str]) -> bool:
    """May this caller see a record of `process_key` under `scope`?"""
    return bool(process_key) and process_key in process_keys_for(caller, scope)
