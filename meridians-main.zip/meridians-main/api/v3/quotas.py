"""Shared quotas and progressive lockout for `/api/v3` (phase-12-plan T09).

ADR 0010 kept rate limits in process because the api ran one task; an
allowance per task is wrong the moment there are two. These counters live in
Postgres (`public.api_quota_window`, revision 0013): fixed windows, one row per
(bucket, window), incremented with one `INSERT ... ON CONFLICT DO UPDATE`, so
every api task spends the same allowance. Still no Redis.

TWO THINGS ARE COUNTED
----------------------
* **Calls, per caller** — `client:<api_clients.id>` for a machine,
  `user:<user id>` for a human: `CALLER_LIMIT` per `CALLER_WINDOW`, then
  `429 QUOTA_EXCEEDED` with `Retry-After`.
* **Authentication failures** — every 401 for a request that presented a
  bearer token counts against `authfail:ip:<address>`, and, when the token's
  signature DID verify (a revoked, disabled or IP-refused client),
  `authfail:client:<cognito client id>` too. Only verified client ids are
  counted: otherwise anybody could lock a partner out by sending forged tokens
  that name its client id.

PROGRESSIVE LOCKOUT
-------------------
Before a bearer request is authenticated, the failure count for its address
and for the client id it names is read. Below `DELAY_AFTER` nothing happens;
from there each request waits `2 ** (n - DELAY_AFTER)` seconds, capped at
`MAX_DELAY_SECONDS`, before it is even looked at; at `LOCKOUT_AFTER` every
request — a valid token included — is refused with `QUOTA_EXCEEDED` until the
window ends. The wait is an `asyncio.sleep`, so a delayed caller holds no
worker thread. Requests without a bearer token (the SPA's cookies) are not
counted: one office behind one NAT address would otherwise lock itself out.

WHEN THE SHARED STORE IS DOWN (critic Stage 1 M-5)
-------------------------------------------------
Nothing here switches itself off. An auth-failure flood that stresses
Postgres must not also lift the lockout and the caps it is flooding.

* `auth_gate` FAILS CLOSED: if the failure counts cannot be read, a bearer
  request is refused with `503 PERSISTENCE_UNAVAILABLE` (retryable) before it
  is looked at.
* `record_auth_failure` and `cap` fall back to an IN-PROCESS count (the same
  fixed windows, per api task) — the `PgRateLimiter` rule: a limit per task
  until the database answers again, never no limit. `auth_gate` reads that
  local count as well, so failures counted during an outage still lock.
"""

from __future__ import annotations

import asyncio
import logging
import math
import random
import threading
import time
from typing import Callable, Dict, Optional, Protocol, Tuple

from fastapi import Request
from starlette.concurrency import run_in_threadpool

from src.api.v2 import errors as err
from src.api.v2.errors import ApiError

from .. import deps as base_deps

logger = logging.getLogger(__name__)

#: `app.state` attribute holding the store. `create_app` sets a
#: `PgQuotaStore`; None (every bare test app) means no quotas.
STORE_STATE = "api_quota_store"

QUOTA_EXCEEDED = "QUOTA_EXCEEDED"

#: Calls per caller per window.
CALLER_LIMIT = 300
CALLER_WINDOW = 60

#: Authentication failures: counted per window; delay from the third, refuse
#: from the tenth.
AUTH_FAILURE_WINDOW = 900
DELAY_AFTER = 3
LOCKOUT_AFTER = 10
MAX_DELAY_SECONDS = 8

#: Set on `request.state` by the machine path once a token's SIGNATURE is
#: verified, so a later refusal may count against that client id.
VERIFIED_CLIENT_STATE = "v3_verified_client_id"

#: Replaced in tests to record the delays instead of waiting them out.
sleep = asyncio.sleep


class QuotaExceeded(ApiError):
    """`429 QUOTA_EXCEEDED` plus the `Retry-After` the handler sets from it."""

    def __init__(self, retry_after: int):
        super().__init__(
            QUOTA_EXCEEDED,
            "Too many requests. Wait and try again.",
            status=429,
            retryable=True,
        )
        self.retry_after = max(1, int(retry_after))


class LockoutUnavailable(ApiError):
    """`503`: the failure counts could not be read, so the request is not let in."""

    def __init__(self) -> None:
        super().__init__(
            err.PERSISTENCE_UNAVAILABLE,
            "The service cannot check sign-in limits right now. Try again shortly.",
            status=503,
            retryable=True,
        )


class QuotaStore(Protocol):
    def hit(self, bucket: str, window: int) -> Tuple[int, int]:
        """Count one; return (count in this window, seconds until it ends)."""

    def peek(self, bucket: str, window: int) -> Tuple[int, int]:
        """(count in this window, seconds until it ends), counting nothing."""


#: The window a statement falls in, from the DATABASE clock so every api task
#: agrees on it.
_WINDOW = "to_timestamp(floor(extract(epoch FROM clock_timestamp()) / %(w)s) * %(w)s)"
_REMAINING = (
    "ceil(extract(epoch FROM q.window_start) + %(w)s - extract(epoch FROM clock_timestamp()))"
)

HIT_SQL = (
    "INSERT INTO public.api_quota_window AS q (bucket, window_start, hits) "  # noqa: S608 table/column names are module constants; values bound
    f"VALUES (%(b)s, {_WINDOW}, 1) "
    "ON CONFLICT (bucket, window_start) DO UPDATE SET hits = q.hits + 1 "
    f"RETURNING q.hits AS hits, {_REMAINING}::int AS remaining"
)
PEEK_SQL = (
    f"SELECT q.hits AS hits, {_REMAINING}::int AS remaining "  # noqa: S608 table/column names are module constants; values bound
    f"FROM public.api_quota_window q WHERE q.bucket = %(b)s AND q.window_start = {_WINDOW}"
)
PRUNE_SQL = "DELETE FROM public.api_quota_window WHERE window_start < now() - interval '1 day'"

#: One `hit` in this many also prunes day-old windows, so the table stays small
#: without a scheduled job.
PRUNE_ONE_IN = 200


class PgQuotaStore:
    """Counters in `public.api_quota_window`, shared by every api task."""

    def hit(self, bucket: str, window: int) -> Tuple[int, int]:
        from src import pg

        with pg.with_anonymous() as db:
            row = db.fetch_one(HIT_SQL, {"b": bucket, "w": window})
            if random.randrange(PRUNE_ONE_IN) == 0:  # noqa: S311 sampling when to prune, not security
                db.execute(PRUNE_SQL)
        if row is None:
            raise AssertionError('row is not None')
        return int(row["hits"]), int(row["remaining"])

    def peek(self, bucket: str, window: int) -> Tuple[int, int]:
        from src import pg

        with pg.with_anonymous() as db:
            row = db.fetch_one(PEEK_SQL, {"b": bucket, "w": window})
        if row is None:
            return 0, window
        return int(row["hits"]), int(row["remaining"])


class LocalQuotaStore:
    """Fixed windows counted in THIS process — the fallback when Postgres is down.

    Same `hit`/`peek` shape as `PgQuotaStore`. Windows are aligned to the
    process clock (`floor(now / window)`), so a window ends at the same moment
    for every bucket, as the database's do. Per api task, which is weaker than
    the shared counter and strictly stronger than none.
    """

    def __init__(self, clock: Callable[[], float] = time.time):
        self._clock = clock
        self._lock = threading.Lock()
        #: `{(bucket, window): (window_start, hits)}`
        self._hits: Dict[Tuple[str, int], Tuple[int, int]] = {}

    def _now(self, window: int) -> Tuple[int, int]:
        now = self._clock()
        start = int(now // window) * window
        # Rounded UP, as `_REMAINING` is in Postgres: a caller that waits
        # `Retry-After` seconds must land in the next window, not just before it.
        return start, max(1, math.ceil(start + window - now))

    def hit(self, bucket: str, window: int) -> Tuple[int, int]:
        start, remaining = self._now(window)
        with self._lock:
            seen_start, hits = self._hits.get((bucket, window), (start, 0))
            hits = hits + 1 if seen_start == start else 1
            self._hits[(bucket, window)] = (start, hits)
            if len(self._hits) > 10_000:  # bound memory: drop windows that ended
                # Each entry against ITS OWN window size (critic Stage 1 round 2 L8):
                # comparing with this call's window start dropped the live counts of
                # every other window size.
                now = self._clock()
                self._hits = {k: v for k, v in self._hits.items() if v[0] + k[1] > now}
        return hits, remaining

    def peek(self, bucket: str, window: int) -> Tuple[int, int]:
        start, remaining = self._now(window)
        with self._lock:
            seen_start, hits = self._hits.get((bucket, window), (start, 0))
        return (hits if seen_start == start else 0), remaining

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


#: The one in-process fallback counter of this api task.
FALLBACK = LocalQuotaStore()


def _refuse_unreadable_lockout() -> None:
    """`auth_gate`'s answer when the shared failure counts cannot be read."""
    raise LockoutUnavailable()


def _store(request: Request) -> Optional[QuotaStore]:
    return getattr(request.app.state, STORE_STATE, None)


def _ip_bucket(request: Request) -> str:
    return f"authfail:ip:{base_deps.client_address(request) or 'unknown'}"


def _client_bucket(cognito_client_id: str) -> str:
    return f"authfail:client:{cognito_client_id}"[:200]


def delay_for(failures: int) -> float:
    """Seconds to wait before looking at a request after `failures` failures."""
    if failures < DELAY_AFTER:
        return 0.0
    return float(min(2 ** (failures - DELAY_AFTER), MAX_DELAY_SECONDS))


#: Set on `request.state` by `auth_gate` when the ADDRESS (not the client id)
#: is locked out: the refusal is deferred until the token is verified, so a
#: partner with a registered IP allowlist is not locked out by forged tokens
#: sent from a shared egress address (critic Stage 1 L-4). Value: Retry-After.
IP_LOCKED_STATE = "v3_ip_locked_retry_after"

#: Set by the machine path when the verified client has an `ip_allowlist`
#: (the address already passed it): such a client is exempt from the address
#: lockout.
ALLOWLISTED_CLIENT_STATE = "v3_client_ip_allowlisted"


async def auth_gate(request: Request) -> None:
    """FastAPI dependency, before authentication: delay or refuse by past failures.

    A locked CLIENT id refuses at once (only verified failures are counted
    against it, so it cannot be forged). A locked ADDRESS refuses once the
    caller is resolved (`refuse_if_address_locked`): every caller from it is
    still refused — invalid tokens with 429 instead of 401 — except a verified
    machine client whose own `ip_allowlist` admits the address.
    """
    store = _store(request)
    token = base_deps._bearer_token(request)
    if store is None or not token:
        return
    ip_bucket = _ip_bucket(request)
    buckets = [ip_bucket]
    from src import cognito

    named = cognito.unverified_client_id(token)
    if named:
        buckets.append(_client_bucket(named))
    try:
        shared = [await run_in_threadpool(store.peek, b, AUTH_FAILURE_WINDOW) for b in buckets]
    except Exception as exc:
        logger.warning("v3 auth lockout unreadable; refusing the request (%s)", type(exc).__name__)
        _refuse_unreadable_lockout()
        return
    # Failures counted in this process while the store was down still count.
    seen = {
        b: max(counted, FALLBACK.peek(b, AUTH_FAILURE_WINDOW))
        for b, counted in zip(buckets, shared)
    }
    client_failures, client_remaining = max(
        (seen[b] for b in buckets if b != ip_bucket), default=(0, AUTH_FAILURE_WINDOW)
    )
    if client_failures >= LOCKOUT_AFTER:
        raise QuotaExceeded(client_remaining)
    ip_failures, ip_remaining = seen[ip_bucket]
    if ip_failures >= LOCKOUT_AFTER:
        setattr(request.state, IP_LOCKED_STATE, ip_remaining)
        wait = delay_for(client_failures)
    else:
        wait = delay_for(max(ip_failures, client_failures))
    if wait:
        await sleep(wait)


def refuse_if_address_locked(request: Request, allowlisted: bool = False) -> None:
    """429 when `auth_gate` found the address locked, unless the client is allowlisted."""
    remaining = getattr(request.state, IP_LOCKED_STATE, None)
    if remaining is not None and not allowlisted:
        raise QuotaExceeded(remaining)


def record_auth_failure(request: Request) -> None:
    """Count a 401 for a bearer request against its address (and verified client)."""
    store = _store(request)
    if store is None or not base_deps._bearer_token(request):
        return
    buckets = [_ip_bucket(request)]
    verified = getattr(request.state, VERIFIED_CLIENT_STATE, None)
    if verified:
        buckets.append(_client_bucket(verified))
    for bucket in buckets:
        try:
            store.hit(bucket, AUTH_FAILURE_WINDOW)
        except Exception as exc:
            logger.warning(
                "v3 auth failure counted in this process: quota store unavailable (%s)",
                type(exc).__name__,
            )
            FALLBACK.hit(bucket, AUTH_FAILURE_WINDOW)


def charge(request: Request, bucket: str) -> None:
    """Spend one call of `bucket`'s allowance, or raise `QuotaExceeded`."""
    cap(request, bucket, CALLER_LIMIT, CALLER_WINDOW)


#: Business-flow caps (OWASP API6, T18): job starts (parse, execute, retry)
#: per org and process, on top of the per-caller allowance. Two of them:
#: `JOB_START_SPACING_LIMIT` per `JOB_START_SPACING_WINDOW` (one every 30
#: seconds, Andres 2026-09-25) spaces starts out; `JOB_START_LIMIT` per
#: `JOB_START_WINDOW` stays as the ceiling on the hour's total, because the
#: spacing alone would still let a script gone wrong start 120 jobs an hour.
#: A real month needs a handful.
JOB_START_SPACING_LIMIT = 1
JOB_START_SPACING_WINDOW = 30
JOB_START_LIMIT = 30
JOB_START_WINDOW = 3600


def cap(request: Request, bucket: str, limit: int, window: int) -> None:
    """Spend one of `limit` per `window` seconds in `bucket`, or `QuotaExceeded`.

    Shared by every api task (the Postgres counters). When the store is
    unreachable the call is counted in this process instead (`FALLBACK`), so
    the cap still holds, per task, until the database answers again.

    Windows are FIXED and aligned to the clock (`floor(now / window)`), so the
    refusal's `Retry-After` is the seconds left in the current window, and
    "1 per 30 s" means one per aligned 30-second window: two calls a moment
    apart across a window edge can both pass, but never more than one in a
    window. A bucket name is used with ONE window size (the Postgres row key
    is `(bucket, window_start)`, which two sizes would share).
    """
    store = _store(request)
    if store is None:
        return
    try:
        count, remaining = store.hit(bucket[:200], window)
    except Exception as exc:
        logger.warning(
            "v3 quota counted in this process: quota store unavailable (%s)", type(exc).__name__
        )
        count, remaining = FALLBACK.hit(bucket[:200], window)
    if count > limit:
        raise QuotaExceeded(remaining)
