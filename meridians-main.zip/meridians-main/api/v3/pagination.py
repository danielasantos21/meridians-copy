"""Keyset pagination and strict query strings for `/api/v3` lists (phase-12-plan §3.3).

Contract §11, verbatim: keyset (never offset), `limit` 1-100 default 25, an
opaque `cursor`, and the body

    {"data": [...], "page": {"next_cursor", "has_more", "limit"},
     "meta": {"total_estimate"}}

THE CURSOR is base64url of a JSON object holding the last row's sort key —
`{"created_at": …, "id": …}` for runs, `{"id": …}` for journal lines, the
natural key for configuration. It is opaque to clients and STRICTLY parsed
here: not base64url, not JSON, not an object, the wrong keys, or a value that
is not a string or an integer → `422 VALIDATION_ERROR` naming `cursor`. A
cursor is never trusted to carry anything but a position; the org, the
filters and the caller come from the request every time.

TWO WAYS A PAGE IS CUT, one rule for both:

* `page_of(rows, limit, key)` — the query already did the keyset (`WHERE
  (sort key) < cursor … LIMIT limit + 1`); the extra row only says whether
  there is a next page. Runs and journal lines, which grow without bound.
* `page_in_memory(rows, key, params)` — the org-scoped repository read
  returns the whole collection (a mapping table, a roster: hundreds of rows),
  and the page is cut here with the same cursor semantics. Still bounded: a
  response never carries more than `limit` rows.

UNKNOWN QUERY PARAMETERS are refused, not ignored (§3.1 rule 3, contract
§11): `only_query(...)` is a dependency naming what a route accepts, and any
other parameter is a 422 naming it. A filter that silently does nothing
answers the question with a lie.
"""

from __future__ import annotations

import base64
import binascii
import json
from dataclasses import dataclass
from typing import Any, Callable, Dict, Generic, List, Optional, Sequence, Tuple, TypeVar

from fastapi import Query, Request

from src.api.v2 import errors as err
from src.api.v2.errors import ApiError

from . import masking
from .schemas import V3Model

T = TypeVar("T")

DEFAULT_LIMIT = 25
MAX_LIMIT = 100

#: Always accepted, on every list route.
PAGE_PARAMS = ("limit", "cursor")


# ----------------------------------------------------------------- the body
class PageInfo(V3Model):
    model_config = masking.model_config_for(masking.GENERAL)

    next_cursor: Optional[str] = None
    has_more: bool = False
    limit: int


class PageMeta(V3Model):
    model_config = masking.model_config_for(masking.GENERAL)

    #: An estimate, labelled as one (contract §11). `null` = not counted:
    #: an exact COUNT(*) on every page of a growing table is not worth it.
    total_estimate: Optional[int] = None


class Paged(V3Model, Generic[T]):
    """One page of a v3 list."""

    model_config = masking.model_config_for(masking.GENERAL)

    data: List[T]
    page: PageInfo
    meta: PageMeta = PageMeta()


# ------------------------------------------------------------------ cursors
def bad_cursor() -> ApiError:
    return ApiError(
        err.VALIDATION_ERROR,
        "That page cursor is not one this server issued.",
        field_errors={"cursor": ["invalid cursor"]},
    )


def encode_cursor(key: Dict[str, Any]) -> str:
    raw = json.dumps(key, separators=(",", ":"), sort_keys=True).encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def decode_cursor(cursor: str, keys: Sequence[str]) -> Dict[str, Any]:
    """The position `cursor` names, with exactly `keys`, or 422."""
    if not cursor or len(cursor) > 512:
        raise bad_cursor()
    try:
        padded = cursor + "=" * (-len(cursor) % 4)
        decoded = base64.b64decode(padded, altchars=b"-_", validate=True)
        value = json.loads(decoded.decode("utf-8"))
    except (binascii.Error, ValueError, UnicodeDecodeError) as exc:
        raise bad_cursor() from exc
    if not isinstance(value, dict) or set(value) != set(keys):
        raise bad_cursor()
    for item in value.values():
        if isinstance(item, bool) or not isinstance(item, (str, int)):
            raise bad_cursor()
    return value


# ------------------------------------------------------------------- params
@dataclass(frozen=True)
class PageParams:
    limit: int
    cursor: Optional[str]

    def after(self, keys: Sequence[str]) -> Optional[Dict[str, Any]]:
        """The decoded position to continue after, or None for the first page."""
        return decode_cursor(self.cursor, keys) if self.cursor is not None else None


def page_params(
    limit: int = Query(DEFAULT_LIMIT, ge=1, le=MAX_LIMIT),
    cursor: Optional[str] = Query(None, min_length=1, max_length=512),
) -> PageParams:
    """FastAPI dependency: `limit` 1-100 (else 422) and the raw cursor."""
    return PageParams(limit=limit, cursor=cursor)


def only_query(*names: str, paged: bool = True) -> Callable[[Request], None]:
    """Dependency: 422 naming every query parameter outside `names`.

    `limit` and `cursor` are accepted too when `paged` (a list route).

    A repeated parameter (`?period=1&period=2`) is refused as well: which one
    the route would read is not something the caller should have to guess.
    """
    allowed = set(names) | (set(PAGE_PARAMS) if paged else set())

    def _check(request: Request) -> None:
        keys = [key for key, _ in request.query_params.multi_items()]
        unknown = sorted({key for key in keys if key not in allowed})
        repeated = sorted({key for key in keys if keys.count(key) > 1} - set(unknown))
        if unknown or repeated:
            field_errors = {key: ["not a parameter this endpoint accepts"] for key in unknown}
            field_errors.update({key: ["given more than once"] for key in repeated})
            raise ApiError(
                err.VALIDATION_ERROR,
                "This endpoint does not accept: " + ", ".join(unknown + repeated),
                field_errors=field_errors,
            )

    _check.accepted_query = tuple(sorted(allowed))  # type: ignore[attr-defined]
    return _check


# ------------------------------------------------------------------- pages
def page_of(
    rows: Sequence[T],
    limit: int,
    key: Callable[[T], Dict[str, Any]],
    total_estimate: Optional[int] = None,
) -> Paged:
    """A page from a keyset query that fetched `limit + 1` rows."""
    page = list(rows[:limit])
    has_more = len(rows) > limit and bool(page)
    return Paged(
        data=page,
        page=PageInfo(
            next_cursor=encode_cursor(key(page[-1])) if has_more else None,
            has_more=has_more,
            limit=limit,
        ),
        meta=PageMeta(total_estimate=total_estimate),
    )


def page_in_memory(
    rows: Sequence[T],
    key: Callable[[T], Tuple[str, ...]],
    key_names: Sequence[str],
    params: PageParams,
) -> Paged:
    """A page of an already-fetched, org-scoped collection, ascending by `key`.

    `key` returns a tuple of strings, one per name in `key_names`, and must be
    unique within the collection (an id, a natural key). The whole collection
    is sorted by it, so the order is stable between requests whatever order
    the repository returned.
    """
    ordered = sorted(rows, key=key)
    after = params.after(key_names)
    if after is not None:
        position = tuple(str(after[name]) for name in key_names)
        ordered = [row for row in ordered if key(row) > position]
    window = ordered[: params.limit + 1]
    return page_of(
        window,
        params.limit,
        lambda row: dict(zip(key_names, key(row))),
        total_estimate=len(rows),
    )
