"""Request and response models for `/api/v3`.

Request models forbid unknown fields (phase-12-plan §3.1 rule 3); response
models are what a handler returns and nothing more.
"""

from pydantic import BaseModel, ConfigDict


class V3Model(BaseModel):
    """Base for every v3 model: an unknown field is a 422, never ignored."""

    model_config = ConfigDict(extra="forbid")


class HealthV3(V3Model):
    #: `api.v3.masking` classification, written out: masking imports this module.
    model_config = ConfigDict(extra="forbid", json_schema_extra={"x-classification": "general"})

    status: str
    version: str
    database: str
