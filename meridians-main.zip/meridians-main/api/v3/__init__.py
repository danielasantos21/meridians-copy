"""`/api/v3` — one API for the React app, our scripts and partners (Phase 12).

Mounted only when `src.settings.api_v3_enabled()` is true: `MERIDIAN_API_V3`
set AND `DATABASE_BACKEND=postgres`. Off, nothing under `/api/v3` is a FastAPI
route and the app behaves exactly as before. The plan is
`docs/reports/phase-12-plan.md`; the rules every route follows are its §3.1.
"""

from __future__ import annotations

from typing import List

from fastapi import Depends, FastAPI
from fastapi.routing import APIRoute

from ..deps import check_csrf
from .routers import (
    employees,
    fallback,
    health,
    journal_entries,
    mappings,
    processes,
    revenue,
    runs,
    webhooks,
)
from .routers.admin_clients import router as admin_clients_router
from .routers.partner_baas import router as partner_baas_router

#: The feature routers, in order. `fallback` is not here: it must come last.
#: This tuple IS the v3 surface — `install` mounts exactly these, and the route
#: matrix test and the 405 `Allow` header both read them from here.
ROUTERS = (
    health.router,
    runs.router,
    processes.router,
    journal_entries.router,
    mappings.router,
    employees.router,
    revenue.router,
    admin_clients_router,
    partner_baas_router,
    webhooks.router,
)


def feature_routes() -> List[APIRoute]:
    """Every v3 route except the fallback."""
    return [r for router in ROUTERS for r in router.routes if isinstance(r, APIRoute)]


def all_routes() -> List[APIRoute]:
    """Every v3 route, the fallback included."""
    return feature_routes() + [r for r in fallback.router.routes if isinstance(r, APIRoute)]


def install(app: FastAPI) -> None:
    """Add the v3 routes to `app`. Call before the Flask mount.

    CSRF is checked on every v3 feature route (double-submit, bearer-exempt —
    the same `api.deps.check_csrf` as v2). The fallback goes last so it only
    claims what no feature route answers.
    """
    for router in ROUTERS:
        app.include_router(router, dependencies=[Depends(check_csrf)])
    app.include_router(fallback.router)
