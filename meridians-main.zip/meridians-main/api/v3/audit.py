"""One `audit.api_request` row for every `/api/v3` call (phase-12-plan T06).

WHAT A ROW HOLDS, AND WHAT IT NEVER HOLDS
-----------------------------------------
Who (org, user or machine client — ids from the database rows `resolve_caller`
read, never from a token), what (method, the matched route TEMPLATE such as
`/api/v3/runs/{run_id}`, the one public UUID acted on, the scope the route
declares), the outcome (status) and from where (the caller's address, as the
rate limiter sees it). Never the raw URL, never a query string, never a
header or a body: those are where a patient identifier would be, and the
template/UUID pair says everything an access review asks without them.

A path parameter that is not a UUID is not recorded at all, so a malformed or
hostile path segment cannot smuggle text into the trail.

HOW
---
A pure ASGI middleware, installed by `api.main.create_app` INSIDE the request
envelope (so the request id exists and the proxy headers have been applied)
and outside the exception handlers (so an `ApiError` has already become its
401/403/404 by the time the status is read). An exception nothing handled is
recorded as 500 and re-raised.

The row is written after the response has been sent, on a worker thread. A
failed write cannot change an answer the client already has; it is logged
with the request id and nothing else. The table is append-only in the
database (revision 0013), so the application can add rows and never read,
change or remove one.
"""

from __future__ import annotations

import ipaddress
import logging
import uuid
from dataclasses import astuple, dataclass
from typing import Any, Callable, Optional

from fastapi.routing import APIRoute
from starlette.concurrency import run_in_threadpool
from starlette.requests import Request
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from .. import errors as api_errors
from ..deps import client_address
from .deps import CALLER_STATE, PREFIX, Caller, declared_scopes

logger = logging.getLogger(__name__)

#: `app.state` attribute holding the writer. `create_app` sets it to
#: `write_row`; a test may set a capturing stand-in, or None to write nothing.
WRITER_STATE = "api_audit_writer"

#: A request no route matched at all (not even the v3 fallback) is recorded
#: under this, never under its raw path.
UNMATCHED = "<unmatched>"

INSERT_SQL = (
    "INSERT INTO audit.api_request (request_id, org_id, user_id, api_client_id, "
    "method, route, record_id, scope_used, status, ip) "
    "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
)


@dataclass(frozen=True)
class AuditRow:
    """One `audit.api_request` row, in column order."""

    request_id: str
    org_id: Optional[str]
    user_id: Optional[str]
    api_client_id: Optional[str]
    method: str
    route: str
    record_id: Optional[str]
    scope_used: Optional[str]
    status: int
    ip: Optional[str]


def write_row(row: AuditRow) -> None:
    """Append `row`. Pre-tenant checkout: the audit table has no org scope."""
    from src import pg

    with pg.with_anonymous() as db:
        db.execute(INSERT_SQL, astuple(row))


def _uuid_or_none(value: Any) -> Optional[str]:
    try:
        return str(uuid.UUID(str(value)))
    except (ValueError, TypeError, AttributeError):
        return None


def _ip_or_none(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        return None


def build_row(scope: Scope, status: int) -> AuditRow:
    """The row for a finished request, from its ASGI scope alone."""
    request = Request(scope)
    route = scope.get("route")
    template = getattr(route, "path", None)
    scope_used = None
    if isinstance(route, APIRoute):
        declared = declared_scopes(route)
        scope_used = declared[0] if declared else None

    record_id = None
    for value in (scope.get("path_params") or {}).values():
        record_id = _uuid_or_none(value) or record_id

    caller: Optional[Caller] = (scope.get("state") or {}).get(CALLER_STATE)
    return AuditRow(
        request_id=api_errors.request_id(request)[:64],
        org_id=_uuid_or_none(caller.org_id) if caller else None,
        user_id=_uuid_or_none(caller.user_id) if caller else None,
        api_client_id=_uuid_or_none(caller.client_id) if caller else None,
        method=str(scope.get("method", ""))[:16],
        route=(template if isinstance(template, str) and template else UNMATCHED)[:300],
        record_id=record_id,
        scope_used=scope_used,
        status=int(status),
        ip=_ip_or_none(client_address(request)),
    )


class ApiAuditMiddleware:
    """Writes one audit row per `/api/v3` request; passes everything else by."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        path = scope.get("path", "") if scope["type"] == "http" else ""
        if not (path == PREFIX or path.startswith(PREFIX + "/")):
            await self.app(scope, receive, send)
            return

        status = {"code": 500}

        async def _send(message: Message) -> None:
            if message["type"] == "http.response.start":
                status["code"] = int(message["status"])
            await send(message)

        try:
            await self.app(scope, receive, _send)
        finally:
            await self._record(scope, status["code"])

    async def _record(self, scope: Scope, status: int) -> None:
        app = scope.get("app")
        writer: Optional[Callable[[AuditRow], None]] = getattr(
            getattr(app, "state", None), WRITER_STATE, None
        )
        if writer is None:
            return
        try:
            row = build_row(scope, status)
            await run_in_threadpool(writer, row)
        except Exception:
            request_id = (scope.get("state") or {}).get("request_id")
            logger.error("api audit row not written for %s", request_id)  # phi-lint: ok request id
