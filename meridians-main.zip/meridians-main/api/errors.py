"""The §4.1 error envelope, as FastAPI exception handlers.

One shape for every failure under this app, exactly as the Flask blueprint
already answers it (`src/api/v2/errors.py`):

    {"error": {"code", "message", "details", "field_errors",
               "request_id", "retryable"}}

The CODE CATALOGUE is not copied — it is imported from `src.api.v2.errors`,
which is the single source of what a code means, which HTTP status it answers
with and whether a client may retry it. Only the two things that are genuinely
framework-specific live here: where the request id is kept (Starlette's
`request.state`, not Flask's `g`) and how an exception becomes a response.

An unexpected exception answers `500 INTERNAL_ERROR` with a request id and
NOTHING ELSE. The traceback is logged, never sent: it names file paths, local
variables and, in this codebase, sometimes the contents of a spreadsheet cell.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from src import log_setup
from src.api.v2 import errors as err
from src.api.v2.errors import ApiError
from src.http_headers import security_headers
from src.pg import NotAMember
from src.support_access import SupportPhiRefused

logger = logging.getLogger(__name__)

#: `request.state` attribute the per-request id is kept on.
REQUEST_ID_ATTR = "request_id"

#: The status each unhandled HTTP status maps to in the catalogue. Same table
#: as the blueprint's `_http_error`, minus the Flask-only CSRF case (CSRF is
#: raised as an `ApiError` here, not as an exception class).
STATUS_CODE_MAP = {
    401: err.AUTH_REQUIRED,
    403: err.PERMISSION_DENIED,
    404: err.NOT_FOUND,
    405: err.METHOD_NOT_ALLOWED,
    413: err.FILE_TOO_LARGE,
    415: err.FILE_TYPE_INVALID,
    429: err.RATE_LIMITED,
}


class RateLimited(ApiError):
    """`RATE_LIMITED` plus the `Retry-After` the 429 must carry (§9).

    `ApiError` has no header slot and should not grow one for every framework;
    the handler below reads `retry_after` off this subclass instead.
    """

    def __init__(self, message: str, retry_after: int, limit: str):
        super().__init__(
            err.RATE_LIMITED,
            message,
            details={"limit": limit},
            retryable=True,
        )
        self.retry_after = retry_after


def new_request_id() -> str:
    """A fresh id, in the `req_…` spelling the contract and the SPA expect."""
    return "req_" + uuid.uuid4().hex


def request_id(request: Request) -> str:
    """This request's id, minting one if the middleware has not yet run."""
    rid = getattr(request.state, REQUEST_ID_ATTR, None)
    if not rid:
        rid = new_request_id()
        setattr(request.state, REQUEST_ID_ATTR, rid)
    return rid


def envelope(
    code: str,
    message: str,
    rid: str,
    details: Optional[Any] = None,
    field_errors: Optional[Dict[str, List[str]]] = None,
    retryable: Optional[bool] = None,
) -> dict:
    """The §4.1 envelope as a plain dict.

    The Flask twin (`err.error_payload`) mints the id from `flask.g`, which
    does not exist here; everything else — the key order, the `None`s that are
    present rather than omitted, the retryable default — is the same, because
    the generated TypeScript client parses both.
    """
    if retryable is None:
        retryable = code in err.RETRYABLE_CODES
    return {
        "error": {
            "code": code,
            "message": message,
            "details": details,
            "field_errors": field_errors,
            "request_id": rid,
            "retryable": bool(retryable),
        }
    }


def error_response(
    request: Request,
    code: str,
    message: str,
    status: Optional[int] = None,
    details: Optional[Any] = None,
    field_errors: Optional[Dict[str, List[str]]] = None,
    retryable: Optional[bool] = None,
    headers: Optional[Dict[str, str]] = None,
) -> JSONResponse:
    """The envelope as a JSON response, with the catalogue's status.

    **The security headers are set HERE and not only in the middleware.** An
    unhandled exception is turned into a response by Starlette's
    `ServerErrorMiddleware`, which sits *outside* every `@app.middleware("http")`
    this app adds — so the 500 envelope left the process with no `nosniff`, no
    `DENY` and no HSTS, which is the one response most likely to be read by a
    browser as something other than JSON. Setting them on the envelope itself
    covers every failure path regardless of where in the stack it was minted;
    the middleware's `setdefault` pass then leaves them alone.

    An explicit `headers` argument still wins: `Retry-After` and a
    `WWW-Authenticate` are per-failure, and nothing in `security_headers()`
    shares a name with them.
    """
    log_setup.note_error_code(code)  # `$.error.code` on the request's log line
    merged: Dict[str, str] = dict(security_headers())
    # The same reason again for `Cache-Control`: the envelope middleware adds
    # `no-store` to every API answer, and a 500 never passes back through it.
    path = request.url.path
    if path.startswith("/api/") or path.startswith("/auth/"):
        merged["Cache-Control"] = "no-store"
    if headers:
        merged.update(headers)
    return JSONResponse(
        status_code=status or err.STATUS_FOR_CODE.get(code, 400),
        content=envelope(code, message, request_id(request), details, field_errors, retryable),
        headers=merged,
    )


def field_errors_from(errors) -> Dict[str, List[str]]:
    """pydantic's `.errors()` -> the §4.1 `field_errors` map.

    The leading `body` segment FastAPI prepends is dropped so a field reads
    `params.accrual_days` and not `body.params.accrual_days` — the SPA matches
    these against its own form field names. `query` and `path` are KEPT,
    because there the segment is the only thing saying where to look.
    """
    out: Dict[str, List[str]] = {}
    for item in errors:
        loc = tuple(str(p) for p in item.get("loc", ()))
        if loc and loc[0] == "body":
            loc = loc[1:]
        key = ".".join(loc) or "body"
        out.setdefault(key, []).append(item.get("msg", "invalid"))
    return out


def install(app: FastAPI) -> FastAPI:
    """Attach one handler per exception class. Every failure is an envelope."""

    @app.exception_handler(ApiError)
    async def _api_error(request: Request, exc: ApiError):
        headers = None
        retry_after = getattr(exc, "retry_after", None)
        if retry_after is not None:
            headers = {"Retry-After": str(int(retry_after))}
        return error_response(
            request,
            exc.code,
            exc.message,
            status=exc.status,
            details=exc.details,
            field_errors=exc.field_errors,
            retryable=exc.retryable,
            headers=headers,
        )

    @app.exception_handler(RequestValidationError)
    async def _validation_error(request: Request, exc: RequestValidationError):
        return error_response(
            request,
            err.VALIDATION_ERROR,
            "Some of the values sent are not valid.",
            field_errors=field_errors_from(exc.errors()),
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http_error(request: Request, exc: StarletteHTTPException):
        code = STATUS_CODE_MAP.get(exc.status_code, err.INTERNAL_ERROR)
        message = exc.detail if isinstance(exc.detail, str) and exc.detail else code
        return error_response(
            request,
            code,
            message,
            status=exc.status_code,
            headers=dict(exc.headers) if exc.headers else None,
        )

    @app.exception_handler(NotAMember)
    async def _not_a_member(request: Request, exc: NotAMember):
        # Codex CX-BE-01: `with_org` refused an org the user does not belong
        # to. A 404, never a 403 or a 500: an org you are not in does not exist
        # as far as you are concerned (§8). Logged without the ids.
        logger.warning("a session named an organization its user is not a member of")
        return error_response(request, err.NOT_FOUND, "No such organization.")

    @app.exception_handler(SupportPhiRefused)
    async def _support_phi_refused(request: Request, exc: SupportPhiRefused):
        # ADR 0051: a superadmin in support mode without PHI access reached for
        # patient-level data. `src/phi.py` refused before anything was read and
        # wrote its own audit row; the answer says how to get it.
        return error_response(
            request,
            err.PERMISSION_DENIED,
            str(exc),
            details={"required": "support_phi_access"},
        )

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception):
        # The traceback goes to the log with the request id, so a support
        # message quoting "req_…" finds it. It does NOT go to the client.
        rid = request_id(request)
        logger.exception(
            "Unhandled error serving a request (%s)",
            rid,
            extra={"event": log_setup.EVENT_UNHANDLED_EXCEPTION, "request_id": rid},
        )
        return error_response(
            request,
            err.INTERNAL_ERROR,
            "Something went wrong on our side. Quote the request id when reporting this.",
        )

    return app
