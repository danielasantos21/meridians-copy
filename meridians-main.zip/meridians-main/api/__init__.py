"""The FastAPI application (Phase 5a, ADR 0023).

`api.main:app` is the process's entry point. It serves the paths that have
been ported and mounts the Flask app (`web_app`) underneath, so every path
that has not been ported is still answered at the same origin, unchanged.

Run it with `scripts/serve_api.sh`, `python -m api`, or
`uvicorn api.main:app`.
"""
