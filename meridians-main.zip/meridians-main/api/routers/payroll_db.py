"""`/api/v2/payroll-db/*` — the Payroll DB (beta) screen.

The HTTP surface of `src/api/v2/payroll_db_routes.py` (main v1.3.4), which
keeps what these endpoints DO. One gate, `payroll_db:access` (its own right since 0047); USA lines are
added only when the caller also holds QB USA payroll `results`.

Never logged, at any level: nothing here logs a body.
"""

from __future__ import annotations

import io
import json
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse

from src.api.v2 import payroll_db_routes as service
from src.api.v2.limits import LIMIT_READ

from ..deps import Identity, check_csrf, limit, require_permission

router = APIRouter(prefix="/api/v2/payroll-db", tags=["payroll-db"])

CSRF = Depends(check_csrf)
PAYROLL_DB = Depends(require_permission("payroll_db", "access"))
READ = Depends(limit(LIMIT_READ))


async def _raw_body(request: Request) -> Any:
    """The decoded JSON body, or `None`. Silent, like `get_json(silent=True)`."""
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


@router.get("/lines", dependencies=[READ])
async def payroll_db_lines(identity: Identity = PAYROLL_DB) -> Response:
    """Every processed pay line for the org, one per person per pay run."""
    payload = service.lines(identity.org_id, identity.user_id, identity.permissions)
    return identity.apply_cookies(JSONResponse(content=payload.model_dump(mode="json")))


@router.post("/export", dependencies=[CSRF, READ])
async def payroll_db_export(request: Request, identity: Identity = PAYROLL_DB) -> Response:
    """The table the screen is showing, as the house-style workbook."""
    data, filename = service.export(await _raw_body(request), identity.org_id, identity.user_id)
    return identity.apply_cookies(
        StreamingResponse(
            io.BytesIO(data),
            media_type=service.XLSX_MIME,
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )
    )
