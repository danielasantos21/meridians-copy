"""`/api/v2/bi/.../export.xlsx` and `/api/v2/bi/pdf/status`: the Excel downloads (S7A), plus the Executive Report .pptx deck.

The HTTP surface of `src/api/v2/bi_download_routes.py`, which keeps what these endpoints
DO: re-run the question on the server under the caller's own permissions (through the same
choke point as the screen, `<11` masking for members, exact counts for admins), write the
raw-row access-log row BEFORE any bytes leave (fail closed with a 503), and build the
workbook from that result only.

GATES, as on main: `bi:access`; CSRF on every POST; `LIMIT_XLSX` (10/minute) on
each of the four downloads, `LIMIT_READ` on the status check. The caller is a
`bi_store.Actor` built from the signed-in identity ONLY; a query string naming an org or
user is refused with 422.

A card run holds no database connection while the workbook is built. Handlers that read a
body are `async def` and hand the blocking work to a worker thread; the per-person
in-flight slot is taken and released (in a `finally`) inside that worker thread.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from src.api.v2 import bi_content_routes as content
from src.api.v2 import bi_download_routes as dl
from src.api.v2.limits import LIMIT_READ, LIMIT_XLSX

from ..deps import Identity, check_csrf, limit, require_admin_in, require_permission

router = APIRouter(prefix="/api/v2/bi", tags=["bi"])

CSRF = Depends(check_csrf)
BI = Depends(require_permission("bi", "access"))
BI_ADMIN = Depends(require_admin_in("bi"))
READ = Depends(limit(LIMIT_READ))
XLSX = Depends(limit(LIMIT_XLSX))


def _actor(identity: Identity, request: Request):
    return content._actor(
        identity.required_org_id, identity.user_id, identity.org, request.query_params
    )


def _file(identity: Identity, built: tuple) -> Response:
    data, headers = built
    return identity.apply_cookies(Response(content=data, status_code=200, headers=headers))


@router.post("/cards/{card_id:int}/export.xlsx", dependencies=[CSRF, XLSX])
async def bi_card_xlsx(card_id: int, request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _file(identity, await run_in_threadpool(dl.bi_card_xlsx, actor, card_id, raw))


@router.post("/query/export.xlsx", dependencies=[CSRF, XLSX])
async def bi_query_xlsx(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _file(identity, await run_in_threadpool(dl.bi_query_xlsx, actor, raw))


@router.post(
    "/dashboards/{dashboard_id:int}/cards/{dashcard_id:int}/export.xlsx",
    dependencies=[CSRF, XLSX],
)
async def bi_dashcard_xlsx(
    dashboard_id: int, dashcard_id: int, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    built = await run_in_threadpool(dl.bi_dashcard_xlsx, actor, dashboard_id, dashcard_id, raw)
    return _file(identity, built)


@router.post("/dashboards/{dashboard_id:int}/export.xlsx", dependencies=[CSRF, XLSX])
async def bi_dashboard_xlsx(
    dashboard_id: int, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _file(identity, await run_in_threadpool(dl.bi_dashboard_xlsx, actor, dashboard_id, raw))


@router.post("/executive/export.pptx", dependencies=[CSRF, XLSX])
async def bi_executive_pptx(request: Request, identity: Identity = BI_ADMIN) -> Response:
    """The Executive Report deck (PREVIEW ONLY: built from the spec the browser sends). Org admins only (owner, 2026-10-18)."""
    actor = _actor(identity, request)
    declared = request.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > dl.MAX_DECK_BODY:
        raise dl._validation("body", dl.DECK_TOO_LARGE)
    raw = await request.body()
    return _file(identity, await run_in_threadpool(dl.bi_executive_pptx, actor, raw))


@router.get("/pdf/status", dependencies=[READ])
def bi_pdf_status(request: Request, identity: Identity = BI) -> Response:
    out = dl.bi_pdf_status(_actor(identity, request))
    return identity.apply_cookies(JSONResponse(content=out))
