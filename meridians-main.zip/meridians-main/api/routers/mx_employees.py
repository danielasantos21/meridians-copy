"""`/api/v2/config/mx-employees*`, `/api/v2/config/mx-departments` — §3.6.

The HTTP surface of `src/api/v2/mx_employees.py`, which kept every line of what
these endpoints DO: the roster read (active-only unless asked), the two required fields the
Flask form refused without, the soft deactivation, and the one-time seed from
the roster file.

`config:access`, all six — the same gate `/config/mx-employees` carried, which
is what an accountant is granted so they can fix a roster row that is blocking a
payroll run. It is deliberately NOT admin-only: the MX roster is operational
data, not an org-wide setting, and the settings resource next door is where the
admin gate belongs.

Why the bodies are parsed by hand rather than declared as pydantic parameters:
contract §10.1 puts pydantic at the HTTP edge and §4.1 says what a 422 looks
like. `routes.body_of` is that definition — the same models, the same message,
the same `field_errors` keys the Flask form produced as a flash.

Never logged, at any level: employee names, positions, payroll codes.
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src.api.v2 import mx_employees as service
from src.api.v2.limits import LIMIT_READ, LIMIT_WRITE

from ..deps import Identity, check_csrf, limit, require_permission

router = APIRouter(prefix="/api/v2/config", tags=["mx-employees"])

#: Every unsafe method here is behind the §6.1 double-submit check.
CSRF = Depends(check_csrf)
#: `config:access` — the same gate the Jinja roster page carried.
CONFIG = Depends(require_permission("config", "access"))

READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))


async def _raw_body(request: Request) -> Any:
    """The decoded JSON body, or `None`. Silent, like `get_json(silent=True)`."""
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


def _json(model, status: int = 200) -> JSONResponse:
    """A pydantic model as the response body, in `mode="json"` (§10.1)."""
    return JSONResponse(status_code=status, content=model.model_dump(mode="json"))


# ------------------------------------------------------------------ reading
@router.get("/mx-employees", dependencies=[READ])
async def mx_employees_list(request: Request, identity: Identity = CONFIG) -> Response:
    """The org's MX employees, by payroll code — active only unless
    `?include_inactive=true`. 200; 422 for a value that is not a boolean."""
    include_inactive = service.include_inactive_arg(request.query_params)
    return identity.apply_cookies(
        _json(service.employees(identity.required_org_id, identity.user_id, include_inactive))
    )


@router.get("/mx-departments", dependencies=[READ])
async def mx_departments_list(identity: Identity = CONFIG) -> Response:
    """The NetSuite departments a roster row may be assigned to. 200."""
    return identity.apply_cookies(
        _json(service.departments(identity.required_org_id, identity.user_id))
    )


# ------------------------------------------------------------------ writing
@router.post("/mx-employees/import", dependencies=[CSRF, WRITE])
async def mx_employees_import(identity: Identity = CONFIG) -> Response:
    """One-time import from the roster file; answers with how many. 200.

    Declared BEFORE the `{employee_id}` routes so that `import` is never read
    as a payroll code. Starlette matches in declaration order.
    """
    return identity.apply_cookies(_json(service.seed(identity.required_org_id, identity.user_id)))


@router.put("/mx-employees/{employee_id}", dependencies=[CSRF, WRITE])
async def mx_employee_save(
    employee_id: str, request: Request, identity: Identity = CONFIG
) -> Response:
    """Create or replace one roster row. 200 with the row as it now stands."""
    payload = service.save(
        employee_id, await _raw_body(request), identity.required_org_id, identity.user_id
    )
    return identity.apply_cookies(_json(payload))


@router.delete("/mx-employees/{employee_id}", status_code=204, dependencies=[CSRF, WRITE])
async def mx_employee_deactivate(employee_id: str, identity: Identity = CONFIG) -> Response:
    """Take one employee out of the active roster. Nothing is removed. 204."""
    service.deactivate(employee_id, identity.required_org_id, identity.user_id)
    return identity.apply_cookies(Response(status_code=204))


@router.post("/mx-employees/{employee_id}/reactivate", dependencies=[CSRF, WRITE])
async def mx_employee_reactivate(employee_id: str, identity: Identity = CONFIG) -> Response:
    """Put a deactivated employee back on the roster. 200."""
    payload = service.reactivate(employee_id, identity.required_org_id, identity.user_id)
    return identity.apply_cookies(_json(payload))
