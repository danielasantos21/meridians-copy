"""`/api/v2/operations/*` — the Operations (beta) dashboards.

The HTTP surface of `src/api/v2/operations_routes.py` (main v1.3.6-v1.3.7),
which keeps what these endpoints DO: the one-org gate that fails closed before
any eCW connection, the query validation, and the aggregate-only answers.

ONE GATE, EVERY PATH: `operations:access` (its own right since 0047).

`by_alias=True` on every dump: `range.from` is spelled `from_` in Python.

Never logged, at any level: nothing here logs a body.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src.api.v2 import operations_routes as service
from src.api.v2.limits import LIMIT_READ

from ..deps import Identity, limit, require_permission

router = APIRouter(prefix="/api/v2/operations", tags=["operations"])

#: The gate. One object, so a new endpoint cannot quietly be added without it.
OPERATIONS = Depends(require_permission("operations", "access"))
READ = Depends(limit(LIMIT_READ))


def _json(identity: Identity, model) -> Response:
    content = model.model_dump(mode="json", by_alias=True)
    return identity.apply_cookies(JSONResponse(content=content))


@router.get("/kpis", dependencies=[READ])
async def operations_kpis(request: Request, identity: Identity = OPERATIONS) -> Response:
    """No-show, access and volume figures from the eCW snapshot."""
    return _json(identity, service.kpis(identity.required_org_id, request.query_params, identity.user_id))


@router.get("/claims", dependencies=[READ])
async def operations_claims(request: Request, identity: Identity = OPERATIONS) -> Response:
    """Ultrasound or billing figures from eCW claims (`?tab=`)."""
    return _json(identity, service.claims(identity.required_org_id, request.query_params, identity.user_id))


@router.get("/portfolio", dependencies=[READ])
async def operations_portfolio(request: Request, identity: Identity = OPERATIONS) -> Response:
    """Per-facility year-to-date board to a month cutoff."""
    return _json(identity, service.portfolio(identity.required_org_id, request.query_params, identity.user_id))
