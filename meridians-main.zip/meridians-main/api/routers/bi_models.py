"""`/api/v2/bi/{segments,metrics,models}` and `/bi/cards/{id}/dependents` (stage S6A).

The HTTP surface of `src/api/v2/bi_model_routes.py`, which keeps what these endpoints DO.
This module maps paths to those functions: the Flask decorator stack became dependencies
and `flask.g` became an `Identity`.

GATES, as on main:
  * `bi:access` for every read;
  * org ADMIN (instead of that permission, as on main) for segment create / edit / archive
    and the Metabase export. Metrics and models are read-only here;
  * CSRF on every unsafe method; LIMIT_READ / LIMIT_WRITE per endpoint, as on main.
The eCW gate (`_gate(org_id)`) runs inside each service function.

The caller is a `bi_store.Actor` built from the signed-in identity ONLY; a query string or
body that names an org or user is refused with 422.

Never logged, at any level: nothing here logs a body.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from src.api.v2 import bi_content_routes as content
from src.api.v2 import bi_model_routes as models
from src.api.v2.limits import LIMIT_READ, LIMIT_WRITE

from ..deps import Identity, check_csrf, limit, require_admin_in, require_permission

router = APIRouter(prefix="/api/v2/bi", tags=["bi"])

CSRF = Depends(check_csrf)
#: The builder gate: one object, so a new endpoint cannot quietly be added without it.
BI = Depends(require_permission("bi", "access"))
#: Org admin INSTEAD of the permission (main used `require_role("admin")` alone here).
ADMIN = Depends(require_admin_in("bi"))
READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))


def _actor(identity: Identity, request: Request):
    """The caller as a store Actor. A query string naming an identity is refused first."""
    return content._actor(
        identity.required_org_id, identity.user_id, identity.org, request.query_params
    )


def _json(identity: Identity, body: dict, status: int = 200) -> Response:
    return identity.apply_cookies(JSONResponse(content=body, status_code=status))


def _empty(identity: Identity) -> Response:
    return identity.apply_cookies(Response(status_code=204))


# ------------------------------------------------------------------ reads
@router.get("/segments", dependencies=[READ])
def bi_segments_list(request: Request, identity: Identity = BI) -> Response:
    return _json(identity, models.bi_segments_list(_actor(identity, request), request.query_params))


@router.get("/segments/{segment_id:int}", dependencies=[READ])
def bi_segment_get(segment_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, models.bi_segment_get(_actor(identity, request), segment_id))


@router.get("/segments/{segment_id:int}/revisions", dependencies=[READ])
def bi_segment_revisions(segment_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, models.bi_segment_revisions(_actor(identity, request), segment_id))


@router.get("/segments/{segment_id:int}/dependents", dependencies=[READ])
def bi_segment_dependents(segment_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, models.bi_segment_dependents(_actor(identity, request), segment_id))


@router.get("/metrics", dependencies=[READ])
def bi_metrics_list(request: Request, identity: Identity = BI) -> Response:
    return _json(identity, models.bi_metrics_list(_actor(identity, request), request.query_params))


@router.get("/models", dependencies=[READ])
def bi_models_list(request: Request, identity: Identity = BI) -> Response:
    return _json(identity, models.bi_models_list(_actor(identity, request)))


@router.get("/cards/{card_id:int}/dependents", dependencies=[READ])
def bi_card_dependents(card_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, models.bi_card_dependents(_actor(identity, request), card_id))


# ----------------------------------------------------------------- writes
@router.post("/segments", dependencies=[CSRF, WRITE])
async def bi_segment_create(request: Request, identity: Identity = ADMIN) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(models.bi_segment_create, actor, raw), 201)


@router.put("/segments/{segment_id:int}", dependencies=[CSRF, WRITE])
async def bi_segment_update(
    segment_id: int, request: Request, identity: Identity = ADMIN
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(
        identity, await run_in_threadpool(models.bi_segment_update, actor, segment_id, raw)
    )


@router.delete("/segments/{segment_id:int}", dependencies=[CSRF, WRITE])
def bi_segment_archive(segment_id: int, request: Request, identity: Identity = ADMIN) -> Response:
    models.bi_segment_archive(_actor(identity, request), segment_id)
    return _empty(identity)


# ----------------------------------------------------------------- export
@router.get("/segments/{segment_id:int}/export/metabase", dependencies=[READ])
def bi_segment_export(segment_id: int, request: Request, identity: Identity = ADMIN) -> Response:
    out = models.bi_segment_export(_actor(identity, request), segment_id, request.query_params)
    return _json(identity, out)
