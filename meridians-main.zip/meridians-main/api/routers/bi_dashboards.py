"""`/api/v2/bi/*` dashboards and drill-through: dashboards (CRUD, revisions, run one
card, filter values, Metabase export, PDF), "who uses this card", "See these rows" and
the merged dashboard-card query.

The HTTP surface of `src/api/v2/bi_dashboard_routes.py` (S5A) and
`src/api/v2/bi_drill_routes.py` (S5B), which keep what these endpoints DO. This module
maps paths to those functions: the Flask decorator stack became dependencies and
`flask.g` became an `Identity`.

GATES, as on main:
  * `bi:access` for everything except
  * org ADMIN (instead of that permission, as on main) for the Metabase export;
  * CSRF on every unsafe method; LIMIT_READ / LIMIT_WRITE / LIMIT_DASH_RUN /
    LIMIT_DRILL_ROWS / LIMIT_PDF per endpoint, as declared on main.
The eCW gate (`_gate(org_id)`) runs inside each service function.

The caller is a `bi_store.Actor` built here from the signed-in identity ONLY; the org and
user are never read from a body or a query string (a query string that names one is
refused with 422, before the org is looked at).

Raw-row access log (`bi_drill_audit`): the observer is registered by `api.main.create_app`
(`bi_drill_routes.register_observer`). Every service function that can send raw rows passes
the actor and an explicit `run_origin` down to it; no request global is involved.

Blocking work stays off the event loop: plain `def` for handlers that read no body,
`async def` + `run_in_threadpool` for those that do. The one-card-at-a-time in-flight
counter lives in the service module and is released in a `finally`, in the worker thread.

Never logged, at any level: nothing here logs a body.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from src import auth as _auth
from src.api.v2 import bi_content_routes as content
from src.api.v2 import bi_dashboard_routes as dash
from src.api.v2 import bi_drill_routes as drill
from src.api.v2.limits import LIMIT_DASH_RUN, LIMIT_DRILL_ROWS, LIMIT_PDF, LIMIT_READ, LIMIT_WRITE

from ..deps import Identity, check_csrf, limit, require_admin_in, require_permission

router = APIRouter(prefix="/api/v2/bi", tags=["bi"])

CSRF = Depends(check_csrf)
#: The builder gate: one object, so a new endpoint cannot quietly be added without it.
BI = Depends(require_permission("bi", "access"))
#: Org admin INSTEAD of the permission (main used `require_role("admin")` alone here).
ADMIN = Depends(require_admin_in("bi"))
READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))
DASH_RUN = Depends(limit(LIMIT_DASH_RUN))
DRILL_ROWS = Depends(limit(LIMIT_DRILL_ROWS))
PDF = Depends(limit(LIMIT_PDF))


def _actor(identity: Identity, request: Request):
    """The caller as a store Actor. A query string naming an identity is refused first."""
    return content._actor(
        identity.required_org_id, identity.user_id, identity.org, request.query_params
    )


def _fresh_cookies(identity: Identity) -> dict | None:
    """The session cookies a silent refresh made on THIS request, by cookie name, so the
    server-made PDF signs in with them instead of the (stale) ones the browser sent.
    Replaces main's `g.fresh_auth_cookies`; None when no refresh happened."""
    fresh = identity.refreshed
    if not fresh:
        return None
    return {
        _auth.ACCESS_TOKEN_COOKIE: fresh.get("access_token"),
        _auth.REFRESH_TOKEN_COOKIE: fresh.get("refresh_token"),
    }


def _json(identity: Identity, body: dict, status: int = 200) -> Response:
    return identity.apply_cookies(JSONResponse(content=body, status_code=status))


def _empty(identity: Identity) -> Response:
    return identity.apply_cookies(Response(status_code=204))


# ------------------------------------------------------------------ dashboards
@router.post("/dashboards", dependencies=[CSRF, WRITE])
async def bi_dashboard_create(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(dash.bi_dashboard_create, actor, raw), 201)


@router.get("/dashboards/{dashboard_id:int}", dependencies=[READ])
def bi_dashboard_get(dashboard_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, dash.bi_dashboard_get(_actor(identity, request), dashboard_id))


@router.put("/dashboards/{dashboard_id:int}", dependencies=[CSRF, WRITE])
async def bi_dashboard_save(
    dashboard_id: int, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(
        identity, await run_in_threadpool(dash.bi_dashboard_save, actor, dashboard_id, raw)
    )


@router.delete("/dashboards/{dashboard_id:int}", dependencies=[CSRF, WRITE])
def bi_dashboard_delete(dashboard_id: int, request: Request, identity: Identity = BI) -> Response:
    dash.bi_dashboard_delete(_actor(identity, request), dashboard_id)
    return _empty(identity)


@router.post("/dashboards/{dashboard_id:int}/duplicate", dependencies=[CSRF, WRITE])
async def bi_dashboard_duplicate(
    dashboard_id: int, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    out = await run_in_threadpool(dash.bi_dashboard_duplicate, actor, dashboard_id, raw)
    return _json(identity, out, 201)


@router.post("/dashboards/{dashboard_id:int}/trash", dependencies=[CSRF, WRITE])
def bi_dashboard_trash(dashboard_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, dash.bi_dashboard_trash(_actor(identity, request), dashboard_id))


@router.post("/dashboards/{dashboard_id:int}/restore", dependencies=[CSRF, WRITE])
async def bi_dashboard_restore(
    dashboard_id: int, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(
        identity, await run_in_threadpool(dash.bi_dashboard_restore, actor, dashboard_id, raw)
    )


@router.get("/dashboards/{dashboard_id:int}/revisions", dependencies=[READ])
def bi_dashboard_revisions(
    dashboard_id: int, request: Request, identity: Identity = BI
) -> Response:
    return _json(identity, dash.bi_dashboard_revisions(_actor(identity, request), dashboard_id))


@router.post("/dashboards/{dashboard_id:int}/revert", dependencies=[CSRF, WRITE])
async def bi_dashboard_revert(
    dashboard_id: int, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(
        identity, await run_in_threadpool(dash.bi_dashboard_revert, actor, dashboard_id, raw)
    )


# ----------------------------------------------------------------- run, values
@router.post(
    "/dashboards/{dashboard_id:int}/cards/{dashcard_id:int}/run", dependencies=[CSRF, DASH_RUN]
)
async def bi_dashcard_run(
    dashboard_id: int, dashcard_id: int, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    out = await run_in_threadpool(dash.bi_dashcard_run, actor, dashboard_id, dashcard_id, raw)
    return _json(identity, out)


@router.get("/dashboards/{dashboard_id:int}/params/{pid}/values", dependencies=[DASH_RUN])
def bi_param_values(
    dashboard_id: int, pid: str, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    return _json(identity, dash.bi_param_values(actor, dashboard_id, pid, request.query_params))


# ---------------------------------------------------------------------- export
@router.get("/dashboards/{dashboard_id:int}/export/metabase", dependencies=[READ])
def bi_dashboard_export(
    dashboard_id: int, request: Request, identity: Identity = ADMIN
) -> Response:
    out = dash.bi_dashboard_export(_actor(identity, request), dashboard_id, request.query_params)
    return _json(identity, out)


# ------------------------------------------------------------------------- pdf
@router.post("/dashboards/{dashboard_id:int}/pdf", dependencies=[CSRF, PDF])
async def bi_dashboard_pdf(
    dashboard_id: int, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    pdf, headers = await run_in_threadpool(
        dash.bi_dashboard_pdf, actor, dashboard_id, raw, request.cookies, _fresh_cookies(identity)
    )
    return identity.apply_cookies(Response(content=pdf, status_code=200, headers=headers))


# ------------------------------------------------------------ who uses a card
@router.get("/cards/{card_id:int}/dashboards", dependencies=[READ])
def bi_card_dashboards(card_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, dash.bi_card_dashboards(_actor(identity, request), card_id))


# ----------------------------------------------------------------------- drill
@router.post("/drill/rows", dependencies=[CSRF, DRILL_ROWS])
async def bi_drill_rows(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(drill.bi_drill_rows, actor, raw))


@router.post(
    "/dashboards/{dashboard_id:int}/cards/{dashcard_id:int}/query", dependencies=[CSRF, DASH_RUN]
)
async def bi_dashcard_query(
    dashboard_id: int, dashcard_id: int, request: Request, identity: Identity = BI
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    out = await run_in_threadpool(drill.bi_dashcard_query, actor, dashboard_id, dashcard_id, raw)
    return _json(identity, out)
