"""`/api/v2/bi/executive/tables` and `/notes`: the Executive Report's shared Highlights, Initiatives and Notes boxes.

The HTTP surface of `src/api/v2/bi_exec_routes.py`. Org ADMINS only, and only while the
`bi` module is on for the organization (`require_admin_in("bi")`). CSRF on the write;
`LIMIT_READ` / `LIMIT_EXEC_TABLES`. The caller is a `bi_store.Actor` built from the signed-in
identity ONLY; a query string naming an org or user is refused with 422.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from src.api.v2 import bi_content_routes as content
from src.api.v2 import bi_exec_routes as ex
from src.api.v2.limits import LIMIT_EXEC_TABLES, LIMIT_READ

from ..deps import Identity, check_csrf, limit, require_admin_in

router = APIRouter(prefix="/api/v2/bi", tags=["bi"])

CSRF = Depends(check_csrf)
BI_ADMIN = Depends(require_admin_in("bi"))
READ = Depends(limit(LIMIT_READ))
EXEC_TABLES = Depends(limit(LIMIT_EXEC_TABLES))


def _actor(identity: Identity, request: Request):
    return content._actor(
        identity.required_org_id, identity.user_id, identity.org, request.query_params
    )


def _json(identity: Identity, body: dict, status: int = 200) -> Response:
    return identity.apply_cookies(JSONResponse(content=body, status_code=status))


@router.get("/executive/tables", dependencies=[READ])
def bi_exec_tables_get(request: Request, identity: Identity = BI_ADMIN) -> Response:
    actor = _actor(identity, request)
    return _json(identity, ex.bi_exec_tables_get(actor, request.query_params))


@router.put("/executive/tables/{kind}", dependencies=[CSRF, EXEC_TABLES])
async def bi_exec_table_put(kind: str, request: Request, identity: Identity = BI_ADMIN) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    body = await run_in_threadpool(ex.bi_exec_table_put, actor, kind, request.query_params, raw)
    return _json(identity, body)


@router.get("/executive/notes", dependencies=[READ])
def bi_exec_notes_get(request: Request, identity: Identity = BI_ADMIN) -> Response:
    actor = _actor(identity, request)
    return _json(identity, ex.bi_exec_notes_get(actor, request.query_params))


@router.put("/executive/notes/{note_id}", dependencies=[CSRF, EXEC_TABLES])
async def bi_exec_note_put(note_id: str, request: Request, identity: Identity = BI_ADMIN) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    body = await run_in_threadpool(ex.bi_exec_note_put, actor, note_id, request.query_params, raw)
    return _json(identity, body)
