"""`/api/v2/qb-usa-payroll/*` — the third runs resource (§3.2, §3A, §12).

The HTTP surface of `src/api/v2/qb_usa_runs.py`, the richest of the three
processes and the one that validated the contract: upload → roster review →
preview with gates → declare the failures → execute → poll → artifacts. The
module kept every line of what these endpoints DO — the atomic upload that
removes the whole run directory rather than half-accepting a period, the
`persist` distinction between a permanent roster row and a run-only override,
the 409 that refuses a preview while a prompt is outstanding (because "200 with
an empty journal list" is the misreading that books a partial payroll), the
re-evaluation of every gate against the CURRENT parse at execute time, and
`state_machine.assert_action` as the only opinion about what may happen next.

THE WORK DID NOT MOVE. `execute` still hands the run to `web_app`'s own worker
on the same `threading.Thread` the Jinja wizard starts, and `run_id` is still
that wizard's `session_id` addressing the same `process_runs` row. This module
changed which framework turns that into a response, and nothing else. (On RDS,
Phase 11 C5: the parse and the export run as the manifest's jobs through
`workers.run_job` instead; `src/api/v2/qb_usa_runs.py` says how.)

TWO PERMISSION LEVELS, per operation, exactly as `v2_permission` applied them:
`qb_usa_payroll:access` to run the booking, `qb_usa_payroll:results` to see
what it produced. §12.11 is that they are genuinely different grants, and the
`Caller` carries the permissions so the envelope can say so before the upload
rather than 403-ing after the money is booked.

WHY THE MULTIPART IS PARSED BY WERKZEUG rather than declared as `UploadFile`:
`api/uploads.py` says, and `qb_usa_runs._classify_uploads` is then one rule
about which file is which for both surfaces.

DOWNLOADS ARE MINTED, NOT PROXIED (§7.2). The 201 carries a short-lived signed
URL and an audit row records the mint; the bytes never pass through this
process. The caller's address and user agent reach that row on the `Caller`.

Never logged, at any level: a filename, an employee name, a figure, or a
signed URL.
"""

from __future__ import annotations

import json

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src.api.v2 import qb_usa_runs as service
from src.api.v2.limits import LIMIT_READ
from src.api.v2.runs_common import Caller

from .. import errors as api_errors
from ..deps import Identity, check_csrf, client_address, limit, require_permission
from ..uploads import close_uploads, form_and_files

router = APIRouter(prefix="/api/v2", tags=["runs"])

#: The path every operation but the accrual guess hangs off.
ROOT = f"/{service.PROCESS}/runs"

#: Every unsafe method here is behind the §6.1 double-submit check.
CSRF = Depends(check_csrf)

#: Declared on every route that parses a multipart body: it closes the
#: `FileStorage` temp files once the handler has answered (P5AR2-10). `create`
#: was the one route that called `form_and_files` without it, so the one upload
#: endpoint of the one process that uploads several workbooks at a time leaked a
#: descriptor per part (P5AR3-01). `tests/test_fastapi_app.py` now asserts the
#: pairing across every router, so a new route cannot forget it either.
CLOSE_UPLOADS = Depends(close_uploads)

#: §9's per-operation limits.
#:
#: `LIMIT_READ` is the shared string flask-limiter is given for reads. **The two
#: write limits are NEW** (P5AR3-08): the Jinja wizard's POSTs carried no
#: per-view limit at all, only the application default, so there is nothing on
#: the Flask side for these to match. They are this surface's own judgement —
#: ten creates and thirty steps a minute is more than a person doing a payroll
#: run can produce and far less than a loop can — and if they turn out to be
#: wrong the evidence will be a 429 in a run that was going fine, not a silent
#: divergence between two surfaces.
LIMIT_CREATE = "10/minute"
LIMIT_STEP = "30/minute"

ACCESS = Depends(require_permission(service.PERMISSION, "access"))
RESULTS = Depends(require_permission(service.PERMISSION, "results"))
READ = Depends(limit(LIMIT_READ))


def _json(model, status: int = 200) -> JSONResponse:
    """A pydantic model as the response body, in `mode="json"` (§10.1)."""
    return JSONResponse(status_code=status, content=model.model_dump(mode="json"))


async def _body(request: Request):
    """The decoded JSON body, or `None` when there is not one.

    Silent, like `flask.request.get_json(silent=True)`: a body that is not
    JSON at all must fall out as the same 422 a missing field gets, not as a
    parse error the caller can tell apart.
    """
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


def _caller(request: Request, identity: Identity) -> Caller:
    """The `Caller` the service functions take.

    The org comes from the membership row `require_org` resolved on THIS
    request and never from a path or a query parameter (§8); the address and
    user agent come from the transport because a signed-URL mint is audited
    (§7.2); the request id is the one `api/errors.py` already minted, so a run
    envelope's `error.request_id` is the SAME id a §4 error would have quoted
    for this request rather than a second, unrelated one.

    The address is `client_address`, not `request.client` (P5AR3-07). Behind
    CloudFront and behind the Next.js proxy `request.client.host` is a hop, not
    a caller — on Render it is a value the caller itself chose — so an audit row
    for a signed-URL mint recorded the infrastructure rather than who asked. It
    is the same function the rate limiter keys on, for the same reason, and now
    the audit trail and the limiter agree about who a caller is.
    """
    return Caller(
        org_id=identity.org_id or "",
        user=identity.user,
        permissions=identity.permissions or {},
        ip=client_address(request),
        user_agent=request.headers.get("User-Agent"),
        request_id=api_errors.request_id(request),
    )


# ------------------------------------------------------- 3A step 0: accrual
@router.get(f"/{service.PROCESS}/accrual-preview", dependencies=[READ])
async def accrual_preview(request: Request, identity: Identity = ACCESS) -> Response:
    """Guess the month's accrual days before any file exists.

    Deliberately NOT under `/runs`: it is asked before a run exists (§3.2).
    """
    payload = service.accrual_preview(_caller(request, identity), request.query_params)
    return identity.apply_cookies(_json(payload))


# -------------------------------------------------------- 3A step 1: create
@router.post(
    ROOT, status_code=201, dependencies=[CSRF, CLOSE_UPLOADS, Depends(limit(LIMIT_CREATE))]
)
async def create_run(request: Request, identity: Identity = ACCESS) -> Response:
    """Upload, classify by content, parse, and say what is next.

    201 for a new run; 200 for a repeated `Idempotency-Key`, which is a retry
    and not a second booking of the period (§3.3, §12.9).
    """
    form, files = await form_and_files(request)
    envelope, status = service.create_run(
        _caller(request, identity),
        form,
        files,
        idempotency_key=request.headers.get("Idempotency-Key"),
    )
    return identity.apply_cookies(_json(envelope, status))


# ------------------------------------------- 3.2 / 11: history, paginated
@router.get(ROOT, dependencies=[READ])
async def list_runs(request: Request, identity: Identity = RESULTS) -> Response:
    """Run history, keyset-paginated (§11)."""
    args = request.query_params
    payload = service.list_runs(_caller(request, identity), args, cursor=args.get("cursor"))
    return identity.apply_cookies(_json(payload))


# ---------------------------------------------- 3A step 7: the poll target
@router.get(f"{ROOT}/{{run_id}}", dependencies=[READ])
async def get_run(run_id: str, request: Request, identity: Identity = ACCESS) -> Response:
    """The canonical envelope. Polled every 2 s while a run is in flight."""
    payload = service.get_run(_caller(request, identity), run_id)
    return identity.apply_cookies(_json(payload))


# -------------------------------------------------- 3.2: cancel / abandon
@router.delete(
    f"{ROOT}/{{run_id}}", status_code=204, dependencies=[CSRF, Depends(limit(LIMIT_STEP))]
)
async def cancel_run(run_id: str, request: Request, identity: Identity = ACCESS) -> Response:
    """Abandon a non-terminal run and purge its uploads. 204."""
    service.cancel_run(_caller(request, identity), run_id)
    return identity.apply_cookies(Response(status_code=204))


# ------------------------------------------------------ 3A step 2: review
@router.get(f"{ROOT}/{{run_id}}/review", dependencies=[READ])
async def get_review(run_id: str, request: Request, identity: Identity = ACCESS) -> Response:
    """Roster prompts and change alerts (§3.4)."""
    payload = service.get_review(_caller(request, identity), run_id)
    return identity.apply_cookies(_json(payload))


@router.post(f"{ROOT}/{{run_id}}/review", dependencies=[CSRF, Depends(limit(LIMIT_STEP))])
async def submit_review(run_id: str, request: Request, identity: Identity = ACCESS) -> Response:
    """Apply the answers and re-run the processor with them (§3A step 3)."""
    payload = service.submit_review(_caller(request, identity), run_id, await _body(request))
    return identity.apply_cookies(_json(payload))


# ----------------------------------------------------- 3A step 4: preview
@router.get(f"{ROOT}/{{run_id}}/preview", dependencies=[READ])
async def get_preview(run_id: str, request: Request, identity: Identity = ACCESS) -> Response:
    """The journal entries, the gate results, and why each one failed."""
    payload = service.get_preview(_caller(request, identity), run_id)
    return identity.apply_cookies(_json(payload))


# ------------------------------------------------ 3A step 5: declarations
@router.post(f"{ROOT}/{{run_id}}/declarations", dependencies=[CSRF, Depends(limit(LIMIT_STEP))])
async def declare_gates(run_id: str, request: Request, identity: Identity = ACCESS) -> Response:
    """Declare the gate failures the accountant expects."""
    payload = service.declare_gates(_caller(request, identity), run_id, await _body(request))
    return identity.apply_cookies(_json(payload))


# -------------------------------------------------- 3A step 6: execute
@router.post(
    f"{ROOT}/{{run_id}}/execute",
    status_code=202,
    dependencies=[CSRF, Depends(limit(LIMIT_CREATE))],
)
async def execute_run(run_id: str, request: Request, identity: Identity = ACCESS) -> Response:
    """Start the export. This is the only place money leaves (§2.2). 202."""
    payload = service.execute_run(
        _caller(request, identity),
        run_id,
        await _body(request),
        idempotency_key=request.headers.get("Idempotency-Key"),
    )
    return identity.apply_cookies(_json(payload, 202))


@router.post(f"{ROOT}/{{run_id}}/quickbooks", dependencies=[CSRF, Depends(limit(LIMIT_CREATE))])
async def push_to_quickbooks(
    run_id: str, request: Request, identity: Identity = ACCESS
) -> Response:
    """Push this run's journal entries to QuickBooks Online.

    200 with the per-journal results where the push runs in the request; 202
    with the run's envelope where it is the `qbo_push` job (Phase 11 E2: RDS
    with qb-usa on `WORKER_PROCESSES`), which the client then polls.
    """
    payload = service.push_to_quickbooks(_caller(request, identity), run_id)
    queued = isinstance(payload, service.sc.QBUSAPayrollRun)
    return identity.apply_cookies(_json(payload, 202 if queued else 200))


# ------------------------------------------------------------- 12.8 retry
@router.post(
    f"{ROOT}/{{run_id}}/retry", status_code=202, dependencies=[CSRF, Depends(limit(LIMIT_CREATE))]
)
async def retry_run(run_id: str, request: Request, identity: Identity = ACCESS) -> Response:
    """Read a blocked run's uploads again, once the fix is in (§12.8). 202.

    Andres, 2026-09-25: every process blocks with an error code and can be
    re-run. `retry` is offered only from `blocked` (the roster empty, the
    benefit overrides unreadable); from anywhere else it is `409
    RUN_STATE_INVALID`. It re-parses, landing on the review or the preview; it
    never books.
    """
    payload = service.retry_run(
        _caller(request, identity),
        run_id,
        idempotency_key=request.headers.get("Idempotency-Key"),
    )
    return identity.apply_cookies(_json(payload, 202))


# ------------------------------------------------ 3A step 8: artifacts
@router.get(f"{ROOT}/{{run_id}}/artifacts", dependencies=[READ])
async def artifacts(run_id: str, request: Request, identity: Identity = RESULTS) -> Response:
    """What this run produced (§3.7)."""
    payload = service.artifacts(_caller(request, identity), run_id)
    return identity.apply_cookies(_json(payload))


@router.post(
    f"{ROOT}/{{run_id}}/artifacts/{{artifact_id}}/download-url",
    status_code=201,
    dependencies=[CSRF, Depends(limit(LIMIT_STEP))],
)
async def download_url(
    run_id: str, artifact_id: str, request: Request, identity: Identity = RESULTS
) -> Response:
    """Mint a short-lived signed URL and audit the mint (§7.2). 201."""
    payload = service.download_url(_caller(request, identity), run_id, artifact_id)
    return identity.apply_cookies(_json(payload, 201))


@router.post(
    f"{ROOT}/{{run_id}}/artifacts/bundle",
    status_code=201,
    dependencies=[CSRF, Depends(limit(LIMIT_CREATE))],
)
async def bundle(run_id: str, request: Request, identity: Identity = RESULTS) -> Response:
    """Build (or refresh) the whole-run ZIP and sign it for 300 s (§7.2)."""
    payload = service.bundle(_caller(request, identity), run_id)
    return identity.apply_cookies(_json(payload, 201))
