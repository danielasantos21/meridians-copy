"""`/api/v2/bi/*` saved content and discovery: collections, cards, items, trash,
revisions, run, Metabase export, search, home, bookmarks, views, pins, snippets.

The HTTP surface of `src/api/v2/bi_content_routes.py` (S4A) and
`src/api/v2/bi_discover_routes.py` (S4B), which keep what these endpoints DO.
This module maps paths to those functions: the Flask decorator stack became
dependencies and `flask.g` became an `Identity`.

GATES, as on main:
  * `bi:access` for everything except
  * org ADMIN (instead of that permission, as on main) for the Metabase export
    and the SQL snippet routes;
  * CSRF on every unsafe method; LIMIT_READ / LIMIT_WRITE / LIMIT_BI per
    endpoint, as declared on main.

The caller is a `bi_store.Actor` built here from the signed-in identity ONLY; the
org and user are never read from a body or a query string (a query string that
names one is refused with 422, before the org is looked at).

Blocking work stays off the event loop: plain `def` for handlers that read no
body, `async def` + `run_in_threadpool` for those that do.

Never logged, at any level: nothing here logs a body.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from src.api.v2 import bi_content_routes as content
from src.api.v2 import bi_discover_routes as discover
from src.api.v2.limits import LIMIT_BI, LIMIT_READ, LIMIT_WRITE

from ..deps import Identity, check_csrf, limit, require_admin_in, require_permission

router = APIRouter(prefix="/api/v2/bi", tags=["bi"])

CSRF = Depends(check_csrf)
#: The builder gate: one object, so a new endpoint cannot quietly be added without it.
BI = Depends(require_permission("bi", "access"))
#: Org admin INSTEAD of the permission (main used `require_role("admin")` alone here).
ADMIN = Depends(require_admin_in("bi"))
READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))
BUILD = Depends(limit(LIMIT_BI))


def _actor(identity: Identity, request: Request):
    """The caller as a store Actor. A query string naming an identity is refused first."""
    return content._actor(
        identity.required_org_id, identity.user_id, identity.org, request.query_params
    )


def _json(identity: Identity, body: dict, status: int = 200) -> Response:
    return identity.apply_cookies(JSONResponse(content=body, status_code=status))


def _empty(identity: Identity) -> Response:
    return identity.apply_cookies(Response(status_code=204))


# ------------------------------------------------------------------ collections
@router.get("/collections/tree", dependencies=[READ])
def bi_collection_tree(request: Request, identity: Identity = BI) -> Response:
    return _json(identity, content.bi_collection_tree(_actor(identity, request)))


@router.get("/collections/{cid}", dependencies=[READ])
def bi_collection_get(cid: str, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, content.bi_collection_get(_actor(identity, request), cid))


@router.post("/collections", dependencies=[CSRF, WRITE])
async def bi_collection_create(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    out = await run_in_threadpool(content.bi_collection_create, actor, raw)
    return _json(identity, out, 201)


@router.patch("/collections/{cid:int}", dependencies=[CSRF, WRITE])
async def bi_collection_update(cid: int, request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_collection_update, actor, cid, raw))


@router.post("/collections/{cid:int}/trash", dependencies=[CSRF, WRITE])
def bi_collection_trash(cid: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, content.bi_collection_trash(_actor(identity, request), cid))


@router.post("/collections/{cid:int}/restore", dependencies=[CSRF, WRITE])
async def bi_collection_restore(cid: int, request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_collection_restore, actor, cid, raw))


@router.delete("/collections/{cid:int}", dependencies=[CSRF, WRITE])
def bi_collection_delete(cid: int, request: Request, identity: Identity = BI) -> Response:
    content.bi_collection_delete(_actor(identity, request), cid)
    return _empty(identity)


# ------------------------------------------------------------------------ cards
@router.post("/cards", dependencies=[CSRF, WRITE])
async def bi_card_create(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_card_create, actor, raw), 201)


@router.get("/cards/{card_id:int}", dependencies=[READ])
def bi_card_get(card_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, content.bi_card_get(_actor(identity, request), card_id))


@router.put("/cards/{card_id:int}", dependencies=[CSRF, WRITE])
async def bi_card_update(card_id: int, request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_card_update, actor, card_id, raw))


@router.delete("/cards/{card_id:int}", dependencies=[CSRF, WRITE])
def bi_card_delete(card_id: int, request: Request, identity: Identity = BI) -> Response:
    content.bi_card_delete(_actor(identity, request), card_id)
    return _empty(identity)


@router.post("/cards/{card_id:int}/duplicate", dependencies=[CSRF, WRITE])
async def bi_card_duplicate(card_id: int, request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    out = await run_in_threadpool(content.bi_card_duplicate, actor, card_id, raw)
    return _json(identity, out, 201)


@router.post("/cards/{card_id:int}/trash", dependencies=[CSRF, WRITE])
def bi_card_trash(card_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, content.bi_card_trash(_actor(identity, request), card_id))


@router.post("/cards/{card_id:int}/restore", dependencies=[CSRF, WRITE])
async def bi_card_restore(card_id: int, request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_card_restore, actor, card_id, raw))


@router.get("/cards/{card_id:int}/revisions", dependencies=[READ])
def bi_card_revisions(card_id: int, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, content.bi_card_revisions(_actor(identity, request), card_id))


@router.post("/cards/{card_id:int}/revert", dependencies=[CSRF, WRITE])
async def bi_card_revert(card_id: int, request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_card_revert, actor, card_id, raw))


# -------------------------------------------------------------------------- run
@router.post("/cards/{card_id:int}/run", dependencies=[CSRF, BUILD])
async def bi_card_run(card_id: int, request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_card_run, actor, card_id, raw))


# ----------------------------------------------------------------------- export
@router.get("/cards/{card_id:int}/export/metabase", dependencies=[READ])
def bi_card_export(card_id: int, request: Request, identity: Identity = ADMIN) -> Response:
    out = content.bi_card_export(_actor(identity, request), card_id, request.query_params)
    return _json(identity, out)


# ------------------------------------------------------------------ bulk, trash
@router.post("/items/move", dependencies=[CSRF, WRITE])
async def bi_items_move(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_items_move, actor, raw))


@router.post("/items/trash", dependencies=[CSRF, WRITE])
async def bi_items_trash(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_items_trash, actor, raw))


@router.post("/items/restore", dependencies=[CSRF, WRITE])
async def bi_items_restore(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(content.bi_items_restore, actor, raw))


@router.get("/trash", dependencies=[READ])
def bi_trash_list(request: Request, identity: Identity = BI) -> Response:
    return _json(identity, content.bi_trash_list(_actor(identity, request)))


# ------------------------------------------------------------------ home, search
@router.get("/home", dependencies=[READ])
def bi_home(request: Request, identity: Identity = BI) -> Response:
    return _json(identity, discover.bi_home(_actor(identity, request)))


@router.get("/search", dependencies=[READ])
def bi_search(request: Request, identity: Identity = BI) -> Response:
    return _json(identity, discover.bi_search(_actor(identity, request), request.query_params))


# --------------------------------------------------------------------- bookmarks
@router.get("/bookmarks", dependencies=[READ])
def bi_bookmarks_list(request: Request, identity: Identity = BI) -> Response:
    return _json(identity, discover.bi_bookmarks_list(_actor(identity, request)))


@router.put("/bookmarks", dependencies=[CSRF, WRITE])
async def bi_bookmark_add(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(discover.bi_bookmark_add, actor, raw))


@router.delete("/bookmarks/{kind}/{item_id:int}", dependencies=[CSRF, WRITE])
def bi_bookmark_remove(
    kind: str, item_id: int, request: Request, identity: Identity = BI
) -> Response:
    discover.bi_bookmark_remove(_actor(identity, request), kind, item_id)
    return _empty(identity)


# ------------------------------------------------------------------------ views
@router.post("/views", dependencies=[CSRF, WRITE])
async def bi_view_record(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    await run_in_threadpool(discover.bi_view_record, actor, raw)
    return _empty(identity)


# ------------------------------------------------------------------------- pins
@router.put("/items/pin", dependencies=[CSRF, WRITE])
async def bi_item_pin(request: Request, identity: Identity = BI) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(discover.bi_item_pin, actor, raw))


# --------------------------------------------------------------------- snippets
@router.get("/snippets", dependencies=[READ])
def bi_snippets_list(request: Request, identity: Identity = ADMIN) -> Response:
    return _json(identity, discover.bi_snippets_list(_actor(identity, request)))


@router.post("/snippets", dependencies=[CSRF, WRITE])
async def bi_snippet_create(request: Request, identity: Identity = ADMIN) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    return _json(identity, await run_in_threadpool(discover.bi_snippet_create, actor, raw), 201)


@router.get("/snippets/{snippet_id:int}", dependencies=[READ])
def bi_snippet_get(snippet_id: int, request: Request, identity: Identity = ADMIN) -> Response:
    return _json(identity, discover.bi_snippet_get(_actor(identity, request), snippet_id))


@router.patch("/snippets/{snippet_id:int}", dependencies=[CSRF, WRITE])
async def bi_snippet_update(
    snippet_id: int, request: Request, identity: Identity = ADMIN
) -> Response:
    actor = _actor(identity, request)
    raw = await request.body()
    out = await run_in_threadpool(discover.bi_snippet_update, actor, snippet_id, raw)
    return _json(identity, out)


@router.delete("/snippets/{snippet_id:int}", dependencies=[CSRF, WRITE])
def bi_snippet_archive(snippet_id: int, request: Request, identity: Identity = ADMIN) -> Response:
    discover.bi_snippet_archive(_actor(identity, request), snippet_id)
    return _empty(identity)
