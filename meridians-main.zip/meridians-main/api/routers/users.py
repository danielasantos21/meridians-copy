"""`/api/v2/org/members`, `/api/v2/org/roles`, `/api/v2/org/invites` — §3.7.

The HTTP surface of `src/api/v2/user_routes.py`, which kept every line of what
these endpoints DO: the one list assembled from two tables, the four typed
guards (no self-removal, no last admin, no deleting a role somebody holds, no
duplicate role name), the matrix written row at a time and scoped to what the
sender could see, and the role cache dropped after the write.

ADMIN ONLY, all eight administration endpoints. That is the same gate the
Jinja `/admin/users` page used, so the two screens cannot disagree about who
may administer an org — and it is a role check, not a permission check,
because there is no permission scope that means "may change who else is here".

The ninth, `POST /org/invites/redeem` (tracker T:86), is the one exception
and it is the other side of the same door: the INVITED person spending the
code, signed in and in no organization yet (`require_user`, per-user
`LIMIT_REDEEM`).

`POST /org/invites` carries its own, harder limit (`LIMIT_INVITE`, 40/hour):
it is the one endpoint in this API that sends mail to an address the caller
chose, which is the one that can be turned into a spam cannon aimed at a third
party.

Never logged, at any level: invite codes, email addresses.
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src.api.v2 import user_routes as service
from src.api.v2.limits import LIMIT_INVITE, LIMIT_READ, LIMIT_REDEEM, LIMIT_WRITE

from ..deps import Identity, check_csrf, limit, require_admin, require_user

router = APIRouter(prefix="/api/v2/org", tags=["users"])

#: Every unsafe method here is behind the §6.1 double-submit check.
CSRF = Depends(check_csrf)
#: The gate. One object, so a new endpoint cannot quietly be added without it.
ADMIN = Depends(require_admin)

READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))
INVITE = Depends(limit(LIMIT_INVITE))
REDEEM = Depends(limit(LIMIT_REDEEM))


async def _raw_body(request: Request) -> Any:
    """The decoded JSON body, or `None`. Silent, like `get_json(silent=True)`."""
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


def _json(model, status: int = 200) -> JSONResponse:
    """A pydantic model as the response body, in `mode="json"` (§10.1)."""
    return JSONResponse(status_code=status, content=model.model_dump(mode="json"))


# ------------------------------------------------------------------- reading
@router.get("/members", dependencies=[READ])
async def org_members_list(identity: Identity = ADMIN) -> Response:
    """Everyone in the org, plus everyone invited into it. Admins only."""
    return identity.apply_cookies(_json(service.members(identity.org_id, identity.user_id)))


@router.get("/roles", dependencies=[READ])
async def org_roles_list(identity: Identity = ADMIN) -> Response:
    """Every role, with its permission matrix and how many members hold it."""
    return identity.apply_cookies(_json(service.roles(identity.org_id, identity.org_modules)))


@router.get("/roles/overview", dependencies=[READ])
async def org_roles_overview(identity: Identity = ADMIN) -> Response:
    """Every role against every area this org has — the effective grants. 200."""
    return identity.apply_cookies(
        _json(service.roles_overview(identity.org_id, identity.org_modules))
    )


@router.get("/support-access", dependencies=[READ])
async def org_support_access(identity: Identity = ADMIN) -> Response:
    """When Meridians support entered this org, who, why, PHI or not. Admins only.

    ADR 0051's transparency half: every support session a superadmin opened
    here, read under this org's own scope (`meridian_org_isolation`), so
    another org's sessions are never listed.
    """
    from src.api.v2 import superadmin as superadmin_service

    payload = superadmin_service.support_log_entries(identity.required_org_id, identity.user_id)
    return identity.apply_cookies(_json(payload))


# --------------------------------------------------------------------- roles
@router.post("/roles", status_code=201, dependencies=[CSRF, WRITE])
async def org_role_create(request: Request, identity: Identity = ADMIN) -> Response:
    """Create a role and its matrix. 201 with the role as it now stands."""
    payload = service.create_role(await _raw_body(request), identity.org_id, identity.org_modules)
    return identity.apply_cookies(_json(payload, 201))


@router.patch("/roles/{role_id}", dependencies=[CSRF, WRITE])
async def org_role_update(role_id: str, request: Request, identity: Identity = ADMIN) -> Response:
    """Rename, set or clear the default, replace the matrix. 200."""
    payload = service.update_role(
        role_id, await _raw_body(request), identity.org_id, identity.org_modules
    )
    return identity.apply_cookies(_json(payload))


@router.delete("/roles/{role_id}", status_code=204, dependencies=[CSRF, WRITE])
async def org_role_delete(role_id: str, identity: Identity = ADMIN) -> Response:
    """Delete a role nobody holds. 204."""
    service.delete_role(role_id, identity.org_id)
    return identity.apply_cookies(Response(status_code=204))


# -------------------------------------------------------------------- invite
@router.post("/invites", status_code=201, dependencies=[CSRF, INVITE])
async def org_invite_create(request: Request, identity: Identity = ADMIN) -> Response:
    """Invite an email address at a role. 201 with the invite record."""
    payload = service.create_invite(
        await _raw_body(request), identity.org_id, identity.user_id, identity.org
    )
    return identity.apply_cookies(_json(payload, 201))


@router.post("/invites/redeem", dependencies=[CSRF, REDEEM])
async def org_invite_redeem(
    request: Request, identity: Identity = Depends(require_user)
) -> Response:
    """Spend an invite code: join the organization it names. 200 with that org.

    NOT behind `ADMIN`, and not behind `require_org` either: the caller is by
    definition somebody with no organization yet. Signed in is the gate; the
    code is the credential; which org is the code's to say (T:86).
    """
    payload = service.redeem_invite(await _raw_body(request), identity.user_id)
    return identity.apply_cookies(_json(payload))


# ---------------------------------------------------------------- membership
@router.patch("/members/{member_id}", dependencies=[CSRF, WRITE])
async def org_member_update(
    member_id: str, request: Request, identity: Identity = ADMIN
) -> Response:
    """Change a member's role, or an invited row's. 200."""
    payload = service.update_member(
        member_id, await _raw_body(request), identity.org_id, identity.user_id
    )
    return identity.apply_cookies(_json(payload))


@router.delete("/members/{member_id}", status_code=204, dependencies=[CSRF, WRITE])
async def org_member_delete(member_id: str, identity: Identity = ADMIN) -> Response:
    """Remove a member, or revoke a pending invite. 204."""
    service.delete_member(member_id, identity.org_id, identity.user_id)
    return identity.apply_cookies(Response(status_code=204))
