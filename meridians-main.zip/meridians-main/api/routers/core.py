"""`/api/v2/health`, `/csrf`, `/me`, `/processes`, `/runs`, the §3.6 config reads.

The HTTP surface of `src/api/v2/routes.py` — the cross-cutting half of the
contract, the endpoints every screen touches before it touches anything else.
The module kept every line of what they DO: the process catalogue and the one
place each process is named, the fail-open module check, the permission map
built from the ONE read `require_org` did on this request, the partial PATCH
that never restates the key it was not sent, and the org-scoped handle that
refuses to serve mappings from a database with no org concept.

TWO GATES, and they are not the same gate. `/health` and `/csrf` are open by
design — the sign-in form has to be able to mint a token while signed out, or
the CSRF-protected login POST can never be made. Everything else is
`require_org`, and the four config collections are additionally
`config:access`, which is what an accountant is granted so they can clear a
blocked run.

THE CSRF TOKEN IS MINTED HERE AND SET AS THE COOKIE IN THE SAME RESPONSE.
`routes.mint_csrf` explains why it is a random token rather than a flask-wtf
signed one (ADR 0023). What matters at this layer is that the body and the
CSRF cookie always carry the same string: the SPA reads the cookie and
echoes it into `X-CSRFToken`, and `api.deps.check_csrf` compares the two. A
`/me` that handed back a token it had not also set would refuse the caller's
next write with a control that was working perfectly.

Why the bodies are parsed by hand rather than declared as pydantic parameters:
contract §10.1 puts pydantic at the HTTP edge and §4.1 says what a 422 looks
like. `routes.body_of` and the module's own `ValidationError` branches are that
definition — same models, same message, same `field_errors` keys the blueprint
produced — so the move changed no response the SPA parses.

Never logged, at any level: a token, an email address, or a body.
"""

from __future__ import annotations

import json
from typing import Any, Literal

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src import local_sign_in_as
from src.api.v2 import pin_routes, user_routes
from src.api.v2 import routes as service
from src.api.v2.limits import LIMIT_PUBLIC, LIMIT_READ, LIMIT_SESSION, LIMIT_WRITE

from ..deps import (
    CSRF_COOKIE,
    CSRF_COOKIE_HOST,
    Identity,
    check_csrf,
    limit,
    require_admin,
    require_org,
    require_permission,
)

router = APIRouter(prefix="/api/v2", tags=["core"])

#: Every unsafe method here is behind the §6.1 double-submit check.
CSRF = Depends(check_csrf)

#: `config:access` — the four mapping collections the fix form reads and posts.
CONFIG = Depends(require_permission("config", "access"))

ORG = Depends(require_org)
#: The org's ADMIN role (the org-wide sidebar pins). Under "View as role" this
#: is the previewed role's, so an admin previewing a member cannot change them.
ADMIN = Depends(require_admin)
READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))


def _json(model, status: int = 200) -> JSONResponse:
    """A pydantic model as the response body, in `mode="json"` (§10.1)."""
    return JSONResponse(status_code=status, content=model.model_dump(mode="json"))


async def _raw_body(request: Request) -> Any:
    """The decoded JSON body, or `None` when there is not one.

    Silent, like `flask.request.get_json(silent=True)`: a body that is not
    JSON at all must fall out as the same 422 a missing field gets, not as a
    parse error the caller can tell apart.
    """
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


def _flask_config(request: Request, key: str, default: Any = None) -> Any:
    """One setting off the mounted Flask app, or `default`.

    Read from there rather than declared here for the reason
    `api.deps.csrf_enabled` gives: ONE switch for both surfaces, so a
    deployment cannot end up with the two halves of its own API disagreeing
    about how long a token lives or whether its cookie is `Secure`.
    """
    flask_app = getattr(request.app.state, "flask_app", None)
    if flask_app is None:
        return default
    try:
        return flask_app.config.get(key, default)
    except Exception:  # pragma: no cover - defensive
        return default


def _csrf_lifetime(request: Request) -> float:
    """How long a minted token is advertised as living, in seconds.

    §6.1 sets `WTF_CSRF_TIME_LIMIT = None` so the token is tied to the session
    rather than expiring under a 40-minute roster review; that spelling means
    "the session lifetime", so it is read from the same app.
    """
    time_limit = _flask_config(request, "WTF_CSRF_TIME_LIMIT", 3600)
    if time_limit is not None:
        return float(time_limit)
    lifetime = _flask_config(request, "PERMANENT_SESSION_LIFETIME", None)
    seconds = getattr(lifetime, "total_seconds", None)
    if callable(seconds):
        return float(seconds())
    if lifetime is not None:
        return float(lifetime)
    return service.CSRF_DEFAULT_LIFETIME_SECONDS


def _samesite(request: Request) -> Literal["lax", "strict", "none"]:
    """`SESSION_COOKIE_SAMESITE` off the mounted app, in Starlette's spelling.

    Flask spells it `"Lax"` and Starlette types it lowercase; anything the
    config does not name falls back to `lax` rather than being passed through,
    because a cookie attribute a browser does not recognise is a cookie
    attribute a browser ignores.
    """
    value = str(_flask_config(request, "SESSION_COOKIE_SAMESITE", "Lax") or "Lax").lower()
    return value if value in ("lax", "strict", "none") else "lax"  # type: ignore[return-value]


def csrf_cookie_name(secure: bool) -> str:
    """`__Host-XSRF-TOKEN` where the cookie is `Secure`, `XSRF-TOKEN` where not.

    **Why the prefix** (P5AR3-10). `__Host-` is not a naming convention, it is
    an instruction a browser enforces: it refuses to store the cookie unless it
    is `Secure`, `Path=/` and has no `Domain`. That last part is the control —
    without it any host under `meridiansgrp.com`, including one an attacker
    gets to run something on, can set a `XSRF-TOKEN` cookie for the parent
    domain, and a double-submit check compares an attacker-chosen cookie with
    an attacker-chosen header and passes. With the prefix the cookie is
    host-locked and a sibling cannot write it.

    **Why both names still exist.** The prefix is refused outright over plain
    HTTP, and development runs over plain HTTP — so the name follows
    `SESSION_COOKIE_SECURE`, the same switch the session cookie uses, and
    `api.deps.check_csrf` accepts whichever of the two arrived.
    """
    return CSRF_COOKIE_HOST if secure else CSRF_COOKIE


def _with_csrf_cookie(request: Request, response: Response, token: str) -> Response:
    """Set the readable CSRF cookie to exactly the token being sent.

    Deliberately NOT httpOnly: the token is not a secret from the page, it is
    a secret from other origins.
    """
    secure = bool(_flask_config(request, "SESSION_COOKIE_SECURE", False))
    response.set_cookie(
        csrf_cookie_name(secure),
        token,
        httponly=False,
        secure=secure,
        samesite=_samesite(request),
        path="/",
    )
    return response


# ------------------------------------------------------------------ 3.1 health
@router.get("/health", dependencies=[Depends(limit(LIMIT_PUBLIC))])
async def health() -> Response:
    """Unauthenticated, and it reads nothing at all."""
    return _json(service.health())


# -------------------------------------------------------------------- 3.1 csrf
@router.get("/csrf", dependencies=[Depends(limit(LIMIT_SESSION))])
async def csrf_token(request: Request) -> Response:
    """Mint a token and set the readable XSRF-TOKEN cookie (§6.1).

    **Deliberately not behind `require_user`.** `POST /auth/login` is
    CSRF-protected like every other unsafe call, so the sign-in form must
    fetch a token before it can post — while signed out, by definition.
    Requiring a session here made that impossible: the fetch 401'd, no cookie
    was set, the login posted with no `X-CSRFToken`, and every sign-in failed.

    Nothing is leaked by minting one anonymously: the token is only ever
    compared with the cookie it was set into, so a caller who receives one has
    gained the ability to make requests they could already make.
    """
    minted = service.mint_csrf(_csrf_lifetime(request))
    return _with_csrf_cookie(request, _json(minted), minted.token)


# ---------------------------------------------------------------------- 3.1a me
@router.get("/me", dependencies=[Depends(limit(LIMIT_SESSION))])
async def me(request: Request, identity: Identity = ORG) -> Response:
    """Session bootstrap. Never another org's data (§8)."""
    minted = service.mint_csrf(_csrf_lifetime(request))
    payload = service.me(
        identity.user,
        identity.org,
        identity.permissions,
        identity.org_modules,
        minted,
        is_superadmin=identity.is_superadmin,
        local_sign_in_as=local_sign_in_as.me_hint(identity.user),
    )
    return identity.apply_cookies(_with_csrf_cookie(request, _json(payload), minted.token))


@router.patch("/me", dependencies=[CSRF, WRITE])
async def patch_me(request: Request, identity: Identity = ORG) -> Response:
    """Change your own display name, or your own interface language."""
    payload = service.patch_me(await _raw_body(request), identity.user)
    return identity.apply_cookies(_json(payload))


# ------------------------------------------------------------ "View as role"
@router.post("/me/preview-role", dependencies=[CSRF, WRITE])
async def start_preview_role(request: Request, identity: Identity = ORG) -> Response:
    """Start viewing the product as one of this org's roles. Admins only. 200.

    `require_org` and not `require_admin`: while a preview runs the caller's
    org role reads as the previewed one, and an admin must still be able to
    switch roles. The service judges the caller's REAL role instead.
    """
    payload = user_routes.start_role_preview(
        await _raw_body(request),
        identity.org,
        identity.user_id,
        is_superadmin=identity.is_superadmin,
    )
    return identity.apply_cookies(_json(payload))


@router.delete("/me/preview-role", status_code=204, dependencies=[CSRF, WRITE])
async def stop_preview_role(identity: Identity = ORG) -> Response:
    """Stop viewing as a role; full access is back on the next request. 204."""
    user_routes.stop_role_preview(identity.org_id, identity.user_id)
    return identity.apply_cookies(Response(status_code=204))


# ------------------------------------------------------------- org switcher
@router.put("/me/org", dependencies=[CSRF, WRITE])
async def select_my_org(request: Request, identity: Identity = ORG) -> Response:
    """Switch to another of your organizations. 200; 404 for one you are not in."""
    payload = service.select_org(await _raw_body(request), identity.user_id, identity.org)
    return identity.apply_cookies(_json(payload))


@router.put("/me/dashboard-preferences", dependencies=[CSRF, WRITE])
async def put_dashboard_preferences(request: Request, identity: Identity = ORG) -> Response:
    """The WHOLE preference, never a partial merge of two positional lists."""
    payload = service.put_dashboard_preferences(await _raw_body(request), identity.user)
    return identity.apply_cookies(_json(payload))


# ---------------------------------------------------------- sidebar pins
@router.get("/me/process-pins", dependencies=[READ])
async def my_process_pins(identity: Identity = ORG) -> Response:
    """What your sidebar pins: your own list, the org's default, or nothing."""
    payload = pin_routes.my_pins(
        identity.org_id, identity.user_id, identity.permissions, identity.org_modules
    )
    return identity.apply_cookies(_json(payload))


@router.put("/me/process-pins", dependencies=[CSRF, WRITE])
async def put_my_process_pins(request: Request, identity: Identity = ORG) -> Response:
    """Replace your own pinned list; `pins: null` resets to the org default."""
    payload = pin_routes.put_my_pins(
        await _raw_body(request),
        identity.org_id,
        identity.user_id,
        identity.permissions,
        identity.org_modules,
    )
    return identity.apply_cookies(_json(payload))


@router.get("/org/process-pins", dependencies=[READ])
async def org_process_pins(identity: Identity = ADMIN) -> Response:
    """The org's default pinned list. Admins only."""
    return identity.apply_cookies(_json(pin_routes.org_pins(identity.org_id)))


@router.put("/org/process-pins", dependencies=[CSRF, WRITE])
async def put_org_process_pins(request: Request, identity: Identity = ADMIN) -> Response:
    """Replace the org's default pinned list; `[]` clears it. Admins only."""
    payload = pin_routes.put_org_pins(await _raw_body(request), identity.org_id, identity.user_id)
    return identity.apply_cookies(_json(payload))


# --------------------------------------------------------------- 3.1b processes
@router.get("/runs", dependencies=[READ])
async def all_runs(request: Request, identity: Identity = ORG) -> Response:
    """Every run this user may see, across every process, newest first (§11)."""
    args = request.query_params
    payload = service.all_runs(
        identity.org_id,
        identity.user_id,
        identity.permissions,
        identity.org_modules,
        args,
        cursor=args.get("cursor"),
    )
    return identity.apply_cookies(_json(payload))


@router.get("/runs/attention-count", dependencies=[READ])
async def runs_attention_count(identity: Identity = ORG) -> Response:
    """How many runs wait on a person (`needs_input` + `blocked`): the Review badge."""
    payload = service.attention_count(identity.org_id, identity.permissions, identity.org_modules)
    return identity.apply_cookies(_json(payload))


@router.get("/processes", dependencies=[READ])
async def processes(identity: Identity = ORG) -> Response:
    """What this user may see, and where each process starts."""
    payload = service.processes(identity.org_id, identity.permissions, identity.org_modules)
    return identity.apply_cookies(_json(payload))


# ------------------------------------------------------ 3.6 config read + create
def _register_collection(kind: str) -> None:
    """The list and the create of one mapping collection.

    Registered from a loop with distinct endpoint names, exactly as the
    blueprint did, because four near-identical handler bodies is four places
    for the org filter to be forgotten.
    """
    create = service.CONFIG_CREATORS[kind]

    @router.get(f"/config/{kind}", name=f"config_{kind}", dependencies=[READ])
    async def _list(identity: Identity = CONFIG) -> Response:
        """This org's rows, active and inactive, in the §3.6 collection shape."""
        return identity.apply_cookies(
            _json(service.config_collection(kind, identity.org_id, identity.user_id))
        )

    @router.post(
        f"/config/{kind}",
        status_code=201,
        name=f"config_add_{kind}",
        dependencies=[CSRF, WRITE],
    )
    async def _create(request: Request, identity: Identity = CONFIG) -> Response:
        """Add one mapping — what `blockers[].resolve.path` points at (§5)."""
        payload = create(await _raw_body(request), identity.org_id, identity.user_id)
        return identity.apply_cookies(_json(payload, 201))


for _kind in service.CONFIG_COLLECTIONS:
    _register_collection(_kind)
