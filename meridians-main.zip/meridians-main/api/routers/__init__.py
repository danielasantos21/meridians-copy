"""The FastAPI routers, one module per `/api/v2` module being ported.

Ported so far (Phase 5a; `mx_employees` and `superadmin` are Phase 5b):

    health   GET /api/v1/health, GET /health          (D-25)
    auth     POST /api/v2/auth/*                      (contract 3.1)
    oauth    GET /auth/{google,microsoft,callback}    (Phase 11 G2; the
             federated sign-in round trip, out of the OpenAPI document)
    core     /api/v2/{health,csrf,me,processes,runs}, (contract 3.1, 3.1a,
             the four /api/v2/config list+create        3.1b, 3.6)
    config   /api/v2/config/*, /settings*, /org,      (contract 3.6)
             /pnl/preview
    users    /api/v2/org/{members,roles,invites}      (contract 3.7)
    mx_employees
             /api/v2/config/mx-employees*,             (contract 3.6)
             /api/v2/config/mx-departments
    superadmin
             /api/v2/superadmin/orgs*                  (contract 3.8)
    pnl      /api/v2/pnl/* (config, drivers, ledger,   (Phase 27)
             the two workbook downloads)
    oneshot_runs
             /api/v2/{qb-revenue,mx-payroll}/runs/*    (contract 3.2, 5, 12.1)
    qb_usa_runs
             /api/v2/qb-usa-payroll/*                  (contract 3.2, 3A)
    dashboard
             GET /api/v2/dashboard                     (contract 3.1)
    payroll_db
             /api/v2/payroll-db/*                      (main v1.3.4, beta)
    operations
             /api/v2/operations/{kpis,claims,portfolio} (main v1.3.6-7, beta)

That is all of `/api/v2`. The Flask blueprint that used to serve it is gone —
`dashboard` was the last path to cross the mount, and `create_api_v2_blueprint`
went with it. What is still mounted underneath this app is the Jinja surface,
which `docs/migration-tracker.md` tracks by phase.
"""
