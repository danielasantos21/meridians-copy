"""`/api/v2/dev/sign-in-as` — the local login page's "Sign in as" (development only).

    GET     the seeded synthetic users, what the database says each one is, and
            which one this browser is signed in as
    POST    `{"user_id": ...}` — sign in as that user (sets an HttpOnly cookie)
    DELETE  back to the built-in dev identity (clears it)

EVERY method answers 404 unless `src.local_sign_in_as.available()` — a
development laptop on `AUTH_BACKEND=disabled` + `DATABASE_BACKEND=postgres`.
The gate is the FIRST dependency, ahead of CSRF and the rate limit, so outside
development the path is indistinguishable from one that does not exist. Out of
the OpenAPI document on purpose: it is not part of the product's contract.

What the chosen user may see is not decided here. The cookie only names who is
asking; `src.auth.org_context` answers what they may do, from their rows.
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src import local_sign_in_as as sign_in_as
from src.api.v2 import errors as err
from src.api.v2.errors import ApiError
from src.api.v2.limits import LIMIT_SESSION

from ..deps import check_csrf, limit
from .core import _flask_config, _samesite


def require_local_sign_in_as() -> None:
    """404 unless "Sign in as" is on in this process. Fail-closed."""
    if not sign_in_as.available():
        raise ApiError(err.NOT_FOUND, "Not found.")


AVAILABLE = Depends(require_local_sign_in_as)
SESSION = Depends(limit(LIMIT_SESSION))

router = APIRouter(prefix="/api/v2/dev", tags=["dev"], include_in_schema=False)


async def _raw_body(request: Request) -> Any:
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


@router.get("/sign-in-as", dependencies=[AVAILABLE, SESSION])
def list_local_test_users(request: Request) -> Response:
    """Who can be chosen. Deliberately not behind sign-in: it is the sign-in."""
    payload = sign_in_as.listing(request.cookies)
    return JSONResponse(payload.model_dump(mode="json"))


@router.post("/sign-in-as", dependencies=[AVAILABLE, Depends(check_csrf), SESSION])
async def sign_in_as_local_test_user(request: Request) -> Response:
    """Answer every following request as this synthetic user. 200."""
    entry = sign_in_as.choose(await _raw_body(request))
    response = JSONResponse({"current": entry.id})
    response.set_cookie(
        sign_in_as.COOKIE,
        entry.id,
        httponly=True,
        secure=bool(_flask_config(request, "SESSION_COOKIE_SECURE", False)),
        samesite=_samesite(request),
        path="/",
    )
    return response


@router.delete(
    "/sign-in-as", status_code=204, dependencies=[AVAILABLE, Depends(check_csrf), SESSION]
)
def reset_local_test_user(request: Request) -> Response:
    """Back to the built-in dev identity. 204, also when nobody was chosen."""
    response = Response(status_code=204)
    clear_cookie(request, response)
    return response


def clear_cookie(request: Request, response: Response) -> None:
    """Expire the choice on `response`. Only ever called while the feature is on."""
    response.delete_cookie(
        sign_in_as.COOKIE,
        path="/",
        httponly=True,
        secure=bool(_flask_config(request, "SESSION_COOKIE_SECURE", False)),
        samesite=_samesite(request),
    )
