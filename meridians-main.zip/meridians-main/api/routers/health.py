"""`GET /api/v1/health` — the liveness probe, and nothing more (D-25).

The first path to move off Flask, because it is the one with no auth, no org,
no database read and no body to get wrong — which makes it the honest test of
whether the mount works at all.

It keeps the v1 path and the v1 body. Render's `healthCheckPath`, the ALB
target group and CloudFront all point at `/api/v1/health` (`render.yaml`,
`infra/meridian/stacks/edge.py`), and a health check is exactly the wrong
thing to change in the same commit as the server under it. D-25 retires the
path in Phase 12, when `/api/v3/health` replaces it.

`/health` is the same handler under its second, undocumented name — it was an
alias on the Flask route and stays one, so anything pointed at it keeps
working.
"""

from fastapi import APIRouter

#: The v1 payload's own version string. Deliberately not the app version: it
#: is part of a response contract that predates this file.
HEALTH_VERSION = "1.0.0"

router = APIRouter(tags=["system"])


def _database() -> str:
    """Which persistence this server is using, reported verbatim.

    Read through `src.settings` — the same switch `web_app._using_supabase_db`
    reads — rather than by importing `web_app`, so the health check stays
    answerable by a process that has not loaded the Flask app.

    **The value is `DATABASE_BACKEND` itself, not a two-way guess.** The first
    version answered `"supabase"` or `"sqlite"`, which meant a task running
    `DATABASE_BACKEND=postgres` — every task after the Phase 9 cutover —
    reported `sqlite` on the one endpoint an operator reads to find out what a
    box is doing. A health check that lies about the backend is worse than one
    that omits it: it is the line somebody quotes while deciding whether a
    deploy took.
    """
    from src.settings import get_settings

    return get_settings().database_backend


@router.get("/api/v1/health")
@router.get("/health")
async def health() -> dict:
    """Liveness. Reads nothing, authenticates nothing, allocates nothing."""
    return {"status": "ok", "version": HEALTH_VERSION, "database": _database()}
