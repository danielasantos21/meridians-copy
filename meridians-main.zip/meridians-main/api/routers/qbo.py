"""`/api/v2/qbo/connection` — the organization's QuickBooks connection (decision D18).

The HTTP surface of `src/api/v2/qbo_connection.py`, which holds what these
endpoints DO. Three JSON endpoints for the React settings card, and the
browser-facing callback Intuit redirects to:

* `GET    /api/v2/qbo/connection`          status (never a token)
* `POST   /api/v2/qbo/connection/connect`  park a one-time `state`, answer
                                           Intuit's authorize URL
* `DELETE /api/v2/qbo/connection`          disconnect: delete locally, then
                                           revoke at Intuit (best effort)
* `GET    <qbo_client.callback_path()>`    Intuit's redirect back; answers a
                                           302 to `/settings?qbo=<outcome>`

ADMIN ONLY, all four — the org `admin` role the Flask `/qbo/connect` and
`/qbo/callback` checked (CX-API-02). The three JSON endpoints use the
`require_admin` dependency. The callback resolves the caller itself, because a
browser landing back from Intuit must end on a screen, not on a JSON 401/403.

The callback's path is `QBO_CALLBACK_PATH` (default
`/api/v2/qbo/connection/callback`), read when this module is imported; the
redirect URI Intuit is given is `QBO_REDIRECT_URI` or the app origin + that path
(`src/qbo_client.py`). It is not in the OpenAPI document: it is a navigation
target for Intuit, not an operation the SPA calls.

The two Intuit-facing ports come from `app.state` when a test put fakes there
(`qbo_token_exchange`, `qbo_token_revoker`), and from `src/qbo_client.py`
otherwise.

Never logged, at any level: the authorization code, `state`, tokens.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse, RedirectResponse

from src import qbo_client
from src.api.v2 import errors as err
from src.api.v2 import qbo_connection as service
from src.api.v2.errors import ApiError
from src.api.v2.limits import LIMIT_READ, LIMIT_WRITE

from ..deps import Identity, check_csrf, limit, require_admin, require_org, require_user

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v2/qbo", tags=["qbo"])

#: Every unsafe method here is behind the §6.1 double-submit check.
CSRF = Depends(check_csrf)
#: The gate. One object, so an endpoint cannot be added here without it.
ADMIN = Depends(require_admin)

READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))


def _json(model, status: int = 200) -> JSONResponse:
    return JSONResponse(status_code=status, content=model.model_dump(mode="json"))


@router.get("/connection", dependencies=[READ])
def qbo_connection_status(identity: Identity = ADMIN) -> Response:
    """Connected or not, to which company, since when, by whom. Admins only."""
    payload = service.status(identity.required_org_id, identity.user_id)
    return identity.apply_cookies(_json(payload))


@router.post("/connection/connect", dependencies=[CSRF, WRITE])
def qbo_connection_connect(identity: Identity = ADMIN) -> Response:
    """Start the Intuit consent round trip. 200 with the URL to send the browser to."""
    payload = service.start(identity.required_org_id, identity.user_id)
    return identity.apply_cookies(_json(payload))


@router.delete("/connection", status_code=204, dependencies=[CSRF, WRITE])
def qbo_connection_disconnect(request: Request, identity: Identity = ADMIN) -> Response:
    """Disconnect QuickBooks. 204 whether or not a connection existed."""
    revoker = getattr(request.app.state, "qbo_token_revoker", None)
    service.disconnect(identity.required_org_id, identity.user_id, revoke=revoker)
    return identity.apply_cookies(Response(status_code=204))


# ---------------------------------------------------------------- callback
#: Separate from `router` because its path is a setting rather than a literal
#: under the prefix, and it is not part of the JSON contract.
callback_router = APIRouter(tags=["qbo"], include_in_schema=False)


def _redirect(location: str) -> RedirectResponse:
    # 302, as the Flask view answered — an OAuth hop is not a replayed method.
    return RedirectResponse(location, status_code=302)


def qbo_connection_callback(request: Request) -> Response:
    """Where Intuit sends the browser back. Always a 302 onto a screen of ours."""
    # WHICH parameters arrived, never their values: `code` is a credential,
    # `state` is a one-time handle, `error_description` is Intuit's free text.
    logger.info("QuickBooks callback hit with: %s", ",".join(sorted(request.query_params.keys())))
    try:
        identity = require_org(require_user(request))
    except ApiError as exc:
        if exc.code == err.AUTH_REQUIRED:
            # Signed out during the round trip. Nothing is spent; the parked
            # state dies at its TTL. Sign in and press Connect again.
            return _redirect("/login?next=/settings")
        return _redirect(service.settings_url(service.OUTCOME_FORBIDDEN))

    outcome = service.finish(
        request.query_params,
        identity.org_id,
        identity.user_id,
        is_admin=service.caller_is_admin(identity.org),
        exchange=getattr(request.app.state, "qbo_token_exchange", None),
    )
    return identity.apply_cookies(_redirect(service.settings_url(outcome)))


callback_router.add_api_route(
    qbo_client.callback_path(),
    qbo_connection_callback,
    methods=["GET"],
    dependencies=[WRITE],
    name="qbo_connection_callback",
)
