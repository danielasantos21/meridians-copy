"""`/api/v2/config/*`, `/api/v2/settings*`, `/api/v2/org`, `/api/v2/pnl/preview`.

The HTTP surface of `src/api/v2/config_routes.py`, which kept every line of
what these endpoints DO — the org filter written out, the case-insensitive
collision rule, the derived account code, the settings validation that saves
warnings and refuses errors. What moved is the framework: the decorator stack
became dependencies and `flask.g` became an `Identity` argument.

TWO DIFFERENT GATES, and the difference is the point. The mapping collections
and the clinic groups are `config:access`, which is what an accountant is
granted so they can clear a blocked run. The settings resource and the org
name are ADMIN — file-naming patterns, output directories, test mode and the
reset button are org-wide, and handing them to everyone who can fix a mapping
was the hole this closed.

Why the bodies are parsed by hand rather than declared as pydantic parameters:
contract §10.1 puts pydantic at the HTTP edge, and §4.1 says what a 422 looks
like. `routes.body_of` is that definition — the same models, the same message,
the same `field_errors` keys the blueprint produced — so the move changed no
response the SPA parses. A declared parameter would answer FastAPI's own
`RequestValidationError` wording instead.

Never logged, at any level: nothing here logs a body.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src import log_setup
from src.api.v2 import config_routes as service
from src.api.v2.limits import LIMIT_READ, LIMIT_WRITE

from ..deps import Identity, check_csrf, limit, require_admin, require_permission

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v2", tags=["config"])

#: Every unsafe method here is behind the §6.1 double-submit check.
CSRF = Depends(check_csrf)

#: `config:access` — the mapping collections and the clinic groups.
CONFIG = Depends(require_permission("config", "access"))
#: `pnl_provider:access` — the two provider-P&L reads that live in this module.
PNL = Depends(require_permission("pnl_provider", "access"))

READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))

#: The five editable mapping collections, path segment -> collection key.
#: Registered from a loop with distinct endpoint names, exactly as the
#: blueprint did, because five near-identical handler bodies is five places
#: for the org filter to be forgotten.
MAPPING_PATHS = (
    ("providers", "providers"),
    ("locations", "locations"),
    ("payers", "payers"),
    ("departments", "departments"),
    ("qb-provider-codes", "qb_provider_codes"),
)


async def _raw_body(request: Request) -> Any:
    """The decoded JSON body, or `None` when there is not one.

    Silent, like `flask.request.get_json(silent=True)`: a body that is not
    JSON at all must fall out as the same 422 a missing field gets, not as a
    parse error the caller can tell apart.
    """
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


def _json(model, status: int = 200) -> JSONResponse:
    """A pydantic model as the response body, in `mode="json"` (§10.1)."""
    return JSONResponse(status_code=status, content=model.model_dump(mode="json"))


def _int(value: Optional[str]) -> Optional[int]:
    """`request.args.get(name, type=int)`: a number, or None. Never raises."""
    try:
        return int(value) if value not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _audit_qb_mapping(action: str, kind: str, identity: Identity, row_id: Any) -> None:
    """The `qb_mapping_change` line (critic R2-M4). Ids, the kind and the verb;
    never a mapping value — those are the org's chart of accounts."""
    logger.info(
        "QuickBooks mapping %s",
        action,
        extra={
            "event": log_setup.EVENT_QB_MAPPING_CHANGE,
            "org_id": str(identity.org_id) if identity.org_id else None,
            "actor": str(identity.user_id) if identity.user_id else None,
            "action": action,
            "kind": kind,
            "row_id": str(row_id) if row_id is not None else None,
        },
    )


def _register_mapping_routes(path: str, name: str, audited: bool = False) -> None:
    @router.patch(
        f"/config/{path}/{{row_id}}",
        name=f"config_update_{name}",
        dependencies=[CSRF, WRITE],
    )
    async def _update(row_id: str, request: Request, identity: Identity = CONFIG) -> Response:
        """Edit one mapping. 200 with the row as it now stands."""
        payload = service.update_collection(
            name, row_id, await _raw_body(request), identity.org_id, identity.user_id
        )
        if audited:
            _audit_qb_mapping("updated", path, identity, getattr(payload, "id", row_id))
        return identity.apply_cookies(_json(payload))

    @router.delete(
        f"/config/{path}/{{row_id}}",
        status_code=204,
        name=f"config_delete_{name}",
        dependencies=[CSRF, WRITE],
    )
    async def _delete(row_id: str, identity: Identity = CONFIG) -> Response:
        """Hard-delete one mapping row of this org. 204."""
        service.delete_collection(name, row_id, identity.org_id, identity.user_id)
        if audited:
            _audit_qb_mapping("deleted", path, identity, row_id)
        return identity.apply_cookies(Response(status_code=204))


for _path, _name in MAPPING_PATHS:
    _register_mapping_routes(_path, _name)


# ------------------------------------------------- QuickBooks mapping tables
# `qb-accounts`, `qb-departments`, `qb-clinics`, `qb-other-codes`,
# `qb-payer-labels`, `qb-locations` (`service.QB_MAP_KINDS`): what a QuickBooks
# revenue or payroll run is coded from, and what a Postgres run is refused
# without (`QB_MAPPINGS_UNAVAILABLE`), so a person looking at a blocked run
# can fix it in the product.
#
# The SAME service functions v3 serves (`qb_map_collection`, `add_qb_map`,
# `update_collection`, `delete_collection`), so the same strict bodies, the
# same case-insensitive natural-key 409, the same org-scoped `_find` (another
# org's id is 404, never 403) and the same Postgres-only rule (503
# `PERSISTENCE_UNAVAILABLE`, `details.reason == "backend"`, on Supabase). Same
# gate as every other mapping collection here: `config:access`. Every write
# stamps `updated_by` on the row and logs a `qb_mapping_change` event.


def _register_qb_map_routes(kind: str, name: str) -> None:
    @router.get(f"/config/{kind}", name=f"config_list_{name}", dependencies=[READ])
    async def _list(identity: Identity = CONFIG) -> Response:
        """Every row of this QuickBooks mapping table the org holds, inactive too."""
        return identity.apply_cookies(
            _json(service.qb_map_collection(name, identity.org_id, identity.user_id))
        )

    @router.post(
        f"/config/{kind}",
        status_code=201,
        name=f"config_add_{name}",
        dependencies=[CSRF, WRITE],
    )
    async def _add(request: Request, identity: Identity = CONFIG) -> Response:
        """Add one row. 201 with the row as stored; 409 if its key exists."""
        payload = service.add_qb_map(
            name, await _raw_body(request), identity.org_id, identity.user_id
        )
        _audit_qb_mapping("created", kind, identity, getattr(payload, "id", None))
        return identity.apply_cookies(_json(payload, 201))

    _register_mapping_routes(kind, name, audited=True)


for _kind, _name in service.QB_MAP_KINDS.items():
    _register_qb_map_routes(_kind, _name)


# ------------------------------------------------ QuickBooks provider codes
@router.get("/config/qb-provider-codes", dependencies=[READ])
async def config_qb_provider_codes(identity: Identity = CONFIG) -> Response:
    """What QuickBooks calls each clinician, in the journal's `Name`."""
    return identity.apply_cookies(
        _json(service.qb_provider_codes(identity.org_id, identity.user_id))
    )


@router.post("/config/qb-provider-codes", status_code=201, dependencies=[CSRF, WRITE])
async def config_add_qb_provider_code(request: Request, identity: Identity = CONFIG) -> Response:
    """Give a clinician their own QB code. 201."""
    payload = service.add_qb_provider_code(
        await _raw_body(request), identity.org_id, identity.user_id
    )
    return identity.apply_cookies(_json(payload, 201))


# ------------------------------------- QB USA payroll people, MX payroll accounts
# Read on `config:access`; every write needs `config:results` (main v1.3.0),
# which the roles model never grants without access.
CONFIG_RESULTS = Depends(require_permission("config", "results"))


@router.get("/config/qb-usa-employees", dependencies=[READ])
async def config_qb_usa_employees(identity: Identity = CONFIG) -> Response:
    """Everyone on the QB USA payroll roster, active and inactive."""
    return identity.apply_cookies(
        _json(service.qb_usa_employees(identity.org_id, identity.user_id))
    )


@router.patch("/config/qb-usa-employees/{row_id}", dependencies=[CSRF, WRITE])
async def config_update_qb_usa_employee(
    row_id: str, request: Request, identity: Identity = CONFIG_RESULTS
) -> Response:
    """Edit one person's QuickBooks coding. No POST and no DELETE."""
    payload = service.update_qb_usa_employee(
        row_id, await _raw_body(request), identity.org_id, identity.user_id, identity.email
    )
    return identity.apply_cookies(_json(payload))


@router.get("/config/mx-payroll-accounts", dependencies=[READ])
async def config_mx_payroll_accounts(identity: Identity = CONFIG) -> Response:
    """Every MX payroll column this org books by name, and its account."""
    return identity.apply_cookies(
        _json(service.mx_payroll_accounts(identity.org_id, identity.user_id))
    )


@router.post("/config/mx-payroll-accounts", status_code=201, dependencies=[CSRF, WRITE])
async def config_add_mx_payroll_account(
    request: Request, identity: Identity = CONFIG_RESULTS
) -> Response:
    """Book a payroll column to an account from the next run on. 201."""
    payload = service.add_mx_payroll_account(
        await _raw_body(request), identity.org_id, identity.user_id, identity.email
    )
    return identity.apply_cookies(_json(payload, 201))


@router.patch("/config/mx-payroll-accounts/{row_id}", dependencies=[CSRF, WRITE])
async def config_update_mx_payroll_account(
    row_id: str, request: Request, identity: Identity = CONFIG_RESULTS
) -> Response:
    """Change a column's name, account or direction, or switch it off."""
    payload = service.update_mx_payroll_account(
        row_id, await _raw_body(request), identity.org_id, identity.user_id, identity.email
    )
    return identity.apply_cookies(_json(payload))


@router.delete("/config/mx-payroll-accounts/{row_id}", status_code=204, dependencies=[CSRF, WRITE])
async def config_delete_mx_payroll_account(
    row_id: str, identity: Identity = CONFIG_RESULTS
) -> Response:
    """Hard delete. The screen offers Deactivate first. 204."""
    service.delete_mx_payroll_account(row_id, identity.org_id, identity.user_id)
    return identity.apply_cookies(Response(status_code=204))


# ---------------------------------------------------- p&l provider roster
@router.get("/config/pnl-providers", dependencies=[READ])
async def config_pnl_providers(identity: Identity = PNL) -> Response:
    """The clinicians the provider P&L has a column for."""
    return identity.apply_cookies(_json(service.pnl_providers(identity.org_id, identity.user_id)))


@router.get("/pnl/preview", dependencies=[READ])
async def pnl_preview(request: Request, identity: Identity = PNL) -> Response:
    """A period's real revenue, at provider grain. Reads; stores nothing."""
    args = request.query_params
    payload = service.pnl_preview(
        identity.org_id,
        identity.user_id,
        batches=args.get("batches") or "",
        fiscal_year=_int(args.get("fiscal_year")),
        period=_int(args.get("period")),
        period_id=args.get("period_id") or "",
    )
    return identity.apply_cookies(_json(payload))


# ------------------------------------------------------------ clinic groups
@router.get("/config/clinic-groups", dependencies=[READ])
async def config_clinic_groups(identity: Identity = CONFIG) -> Response:
    """The org's clinic groups, from `config_clinic_groups`."""
    return identity.apply_cookies(_json(service.clinic_groups(identity.org_id, identity.user_id)))


def _audit_clinic_group(action: str, identity: Identity, row_id: Any, fields: Any) -> None:
    """The `clinic_group_change` line (Stage 2 pass 2 N1). Ids, the verb and the
    field NAMES sent; never a value — a group's locations and bank key are the
    org's own set-up, and the table keeps no `updated_by` to say who."""
    logger.info(
        "Clinic group %s",
        action,
        extra={
            "event": log_setup.EVENT_CLINIC_GROUP_CHANGE,
            "org_id": str(identity.org_id) if identity.org_id else None,
            "actor": str(identity.user_id) if identity.user_id else None,
            "action": action,
            "row_id": str(row_id) if row_id is not None else None,
            "fields": sorted(fields),
        },
    )


@router.post("/config/clinic-groups", status_code=201, dependencies=[CSRF, WRITE])
async def config_add_clinic_group(request: Request, identity: Identity = CONFIG) -> Response:
    """Add a clinic group. Supabase, org-scoped — never the workbook. 201."""
    raw = await _raw_body(request)
    payload = service.add_clinic_group(raw, identity.org_id, identity.user_id)
    _audit_clinic_group(
        "created", identity, getattr(payload, "id", None), raw if isinstance(raw, dict) else {}
    )
    return identity.apply_cookies(_json(payload, 201))


@router.patch("/config/clinic-groups/{row_id}", dependencies=[CSRF, WRITE])
async def config_update_clinic_group(
    row_id: str, request: Request, identity: Identity = CONFIG
) -> Response:
    """Edit one clinic group's unposted fields (N1). RDS only. 200 with the row."""
    raw = await _raw_body(request)
    payload = service.update_clinic_group(row_id, raw, identity.org_id, identity.user_id)
    _audit_clinic_group(
        "updated", identity, getattr(payload, "id", row_id), raw if isinstance(raw, dict) else {}
    )
    return identity.apply_cookies(_json(payload))


# ----------------------------------------------------------------- settings
ADMIN = Depends(require_admin)


@router.get("/settings", dependencies=[READ])
async def settings_read(identity: Identity = ADMIN) -> Response:
    """What `/settings` shows, typed. Admins only."""
    return identity.apply_cookies(_json(service.read_settings(identity.org_id)))


@router.patch("/settings", dependencies=[CSRF, WRITE])
async def settings_update(request: Request, identity: Identity = ADMIN) -> Response:
    """Partial update. Warnings are saved and returned; errors are a 422."""
    return identity.apply_cookies(
        _json(service.update_settings(await _raw_body(request), identity.org_id))
    )


@router.post("/settings/reset", dependencies=[CSRF, WRITE])
async def settings_reset(identity: Identity = ADMIN) -> Response:
    """Put every setting back to its default and return them."""
    return identity.apply_cookies(_json(service.reset_settings(identity.org_id)))


# ---------------------------------------------------------------------- org
@router.get("/org", dependencies=[READ])
async def org_read(identity: Identity = ADMIN) -> Response:
    """The org as `/admin/organization` shows it. Admins only."""
    return identity.apply_cookies(_json(service.read_org(identity.org_id, identity.org)))


@router.patch("/org", dependencies=[CSRF, WRITE])
async def org_update(request: Request, identity: Identity = ADMIN) -> Response:
    """Rename the organization. Admins only."""
    payload = service.update_org(await _raw_body(request), identity.org_id, identity.org)
    return identity.apply_cookies(_json(payload))
