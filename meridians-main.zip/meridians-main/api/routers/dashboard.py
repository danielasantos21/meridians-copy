"""`GET /api/v2/dashboard` — the HTTP surface of the dashboard aggregate.

The LAST path to cross the mount. With it the Flask `/api/v2` blueprint serves
nothing at all, so `create_api_v2_blueprint` and its registration in
`web_app.py` went in the same commit: a factory that builds an empty blueprint
is a place a route can be added back without anybody noticing which framework
is meant to answer for it.

There is no dashboard logic in this file, on purpose. The handler resolves the
caller through the same `require_org` dependency every other tenant-scoped
router declares and calls `src.api.v2.auth_routes.dashboard`, which is the
whole of what the Flask view did — the process catalogue, the period window,
the close checklist, the badge counts and the trend, unchanged.

`identity.required_org_id` rather than `identity.org_id`: it is
`runs_common.org_id_of`, the same fail-closed rule (and the same sentence) the
Flask view got from `org_id_or_403`, so a superadmin with no membership row is
still refused with `ORG_REQUIRED` rather than reading with `org_id=None`.

Never logged, at any level: a token, an email address, or a body.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Response
from fastapi.responses import JSONResponse

from src.api.v2 import auth_routes as service
from src.api.v2 import dashboard_widgets
from src.api.v2.limits import LIMIT_READ

from ..deps import Identity, limit, require_org

router = APIRouter(prefix="/api/v2", tags=["dashboard"])


@router.get("/dashboard", dependencies=[Depends(limit(LIMIT_READ))])
async def dashboard(identity: Identity = Depends(require_org)) -> Response:
    """Everything the dashboard renders, in one call. Org-scoped (§8)."""
    payload = service.dashboard(
        identity.required_org_id,
        identity.org,
        identity.user,
        identity.permissions,
        identity.org_modules,
    )
    return identity.apply_cookies(
        JSONResponse(status_code=200, content=payload.model_dump(mode="json"))
    )


@router.get("/dashboard/widgets/{widget_id}", dependencies=[Depends(limit(LIMIT_READ))])
async def dashboard_widget(widget_id: str, identity: Identity = Depends(require_org)) -> Response:
    """One chart widget's numbers (`src.api.v2.dashboard_widgets`). Org-scoped."""
    payload = dashboard_widgets.widget(
        widget_id,
        identity.required_org_id,
        identity.user,
        identity.permissions,
        identity.org_modules,
    )
    return identity.apply_cookies(
        JSONResponse(status_code=200, content=payload.model_dump(mode="json"))
    )
