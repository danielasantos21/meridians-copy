"""`GET /api/v2/local-storage/{token}` — a declared-local download link (Stage 2 S2-F5).

On a laptop with `STORAGE_BACKEND=local` (decision D4: plain disk) there is no
S3 to presign a GET, so `LocalStorageManager.get_signed_url` returns a link to
this route instead. The authorization and the audit happen where they happen
for S3: in the endpoint that MINTS the link (object-level checks, the
`download_log` row, `phi.open_artifact('artifact_mint', …)` for a PHI file).
This route is the presigned GET's twin — the link is the capability: it names
one org's file, carries a MAC under a per-process key and expires with the
mint's TTL (`src.storage.resolve_local_link`). A link that is forged, expired,
outside its org's folder, or redeemed on a server not using declared local
storage is 404, the same answer as a file that never existed.
"""

from __future__ import annotations

from fastapi import APIRouter
from fastapi.responses import Response

from src import storage

router = APIRouter(tags=["system"])


@router.get(storage.LOCAL_LINK_PREFIX + "{token}", include_in_schema=False)
def local_download(token: str) -> Response:
    try:
        data, content_type, disposition = storage.resolve_local_link(token)
    except storage.LocalLinkInvalid:
        return Response(status_code=404)
    return Response(
        content=data,
        media_type=content_type,
        headers={"Content-Disposition": disposition, "Cache-Control": "no-store"},
    )
