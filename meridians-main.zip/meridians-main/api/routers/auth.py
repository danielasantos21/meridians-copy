"""`/api/v2/auth/*` — the HTTP surface of `src/api/v2/auth_routes.py`.

There is no authentication logic in this file, on purpose. Every handler
decodes a body, calls the function in `src.api.v2.auth_routes` that already
implements the endpoint, and turns what comes back into a response. The
Cognito calls, the branch on `AUTH_BACKEND`, the pending-challenge store and
every error code stayed where they were; what moved is the framework.

That matters most for the MFA handle store: it is module state in
`auth_routes`, and this module imports the functions that read and write it
rather than keeping a store of its own. One store, one TTL, one attempt
ceiling — a second copy would mean a handle minted by one surface and refused
by the other.

Why the bodies are parsed by hand rather than declared as pydantic parameters:
a body FastAPI rejects answers `RequestValidationError`, whose message is
FastAPI's. §4 and the login form want "Enter an email address and a password."
and the field map the Flask route produced. `auth_routes.parse_body` is that
definition, and calling it keeps the 422 identical across the move.

Never logged, at any level: passwords, tokens, email addresses.
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src import auth as _auth
from src import local_sign_in_as
from src.api.v2 import auth_routes as service
from src.api.v2 import schemas as sc
from src.api.v2.limits import LIMIT_AUTH, LIMIT_LOGIN, LIMIT_SESSION

from ..deps import Identity, check_csrf, limit, require_user

router = APIRouter(prefix="/api/v2/auth", tags=["session"])

#: Every endpoint here is an unsafe method behind the §6.1 double-submit
#: check. Sign-in included: a login form is exactly the kind of endpoint a
#: cross-origin page would like to submit on a victim's behalf.
CSRF = Depends(check_csrf)


async def _raw_body(request: Request) -> Any:
    """The decoded JSON body, or `None` when there is not one.

    Silent, like `flask.request.get_json(silent=True)`: a body that is not
    JSON at all must fall out as the same 422 a missing field gets, not as a
    parse error the caller can tell apart.
    """
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


def _json(model, status: int = 200) -> JSONResponse:
    """A pydantic model as the response body, in `mode="json"` (§10.1)."""
    return JSONResponse(status_code=status, content=model.model_dump(mode="json"))


def _sign_in_response(result: service.SignIn) -> JSONResponse:
    """A `SignIn` as the 200 that ends a sign-in, cookies and all.

    The cookie writer is `src.auth`'s, called by the service layer through the
    closure it handed back — a Starlette response accepts the same
    `set_cookie` keywords a Flask one does, so the tokens, flags and lifetimes
    are literally the ones the Jinja form writes.
    """
    response = _json(result.payload)
    if result.set_cookies is not None:
        result.set_cookies(response)
    return response


@router.post("/login", dependencies=[CSRF, Depends(limit(LIMIT_LOGIN))])
async def login(request: Request) -> Response:
    """Sign in with email and password; set the session cookies."""
    body = service.login_body(await _raw_body(request))
    return _sign_in_response(service.login(body, request.cookies.get(_auth.DEVICE_COOKIE)))


@router.post("/logout", status_code=204, dependencies=[CSRF, Depends(limit(LIMIT_SESSION))])
async def logout(request: Request) -> Response:
    """Revoke the refresh token and clear the cookies. 204, safe when already out."""
    response = Response(status_code=204)
    service.logout_cookies(response, request.cookies.get(_auth.REFRESH_TOKEN_COOKIE))
    if local_sign_in_as.available():
        # Development only: signing out also forgets the local test user, so
        # the login page's "Sign in as" list is where it lands.
        from .dev import clear_cookie

        clear_cookie(request, response)
    return response


@router.post("/mfa", dependencies=[CSRF, Depends(limit(LIMIT_AUTH))])
async def answer_mfa(request: Request) -> Response:
    """Finish a sign-in that `POST /auth/login` answered with a challenge."""
    body = service.parse_body(sc.MfaIn, await _raw_body(request))
    return _sign_in_response(service.answer_mfa(body))


@router.post("/forgot-password", dependencies=[CSRF, Depends(limit(LIMIT_AUTH))])
async def forgot_password(request: Request) -> Response:
    """Ask for a reset code. Always 200, always the same body."""
    body = service.parse_body(sc.ForgotPasswordIn, await _raw_body(request))
    return _json(service.forgot_password(body))


@router.post("/reset-password", dependencies=[CSRF, Depends(limit(LIMIT_AUTH))])
async def reset_password(request: Request) -> Response:
    """Spend a reset code on a new password. A REAL reset."""
    body = service.parse_body(sc.ResetPasswordIn, await _raw_body(request))
    return _json(service.reset_password(body))


@router.post("/mfa/setup", dependencies=[CSRF, Depends(limit(LIMIT_AUTH))])
async def begin_mfa_enrolment(
    request: Request, identity: Identity = Depends(require_user)
) -> Response:
    """Start enrolling an authenticator. Returns the shared secret ONCE.

    The account enrolled is the one the SESSION names, never one the body
    chose: `identity.email` is what the dependency resolved from the cookie or
    the bearer token.
    """
    body = service.parse_body(sc.MfaSetupIn, await _raw_body(request))
    payload = service.begin_mfa_enrolment(body, identity.email)
    return identity.apply_cookies(_json(payload))


@router.post("/mfa/verify", dependencies=[CSRF, Depends(limit(LIMIT_AUTH))])
async def finish_mfa_enrolment(
    request: Request, identity: Identity = Depends(require_user)
) -> Response:
    """Prove the authenticator works, then make it this user's factor."""
    body = service.parse_body(sc.MfaVerifyIn, await _raw_body(request))
    payload = service.finish_mfa_enrolment(body, identity.email)
    return identity.apply_cookies(_json(payload))


# ------------------------------------------------ sign-in challenges (T:85)
# The two Cognito challenges a password sign-in can end in besides the MFA
# code. Anonymous, like `/auth/mfa`: the caller has no session yet — the handle
# from `POST /auth/login` is the only thing that names them — and the same
# credential-endpoint limit applies.


@router.post("/challenge/new-password", dependencies=[CSRF, Depends(limit(LIMIT_AUTH))])
async def answer_new_password(request: Request) -> Response:
    """Replace a temporary password; answers like `POST /auth/login`."""
    body = service.parse_body(sc.NewPasswordIn, await _raw_body(request))
    return _sign_in_response(service.answer_new_password(body))


@router.post("/challenge/mfa-setup", dependencies=[CSRF, Depends(limit(LIMIT_AUTH))])
async def begin_challenge_mfa_setup(request: Request) -> Response:
    """The setup key for the authenticator the pool demands. Shown ONCE."""
    body = service.parse_body(sc.ChallengeIn, await _raw_body(request))
    return _json(service.begin_challenge_mfa_setup(body))


@router.post("/challenge/mfa-setup/verify", dependencies=[CSRF, Depends(limit(LIMIT_AUTH))])
async def finish_challenge_mfa_setup(request: Request) -> Response:
    """The first code from the new authenticator; signs the user in."""
    body = service.parse_body(sc.MfaVerifyIn, await _raw_body(request))
    return _sign_in_response(service.finish_challenge_mfa_setup(body))
