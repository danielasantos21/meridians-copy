"""`/api/v2/qb-revenue/runs` and `/api/v2/mx-payroll/runs` — §3.2, §5, §12.1.

The HTTP surface of `src/api/v2/oneshot_runs.py`, which kept every line of what
these endpoints DO: the §5 invariant that an unmapped provider stops a run
before any journal entry exists, the retry parameters written to the `params`
COLUMN so `blocked` survives a deploy, the idempotent create that returns the
ORIGINAL run rather than booking a period twice, the whitelist that decides
what `params` the browser may see, and the state machine deciding what may
happen next.

TWO PROCESSES, ONE REGISTRATION LOOP, as the blueprint did. Nine operations
each — both with `retry`, the way out of `blocked` (Andres, 2026-09-25,
§12.8) — registered from `SPECS` with distinct endpoint names, because
eighteen near-identical handler bodies is eighteen places for the org filter to
be forgotten. The per-process difference is the permission: `revenue:*` for one
and `payroll:*` for the other, and `access` or `results` per operation, exactly
as `v2_permission` applied them.

THE WORK DID NOT MOVE. A create still starts `web_app`'s own worker on a
`threading.Thread`; this module changed which framework turns that into a
response, and nothing else. `run_id` is still the Jinja wizard's `job_id` and
still addresses the same `process_runs` row.

WHY THE MULTIPART IS PARSED BY WERKZEUG rather than declared as `UploadFile`:
`api/uploads.py` says, and `oneshot_runs.select_upload` is then one rule about
which part names count for both surfaces.

DOWNLOADS ARE MINTED, NOT PROXIED (§7.2). The 201 carries a short-lived signed
URL and an audit row records the mint; the bytes never pass through this
process, so the mint is the only honest thing to record. The caller's address
and user agent reach the audit row on the `Caller`, which is the only place
this module reads the transport for anything but routing.

Never logged, at any level: a filename, a body, or a signed URL.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src.api.v2 import oneshot_runs as service
from src.api.v2.limits import LIMIT_READ
from src.api.v2.runs_common import Caller

from .. import errors as api_errors
from ..deps import Identity, check_csrf, client_address, limit, require_permission
from ..uploads import close_uploads, form_and_files

router = APIRouter(prefix="/api/v2", tags=["runs"])

#: Every unsafe method here is behind the §6.1 double-submit check.
CSRF = Depends(check_csrf)

#: Declared on every route that parses a multipart body: it closes the
#: `FileStorage` temp files once the handler has answered (P5AR2-10).
CLOSE_UPLOADS = Depends(close_uploads)

#: §9's per-operation limits, the same strings flask-limiter was given.
LIMIT_CREATE = "10/minute"
LIMIT_CANCEL = "30/minute"
LIMIT_MINT = "30/minute"


def _json(model, status: int = 200) -> JSONResponse:
    """A pydantic model as the response body, in `mode="json"` (§10.1)."""
    return JSONResponse(status_code=status, content=model.model_dump(mode="json"))


def _caller(request: Request, identity: Identity) -> Caller:
    """The `Caller` the service functions take.

    The org comes from the membership row `require_org` resolved on THIS
    request and never from a path or a query parameter (§8); the address and
    user agent come from the transport because a signed-URL mint is audited
    (§7.2) and an audit row with no requester is half a record.

    `required_org_id` and not `org_id or ""` (P5AR2-01): a superadmin with no
    membership row has a context whose `org_id` is `None`, and `""` turned that
    into a run created under an org id no organization has — a row nobody owns,
    written past the `org_id = %s` predicate that is half of the tenancy
    control. It raises `ORG_REQUIRED`, which is what Flask answered.

    The address is `client_address`, not `request.client` (P5AR3-07): behind
    CloudFront and behind the Next.js proxy the socket address is a hop, so an
    audit row for a signed-URL mint recorded the infrastructure rather than the
    person. It is the same reading the rate limiter uses.
    """
    return Caller(
        org_id=identity.required_org_id,
        user=identity.user,
        permissions=identity.permissions or {},
        ip=client_address(request),
        user_agent=request.headers.get("User-Agent"),
        request_id=api_errors.request_id(request),
    )


def _register(process: str) -> None:
    """The nine operations of one one-shot process."""
    spec = service.spec_for(process)
    name = process.replace("-", "_")
    root = f"/{process}/runs"

    access = Depends(require_permission(spec.permission, "access"))
    results = Depends(require_permission(spec.permission, "results"))

    @router.post(
        root,
        status_code=201,
        name=f"{name}_create_run",
        dependencies=[CSRF, CLOSE_UPLOADS, Depends(limit(LIMIT_CREATE))],
    )
    async def create_run(request: Request, identity: Identity = access) -> Response:
        """Create a run and start it. 12.1: create IS execute."""
        form, files = await form_and_files(request)
        envelope, status = service.create_run(
            process,
            _caller(request, identity),
            form,
            files,
            idempotency_key=request.headers.get("Idempotency-Key"),
        )
        return identity.apply_cookies(_json(envelope, status))

    @router.get(root, name=f"{name}_list_runs", dependencies=[Depends(limit(LIMIT_READ))])
    async def list_runs(request: Request, identity: Identity = results) -> Response:
        """Run history, keyset-paginated (11)."""
        args = request.query_params
        payload = service.list_runs(
            process, _caller(request, identity), args, cursor=args.get("cursor")
        )
        return identity.apply_cookies(_json(payload))

    @router.get(
        f"{root}/{{run_id}}", name=f"{name}_get_run", dependencies=[Depends(limit(LIMIT_READ))]
    )
    async def get_run(run_id: str, request: Request, identity: Identity = access) -> Response:
        """The canonical envelope. Polled every 2 s while a run is in flight."""
        payload = service.get_run(process, _caller(request, identity), run_id)
        return identity.apply_cookies(_json(payload))

    @router.delete(
        f"{root}/{{run_id}}",
        status_code=204,
        name=f"{name}_cancel_run",
        dependencies=[CSRF, Depends(limit(LIMIT_CANCEL))],
    )
    async def cancel_run(run_id: str, request: Request, identity: Identity = access) -> Response:
        """Abandon a non-terminal run and purge its upload. 204."""
        service.cancel_run(process, _caller(request, identity), run_id)
        return identity.apply_cookies(Response(status_code=204))

    @router.post(
        f"{root}/{{run_id}}/execute",
        status_code=202,
        name=f"{name}_execute_run",
        dependencies=[CSRF, CLOSE_UPLOADS, Depends(limit(LIMIT_CREATE))],
    )
    async def execute_run(run_id: str, request: Request, identity: Identity = access) -> Response:
        """Start the export. 202, or 409 for these two (12.1)."""
        payload = service.execute_run(
            process,
            _caller(request, identity),
            run_id,
            idempotency_key=request.headers.get("Idempotency-Key"),
        )
        return identity.apply_cookies(_json(payload, 202))

    if spec.supports_retry:
        # 12.8: retry is registered only where the manifest says `supports_retry`,
        # elsewhere it 404s rather than 405s and the SPA never special-cases a
        # process.
        @router.post(
            f"{root}/{{run_id}}/retry",
            status_code=202,
            name=f"{name}_retry_run",
            dependencies=[CSRF, CLOSE_UPLOADS, Depends(limit(LIMIT_CREATE))],
        )
        async def retry_run(run_id: str, request: Request, identity: Identity = access) -> Response:
            """Re-run a blocked run after the mappings have been added (5)."""
            payload = service.retry_run(
                process,
                _caller(request, identity),
                run_id,
                idempotency_key=request.headers.get("Idempotency-Key"),
            )
            return identity.apply_cookies(_json(payload, 202))

    @router.get(
        f"{root}/{{run_id}}/artifacts",
        name=f"{name}_artifacts",
        dependencies=[Depends(limit(LIMIT_READ))],
    )
    async def artifacts(run_id: str, request: Request, identity: Identity = results) -> Response:
        """What this run produced (3.7)."""
        payload = service.artifacts(process, _caller(request, identity), run_id)
        return identity.apply_cookies(_json(payload))

    @router.post(
        f"{root}/{{run_id}}/artifacts/{{artifact_id}}/download-url",
        status_code=201,
        name=f"{name}_download_url",
        dependencies=[CSRF, Depends(limit(LIMIT_MINT))],
    )
    async def download_url(
        run_id: str, artifact_id: str, request: Request, identity: Identity = results
    ) -> Response:
        """Mint a short-lived signed URL and audit the mint (7.2). 201."""
        payload = service.download_url(process, _caller(request, identity), run_id, artifact_id)
        return identity.apply_cookies(_json(payload, 201))

    @router.post(
        f"{root}/{{run_id}}/artifacts/bundle",
        status_code=201,
        name=f"{name}_bundle",
        dependencies=[CSRF, CLOSE_UPLOADS, Depends(limit(LIMIT_CREATE))],
    )
    async def bundle(run_id: str, request: Request, identity: Identity = results) -> Response:
        """Build (or refresh) the whole-run ZIP and sign it for 300 s (7.2)."""
        payload = service.bundle(process, _caller(request, identity), run_id)
        return identity.apply_cookies(_json(payload, 201))


# Both processes, from the one loop — the same thing `register_oneshot_routes`
# did, and for the same reason.
for _process in service.SPECS:
    _register(_process)
