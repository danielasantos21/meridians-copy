"""`/api/v2/pnl/*` — the provider P&L (Daniela's), served by FastAPI.

The HTTP surface of `src/api/v2/pnl_routes.py`, which holds the work. This
module only maps paths to those functions: the decorator stack became
dependencies and `flask.g` became an `Identity` argument.

ONE GATE, EVERY PATH: `pnl_provider:access`. The P&L carries every
clinician's compensation, so there is no read here that is safe for someone
who may not open it.

Handlers are plain `def` (run in FastAPI's thread pool) when they have no
body, and `async def` + `run_in_threadpool` when they read one: the database
work is blocking and must not sit on the event loop.

`POST /runs` answers 503 `ECW_NOT_CONNECTED` when eCW is not configured (and
on the AWS backend until T:251 lands); every other path works from the `pl_*`
tables alone.

Never logged, at any level: nothing here logs a body.
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from src.api.v2 import pnl_routes as service
from src.api.v2.limits import LIMIT_READ, LIMIT_WRITE
from src.api.v2.pnl_routes import XLSX_MIME

from ..deps import Identity, check_csrf, limit, require_permission

router = APIRouter(prefix="/api/v2/pnl", tags=["pnl"])

CSRF = Depends(check_csrf)
PNL = Depends(require_permission("pnl_provider", "access"))
READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))


async def _raw_body(request: Request) -> Any:
    """The decoded JSON body, or `None`. Silent, like `get_json(silent=True)`."""
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


def _json(identity: Identity, model, status: int = 200) -> Response:
    return identity.apply_cookies(
        JSONResponse(status_code=status, content=model.model_dump(mode="json"))
    )


def _workbook(identity: Identity, payload: bytes, filename: str) -> Response:
    return identity.apply_cookies(
        Response(
            content=payload,
            media_type=XLSX_MIME,
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    )


# -------------------------------------------------------------------- runs
@router.get("/runs", dependencies=[READ])
def pnl_list_runs(identity: Identity = PNL) -> Response:
    """The saved runs, newest first."""
    return _json(identity, service.runs(identity.required_org_id, identity.user_id))


@router.post("/runs", dependencies=[CSRF, WRITE])
async def pnl_start_run(request: Request, identity: Identity = PNL) -> Response:
    """Start a run in the background. 503 `ECW_NOT_CONNECTED` without eCW."""
    raw = await _raw_body(request)
    run = await run_in_threadpool(
        service.start_run, identity.required_org_id, identity.user_id, raw
    )
    return _json(identity, run, 202)


@router.get("/runs/{run_id}/export", dependencies=[READ])
def pnl_export_run(run_id: str, identity: Identity = PNL) -> Response:
    """The run as an Excel workbook."""
    payload, filename = service.export_run(identity.required_org_id, identity.user_id, run_id)
    return _workbook(identity, payload, filename)


@router.get("/runs/{run_id}/log", dependencies=[READ])
def pnl_run_log(run_id: str, identity: Identity = PNL) -> Response:
    """The end of what the script printed."""
    return _json(identity, service.run_log(identity.required_org_id, identity.user_id, run_id))


@router.get("/runs/{run_id}/report", dependencies=[READ])
def pnl_run_report(run_id: str, request: Request, identity: Identity = PNL) -> Response:
    """One run's report, calculated by the server."""
    return _json(
        identity,
        service.report(identity.required_org_id, identity.user_id, run_id, request.query_params),
    )


# ------------------------------------------------------------------- rules
@router.get("/rules", dependencies=[READ])
def pnl_list_rules(identity: Identity = PNL) -> Response:
    return _json(identity, service.list_rules(identity.required_org_id, identity.user_id))


@router.post("/rules", dependencies=[CSRF, WRITE])
async def pnl_add_rule(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(service.add_rule, identity.required_org_id, identity.user_id, raw),
    )


@router.patch("/rules/{rule_id}", dependencies=[CSRF, WRITE])
async def pnl_change_rule(rule_id: str, request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.change_rule, identity.required_org_id, identity.user_id, rule_id, raw
        ),
    )


@router.delete("/rules/{rule_id}", dependencies=[CSRF, WRITE])
def pnl_delete_rule(rule_id: str, identity: Identity = PNL) -> Response:
    return _json(identity, service.delete_rule(identity.required_org_id, identity.user_id, rule_id))


@router.post("/rules/{rule_id}/move", dependencies=[CSRF, WRITE])
async def pnl_move_rule(rule_id: str, request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.move_rule, identity.required_org_id, identity.user_id, rule_id, raw
        ),
    )


@router.get("/drivers", dependencies=[READ])
def pnl_list_drivers(identity: Identity = PNL) -> Response:
    return _json(identity, service.drivers(identity.required_org_id, identity.user_id))


# --------------------------------------------------------------- providers
@router.get("/providers", dependencies=[READ])
def pnl_list_providers(request: Request, identity: Identity = PNL) -> Response:
    return _json(
        identity,
        service.providers(identity.required_org_id, identity.user_id, request.query_params),
    )


@router.post("/providers/save", dependencies=[CSRF, WRITE])
async def pnl_save_providers(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.save_providers, identity.required_org_id, identity.user_id, raw
        ),
    )


@router.get("/flags", dependencies=[READ])
def pnl_list_flags(identity: Identity = PNL) -> Response:
    return _json(identity, service.flags(identity.required_org_id, identity.user_id))


@router.post("/flags", dependencies=[CSRF, WRITE])
async def pnl_add_flag(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(service.add_flag, identity.required_org_id, identity.user_id, raw),
    )


@router.post("/flags/rename", dependencies=[CSRF, WRITE])
async def pnl_rename_flag(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.rename_flag, identity.required_org_id, identity.user_id, raw
        ),
    )


@router.post("/flags/delete", dependencies=[CSRF, WRITE])
async def pnl_delete_flag(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.delete_flag, identity.required_org_id, identity.user_id, raw
        ),
    )


# ----------------------------------------------------------------- reviews
@router.get("/reviews", dependencies=[READ])
def pnl_get_review(request: Request, identity: Identity = PNL) -> Response:
    return _json(
        identity, service.review(identity.required_org_id, identity.user_id, request.query_params)
    )


@router.get("/reviews/status", dependencies=[READ])
def pnl_review_status(request: Request, identity: Identity = PNL) -> Response:
    return _json(
        identity,
        service.review_status(identity.required_org_id, identity.user_id, request.query_params),
    )


@router.post("/reviews/decide", dependencies=[CSRF, WRITE])
async def pnl_decide_review(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.decide_review, identity.required_org_id, identity.user_id, raw
        ),
    )


@router.post("/reviews/approve", dependencies=[CSRF, WRITE])
async def pnl_approve_review(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.approve_review, identity.required_org_id, identity.user_id, raw
        ),
    )


@router.post("/reviews/finish", dependencies=[CSRF, WRITE])
async def pnl_finish_review(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.finish_review, identity.required_org_id, identity.user_id, raw
        ),
    )


# ----------------------------------------------------------------- reclass
@router.get("/reclass", dependencies=[READ])
def pnl_list_reclass(identity: Identity = PNL) -> Response:
    return _json(identity, service.reclass(identity.required_org_id, identity.user_id))


@router.put("/reclass", dependencies=[CSRF, WRITE])
async def pnl_save_reclass(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.save_reclass, identity.required_org_id, identity.user_id, raw
        ),
    )


@router.post("/reclass/approve", dependencies=[CSRF, WRITE])
async def pnl_approve_reclass(request: Request, identity: Identity = PNL) -> Response:
    raw = await _raw_body(request)
    return _json(
        identity,
        await run_in_threadpool(
            service.approve_reclass, identity.required_org_id, identity.user_id, raw
        ),
    )


@router.get("/reclass/status", dependencies=[READ])
def pnl_reclass_status(identity: Identity = PNL) -> Response:
    return _json(identity, service.reclass_status(identity.required_org_id, identity.user_id))
