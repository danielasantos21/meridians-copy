"""`/api/v2/superadmin/orgs*` — §3.8.

The HTTP surface of `src/api/v2/superadmin.py`, which kept every line of what
these endpoints DO: the one audited cross-organization pass, the three
org-scoped reads that name an organization, and the module toggle that checks
its value against `ALL_PROCESSES` before writing.

SUPERADMIN ONLY, all four, and the refusal is a **404**. Not a 403: a 403 tells
the caller the console exists and that they are simply not on the list, which is
exactly what `src/auth.require_superadmin` has always refused to say. §8's
404-not-403 rule is the same rule one level up — there it hides another tenant's
row, here it hides a whole screen.

THE GATE HANGS OFF `require_user`, NOT `require_org`, and that is load-bearing.
A superadmin need not be a member of anything: `src/auth.org_context` gives one
a system context with `org_id=None`, and `require_org` would refuse them before
the superadmin check ever ran. The org-scoped endpoints take their organization
from the PATH instead, which is what makes them ordinary scoped checkouts of an
organization the caller named rather than of one they belong to.

Why the bodies are parsed by hand rather than declared as pydantic parameters:
contract §10.1 puts pydantic at the HTTP edge and §4.1 says what a 422 looks
like. `routes.body_of` is that definition, so the 422 here is the one the SPA
already parses.

Never logged, at any level: organization names, slugs, member ids.
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse

from src import auth as _auth
from src.api.v2 import errors as err
from src.api.v2 import superadmin as service
from src.api.v2.errors import ApiError
from src.api.v2.limits import LIMIT_READ, LIMIT_WRITE

from ..deps import Identity, check_csrf, limit, require_user

router = APIRouter(prefix="/api/v2/superadmin", tags=["superadmin"])


def _caller(identity: Identity) -> str:
    """The caller's user id as a plain `str`, or the same 404 the gate answers.

    `require_user` has already established that there IS a caller, so the
    falsy branch is unreachable in practice. It is written out anyway because
    `Identity.user_id` is `Optional` by construction — an `Identity` exists
    before any gate has run — and "unreachable" is a claim that stops being
    true the first time a dependency is reordered.
    """
    user_id = identity.user_id
    if not user_id:
        raise ApiError(err.NOT_FOUND, "Not found.")
    return user_id


def require_superadmin(identity: Identity = Depends(require_user)) -> Identity:
    """Only a row in `public.superadmins` gets past here. Everyone else: 404.

    Declared in this router rather than in `api/deps.py` because it is the only
    surface that has one; it moves to `deps.py` the moment a second does.

    The built-in local bypass identity is honoured exactly as every other gate
    honours it, so a local bypass run does not have to keep a superadmins
    table; a user chosen through the local "Sign in as" is checked against the
    table like anybody (`bypass_grants_all`).
    """
    # Superadmin powers are off while the caller previews a role ("View as
    # role", `src/role_preview.py`): no org role grants them.
    caller = _caller(identity)
    if not _auth.bypass_grants_all(identity.user) and not _auth.is_superadmin(caller):
        raise ApiError(err.NOT_FOUND, "Not found.")
    if _auth.superadmin_suspended_by_preview(caller):
        raise ApiError(err.NOT_FOUND, "Not found.")
    return identity


# Every route below takes its caller through `_caller` and never through
# `identity.user_id` directly. Three of the four used to read the Optional
# attribute straight, which meant `None` reached `with_superadmin` and came
# back as a `NotASuperadmin` — a 500 for what §8 says is a 404, and a different
# answer from `/orgs` for the same missing caller (critic P5BR2-06).

#: Every unsafe method here is behind the §6.1 double-submit check.
CSRF = Depends(check_csrf)
#: The gate. One object, so a new endpoint cannot quietly be added without it.
SUPERADMIN = Depends(require_superadmin)

READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))


async def _raw_body(request: Request) -> Any:
    """The decoded JSON body, or `None`. Silent, like `get_json(silent=True)`."""
    try:
        payload = await request.body()
    except Exception:  # pragma: no cover - a disconnected client
        return None
    if not payload:
        return None
    try:
        return json.loads(payload)
    except ValueError:
        return None


def _json(model, status: int = 200) -> JSONResponse:
    """A pydantic model as the response body, in `mode="json"` (§10.1)."""
    return JSONResponse(status_code=status, content=model.model_dump(mode="json"))


# ------------------------------------------------------- the cross-org read
@router.get("/orgs", dependencies=[READ])
async def superadmin_orgs(identity: Identity = SUPERADMIN) -> Response:
    """Every organization, with members, modules, last batch and health. 200."""
    return identity.apply_cookies(_json(service.overview(_caller(identity))))


# ------------------------------------------------- one named organization
@router.get("/orgs/{org_id}", dependencies=[READ])
async def superadmin_org_detail(org_id: str, identity: Identity = SUPERADMIN) -> Response:
    """One organization: its row, its membership and its modules. 200."""
    return identity.apply_cookies(_json(service.org_detail(org_id, _caller(identity))))


@router.get("/orgs/{org_id}/batches", dependencies=[READ])
async def superadmin_org_batches(org_id: str, identity: Identity = SUPERADMIN) -> Response:
    """That organization's batch history. 200."""
    return identity.apply_cookies(_json(service.org_batches(org_id, _caller(identity))))


@router.put("/orgs/{org_id}/modules", dependencies=[CSRF, WRITE])
async def superadmin_set_module(
    org_id: str, request: Request, identity: Identity = SUPERADMIN
) -> Response:
    """Turn one module on or off; answers with the whole enabled set. 200."""
    payload = service.set_module(await _raw_body(request), org_id, _caller(identity))
    return identity.apply_cookies(_json(payload))


# ------------------------------------------------ superadmin control (ADR 0051)
@router.post("/orgs", status_code=201, dependencies=[CSRF, WRITE])
async def superadmin_create_org(request: Request, identity: Identity = SUPERADMIN) -> Response:
    """Create a customer organization. 201 with its console row."""
    payload = service.create_org(await _raw_body(request), _caller(identity))
    return identity.apply_cookies(_json(payload, 201))


@router.get("/orgs/{org_id}/support-access", dependencies=[READ])
async def superadmin_org_support_access(org_id: str, identity: Identity = SUPERADMIN) -> Response:
    """That organization's Meridians support-access log. 200."""
    return identity.apply_cookies(_json(service.org_support_log(org_id, _caller(identity))))


@router.post("/support-session", dependencies=[CSRF, WRITE])
async def start_support_session(request: Request, identity: Identity = SUPERADMIN) -> Response:
    """Enter an organization in support mode. 200 with the session."""
    _caller(identity)
    payload = service.support_start(await _raw_body(request), identity.user)
    return identity.apply_cookies(_json(payload))


@router.post("/support-session/phi", dependencies=[CSRF, WRITE])
async def grant_support_session_phi(request: Request, identity: Identity = SUPERADMIN) -> Response:
    """Add patient-level access to the running session. 200."""
    payload = service.support_phi(await _raw_body(request), _caller(identity))
    return identity.apply_cookies(_json(payload))


@router.delete("/support-session", status_code=204, dependencies=[CSRF, WRITE])
async def end_support_session(identity: Identity = Depends(require_user)) -> Response:
    """Leave support mode. 204.

    `require_user`, NOT the superadmin gate: anybody may end their OWN session
    and Exit must always work — including during a role preview inside the
    supported org, when the superadmin gate answers 404.
    """
    # Not `_caller`: a missing caller has no session to end, and Exit answers
    # 204 for "nothing to end" rather than the gate's 404.
    service.support_end(identity.user.get("id"))
    return identity.apply_cookies(Response(status_code=204))


@router.get("/superadmins", dependencies=[READ])
async def list_superadmins(identity: Identity = SUPERADMIN) -> Response:
    """Every superadmin, and the recent add/remove requests. 200."""
    return identity.apply_cookies(_json(service.superadmins(_caller(identity))))


@router.post("/superadmins", status_code=201, dependencies=[CSRF, WRITE])
async def request_superadmin_change(request: Request, identity: Identity = SUPERADMIN) -> Response:
    """Ask to add or remove a superadmin (two-person rule). 201."""
    _caller(identity)
    payload = service.request_superadmin_change(await _raw_body(request), identity.user)
    return identity.apply_cookies(_json(payload, 201))


@router.post("/superadmin-changes/{change_id}/decision", dependencies=[CSRF, WRITE])
async def decide_superadmin_change(
    change_id: str, request: Request, identity: Identity = SUPERADMIN
) -> Response:
    """Approve or reject a pending superadmin change. 200."""
    payload = service.decide_superadmin_change(
        change_id, await _raw_body(request), _caller(identity)
    )
    return identity.apply_cookies(_json(payload))
