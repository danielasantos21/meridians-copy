"""`/api/v2/bi/*` -- the BI query engine, Ask Meridian and the data browser.

The HTTP surface of `src/api/v2/bi_routes.py` and `src/api/v2/bi_data_routes.py`
(main v1.3.9-v1.3.47), which keep what these endpoints DO. This module maps
paths to those functions: the Flask decorator stack became dependencies and
`flask.g` became an `Identity`.

GATES, as on main:
  * `bi:access` for the builder, catalog and the data browser reads; Ask also needs `bi_ask:access`;
  * org ADMIN (instead of that permission, as on main) for native SQL, the data
    edits, rescan and the Metabase export;
  * superadmin (404 for everyone else) for `/ask/usage` and `/ask/log`; `/ask/recent` needs bi + bi_ask and returns only the caller's own rows;
  * CSRF on every unsafe method; LIMIT_BI / LIMIT_ASK / LIMIT_READ / LIMIT_WRITE /
    LIMIT_DASH_RUN per endpoint, as declared on main.
The eCW gate (`mart_source.gate(org_id)`: 503 / 404 before any database call) runs inside
each service function. On the Postgres backend it opens only when the audited eCW copy
is configured (MART_DB_*), and every read is wrapped in an audit scope; native SQL is
always refused there.

The caller is a `bi_store.Actor` built here from the signed-in identity ONLY; the
org and user are never read from a body or a query string (a query string that
names one is refused with 422 by the service).

Blocking work stays off the event loop: plain `def` for reads, `async def` +
`run_in_threadpool` for the handlers that read a body.

Never logged, at any level: nothing here logs a body.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from src import auth as _auth
from src import bi_store
from src.api.v2 import bi_data_routes as data
from src.api.v2 import bi_routes as service
from src.api.v2 import errors as err
from src.api.v2.errors import ApiError
from src.api.v2.limits import LIMIT_ASK, LIMIT_BI, LIMIT_DASH_RUN, LIMIT_READ, LIMIT_WRITE

from ..deps import Identity, check_csrf, limit, require_admin_in, require_org, require_permission

router = APIRouter(prefix="/api/v2/bi", tags=["bi"])

CSRF = Depends(check_csrf)
#: The builder gate: one object, so a new endpoint cannot quietly be added without it.
BI = Depends(require_permission("bi", "access"))
ASK_DOOR = Depends(require_permission("bi_ask", "access"))
#: Org admin INSTEAD of the permission (main used `require_role("admin")` alone here).
ADMIN = Depends(require_admin_in("bi"))
READ = Depends(limit(LIMIT_READ))
WRITE = Depends(limit(LIMIT_WRITE))
BUILD = Depends(limit(LIMIT_BI))
ASK = Depends(limit(LIMIT_ASK))
DASH_RUN = Depends(limit(LIMIT_DASH_RUN))


def require_superadmin(identity: Identity = Depends(require_org)) -> Identity:
    """Only a row in `public.superadmins` gets past here. Everyone else: 404.

    `src.auth.require_superadmin`, on top of `require_org` (the usage log is the
    caller's org's). A preview of a role switches the powers off.
    """
    if _auth.bypass_grants_all(identity.user):
        if _auth.superadmin_suspended_by_preview(_auth.LOCAL_DEV_USER_ID):
            raise ApiError(err.NOT_FOUND, "Not found.")
        return identity
    user_id = identity.user_id
    if (
        not user_id
        or not _auth.is_superadmin(user_id)
        or _auth.superadmin_suspended_by_preview(user_id)
    ):
        raise ApiError(err.NOT_FOUND, "Not found.")
    return identity


SUPERADMIN = Depends(require_superadmin)


def _actor(identity: Identity) -> bi_store.Actor:
    """The caller as a store Actor, from the identity only."""
    return service.actor_of(identity.required_org_id, identity.user_id, identity.org)


def _testing(request: Request) -> bool:
    """Is the mounted app in testing mode (`options.today` may be honoured)? False when there is none."""
    flask_app = getattr(request.app.state, "flask_app", None)
    try:
        return bool(flask_app is not None and flask_app.config.get("TESTING"))
    except Exception:  # pragma: no cover - defensive
        return False


def _json(identity: Identity, model, *, by_alias: bool = False) -> Response:
    content = model if isinstance(model, dict) else model.model_dump(mode="json", by_alias=by_alias)
    return identity.apply_cookies(JSONResponse(content=content))


# ------------------------------------------------------------ query engine
@router.get("/catalog", dependencies=[READ])
def bi_catalog_get(identity: Identity = BI) -> Response:
    """What a question may use, with this org's table and column edits."""
    return _json(identity, service.bi_catalog_get(_actor(identity)))


@router.post("/query", dependencies=[CSRF, BUILD])
async def bi_query_run(request: Request, identity: Identity = BI) -> Response:
    raw = await request.body()
    out = await run_in_threadpool(
        service.bi_query_run, _actor(identity), raw, testing=_testing(request)
    )
    return _json(identity, out)


@router.post("/query/compile", dependencies=[CSRF, BUILD])
async def bi_query_compile(request: Request, identity: Identity = BI) -> Response:
    raw = await request.body()
    out = await run_in_threadpool(
        service.bi_query_compile, _actor(identity), raw, testing=_testing(request)
    )
    return _json(identity, out)


@router.post("/ask", dependencies=[CSRF, ASK, ASK_DOOR])
async def bi_ask_question(request: Request, identity: Identity = BI) -> Response:
    """Ask Meridian. Off (503) on any server without BEDROCK_REGION (OD-5)."""
    raw = await request.body()
    return _json(identity, await run_in_threadpool(service.bi_ask_question, _actor(identity), raw))


@router.post("/ask/related", dependencies=[CSRF, ASK, ASK_DOOR])
async def bi_ask_related(request: Request, identity: Identity = BI) -> Response:
    raw = await request.body()
    return _json(identity, await run_in_threadpool(service.bi_ask_related, _actor(identity), raw))


@router.get("/ask/recent", dependencies=[READ, ASK_DOOR])
def bi_ask_recent_get(identity: Identity = BI) -> Response:
    """The caller's own recent asks (rows are filtered by org and user)."""
    return _json(identity, service.bi_ask_recent_get(_actor(identity)))


@router.get("/ask/usage", dependencies=[READ])
def bi_ask_usage_get(identity: Identity = SUPERADMIN) -> Response:
    return _json(identity, service.bi_ask_usage_get(_actor(identity)))


@router.get("/ask/log", dependencies=[READ])
def bi_ask_log_get(identity: Identity = SUPERADMIN) -> Response:
    return _json(identity, service.bi_ask_log_get(_actor(identity)))


@router.post("/native", dependencies=[CSRF, BUILD])
async def bi_native_run(request: Request, identity: Identity = ADMIN) -> Response:
    """Hand-written SQL, org admins only, on the powerless reader login."""
    raw = await request.body()
    return _json(identity, await run_in_threadpool(service.bi_native_run, _actor(identity), raw))


# ------------------------------------------------------------ data browser
@router.get("/data", dependencies=[READ])
def bi_data_browse(request: Request, identity: Identity = BI) -> Response:
    return _json(identity, data.browse(_actor(identity), request.query_params))


@router.get("/data/export/metabase", dependencies=[READ])
def bi_data_export(request: Request, identity: Identity = ADMIN) -> Response:
    return _json(identity, data.export_metabase(_actor(identity), request.query_params))


@router.get("/data/tables/{name}", dependencies=[READ])
def bi_data_table(name: str, request: Request, identity: Identity = BI) -> Response:
    # `from` (a foreign-key edge) is spelled `from_` in Python: dump by alias.
    return _json(
        identity, data.table_detail(_actor(identity), request.query_params, name), by_alias=True
    )


@router.put("/data/tables/{name}", dependencies=[CSRF, WRITE])
async def bi_data_table_put(name: str, request: Request, identity: Identity = ADMIN) -> Response:
    raw = await request.body()
    out = await run_in_threadpool(data.put_table, _actor(identity), request.query_params, name, raw)
    return _json(identity, out)


@router.get("/data/tables/{name}/columns/{col}", dependencies=[READ])
def bi_data_column(name: str, col: str, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, data.column(_actor(identity), request.query_params, name, col))


@router.put("/data/tables/{name}/columns/{col}", dependencies=[CSRF, WRITE])
async def bi_data_column_put(
    name: str, col: str, request: Request, identity: Identity = ADMIN
) -> Response:
    raw = await request.body()
    out = await run_in_threadpool(
        data.put_column, _actor(identity), request.query_params, name, col, raw
    )
    return _json(identity, out)


@router.get("/data/tables/{name}/columns/{col}/values", dependencies=[DASH_RUN])
def bi_data_values(name: str, col: str, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, data.values(_actor(identity), request.query_params, name, col))


@router.get("/data/tables/{name}/columns/{col}/stats", dependencies=[DASH_RUN])
def bi_data_stats(name: str, col: str, request: Request, identity: Identity = BI) -> Response:
    return _json(identity, data.stats(_actor(identity), request.query_params, name, col))


@router.post("/data/tables/{name}/rescan", dependencies=[CSRF, WRITE])
def bi_data_rescan(name: str, request: Request, identity: Identity = ADMIN) -> Response:
    return _json(identity, data.rescan(_actor(identity), request.query_params, name))
