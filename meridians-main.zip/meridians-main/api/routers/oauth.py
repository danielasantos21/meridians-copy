"""`/auth/google`, `/auth/microsoft`, `/auth/callback` — the federated sign-in round trip.

The React sign-in form links to the first two
(`web/src/components/login-form.tsx`), and the third is the redirect URI the
Cognito app client and Supabase's allow-list both name
(`infra/meridian/stacks/auth.py` `CALLBACK_PATH`). The browser reaches them
through the `/auth/:path*` proxy prefix (`web/next.config.mjs`), which on AWS
is an ALB rule to the `api` target group.

A failure redirects to `/login` with no message. The `state` check runs
before the Cognito exchange, and the PKCE verifier is the Supabase browser
binding's (Codex CX-API-01).

Never logged, at any level: the authorization code, `error_description`,
tokens. Which query parameters arrived is logged; their values are not.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import logging
import os
import secrets
from urllib.parse import quote

from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse

from src import auth as _auth
from src import cognito
from src import settings as app_settings_env

logger = logging.getLogger(__name__)

router = APIRouter(tags=["session"], include_in_schema=False)

#: Where a federated sign-in should land, parked for the round trip out to the
#: identity provider and back. It cannot ride on `redirect_to`: that URL has to
#: match Supabase's allow-list, and appending a query string to it is exactly
#: the kind of near-match an allow-list rejects. A cookie needs no dashboard
#: configuration and cannot be tampered into an open redirect, because
#: `safe_next` re-checks it on the way back out.
OAUTH_NEXT_COOKIE = "ns_oauth_next"

#: The OAuth `state` parameter, parked for the same round trip.
#:
#: Without it `/auth/callback` accepts ANY authorization code anyone can make
#: a signed-out browser follow: an attacker starts a sign-in as themselves,
#: keeps the code, and links it to a victim's browser, which then holds a
#: session belonging to the attacker's account — login CSRF, and with it
#: session fixation. `state` is the standard fix (RFC 6749 §10.12): a random
#: value written here, echoed back by the provider, and compared to the cookie
#: before a single token is exchanged. HttpOnly so script cannot read it,
#: `SameSite=Lax` so it survives the provider's top-level GET back to us, and
#: spent on first use so a code cannot be replayed against it.
OAUTH_STATE_COOKIE = "ns_oauth_state"

#: Supabase (PKCE) only: the code verifier this browser must present at the
#: exchange. Supabase's `/authorize` does not echo `state`, so under that
#: backend the verifier IS the binding between the browser that started the
#: sign-in and the code that comes back (CX-API-01): a code obtained by another
#: browser fails the exchange here because it was issued against a different
#: challenge. Cognito echoes `state` and the check below uses it instead.
OAUTH_VERIFIER_COOKIE = "ns_oauth_verifier"

#: One sign-in round trip, not a session. A `state` that outlives the redirect
#: is a `state` an attacker has time to work with.
OAUTH_COOKIE_MAX_AGE = 600

#: Where every refusal lands: the React sign-in page.
LOGIN_PATH = "/login"
#: Where a sign-in with no (or no safe) `next` lands.
DEFAULT_NEXT = "/dashboard"


def safe_next(raw: str | None) -> str:
    """The open-redirect guard: only a path on this site is honoured.

    Absolute URL, protocol-relative `//evil`, a backslash the browser will
    normalise into a slash — all fall back to the dashboard. The same rule as
    `web_app._safe_next`, which the Jinja `/login` (the `MERIDIAN_JINJA_AUTH`
    rollback hatch) still uses.
    """
    if (
        not raw
        or not raw.startswith("/")
        or raw.startswith("//")
        or raw.startswith("/\\")
        or "://" in raw
    ):
        return DEFAULT_NEXT
    return raw


def callback_url() -> str:
    """The redirect URI, identical on the way out and on the way back.

    The origin is the *app's* (`settings.public_app_url()`, ADR 0050 — `app.`,
    never `www.` or `api.`): the session cookie is host-only, so a callback that
    lands on any other host writes the cookie where the Next app will never see
    it. Computed in one place because Cognito compares this string byte for byte
    at the token exchange — a trailing slash on one side is `invalid_grant` on
    the other.
    """
    return f"{app_settings_env.public_app_url()}/auth/callback"


def _redirect(location: str) -> RedirectResponse:
    # 302, as Flask's `redirect()` answered — not Starlette's 307 default,
    # which would replay a method and is not what an OAuth hop is.
    return RedirectResponse(location, status_code=302)


def _park(response: RedirectResponse, name: str, value: str, secure: bool) -> None:
    response.set_cookie(
        name,
        value,
        max_age=OAUTH_COOKIE_MAX_AGE,
        httponly=True,
        secure=secure,
        samesite="lax",  # survives the provider's top-level GET back to us
        path="/",
    )


def _clear_oauth_cookies(response: RedirectResponse) -> RedirectResponse:
    """All three round-trip cookies are spent on first use, whatever the outcome."""
    for name in (OAUTH_NEXT_COOKIE, OAUTH_STATE_COOKIE, OAUTH_VERIFIER_COOKIE):
        response.delete_cookie(name, path="/")
    return response


def _refuse() -> RedirectResponse:
    """Back to sign-in with nothing set and every parked cookie spent."""
    return _clear_oauth_cookies(_redirect(LOGIN_PATH))


def _start(request: Request, provider: tuple[str, str], label: str) -> RedirectResponse:
    """Hand off to the hosted authorize endpoint for one provider.

    Cognito's hosted domain under `AUTH_BACKEND=cognito`, Supabase's otherwise
    (ADR 0021: the hosted UI is used for exactly these two redirects, where the
    user is leaving for Google or Microsoft anyway).

    `provider` is a `(cognito_name, supabase_id)` pair because the two name the
    same identity provider differently and neither is derivable from the other:
    Entra ID is `azure` to Supabase and whatever the pool registered the OIDC
    provider as to Cognito.
    """
    cognito_provider, supabase_provider = provider
    callback = callback_url()
    state = secrets.token_urlsafe(32)
    # `staging` is a real deployment over the public internet;
    # `dev_fallbacks_permitted()` is the line that means "laptop or pytest",
    # and `set_auth_cookies` keys on the same one.
    secure = not app_settings_env.dev_fallbacks_permitted()

    if app_settings_env.get_settings().auth_is_cognito:
        try:
            target = cognito.hosted_authorize_url(callback, cognito_provider, state=state)
        except RuntimeError:
            logger.warning(  # phi-lint: ok label is the literal "Google"/"Microsoft"
                "%s sign-in is not configured", label
            )
            return _redirect(LOGIN_PATH)
        response = _redirect(target)
    else:
        supabase_url = os.environ.get("SUPABASE_URL", "").rstrip("/")
        if not supabase_url:
            logger.warning(  # phi-lint: ok label is the literal "Google"/"Microsoft"
                "%s sign-in is not configured", label
            )
            return _redirect(LOGIN_PATH)
        # PKCE: without a challenge Supabase answers with the implicit grant
        # (tokens in the URL fragment), which the callback does not accept.
        verifier = secrets.token_urlsafe(64)
        challenge = (
            base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("ascii")).digest())
            .rstrip(b"=")
            .decode("ascii")
        )
        response = _redirect(
            f"{supabase_url}/auth/v1/authorize"
            f"?provider={supabase_provider}&redirect_to={quote(callback, safe='')}"
            f"&code_challenge={challenge}&code_challenge_method=s256"
        )
        _park(response, OAUTH_VERIFIER_COOKIE, verifier, secure)

    _park(response, OAUTH_NEXT_COOKIE, safe_next(request.query_params.get("next")), secure)
    _park(response, OAUTH_STATE_COOKIE, state, secure)
    return response


def _state_ok(request: Request) -> bool:
    """Did the provider echo back the `state` this browser was given?

    Constant-time, and false for a missing cookie or a missing parameter as
    well as for a mismatch: a callback with no `state` at all is exactly what
    an injected authorization code looks like.
    """
    parked = request.cookies.get(OAUTH_STATE_COOKIE) or ""
    returned = request.query_params.get("state", "")
    if not parked or not returned:
        return False
    # Bytes, not str: `compare_digest` raises on non-ASCII text, and the
    # parameter is caller-controlled.
    return hmac.compare_digest(returned.encode("utf-8"), parked.encode("utf-8"))


def _land(
    request: Request, access: str, refresh: str, refresh_expires: int | None = None
) -> RedirectResponse:
    """Finish a federated sign-in: cookies on, parked `next`, `state` and verifier spent.

    `refresh_expires` is passed by the Cognito branch, whose pool issues a
    30-day refresh token: the cookie default is seven days, which would throw
    away three weeks of a valid token and sign the user out early.
    """
    response = _redirect(safe_next(request.cookies.get(OAUTH_NEXT_COOKIE)))
    if access and refresh:
        if refresh_expires is None:
            _auth.set_auth_cookies(response, access, refresh)
        else:
            _auth.set_auth_cookies(response, access, refresh, refresh_expires=refresh_expires)
    return _clear_oauth_cookies(response)


@router.get("/auth/google")
def auth_google(request: Request) -> RedirectResponse:
    # 'Google' is Cognito's reserved name for the social provider; 'google' is
    # Supabase's provider id.
    return _start(request, ("Google", "google"), "Google")


@router.get("/auth/microsoft")
def auth_microsoft(request: Request) -> RedirectResponse:
    # 'azure' is the Supabase provider id for Entra ID (formerly Azure AD). On
    # the Cognito side Entra is an OIDC provider registered under the name
    # below, which the auth stack sets and must not drift from.
    return _start(request, ("Microsoft", "azure"), "Microsoft")


@router.get("/auth/callback")
def auth_callback(request: Request) -> RedirectResponse:
    # WHICH parameters arrived, never their values: `code` is a credential and
    # `error_description` is free text the identity provider chose.
    logger.info("Auth callback hit with: %s", ",".join(sorted(request.query_params.keys())))

    idp_code = request.query_params.get("error")
    if idp_code:
        # `error` is a short IdP code (access_denied, server_error, ...).
        logger.warning("OAuth sign-in refused by the identity provider (%s)", idp_code[:40])
        return _redirect(LOGIN_PATH)

    # ONE flow: an authorization code, exchanged server-side.
    code = request.query_params.get("code")
    if not code:
        logger.info("Auth callback with no authorization code")
        return _redirect(LOGIN_PATH)

    if app_settings_env.get_settings().auth_is_cognito:
        # The `state` check comes BEFORE the exchange, because the exchange is
        # the thing being protected.
        if not _state_ok(request):
            logger.warning("OAuth callback rejected: state did not match")
            return _refuse()
        # `redirect_uri` has to be the same string the authorize call carried.
        tokens = cognito.exchange_code(code, callback_url())
        identity = cognito.validate_token(tokens["id_token"]) if tokens else None
        if not tokens or not identity:
            logger.warning("Cognito code exchange produced no usable session")
            # Spent either way: the same `state` must not buy a second exchange.
            return _refuse()
        return _land(
            request,
            tokens["id_token"],
            tokens.get("refresh_token") or "",
            refresh_expires=cognito.REFRESH_TOKEN_VALIDITY_SECONDS,
        )

    # Supabase: the verifier parked by `_start` is the browser binding. No
    # verifier, no exchange — and the cookies are spent either way.
    verifier = request.cookies.get(OAUTH_VERIFIER_COOKIE) or ""
    if not verifier:
        logger.warning("OAuth callback rejected: no code verifier for this browser")
        return _refuse()
    try:
        # No `redirect_to`: the exchange is bound by the verifier, and the body
        # is exactly what the Flask route sent (the stub's TypedDict marks the
        # key required; the client reads it with `.get`).
        session_response = _auth.get_supabase().auth.exchange_code_for_session(
            {"auth_code": code, "code_verifier": verifier}  # type: ignore[typeddict-item]
        )
        # The response carries the access and refresh tokens; log only
        # whether one came back.
        logger.info("Code exchange returned a session: %s", bool(session_response))
        if session_response and session_response.session:
            return _land(
                request,
                session_response.session.access_token,
                session_response.session.refresh_token,
            )
        logger.error("Code exchange returned no session")
        return _refuse()
    except Exception:
        logger.error("Code exchange failed", exc_info=True)  # phi-lint: ok no user data in scope
        return _refuse()
