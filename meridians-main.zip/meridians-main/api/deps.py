"""Request dependencies: who is calling, may they, and how often.

This module is what `flask.g` was. Flask's decorators resolved a request's
identity and org into three globals (`g.user`, `g.org`, `g.permissions`) that
any function five frames down could read; a FastAPI dependency hands the same
facts to the handler as an argument, which means a handler cannot forget to
ask and a test cannot forget to provide.

Three concerns, in the order a request meets them — the same order Flask runs
them in today, so behaviour does not change with the framework:

1. **CSRF** (§6.1, ADR 0021). Double-submit on every unsafe method, exempt
   only for a request carrying `Authorization: Bearer` — a browser will not
   attach that header cross-origin, so there is nothing to forge.
2. **Rate limit** (§9). The class limits and the key function come from
   `src/api/v2/limits.py` — the same strings flask-limiter is given, so the
   two surfaces cost an attacker the same.
3. **Auth.** The Cognito ID token from the HttpOnly cookie or the `Bearer`
   header, verified through `src.auth.validate_token` — the one seam that
   holds dual issuer acceptance (ADR 0021) — then the org and permissions from
   the database on every request, never from a token claim.

Never logged, at any level: tokens, passwords, email addresses.
"""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional, Tuple

from fastapi import Depends, Request

from src import auth as _auth
from src.api.v2 import errors as err
from src.api.v2.errors import ApiError
from src.api.v2.runs_common import org_id_of
from src.settings import forwarded_allow_ips

from .errors import RateLimited

logger = logging.getLogger(__name__)

#: The readable cookie `GET /api/v2/csrf` sets, and the headers §6.1 accepts.
#:
#: TWO NAMES, ONE TOKEN (P5AR3-10). `__Host-` is a prefix a browser enforces:
#: it refuses the cookie unless it is `Secure`, `Path=/` and carries no
#: `Domain`, which is exactly what stops a sibling host on the same registrable
#: domain — `something.meridiansgrp.com` — from writing a cookie the main site
#: then reads back as its own CSRF token. It therefore cannot be used without
#: TLS, and local development has none, so `api/routers/core.py` sets the
#: prefixed name when the session cookie is `Secure` and the bare name
#: otherwise. This reader accepts whichever arrived, preferring the prefixed
#: one, so a browser holding both from before a deploy is not locked out.
CSRF_COOKIE_HOST = "__Host-XSRF-TOKEN"
CSRF_COOKIE = "XSRF-TOKEN"
CSRF_COOKIE_NAMES = (CSRF_COOKIE_HOST, CSRF_COOKIE)
CSRF_HEADERS = ("X-CSRFToken", "X-CSRF-Token")

#: The header CloudFront adds when the origin request policy forwards it:
#: `<ip>:<port>` for the VIEWER, written by the edge itself and not by anybody
#: who could forge it. See `client_address`.
CLOUDFRONT_VIEWER_ADDRESS = "CloudFront-Viewer-Address"

#: Methods that change nothing and therefore need no CSRF token.
SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "TRACE"})

#: `"5/minute"` -> seconds. The three flask-limiter window names this codebase
#: actually uses; anything else is a typo and should fail loudly at import.
_WINDOWS = {"second": 1, "minute": 60, "hour": 3600, "day": 86400}


# --------------------------------------------------------------------- identity
@dataclass
class Identity:
    """Everything a handler is allowed to know about its caller.

    `refreshed` is the token set a silent refresh produced, if one happened.
    The handler writes it back with `apply_cookies(response)` — the FastAPI
    equivalent of the `make_response` branch at the end of `require_auth`,
    which exists so a 202 or a 204 still carries the new `Set-Cookie`.
    """

    user: Dict[str, Any]
    org: Optional[Dict[str, Any]] = None
    permissions: Optional[Dict[str, Any]] = None
    org_modules: Optional[set] = None
    #: From `public.superadmins`, read by `require_org` with the rest of the
    #: context. A UI hint for `/me` — every superadmin endpoint re-checks the
    #: table itself, so nothing is authorized on the strength of this flag.
    is_superadmin: bool = False
    bearer: bool = False
    refreshed: Optional[Dict[str, Any]] = field(default=None, repr=False)

    @property
    def user_id(self) -> Optional[str]:
        return self.user.get("id")

    @property
    def email(self) -> Optional[str]:
        return self.user.get("email")

    @property
    def org_id(self) -> Optional[str]:
        return (self.org or {}).get("org_id")

    @property
    def required_org_id(self) -> str:
        """The org id, or `ORG_REQUIRED` — never `None` and never `""`.

        `org_id` is `Optional` because an `Identity` exists before
        `require_org` has run. This one is the value a tenant-scoped call may
        use, and it is `runs_common.org_id_of` so that the FastAPI surface
        fails closed by the SAME rule and with the same sentence the Flask
        `org_id_or_403` used.
        """
        return org_id_of(self.org)

    def apply_cookies(self, response):
        """Write refreshed session cookies onto `response`, if any."""
        if self.refreshed:
            _auth.set_auth_cookies(
                response,
                self.refreshed["access_token"],
                self.refreshed["refresh_token"],
                self.refreshed.get("expires_in", 3600),
            )
        return response


def _bearer_token(request: Request) -> Optional[str]:
    """The `Authorization: Bearer` token, or None. Scheme match is loose on
    case (RFC 7235 says the scheme is case-insensitive) and strict on shape."""
    header = request.headers.get("Authorization") or ""
    scheme, _, value = header.partition(" ")
    if scheme.lower() != "bearer":
        return None
    return value.strip() or None


def resolve_identity(request: Request) -> Optional[Identity]:
    """The caller, or None when there is no usable credential.

    Mirrors `src.auth.require_auth` exactly, including the silent refresh:
    a valid access token wins; failing that, a refresh token is spent for a new
    one and the caller is resolved from that. The local-development bypass is
    the same function the Flask decorator uses, so a dev running
    `AUTH_BACKEND=disabled` sees one identity, not two.
    """
    if _auth._auth_disabled():
        # The built-in dev identity, or the synthetic user the local login
        # page chose ("Sign in as", `src/local_sign_in_as.py`).
        return Identity(user=_auth.bypass_user(request.cookies))

    token = _bearer_token(request)
    if token:
        user = _auth.validate_token(token)
        return Identity(user=user, bearer=True) if user else None

    access_token = request.cookies.get(_auth.ACCESS_TOKEN_COOKIE)
    refresh_token = request.cookies.get(_auth.REFRESH_TOKEN_COOKIE)

    user = _auth.validate_token(access_token) if access_token else None
    refreshed = None
    if not user and refresh_token:
        refreshed = _auth.try_refresh_token(refresh_token, access_token=access_token)
        if refreshed:
            user = _auth.validate_token(refreshed["access_token"])
    if not user:
        return None
    return Identity(user=user, refreshed=refreshed if user else None)


def _attach_org(identity: Identity) -> Identity:
    """Fill in the org half, or raise `ORG_REQUIRED`."""
    if _auth._auth_disabled():
        # A "Sign in as" user gets `org_context` itself, so one in no
        # organization is refused below exactly as a real one is.
        context = _auth.local_dev_org_context(identity.user)
    else:
        context = _auth.org_context(identity.user_id)
    if context is None:
        raise ApiError(err.ORG_REQUIRED, "Organization required.")
    # A context is not the same thing as an org. `src.auth.org_context` hands a
    # SUPERADMIN with no membership row a system context whose `org_id` is
    # `None` (so the SPA can render "System" rather than bounce them to
    # onboarding), and Flask then refused the first tenant-scoped thing they
    # asked for: every v2 service function begins `org_id_or_403()`, which is
    # `org_id_of` on that same row and raises `ORG_REQUIRED`. FastAPI had no
    # such second gate — the routers pass `identity.org_id` straight through —
    # so the same caller reached a write with `org_id=None` (or, in
    # `oneshot_runs._caller`, `""`). The gate goes here, once, where both
    # branches of the context lookup meet.
    identity.org = context["org"]
    identity.permissions = context["permissions"]
    identity.org_modules = context["org_modules"]
    identity.is_superadmin = bool(context.get("is_superadmin", False))
    org_id_of(identity.org)
    return identity


def require_user(request: Request) -> Identity:
    """FastAPI dependency: a signed-in caller, or `401 AUTH_REQUIRED`.

    Never a redirect. §6.2's path-first rule said anything under `/api/` must
    answer with JSON whatever headers it sent; on this surface there is no
    HTML to redirect to at all, so the rule is structural rather than a check.
    """
    identity = resolve_identity(request)
    if identity is None:
        raise ApiError(err.AUTH_REQUIRED, "Authentication required.")
    request.state.identity = identity
    return identity


def require_org(identity: Identity = Depends(require_user)) -> Identity:
    """FastAPI dependency: a signed-in caller WITH an org, or 401/403.

    401 stays distinguishable from 403 (§6.2): no credential routes the SPA to
    `/login`, a credential with no org routes it to onboarding.
    """
    return _attach_org(identity)


def require_permission(process: str, level: str = "access"):
    """FastAPI dependency: an org member holding `process:level`, or 403.

    The twin of `src.api.v2.routes.v2_permission`, which is
    `src.auth.require_permission` plus the `details.required` a §4.2 403 has
    to carry. Two differences from the Flask original, both of them the point
    of the move: the permissions are the ones `require_org` already read from
    the database on THIS request (never a token claim, never a second read),
    and there is no redirect branch — this surface has no HTML to redirect to.

    The local-development bypass is kept so a developer running
    `AUTH_BACKEND=disabled` is not gated by a permissions table they have no
    rows in; `local_dev_org_context()` grants everything anyway, so this is
    belt and braces rather than a second policy. A user chosen through the
    local "Sign in as" is NOT waved through (`bypass_grants_all`): their own
    rows decide, as for anybody.
    """

    def _dependency(identity: Identity = Depends(require_org)) -> Identity:
        # A "View as role" preview is enforced on the bypass too: that is the
        # only way a developer can see what the previewed role really gets.
        # So is support mode (ADR 0051): the supported org's admin context.
        if (
            _auth.bypass_grants_all(identity.user)
            and not _auth.previewing(identity.org)
            and not _auth.supporting(identity.org)
        ):
            return identity
        granted = (identity.permissions or {}).get(process) or {}
        allowed = granted.get("results" if level == "results" else "access", False)
        if not allowed:
            raise ApiError(
                err.PERMISSION_DENIED,
                "Permission denied",
                details={"required": {"process": process, "level": level}},
            )
        return identity

    return _dependency


def require_admin(identity: Identity = Depends(require_org)) -> Identity:
    """FastAPI dependency: the org's ADMIN role, or 403.

    `src.auth.require_role("admin")` without the flash-and-redirect half. It
    is a different gate from `require_permission`, deliberately: settings, the
    org name and user management are org-wide, while `config:access` is held
    by anyone who can clear a blocked run.

    No `details.required`, matching the Flask side — `v2_required_permission`
    was only ever set by `v2_permission`, so a role failure answered a bare
    `PERMISSION_DENIED` and the SPA reads it the same way.
    """
    if (identity.org or {}).get("role") != "admin":
        raise ApiError(err.PERMISSION_DENIED, "Permission denied")
    return identity


def require_admin_in(process: str):
    """FastAPI dependency: the org's ADMIN role AND the `process` door, or 403.

    For admin-only routes inside a module a superadmin can switch off for the
    org: an admin still gets 403 when the module is off (the module mask lives
    in the permissions `require_permission` reads).
    """
    door = require_permission(process, "access")

    def _dependency(identity: Identity = Depends(require_admin)) -> Identity:
        return door(identity)

    return _dependency


def optional_identity(request: Request) -> Optional[Identity]:
    """The caller if there is one, None if not. Never raises.

    For endpoints that are open by design — sign-in, the health check — but
    whose rate-limit bucket should still be the user's when one is known.
    """
    try:
        identity = resolve_identity(request)
    except Exception:  # pragma: no cover - a broken token is not an outage
        logger.debug("could not resolve an optional identity", exc_info=True)
        return None
    if identity is not None:
        request.state.identity = identity
    return identity


# ------------------------------------------------------------------------ CSRF
def csrf_enabled(request: Request) -> bool:
    """Is CSRF checking on for this app?

    Read off the mounted Flask app's `WTF_CSRF_ENABLED`, so there is ONE
    switch for both surfaces: a test that turns CSRF off for the Flask
    blueprint turns it off here too, and a deployment cannot end up protecting
    one half of its own API.
    """
    flask_app = getattr(request.app.state, "flask_app", None)
    if flask_app is None:
        return True
    try:
        return bool(flask_app.config.get("WTF_CSRF_ENABLED", True))
    except Exception:  # pragma: no cover - defensive
        return True


def check_csrf(request: Request) -> None:
    """Double-submit check for unsafe methods (§6.1, ADR 0021).

    The header must be present and equal to the readable CSRF cookie —
    `__Host-XSRF-TOKEN` where the session is `Secure`, `XSRF-TOKEN` where it is
    not, and whichever of the two arrived is the one compared (P5AR3-10).
    This is a comparison, not a signature check: the Flask side's token is
    signed against the *Flask session cookie*, which this surface has no
    access to, and re-deriving it here would mean two implementations of one
    control. Both checks reject the same attacker — an origin that cannot read
    the cookie cannot produce the header — so the weaker-looking one is the
    honest one to run here.

    `Authorization: Bearer` is exempt: the browser will not attach that header
    on a cross-origin form post, so there is nothing to forge.
    """
    if request.method.upper() in SAFE_METHODS:
        return
    if _bearer_token(request):
        return
    if not csrf_enabled(request):
        return

    sent = None
    for name in CSRF_HEADERS:
        value = request.headers.get(name)
        if value:
            sent = value
            break
    cookie = None
    for name in CSRF_COOKIE_NAMES:
        value = request.cookies.get(name)
        if value:
            cookie = value
            break
    if sent and cookie and hmac.compare_digest(sent, cookie):
        return
    raise ApiError(
        err.CSRF_INVALID,
        "Your session security token was missing or out of date. Refresh the token and try again.",
        retryable=True,
    )


# ------------------------------------------------------------------ rate limits
def parse_limit(spec: str) -> Tuple[int, int]:
    """`"40/hour"` -> `(40, 3600)`. The flask-limiter spellings used here."""
    count, _, window = spec.partition("/")
    seconds = _WINDOWS.get(window.strip().rstrip("s"))
    if seconds is None:
        raise ValueError(f"unsupported rate-limit window: {spec!r}")
    return int(count.strip()), seconds


def describe_limit(spec: str) -> str:
    """`"5/minute"` -> `"5 per 1 minute"` — flask-limiter's own wording.

    The 429 body quotes it under `details.limit`, and the SPA shows it. Two
    surfaces describing the same limit differently would read to a user like
    two different limits.
    """
    count, _, window = spec.partition("/")
    return f"{count.strip()} per 1 {window.strip()}"


def _trusted_networks() -> Tuple[list, bool, bool]:
    """`FORWARDED_ALLOW_IPS` as `(networks, is wildcard, names a real range)`.

    A bare address parses as a /32 or /128, so one list covers both spellings.
    An entry that is neither (a hostname — uvicorn accepts `"testclient"`, and
    `scripts/serve_api.sh` may be given one) is dropped from the network list:
    it can still never match a forwarded ENTRY, which is always an address.

    The third value is "does this name a range wider than a single host", which
    is how `client_address` tells the ECS deployment (the VPC's own CIDR) from
    Render (`*`) and from development (`127.0.0.1`). It is a proxy for "behind
    the origin-verifying CloudFront distribution", and `client_address` says why
    it has to be a proxy rather than a check.
    """
    entries = forwarded_allow_ips()
    if "*" in entries:
        return [], True, False
    networks = []
    ranged = False
    for entry in entries:
        try:
            network = ipaddress.ip_network(entry, strict=False)
        except ValueError:
            continue
        networks.append(network)
        if network.num_addresses > 1:
            ranged = True
    return networks, False, ranged


def _is_trusted_hop(hop: str, networks: list) -> bool:
    """Is this forwarded entry one of our own proxies?"""
    try:
        address = ipaddress.ip_address(hop.split("%", 1)[0])
    except ValueError:
        return False
    return any(address in network for network in networks)


def _viewer_address_ip(value: str) -> Optional[str]:
    """The `ip` half of CloudFront's `<ip>:<port>`, or None if it is not one.

    IPv6 arrives unbracketed (`2001:db8::1:52000`), so the split is from the
    RIGHT and the remainder is validated as an address rather than assumed.
    """
    candidate = value.strip()
    if not candidate:
        return None
    head, sep, _port = candidate.rpartition(":")
    for part in ((head if sep else ""), candidate):
        if not part:
            continue
        try:
            return str(ipaddress.ip_address(part.strip("[]")))
        except ValueError:
            continue
    return None


def client_address(request: Request) -> Optional[str]:
    """The caller's own address for rate-limiting (P5AR3-02).

    **Round 2 said "the rightmost entry". That was wrong on AWS**, and the
    reason is the shape of the chain rather than anything about the header. The
    rightmost entry is always a proxy — on AWS a CloudFront edge or the ALB, on
    Render the platform router's egress address — and every request through that
    path shares it. One bucket for the estate is the failure §9 exists to
    prevent, arrived at from the other end.

    So the rule is the one uvicorn's CIDR branch uses and the one the header was
    designed for: **walk from the right, skip every entry that is one of our own
    proxies, and take the first that is not.** Three inputs, in order:

    1. `CloudFront-Viewer-Address`, when the request is trusted to have come
       through CloudFront. The edge writes it about a socket it genuinely had,
       and nothing downstream of the viewer can add or change it.
    2. `X-Forwarded-For`, walked right to left past `FORWARDED_ALLOW_IPS`.
       `*` — which `render.yaml` must use, because Render publishes no inbound
       router range — means "trust the immediate peer and nothing else", so
       exactly one rightmost entry is skipped. Anything left of the first
       untrusted entry may have been written by the client and is ignored.
    3. `request.client.host`, when there is no forwarded header at all.

    **How the CloudFront trust is decided, and the assumption in it.** On AWS
    every ALB listener rule requires `X-Origin-Verify`, a secret only the edge
    sends (`infra/meridian/stacks/edge.py`), so a request that reached this
    process through the ALB came through CloudFront by construction. The app
    cannot check that itself: the secret is in Secrets Manager and the api task
    is given the database password and nothing else, so there is no expected
    value here to compare against. The stand-in is `FORWARDED_ALLOW_IPS` being a
    CIDR, which is true of the ECS task definition (the VPC's own range) and
    false of every other deployment — Render sets `*` and development
    `127.0.0.1`. The assumption is therefore: *a deployment that names a CIDR is
    the ECS one, and on the ECS one an ALB request has already been proved to
    have come from CloudFront.* A deployment that names a CIDR but is NOT behind
    an origin-verifying edge would let a peer inside that CIDR choose a bucket
    by sending this header; there is no such deployment, and ADR 0023's round-3
    note carries the residual.

    **The header is the VIEWER's, because there is exactly one CloudFront pass**
    (P5AR4-02). `edge.py` forwards it — `ALL_VIEWER_AND_CLOUDFRONT_2022` rather
    than `ALL_VIEWER` — and the SPA path is browser → CloudFront → ALB → api:
    the ALB's listener rules send `/api/*` to this service directly, before the
    `/*` rule that reaches the Next.js container, so no application hop sits in
    between (P5AR5-01).

    That ordering is the whole of why the header can be believed. CloudFront
    REWRITES `CloudFront-Viewer-Address` on every pass, about the socket it
    sees, so a design that sent these calls back out through the distribution
    would replace the viewer's address with the NAT gateway's and put every SPA
    request in one bucket — worse than the edge node it replaced. Nothing
    between the viewer and this process rewrites it.

    **CloudFront replaces viewer-sent `CloudFront-*` headers — verified on
    staging** (`docs/runbooks/deploy-staging.md` §7.2). It is AWS's
    documented behaviour for the `CloudFront-*` family rather than something this
    code can check, so the runbook sends a forged
    `CloudFront-Viewer-Address: 203.0.113.9:1` through the distribution and
    asserts the api bucketed on the real viewer. Behind that, the ALB answers a
    fixed 403 to anything not bearing the origin-verify secret, which only
    CloudFront holds.
    """
    viewer = request.headers.get(CLOUDFRONT_VIEWER_ADDRESS)
    networks, wildcard, ranged = _trusted_networks()
    if viewer and ranged:
        address = _viewer_address_ip(viewer)
        if address:
            return address

    client = request.client
    peer = client.host if client else None
    forwarded = request.headers.get("X-Forwarded-For")
    if not forwarded:
        return peer
    hops = [hop.strip() for hop in forwarded.split(",") if hop.strip()]
    if not hops:
        return peer

    if wildcard:
        # One hop of trust: the peer that appended the last entry. Everything
        # to the left of it is the client's word for it.
        remaining = hops[:-1]
    else:
        remaining = list(hops)
        while remaining and _is_trusted_hop(remaining[-1], networks):
            remaining.pop()
    if remaining:
        return remaining[-1]
    # Every entry was one of ours, so the leftmost is what the first of our own
    # proxies said about the socket it had. Not forgeable, and the only reading
    # left.
    return hops[0]


def rate_limit_key(request: Request) -> str:
    """The user when one is known, else the caller's address.

    Keyed this way and for the reason `limits.rate_limit_key` gives: behind the
    Next.js rewrite every request arrives from the proxy's address, so keying
    on the address alone would put the whole firm in one bucket.

    **The identity comes from `limit()`'s own `optional_identity` dependency**,
    not from a later one. Route-level dependencies resolve before the handler's
    parameters, so before P5AR2-07 `require_org` had not run yet and
    `request.state.identity` was always unset — every endpoint, authenticated
    or not, keyed on the address. There is no `org:user` branch here for the
    same reason: `optional_identity` resolves the token and stops, deliberately
    (a database read for the org on every rate-limited request would be the
    limiter doing more work than the endpoint), and a user id is already unique
    across orgs, so the org would only have been a second spelling of the same
    bucket. The Flask side's `org:user` spelling costs an attacker exactly the
    same, which is the property §9 asks for.

    The address is `client_address`, not `request.client`: see there.
    """
    identity = getattr(request.state, "identity", None)
    user_id = identity.user_id if identity else None
    if user_id:
        return f"user:{user_id}"
    return f"ip:{client_address(request) or 'unknown'}"


def rate_limit_scope(request: Request) -> str:
    """WHICH endpoint this request is being counted against (P5AR3-04).

    The matched route's TEMPLATE path, so every run of one operation shares a
    bucket and `/runs/{run_id}` is one endpoint rather than one per run — which
    is both what flask-limiter's per-view decorator does and the only reading
    that limits anything (a per-run bucket is no bucket).

    Starlette puts the matched `Route` in the ASGI scope before any dependency
    runs, so it is there by the time this is asked. The fallbacks exist for the
    paths that are not a matched `APIRoute` — a mounted app, an exception
    handler re-running a dependency — where a coarser bucket is right and no
    bucket is not.
    """
    route = request.scope.get("route")
    path = getattr(route, "path", None)
    if isinstance(path, str) and path:
        return path
    endpoint = request.scope.get("endpoint")
    name = getattr(endpoint, "__qualname__", None)
    if isinstance(name, str) and name:
        return name
    return request.url.path


class RateLimiter:
    """A fixed-window counter, in process, with flask-limiter's semantics.

    In process and honest about it, exactly as `memory://` is on the Flask
    side (ADR 0010 rules out Redis). This is the limiter for the Supabase
    backend on Render, which runs one worker; a second worker would give each
    its own allowance. On `DATABASE_BACKEND=postgres` `make_rate_limiter`
    hands out `PgRateLimiter` instead, which every api task shares (T:98).
    """

    def __init__(self, clock: Callable[[], float] = time.monotonic):
        self._clock = clock
        self._lock = threading.Lock()
        #: `{(spec, scope, key): (window_start, count)}`
        self._hits: Dict[Tuple[str, str, str], Tuple[float, int]] = {}

    def check(self, spec: str, key: str, scope: str = "") -> None:
        """Count this request, or raise the §9 429 with `Retry-After`.

        **`scope` is the endpoint, and leaving it out of the bucket was a bug**
        (P5AR3-04). Two endpoints declaring the same spelling — and `5/minute`
        is the spelling on `/auth/login`, `/auth/mfa`, `/auth/reset-password`
        and four more — shared one counter for one caller, so five login
        attempts spent the allowance for password reset and for MFA as well.
        That is not what flask-limiter does: a decorator there is per view
        function, and §9 lists the limits per operation. One counter per
        (spec, endpoint, caller) is that.
        """
        allowed, seconds = parse_limit(spec)
        now = self._clock()
        with self._lock:
            start, count = self._hits.get((spec, scope, key), (now, 0))
            if now - start >= seconds:
                start, count = now, 0
            count += 1
            self._hits[(spec, scope, key)] = (start, count)
            remaining = seconds - (now - start)
        if count > allowed:
            raise RateLimited(
                "You are sending requests faster than this endpoint "
                "allows. Wait a moment and try again.",
                retry_after=max(1, int(remaining) + 1),
                limit=describe_limit(spec),
            )

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


#: The prefix every limiter bucket carries in `public.api_quota_window`, so the
#: v3 quota counters (`client:`, `user:`, `authfail:`) and these never collide.
PG_BUCKET_PREFIX = "rl:"

#: `api_quota_window.bucket` is `CHECK (length(bucket) <= 200)` (revision 0013).
_PG_BUCKET_MAX = 200


class PgRateLimiter(RateLimiter):
    """The same limits, counted in Postgres so every api task shares them (T:98).

    `DATABASE_BACKEND=postgres` only (`make_rate_limiter`). The counter is
    revision 0013's `public.api_quota_window` — the table `/api/v3`'s quotas
    already count in, through the same one-statement
    `INSERT … ON CONFLICT DO UPDATE` (`api.v3.quotas.HIT_SQL`) — under an
    `rl:` bucket, so two tasks spend ONE allowance on `/auth/login` rather than
    one each. Still no Redis (ADR 0010).

    **Windows are aligned to the database clock** (`floor(epoch / window)`),
    not started at a caller's first hit as the in-process counter's are. Every
    task therefore agrees on when a window ends, which is the property that
    matters here; the price is that a burst straddling a boundary can get up to
    twice the allowance across two adjacent windows, which is flask-limiter's
    own fixed-window behaviour.

    **A database failure degrades to the in-process counter, not to no
    limit.** The credential endpoints do not otherwise need the database —
    sign-in talks to Cognito — so failing open would turn a database outage
    into an unlimited password-guessing window. Falling back to this task's
    own count keeps a limit, per task, until the database answers again.
    """

    def _bucket(self, spec: str, scope: str, key: str) -> str:
        bucket = f"{PG_BUCKET_PREFIX}{spec}:{scope}:{key}"
        if len(bucket) <= _PG_BUCKET_MAX:
            return bucket
        digest = hashlib.sha256(bucket.encode("utf-8")).hexdigest()
        return f"{PG_BUCKET_PREFIX}{digest}"

    def check(self, spec: str, key: str, scope: str = "") -> None:
        allowed, seconds = parse_limit(spec)
        try:
            from src import pg

            from .v3.quotas import HIT_SQL

            with pg.with_anonymous() as db:
                row = db.fetch_one(HIT_SQL, {"b": self._bucket(spec, scope, key), "w": seconds})
            if row is None:  # pragma: no cover - RETURNING always answers
                raise RuntimeError("the rate-limit counter returned no row")
            count, remaining = int(row["hits"]), int(row["remaining"])
        except Exception as exc:
            logger.warning(
                "rate-limit store unavailable; counting in this process instead (%s)",
                type(exc).__name__,
            )
            super().check(spec, key, scope)
            return
        if count > allowed:
            raise RateLimited(
                "You are sending requests faster than this endpoint "
                "allows. Wait a moment and try again.",
                retry_after=max(1, remaining),
                limit=describe_limit(spec),
            )


def make_rate_limiter() -> RateLimiter:
    """The limiter for this deployment: Postgres-backed on the RDS backend.

    Every other backend keeps the in-process counter — Render runs one worker
    and has no Postgres to count in, which is the same assumption the Flask
    side's flask-limiter `memory://` makes.
    """
    from src import settings

    if settings.get_settings().database_is_postgres:
        return PgRateLimiter()
    return RateLimiter()


def limit(spec: str):
    """A dependency applying `spec` to the endpoint it is declared on.

    No limiter on the app means no limiting — the same `limiter=None` opt-out
    `create_api_v2_blueprint` has, so a test can exercise a handler a hundred
    times without tripping a production limit.

    **It resolves the identity itself** (P5AR2-07). A dependency in a route's
    `dependencies=[...]` list runs before the handler's own parameters, so
    `require_user` / `require_org` had not written `request.state.identity` by
    the time the key was computed and EVERY endpoint keyed on the address —
    which behind one proxy is one bucket for the whole firm, the exact failure
    §9 names. `optional_identity` never raises and returns `None` for an
    anonymous caller, so the credential endpoints keep keying on the address
    (which is what §9 asks of them) and an authenticated call keys on its user.
    """

    def _dependency(
        request: Request, identity: Optional[Identity] = Depends(optional_identity)
    ) -> None:
        limiter = getattr(request.app.state, "limiter", None)
        if limiter is None:
            return
        limiter.check(spec, rate_limit_key(request), scope=rate_limit_scope(request))

    # Readable back off the route, which is how a test asks "is this endpoint
    # carrying the limit §9 says it should?" without sending the requests.
    # `limiter.limit(spec)` was introspectable on the Flask side by decorating
    # a recording stand-in; a dependency is a plain object, so it says so.
    _dependency.rate_limit = spec  # type: ignore[attr-defined]
    return _dependency
