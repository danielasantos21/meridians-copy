"""One `http_request` log line per request, FastAPI and Flask halves alike.

WHAT: a pure ASGI middleware, outermost in `api.main.create_app`, that opens
the request's log context (`src.log_setup.begin_request`) and, when the
response has started — or the app has raised — writes one record:

    {"event": "http_request", "http": {"method", "path", "status"},
     "duration_ms", "request_id", "error": {"code"}, "user": {"id"},
     "auth": {"issuer"}, "env", ...}

READS: the ASGI scope (method, the matched route, `state.request_id`) and the
context holder the auth seam and the envelope builders write into.
WRITES: that one log record, through the root logger's JSON handler.

`http.path` is the route TEMPLATE as matched — `/api/v2/runs/{run_id}`, or the
Flask rule `/api/v2/runs/<run_id>` — never the raw URL: a path parameter can be
an id and a download path can be a filename (ADR 0024 §4). A request nothing
matched is `<unmatched>`.

This line is also what the `HttpRequests` heartbeat counts (tracker T:138):
every request, health checks included, so a 5xx-free day is not a silent one.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Optional

from starlette.types import ASGIApp, Message, Receive, Scope, Send

from src import log_setup

logger = logging.getLogger("meridian.request")


def route_template(scope: Scope, holder: Optional[dict[str, Any]]) -> str:
    """The route as matched: Flask's rule, FastAPI's template, or `<unmatched>`."""
    if holder is not None and holder.get("route"):
        return str(holder["route"])
    route = scope.get("route")
    template = getattr(route, "path", None)
    # The Flask mount's own "path" is the empty prefix: a Flask path Flask did
    # not match is unmatched, not "".
    if isinstance(template, str) and template:
        return template
    return log_setup.UNMATCHED_ROUTE


class RequestLogMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        state = scope.setdefault("state", {})
        token = log_setup.begin_request(state)
        holder = log_setup.current()
        started = time.monotonic()
        status = {"code": 500}

        async def _send(message: Message) -> None:
            if message["type"] == "http.response.start":
                status["code"] = int(message["status"])
            await send(message)

        try:
            await self.app(scope, receive, _send)
        finally:
            try:
                self._log(scope, holder, status["code"], started)
            finally:
                log_setup.end_request(token)

    @staticmethod
    def _log(scope: Scope, holder: Optional[dict[str, Any]], status: int, started: float) -> None:
        extra: dict[str, Any] = {
            "event": log_setup.EVENT_HTTP_REQUEST,
            "http": {
                "method": str(scope.get("method", "")),
                "path": route_template(scope, holder),
                "status": status,
            },
            "duration_ms": int((time.monotonic() - started) * 1000),
        }
        if holder is not None and holder.get("error_code"):
            extra["error_code"] = holder["error_code"]
        logger.info("request served", extra=extra)
