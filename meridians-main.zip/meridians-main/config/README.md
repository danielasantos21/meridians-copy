# config/

Configuration files that are still read off the filesystem. **This folder is legacy and is
shrinking.** Nothing new belongs here: the migration's Rule 1
(`docs/architecture/repo-layout.md` §5) says all data and configuration live in Postgres.

## What is tracked here, and what is not

The mapping files hold real provider, payer and employee names, so the repo ships
**redacted `*.example.*` copies** and gitignores the real ones. On a fresh clone you copy
the example to its real name and fill it in:

| Tracked (safe) | Its real, **gitignored** counterpart |
|---|---|
| `mappings.example.xlsx` | `mappings.xlsx` |
| `provider_maps.example.json` | `provider_maps.json` |
| `employee_allocations.example.json` | `employee_allocations.json` |
| `mx_employee_roster.example.json` | `mx_employee_roster.json` |

Two non-client JSON files are tracked as they stand — `app_settings.json` (web-app
settings: file patterns, output directories) and `mso_mappings.json`. Both
are legacy: they migrate into Postgres tables the next time a phase touches them, and they
have a row in `docs/migration-tracker.md`.

`local_user_prefs.json` is per-machine and gitignored. `wearbly_order_roster.json` (a
Wearbly employee roster) stays in `.gitignore`/`.dockerignore` so a stray copy can never be
committed, even though Wearbly's code left Meridian on 2026-09-29 and its
`*.example.json` twin went with it.

## The real files do not have to live here

`MERIDIAN_DATA_DIR` moves the whole data tree somewhere else while keeping the same
relative shape — set it and `config/mappings.xlsx` is read from
`$MERIDIAN_DATA_DIR/config/mappings.xlsx` instead. Unset, it is the repo root. That is the
supported way to keep client data on the PHI volume and out of the repository entirely; see
`src/settings.py` (`data_dir`).

## What does not live here

- **Secrets.** Every credential comes from `.env` (gitignored) or, after the migration, AWS
  Secrets Manager. Never a key, a password, or a bank routing or account number in a file
  here.
- **New configuration of any kind.** No new `config/*.json`. A new setting goes in a
  Postgres table.
- **Generated output**, workbooks a process produced, or anything with patient data in it.
