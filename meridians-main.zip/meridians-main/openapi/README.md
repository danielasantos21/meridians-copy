# openapi/

**Generated, not written.** `meridian-v2.json` is the OpenAPI description of the `/api/v2`
surface, emitted from the pydantic models by `scripts/generate_openapi.py` (contract
§10.2). `meridian-v3.json` is the `/api/v3` description, generated from the FastAPI routes
themselves by `scripts/generate_openapi.py --v3` (Phase 12 T14, ADR 0043) — no registry.
It is NOT served live; partners receive it at onboarding. Editing either by hand achieves
nothing — the next generation overwrites it.

## How it is kept honest

`scripts/check_api_drift.sh` is the CI drift gate. It regenerates this file, regenerates
`web/src/lib/api/schema.d.ts` from it, checks the generation is deterministic (twice in a
row, byte-identical), and fails if either artifact differs from what is committed. So the
served API, this document and the TypeScript the front end compiles against cannot drift
apart silently.

For v3 it also regenerates `web/src/lib/api/v3/schema.d.ts` and the Python client in
`clients/python/meridian_client/`; `tests/test_openapi_matches_routes.py` and
`tests/test_python_client.py` run the Python half of the same checks in every pytest run,
and the `web` workflow regenerates both TypeScript files.

Regenerate locally with:

```bash
python scripts/generate_openapi.py
python scripts/generate_openapi.py --v3
python scripts/generate_python_client.py
```

## What happens to this folder

**It goes away in Phase 5a.** Once `/api/v2` is served by FastAPI, the framework produces
OpenAPI from the route signatures directly and there is nothing left to hand-generate — the
generator script, this file and the drift gate are replaced by FastAPI's own schema plus a
client-generation step. `/api/v3` (Phase 12) is FastAPI-native from the start.

## What does not live here

- Hand-written API documentation. The prose contract is `docs/api-v2-contract.md`.
- Generated clients. The TypeScript types live with the code that imports them
  (`web/src/lib/api/schema.d.ts`, `web/src/lib/api/v3/schema.d.ts`); the Python client is
  `clients/python/`.
